// نقطة دخول V2 (ES module) — البرومبت 02.02: يطبّق المظهر قبل الرسم، يقرأ الدور التجريبي من العنوان، يبني القشرة، ويقرأ رقم البناء.
// لا شبكة غير version.json ولا بيانات حقيقية (ADR-317: بلا كود/نمط مضمّن). التخزين الوحيد: تفضيل المظهر عبر حارس التخزين وعند اختيار المستخدم فقط.
import { t } from './core/i18n.js';
import { VERSION_URL } from './core/constants.js';
import * as store from './ui/store.js';
import { loadPrefs, applyTheme } from './ui/theme.js';
import { createShell } from './ui/shell.js';
import { roleFromSearch } from './ui/mock-session.js';
import { MOCK_UNREAD } from './data/mock.js';

function fillStatic() {
  document.querySelectorAll('[data-t]').forEach((el) => { el.textContent = t(el.getAttribute('data-t')); });
}

async function readVersion() {
  let v = '';
  try {
    const r = await fetch(VERSION_URL, { cache: 'no-store' });
    const j = await r.json();
    v = typeof j.version === 'string' ? j.version : '';
  } catch (e) { v = ''; }
  store.set({ version: v });
  const out = document.getElementById('build-version');
  if (out) out.textContent = v || t('foundation.status.unknown');
}

function boot() {
  applyTheme(loadPrefs().theme);
  fillStatic();
  store.set({ online: navigator.onLine !== false, role: roleFromSearch(location.search), unread: MOCK_UNREAD });
  createShell().start();
  readVersion();
}

boot();
