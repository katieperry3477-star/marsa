// مَرسى V2 — حارس التخزين المحلي الصغير (تفضيلات الواجهة فقط؛ البيانات الحقيقية في IndexedDB/الخادم لاحقاً).
// قائمة بيضاء: أي مفتاح لا يبدأ بـmarsa.v2. يُرفض بخطأ صريح، فلا يمكن لكود V2 أن يمس مفاتيح V1 أو التطبيق الأكاديمي ولو بالخطأ (R-100).
// كل وصول للـbackend داخل try/catch (وضع خاص/حصة/تعطيل) والفشل يُرجع حالة لا استثناءً، فتعمل الواجهة بلا تخزين.
import { STORAGE_PREFIX } from './constants.js';

export function assertKey(key) {
  if (typeof key !== 'string' || key.indexOf(STORAGE_PREFIX) !== 0 || key.length === STORAGE_PREFIX.length) {
    throw new Error('مفتاح تخزين غير مسموح في V2: ' + String(key));
  }
  return key;
}

export function createStorage(backend) {
  function safe(fn, fallback) { try { return fn(); } catch (e) { return fallback; } }
  return {
    available() { return !!backend && safe(() => { const k = STORAGE_PREFIX + 'probe'; backend.setItem(k, '1'); backend.removeItem(k); return true; }, false); },
    getJSON(key, fallback) {
      assertKey(key);
      return safe(() => { const raw = backend.getItem(key); return raw === null || raw === undefined ? fallback : JSON.parse(raw); }, fallback);
    },
    setJSON(key, value) {
      assertKey(key);
      return safe(() => { backend.setItem(key, JSON.stringify(value)); return true; }, false);
    },
    remove(key) { assertKey(key); return safe(() => { backend.removeItem(key); return true; }, false); },
    // مفاتيح V2 فقط؛ لا تُعرض مفاتيح غيرها أبداً
    keys() {
      return safe(() => { const out = []; for (let i = 0; i < backend.length; i++) { const k = backend.key(i); if (k && k.indexOf(STORAGE_PREFIX) === 0) out.push(k); } return out; }, []);
    }
  };
}

export function browserStorage() {
  try { return createStorage(typeof localStorage !== 'undefined' ? localStorage : null); } catch (e) { return createStorage(null); }
}
