// t(key): يُرجع النص أو المفتاح نفسه عند غيابه (ويُسجَّل الغائب ليكشفه الاختبار) — لا استثناء في الإنتاج.
// tf(key, vars): نفس t مع استبدال {name} بقيم المتغيرات (نصوص بلا تركيب جمل داخل المنطق).
// النصوص = ar.js (يدوي) + ar-nav.js (مولَّد من خريطة الواجهات).
import { ar } from '../i18n/ar.js';
import { arNav } from '../i18n/ar-nav.js';

const all = Object.freeze(Object.assign({}, ar, arNav));
const missing = new Set();
export function t(key) {
  if (Object.prototype.hasOwnProperty.call(all, key)) return all[key];
  missing.add(key);
  return key;
}
export function tf(key, vars) {
  let s = t(key);
  if (vars) Object.keys(vars).forEach((k) => { s = s.split('{' + k + '}').join(String(vars[k])); });
  return s;
}
export function missingKeys() { return Array.from(missing); }
export function allKeys() { return Object.keys(all); }
