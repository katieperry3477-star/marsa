// تحميل كسول لوحدات V1 النقية المنسوخة في v2/legacy (انظر v2/legacy/MANIFEST.json). الوحدات UMD تضع نفسها على globalThis.
// يُحمَّل ملف واحد فقط بـ<script src> من الأصل نفسه (متوافق مع CSP: script-src 'self')، ولا يُحمَّل أي اسم خارج القائمة.
const GLOBALS = Object.freeze({
  'safe-text': 'MarsaSafeText',
  'attendance-model': 'MarsaAttendanceModel',
  'grades-model': 'MarsaGradesModel',
  'exams-model': 'MarsaExamsModel',
  'schedule-model': 'MarsaScheduleModel',
  'payments-model': 'MarsaPaymentsModel'
});
const pending = new Map();

export function legacyNames() { return Object.keys(GLOBALS); }

export function loadLegacy(name, doc = document, root = globalThis) {
  if (!Object.prototype.hasOwnProperty.call(GLOBALS, name)) return Promise.reject(new Error('وحدة قديمة غير مسموحة: ' + String(name)));
  const g = GLOBALS[name];
  if (root[g]) return Promise.resolve(root[g]);
  if (pending.has(name)) return pending.get(name);
  const p = new Promise((resolve, reject) => {
    const s = doc.createElement('script');
    s.src = new URL('../../legacy/' + name + '.js', import.meta.url).href;
    s.async = true;
    s.onload = () => (root[g] ? resolve(root[g]) : reject(new Error('الوحدة لم تعرّف ' + g)));
    s.onerror = () => { pending.delete(name); reject(new Error('تعذّر تحميل ' + name)); };
    doc.head.appendChild(s);
  });
  pending.set(name, p);
  return p;
}
