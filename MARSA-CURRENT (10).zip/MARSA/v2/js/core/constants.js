// مَرسى V2 — ثوابت العزل عن V1 (ADR-301، R-100). وحدة ES نقية بلا تأثيرات جانبية.
// V2 لا يقرأ ولا يكتب أي مفتاح خارج marsa.v2.* ولا يلمس قواعد IndexedDB غير marsa-v2.
export const APP_ID = 'marsa';
export const APP_GENERATION = 'v2';
export const STORAGE_PREFIX = 'marsa.v2.';
export const IDB_NAME = 'marsa-v2';
// مفاتيح V1 وfull.html المحظورة على V2 قراءةً وكتابةً (للتوثيق والاختبار؛ الحارس يعتمد القائمة البيضاء STORAGE_PREFIX لا هذه القائمة)
export const FORBIDDEN_PREFIXES = Object.freeze(['marsa.v1.', 'marsa.academic.', 'marsa.']);
export const VERSION_URL = './version.json';
