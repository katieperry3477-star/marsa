// أيقونات SVG مضمّنة (UI-MAP §9-ج): 24×24، خط 2، أطراف مدوّرة، currentColor. بيانات مسارات فقط؛ العناصر تُبنى بـcreateElementNS (لا innerHTML).
// الأسهم مرسومة للاتجاه RTL مباشرة (الرجوع يتجه يميناً)، فلا حاجة لقلب CSS.
export const ICONS = Object.freeze({
  menu: ['M4 6h16', 'M4 12h16', 'M4 18h16'],
  close: ['M6 6l12 12', 'M18 6L6 18'],
  back: ['M5 12h14', 'M13 6l6 6-6 6'],
  chevron: ['M6 9l6 6 6-6'],
  bell: ['M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z', 'M10 21h4'],
  home: ['M4 11l8-7 8 7', 'M6 10v10h12V10', 'M10 20v-5h4v5'],
  book: ['M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z', 'M5 17a3 3 0 0 1 3-3h10'],
  user: ['M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', 'M4 20a8 8 0 0 1 16 0'],
  users: ['M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z', 'M2.5 20a6.5 6.5 0 0 1 13 0', 'M16 4.5a3.5 3.5 0 0 1 0 6.5', 'M18 14.5a6.5 6.5 0 0 1 3.5 5.5'],
  grid: ['M4 4h7v7H4z', 'M13 4h7v7h-7z', 'M4 13h7v7H4z', 'M13 13h7v7h-7z'],
  gauge: ['M4 17a8 8 0 1 1 16 0', 'M12 17l4-5', 'M12 17h.01'],
  server: ['M4 5h16v6H4z', 'M4 13h16v6H4z', 'M8 8h.01', 'M8 16h.01'],
  hourglass: ['M7 3h10', 'M7 21h10', 'M8 3v4a4 4 0 0 0 1.5 3L12 12l-2.5 2A4 4 0 0 0 8 17v4', 'M16 3v4a4 4 0 0 1-1.5 3L12 12l2.5 2A4 4 0 0 1 16 17v4'],
  wifioff: ['M3 3l18 18', 'M5 12.5a10 10 0 0 1 4-2.4', 'M8.5 16a5 5 0 0 1 5-1.2', 'M12 20h.01', 'M13.5 6.2a14 14 0 0 1 7.5 3.3', 'M2 9.5A14 14 0 0 1 5.5 7'],
  eye: ['M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z', 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z'],
  alert: ['M12 3l10 18H2z', 'M12 10v5', 'M12 18h.01'],
  inbox: ['M4 13l2-8h12l2 8', 'M4 13v6h16v-6', 'M4 13h5l1 2h4l1-2h5'],
  refresh: ['M20 11a8 8 0 0 0-14-4L4 9', 'M4 4v5h5', 'M4 13a8 8 0 0 0 14 4l2-2', 'M20 20v-5h-5'],
  check: ['M5 12l5 5L20 7'],
  lock: ['M6 11h12v9H6z', 'M8 11V8a4 4 0 0 1 8 0v3'],
  logout: ['M14 4h5v16h-5', 'M9 8l-4 4 4 4', 'M5 12h10'],
  settings: ['M4 7h9', 'M17 7h3', 'M4 17h3', 'M11 17h9', 'M15 5v4', 'M9 15v4'],
  info: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', 'M12 11v5', 'M12 8h.01'],
  calendar: ['M4 6h16v14H4z', 'M4 10h16', 'M8 3v4', 'M16 3v4'],
  clipboard: ['M8 4h8v3H8z', 'M6 6H5v15h14V6h-1', 'M9 12h6', 'M9 16h6'],
  megaphone: ['M4 10v4h3l7 4V6L7 10H4z', 'M17 9a4 4 0 0 1 0 6'],
  chart: ['M5 20V10', 'M12 20V4', 'M19 20v-7'],
  wallet: ['M4 7a2 2 0 0 1 2-2h12v2', 'M4 7v11a2 2 0 0 0 2 2h14V9H6a2 2 0 0 1-2-2z', 'M16 14h.01'],
  shield: ['M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z'],
  archive: ['M4 5h16v4H4z', 'M5 9v10h14V9', 'M10 13h4'],
  pin: ['M9 4h6l-1 6 3 3H7l3-3z', 'M12 13v7'],
  file: ['M6 3h8l4 4v14H6z', 'M14 3v4h4'],
  plus: ['M12 5v14', 'M5 12h14'],
  clock: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', 'M12 7v5l3 2'],
  sun: ['M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', 'M12 2v2', 'M12 20v2', 'M2 12h2', 'M20 12h2', 'M5 5l1.5 1.5', 'M17.5 17.5L19 19', 'M5 19l1.5-1.5', 'M17.5 6.5L19 5'],
  moon: ['M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z'],
  auto: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', 'M12 3v18']
});

// أيقونة كل شاشة في القائمة الجانبية (الافتراضي: file)
export const SCREEN_ICON = Object.freeze({
  'SC-HOME-S': 'home', 'SC-HOME-R': 'home', 'SC-DEV-HOME': 'gauge',
  'SC-PREPS-TODAY': 'book', 'SC-PREPS-TOMORROW': 'calendar', 'SC-EXAM': 'clipboard', 'SC-PREPS-ARCHIVE': 'archive', 'SC-PREP-FORM': 'plus',
  'SC-HOMEWORK': 'file', 'SC-SCHEDULE': 'calendar', 'SC-EXAMS': 'clipboard', 'SC-ANNOUNCE': 'megaphone', 'SC-NOTIFS': 'bell',
  'SC-PROFILE': 'user', 'SC-ABSENCES-MINE': 'calendar', 'SC-GRADES-MINE': 'chart', 'SC-PAYMENTS-MINE': 'wallet',
  'SC-CLASS-MGMT': 'grid', 'SC-STUDENTS': 'users', 'SC-ATTENDANCE': 'check', 'SC-GRADES': 'chart', 'SC-COSTS': 'wallet',
  'SC-REPS': 'users', 'SC-SUPPORT': 'eye', 'SC-AUDIT': 'shield', 'SC-SYSTEM': 'server', 'SC-BACKUP': 'archive',
  'SC-SETTINGS': 'settings', 'SC-ABOUT': 'info'
});
export const ROLE_ICON = Object.freeze({ student: 'book', rep: 'users', dev: 'gauge' });
