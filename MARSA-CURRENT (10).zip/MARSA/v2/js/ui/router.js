// موجّه المسارات بـlocation.hash (#/…) كما في الخريطة: بلا خادم توجيه. حارس الواجهة فقط — الخادم/RLS هو الحكم (R-029).
// القواعد: المسار الأخص (ثابت قبل :param) يربح بغض النظر عن الدور؛ ثم يُفحص الدور: غير مسموح ◄ forbidden بلا أي طلب بيانات؛ لا مطابقة ◄ notfound.
// مع التساوي في الأخصية (مثل #/home للطالب والممثل) تُفضَّل الشاشة المسموحة للدور.

export function parseHash(hash) {
  let h = String(hash || '');
  if (h.charAt(0) === '#') h = h.slice(1);
  const qi = h.indexOf('?');
  const rawPath = qi > -1 ? h.slice(0, qi) : h;
  const rawQuery = qi > -1 ? h.slice(qi + 1) : '';
  const query = {};
  rawQuery.split('&').forEach((p) => { if (!p) return; const i = p.indexOf('='); let k = i > -1 ? p.slice(0, i) : p, v = i > -1 ? p.slice(i + 1) : ''; try { k = decodeURIComponent(k); v = decodeURIComponent(v); } catch (e) { /* يُترك كما هو */ } query[k] = v; });
  let path = rawPath;
  if (path.length > 1 && path.charAt(path.length - 1) === '/') path = path.slice(0, -1);
  return { path: path || '/', query };
}

// هل هذا الهاش مسار تطبيق؟ (#/… أو فارغ). #main وأمثاله روابط داخل الصفحة فلا يعالجها الموجّه.
export function isRouteHash(hash) {
  const h = String(hash || '');
  return h === '' || h === '#' || h.indexOf('#/') === 0;
}

export function matchPattern(pattern, path) {
  const ps = pattern.split('/').filter(Boolean), xs = path.split('/').filter(Boolean);
  if (ps.length !== xs.length) return null;
  const params = {};
  let score = 0;
  for (let i = 0; i < ps.length; i++) {
    if (ps[i].charAt(0) === ':') {
      let v = xs[i];
      try { v = decodeURIComponent(v); } catch (e) { return null; }
      if (!v) return null;
      params[ps[i].slice(1)] = v;
    } else if (ps[i] === xs[i]) score += 2;
    else return null;
  }
  return { params, score: score + (ps.length ? 0 : 1) };
}

// يرجع { type: 'ok'|'forbidden'|'notfound'|'root', screen, params, query, path }
export function resolve(screens, role, hash) {
  const { path, query } = parseHash(hash);
  if (path === '/') return { type: 'root', path, query, params: {}, screen: null };
  let best = null;
  Object.keys(screens).forEach((id) => {
    const sc = screens[id];
    sc.routes.forEach((pat) => {
      const m = matchPattern(pat, path);
      if (!m) return;
      const allowed = !!role && sc.roles.indexOf(role) > -1;
      if (!best || m.score > best.score || (m.score === best.score && allowed && !best.allowed)) best = { screen: sc, params: m.params, score: m.score, allowed };
    });
  });
  if (!best) return { type: 'notfound', path, query, params: {}, screen: null };
  if (!best.allowed) return { type: 'forbidden', path, query, params: {}, screen: null };
  return { type: 'ok', path, query, params: best.params, screen: best.screen };
}
