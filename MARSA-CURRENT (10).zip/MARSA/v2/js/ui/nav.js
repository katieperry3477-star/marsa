// مساعدات التنقل المبنية على nav-config.js (المولَّد من خريطة الواجهات): المسار الرئيسي لكل دور، تمييز التبويب الأب، عنوان الصفحة حسب الدور.
import { TABBARS, SIDEBARS, SCREENS } from './nav-config.js';

export function firstRoute(screenId) { const s = SCREENS[screenId]; return s && s.routes.length ? s.routes[0] : null; }
export function hrefOf(screenId) { const r = firstRoute(screenId); return r ? '#' + r : '#/'; }
export function homeRoute(role) { return firstRoute(TABBARS[role][0].screen) || '/home'; }

// تمييز التبويب الأب (UI-MAP §2). يرجع معرّف شاشة التبويب النشط.
const STUDENT_PREPS = ['SC-PREPS-TODAY', 'SC-PREPS-TOMORROW', 'SC-EXAM', 'SC-PREPS-ARCHIVE', 'SC-PREP-VIEW', 'SC-HOMEWORK', 'SC-EXAMS'];
const STUDENT_PROFILE = ['SC-PROFILE', 'SC-ABSENCES-MINE', 'SC-GRADES-MINE', 'SC-PAYMENTS-MINE'];
const REP_CLASS_IDS = ['SC-EXAMS', 'SC-EXAM-FORM', 'SC-SCHEDULE', 'SC-ANNOUNCE', 'SC-ANNOUNCE-FORM'];
const REP_PREPS = ['SC-PREPS-TODAY', 'SC-PREPS-TOMORROW', 'SC-EXAM', 'SC-PREPS-ARCHIVE', 'SC-PREP-VIEW', 'SC-PREP-FORM', 'SC-HOMEWORK'];
const DEV_SYSTEM = ['SC-SYSTEM', 'SC-BACKUP', 'SC-AUDIT'];
const DEV_REPS = ['SC-REPS', 'SC-SUPPORT'];

export function parentTab(role, screenId, path) {
  const tabs = TABBARS[role].map((t) => t.screen);
  if (role === 'student') return STUDENT_PREPS.indexOf(screenId) > -1 ? tabs[1] : STUDENT_PROFILE.indexOf(screenId) > -1 ? tabs[2] : tabs[0];
  if (role === 'rep') {
    // «إدارة الصف» لكل شاشة مساراتها تحت /class (من جدول المسارات) أو المسار الحالي، إضافة إلى الشاشات المسمّاة
    const sc = SCREENS[screenId];
    const inClass = (sc && sc.routes.some((r) => r.indexOf('/class') === 0)) || String(path || '').indexOf('/class') === 0;
    if (inClass || REP_CLASS_IDS.indexOf(screenId) > -1) return tabs[1];
    return REP_PREPS.indexOf(screenId) > -1 ? tabs[2] : tabs[0];
  }
  return DEV_SYSTEM.indexOf(screenId) > -1 ? tabs[2] : DEV_REPS.indexOf(screenId) > -1 ? tabs[1] : tabs[0];
}

// الشاشة «جذر تبويب» إن كانت هدف أحد عناصر الشريط السفلي لهذا الدور (عليها السطر الهادئ «قيد التطوير» ولا زر رجوع)
export function isTabRoot(role, screenId) { return TABBARS[role].some((t) => t.screen === screenId); }

// بلا زر رجوع: الجذور وصفحات التبويب (الثلاث)؛ ما سواها أعمق
export function isDeep(role, screenId) {
  const sc = SCREENS[screenId];
  if (!sc) return true;
  if (sc.kind === 'root' || sc.kind === 'tabpage') return false;
  return !isTabRoot(role, screenId);
}

// عنوان الصفحة حسب الدور: تسمية الشريط/القائمة لهذا الدور إن وُجدت (مثل «حسابي» للممثل) وإلا عنوان الشاشة
export function titleKey(role, screenId) {
  const tab = TABBARS[role].find((t) => t.screen === screenId);
  if (tab) return tab.label;
  let found = null;
  SIDEBARS[role].forEach((g) => g.items.forEach((it) => { if (it.type === 'link' && it.screen === screenId && !found) found = it.label; }));
  if (found) return found;
  const sc = SCREENS[screenId];
  return sc ? sc.title : 'app.title';
}
