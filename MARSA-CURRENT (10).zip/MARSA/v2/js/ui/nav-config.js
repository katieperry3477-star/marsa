// مولَّد بـscripts/v2-nav-sync.js من tests/ui/ui-map-v2.js — لا تعدّله يدوياً (UI-MAP-V2 §2، §4، §7). النصوص في ar-nav.js بمفاتيح.
// الجداول: الأشرطة السفلية (3 عناصر لكل دور)، القوائم الجانبية، بنود «قيد التطوير»، الشاشات (مسارات وأدوار وحالات).
export const ROLES = Object.freeze(["student","rep","dev"]);
export const TABBARS = Object.freeze({
  "student": [
    {
      "label": "tab.student.0",
      "screen": "SC-HOME-S",
      "icon": "home"
    },
    {
      "label": "tab.student.1",
      "screen": "SC-PREPS-TODAY",
      "icon": "book"
    },
    {
      "label": "tab.student.2",
      "screen": "SC-PROFILE",
      "icon": "user"
    }
  ],
  "rep": [
    {
      "label": "tab.rep.0",
      "screen": "SC-HOME-R",
      "icon": "home"
    },
    {
      "label": "tab.rep.1",
      "screen": "SC-CLASS-MGMT",
      "icon": "grid"
    },
    {
      "label": "tab.rep.2",
      "screen": "SC-PREPS-TODAY",
      "icon": "book"
    }
  ],
  "dev": [
    {
      "label": "tab.dev.0",
      "screen": "SC-DEV-HOME",
      "icon": "gauge"
    },
    {
      "label": "tab.dev.1",
      "screen": "SC-REPS",
      "icon": "users"
    },
    {
      "label": "tab.dev.2",
      "screen": "SC-SYSTEM",
      "icon": "server"
    }
  ]
});
export const SIDEBARS = Object.freeze({
  "student": [
    {
      "title": null,
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.student.SC-HOME-S",
          "screen": "SC-HOME-S"
        }
      ]
    },
    {
      "title": "grp.student.1",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.student.SC-PREPS-TODAY",
          "screen": "SC-PREPS-TODAY"
        },
        {
          "type": "link",
          "label": "sb.student.SC-PREPS-TOMORROW",
          "screen": "SC-PREPS-TOMORROW"
        },
        {
          "type": "link",
          "label": "sb.student.SC-EXAM",
          "screen": "SC-EXAM"
        },
        {
          "type": "link",
          "label": "sb.student.SC-PREPS-ARCHIVE",
          "screen": "SC-PREPS-ARCHIVE"
        }
      ]
    },
    {
      "title": "grp.student.2",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.student.SC-HOMEWORK",
          "screen": "SC-HOMEWORK"
        },
        {
          "type": "link",
          "label": "sb.student.SC-SCHEDULE",
          "screen": "SC-SCHEDULE"
        },
        {
          "type": "link",
          "label": "sb.student.SC-EXAMS",
          "screen": "SC-EXAMS"
        },
        {
          "type": "link",
          "label": "sb.student.SC-ANNOUNCE",
          "screen": "SC-ANNOUNCE"
        },
        {
          "type": "link",
          "label": "sb.student.SC-NOTIFS",
          "screen": "SC-NOTIFS"
        }
      ]
    },
    {
      "title": "grp.student.3",
      "footer": false,
      "collapsible": true,
      "items": [
        {
          "type": "link",
          "label": "sb.student.SC-PROFILE",
          "screen": "SC-PROFILE"
        },
        {
          "type": "link",
          "label": "sb.student.SC-ABSENCES-MINE",
          "screen": "SC-ABSENCES-MINE"
        },
        {
          "type": "link",
          "label": "sb.student.SC-GRADES-MINE",
          "screen": "SC-GRADES-MINE"
        },
        {
          "type": "link",
          "label": "sb.student.SC-PAYMENTS-MINE",
          "screen": "SC-PAYMENTS-MINE"
        }
      ]
    },
    {
      "title": "grp.student.4",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "future",
          "key": "teachers"
        },
        {
          "type": "future",
          "key": "chat"
        },
        {
          "type": "future",
          "key": "english"
        }
      ]
    },
    {
      "title": null,
      "footer": true,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.student.SC-SETTINGS",
          "screen": "SC-SETTINGS"
        },
        {
          "type": "link",
          "label": "sb.student.SC-ABOUT",
          "screen": "SC-ABOUT"
        },
        {
          "type": "action",
          "action": "lock",
          "label": "action.lock"
        },
        {
          "type": "action",
          "action": "logout",
          "label": "action.logout"
        }
      ]
    }
  ],
  "rep": [
    {
      "title": null,
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.rep.SC-HOME-R",
          "screen": "SC-HOME-R"
        }
      ]
    },
    {
      "title": "grp.rep.1",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.rep.SC-STUDENTS",
          "screen": "SC-STUDENTS"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-ATTENDANCE",
          "screen": "SC-ATTENDANCE"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-GRADES",
          "screen": "SC-GRADES"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-EXAMS",
          "screen": "SC-EXAMS"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-SCHEDULE",
          "screen": "SC-SCHEDULE"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-COSTS",
          "screen": "SC-COSTS"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-ANNOUNCE",
          "screen": "SC-ANNOUNCE"
        }
      ]
    },
    {
      "title": "grp.rep.2",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.rep.SC-PREPS-TODAY",
          "screen": "SC-PREPS-TODAY"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-PREPS-TOMORROW",
          "screen": "SC-PREPS-TOMORROW"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-EXAM",
          "screen": "SC-EXAM"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-PREPS-ARCHIVE",
          "screen": "SC-PREPS-ARCHIVE"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-PREP-FORM",
          "screen": "SC-PREP-FORM"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-HOMEWORK",
          "screen": "SC-HOMEWORK"
        }
      ]
    },
    {
      "title": null,
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.rep.SC-NOTIFS",
          "screen": "SC-NOTIFS"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-PROFILE",
          "screen": "SC-PROFILE"
        }
      ]
    },
    {
      "title": "grp.rep.4",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "future",
          "key": "teachers"
        },
        {
          "type": "future",
          "key": "principal"
        },
        {
          "type": "future",
          "key": "chat"
        },
        {
          "type": "future",
          "key": "classes"
        },
        {
          "type": "future",
          "key": "english"
        }
      ]
    },
    {
      "title": null,
      "footer": true,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.rep.SC-SETTINGS",
          "screen": "SC-SETTINGS"
        },
        {
          "type": "link",
          "label": "sb.rep.SC-ABOUT",
          "screen": "SC-ABOUT"
        },
        {
          "type": "action",
          "action": "lock",
          "label": "action.lock"
        },
        {
          "type": "action",
          "action": "logout",
          "label": "action.logout"
        }
      ]
    }
  ],
  "dev": [
    {
      "title": null,
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.dev.SC-DEV-HOME",
          "screen": "SC-DEV-HOME"
        }
      ]
    },
    {
      "title": "grp.dev.1",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.dev.SC-REPS",
          "screen": "SC-REPS"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-SUPPORT",
          "screen": "SC-SUPPORT"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-AUDIT",
          "screen": "SC-AUDIT"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-SYSTEM",
          "screen": "SC-SYSTEM"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-BACKUP",
          "screen": "SC-BACKUP"
        }
      ]
    },
    {
      "title": "grp.dev.2",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.dev.SC-CLASS-MGMT",
          "screen": "SC-CLASS-MGMT"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-PREPS-TODAY",
          "screen": "SC-PREPS-TODAY"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-PREPS-TOMORROW",
          "screen": "SC-PREPS-TOMORROW"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-EXAM",
          "screen": "SC-EXAM"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-PREPS-ARCHIVE",
          "screen": "SC-PREPS-ARCHIVE"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-ANNOUNCE",
          "screen": "SC-ANNOUNCE"
        }
      ]
    },
    {
      "title": null,
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.dev.SC-NOTIFS",
          "screen": "SC-NOTIFS"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-PROFILE",
          "screen": "SC-PROFILE"
        }
      ]
    },
    {
      "title": "grp.dev.4",
      "footer": false,
      "collapsible": false,
      "items": [
        {
          "type": "future",
          "key": "teachers"
        },
        {
          "type": "future",
          "key": "principal"
        },
        {
          "type": "future",
          "key": "chat"
        },
        {
          "type": "future",
          "key": "classes"
        },
        {
          "type": "future",
          "key": "english"
        }
      ]
    },
    {
      "title": null,
      "footer": true,
      "collapsible": false,
      "items": [
        {
          "type": "link",
          "label": "sb.dev.SC-SETTINGS",
          "screen": "SC-SETTINGS"
        },
        {
          "type": "link",
          "label": "sb.dev.SC-ABOUT",
          "screen": "SC-ABOUT"
        },
        {
          "type": "action",
          "action": "lock",
          "label": "action.lock"
        },
        {
          "type": "action",
          "action": "logout",
          "label": "action.logout"
        }
      ]
    }
  ]
});
export const FUTURE = Object.freeze({
  "teachers": {
    "name": "future.teachers",
    "text": "future.teachers.text",
    "note": "future.teachers.note",
    "roles": [
      "student",
      "rep",
      "dev"
    ]
  },
  "principal": {
    "name": "future.principal",
    "text": "future.principal.text",
    "note": "future.principal.note",
    "roles": [
      "rep",
      "dev"
    ]
  },
  "chat": {
    "name": "future.chat",
    "text": "future.chat.text",
    "note": "future.chat.note",
    "roles": [
      "student",
      "rep",
      "dev"
    ]
  },
  "classes": {
    "name": "future.classes",
    "text": "future.classes.text",
    "note": "future.classes.note",
    "roles": [
      "rep",
      "dev"
    ]
  },
  "english": {
    "name": "future.english",
    "text": "future.english.text",
    "note": "future.english.note",
    "roles": [
      "student",
      "rep",
      "dev"
    ]
  }
});
export const SCREENS = Object.freeze({
  "SC-INTRO": {
    "id": "SC-INTRO",
    "title": "screen.SC-INTRO",
    "routes": [],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "system",
    "states": "",
    "prompt": "02.02"
  },
  "SC-LOGIN-DEV": {
    "id": "SC-LOGIN-DEV",
    "title": "screen.SC-LOGIN-DEV",
    "routes": [
      "/login"
    ],
    "roles": [
      "dev"
    ],
    "kind": "auth",
    "states": "XV",
    "prompt": "04.01"
  },
  "SC-ACTIVATE": {
    "id": "SC-ACTIVATE",
    "title": "screen.SC-ACTIVATE",
    "routes": [
      "/activate"
    ],
    "roles": [
      "student",
      "rep"
    ],
    "kind": "auth",
    "states": "XV",
    "prompt": "04.02، 04.03"
  },
  "SC-PIN-SETUP": {
    "id": "SC-PIN-SETUP",
    "title": "screen.SC-PIN-SETUP",
    "routes": [
      "/pin/setup"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "auth",
    "states": "V",
    "prompt": "04.01، 04.02، 04.03"
  },
  "SC-PIN-UNLOCK": {
    "id": "SC-PIN-UNLOCK",
    "title": "screen.SC-PIN-UNLOCK",
    "routes": [
      "/pin"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "auth",
    "states": "XV",
    "prompt": "04.04"
  },
  "SC-INSTALL-HELP": {
    "id": "SC-INSTALL-HELP",
    "title": "screen.SC-INSTALL-HELP",
    "routes": [
      "/install"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "static",
    "states": "",
    "prompt": "02.03"
  },
  "SC-HOME-S": {
    "id": "SC-HOME-S",
    "title": "screen.SC-HOME-S",
    "routes": [
      "/home"
    ],
    "roles": [
      "student"
    ],
    "kind": "root",
    "states": "LEXO",
    "prompt": "08.01"
  },
  "SC-HOME-R": {
    "id": "SC-HOME-R",
    "title": "screen.SC-HOME-R",
    "routes": [
      "/home"
    ],
    "roles": [
      "rep"
    ],
    "kind": "root",
    "states": "LEXO",
    "prompt": "08.02"
  },
  "SC-DEV-HOME": {
    "id": "SC-DEV-HOME",
    "title": "screen.SC-DEV-HOME",
    "routes": [
      "/dev"
    ],
    "roles": [
      "dev"
    ],
    "kind": "root",
    "states": "LEXB",
    "prompt": "08.03"
  },
  "SC-PREPS-TODAY": {
    "id": "SC-PREPS-TODAY",
    "title": "screen.SC-PREPS-TODAY",
    "routes": [
      "/preps/today"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "tabpage",
    "states": "LEXOCW",
    "prompt": "06.01، 06.03، 08.01، 08.02"
  },
  "SC-PREPS-TOMORROW": {
    "id": "SC-PREPS-TOMORROW",
    "title": "screen.SC-PREPS-TOMORROW",
    "routes": [
      "/preps/tomorrow"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "tabpage",
    "states": "LEXOCW",
    "prompt": "06.01، 08.01، 08.02"
  },
  "SC-EXAM": {
    "id": "SC-EXAM",
    "title": "screen.SC-EXAM",
    "routes": [
      "/preps/exam"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "tabpage",
    "states": "LEXO",
    "prompt": "05.04، 08.01، 08.02"
  },
  "SC-PREPS-ARCHIVE": {
    "id": "SC-PREPS-ARCHIVE",
    "title": "screen.SC-PREPS-ARCHIVE",
    "routes": [
      "/preps/archive"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXO",
    "prompt": "06.03"
  },
  "SC-PREP-VIEW": {
    "id": "SC-PREP-VIEW",
    "title": "screen.SC-PREP-VIEW",
    "routes": [
      "/preps/:id"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXO",
    "prompt": "06.01، 06.02"
  },
  "SC-PREP-FORM": {
    "id": "SC-PREP-FORM",
    "title": "screen.SC-PREP-FORM",
    "routes": [
      "/preps/new",
      "/preps/:id/edit"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "form",
    "states": "VCWX",
    "prompt": "06.01"
  },
  "SC-ATTACH": {
    "id": "SC-ATTACH",
    "title": "screen.SC-ATTACH",
    "routes": [],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "sheet",
    "states": "LXVW",
    "prompt": "06.02"
  },
  "SC-HOMEWORK": {
    "id": "SC-HOMEWORK",
    "title": "screen.SC-HOMEWORK",
    "routes": [
      "/homework"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCVW",
    "prompt": "06.04"
  },
  "SC-EXAMS": {
    "id": "SC-EXAMS",
    "title": "screen.SC-EXAMS",
    "routes": [
      "/exams"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCW",
    "prompt": "05.04"
  },
  "SC-EXAM-FORM": {
    "id": "SC-EXAM-FORM",
    "title": "screen.SC-EXAM-FORM",
    "routes": [
      "/exams/new",
      "/exams/:id/edit"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "form",
    "states": "VCWX",
    "prompt": "05.04"
  },
  "SC-SCHEDULE": {
    "id": "SC-SCHEDULE",
    "title": "screen.SC-SCHEDULE",
    "routes": [
      "/schedule"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCVW",
    "prompt": "05.02"
  },
  "SC-ANNOUNCE": {
    "id": "SC-ANNOUNCE",
    "title": "screen.SC-ANNOUNCE",
    "routes": [
      "/announcements"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOW",
    "prompt": "07.01"
  },
  "SC-ANNOUNCE-FORM": {
    "id": "SC-ANNOUNCE-FORM",
    "title": "screen.SC-ANNOUNCE-FORM",
    "routes": [
      "/announcements/new"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "form",
    "states": "VCWX",
    "prompt": "07.01"
  },
  "SC-NOTIFS": {
    "id": "SC-NOTIFS",
    "title": "screen.SC-NOTIFS",
    "routes": [
      "/notifications"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXO",
    "prompt": "07.02"
  },
  "SC-PROFILE": {
    "id": "SC-PROFILE",
    "title": "screen.SC-PROFILE",
    "routes": [
      "/me"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "root",
    "states": "LEXO",
    "prompt": "08.01"
  },
  "SC-ABSENCES-MINE": {
    "id": "SC-ABSENCES-MINE",
    "title": "screen.SC-ABSENCES-MINE",
    "routes": [
      "/me/absences"
    ],
    "roles": [
      "student"
    ],
    "kind": "tabpage",
    "states": "LEXO",
    "prompt": "08.01"
  },
  "SC-GRADES-MINE": {
    "id": "SC-GRADES-MINE",
    "title": "screen.SC-GRADES-MINE",
    "routes": [
      "/me/grades"
    ],
    "roles": [
      "student"
    ],
    "kind": "tabpage",
    "states": "LEXO",
    "prompt": "08.01"
  },
  "SC-PAYMENTS-MINE": {
    "id": "SC-PAYMENTS-MINE",
    "title": "screen.SC-PAYMENTS-MINE",
    "routes": [
      "/me/payments"
    ],
    "roles": [
      "student"
    ],
    "kind": "tabpage",
    "states": "LEXO",
    "prompt": "08.01"
  },
  "SC-CLASS-MGMT": {
    "id": "SC-CLASS-MGMT",
    "title": "screen.SC-CLASS-MGMT",
    "routes": [
      "/class"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "root",
    "states": "LEXO",
    "prompt": "08.02"
  },
  "SC-STUDENTS": {
    "id": "SC-STUDENTS",
    "title": "screen.SC-STUDENTS",
    "routes": [
      "/class/students"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCW",
    "prompt": "05.01"
  },
  "SC-STUDENT-FORM": {
    "id": "SC-STUDENT-FORM",
    "title": "screen.SC-STUDENT-FORM",
    "routes": [
      "/class/students/new",
      "/class/students/:id/edit"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "form",
    "states": "VCWX",
    "prompt": "04.03، 05.01"
  },
  "SC-STUDENT-PROFILE": {
    "id": "SC-STUDENT-PROFILE",
    "title": "screen.SC-STUDENT-PROFILE",
    "routes": [
      "/class/students/:id"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCW",
    "prompt": "04.03، 04.04، 05.01"
  },
  "SC-STUDENT-IMPORT": {
    "id": "SC-STUDENT-IMPORT",
    "title": "screen.SC-STUDENT-IMPORT",
    "routes": [
      "/class/students/import"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "XVBW",
    "prompt": "05.01"
  },
  "SC-ATTENDANCE": {
    "id": "SC-ATTENDANCE",
    "title": "screen.SC-ATTENDANCE",
    "routes": [
      "/class/attendance"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCW",
    "prompt": "05.03"
  },
  "SC-GRADES": {
    "id": "SC-GRADES",
    "title": "screen.SC-GRADES",
    "routes": [
      "/class/grades"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCVW",
    "prompt": "05.04"
  },
  "SC-COSTS": {
    "id": "SC-COSTS",
    "title": "screen.SC-COSTS",
    "routes": [
      "/class/costs"
    ],
    "roles": [
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LEXOCVW",
    "prompt": "05.05"
  },
  "SC-SETTINGS": {
    "id": "SC-SETTINGS",
    "title": "screen.SC-SETTINGS",
    "routes": [
      "/settings"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "page",
    "states": "LXOW",
    "prompt": "08.04"
  },
  "SC-UPCOMING": {
    "id": "SC-UPCOMING",
    "title": "screen.SC-UPCOMING",
    "routes": [
      "/settings/upcoming"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "static",
    "states": "",
    "prompt": "08.04"
  },
  "SC-ABOUT": {
    "id": "SC-ABOUT",
    "title": "screen.SC-ABOUT",
    "routes": [
      "/about"
    ],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "static",
    "states": "",
    "prompt": "08.04"
  },
  "SC-REPS": {
    "id": "SC-REPS",
    "title": "screen.SC-REPS",
    "routes": [
      "/dev/reps"
    ],
    "roles": [
      "dev"
    ],
    "kind": "root",
    "states": "LEXOCW",
    "prompt": "04.02"
  },
  "SC-SUPPORT": {
    "id": "SC-SUPPORT",
    "title": "screen.SC-SUPPORT",
    "routes": [
      "/dev/support"
    ],
    "roles": [
      "dev"
    ],
    "kind": "page",
    "states": "LEXBW",
    "prompt": "04.04"
  },
  "SC-AUDIT": {
    "id": "SC-AUDIT",
    "title": "screen.SC-AUDIT",
    "routes": [
      "/dev/audit"
    ],
    "roles": [
      "dev"
    ],
    "kind": "page",
    "states": "LEXB",
    "prompt": "04.04، 08.03"
  },
  "SC-SYSTEM": {
    "id": "SC-SYSTEM",
    "title": "screen.SC-SYSTEM",
    "routes": [
      "/dev/system"
    ],
    "roles": [
      "dev"
    ],
    "kind": "root",
    "states": "LEXBW",
    "prompt": "08.03"
  },
  "SC-BACKUP": {
    "id": "SC-BACKUP",
    "title": "screen.SC-BACKUP",
    "routes": [
      "/dev/backup"
    ],
    "roles": [
      "dev"
    ],
    "kind": "page",
    "states": "XBW",
    "prompt": "09.05"
  },
  "SC-FORBIDDEN": {
    "id": "SC-FORBIDDEN",
    "title": "screen.SC-FORBIDDEN",
    "routes": [],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "system",
    "states": "",
    "prompt": "02.02"
  },
  "SC-NOTFOUND": {
    "id": "SC-NOTFOUND",
    "title": "screen.SC-NOTFOUND",
    "routes": [],
    "roles": [
      "student",
      "rep",
      "dev"
    ],
    "kind": "system",
    "states": "",
    "prompt": "02.02"
  }
});
export const HOME_CAPS = Object.freeze({ cards: 4, quick: 3 });
