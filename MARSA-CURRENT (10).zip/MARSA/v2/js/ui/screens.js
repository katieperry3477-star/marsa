// الشاشات (02.02): هياكل ببيانات وهمية تُظهر الحالات (تحميل/فراغ/خطأ/دون اتصال) والتنقل. الشاشات الحقيقية تُبنى في 05–08 (UI-MAP §3 عمود «تنفيذ»).
// كل شاشة تُعيد متحكّماً { el, layoutKey, update(ctx), refresh(), destroy() }؛ الصفحات الثلاث تتشارك الهيكل (شريط التبويب الداخلي ينزلق بين الصفحات).
import { h, icon } from './dom.js';
import { t, tf } from '../core/i18n.js';
import { FUTURE, HOME_CAPS } from './nav-config.js';
import { hrefOf, isDeep, titleKey, homeRoute } from './nav.js';
import { bindStateView, emptyState, writeButton } from './states.js';
import { loadScreenData, SUPPORT_TARGETS } from '../data/mock.js';
import { agoLabel, inDaysLabel } from './time.js';
import { THEMES } from './theme.js';

export const TRIO = Object.freeze(['SC-PREPS-TODAY', 'SC-PREPS-TOMORROW', 'SC-EXAM']);

// ───────────── أدوات مشتركة ─────────────
const card = (cls, kids) => h('section', { class: 'card ' + cls }, kids);
const homeCard = (cls, kids) => h('section', { class: 'card home-card ' + cls, 'data-home-card': '' }, kids);
const cardTitle = (text) => h('h2', { class: 'card-title' }, text);
const row = (href, label, value) => h('a', { class: 'row', href }, [h('span', null, label), h('b', null, value)]);
const noteBox = (text) => h('p', { class: 'note-box' }, [icon('info', 's'), text]);
const isOfflineCtx = (ctx, svc) => !svc.isOnline() || ctx.query.state === 'offline' || ctx.query.state === 'stale';

function pageHead(ctx, svc, withBack) {
  const kids = [];
  if (withBack) kids.push(h('button', { class: 'ib back', type: 'button', 'aria-label': t('nav.back'), on: { click: () => svc.goBack() } }, icon('back')));
  kids.push(h('h1', { class: 'page-title', tabindex: '-1' }, t(titleKey(ctx.role, ctx.id))));
  return h('div', { class: 'page-head' }, kids);
}

function loaderFor(ctx) {
  return (x) => loadScreenData({ screenId: ctx.id, role: ctx.role, state: x.state, attempt: x.attempt, offline: x.offline });
}

// ───────────── الرئيسية (R-083: ≤4 بطاقات و≤3 أزرار سريعة) ─────────────
function summaryCard(today) {
  return homeCard('summary', [
    cardTitle(t('home.today.title')),
    h('div', { class: 'rows' }, [
      row(hrefOf('SC-PREPS-TODAY'), t('home.today.today'), tf('home.today.count', { n: today.today })),
      row(hrefOf('SC-PREPS-TOMORROW'), t('home.today.tomorrow'), tf('home.today.count', { n: today.tomorrow })),
      row(hrefOf('SC-EXAM'), t('home.today.exam'), inDaysLabel(today.examInDays, tf))
    ])
  ]);
}
const pinnedCard = (p) => homeCard('pinned', [h('p', { class: 'eyebrow' }, [icon('pin', 's'), t('home.pinned')]), cardTitle(p.title), h('p', null, p.body)]);

function homeStudent() {
  return {
    skeletonKind: 'cards',
    renderOk(d) {
      const cards = [];
      if (d.pinned) cards.push(pinnedCard(d.pinned));
      cards.push(summaryCard(d.today));
      if (d.notifs && d.notifs.length) {
        cards.push(homeCard('notifs', [cardTitle(t('home.notifs.title')), h('ul', { class: 'plain-list' }, d.notifs.slice(0, 2).map((x) => h('li', null, x))), h('a', { class: 'link', href: hrefOf('SC-NOTIFS') }, t('screen.SC-NOTIFS'))]));
      }
      return h('div', { class: 'home-grid' }, cards.slice(0, HOME_CAPS.cards));
    },
    renderEmpty() { return emptyState({ text: t('state.empty.home') }); }
  };
}

function homeRep() {
  return {
    skeletonKind: 'cards',
    renderOk(d, meta) {
      const cards = [summaryCard(d.today)];
      if (d.alerts) {
        const items = [];
        if (d.alerts.attendanceOpen) items.push(row(hrefOf('SC-ATTENDANCE'), t('home.alerts.attendance'), icon('alert', 's')));
        if (d.alerts.overdueCosts) items.push(row(hrefOf('SC-COSTS'), tf('home.alerts.costs', { n: d.alerts.overdueCosts }), icon('alert', 's')));
        if (items.length) cards.push(homeCard('alerts', [cardTitle(t('home.alerts.title')), h('div', { class: 'rows' }, items)]));
      }
      if (d.pinned) cards.push(pinnedCard(d.pinned));
      const online = !meta.offline;
      const quick = h('div', { class: 'quick', 'data-quick-actions': '' }, [
        writeButton({ online, href: hrefOf('SC-PREP-FORM'), icon: 'plus', label: t('quick.add_prep') }),
        writeButton({ online, href: hrefOf('SC-ATTENDANCE'), icon: 'check', label: t('quick.approve_attendance') }),
        writeButton({ online, href: hrefOf('SC-ANNOUNCE-FORM'), icon: 'megaphone', label: t('quick.new_announcement') })
      ].slice(0, HOME_CAPS.quick));
      return h('div', { class: 'stack' }, [h('div', { class: 'home-grid' }, cards.slice(0, HOME_CAPS.cards)), quick]);
    },
    renderEmpty() { return emptyState({ text: t('state.empty.home') }); }
  };
}

function homeDev() {
  return {
    skeletonKind: 'cards',
    renderOk(d) {
      const cards = [
        homeCard('sys', [cardTitle(t('home.sys.title')), h('div', { class: 'rows' }, [
          h('p', { class: 'kv' }, h('span', { class: 'chip chip-ok' }, [icon('check', 's'), t('home.sys.online')])),
          h('p', { class: 'kv' }, tf('home.sys.schema', { v: d.sys.schema })),
          h('p', { class: 'kv' }, tf('home.sys.backup', { when: agoLabel(d.sys.backupAgo, tf) }))
        ])]),
        homeCard('storage', [cardTitle(t('home.storage.title')), h('div', { class: 'rows' }, [
          h('p', { class: 'kv' }, tf('home.storage.db', { used: d.storage.dbUsed, max: d.storage.dbMax })),
          h('p', { class: 'kv' }, tf('home.storage.files', { used: d.storage.filesUsed, max: d.storage.filesMax }))
        ])]),
        homeCard('reps', [cardTitle(t('home.reps.title')), h('p', { class: 'kv' }, tf('home.reps.counts', { a: d.reps.active, s: d.reps.suspended })), h('a', { class: 'link', href: hrefOf('SC-REPS') }, t('screen.SC-REPS'))]),
        homeCard('audit', [cardTitle(t('home.audit.title')), h('ul', { class: 'plain-list' }, d.audit.slice(0, 5).map((x) => h('li', null, x)))])
      ];
      const quick = h('div', { class: 'quick', 'data-quick-actions': '' }, [h('a', { class: 'btn btn-primary', href: hrefOf('SC-SUPPORT') }, [icon('eye'), t('quick.open_support')])].slice(0, HOME_CAPS.quick));
      return h('div', { class: 'stack' }, [h('div', { class: 'home-grid' }, cards.slice(0, HOME_CAPS.cards)), quick]);
    },
    renderEmpty() { return emptyState({ text: t('state.empty.home') }); }
  };
}

// ───────────── التحاضير الثلاث (اليوم · باچر · هل عدنا امتحان؟) ─────────────
function prepCard(p) {
  return h('a', { class: 'card prep', href: '#/preps/' + encodeURIComponent(p.id), 'data-prep': p.id }, [
    h('div', { class: 'prep-top' }, [
      p.pinned ? h('span', { class: 'chip chip-gold' }, [icon('pin', 's'), t('prep.pinned')]) : null,
      h('span', { class: 'muted' }, tf('prep.edited', { time: agoLabel(p.editedAgo, tf) }))
    ]),
    p.homework ? h('p', { class: 'prep-line' }, [h('b', null, t('prep.homework') + ': '), p.homework]) : null,
    p.notes ? h('p', { class: 'prep-notes' }, p.notes) : null,
    p.files ? h('span', { class: 'chip' }, [icon('file', 's'), tf('prep.files', { n: p.files })]) : null
  ]);
}

function addButton(ctx, svc, meta, labelKey, screenId, iconName) {
  return writeButton({ online: !meta.offline, href: hrefOf(screenId), icon: iconName || 'plus', label: t(labelKey) });
}

function todayDef(ctx, svc) {
  return {
    skeletonKind: 'cards',
    renderOk(d) {
      const by = {};
      d.items.forEach((p) => { (by[p.subject] = by[p.subject] || []).push(p); });
      return h('div', { class: 'stack' }, Object.keys(by).map((k) => h('section', { class: 'group', 'data-subject': k }, [h('h2', { class: 'group-title' }, t('subject.' + k))].concat(by[k].map(prepCard)))));
    },
    renderEmpty(meta) {
      return emptyState({ text: t('preps.today.empty'), action: ctx.role !== 'student' ? addButton(ctx, svc, meta, 'preps.add_first', 'SC-PREP-FORM') : null });
    }
  };
}

function tomorrowDef(ctx, svc) {
  return {
    skeletonKind: 'list',
    renderOk(d) {
      const kids = [];
      if (d.exam) kids.push(h('div', { class: 'banner banner-gold', 'data-banner': 'exam' }, [icon('alert'), h('p', null, tf('exam.banner', { subject: t('subject.' + d.exam.subject) }))]));
      d.rows.forEach((r) => kids.push(h('div', { class: 'card row-card', 'data-subject': r.subject }, [
        h('h2', { class: 'row-title' }, t('subject.' + r.subject)),
        r.preps ? h('p', { class: 'row-meta' }, [t('preps.tomorrow.has') + ': ' + r.preps, r.homework ? h('span', { class: 'chip' }, t('prep.homework')) : null]) : h('p', { class: 'row-meta muted' }, t('preps.tomorrow.none'))
      ])));
      return h('div', { class: 'stack' }, kids);
    },
    renderEmpty(meta) {
      return emptyState({ text: t('preps.tomorrow.empty'), action: ctx.role !== 'student' ? addButton(ctx, svc, meta, 'preps.add_first', 'SC-PREP-FORM') : null });
    }
  };
}

function examDef(ctx, svc) {
  return {
    skeletonKind: 'cards',
    renderOk(d) {
      const n = d.next;
      return h('div', { class: 'stack' }, [
        h('section', { class: 'card answer answer-yes', 'data-answer': 'yes' }, [
          h('h2', { class: 'answer-title' }, [icon('check'), t('exam.yes')]),
          h('p', { class: 'answer-meta' }, [h('b', null, t('subject.' + n.subject)), ' · ', inDaysLabel(n.inDays, tf), ' · ', h('span', { dir: 'ltr' }, n.time)])
        ]),
        h('section', { class: 'card' }, [cardTitle(t('exam.upcoming')), h('ul', { class: 'plain-list' }, d.upcoming.slice(0, 5).map((u) => h('li', { class: 'split' }, [h('span', null, t('subject.' + u.subject)), h('span', { class: 'muted' }, inDaysLabel(u.inDays, tf))])))])
      ]);
    },
    // «لا» ليست حالة فراغ بل جواب السؤال نفسه
    renderEmpty() {
      return h('section', { class: 'card answer answer-no', 'data-answer': 'no' }, [h('h2', { class: 'answer-title' }, [icon('inbox'), t('exam.no')])]);
    }
  };
}

const TRIO_DEFS = { 'SC-PREPS-TODAY': todayDef, 'SC-PREPS-TOMORROW': tomorrowDef, 'SC-EXAM': examDef };

function mountTrio(ctx0, svc) {
  let ctx = ctx0, binder = null;
  const title = h('h1', { class: 'page-title', tabindex: '-1' });
  const nav = h('nav', { class: 'seg', 'aria-label': t('preps.nav') }, TRIO.map((id) => h('a', { href: hrefOf(id), 'data-screen': id }, t('screen.' + id))).concat([h('span', { class: 'seg-ind', 'aria-hidden': 'true' })]));
  const archive = h('a', { class: 'link archive-link', href: hrefOf('SC-PREPS-ARCHIVE') }, [icon('archive', 's'), t('preps.archive_link')]);
  const host = h('div', { class: 'view', 'data-view': 'trio' });
  const body = h('div', { class: 'trio-body' }, host);
  const actions = h('div', { class: 'sticky-actions' });
  const el = h('div', { class: 'page-inner trio' }, [h('div', { class: 'page-head' }, title), h('p', { class: 'demo-chip' }, t('mock.badge')), nav, archive, body, actions]);

  function renderActions() {
    actions.replaceChildren();
    if (ctx.role === 'student') return;
    const exam = ctx.id === 'SC-EXAM';
    actions.appendChild(writeButton({ online: !isOfflineCtx(ctx, svc), href: hrefOf(exam ? 'SC-EXAM-FORM' : 'SC-PREP-FORM'), icon: 'plus', label: t(exam ? 'exam.add' : 'preps.add') }));
  }
  function bind(animate) {
    if (binder) binder.destroy();
    const def = TRIO_DEFS[ctx.id](ctx, svc);
    title.textContent = t('screen.' + ctx.id);
    nav.setAttribute('data-idx', String(TRIO.indexOf(ctx.id) + 1));
    Array.from(nav.querySelectorAll('a')).forEach((a) => { if (a.getAttribute('data-screen') === ctx.id) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    renderActions();
    if (animate) { body.classList.remove('route-in'); void body.offsetWidth; body.classList.add('route-in'); }
    binder = bindStateView(host, {
      states: ctx.screen.states, forced: ctx.query.state, isOnline: svc.isOnline, skeletonKind: def.skeletonKind, load: loaderFor(ctx),
      renderOk: (d, m) => def.renderOk(d, m), renderEmpty: (m) => def.renderEmpty(m)
    });
  }
  bind(false);
  return {
    el, layoutKey: 'trio',
    update(next) { ctx = next; bind(true); },
    refresh() { renderActions(); return binder.rerun(); },
    destroy() { if (binder) binder.destroy(); }
  };
}

// ───────────── إشعارات، دعم، هيكل عام ─────────────
function notifsDef() {
  return {
    skeletonKind: 'list',
    renderOk(d) {
      return h('ul', { class: 'plain-list cards-list' }, d.items.map((n) => h('li', { class: 'card row-card notif' + (n.unread ? ' is-unread' : ''), 'data-notif': n.id }, [
        h('p', { class: 'notif-text' }, n.text),
        h('p', { class: 'row-meta muted' }, [agoLabel(n.ago, tf), n.unread ? h('span', { class: 'chip chip-gold' }, t('notifs.unread')) : null])
      ])));
    },
    renderEmpty() { return emptyState({ icon: 'bell', text: t('notifs.empty') }); }
  };
}

function supportDef(ctx, svc) {
  return {
    skeletonKind: 'cards',
    renderOk() {
      return h('div', { class: 'stack' }, [
        noteBox(t('support.mock_note')),
        h('div', { class: 'quick' }, ['student', 'rep'].map((r) => h('button', { class: 'btn btn-primary', type: 'button', 'data-support-start': r, on: { click: () => svc.startSupport(r) } }, [icon('eye'), t('support.start.' + r)])))
      ]);
    }
  };
}

function scaffoldDef(ctx, svc) {
  const sc = ctx.screen;
  return {
    skeletonKind: sc.kind === 'form' ? 'form' : 'list',
    renderOk(d, meta) {
      const kids = [noteBox(tf('scaffold.note', { prompt: sc.prompt }))];
      if (sc.kind === 'form') {
        kids.push(writeButton({ online: !meta.offline, icon: 'check', label: t('scaffold.form.save'), onClick: () => svc.toast(t('write.demo_only')) }));
      } else {
        const rows = [];
        for (let i = 1; i <= d.rows; i++) rows.push(h('li', { class: 'card row-card' }, [h('b', null, tf('scaffold.sample', { n: i })), h('span', { class: 'muted' }, t('scaffold.sample.meta'))]));
        kids.push(h('ul', { class: 'plain-list cards-list' }, rows));
        if (ctx.role !== 'student' && String(sc.states).indexOf('W') > -1) kids.push(writeButton({ online: !meta.offline, icon: 'plus', label: t('scaffold.add'), onClick: () => svc.toast(t('write.demo_only')) }));
      }
      return h('div', { class: 'stack' }, kids);
    }
  };
}

const STATE_DEFS = { 'SC-HOME-S': homeStudent, 'SC-HOME-R': homeRep, 'SC-DEV-HOME': homeDev, 'SC-NOTIFS': notifsDef, 'SC-SUPPORT': supportDef };

// ───────────── شاشات ثابتة (بلا حالات بيانات) ─────────────
function settingsView(ctx, svc) {
  const cur = svc.getTheme();
  const ico = { auto: 'auto', light: 'sun', dark: 'moon' };
  return h('div', { class: 'stack' }, [
    h('fieldset', { class: 'card theme-card' }, [
      h('legend', { class: 'card-title' }, t('settings.theme')),
      h('div', { class: 'radios' }, THEMES.map((v) => h('label', { class: 'radio', for: 'theme-' + v }, [
        h('input', { type: 'radio', name: 'theme', id: 'theme-' + v, value: v, checked: v === cur, on: { change: () => svc.setTheme(v) } }),
        icon(ico[v]),
        h('span', null, t('settings.theme.' + v))
      ]))),
      h('p', { class: 'hint' }, t('settings.theme.hint'))
    ]),
    h('a', { class: 'card link-card', href: hrefOf('SC-UPCOMING') }, [h('b', null, t('settings.upcoming')), h('span', { class: 'muted' }, t('settings.upcoming.hint'))]),
    h('p', { class: 'kv' }, [t('foundation.status.version') + ': ', h('b', { id: 'build-version', dir: 'ltr' }, svc.version() || t('foundation.status.unknown'))])
  ]);
}

function upcomingView(ctx) {
  const keys = Object.keys(FUTURE).filter((k) => FUTURE[k].roles.indexOf(ctx.role) > -1);
  return h('div', { class: 'stack' }, [
    noteBox(t('upcoming.intro')),
    h('ul', { class: 'plain-list cards-list' }, keys.map((k) => h('li', { class: 'card fut-card', 'data-future': k }, [
      h('div', { class: 'fut-head' }, [h('h2', { class: 'card-title' }, t(FUTURE[k].name)), h('span', { class: 'chip chip-gold' }, [icon('hourglass', 's'), t('future.badge')])]),
      h('p', null, t(FUTURE[k].note))
    ])))
  ]);
}

function aboutView() {
  return h('div', { class: 'stack' }, [card('about', [cardTitle(t('about.heading')), h('p', null, t('about.body')), h('p', { class: 'hint' }, t('about.note'))])]);
}

function systemView(kind, ctx) {
  const forb = kind === 'forbidden';
  return h('div', { class: 'stack' }, [h('div', { class: 'state state-sys', 'data-state': kind }, [
    h('span', { class: 'state-icon' }, icon(forb ? 'lock' : 'alert')),
    h('p', { class: 'state-text' }, t(forb ? 'forbidden.text' : 'notfound.text')),
    h('a', { class: 'btn btn-primary', href: '#' + homeRoute(ctx.role) }, [icon('home'), t('notfound.home')])
  ])]);
}

const STATIC = {
  'SC-SETTINGS': settingsView, 'SC-UPCOMING': upcomingView, 'SC-ABOUT': aboutView,
  'SC-FORBIDDEN': (c) => systemView('forbidden', c), 'SC-NOTFOUND': (c) => systemView('notfound', c)
};

function mountSingle(ctx, svc) {
  const root = h('div', { class: 'page-inner', 'data-screen': ctx.id }, [pageHead(ctx, svc, isDeep(ctx.role, ctx.id))]);
  let binder = null;
  if (STATIC[ctx.id]) {
    root.appendChild(STATIC[ctx.id](ctx, svc));
  } else {
    const def = (STATE_DEFS[ctx.id] || scaffoldDef)(ctx, svc);
    const host = h('div', { class: 'view', 'data-view': ctx.id });
    root.appendChild(h('p', { class: 'demo-chip' }, t('mock.badge')));
    root.appendChild(host);
    binder = bindStateView(host, {
      states: ctx.screen.states, forced: ctx.query.state, isOnline: svc.isOnline, skeletonKind: def.skeletonKind, load: loaderFor(ctx),
      renderOk: (d, m) => def.renderOk(d, m), renderEmpty: (m) => (def.renderEmpty ? def.renderEmpty(m) : emptyState({ text: t('state.empty.default') }))
    });
  }
  return { el: root, layoutKey: null, update() {}, refresh() { return binder ? binder.rerun() : Promise.resolve(); }, destroy() { if (binder) binder.destroy(); } };
}

// يركّب الشاشة؛ الصفحات الثلاث تعيد استعمال الهيكل السابق (prev) فينزلق المؤشر بدل إعادة البناء.
export function mountScreen(ctx, svc, prev) {
  if (TRIO.indexOf(ctx.id) > -1) {
    if (prev && prev.layoutKey === 'trio') { prev.update(ctx); return prev; }
    return mountTrio(ctx, svc);
  }
  return mountSingle(ctx, svc);
}
