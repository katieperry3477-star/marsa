// مكوّنات الحالات المشتركة (UI-MAP §9-ب): تحميل (هيكل بنفس هندسة المحتوى) · فراغ · خطأ · محجوب دون اتصال · تعارض · ختم «آخر تحديث» · زر كتابة معطّل بسبب ظاهر.
// bindStateView يدير دورة: هيكل ◄ محتوى/فراغ/خطأ، مع إعادة المحاولة والتحديث عند عودة الاتصال.
import { h, icon } from './dom.js';
import { t, tf } from '../core/i18n.js';
import { agoLabel, isStale } from './time.js';

export function skeleton(kind) {
  const k = kind || 'cards';
  const blocks = [];
  if (k === 'list') for (let i = 0; i < 4; i++) blocks.push(h('div', { class: 'skel skel-row' }));
  else if (k === 'form') for (let i = 0; i < 3; i++) blocks.push(h('div', { class: 'skel skel-field' }));
  else for (let i = 0; i < 3; i++) blocks.push(h('div', { class: 'skel skel-card' }));
  return h('div', { class: 'skel-wrap skel-' + k, 'data-skeleton': k, 'aria-hidden': 'true' }, blocks);
}

export function emptyState(o) {
  return h('div', { class: 'state state-empty', 'data-state': 'empty' }, [
    h('span', { class: 'state-icon' }, icon(o.icon || 'inbox')),
    h('p', { class: 'state-text' }, o.text || t('state.empty.default')),
    o.action || null
  ]);
}

export function errorState(o) {
  return h('div', { class: 'alert alert-error', role: 'alert', 'data-state': 'error' }, [
    icon('alert'),
    h('p', { class: 'alert-text' }, t('state.error.title')),
    h('button', { class: 'btn', type: 'button', on: { click: o.onRetry } }, [icon('refresh'), t('state.error.retry')])
  ]);
}

export function conflictState(o) {
  return h('div', { class: 'alert alert-warn', role: 'alert', 'data-state': 'conflict' }, [
    icon('alert'),
    h('p', { class: 'alert-text' }, t('state.conflict')),
    h('button', { class: 'btn', type: 'button', on: { click: o.onRefresh } }, [icon('refresh'), t('state.refresh')])
  ]);
}

export function blockedState() {
  return h('div', { class: 'state state-blocked', 'data-state': 'blocked' }, [
    h('span', { class: 'state-icon' }, icon('wifioff')),
    h('p', { class: 'state-text' }, t('state.blocked')),
    h('p', { class: 'state-hint' }, t('state.blocked.hint'))
  ]);
}

// ختم آخر تحديث للبيانات المخزنة (دون اتصال). فوق 24 ساعة: تحذير نصّي ظاهر (لا لون وحده).
export function stampView(fetchedAt, now) {
  const diff = (now || Date.now()) - fetchedAt;
  const stale = isStale(diff);
  return h('p', { class: 'stamp' + (stale ? ' stamp-stale' : ''), 'data-stamp': stale ? 'stale' : 'fresh' }, [
    icon('clock', 's'),
    h('span', null, [t('stamp.prefix') + ': ', h('time', { datetime: new Date(fetchedAt).toISOString() }, agoLabel(diff, tf))]),
    stale ? h('span', { class: 'chip chip-warn' }, t('stamp.stale')) : null
  ]);
}

let uid = 0;
// زر كتابة: متصل ◄ رابط/زر فعّال؛ دون اتصال ◄ زر aria-disabled مع سبب ظاهر نصّاً (لا tooltip وحده).
export function writeButton(o) {
  const content = [icon(o.icon || 'plus'), o.label];
  if (o.online) {
    if (o.href) return h('a', { class: 'btn btn-primary', href: o.href, 'data-write': 'enabled' }, content);
    return h('button', { class: 'btn btn-primary', type: 'button', 'data-write': 'enabled', on: { click: o.onClick } }, content);
  }
  const rid = 'wr-' + (++uid);
  return h('div', { class: 'write-disabled', 'data-write': 'disabled' }, [
    h('button', { class: 'btn btn-primary', type: 'button', 'aria-disabled': 'true', 'aria-describedby': rid, on: { click: (e) => e.preventDefault() } }, content),
    h('p', { class: 'write-reason', id: rid }, t('write.needs_connection'))
  ]);
}

// يربط حاوية بدورة الحالات. o: { states, forced, isOnline, load, renderOk, renderEmpty, skeletonKind }
export function bindStateView(host, o) {
  let attempt = 0, token = 0, destroyed = false, forced = o.forced || null;
  const has = (c) => String(o.states || '').indexOf(c) > -1;
  const isOffline = () => !o.isOnline() || forced === 'offline' || forced === 'stale';

  function settle(nodes) {
    host.replaceChildren();
    (Array.isArray(nodes) ? nodes : [nodes]).forEach((n) => { if (n) host.appendChild(n); });
    host.removeAttribute('aria-busy');
  }

  function run() {
    const my = ++token;
    host.setAttribute('aria-busy', 'true');
    host.replaceChildren(skeleton(o.skeletonKind));
    const offline = isOffline();
    if (forced === 'blocked' || (offline && has('B'))) { settle(blockedState()); return Promise.resolve(); }
    return o.load({ attempt: attempt++, offline, state: forced }).then((res) => {
      if (my !== token || destroyed) return;
      if (forced === 'conflict' && has('C')) {
        settle(conflictState({ onRefresh: () => { forced = null; run(); } }));
        return;
      }
      const meta = { offline };
      const nodes = [];
      if (offline) nodes.push(stampView(res.fetchedAt));
      nodes.push(res.empty ? o.renderEmpty(meta) : o.renderOk(res.data, meta));
      settle(nodes);
    }, () => {
      if (my !== token || destroyed) return;
      settle(errorState({ onRetry: run }));
    });
  }
  run();
  return { rerun: run, destroy() { destroyed = true; token++; } };
}
