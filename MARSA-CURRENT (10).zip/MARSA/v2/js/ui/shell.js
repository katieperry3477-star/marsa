// قشرة V2 (02.02، UI-MAP §2 و§4 و§9): ترويسة + قائمة جانبية (ورقة على الجوال/ثابتة ≥1024) + شريط تبويب سفلي + شريط دون اتصال + شريط الدعم + تنبيهات + افتتاحية.
// القشرة تتبع الدور الفعّال (الدور أو حساب الدعم المعروض). الحارس واجهي فقط؛ الحكم للخادم (R-029). لا innerHTML ولا style مضمّن (CSP).
import { h, icon, logo, focusables } from './dom.js';
import { t, tf } from '../core/i18n.js';
import * as store from './store.js';
import { SCREENS, SIDEBARS, TABBARS, FUTURE } from './nav-config.js';
import { resolve, isRouteHash } from './router.js';
import { parentTab, homeRoute, hrefOf, isTabRoot, titleKey } from './nav.js';
import { SCREEN_ICON, ROLE_ICON } from './icons.js';
import { mountScreen } from './screens.js';
import { mountPicker, setUrlRole } from './mock-session.js';
import { savePrefs, applyTheme, loadPrefs } from './theme.js';
import { SUPPORT_TARGETS } from '../data/mock.js';

const INTRO_MS = 1500;

export function createShell() {
  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const app = $('app'), sidebar = $('sidebar'), scrim = $('scrim'), appMain = $('app-main'), top = $('top');
  const offlineBar = $('offline-bar'), devNote = $('dev-note'), main = $('main'), tabbar = $('tabbar');
  const toasts = $('toasts'), supportBar = $('support-bar'), intro = $('intro'), skip = $('skip-link');
  const mqDesktop = window.matchMedia('(min-width: 1024px)');
  const mqReduce = window.matchMedia('(prefers-reduced-motion: reduce)');

  let current = null, rendered = false, menuBtn = null;
  let lastKey = '', lastMode = null, lastRole = null, lastSupportObj = null, prevOnline = store.get().online, simNow = false;
  let theme = loadPrefs().theme, supportTimer = 0;
  const trail = [];

  // ───────────── خدمات تُمرَّر إلى الشاشات ─────────────
  const svc = {
    isOnline: () => store.get().online,
    navigate: (path) => { location.hash = '#' + path; },
    goBack, toast,
    version: () => store.get().version,
    startSupport, endSupport, logout, pickRole,
    getTheme: () => theme,
    setTheme: (v) => { theme = applyTheme(v); savePrefs({ theme }); }
  };

  function toast(text) {
    while (toasts.children.length >= 3) toasts.removeChild(toasts.firstChild);
    const el = h('div', { class: 'toast' }, text);
    toasts.appendChild(el);
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 220); }, 4000);
  }

  function trackTrail(hash) {
    if (trail.length > 1 && trail[trail.length - 2] === hash) trail.pop();
    else if (trail[trail.length - 1] !== hash) trail.push(hash);
  }
  function goBack() {
    if (trail.length > 1) history.back();
    else location.hash = '#' + homeRoute(store.effectiveRole() || 'student');
  }

  // ───────────── الجلسة التجريبية ودعم المطوّر ─────────────
  function pickRole(role) {
    setUrlRole(role);
    location.hash = '#' + homeRoute(role);
    store.set({ role });
  }
  function logout() {
    clearInterval(supportTimer);
    setUrlRole(null);
    history.replaceState(history.state, '', location.pathname + location.search);
    trail.length = 0;
    store.set({ sidebarOpen: false, support: null, role: null });
  }
  function startSupport(role) {
    const tg = SUPPORT_TARGETS[role];
    if (!tg) return;
    clearInterval(supportTimer);
    supportTimer = setInterval(tickSupport, 60000);
    location.hash = '#' + homeRoute(tg.role);
    store.set({ support: { role: tg.role, name: tg.name, minutes: tg.minutes } });
  }
  function endSupport() {
    clearInterval(supportTimer);
    location.hash = '#/dev/support';
    store.set({ support: null });
  }
  function tickSupport() {
    const s = store.get().support;
    if (!s) return;
    if (s.minutes <= 1) endSupport(); else store.set({ support: { role: s.role, name: s.name, minutes: s.minutes - 1 } });
  }

  // ───────────── الترويسة ─────────────
  function bellLink() {
    const n = store.get().unread;
    const a = h('a', { class: 'ib bell', href: hrefOf('SC-NOTIFS'), 'aria-label': n > 0 ? tf('header.bell.unread', { n }) : t('header.bell') }, icon('bell'));
    if (n > 0) a.appendChild(h('span', { class: 'badge', 'aria-hidden': 'true' }, n > 9 ? '+9' : String(n)));
    return a;
  }
  function renderHeader(mode, role) {
    top.replaceChildren();
    menuBtn = null;
    if (mode === 'role') {
      menuBtn = h('button', { class: 'ib menu-btn', type: 'button', 'aria-controls': 'sidebar', 'aria-expanded': 'false', 'aria-label': t('header.menu.open'), on: { click: () => (store.get().sidebarOpen ? closeSidebar(true) : openSidebar()) } }, icon('menu'));
      top.appendChild(menuBtn);
    }
    const kids = [logo(), h('span', { class: 'brand-text' }, [h('b', null, t('app.name')), h('span', null, t('app.division'))])];
    top.appendChild(mode === 'role' ? h('a', { class: 'brand', href: '#' + homeRoute(role) }, kids) : h('div', { class: 'brand' }, kids));
    if (mode === 'role') top.appendChild(bellLink());
  }

  // ───────────── القائمة الجانبية ─────────────
  function expandable(id, content, open) {
    const inner = h('div', { class: 'expand-in' }, content);
    const wrap = h('div', { class: 'expand', id }, inner);
    const set = (o) => { wrap.setAttribute('data-open', o ? 'true' : 'false'); if (o) inner.removeAttribute('inert'); else inner.setAttribute('inert', ''); };
    set(open);
    return { wrap, set };
  }
  function renderItem(role, it) {
    if (it.type === 'link') return h('a', { class: 'sb-item', href: hrefOf(it.screen), 'data-screen': it.screen }, [icon(SCREEN_ICON[it.screen] || 'file'), h('span', null, t(it.label))]);
    if (it.type === 'future') {
      const f = FUTURE[it.key], id = 'fut-' + role + '-' + it.key;
      const ex = expandable(id, h('p', { class: 'fut-text' }, t(f.text)), false);
      const btn = h('button', { class: 'sb-item sb-future', type: 'button', 'aria-expanded': 'false', 'aria-controls': id, 'data-future': it.key, on: { click: () => { const o = btn.getAttribute('aria-expanded') !== 'true'; btn.setAttribute('aria-expanded', String(o)); ex.set(o); } } }, [icon('hourglass'), h('span', null, t(f.name)), h('span', { class: 'chip chip-gold' }, t('future.badge'))]);
      return [btn, ex.wrap];
    }
    if (it.action === 'lock') {
      const id = 'lock-note-' + role;
      return [h('button', { class: 'sb-item', type: 'button', 'aria-disabled': 'true', 'aria-describedby': id, 'data-action': 'lock', on: { click: (e) => e.preventDefault() } }, [icon('lock'), h('span', null, t(it.label))]), h('p', { class: 'sb-note', id }, t('action.lock.note'))];
    }
    return h('button', { class: 'sb-item', type: 'button', 'data-action': 'logout', on: { click: () => logout() } }, [icon('logout'), h('span', null, t(it.label))]);
  }
  function renderGroup(role, g, gi) {
    const sec = h('section', { class: 'sb-group' + (g.footer ? ' sb-footer' : '') });
    const lid = 'sbg-' + role + '-' + gi;
    const list = h('ul', { class: 'sb-list' }, g.items.map((it) => h('li', null, renderItem(role, it))));
    if (g.title && g.collapsible) {
      const ex = expandable(lid, list, true);
      const btn = h('button', { class: 'sb-toggle', type: 'button', 'aria-expanded': 'true', 'aria-controls': lid, on: { click: () => { const o = btn.getAttribute('aria-expanded') !== 'true'; btn.setAttribute('aria-expanded', String(o)); ex.set(o); } } }, [h('span', null, t(g.title)), icon('chevron', 'chev')]);
      sec.appendChild(h('h2', { class: 'sb-title' }, btn));
      sec.appendChild(ex.wrap);
    } else {
      if (g.title) sec.appendChild(h('h2', { class: 'sb-title' }, t(g.title)));
      sec.appendChild(list);
    }
    return sec;
  }
  function renderSidebar(role) {
    sidebar.replaceChildren();
    sidebar.setAttribute('aria-label', t('sidebar.label'));
    sidebar.appendChild(h('div', { class: 'sb-head' }, [
      h('div', { class: 'sb-brand' }, [logo(), h('div', { class: 'sb-brand-text' }, [h('b', null, t('app.name')), h('span', null, t('app.division'))])]),
      h('button', { class: 'ib sb-close', type: 'button', 'aria-label': t('header.menu.close'), on: { click: () => closeSidebar(true) } }, icon('close'))
    ]));
    sidebar.appendChild(h('div', { class: 'sb-who' }, [
      h('span', { class: 'sb-avatar' }, icon(ROLE_ICON[role])),
      h('div', { class: 'sb-who-text' }, [h('p', { class: 'sb-name' }, t('user.' + role)), h('span', { class: 'chip chip-role', 'data-role-badge': role }, t('role.' + role))])
    ]));
    const nav = h('nav', { class: 'sb-nav', 'aria-label': t('sidebar.nav') });
    SIDEBARS[role].forEach((g, gi) => nav.appendChild(renderGroup(role, g, gi)));
    sidebar.appendChild(nav);
  }
  function renderTabbar(role) {
    tabbar.replaceChildren();
    tabbar.setAttribute('aria-label', t('tabbar.label'));
    TABBARS[role].forEach((tab) => tabbar.appendChild(h('a', { href: hrefOf(tab.screen), 'data-screen': tab.screen }, [icon(tab.icon), h('span', null, t(tab.label))])));
  }
  function updateActive(role, screenId, path) {
    const tabScreen = parentTab(role, screenId, path);
    tabbar.querySelectorAll('a').forEach((a) => { if (a.getAttribute('data-screen') === tabScreen) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    sidebar.querySelectorAll('a.sb-item').forEach((a) => { if (a.getAttribute('data-screen') === screenId) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  }

  // ورقة جانبية على الجوال (حبس تركيز + inert للخلفية) / ثابتة على الحاسوب
  const isSheet = () => !mqDesktop.matches;
  function syncSidebar() {
    const sheet = isSheet(), open = sheet && store.get().sidebarOpen;
    sidebar.setAttribute('data-open', open ? 'true' : 'false');
    scrim.setAttribute('data-open', open ? 'true' : 'false');
    if (sheet) { sidebar.setAttribute('role', 'dialog'); sidebar.setAttribute('aria-modal', 'true'); } else { sidebar.removeAttribute('role'); sidebar.removeAttribute('aria-modal'); }
    if (sheet && !open) sidebar.setAttribute('inert', ''); else sidebar.removeAttribute('inert');
    if (open) appMain.setAttribute('inert', ''); else appMain.removeAttribute('inert');
    if (menuBtn) { menuBtn.setAttribute('aria-expanded', String(open)); menuBtn.setAttribute('aria-label', t(open ? 'header.menu.close' : 'header.menu.open')); }
  }
  function openSidebar() {
    if (!isSheet() || store.get().sidebarOpen || lastMode !== 'role') return;
    store.set({ sidebarOpen: true });
    const f = focusables(sidebar);
    if (f.length) f[0].focus();
  }
  function closeSidebar(returnFocus) {
    if (!store.get().sidebarOpen) return;
    store.set({ sidebarOpen: false });
    if (returnFocus && menuBtn) menuBtn.focus();
  }
  function onKey(e) {
    if (!store.get().sidebarOpen) return;
    if (e.key === 'Escape') { e.preventDefault(); closeSidebar(true); return; }
    if (e.key !== 'Tab') return;
    const f = focusables(sidebar);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1], active = document.activeElement;
    if (e.shiftKey && (active === first || !sidebar.contains(active))) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && (active === last || !sidebar.contains(active))) { e.preventDefault(); first.focus(); }
  }

  // ───────────── الاتصال، الدعم، الافتتاحية ─────────────
  function renderOfflineBar() {
    const off = !store.get().online || simNow;
    offlineBar.hidden = !off;
    if (off && !offlineBar.firstChild) offlineBar.replaceChildren(icon('wifioff', 's'), h('span', null, t('offline.bar')));
  }
  function measureSupport() {
    const px = supportBar.hidden ? 0 : Math.round(supportBar.getBoundingClientRect().height * 100) / 100; // الارتفاع الفعلي بلا تقريب لأعلى فلا فجوة تحت الشريط
    root.style.setProperty('--support-h', px + 'px');
  }
  function renderSupportBar() {
    const s = store.get().support;
    if (s) root.setAttribute('data-support', ''); else root.removeAttribute('data-support');
    if (!s) { supportBar.hidden = true; supportBar.replaceChildren(); measureSupport(); return; }
    supportBar.setAttribute('aria-label', t('support.region'));
    supportBar.replaceChildren(
      icon('eye', 's'),
      h('p', { class: 'support-text' }, tf('support.bar', { name: s.name, role: t('role.' + s.role) })),
      h('span', { class: 'support-time' }, tf('support.remaining', { n: s.minutes })),
      h('button', { class: 'support-end', type: 'button', on: { click: endSupport } }, t('support.end'))
    );
    supportBar.hidden = false;
    measureSupport();
  }
  function runIntro() {
    if (mqReduce.matches) return;
    const skipBtn = h('button', { class: 'intro-skip', type: 'button' }, t('intro.skip'));
    intro.setAttribute('role', 'dialog');
    intro.setAttribute('aria-modal', 'true');
    intro.setAttribute('aria-label', t('intro.label'));
    intro.replaceChildren(logo('intro-logo'), h('p', { class: 'intro-name' }, t('app.name')), h('p', { class: 'intro-sub', lang: 'en', dir: 'ltr' }, t('app.name.en')), skipBtn);
    intro.hidden = false;
    app.setAttribute('inert', '');
    let done = false;
    const end = () => { if (done) return; done = true; clearTimeout(tm); intro.hidden = true; intro.replaceChildren(); app.removeAttribute('inert'); };
    const tm = setTimeout(end, INTRO_MS);
    intro.addEventListener('click', end);
    skipBtn.focus();
  }

  // ───────────── الوضع (منتقي/عارٍ/دور) والتوجيه ─────────────
  function setMode(mode, role) {
    if (mode === lastMode && role === lastRole) return;
    if (role !== lastRole && current) { current.destroy(); current = null; }
    lastMode = mode; lastRole = role;
    app.setAttribute('data-mode', mode);
    app.setAttribute('data-role', role || '');
    renderHeader(mode, role);
    if (mode === 'role') { renderSidebar(role); renderTabbar(role); sidebar.hidden = false; tabbar.hidden = false; }
    else { sidebar.replaceChildren(); tabbar.replaceChildren(); sidebar.hidden = true; tabbar.hidden = true; }
    syncSidebar();
  }
  function swap(ctrl) {
    if (ctrl === current) return;
    if (current) current.destroy();
    current = ctrl;
    main.replaceChildren(ctrl.el);
    ctrl.el.classList.add('route-in');
  }
  function renderRoute() {
    const hash = location.hash;
    if (!isRouteHash(hash)) return;
    const role = store.effectiveRole();
    const key = (role || '-') + '|' + hash + '|' + (store.get().support ? 's' : '');
    if (key === lastKey) return;
    lastKey = key;
    let title;
    if (!role) {
      simNow = false;
      setMode('picker', null);
      swap(mountPicker(svc));
      devNote.hidden = true;
      title = t('mock.title');
    } else {
      const r = resolve(SCREENS, role, hash);
      if (r.type === 'root') { history.replaceState(history.state, '', location.pathname + location.search + '#' + homeRoute(role)); lastKey = ''; renderRoute(); return; }
      const id = r.type === 'ok' ? r.screen.id : (r.type === 'forbidden' ? 'SC-FORBIDDEN' : 'SC-NOTFOUND');
      const screen = SCREENS[id];
      const mode = screen.kind === 'auth' ? 'bare' : 'role';
      simNow = r.query.state === 'offline' || r.query.state === 'stale';
      setMode(mode, role);
      if (store.get().sidebarOpen) store.set({ sidebarOpen: false });
      updateActive(role, id, r.path);
      trackTrail(hash);
      swap(mountScreen({ id, screen, role, params: r.params, query: r.query, path: r.path }, svc, current));
      devNote.hidden = !(mode === 'role' && r.type === 'ok' && isTabRoot(role, id));
      title = t(titleKey(role, id));
    }
    renderOfflineBar();
    document.title = title + ' — ' + t('app.title');
    window.scrollTo(0, 0);
    if (rendered) { const h1 = main.querySelector('h1'); if (h1) h1.focus({ preventScroll: true }); }
    rendered = true;
    root.setAttribute('data-v2', 'ready');
  }

  function onStoreChange(s) {
    syncSidebar();
    if (s.support !== lastSupportObj) {
      const roleChanged = (s.support ? s.support.role : s.role) !== lastRole || !s.support !== !lastSupportObj;
      lastSupportObj = s.support;
      renderSupportBar();
      if (roleChanged) { lastKey = ''; renderRoute(); return; }
    }
    if (store.effectiveRole() !== lastRole) { lastKey = ''; renderRoute(); return; }
    if (s.online !== prevOnline) {
      prevOnline = s.online;
      renderOfflineBar();
      const back = s.online;
      if (current) current.refresh().then(() => { if (back) toast(t('toast.updated')); });
    }
  }

  function start() {
    skip.addEventListener('click', (e) => { e.preventDefault(); main.focus(); });
    scrim.addEventListener('click', () => closeSidebar(true));
    document.addEventListener('keydown', onKey);
    window.addEventListener('hashchange', renderRoute);
    window.addEventListener('online', () => store.set({ online: true }));
    window.addEventListener('offline', () => store.set({ online: false }));
    window.addEventListener('resize', measureSupport);
    mqDesktop.addEventListener('change', () => { if (mqDesktop.matches && store.get().sidebarOpen) store.set({ sidebarOpen: false }); syncSidebar(); });
    devNote.textContent = t('app.dev_note');
    store.subscribe(onStoreChange);
    renderSupportBar();
    renderRoute();
    runIntro();
  }

  return { start, svc };
}
