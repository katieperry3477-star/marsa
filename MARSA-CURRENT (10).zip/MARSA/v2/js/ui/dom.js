// أدوات DOM صغيرة: كل نص عبر textContent وكل عنصر بـcreateElement (لا innerHTML، لا style مضمّن — CSP، ADR-317).
import { ICONS } from './icons.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

export function append(el, kids) {
  if (kids === undefined || kids === null || kids === false) return el;
  (Array.isArray(kids) ? kids : [kids]).forEach((k) => {
    if (k === undefined || k === null || k === false) return;
    if (Array.isArray(k)) { append(el, k); return; }
    el.appendChild(typeof k === 'string' || typeof k === 'number' ? document.createTextNode(String(k)) : k);
  });
  return el;
}

// h('button', { class:'btn', type:'button', on:{ click: fn }, 'aria-label': '…' }, [children])
export function h(tag, props, kids) {
  const el = document.createElement(tag);
  if (props) {
    Object.keys(props).forEach((k) => {
      const v = props[k];
      if (v === undefined || v === null || v === false) return;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'on') Object.keys(v).forEach((ev) => el.addEventListener(ev, v[ev]));
      else if (k === 'style') throw new Error('style مضمّن غير مسموح (CSP)');
      else el.setAttribute(k, v === true ? '' : String(v));
    });
  }
  return append(el, kids);
}

export function icon(name, cls) {
  const paths = ICONS[name] || ICONS.file;
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', 'i' + (cls ? ' ' + cls : ''));
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  paths.forEach((d) => { const p = document.createElementNS(SVG_NS, 'path'); p.setAttribute('d', d); svg.appendChild(p); });
  return svg;
}

// شعار مَرسى من الرمز المعرَّف في index.html (#marsa-mark)
export function logo(cls) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 64 64');
  svg.setAttribute('class', 'logo' + (cls ? ' ' + cls : ''));
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  const use = document.createElementNS(SVG_NS, 'use');
  use.setAttribute('href', '#marsa-mark');
  svg.appendChild(use);
  return svg;
}

export function clear(el) { el.replaceChildren(); return el; }

// عناصر قابلة للتركيز ومرئية داخل حاوية (لحبس التركيز)
export function focusables(root) {
  return Array.from(root.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),[tabindex]:not([tabindex="-1"])'))
    .filter((el) => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden');
}
