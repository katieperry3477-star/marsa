// المظهر (R-076): تلقائي (يتبع الجهاز، الافتراضي) · فاتح · داكن. يُطبَّق بـdata-theme على الجذر ويُحفظ في marsa.v2.ui عبر حارس التخزين فقط.
// لا كتابة عند الفتح؛ الكتابة عند اختيار المستخدم فقط. القيمة التالفة أو المجهولة = تلقائي.
import { browserStorage } from '../core/storage.js';
import { STORAGE_PREFIX } from '../core/constants.js';

export const UI_KEY = STORAGE_PREFIX + 'ui';
export const THEMES = Object.freeze(['auto', 'light', 'dark']);

export function normalizeTheme(v) { return THEMES.indexOf(v) > -1 ? v : 'auto'; }

export function loadPrefs(storage) {
  const s = storage || browserStorage();
  const p = s.getJSON(UI_KEY, null);
  return { theme: normalizeTheme(p && typeof p === 'object' ? p.theme : null) };
}

// يدمج التغيير مع باقي ما في المفتاح (لا يمحو حقولاً أخرى)
export function savePrefs(patch, storage) {
  const s = storage || browserStorage();
  const cur = s.getJSON(UI_KEY, null);
  const base = cur && typeof cur === 'object' && !Array.isArray(cur) ? cur : {};
  return s.setJSON(UI_KEY, Object.assign({}, base, patch));
}

export function applyTheme(theme, root) {
  const r = root || document.documentElement;
  const v = normalizeTheme(theme);
  if (v === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', v);
  return v;
}
