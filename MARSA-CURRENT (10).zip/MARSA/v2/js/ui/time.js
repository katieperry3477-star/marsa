// تسميات الزمن النسبي العربية (ختم آخر تحديث، «بعد N يوم»): دوال نقية؛ النصوص من ar.js. الأرقام لاتينية (E-025).
export const STALE_MS = 24 * 60 * 60 * 1000;
export const DAY_MS = 24 * 60 * 60 * 1000;

// صيغ الجمع العربية: 1 مفرد · 2 مثنى · 3–10 جمع قلة · غير ذلك تمييز مفرد
export function pluralForm(n) {
  if (n === 1) return 'one';
  if (n === 2) return 'two';
  if (n >= 3 && n <= 10) return 'few';
  return 'many';
}

export function agoUnit(diffMs) {
  const d = Math.max(0, diffMs);
  const m = Math.floor(d / 60000);
  if (m < 1) return { unit: 'now', n: 0 };
  if (m < 60) return { unit: 'minute', n: m };
  const hr = Math.floor(m / 60);
  if (hr < 24) return { unit: 'hour', n: hr };
  return { unit: 'day', n: Math.floor(hr / 24) };
}

export function agoLabel(diffMs, tf) {
  const u = agoUnit(diffMs);
  if (u.unit === 'now') return tf('ago.now');
  return tf('ago.' + u.unit + '.' + pluralForm(u.n), { n: u.n });
}

export function isStale(diffMs) { return diffMs > STALE_MS; }

// «بعد N يوم» للامتحانات: 0 اليوم · 1 باچر · 2 بعد يومين · 3–10 بعد N أيام · غير ذلك بعد N يوماً
export function inDaysLabel(n, tf) {
  if (n <= 0) return tf('in.today');
  if (n === 1) return tf('in.tomorrow');
  if (n === 2) return tf('in.two');
  return tf(n <= 10 ? 'in.few' : 'in.many', { n });
}
