// جلسة معاينة تجريبية مؤقتة (02.02): تُحدَّد الشاشة والدور قبل وجود الحسابات (04.x). تُحذف عند بناء الدخول الحقيقي.
// ليست تبديل دور داخل التطبيق (R-075): تظهر قبل القشرة فقط، والدور يُحفظ في عنوان الصفحة ?mock= دون أي تخزين.
import { h, icon } from './dom.js';
import { t } from '../core/i18n.js';
import { ROLE_ICON } from './icons.js';

export const MOCK_ROLES = Object.freeze(['student', 'rep', 'dev']);

export function roleFromSearch(search) {
  let v = null;
  try { v = new URLSearchParams(search || '').get('mock'); } catch (e) { v = null; }
  return MOCK_ROLES.indexOf(v) > -1 ? v : null;
}

export function setUrlRole(role) {
  try {
    const u = new URL(location.href);
    if (role) u.searchParams.set('mock', role); else u.searchParams.delete('mock');
    history.replaceState(history.state, '', u.pathname + u.search + u.hash);
  } catch (e) { /* لا يؤثر على العمل */ }
}

export function mountPicker(svc) {
  const el = h('div', { class: 'page-inner picker', 'data-view': 'picker' }, [
    h('div', { class: 'page-head' }, h('h1', { class: 'page-title', tabindex: '-1' }, t('mock.title'))),
    h('p', { class: 'note-box' }, [icon('info', 's'), t('mock.note')]),
    h('div', { class: 'role-cards' }, MOCK_ROLES.map((r) => h('button', { class: 'role-card', type: 'button', 'data-role': r, on: { click: () => svc.pickRole(r) } }, [
      h('span', { class: 'role-ico' }, icon(ROLE_ICON[r])),
      h('span', { class: 'role-name' }, t('role.' + r))
    ])))
  ]);
  return { el, layoutKey: null, update() {}, refresh() { return Promise.resolve(); }, destroy() {} };
}
