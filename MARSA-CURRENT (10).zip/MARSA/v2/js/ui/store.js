// حالة القشرة في الذاكرة فقط (لا تخزين هنا): الدور، وضع الدعم، الاتصال، فتح القائمة. التفضيلات المحفوظة في theme.js عبر حارس التخزين.
// الدور في هذه المرحلة «جلسة تجريبية» (mock-session.js)؛ يحل محله دور الخادم في 04.x (R-075: لا تبديل دور من الواجهة).
const state = {
  role: null,            // student | rep | dev | null (بلا جلسة)
  support: null,         // { role, name, minutes } أثناء وضع الدعم (عرض بصفة) — مجرد عرض وهمي الآن
  online: true,
  sidebarOpen: false,
  unread: 0,
  version: ''
};
const subs = new Set();

export function get() { return state; }
export function set(patch) {
  let changed = false;
  Object.keys(patch).forEach((k) => { if (state[k] !== patch[k]) { state[k] = patch[k]; changed = true; } });
  if (changed) subs.forEach((fn) => fn(state));
}
export function subscribe(fn) { subs.add(fn); return () => subs.delete(fn); }
// الدور الفعّال للقشرة: أثناء وضع الدعم = دور الحساب المعروض (قشرته وقائمته وشريطه)
export function effectiveRole() { return state.support ? state.support.role : state.role; }
