// بيانات وهمية فقط (البرومبت 02.02): لا شبكة ولا حسابات ولا بيانات حقيقية. تُستبدل بطبقة البيانات الحقيقية في 03.04.
// محاكاة الحالات للمعاينة والاختبار عبر ?state= داخل الهاش مثل #/preps/today?state=error :
//   loading (يبقى الهيكل) · empty · error · flaky (يفشل أول طلب فقط) · offline · stale (أكثر من 24 ساعة) · blocked · conflict
// نصوص الواجهة تأتي من ar.js؛ هنا محتوى سجلات وهمية فقط (أسماء بعلامة «تجريبي»).
const DELAY_MS = 300;
const HOUR = 3600000, MIN = 60000;
const calls = [];

export const MOCK_UNREAD = 3;
export const SUPPORT_TARGETS = Object.freeze({
  student: { role: 'student', name: 'طالب تجريبي 7', minutes: 30 },
  rep: { role: 'rep', name: 'ممثل تجريبي 2', minutes: 30 }
});

// سجل الاستدعاءات: يثبت أن الحارس لا يطلب بيانات لشاشة محجوبة (R-029)
export function callLog() { return calls.slice(); }
export function resetCallLog() { calls.length = 0; }

function preps() {
  return [
    { id: 'p1', subject: 'math', homework: 'حل تمارين الصفحة 45 كاملة', notes: 'مراجعة القوانين قبل الحل، وإحضار الدفتر والآلة الحاسبة.', pinned: true, files: 2, editedAgo: 20 * MIN },
    { id: 'p2', subject: 'physics', homework: 'مسائل الفصل الثالث (1 إلى 6)', notes: '', pinned: false, files: 0, editedAgo: 2 * HOUR },
    { id: 'p3', subject: 'chemistry', homework: '', notes: 'تجربة المختبر غداً: إحضار المريول وتدوين الملاحظات.', pinned: false, files: 4, editedAgo: 5 * HOUR },
    { id: 'p4', subject: 'arabic', homework: 'كتابة موضوع تعبير من صفحة واحدة', notes: 'الالتزام بالفقرات الثلاث: مقدمة وعرض وخاتمة.', pinned: false, files: 1, editedAgo: 26 * HOUR }
  ];
}

export function buildData(screenId, role) {
  switch (screenId) {
    case 'SC-HOME-S':
      return { pinned: { title: 'موعد تجريبي لمراجعة عامة', body: 'نص إعلان وهمي لعرض البطاقة المثبّتة.' }, today: { today: 3, tomorrow: 2, examInDays: 1 }, notifs: ['تحضير جديد في مادة الرياضيات', 'تعديل على واجب الفيزياء'] };
    case 'SC-HOME-R':
      return { pinned: { title: 'إعلان تجريبي مثبّت', body: 'نص إعلان وهمي لعرض البطاقة المثبّتة.' }, today: { today: 3, tomorrow: 2, examInDays: 1 }, alerts: { attendanceOpen: true, overdueCosts: 3 } };
    case 'SC-DEV-HOME':
      return {
        sys: { schema: '2.0-mock', backupAgo: 6 * HOUR },
        storage: { dbUsed: 12, dbMax: 500, filesUsed: 40, filesMax: 1024 },
        reps: { active: 3, suspended: 1 },
        audit: ['إنشاء رمز تفعيل لممثل تجريبي', 'تعليق حساب تجريبي', 'نسخة احتياطية وهمية', 'دخول المطوّر', 'تغيير إعداد وهمي']
      };
    case 'SC-PREPS-TODAY':
      return { items: preps() };
    case 'SC-PREPS-TOMORROW':
      return { exam: { subject: 'chemistry' }, rows: [{ subject: 'math', preps: 1, homework: true }, { subject: 'chemistry', preps: 0, homework: false }, { subject: 'english', preps: 2, homework: true }, { subject: 'biology', preps: 0, homework: false }] };
    case 'SC-EXAM':
      return { next: { subject: 'chemistry', inDays: 1, time: '09:00' }, upcoming: [{ subject: 'chemistry', inDays: 1 }, { subject: 'math', inDays: 6 }, { subject: 'physics', inDays: 12 }] };
    case 'SC-NOTIFS':
      return { items: [
        { id: 'n1', text: 'أُضيف تحضير جديد لمادة الرياضيات', unread: true, ago: 15 * MIN },
        { id: 'n2', text: 'إعلان جديد من ممثل الصف', unread: true, ago: 3 * HOUR },
        { id: 'n3', text: 'عدنا امتحان الكيمياء باچر', unread: true, ago: 5 * HOUR },
        { id: 'n4', text: 'عُدّل واجب مادة الفيزياء', unread: false, ago: 30 * HOUR }
      ] };
    default:
      return { rows: 4, role };
  }
}

// يحاكي طلب بيانات شاشة: { screenId, role, state, attempt, offline } ◄ Promise يُرفض عند الخطأ.
export function loadScreenData(o) {
  calls.push(o.screenId);
  return new Promise((resolve, reject) => {
    if (o.state === 'loading') return; // لا يُحسم أبداً: يبقى هيكل التحميل للمعاينة
    setTimeout(() => {
      if (o.state === 'error' || (o.state === 'flaky' && o.attempt === 0)) { reject(new Error('mock-error')); return; }
      const age = o.state === 'stale' ? 30 * HOUR : (o.offline || o.state === 'offline') ? 3 * HOUR : 0;
      const fetchedAt = Date.now() - age;
      if (o.state === 'empty') { resolve({ empty: true, data: null, fetchedAt }); return; }
      resolve({ empty: false, data: buildData(o.screenId, o.role), fetchedAt });
    }, DELAY_MS);
  });
}
