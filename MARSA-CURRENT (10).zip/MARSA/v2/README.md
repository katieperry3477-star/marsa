# v2/ — مَرسى V2 (معزول عن V1)

مجلد واحد مستقل. **حدّ الرجوع: حذف هذا المجلد** ثم `scripts/v2-sync.js` غير لازم؛ V1 (`index.html`، `js/v1-*`، `css/v1.css`) و`full.html` لا يعتمدان عليه ولا يستوردان منه.
المرجع الكامل: `docs/execution-v2/V2-FOUNDATION.md`.

| المسار | الغرض | يُملأ في |
|---|---|---|
| `index.html` | نقطة دخول + هياكل القشرة (ترويسة، قائمة، شريط سفلي، تنبيهات) — بلا سكربت/نمط مضمّن (CSP) | 02.02 ✅ |
| `js/main.js` | دخول ES module: المظهر ◄ الدور التجريبي ◄ القشرة ◄ `version.json` | 02.02 ✅ |
| `js/core/` | ثوابت العزل، حارس التخزين `marsa.v2.*`، النصوص، محمّل الوحدات القديمة | 02.01 ✅ |
| `js/i18n/ar.js` | نصوص الواجهة العربية (ADR-320) | يتوسع مع كل شاشة |
| `js/data/` | الآن `mock.js` **بيانات وهمية مؤقتة**؛ لاحقاً طبقة البيانات (Supabase + كاش IndexedDB `marsa-v2`) | 03.04 |
| `js/features/` | وظائف الأدوار (طلاب، حضور، درجات، تحاضير…) | 05.x–08.x |
| `js/ui/` | القشرة: ترويسة، قائمة جانبية، شريط سفلي، حالات، موجّه، مظهر، شاشات هيكلية | 02.02 ✅ |
| `legacy/` | نسخ **حرفية** لوحدات V1 النقية + `MANIFEST.json` (بصمات وفجوات التكييف) | 02.01 ✅ |
| `css/tokens.css` | رموز التصميم — **مولَّد** من `tests/ui/ui-map-v2.js` | 02.01 ✅ |
| `css/base.css` · `shell.css` · `components.css` | أساس + هيكل + مكوّنات (كل لون من `tokens.css`، خصائص منطقية RTL، حركة transform/opacity) | 02.02 ✅ |
| `_headers` | CSP وترويسات (ADR-317) | 02.03 ينشر |
| `version.json` | رقم البناء و`minSupported` (ADR-310) — الآن `2.0.0-shell.1` | كل إصدار |

## قواعد
- لا كود ولا نمط مضمّن، لا CDN، لا أسرار، لا مفاتيح `marsa.v1.*`/`marsa.academic.*`، لا إشارة إلى `full.html` أو `js/app.js` أو `css/styles.css` أو `../` خارج المجلد.
- ما في `legacy/` لا يُعدَّل يدوياً: `node scripts/v2-sync.js` يعيد النسخ و`--check` يفحص. التكييف مع مخطط V2 في طبقة منفصلة داخل `js/data` أو `js/features`.
- يُفحص كل ذلك آلياً: `node tests/v2/v2-isolation.test.js` و`node tests/v2/legacy-parity.test.js` و`NODE_PATH=$(npm root -g) node tests/v2/e2e-v2-foundation.playwright.js`.

## القشرة (02.02) — التشغيل المحلي والمعاينة
- وحدات ES لا تعمل من `file://`: `cd MARSA && python3 -m http.server 8000` ثم `http://localhost:8000/v2/index.html`.
- المنتقي التجريبي المؤقت يسأل عن الدور (طالب/ممثل/مطوّر) ويحفظه في العنوان `?mock=` فقط. محاكاة الحالات: `…#/preps/today?state=loading|empty|error|flaky|offline|stale|blocked|conflict`.
- `js/ui/nav-config.js` و`js/i18n/ar-nav.js` **مولَّدان** من خريطة الواجهات: `node scripts/v2-nav-sync.js` (و`--check`). لا تعدّلهما يدوياً.
- الاختبارات: `node tests/v2/shell-config.test.js` و`NODE_PATH=$(npm root -g) node tests/v2/e2e-v2-shell.playwright.js`. التقرير: `docs/execution-v2/UI-SHELL-REPORT.md`.
- سقالة مؤقتة تُحذف/تُستبدل: `js/ui/mock-session.js` (04.x) و`js/data/mock.js` و`?state=` (03.04).
