// config/marsa-config.example.js — قالب الإعداد العام للواجهة (03.01). غير محمَّل من index.html اليوم.
// الاستعمال لاحقاً (P5 فقط): انسخه إلى js/marsa-config.js وعدّل القيم العامة.
// ممنوع هنا: أي سر (sb_secret_… / service_role / HMAC / كلمة سر قاعدة بيانات). المفتاح العام وحده مسموح.
// الحقول الثلاثة هي المسموحة فقط؛ scripts/check-env.js يرفض غيرها ويرفض عدم مطابقته لملف .env.<البيئة>.
(function (g) {
  'use strict';
  g.MARSA_CONFIG = Object.freeze({
    mode: 'local',              // 'local' (الافتراضي الآمن) أو 'shared'
    supabaseUrl: '',            // عند shared فقط: http://127.0.0.1:54321 (E1) أو https://<ref>.supabase.co
    supabasePublishableKey: ''  // عند shared فقط: sb_publishable_…
  });
})(typeof window !== 'undefined' ? window : globalThis);
