# 00 — نظرة عامة على المشروع

> ذاكرة دائمة داخل `MARSA-CURRENT.zip` (U2-039، 2026-11-14). المرجع الأول في كل جلسة. آخر مهمة مسجّلة: **المهمة-009 (02.02)**. لا أسرار هنا.

## ما هو المشروع
- **الاسم:** مَرسى (MARSA).
- **الغرض:** تطبيق عربي (RTL أولاً) لإدارة **شعبة/صف دراسي واحد** (~100 طالب في الإصدار الأول): تحاضير وواجبات يومية، حضور وغياب، درجات وامتحانات، جدول أسبوعي، تكاليف/مدفوعات بالدينار، إعلانات وإشعارات، ملفات. التفصيل في `docs/execution-v2/PRODUCT_SPEC.md` (مستخلص من إجابات المستخدم).
- **الأدوار (V2):** **مطوّر** واحد، **ممثلون** متساوون، **طلاب**. الدور يأتي من الخادم؛ لا تبديل دور داخل التطبيق (R-075).
- **المنصات المستهدفة:** iPhone كـPWA، Android (APK من القاعدة نفسها لاحقاً)، وسطح المكتب؛ يعمل دون اتصال بآخر بيانات محفوظة وكتابة أثناء الاتصال فقط (ADR-309). استضافة وخادم **مجانيان فقط** (Supabase مجاني).
- **اللغة:** العربية فقط في الإصدار الأول (ADR-320)؛ الأرقام لاتينية (E-025)؛ الاتجاه RTL؛ لهجة الواجهة عراقية خفيفة حسب خريطة الواجهات.

## الحالة بإيجاز
- **V1** (محلي كامل بلا خادم) يعمل ومحمي بالبصمات؛ لا يُعدَّل.
- **V2** قيد البناء بالتسلسل: خط الأساس والتصميم والمعمارية وقاعدة البيانات (تصميم) وخريطة الواجهات ✅، هيكل `v2/` المعزول ✅، **قشرة الواجهة ببيانات وهمية ✅ (02.02)**. غير منفَّذ: PWA/النشر (02.03)، Supabase/RLS/Auth (03.x–04.x)، الشاشات الوظيفية (05–08). التفصيل: `02_PROJECT_STATE.md`.

## التقنيات
- **V1:** HTML/CSS/JavaScript عادي بلا إطار ولا حزم؛ تخزين `localStorage` (`marsa.v1.*`, `marsa.academic.*`).
- **V2 (الحالي):** وحدات ES بلا bundler، CSP صارمة (`script-src 'self'; style-src 'self'` بلا unsafe-inline)، رموز تصميم مولَّدة، موجّه هاش، DOM بلا `innerHTML`، تخزين `marsa.v2.*` عبر حارس واحد.
- **V2 (مخطَّط):** Supabase (Postgres + RLS + Auth + Storage + Realtime) + PWA؛ التصميم في `ARCHITECTURE-V2.md` و`DATA-MODEL-V2.md` و`db/schema-v2.sql`.
- **الاختبار:** Node (مجموعة اختبارات ذاتية بلا اعتمادات) + Playwright Chromium رأسي. لا Skills/MCP/إضافات/أطر مدفوعة (U2-036).

## البنية (جذر الأرشيف `MARSA/`)
| المسار | المحتوى |
|---|---|
| `index.html` · `css/v1.css` · `js/v1-*.js` | تطبيق V1 (لا يُعدَّل) |
| `full.html` · `css/styles.css` · `js/app.js` · `js/*-model.js` · `js/academic-store.js` | النسخة الكاملة القديمة (مرجعية، لا تُعدَّل) |
| `v2/` | **V2 المعزول** (حدّ الرجوع: حذفه) — `index.html`، `css/`، `js/{core,i18n,ui,data,features}`، `legacy/`، `_headers`، `version.json` |
| `docs/execution-v2/` | حزمة التنفيذ: وثائق التحكم والحالة والمواصفات والتقارير والأدوات والبرومبتات |
| `docs/architecture/` | سجلات ADR والقرارات القديمة + `code-baseline.sha256` |
| `tests/` | اختبارات Node وPlaywright (V1، الأمان، الترحيل، الواجهة، `v2/`) |
| `scripts/` | `v2-sync.js` (وحدات legacy)، `v2-nav-sync.js` (التنقل)، `check-env.js` |
| `الصور المرجعية/` | لقطات داكنة لكل مهمة (`00.01`…`02.01`، ثم `المهمة-009`) |
| `PROJECT_MEMORY/` | هذه الذاكرة |
| `MARSA_PROGRESS.md` · `MARSA_HANDOFF.md` · `MARSA_BACKUP_CHAT.md` | ملخصات حالة قديمة/متجددة (لا يُمحى تاريخها) |
| `archive/` · `config/` | أرشيف المرحلة الخامسة الأصلي؛ مثال إعدادات بلا أسرار |

## أهم الملفات المصدرية والمرجعية
- التحكم: `docs/execution-v2/{PROMPT_CONTROL,REFERENCE_IMAGES_RULE,START_HERE,STATE.json,QUEUE_STATE.json,HANDOFF,DECISION_REGISTER,PRODUCT_SPEC,PROMPT_INDEX,ROADMAP,BLOCKERS,CHANGELOG,TEST_EVIDENCE}.md`.
- التصميم: `UI-MAP-V2.md` (45 شاشة، مصدرها الآلي `tests/ui/ui-map-v2.js`)، `ARCHITECTURE-V2.md`، `ADR-V2.md`، `THREAT-MODEL-V2.md`، `GATES.md`، `ACCESS-MATRIX-V2.md`، `DATA-MODEL-V2.md`، `REQUIREMENTS-TRACEABILITY.md` (R-001…R-100).
- V2 الحالي: `V2-FOUNDATION.md`، `UI-SHELL-REPORT.md`، `v2/js/ui/shell.js` و`screens.js` و`router.js`، `scripts/v2-nav-sync.js`.
