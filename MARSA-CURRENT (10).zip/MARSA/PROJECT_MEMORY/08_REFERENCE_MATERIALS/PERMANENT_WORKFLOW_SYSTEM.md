<!-- مادة مرجعية أصلية: وثيقة المستخدم «نظام الذاكرة الدائمة وسجل المهام والأدلة البصرية» كما وردت حرفياً بتاريخ 2026-11-14 (أثناء تنفيذ البرومبت 02.02). لا تُعدَّل؛ الملخص التنفيذي في 01_PERMANENT_INSTRUCTIONS.md. -->

PERMANENT PROJECT MEMORY, TASK ACTIVITY LOG & VISUAL EVIDENCE SYSTEM

This is a permanent workflow requirement. Apply it to every development task without exception. It supplements all existing project instructions and must never replace, weaken, or remove them.

1. Task Activity Log — Chronological Execution Record

For every task, maintain a clear chronological record of the actual work performed, similar to a professional AI coding agent's activity timeline.

Record meaningful actions as they happen, including:

- Inspecting existing project files and understanding the current implementation.
- Reading relevant source code, documentation, and reference materials.
- Creating new files.
- Editing existing files.
- Fixing bugs and implementation issues.
- Running tests and analyzing their results.
- Re-running tests after applying fixes.
- Checking responsive layouts at relevant screen widths.
- Reviewing the actual application in the browser.
- Capturing screenshots as visual evidence.
- Updating project documentation and memory.

Each entry must describe one meaningful action and its actual outcome.

Example activity timeline:

Task #008 — Improve the mobile interface

1. Inspected the existing navigation implementation.
2. Read the relevant CSS and JavaScript files.
3. Identified a mobile navigation overflow issue.
4. Updated the navigation layout.
5. Fixed the responsive button positioning.
6. Ran the existing test suite.
7. Applied fixes to the failing tests.
8. Re-ran the test suite — passed.
9. Checked the interface at mobile, tablet, and desktop widths.
10. Captured updated dark-mode screenshots.
11. Updated the project memory and task history.

These are illustrative examples, not mandatory actions. Only record actions that were actually performed.

Activity Log Rules

- Keep entries in chronological order.
- Clearly distinguish completed, failed, skipped, and blocked actions.
- Report actual test results, including failures.
- Record the names of created, modified, and deleted files.
- Include important discoveries and implementation decisions.
- Do not invent actions, tests, file changes, or successful results.
- Never claim that a task is complete while important work remains unfinished.
- Maintain a concise task summary showing what changed and what remains.

2. Permanent Project Memory — ZIP Archive

Maintain a persistent project memory inside the project's existing ZIP archive.

If no memory structure exists, create one.

Recommended structure:

PROJECT_MEMORY/

- 00_PROJECT_OVERVIEW.md
- 01_PERMANENT_INSTRUCTIONS.md
- 02_PROJECT_STATE.md
- 03_TECHNICAL_ARCHITECTURE.md
- 04_FEATURES_AND_REQUIREMENTS.md
- 05_DECISIONS_AND_CONSTRAINTS.md
- 06_TASK_HISTORY.md
- 07_PENDING_WORK_AND_KNOWN_ISSUES.md
- 08_REFERENCE_MATERIALS/

What Must Be Remembered?

Project Overview

- Project name and purpose.
- Target platforms.
- Main technologies.
- Existing project structure.
- Important source files.

Permanent Instructions

- Design rules.
- Coding conventions.
- User preferences.
- Implementation restrictions.
- Testing requirements.
- All permanent workflow instructions.

Project State

- Current implementation status.
- Completed features.
- Partially completed features.
- Features that have not been implemented.
- Current version and important changes.

Technical Architecture

- Database structure.
- Storage mechanisms.
- Main functions and components.
- File relationships.
- APIs and integrations, without saving secret credentials.

Decisions

- Decisions explicitly approved by the user.
- Features intentionally excluded.
- Previous implementation choices.
- Reasons behind important technical decisions.

Task History

- Task number.
- Task objective.
- Actions performed.
- Files created, modified, or deleted.
- Tests performed and their results.
- Screenshots created.
- Remaining issues.

Processing New Information

Whenever the user provides a new text file, prompt, document, ZIP archive, screenshot, or additional project requirements:

1. Read and understand the supplied material.
2. Extract relevant permanent project information.
3. Preserve important details instead of reducing everything to a vague summary.
4. Save the original reference material when appropriate.
5. Update the relevant memory files.
6. Reconcile new information with existing decisions.
7. Never silently remove an existing requirement.
8. Follow the latest explicit user instruction when it conflicts with an older decision.
9. Keep the memory updated so the user does not have to repeatedly provide the same information.

The project memory is the primary reference for future work whenever it is available.

3. Reference Screenshots — Actual Visual Evidence

At the end of every task that produces a visible change, capture actual screenshots of the running application or final output.

Save them using this folder structure:

الصور المرجعية/

- المهمة-001/
- المهمة-002/
- المهمة-003/

The screenshot count is flexible. Capture only the screens that provide meaningful visual evidence of the completed task.

Screenshot Requirements

- Dark mode only.
- Capture the actual application, not an AI-generated imitation.
- Screenshots must represent the latest implemented state.
- Capture important screens affected by the task.
- Include relevant mobile, tablet, or desktop views when necessary.
- Never fabricate screenshots or use outdated images as evidence of new changes.
- Do not create screenshots merely to increase their number.

Screenshot Verification

After capturing the screenshots:

- Verify that each expected file exists.
- Verify that each file has a size greater than zero.
- Do not open, read, analyze, interpret, or describe the screenshot contents.
- Do not claim visual verification when only file existence was checked.

If the task makes no visible changes, screenshots are unnecessary. Record one brief explanation in the task history.

If screenshot capture is unavailable, record the actual limitation in one brief statement. Never pretend that screenshots were captured.

4. Task Completion — Update the ZIP

At the end of each task:

1. Update the permanent project memory.
2. Append the completed task to the task history.
3. Update the current project state.
4. Record newly discovered issues and pending work.
5. Store the new reference screenshots in the correct task folder.
6. Update the existing ZIP archive with the relevant new information and files.
7. Preserve previously stored memory and historical records.
8. Do not overwrite or remove earlier task evidence.
9. Verify that the updated archive contains the intended files.

Use sequential task numbers. Never reuse an existing task number.

If an existing ZIP archive is supplied, update that archive rather than creating an unrelated replacement.

If no ZIP archive is supplied but the project workspace is available, maintain the memory folder in the project and produce an updated ZIP when the workflow requires a handoff.

Never include unnecessary temporary files, caches, or secret credentials in the memory archive.

5. Final Task Report

At the end of each task, provide a concise but informative report containing:

Task: Number and title.

Execution Summary: What was actually completed.

Files: Files created, edited, or deleted.

Testing: Tests performed and their actual results.

Reference Screenshots: Number and folder location, or the reason they were not created.

Project Memory: Which memory records were updated.

Remaining Work: Any unfinished items, known problems, or blockers.

ZIP Archive: Confirm whether the updated archive was successfully created and verified.

Do not report success unless the relevant files and archive have actually been saved and checked.

6. Continuity Between Conversations

At the beginning of every new session:

1. Inspect the available project files and memory archive.
2. Read the permanent instructions and current project state.
3. Review previous task history and pending work.
4. Identify the latest completed task number.
5. Continue from the actual state of the project.
6. Do not repeat completed work unnecessarily.
7. Do not ask the user to resend information that already exists in the accessible project memory.

If the memory archive is not available in the current workspace or conversation, clearly report that limitation instead of pretending to remember its contents.

7. Highest-Priority Principles

- Work on the actual project, not just provide plans.
- Preserve existing working functionality.
- Keep a genuine chronological activity record.
- Save durable knowledge in project memory.
- Capture genuine visual evidence when the task changes the interface.
- Maintain the ZIP archive throughout the project.
- Never fabricate progress, screenshots, test results, or saved files.
- Every completed task must leave the project in a documented, recoverable state.

This system must remain active throughout the entire project lifecycle.
