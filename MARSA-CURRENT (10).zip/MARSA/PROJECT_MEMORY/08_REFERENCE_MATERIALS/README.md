# 08 — المواد المرجعية الأصلية

| الملف | ما هو |
|---|---|
| `PERMANENT_WORKFLOW_SYSTEM.md` | وثيقة المستخدم «نظام الذاكرة الدائمة وسجل المهام والأدلة البصرية» **حرفياً** (2026-11-14، U2-039) |
| `PROMPT_CONTROL.snapshot-2026-11-14.md` | لقطة من `docs/execution-v2/PROMPT_CONTROL.md` بعد التحديث (الحي هو الأصل عند الاختلاف) |
| `REFERENCE_IMAGES_RULE.snapshot-2026-11-14.md` | لقطة من قاعدة الصور بعد التحديث |
| `prompt-02.02.copy.txt` | نص البرومبت 02.02 كما نُفّذ (الأصل: `docs/execution-v2/prompts/02.02-بناء-هيكل-الواجهة-والتنقل.txt`) |

مراجع حيّة لا تُنسخ هنا لتفادي الانجراف: `docs/execution-v2/{PRODUCT_SPEC,DECISION_REGISTER,UI-MAP-V2,ARCHITECTURE-V2,DATA-MODEL-V2,REQUIREMENTS-TRACEABILITY,V2-FOUNDATION,UI-SHELL-REPORT}.md` وبرومبتات `docs/execution-v2/prompts/`.
