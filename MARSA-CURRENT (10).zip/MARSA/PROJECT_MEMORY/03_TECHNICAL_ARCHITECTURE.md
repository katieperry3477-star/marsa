# 03 — المعمارية التقنية

## V2 القائم (02.02)
**الإقلاع:** `v2/index.html` (هياكل فارغة + رمز الشعار) ◄ `js/main.js`: يطبّق المظهر المحفوظ قبل الرسم (`theme.js`) ◄ يقرأ الدور التجريبي من `?mock=` (`mock-session.js`) ◄ `shell.js` يبني القشرة ويستمع لـ`hashchange` وأحداث الاتصال ◄ يقرأ `version.json`.

**الطبقات (كلها `v2/js/`):**
| الطبقة | الملفات | ملاحظات |
|---|---|---|
| core | `constants.js`، `storage.js` (حارس `marsa.v2.*` وحده)، `i18n.js` (`t`/`tf` + دمج `ar.js` و`ar-nav.js`)، `legacy-loader.js` | من 02.01؛ `i18n.js` وُسّع في 02.02 |
| i18n | `ar.js` يدوي؛ `ar-nav.js` **مولَّد** | ADR-320 |
| ui | `nav-config.js` **مولَّد**؛ `router.js` (هاش + حارس دور)؛ `nav.js` (تبويب أب، عناوين)؛ `shell.js`؛ `screens.js`؛ `states.js`؛ `store.js`؛ `theme.js`؛ `time.js`؛ `dom.js`؛ `icons.js`؛ `mock-session.js` | بناء DOM بـcreateElement/textContent؛ لا style مضمّن |
| data | `mock.js` (وهمي مؤقت) ◄ يُستبدل في 03.04 | `callLog` للاختبار |
| features | فارغ (05–08) | |
| legacy | 6 وحدات V1 حرفية + `MANIFEST.json` | `scripts/v2-sync.js` |

**التدفق:** الهاش ◄ `router.resolve(SCREENS, role, hash)` ◄ ok/forbidden/notfound/root ◄ `shell.renderRoute` يبدّل الوضع (picker/bare/role) ويرسم الترويسة والقائمة والشريط ◄ `screens.mountScreen` يُرجع متحكماً ◄ `states.bindStateView` يدير الهيكل/المحتوى/الفراغ/الخطأ/المحجوب/التعارض مع إعادة المحاولة وإعادة التشغيل عند تغيّر الاتصال.

**الحالة:** `store.js` في الذاكرة فقط (الدور، وضع الدعم، الاتصال، فتح القائمة، غير المقروء، النسخة). التخزين الدائم الوحيد: `marsa.v2.ui = {"theme": …}` عند اختيار المستخدم فقط.

**التنقل المولَّد:** `tests/ui/ui-map-v2.js` ──`scripts/v2-nav-sync.js`──► `nav-config.js` (بيانات) + `ar-nav.js` (نصوص). وبالمثل `tokens.css` من `scripts/v2-sync.js`. كلاهما بـ`--check`.

**الأمن:** CSP صارمة في `v2/_headers` (`script-src 'self'; style-src 'self'`، بلا unsafe-inline/CDN)؛ لا `innerHTML`؛ الاستثناء الوحيد من CSSOM `style.setProperty('--support-h')`. الحارس واجهي فقط (R-029) والحكم للخادم/RLS لاحقاً.

**CSS:** `tokens.css` (مولَّد: فاتح/داكن/تلقائي) ◄ `base.css` (متغيّرات غير الألوان، إعادة ضبط، تركيز، حركة) ◄ `shell.css` (هيكل) ◄ `components.css`. نقاط الاستجابة: <768 هاتف، 768–1023 تابلت (عمود ≤720)، ≥1024 حاسوب (قائمة ثابتة 280، عمود ≤960).

## V1
HTML/JS عادي: `index.html` + `js/v1-*.js` + `css/v1.css`، تخزين `localStorage` (`marsa.v1.*`، `marsa.academic.*`). `full.html` + `js/app.js` + `js/*-model.js` نسخة كاملة قديمة مرجعية. لا يعتمد على V2.

## V2 المخطَّط (غير منفَّذ)
Supabase: Postgres (24 جدولاً عاماً و4 خاصة في `db/schema-v2.sql`) + RLS (مصفوفة الصلاحيات `ACCESS-MATRIX-V2.md`) + Auth + Storage + Realtime؛ كاش قراءة IndexedDB باسم `marsa-v2`؛ كتابة أثناء الاتصال فقط (ADR-309)؛ PWA وSW وحزمة نشر في 02.03. الوثائق: `ARCHITECTURE-V2.md`، `ADR-V2.md`، `THREAT-MODEL-V2.md`، `DATA-MODEL-V2.md`. لا مفاتيح ولا عناوين مشاريع في المستودع.

## الاختبارات
- Node: اختبارات ذاتية تطبع `PASS/FAIL` وملخصاً؛ Playwright Chromium رأسي بخادم محلي مؤقت يطبّق `_headers`.
- V2: `v2-isolation` (عزل ونظافة)، `legacy-parity` (بصمات وتكافؤ وCSS)، `shell-config` (تنقل/موجّه/زمن/مظهر/نصوص/نظافة/طفرات)، `e2e-v2-foundation`، `e2e-v2-shell` (181 فحصاً: أدوار، قوائم، حالات، مظهر، RTL، استجابة، دعم، اتصال، حركة، وصول، عزل).
- أدوات: `check-traceability.js`، `check-architecture.js`، `capture-reference.js` (لقطات).
