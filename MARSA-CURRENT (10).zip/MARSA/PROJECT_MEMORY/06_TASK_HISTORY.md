# 06 — تاريخ المهام (يُلحَق ولا يُمحى؛ الأرقام متسلسلة ولا تُعاد)

## ملاحظة الترقيم
نظام «المهمة-NNN» بدأ بوثيقة 2026-11-14. المهام 001–008 **مُدرَجة بأثر رجعي** حسب ترتيب الاكتمال في `STATE.json` ومن `CHANGELOG.md` و`MARSA_PROGRESS.md` (ليست سجلات نشاط لحظية، ولا تُعدّ أدلة جديدة). **المهمة-009 هي أول مهمة بسجل نشاط حي.** المهمة التالية = **010**.

## المهام 001–008 (أثر رجعي)
| # | البرومبت | الهدف والمخرجات (من السجلات) | الاختبارات المسجّلة حينها | لقطات |
|---|---|---|---|---|
| 001 | 00.01 | إعادة فحص خط الأساس (`BASELINE-RECHECK.md`)؛ أداة اللقطات وقاعدتها | Node 26 ملفاً 898/0؛ Playwright 23 ملفاً 1568/0 | `الصور المرجعية/00.01` (12) |
| 002 | 00.02 | تسوية القديم والجديد (`LEGACY-RECONCILIATION.md`): 25 تعارضاً و33 ADR مصنّفة؛ لافتات على 53 وثيقة قديمة — وثائق فقط | — | `00.02` |
| 003 | 00.03 | تتبّع المتطلبات (`REQUIREMENTS-TRACEABILITY.md`: R-001…R-100) + `check-traceability.js` | 21/0 | `00.03` |
| 004 | 00.04 | `ARCHITECTURE-V2.md`، `ADR-V2.md`، `THREAT-MODEL-V2.md`، `GATES.md`؛ اجتياز GX-00؛ `check-architecture.js` | 42/0 | `00.04` |
| 005 | 01.01 | مصفوفة الصلاحيات `ACCESS-MATRIX-V2.md` + اختبارات أمان وطفرات | access-matrix 152/0 وغيرها | — (وثائق/اختبارات) |
| 006 | 01.02 | نموذج البيانات `DATA-MODEL-V2.md` + `db/schema-v2.sql` على PostgreSQL 16 محلي مؤقت | schema 241/0؛ Node 1225/0 | — |
| 007 | 01.05 | `UI-MAP-V2.md` (45 شاشة) + `UI-DESIGN-PREVIEW-V2.html` | ui-map 73/0؛ معاينة 55/0؛ Node 1298/0 | — |
| 008 | 02.01 | `V2-FOUNDATION.md` + مجلد `v2/` المعزول + `v2/legacy` + `scripts/v2-sync.js` + اختبارات العزل والتكافؤ + CSP | isolation 52/0، parity 53/0، e2e 28/0، 7 طفرات | `02.01` (8) |

## المهمة-009 — البرومبت 02.02: بناء هيكل الواجهة والتنقل (2026-11-14)
**الهدف:** أساس الواجهة: RTL، استجابة، قشرة حسب الدور، قائمة جانبية سلسة، شريط تبويب، حالات التحميل/الفراغ/الخطأ، فاتح/داكن؛ ببيانات وهمية فقط؛ المخرج الرئيسي `UI-SHELL-REPORT.md`؛ اختبار ما نُفّذ فعلاً؛ تحديث الذاكرة والـZIP.

### سجل النشاط الزمني (فعلي)
1. **[مكتمل]** فك `MARSA-CURRENT__9_.zip` (435 ملفاً) وفحص بنيته.
2. **[مكتمل]** قراءة `PROMPT_CONTROL.md` و`REFERENCE_IMAGES_RULE.md` و`START_HERE.md` و`PRODUCT_SPEC.md` ونص البرومبت 02.02 و`STATE.json` و`QUEUE_STATE.json` و`DECISION_REGISTER.md`.
3. **[مكتمل]** قراءة `UI-MAP-V2.md` كاملاً و`V2-FOUNDATION.md`.
4. **[مكتمل]** قراءة كود `v2/` الحالي (index.html، main.js، core، i18n، base/tokens.css، READMEs) واختباري `tests/v2` (العزل وe2e الأساس) وبيانات `tests/ui/ui-map-v2.js` وCSS المعاينة وأداة الالتقاط وتنسيقات ملفات الحالة (CHANGELOG/HANDOFF/TEST_EVIDENCE/MARSA_*).
5. **[مكتمل]** تحقق من توفر Chromium 153 وPlaywright 1.63 بلا شبكة.
6. **[مكتمل]** حفظ ملاحظة المشروع في ذاكرة Claude الخارجية (خارج الأرشيف).
7. **[مكتمل]** إنشاء `scripts/v2-nav-sync.js` وتوليد `nav-config.js` و`ar-nav.js`؛ ثم عُدِّل المولِّد ثلاث مرات (ملاحظات «قيد التطوير» وعلم الطي؛ حذف التوضيح بين قوسين من العناوين؛ نصوص الإجراءات من الخريطة).
8. **[مكتمل]** كتابة وحدات القشرة (`dom/icons/store/theme/time/router/nav/states/screens/shell/mock-session`) و`data/mock.js` و`main.js` و`index.html` والأنماط الثلاثة، ورفع `version.json` إلى `2.0.0-shell.1`؛ توسيع `ar.js` و`i18n.js`.
9. **[مكتمل]** أول تشغيل تحت CSP الحقيقية: 0 أخطاء، الأدوار الثلاثة تظهر. *(راجعتُ ثلاث لقطات تجريبية مؤقتة — المنتقي ورئيسية الطالب والممثل — قبل أن تصل قاعدة «عدم فتح اللقطات»؛ لم تُحفظ في المشروع ولم تُستعمل دليلاً.)*
10. **[فاشل ◄ أُصلح]** `legacy-parity`: فحص «كل var(--x) في tokens.css» رفض متغيّرات `base.css` غير اللونية ◄ حُسِّن الفحص (يقبل تعريفاً محلياً) ووُسِّع إلى shell/components ◄ 57/0 (كان 53).
11. **[مكتمل]** `v2-isolation` 52/0 بعد الإضافات (وأعيد بعد تحديث READMEs: 52/0).
12. **[فاشل ◄ أُصلح]** `shell-config.test.js` (جديد): أول تشغيل 63/5 — خلل كود حقيقي (التبويب الأب للممثل اعتمد على المسار) ◄ أُصلح `nav.js` من جدول المسارات؛ 4 إيجابيات كاذبة (فاصلة عربية، رسائل أخطاء المطوّر، أرقام ميلي ثانية، كلمة fetchedAt) ◄ ضُبط الاختبار ◄ 68/0.
13. **[فاشل ◄ أُصلح]** `e2e-v2-shell` (جديد): عدة جولات — (أ) النقر على عنصر `aria-disabled` يتطلب force، (ب) توقيت `hashchange` غير المتزامن، (ج) حالة `loading` لا تستقر عمداً، (د) انتقال بالهاش فقط يُبقي التركيز على h1، (هـ) فحص الطيّ بـ`isVisible` لا يرى القص ◄ تصحيحات اختبار؛ ثم **إصلاحا كود**: ارتفاع شريط الدعم الكسري (كان مقرَّباً لأعلى فتظهر فجوة ≈1px) وعرض منتقي الدور على الحاسوب (≤640) (إضافة إلى إصلاح التبويب الأب في البند 12) ◄ **181/0**.
14. **[مكتمل]** تكييف `e2e-v2-foundation` للصفحة الأولى الجديدة ◄ 29/0.
15. **[مكتمل]** الانحدار الكامل: Node 31 ملفاً **1300/0**؛ Playwright 26 ملفاً **1833/0**؛ `v2-sync --check` و`v2-nav-sync --check` مطابقان؛ `check-traceability` 21/0؛ `check-architecture` 42/0؛ بصمات V1 22/22 و14/14. **[متخطّى]** `tests/db/schema-v2.test.js` (لا PostgreSQL). ملاحظتان: `e2e-isolation` ≈212ث (قطعته مهلة 140ث في أول تشغيل ◄ أُعيد منفرداً 144/0)؛ الخيط الخلفي مات عند انتهاء جلسة الأداة ◄ نُفّذ الباقي على دفعات.
16. **[مكتمل]** 8 طفرات على نسخ مؤقتة: **8/8 كُشفت** (3 بالـNode، 4 بالمتصفح؛ ختم «آخر تحديث» كُشف بانهيار F10 برمز خروج 2 بعد أن قرأ مجمّع الطفرات الأول خطأً أنه لم يُكشف ◄ تحققتُ بتشغيل مباشر).
17. **[مكتمل]** توسيع `capture-reference.js` (`--no-base`، `--v2-shell`، تحقق وجود/حجم) والتقاط **26 لقطة داكنة** في `الصور المرجعية/المهمة-009/`؛ تحقق: 26/26 موجودة وحجمها > 0، 0 فارغة، 0 مفقودة. **لم تُفتح.**
18. **[مكتمل]** كتابة `UI-SHELL-REPORT.md` وتحديث `STATE.json` و`DECISION_REGISTER.md` (U2-039/U2-040 وE-037…E-046) و`PROMPT_CONTROL.md` و`REFERENCE_IMAGES_RULE.md` و`CHANGELOG.md` و`TEST_EVIDENCE.md` و`HANDOFF.md` و`BLOCKERS.md` و`START_HERE.md` وREADMEs `v2/` وملفات `MARSA_*`. `QUEUE_STATE.json`: فُحص وهو صحيح (طابور فارغ، لا تنفيذ جارٍ) فلم يُعدَّل.
19. **[مكتمل]** استلام وثيقة نظام الذاكرة الدائمة أثناء المهمة: قراءتها، حفظ نصها الأصلي، تسوية التعارضين (التقرير الختامي في المحادثة؛ تسمية مجلد اللقطات) وتسجيلهما، إنشاء `PROJECT_MEMORY/` (00–08) وتحديث ذاكرة Claude الخارجية بالتفضيل الدائم.
20. **[مكتمل]** بناء `MARSA-CURRENT.zip` والتحقق منه: أُعيد بناء الأرشيف الحالي (الاسم الثابت، جذر `MARSA/`) من شجرة المشروع؛ **494 مدخلاً** (435 أصلياً + 33 ملفاً جديداً + 26 لقطة)؛ `testzip` سليم؛ بصمة كل ملف داخل الأرشيف = بصمته في الشجرة (0 اختلاف، 0 ناقص، 0 زائد)؛ **0 ملفاً أصلياً مفقوداً** و108 لقطات قديمة محفوظة؛ الملفات الأصلية المتغيّرة = 24 المعدَّلة المعدّدة أدناه فقط؛ أسماء الملفات غير اللاتينية بعلم UTF-8؛ لا مؤقتات ولا كاش ولا أسرار (مسح أنماط الأسرار لم يجد إلا أوصاف أنماط قديمة في اختبارات/وثائق). البصمة والحجم يُذكران في تقرير المحادثة لأن الأرشيف لا يحمل بصمة نفسه.

### الملفات
**أُنشئت (33 + 26 لقطة):**
- `PROJECT_MEMORY/00_PROJECT_OVERVIEW.md`
- `PROJECT_MEMORY/01_PERMANENT_INSTRUCTIONS.md`
- `PROJECT_MEMORY/02_PROJECT_STATE.md`
- `PROJECT_MEMORY/03_TECHNICAL_ARCHITECTURE.md`
- `PROJECT_MEMORY/04_FEATURES_AND_REQUIREMENTS.md`
- `PROJECT_MEMORY/05_DECISIONS_AND_CONSTRAINTS.md`
- `PROJECT_MEMORY/06_TASK_HISTORY.md`
- `PROJECT_MEMORY/07_PENDING_WORK_AND_KNOWN_ISSUES.md`
- `PROJECT_MEMORY/08_REFERENCE_MATERIALS/PERMANENT_WORKFLOW_SYSTEM.md`
- `PROJECT_MEMORY/08_REFERENCE_MATERIALS/PROMPT_CONTROL.snapshot-2026-11-14.md`
- `PROJECT_MEMORY/08_REFERENCE_MATERIALS/README.md`
- `PROJECT_MEMORY/08_REFERENCE_MATERIALS/REFERENCE_IMAGES_RULE.snapshot-2026-11-14.md`
- `PROJECT_MEMORY/08_REFERENCE_MATERIALS/prompt-02.02.copy.txt`
- `docs/execution-v2/UI-SHELL-REPORT.md`
- `scripts/v2-nav-sync.js`
- `tests/v2/e2e-v2-shell.playwright.js`
- `tests/v2/shell-config.test.js`
- `v2/css/components.css`
- `v2/css/shell.css`
- `v2/js/data/mock.js`
- `v2/js/i18n/ar-nav.js`
- `v2/js/ui/dom.js`
- `v2/js/ui/icons.js`
- `v2/js/ui/mock-session.js`
- `v2/js/ui/nav-config.js`
- `v2/js/ui/nav.js`
- `v2/js/ui/router.js`
- `v2/js/ui/screens.js`
- `v2/js/ui/shell.js`
- `v2/js/ui/states.js`
- `v2/js/ui/store.js`
- `v2/js/ui/theme.js`
- `v2/js/ui/time.js`
- `الصور المرجعية/المهمة-009/*.png` (26 لقطة داكنة)

**عُدِّلت (24):**
- `MARSA_BACKUP_CHAT.md`
- `MARSA_HANDOFF.md`
- `MARSA_PROGRESS.md`
- `docs/execution-v2/BLOCKERS.md`
- `docs/execution-v2/CHANGELOG.md`
- `docs/execution-v2/DECISION_REGISTER.md`
- `docs/execution-v2/HANDOFF.md`
- `docs/execution-v2/PROMPT_CONTROL.md`
- `docs/execution-v2/REFERENCE_IMAGES_RULE.md`
- `docs/execution-v2/START_HERE.md`
- `docs/execution-v2/STATE.json`
- `docs/execution-v2/TEST_EVIDENCE.md`
- `docs/execution-v2/tools/capture-reference.js`
- `tests/v2/e2e-v2-foundation.playwright.js`
- `tests/v2/legacy-parity.test.js`
- `v2/README.md`
- `v2/css/base.css`
- `v2/index.html`
- `v2/js/core/i18n.js`
- `v2/js/data/README.md`
- `v2/js/i18n/ar.js`
- `v2/js/main.js`
- `v2/js/ui/README.md`
- `v2/version.json`

**حُذفت:** لا شيء. (استُبدلت صفحة هيكل 02.01 بالقشرة؛ وظائفها محفوظة؛ أُزيلت مفاتيح `foundation.*` الخاصة بنصها فقط.)

### الاختبارات (فعلية)
Node: 31 ملفاً 1300/0 (+1 متخطّى بلا PostgreSQL). Playwright: 26 ملفاً 1833/0. الجديدة: `shell-config` 68/0، `e2e-v2-shell` 181/0. معدّلة: `e2e-v2-foundation` 29/0، `legacy-parity` 57/0. طفرات 8/8. التفاصيل: `docs/execution-v2/TEST_EVIDENCE.md` و`UI-SHELL-REPORT.md` §7.

### اللقطات
26 داكنة (هاتف 390×844، تابلت 768×1024، حاسوب 1280×800) في `الصور المرجعية/المهمة-009/`: الافتتاحية، المنتقي، رئيسية الأدوار الثلاثة، قوائم الأدوار، التحاضير الثلاث، الحالات، الإعدادات، القادم، الحجب، غير موجود، شريط الدعم، تابلت وحاسوب. **تحقق وجود/حجم فقط؛ لم تُفتح ولم تُقيَّم بصرياً.**

### المسائل المتبقية
انظر `07_PENDING_WORK_AND_KNOWN_ISSUES.md`: مؤجلات 02.02، السقالات المؤقتة، ما لم يُختبر (Safari/هاتف/قارئ شاشة/PostgreSQL).
