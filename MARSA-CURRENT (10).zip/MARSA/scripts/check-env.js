#!/usr/bin/env node
// scripts/check-env.js — فحص آمن لإعدادات بيئة MARSA (03.01). لا مكتبات، لا شبكة، لا يطبع أي قيمة.
// تشغيل:  node scripts/check-env.js [--target local|dev|prod] [--env-file مسار] [--root مسار]
// رموز الخروج: 0 سليم (قد توجد تحذيرات) · 1 مشكلة/نقص/مانع · 2 خطأ في طريقة الاستعمال.
'use strict';
var fs = require('fs'), path = require('path'), vm = require('vm');

var TARGETS = ['local', 'dev', 'prod'];
var FILE_FOR = { local: '.env.local', dev: '.env.dev', prod: '.env.prod' };
var KNOWN = ['MARSA_ENV', 'MARSA_MODE', 'SUPABASE_URL', 'SUPABASE_PUBLISHABLE_KEY', 'SUPABASE_SECRET_KEY', 'MARSA_INVITE_HMAC_SECRET'];
var LEGACY = { SUPABASE_ANON_KEY: 'SUPABASE_PUBLISHABLE_KEY', SUPABASE_SERVICE_ROLE_KEY: 'SUPABASE_SECRET_KEY' };
var PUBLIC_PREFIX = /^(NEXT_PUBLIC_|VITE_|PUBLIC_|REACT_APP_|MARSA_PUBLIC_)/;
var PLACEHOLDER = /(example|your[-_ ]?project|your[-_ ]?key|changeme|change[-_ ]?me|xxxx|placeholder|<.*>)/i;
// ملفات الواجهة المنشورة (V1 فقط). full.html وjs/app.js تطبيق قديم خارج النشر (ADR-203) ولا تُفحص هنا.
var FRONTEND_PATTERNS = [/^index\.html$/, /^css\/v1\.css$/, /^js\/(v1-[a-z-]+|safe-text|preps-model|marsa-config|data-gateway|remote-adapter|session)\.js$/];
var SECRET_PATTERNS = [
  { id: 'sb_secret', re: /sb_secret_[A-Za-z0-9_-]{8,}/ },
  { id: 'jwt_service_role', re: /eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/ },
  { id: 'service_role_word', re: /service_role/i },
  { id: 'secret_var_name', re: /SUPABASE_SECRET_KEY|MARSA_INVITE_HMAC_SECRET/ },
  { id: 'env_access', re: /process\.env|import\.meta\.env/ },
  { id: 'db_password_url', re: /postgres(?:ql)?:\/\/[^\s:@]+:[^\s@]+@/i }
];

function parseDotenv(text) {
  var out = {}, lines = String(text).split(/\r?\n/), i, m, k, v, q;
  for (i = 0; i < lines.length; i++) {
    m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$/.exec(lines[i]);
    if (!m) continue;
    k = m[1]; v = m[2].replace(/^\s+/, '');
    q = v.charAt(0);
    if ((q === '"' || q === "'") && v.indexOf(q, 1) > 0) v = v.slice(1, v.indexOf(q, 1));
    else v = v.replace(/\s+#.*$/, '').replace(/\s+$/, '');
    out[k] = v;
  }
  return out;
}

function jwtRole(tok) {
  var p = String(tok).split('.');
  if (p.length !== 3) return null;
  try { var j = JSON.parse(Buffer.from(p[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); return j && typeof j.role === 'string' ? j.role : '?'; } catch (e) { return '?'; }
}

function parseUrl(u) { try { return new URL(u); } catch (e) { return null; } }
function projectRef(u) { var p = parseUrl(u); if (!p) return null; var m = /^([a-z0-9]{10,})\.supabase\.co$/.exec(p.hostname); return m ? m[1] : null; }
function isPlaceholder(v) { return !v || PLACEHOLDER.test(v); }

function loadConfigJs(code) {
  var box = {}; box.window = box; box.globalThis = box; box.self = box;
  vm.runInNewContext(String(code), box, { timeout: 200 });
  return box.MARSA_CONFIG;
}

// io: { read(relPath) → string|null, list(relDir) → [names] }
function checkEnv(opts) {
  var target = opts.target, io = opts.io, res = [], envFile = opts.envFile || FILE_FOR[target];
  function add(id, status, msg) { res.push({ id: id, status: status, msg: msg }); }
  var env = null, text = io.read(envFile), mode, url, key, secret, ref, i, k, other;

  if (TARGETS.indexOf(target) < 0) { add('T0', 'fail', 'الهدف غير معروف: استعمل local أو dev أو prod.'); return summarize(res, target); }

  if (text === null) {
    if (target === 'local') add('F1', 'warn', 'لا يوجد ملف ' + envFile + ' — التطبيق يعمل بوضع local فقط بلا اتصال بأي خدمة (E0). للوضع المشترك انسخ .env.example إلى ' + envFile + '.');
    else add('F1', 'fail', 'ملف ' + envFile + ' غير موجود. لا يُفترض أي إعداد بديل. (' + (target === 'prod' ? 'prod محجوب أصلاً حتى G-D.' : 'dev السحابي يحتاج إذنك G-B قبل إنشاء المشروع.') + ')');
  } else {
    env = parseDotenv(text);
    add('F1', 'ok', 'ملف ' + envFile + ' موجود (قُرئت أسماء المتغيرات فقط).');
  }

  if (env) {
    for (k in env) {
      if (LEGACY[k]) add('N1', 'warn', 'اسم قديم «' + k + '»: استعمل ' + LEGACY[k] + ' (المفاتيح القديمة anon/service_role مُعلَن إيقافها نهاية 2026 في وثائق Supabase).');
      else if (KNOWN.indexOf(k) < 0) add('N2', 'warn', 'متغير غير معروف «' + k + '» — تحقق من الإملاء.');
      if (PUBLIC_PREFIX.test(k) && /(SECRET|SERVICE|PASSWORD|HMAC|PRIVATE)/i.test(k)) add('S1', 'fail', 'المتغير «' + k + '» بادئته تجعله يُشحن للمتصفح واسمه يدل على سر.');
    }

    if (env.MARSA_ENV === undefined || env.MARSA_ENV === '') add('E1', 'fail', 'MARSA_ENV مفقود (يجب أن يساوي ' + target + ').');
    else if (env.MARSA_ENV !== target) add('E1', 'fail', 'MARSA_ENV لا يطابق الهدف المفحوص: الملف يقول «' + String(env.MARSA_ENV).slice(0, 12) + '» والمطلوب «' + target + '». لا تستعمل ملف بيئة لبيئة أخرى.');
    else add('E1', 'ok', 'MARSA_ENV يطابق الهدف.');

    mode = env.MARSA_MODE;
    if (mode === undefined || mode === '') add('M1', 'fail', 'MARSA_MODE مفقود (local أو shared). لا نفترض shared أبداً.');
    else if (mode !== 'local' && mode !== 'shared') add('M1', 'fail', 'MARSA_MODE قيمة غير مقبولة (المسموح: local أو shared).');
    else add('M1', 'ok', 'MARSA_MODE = ' + mode + '.');

    url = env.SUPABASE_URL; key = env.SUPABASE_PUBLISHABLE_KEY; secret = env.SUPABASE_SECRET_KEY;

    if (mode === 'shared') {
      var pu = parseUrl(url || '');
      if (!url) add('U1', 'fail', 'SUPABASE_URL مفقود وهو لازم للوضع shared.');
      else if (isPlaceholder(url) || !pu) add('U1', 'fail', 'SUPABASE_URL قيمة وهمية أو غير صالحة.');
      else if (pu.username || pu.password || (pu.pathname !== '/' && pu.pathname !== '') || pu.search || pu.hash) add('U1', 'fail', 'SUPABASE_URL يجب أن يكون الأصل فقط (بلا مستخدم/كلمة سر/مسار/استعلام).');
      else if (target === 'local' && !(pu.protocol === 'http:' && (pu.hostname === '127.0.0.1' || pu.hostname === 'localhost'))) add('U1', 'fail', 'بيئة local يجب أن تشير إلى http://127.0.0.1 أو localhost فقط (ليس خدمة بعيدة).');
      else if (target !== 'local' && (pu.protocol !== 'https:' || !projectRef(url))) add('U1', 'fail', 'بيئة ' + target + ' يجب أن تكون https://<ref>.supabase.co.');
      else add('U1', 'ok', 'عنوان المشروع صالح الشكل لبيئة ' + target + '.');

      if (!key) add('K1', 'fail', 'SUPABASE_PUBLISHABLE_KEY مفقود وهو لازم للوضع shared.');
      else if (/^sb_secret_/.test(key) || jwtRole(key) === 'service_role') add('K1', 'fail', 'المفتاح في خانة «publishable» هو مفتاح سري (secret/service_role). أوقفه فوراً ولا تضعه بالواجهة؛ وإن كان حقيقياً فهو مكشوف ويلزم تدويره.');
      else if (isPlaceholder(key)) add('K1', 'fail', 'SUPABASE_PUBLISHABLE_KEY قيمة وهمية — ضع المفتاح الحقيقي لبيئتك.');
      else if (/^sb_publishable_/.test(key)) add('K1', 'ok', 'المفتاح العام بصيغة sb_publishable_ (مسموح للواجهة).');
      else if (jwtRole(key) === 'anon') add('K1', 'warn', 'مفتاح anon القديم (JWT): يعمل الآن لكن Supabase أعلنت إيقافه نهاية 2026؛ يُفضَّل sb_publishable_.');
      else add('K1', 'fail', 'صيغة المفتاح العام غير معروفة (المتوقع sb_publishable_…).');
    } else if (mode === 'local') {
      if (key && !isPlaceholder(key)) { if (/^sb_secret_/.test(key) || jwtRole(key) === 'service_role') add('K1', 'fail', 'مفتاح سري في خانة publishable.'); }
      add('U1', 'ok', 'الوضع local: لا يلزم عنوان ولا مفاتيح (V1 لا يتصل بشبكة).');
    }

    if (secret) {
      if (isPlaceholder(secret)) add('S2', 'warn', 'SUPABASE_SECRET_KEY وهمي — اتركه فارغاً ما لم تحتجه دالة خادمية.');
      else if (target === 'prod') add('S2', 'fail', 'مفتاح سري داخل ملف prod محلي. الأسرار الإنتاجية تُحفظ في أسرار الدوال على الخادم لا في ملف بجهازك.');
      else if (target === 'local' && /^sb_secret_/.test(secret)) add('S2', 'ok', 'مفتاح سري محلي (E1) للدوال الخادمية فقط؛ لا يدخل الواجهة.');
      else add('S2', 'warn', 'مفتاح سري موجود في ملف ' + target + ': يبقى للدوال الخادمية فقط ولا يُنسخ لأي ملف واجهة.');
    }

    if (target === 'dev' || target === 'prod') {
      other = target === 'dev' ? 'prod' : 'dev';
      var ot = io.read(FILE_FOR[other]);
      if (ot !== null) {
        var oe = parseDotenv(ot);
        ref = projectRef(url || '');
        if (ref && oe.SUPABASE_URL && projectRef(oe.SUPABASE_URL) === ref) add('X1', 'fail', 'dev وprod يشيران إلى المشروع نفسه. افصلهما: مشروع لكل بيئة (ADR-212).');
        else if (key && oe.SUPABASE_PUBLISHABLE_KEY && key === oe.SUPABASE_PUBLISHABLE_KEY && !isPlaceholder(key)) add('X1', 'fail', 'dev وprod يستعملان المفتاح نفسه.');
        else if (secret && oe.SUPABASE_SECRET_KEY && secret === oe.SUPABASE_SECRET_KEY && !isPlaceholder(secret)) add('X1', 'fail', 'dev وprod يستعملان المفتاح السري نفسه.');
        else add('X1', 'ok', 'dev وprod منفصلان.');
      }
    }
  }

  if (target === 'prod') add('G1', 'fail', 'مانع: البوابة G-D لم تُفتح — لا نشر ولا بيانات حقيقية ولا مشروع prod قبل قرارك الصريح.');

  // مقارنة js/marsa-config.js (إن وُجد) مع ملف البيئة
  var cfgText = io.read('js/marsa-config.js');
  if (cfgText !== null) {
    var cfg = null;
    try { cfg = loadConfigJs(cfgText); } catch (e) { add('C1', 'fail', 'js/marsa-config.js لا يُنفَّذ كما هو متوقع (خطأ صياغة أو عملية ممنوعة).'); }
    if (cfg) {
      var bad = Object.keys(cfg).filter(function (x) { return ['mode', 'supabaseUrl', 'supabasePublishableKey'].indexOf(x) < 0; });
      if (bad.length) add('C1', 'fail', 'js/marsa-config.js يحوي حقولاً غير مسموحة (المسموح: mode, supabaseUrl, supabasePublishableKey): ' + bad.join(', '));
      else if (env && (cfg.mode !== env.MARSA_MODE || (env.MARSA_MODE === 'shared' && (cfg.supabaseUrl !== env.SUPABASE_URL || cfg.supabasePublishableKey !== env.SUPABASE_PUBLISHABLE_KEY)))) add('C1', 'fail', 'js/marsa-config.js لا يطابق ملف ' + envFile + ' (الوضع/العنوان/المفتاح العام).');
      else add('C1', 'ok', 'js/marsa-config.js يحوي الحقول العامة المسموحة فقط' + (env ? ' ويطابق ملف البيئة.' : '.'));
    }
  }

  // فحص الواجهة المنشورة بحثاً عن أسرار
  var files = [], dirs = ['', 'css', 'js'], d, names, rel;
  for (d = 0; d < dirs.length; d++) {
    names = io.list(dirs[d]);
    for (i = 0; i < names.length; i++) {
      rel = dirs[d] ? dirs[d] + '/' + names[i] : names[i];
      if (FRONTEND_PATTERNS.some(function (p) { return p.test(rel); })) files.push(rel);
    }
  }
  var hits = [];
  files.forEach(function (f) {
    var c = io.read(f); if (c === null) return;
    SECRET_PATTERNS.forEach(function (p) { if (p.re.test(c)) hits.push(f + ' ← ' + p.id); });
    if (env) ['SUPABASE_SECRET_KEY', 'MARSA_INVITE_HMAC_SECRET'].forEach(function (n) { if (env[n] && !isPlaceholder(env[n]) && env[n].length >= 8 && c.indexOf(env[n]) >= 0) hits.push(f + ' ← قيمة سر من ' + n); });
  });
  if (hits.length) add('W1', 'fail', 'أسرار أو مراجع أسرار في ملفات الواجهة: ' + hits.join(' ، '));
  else add('W1', 'ok', 'فُحص ' + files.length + ' ملف واجهة: لا أسرار ولا مراجع env.');

  return summarize(res, target);
}

function summarize(res, target) {
  var fail = res.filter(function (r) { return r.status === 'fail'; }).length, warn = res.filter(function (r) { return r.status === 'warn'; }).length;
  return { target: target, results: res, failures: fail, warnings: warn, ok: fail === 0 };
}

function fsIo(root) {
  return {
    read: function (rel) { try { return fs.readFileSync(path.join(root, rel), 'utf8'); } catch (e) { return null; } },
    list: function (rel) { try { return fs.readdirSync(path.join(root, rel)).filter(function (n) { try { return fs.statSync(path.join(root, rel, n)).isFile(); } catch (e) { return false; } }); } catch (e) { return []; } }
  };
}

function main(argv) {
  var target = 'local', envFile, root = path.resolve(__dirname, '..'), i, a;
  for (i = 0; i < argv.length; i++) {
    a = argv[i];
    if (a === '--target') target = argv[++i];
    else if (a === '--env-file') envFile = argv[++i];
    else if (a === '--root') root = path.resolve(argv[++i] || '');
    else if (a === '-h' || a === '--help') { console.log('استعمال: node scripts/check-env.js [--target local|dev|prod] [--env-file مسار] [--root مسار]'); return 0; }
    else { console.error('وسيط غير معروف: ' + a); return 2; }
  }
  if (TARGETS.indexOf(target) < 0) { console.error('--target يجب أن يكون local أو dev أو prod'); return 2; }
  var r = checkEnv({ target: target, envFile: envFile, io: fsIo(root) });
  var icon = { ok: '✔', warn: '⚠', fail: '✖' };
  console.log('فحص إعدادات MARSA — الهدف: ' + target + '  (لا تُطبع أي قيم)');
  r.results.forEach(function (x) { console.log(' ' + icon[x.status] + ' [' + x.id + '] ' + x.msg); });
  console.log(r.ok ? 'النتيجة: سليم' + (r.warnings ? ' مع ' + r.warnings + ' تحذير' : '') : 'النتيجة: ' + r.failures + ' مشكلة تمنع المتابعة');
  return r.ok ? 0 : 1;
}

if (require.main === module) process.exit(main(process.argv.slice(2)));
module.exports = { checkEnv: checkEnv, parseDotenv: parseDotenv, jwtRole: jwtRole, projectRef: projectRef, FILE_FOR: FILE_FOR };
