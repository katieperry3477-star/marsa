#!/usr/bin/env node
/* MARSA V2 — مزامنة إعدادات التنقل (البرومبت 02.02، E-036 امتداداً).
 * يولّد من tests/ui/ui-map-v2.js (مصدر الحقيقة لخريطة الواجهات) ملفين داخل v2/:
 *   v2/js/ui/nav-config.js   بيانات فقط: الأشرطة السفلية، القوائم الجانبية، بنود «قيد التطوير»، جدول المسارات والأدوار
 *   v2/js/i18n/ar-nav.js     نصوص التنقل (ADR-320): كل ما يُعرض في القشرة مفتاح نص لا حرف داخل المنطق
 * الاستعمال:  node scripts/v2-nav-sync.js          يكتب الملفين
 *            node scripts/v2-nav-sync.js --check  يفحص فقط (رمز خروج 1 عند أي اختلاف) — لا يكتب شيئاً
 * لا شبكة ولا اعتمادات. التراجع: حذف الملفين مع v2/. */
'use strict';
var fs = require('fs'), path = require('path');
var ROOT = path.join(__dirname, '..');
var U = require(path.join(ROOT, 'tests', 'ui', 'ui-map-v2.js'));
var OUT_CFG = path.join(ROOT, 'v2', 'js', 'ui', 'nav-config.js');
var OUT_TXT = path.join(ROOT, 'v2', 'js', 'i18n', 'ar-nav.js');

var ROLE = { s: 'student', r: 'rep', d: 'dev' };
var ROLE_ORDER = ['student', 'rep', 'dev'];
function rolesOf(letters) { return ROLE_ORDER.filter(function (r) { return letters.split('').some(function (c) { return ROLE[c] === r; }); }); }

// عنوان الصفحة: يُحذف لاحق الدور وأي توضيح بين قوسين في آخر اسم الشاشة (مثل «(جديد)» و«(≡ SC-HOME-D)» و«(6 أرقام…)»)
function titleOf(ar) { return ar.replace(/\s*\([^)]*\)\s*$/, '').replace(/\s*—\s*(طالب|ممثل)\s*$/, '').trim(); }

function build() {
  var txt = {};
  var screens = {};
  U.SCREENS.forEach(function (s) {
    var routes = s.route.split(' · ').filter(function (r) { return r.indexOf('#/') === 0; }).map(function (r) { return r.slice(1); });
    txt['screen.' + s.id] = titleOf(s.ar);
    screens[s.id] = { id: s.id, title: 'screen.' + s.id, routes: routes, roles: rolesOf(s.roles), kind: s.kind, states: s.states, prompt: s.prompt };
  });

  var tabbars = {};
  ['s', 'r', 'd'].forEach(function (k) {
    var role = ROLE[k];
    tabbars[role] = U.TABBARS[k].tabs.map(function (t, i) {
      txt['tab.' + role + '.' + i] = t[0];
      return { label: 'tab.' + role + '.' + i, screen: t[1], icon: t[2] };
    });
  });

  var futureByKey = {};
  U.FUTURE.forEach(function (f) {
    txt['future.' + f.key] = f.ar;
    txt['future.' + f.key + '.text'] = f.ar + ' — قيد التطوير ولم يُفعَّل بعد. ' + f.note;
    txt['future.' + f.key + '.note'] = f.note;
    futureByKey[f.key] = { name: 'future.' + f.key, text: 'future.' + f.key + '.text', note: 'future.' + f.key + '.note', roles: rolesOf(f.roles) };
  });

  var sidebars = {};
  ['s', 'r', 'd'].forEach(function (k) {
    var role = ROLE[k];
    sidebars[role] = U.SIDEBARS[k].map(function (g, gi) {
      var title = null;
      if (g.title) { title = 'grp.' + role + '.' + gi; txt[title] = g.title; }
      return {
        title: title, footer: !!g.footer, collapsible: g.title === 'ملفي', // القابلة للطي: «ملفي» فقط (UI-MAP §4-ب)
        items: g.items.map(function (it) {
          if (it.future) return { type: 'future', key: it.future };
          if (it.action) { txt['action.' + it.action] = it.ar; return { type: 'action', action: it.action, label: 'action.' + it.action }; }
          var key = 'sb.' + role + '.' + it.screen; txt[key] = it.ar;
          return { type: 'link', label: key, screen: it.screen };
        })
      };
    });
  });

  var cfg = [
    '// مولَّد بـscripts/v2-nav-sync.js من tests/ui/ui-map-v2.js — لا تعدّله يدوياً (UI-MAP-V2 §2، §4، §7). النصوص في ar-nav.js بمفاتيح.',
    '// الجداول: الأشرطة السفلية (3 عناصر لكل دور)، القوائم الجانبية، بنود «قيد التطوير»، الشاشات (مسارات وأدوار وحالات).',
    'export const ROLES = Object.freeze(' + JSON.stringify(ROLE_ORDER) + ');',
    'export const TABBARS = Object.freeze(' + JSON.stringify(tabbars, null, 2) + ');',
    'export const SIDEBARS = Object.freeze(' + JSON.stringify(sidebars, null, 2) + ');',
    'export const FUTURE = Object.freeze(' + JSON.stringify(futureByKey, null, 2) + ');',
    'export const SCREENS = Object.freeze(' + JSON.stringify(screens, null, 2) + ');',
    'export const HOME_CAPS = Object.freeze({ cards: ' + U.HOME.maxCards + ', quick: ' + U.HOME.maxQuick + ' });',
    ''
  ].join('\n');

  var keys = Object.keys(txt).sort();
  var o = {}; keys.forEach(function (k) { o[k] = txt[k]; });
  var text = [
    '// مولَّد بـscripts/v2-nav-sync.js من tests/ui/ui-map-v2.js — لا تعدّله يدوياً. نصوص التنقل والعناوين (ADR-320).',
    'export const arNav = Object.freeze(' + JSON.stringify(o, null, 2) + ');',
    ''
  ].join('\n');
  return [[OUT_CFG, cfg], [OUT_TXT, text]];
}

function main() {
  var check = process.argv.indexOf('--check') > -1, bad = 0;
  build().forEach(function (f) {
    var cur = fs.existsSync(f[0]) ? fs.readFileSync(f[0], 'utf8') : null;
    if (check) { if (cur !== f[1]) { bad++; console.log('DIFF', path.relative(ROOT, f[0])); } else console.log('OK  ', path.relative(ROOT, f[0])); }
    else { fs.mkdirSync(path.dirname(f[0]), { recursive: true }); fs.writeFileSync(f[0], f[1]); console.log('WROTE', path.relative(ROOT, f[0])); }
  });
  process.exit(bad ? 1 : 0);
}
if (require.main === module) main();
module.exports = { build: build, titleOf: titleOf };
