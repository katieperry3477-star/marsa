#!/usr/bin/env node
/* MARSA V2 — مزامنة المكوّنات المعاد استعمالها (البرومبت 02.01، ADR-301).
 *  1) ينسخ حرفياً وحدات V1 النقية المختارة من js/ إلى v2/legacy/ (الأصل لا يُعدَّل أبداً).
 *  2) يكتب v2/legacy/MANIFEST.json (المصدر، البصمة، الاسم العام، البرومبت المالك، فجوات التكييف المعروفة، وما استُبعد ولماذا).
 *  3) يولّد v2/css/tokens.css من TOKENS في tests/ui/ui-map-v2.js (مصدر الحقيقة لرموز التصميم، UI-MAP-V2 §9-ب).
 * الاستعمال:  node scripts/v2-sync.js          يكتب الملفات
 *             node scripts/v2-sync.js --check  يفحص فقط (رمز خروج 1 عند أي اختلاف) — لا يكتب شيئاً
 * لا شبكة ولا اعتمادات. التراجع: حذف v2/. */
'use strict';
var fs = require('fs'), path = require('path'), crypto = require('crypto');
var ROOT = path.join(__dirname, '..');
var SRC = path.join(ROOT, 'js'), DST = path.join(ROOT, 'v2', 'legacy'), CSS = path.join(ROOT, 'v2', 'css', 'tokens.css');

function sha(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }

// ===== ما يُنسخ: وحدات نقية (بلا DOM ولا تخزين ولا شبكة) لها مقابل صريح في PRODUCT_SPEC =====
// deltas = فجوات بين الوحدة (شكل بيانات V1: camelCase + recordId) ومخطط V2 (db/schema-v2.sql: snake_case + UUID)؛ تُسدّها طبقة تكييف يكتبها
// البرومبت المالك، ولا تُعدَّل النسخة هنا (يمنع ذلك اختبار التكافؤ). الوحدة تبقى منطقاً نقياً: تحقق، ترتيب، تجميع، حساب.
var REUSE = [
  { file: 'safe-text.js', global: 'MarsaSafeText', owner: '07.01 · 06.04', purpose: 'عرض روابط النص بأمان (http/https فقط) للإعلانات والواجبات والملاحظات',
    reusable: 'كاملة (segments، safeHref)', deltas: [] },
  { file: 'attendance-model.js', global: 'MarsaAttendanceModel', owner: '05.03', purpose: 'تحقق وتجميع وترتيب الحضور والغياب',
    reusable: 'buildDay، countRows، filterRows، summarizeDays، findConflicts، searchKey، التواريخ',
    deltas: ['الحالات 4 (present/absent/late/excused) والمخطط 5 (يضيف exceptional)', 'camelCase (studentId/recordId) مقابل student_id/id', 'تسمية «بعذر» مقابل «مجاز» في المواصفة §5'] },
  { file: 'grades-model.js', global: 'MarsaGradesModel', owner: '05.04', purpose: 'تحليل الدرجات وحساب النسب والمعدل بقاعدة معلنة',
    reusable: 'parseNumber، percent، fmtNum، fmtPercent، pooledAverage، meanOfPercents، summarizeBySubject، searchKey (قاعدة المعدل المعلنة AVG_BASIS)',
    deltas: ['validateEntry لا يصلح كما هو: تقييم V1 له title وdate بينما درجة V2 لها term (monthly/midyear/final) وperiod_month بلا title ولا date', 'camelCase (studentId/maxScore) مقابل student_id/max_score', 'سقف الدرجة القصوى 1000 يطابق CHECK؛ الدرجات العشرية خانتان يطابق numeric(7,2)'] },
  { file: 'exams-model.js', global: 'MarsaExamsModel', owner: '05.04', purpose: 'تحقق الامتحانات وتقسيم القادم/الماضي',
    reusable: 'partition، isUpcoming، relativeLabel، daysBetween، filterRecords، التواريخ',
    deltas: ['title إلزامي في الوحدة ولا عمود له في exams V2 (المواصفة §6: مادة/موعد/وقت/ملاحظات)', 'examDate/startTime مقابل exam_date/start_time', 'سقف الملاحظات 1000 مقابل 300 في المخطط'] },
  { file: 'schedule-model.js', global: 'MarsaScheduleModel', owner: '05.02', purpose: 'تحقق الجدول الأسبوعي وتجميعه وترتيبه',
    reusable: 'sortDay، groupByDay، visibleDays، findConflicts، normTime، timeRange',
    deltas: ['day مقابل weekday (sat…fri)', 'period/startTime/endTime مقابل period_no/start_time/end_time'] },
  { file: 'payments-model.js', global: 'MarsaPaymentsModel', owner: '05.05', purpose: 'تحليل المبالغ (دينار صحيح) وتنسيقها وجمع الدفعات',
    reusable: 'parseAmount، formatAmount، sumRecords، totalsByStudent، التواريخ',
    deltas: ['النموذج دفتر مدفوعات V1 (purpose/receiptNo) لا بنود تكلفة مسندة لطلاب (cost_items → cost_assignments → payments) فالحالة المحسوبة (لم يدفع/جزئي/كامل) والمتبقي تُكتب في 05.05', 'سقف الإدخال 999,999,999,999 مقابل CHECK ≤ 100,000,000 في المخطط (الأضيق يحكم)', 'سجل الدفعات في V2 للإلحاق فقط والتصحيح بإبطال (E-009)'] }
];

// ===== ما لا يُنسخ ولماذا =====
var EXCLUDED = [
  { source: 'js/academic-store.js', reason: 'يكتب في localStorage بمفاتيح marsa.academic.*؛ V2 بلا وضع محلي (ADR-301، ADR-309) والمفاتيح محظورة (R-100)' },
  { source: 'js/v1-store.js', reason: 'مفاتيح marsa.v1.*؛ V2 يستعمل marsa.v2.* وIndexedDB marsa-v2 فقط' },
  { source: 'js/v1-demo.js', reason: 'بيانات تجريبية لـV1؛ V2 يستعمل بيانات اصطناعية خاصة به في الاختبارات فقط' },
  { source: 'js/v1-share.js', reason: 'قناة الكود MARSA1 (DEC-21): قرار 02.01 — V2 لا يستقبل بيانات من نص خارجي (ADR-V2 §3)؛ المزامنة عبر الخادم فقط' },
  { source: 'js/v1-text.js', reason: 'غلاف لـpreps-model لحقل «الصف/الشعبة» ورموز الواتساب؛ لا مقابل في V2' },
  { source: 'js/preps-model.js', reason: 'يفرض title وcontent وdate ظاهراً، وهذا يخالف المواصفة §7 (التحضير: مادة/يوم/واجب/ملاحظات/مرفقات) — تعارض C-13؛ يُكتب بديله في 06.01' },
  { source: 'js/lessons-model.js', reason: 'سجل دروس V1 بعنوان وتاريخ؛ مقابله في V2 حالة التحضير prep_status (06.03) فيُكتب ما يلزم هناك' },
  { source: 'js/archive-model.js', reason: 'يجمع دروساً/تحاضير/امتحانات بشكل بيانات V1؛ يُراجع عند 06.03 على مخطط V2' },
  { source: 'js/dashboard-model.js', reason: 'يلخّص بشكل بيانات V1؛ رئيسية V2 مختلفة (UI-MAP-V2 §6، سقف 4 بطاقات)' },
  { source: 'js/app.js · full.html · css/styles.css', reason: 'التطبيق الأكاديمي السابق: مرجع تاريخي محفوظ كما هو ولا يدخل V2 ولا حزمة نشره (ADR-302)' },
  { source: 'js/v1-app.js · js/v1-boot.js · css/v1.css', reason: 'واجهة V1؛ تبقى كما هي. نمط الانترو وملاءمة الهاتف مرجع تصميمي لـ02.02 يُعاد كتابته بلا سكربت/نمط مضمّن' }
];

function buildOutputs() {
  var out = {}, files = [];
  REUSE.forEach(function (r) {
    var buf = fs.readFileSync(path.join(SRC, r.file));
    out[path.join(DST, r.file)] = buf;
    files.push({ file: r.file, source: 'js/' + r.file, sha256: sha(buf), global: r.global, owner_prompt: r.owner, purpose: r.purpose, reusable_parts: r.reusable, adaptation_gaps: r.deltas });
  });
  var manifest = {
    generated_by: 'scripts/v2-sync.js',
    rule: 'نسخ حرفي بلا تعديل؛ أي تعديل يُنفَّذ في طبقة تكييف خارج هذا المجلد أو بقرار موثق يحدّث البصمة هنا (tests/v2/legacy-parity.test.js يمنع الانجراف الصامت)',
    files: files,
    excluded: EXCLUDED
  };
  out[path.join(DST, 'MANIFEST.json')] = Buffer.from(JSON.stringify(manifest, null, 2) + '\n', 'utf8');
  out[CSS] = Buffer.from(tokensCss(), 'utf8');
  return out;
}

function tokensCss() {
  var T = require(path.join(ROOT, 'tests', 'ui', 'ui-map-v2.js')).TOKENS;
  function block(sel, o) { return sel + '{\n' + Object.keys(o).map(function (k) { return '  --' + k + ': ' + o[k] + ';'; }).join('\n') + '\n}\n'; }
  return '/* مولَّد بـscripts/v2-sync.js من tests/ui/ui-map-v2.js (TOKENS) — لا تعدّله يدوياً. UI-MAP-V2 §9-ب.\n' +
    ' * «تلقائي» = بلا data-theme فيتبع الجهاز؛ «فاتح/داكن» = data-theme على الجذر (يُحفظ في marsa.v2.ui). */\n' +
    block(':root', T.light) + ':root{color-scheme:light dark}\n' +
    '@media (prefers-color-scheme:dark){\n' + block(':root:not([data-theme="light"])', T.dark).replace(/^/gm, '  ') + '}\n' +
    ':root[data-theme="light"]{color-scheme:light}\n' +
    block(':root[data-theme="dark"]', T.dark) + ':root[data-theme="dark"]{color-scheme:dark}\n';
}

function main() {
  var check = process.argv.indexOf('--check') > -1, outs = buildOutputs(), bad = [], p;
  Object.keys(outs).forEach(function (f) {
    var cur = fs.existsSync(f) ? fs.readFileSync(f) : null;
    if (!cur || !cur.equals(outs[f])) bad.push(path.relative(ROOT, f));
  });
  if (check) {
    if (bad.length) { console.log('FAIL v2-sync --check: غير مطابق: ' + bad.join(', ')); process.exit(1); }
    console.log('OK v2-sync --check: ' + Object.keys(outs).length + ' ملفاً مطابقاً'); return;
  }
  Object.keys(outs).forEach(function (f) { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, outs[f]); });
  console.log('كُتب ' + Object.keys(outs).length + ' ملفاً؛ المتغيّر: ' + (bad.length ? bad.join(', ') : 'لا شيء'));
}
if (require.main === module) main();
module.exports = { REUSE: REUSE, EXCLUDED: EXCLUDED, buildOutputs: buildOutputs, tokensCss: tokensCss };
