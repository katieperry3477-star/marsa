/* MARSA V1 — التخزين المحلي لـ«التحاضير بالكود»
 * مفاتيح جديدة مستقلة تماماً عن مفاتيح التطبيق الكامل (marsa.academic.* وغيرها) فلا تلمس أي بيانات سابقة:
 *   marsa.v1.mine   تحاضير أنشأها الممثل على هذا الجهاز
 *   marsa.v1.saved  تحاضير استوردها الطالب بالكود («تحضيراتي»)
 *   marsa.v1.draft  مسودة نموذج الإنشاء غير المحفوظ
 *   marsa.v1.ui     تفضيلات الواجهة (الدور ورابط التطبيق للرسالة والمظهر وعلم «تمّ الترحيب»)
 *   marsa.v1.demo   بيانات تجريبية اصطناعية لشاشات اليوم/باچر/الامتحان (01.03) — مفتاح مستقل لا يمسّ mine ولا saved
 * القيمة: { schemaVersion, records }. كل كتابة: قراءة ← تعديل ← كتابة ← إعادة قراءة للتأكد؛ وعند الفشل تُعاد القيمة السابقة.
 * بيانات تالفة لا تُمسح: تُنسخ أولاً إلى مفتاح marsa.v1.backup.* ثم يبدأ القسم فارغاً (أو يُقفل إن تعذّر النسخ).
 * لاستبدال التخزين في الاختبارات: create({ storage }) بواجهة getItem/setItem/removeItem. */
(function (root, factory) {
  'use strict';
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaV1Store = api.create();
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var SCHEMA = 1;
  var K = { mine: 'marsa.v1.mine', saved: 'marsa.v1.saved', draft: 'marsa.v1.draft', ui: 'marsa.v1.ui', demo: 'marsa.v1.demo' };
  var BACKUP = 'marsa.v1.backup.';
  var MAX = { mine: 300, saved: 500 };
  var ID_RE = /^[A-Za-z0-9_-]{6,64}$/;
  var ID_ALPHABET = 'abcdefghijkmnpqrstuvwxyz23456789';
  var CONTENT_KEYS = ['subject', 'title', 'date', 'content', 'pages', 'homework', 'notes', 'group'];

  function getModel() {
    if (root && root.MarsaPrepsModel) return root.MarsaPrepsModel;
    if (typeof require === 'function') return require('./preps-model.js');
    throw new Error('preps-model.js غير محمَّل');
  }
  function getText() {
    if (root && root.MarsaV1Text) return root.MarsaV1Text;
    if (typeof require === 'function') return require('./v1-text.js');
    throw new Error('v1-text.js غير محمَّل');
  }
  function getDemo() {
    if (root && root.MarsaV1Demo) return root.MarsaV1Demo;
    if (typeof require === 'function') return require('./v1-demo.js');
    throw new Error('v1-demo.js غير محمَّل');
  }
  function isPlain(o) { return !!o && typeof o === 'object' && !Array.isArray(o); }
  function str(x) { return typeof x === 'string' ? x : ''; }

  function validRecord(r, saved) {
    var i;
    if (!isPlain(r) || typeof r.id !== 'string' || !ID_RE.test(r.id)) return false;
    for (i = 0; i < 4; i++) if (typeof r[CONTENT_KEYS[i]] !== 'string') return false;
    for (i = 4; i < CONTENT_KEYS.length; i++) if (r[CONTENT_KEYS[i]] !== undefined && typeof r[CONTENT_KEYS[i]] !== 'string') return false;
    if (saved && (typeof r.sourceUpdatedAt !== 'number' || !isFinite(r.sourceUpdatedAt))) return false;
    return true;
  }
  function sameContent(a, b) {
    var i;
    for (i = 0; i < CONTENT_KEYS.length; i++) if (str(a[CONTENT_KEYS[i]]) !== str(b[CONTENT_KEYS[i]])) return false;
    return true;
  }
  function pick(src) { // ينسخ حقول المحتوى فقط (لا حقول زائدة من مصدر غير موثوق)
    var o = {}, i, k;
    for (i = 0; i < CONTENT_KEYS.length; i++) { k = CONTENT_KEYS[i]; if (typeof src[k] === 'string' && (i < 4 || src[k])) o[k] = src[k]; }
    return o;
  }

  function create(opts) {
    opts = opts || {};
    var backend = opts.storage !== undefined ? opts.storage : null, memory = {}, memoryMode = false, handled = {}, locked = {}, notices = [];
    var now = opts.now || function () { return new Date().getTime(); };

    if (opts.storage === undefined) { try { backend = typeof localStorage !== 'undefined' ? localStorage : null; } catch (e) { backend = null; } }
    if (backend) { try { backend.setItem('marsa.v1.probe', '1'); backend.removeItem('marsa.v1.probe'); } catch (e2) { backend = null; } }
    if (!backend) {
      memoryMode = true;
      notices.push('تعذّر الوصول إلى تخزين المتصفح (قد يكون وضع التصفح الخاص). تعمل الصفحة، لكن ما تضيفه سيُفقد عند إغلاقها.');
    }

    function rawGet(k) { if (memoryMode) return memory[k] === undefined ? null : memory[k]; return backend.getItem(k); }
    function rawSet(k, v) { if (memoryMode) memory[k] = v; else backend.setItem(k, v); }
    function rawRemove(k) { if (memoryMode) delete memory[k]; else backend.removeItem(k); }
    function note(msg) { if (notices.indexOf(msg) < 0) notices.push(msg); }
    function iso() { return new Date(now()).toISOString(); }

    function backupOf(name, raw) {
      try { rawSet(BACKUP + name + '.' + now(), raw); return true; } catch (e) { return false; }
    }

    // يُرجع { records, locked } ولا يرمي أبداً
    function load(name) {
      var key = K[name], raw, data, out = [], bad = 0, i, label = name === 'mine' ? 'تحاضير أنشأتها' : 'تحضيراتي';
      try { raw = rawGet(key); } catch (e) { locked[name] = 'تعذّرت قراءة تخزين المتصفح، فلم يُعدَّل شيء.'; return { records: [], locked: locked[name] }; }
      if (raw === null || raw === undefined || raw === '') { delete locked[name]; return { records: [], raw: null }; }
      try { data = JSON.parse(raw); } catch (e2) { data = null; }
      if (!isPlain(data) || !Array.isArray(data.records) || typeof data.schemaVersion !== 'number') {
        if (handled[name] === raw) return { records: [], raw: raw, locked: locked[name] || null };
        if (backupOf(name, raw)) { handled[name] = raw; delete locked[name]; note('وُجدت بيانات «' + label + '» تالفة، فحُفظت نسخة منها احتياطياً وبدأت القائمة فارغة.'); return { records: [], raw: raw }; }
        handled[name] = raw; locked[name] = 'بيانات «' + label + '» في هذا المتصفح تالفة وتعذّر حفظ نسخة منها، لذلك لن يُكتب فوقها شيء.';
        note(locked[name]);
        return { records: [], raw: raw, locked: locked[name] };
      }
      if (data.schemaVersion > SCHEMA) {
        locked[name] = 'بيانات «' + label + '» محفوظة بإصدار أحدث من مَرسى. حدّث التطبيق؛ لم يُعدَّل شيء.';
        note(locked[name]);
        return { records: [], raw: raw, locked: locked[name] };
      }
      delete locked[name];
      for (i = 0; i < data.records.length; i++) { if (validRecord(data.records[i], name === 'saved')) out.push(data.records[i]); else bad++; }
      if (bad && handled[name] !== raw) {
        handled[name] = raw;
        if (backupOf(name, raw)) note('وُجد ' + bad + ' من السجلات التالفة في «' + label + '» فتجاهلها التطبيق، وحُفظت نسخة احتياطية من البيانات الأصلية.');
      }
      return { records: out, raw: raw };
    }

    function restore(key, prev) { try { if (prev === null || prev === undefined) rawRemove(key); else rawSet(key, prev); } catch (e) { /* لا شيء أكثر يمكن فعله */ } }

    function commit(name, records, prevRaw) {
      var key = K[name], json = JSON.stringify({ schemaVersion: SCHEMA, records: records }), back;
      if (locked[name]) return { ok: false, error: locked[name] };
      try { rawSet(key, json); back = rawGet(key); }
      catch (e) { restore(key, prevRaw); return { ok: false, error: 'تعذّر الحفظ: مساحة تخزين المتصفح ممتلئة أو غير متاحة. لم يتغيّر شيء من بياناتك المحفوظة.' }; }
      if (back !== json) { restore(key, prevRaw); return { ok: false, error: 'تعذّر التأكد من حفظ البيانات في المتصفح. لم يتغيّر شيء من بياناتك المحفوظة.' }; }
      return { ok: true };
    }

    function randomId(taken) {
      var tries = 0, id, i, bytes, c;
      do {
        bytes = new Uint8Array(12);
        c = root && root.crypto && root.crypto.getRandomValues ? root.crypto : (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.getRandomValues ? globalThis.crypto : null);
        if (c) c.getRandomValues(bytes); else for (i = 0; i < 12; i++) bytes[i] = Math.floor(Math.random() * 256);
        id = 'p';
        for (i = 0; i < 12; i++) id += ID_ALPHABET.charAt(bytes[i] % 32);
        tries++;
      } while (taken[id] && tries < 20);
      return id;
    }
    function idMap(list) { var m = {}, i; for (i = 0; i < list.length; i++) m[list[i].id] = 1; return m; }
    function find(list, id) { var i; for (i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; }

    // ===== تحاضير الممثل =====
    function validateInput(input) {
      var v = getText().validate(input || {});
      return { ok: v.ok, values: v.values, group: v.values.group || '', errors: v.errors, firstError: v.firstError };
    }

    function listMine() { return load('mine').records.slice().sort(function (a, b) { return a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0; }); }
    function getMine(id) { return find(load('mine').records, id); }

    function createMine(input) {
      var v = validateInput(input), st, rec, list;
      if (!v.ok) return { ok: false, errors: v.errors, firstError: v.firstError };
      st = load('mine'); list = st.records;
      if (st.locked) return { ok: false, error: st.locked };
      if (list.length >= MAX.mine) return { ok: false, error: 'وصلت إلى الحد الأقصى (' + MAX.mine + ' تحضيراً). احذف تحاضير قديمة ثم حاول من جديد.' };
      rec = getModel().buildRecord(v.values, null);
      if (v.group) rec.group = v.group;
      rec.id = randomId(idMap(list)); rec.createdAt = iso(); rec.updatedAt = rec.createdAt;
      list = list.concat([rec]);
      var res = commit('mine', list, st.raw);
      return res.ok ? { ok: true, record: rec } : res;
    }

    function updateMine(id, input) {
      var v = validateInput(input), st = load('mine'), cur = find(st.records, id), next, list, i, res;
      if (!v.ok) return { ok: false, errors: v.errors, firstError: v.firstError };
      if (st.locked) return { ok: false, error: st.locked };
      if (!cur) return { ok: false, error: 'لم يعد هذا التحضير موجوداً (ربما حُذف من نافذة أخرى).' };
      next = getModel().buildRecord(v.values, cur);
      if (v.group) next.group = v.group; else delete next.group;
      if (sameContent(cur, next)) return { ok: true, record: cur, unchanged: true };
      next.updatedAt = iso();
      if (next.updatedAt <= cur.updatedAt) next.updatedAt = new Date(Date.parse(cur.updatedAt) + 1).toISOString(); // يتقدّم التحديث دائماً
      list = st.records.slice();
      for (i = 0; i < list.length; i++) if (list[i].id === id) list[i] = next;
      res = commit('mine', list, st.raw);
      return res.ok ? { ok: true, record: next } : res;
    }

    function deleteMine(id) {
      var st = load('mine'), list;
      if (st.locked) return { ok: false, error: st.locked };
      if (!find(st.records, id)) return { ok: true, missing: true };
      list = st.records.filter(function (r) { return r.id !== id; });
      return commit('mine', list, st.raw);
    }

    // ===== تحضيرات الطالب (المستوردة) =====
    function listSaved() { return load('saved').records.slice(); }
    function getSaved(id) { return find(load('saved').records, id); }

    function toSaved(prep, addedAt) {
      var rec = pick(prep);
      rec.id = prep.id; rec.sourceUpdatedAt = prep.updatedAt; rec.addedAt = addedAt; rec.createdAt = addedAt; rec.updatedAt = addedAt;
      return rec;
    }

    // تصنيف بلا كتابة (للمعاينة): new | duplicate | update | older | error. نفس منطق addSaved.
    function classifySaved(prep) {
      var st = load('saved'), list = st.records, cur, i;
      if (st.locked) return { status: 'error', error: st.locked };
      cur = find(list, prep.id);
      if (cur) {
        if (sameContent(cur, prep)) return { status: 'duplicate', record: cur };
        return prep.updatedAt >= cur.sourceUpdatedAt ? { status: 'update', existing: cur } : { status: 'older', existing: cur };
      }
      for (i = 0; i < list.length; i++) if (sameContent(list[i], prep)) return { status: 'duplicate', record: list[i] };
      if (list.length >= MAX.saved) return { status: 'error', error: 'وصلت إلى الحد الأقصى (' + MAX.saved + ' تحضيراً). احذف تحاضير قديمة ثم حاول من جديد.' };
      return { status: 'new' };
    }

    // prep: ناتج MarsaV1Share.decode (ok:true).prep. لا يكتب شيئاً إلا عند status = added
    function addSaved(prep) {
      var st = load('saved'), list = st.records, cur, i, rec, res;
      if (st.locked) return { status: 'error', error: st.locked };
      cur = find(list, prep.id);
      if (cur) {
        if (sameContent(cur, prep)) return { status: 'duplicate', record: cur };
        return prep.updatedAt >= cur.sourceUpdatedAt ? { status: 'update', existing: cur, incoming: prep } : { status: 'older', existing: cur };
      }
      for (i = 0; i < list.length; i++) if (sameContent(list[i], prep)) return { status: 'duplicate', record: list[i] };
      if (list.length >= MAX.saved) return { status: 'error', error: 'وصلت إلى الحد الأقصى (' + MAX.saved + ' تحضيراً). احذف تحاضير قديمة ثم حاول من جديد.' };
      rec = toSaved(prep, iso());
      res = commit('saved', list.concat([rec]), st.raw);
      return res.ok ? { status: 'added', record: rec } : { status: 'error', error: res.error };
    }

    // استبدال نسخة موجودة بنسخة أحدث من الممثل (بعد موافقة الطالب)
    function replaceSaved(prep) {
      var st = load('saved'), cur = find(st.records, prep.id), rec, list, i, res;
      if (st.locked) return { ok: false, error: st.locked };
      if (!cur) return { ok: false, error: 'لم يعد هذا التحضير في تحضيراتك. أضفه من جديد.' };
      rec = toSaved(prep, cur.addedAt || iso()); rec.updatedAt = iso();
      list = st.records.slice();
      for (i = 0; i < list.length; i++) if (list[i].id === prep.id) list[i] = rec;
      res = commit('saved', list, st.raw);
      return res.ok ? { ok: true, record: rec } : res;
    }

    function deleteSaved(id) {
      var st = load('saved'), list;
      if (st.locked) return { ok: false, error: st.locked };
      if (!find(st.records, id)) return { ok: true, missing: true };
      list = st.records.filter(function (r) { return r.id !== id; });
      return commit('saved', list, st.raw);
    }

    // ===== المسودة وتفضيلات الواجهة (best-effort؛ لا تُعيق العمل) =====
    function readObj(key) { try { var raw = rawGet(key), d = raw ? JSON.parse(raw) : null; return isPlain(d) ? d : null; } catch (e) { return null; } }
    function writeObj(key, obj) { try { rawSet(key, JSON.stringify(obj)); return true; } catch (e) { return false; } }

    function loadDraft() {
      var d = readObj(K.draft), v, i, k, keys = ['subject', 'title', 'date', 'content', 'pages', 'homework', 'notes', 'group'];
      if (!d || d.schemaVersion !== SCHEMA || !isPlain(d.values)) return null;
      v = {};
      for (i = 0; i < keys.length; i++) { k = keys[i]; v[k] = typeof d.values[k] === 'string' ? d.values[k] : ''; }
      return { editingId: typeof d.editingId === 'string' && ID_RE.test(d.editingId) ? d.editingId : null, values: v };
    }
    function saveDraft(editingId, values) { return writeObj(K.draft, { schemaVersion: SCHEMA, editingId: editingId || null, values: values, savedAt: iso() }); }
    function clearDraft() { try { rawRemove(K.draft); } catch (e) { /* لا شيء */ } }

    function loadUi() {
      var d = readObj(K.ui) || {};
      return { mode: d.mode === 'rep' ? 'rep' : 'student', appUrl: typeof d.appUrl === 'string' ? d.appUrl.slice(0, 300) : '' };
    }
    function saveUi(ui) { var p = loadPrefs(); return writeObj(K.ui, { schemaVersion: SCHEMA, mode: ui.mode === 'rep' ? 'rep' : 'student', appUrl: typeof ui.appUrl === 'string' ? ui.appUrl.slice(0, 300) : '', theme: p.theme, welcomed: p.welcomed }); }

    // المظهر (auto|light|dark) وعلم «تمّ الترحيب» داخل marsa.v1.ui نفسه (Q-18). savePrefs تتحقق من القراءة بعد الكتابة وتعيد القيمة السابقة عند الفشل.
    function loadPrefs() { var d = readObj(K.ui) || {}; return { theme: d.theme === 'light' || d.theme === 'dark' ? d.theme : 'auto', welcomed: d.welcomed === true }; }
    function savePrefs(p) {
      var u = loadUi(), cur = loadPrefs(), t = p && p.theme !== undefined ? p.theme : cur.theme, w = p && p.welcomed !== undefined ? p.welcomed === true : cur.welcomed, prev, read = false, json;
      if (t !== 'light' && t !== 'dark') t = 'auto';
      json = JSON.stringify({ schemaVersion: SCHEMA, mode: u.mode, appUrl: u.appUrl, theme: t, welcomed: w });
      try {
        prev = rawGet(K.ui); read = true; rawSet(K.ui, json);
        if (rawGet(K.ui) !== json) { restore(K.ui, prev); return false; }
        return true;
      } catch (e) { if (read) restore(K.ui, prev); return false; }
    }

    // ===== البيانات التجريبية (مفتاح مستقل؛ لا تُكتب أي مفاتيح أخرى) =====
    function loadDemo() {
      var raw, d;
      try { raw = rawGet(K.demo); } catch (e) { return { data: null, error: 'تعذّرت قراءة البيانات التجريبية من تخزين المتصفح.' }; }
      if (raw === null || raw === undefined || raw === '') return { data: null };
      try { d = JSON.parse(raw); } catch (e2) { d = null; }
      if (!getDemo().validate(d)) return { data: null, corrupt: true, error: 'البيانات التجريبية المحفوظة تالفة أو بإصدار غير مدعوم. احذفها من الإعدادات ثم حمّلها من جديد.' };
      return { data: d };
    }
    function saveDemo(data) {
      var json, prev, read = false;
      if (!getDemo().validate(data)) return { ok: false, error: 'تعذّر تحميل البيانات التجريبية: الصيغة غير صالحة.' };
      json = JSON.stringify(data);
      try {
        prev = rawGet(K.demo); read = true; rawSet(K.demo, json);
        if (rawGet(K.demo) !== json) { restore(K.demo, prev); return { ok: false, error: 'تعذّر التأكد من حفظ البيانات التجريبية في المتصفح. لم يتغيّر شيء من تحاضيرك.' }; }
        return { ok: true };
      } catch (e) {
        if (read) restore(K.demo, prev);
        return { ok: false, error: 'تعذّر حفظ البيانات التجريبية: مساحة تخزين المتصفح ممتلئة أو غير متاحة. لم يتغيّر شيء من تحاضيرك.' };
      }
    }
    function clearDemo() {
      var back;
      try { rawRemove(K.demo); back = rawGet(K.demo); } catch (e) { return { ok: false, error: 'تعذّر حذف البيانات التجريبية من تخزين المتصفح. لم يتغيّر شيء من تحاضيرك.' }; }
      return back === null || back === undefined ? { ok: true } : { ok: false, error: 'تعذّر التأكد من حذف البيانات التجريبية. لم يتغيّر شيء من تحاضيرك.' };
    }

    function takeNotices() { var n = notices.slice(); notices.length = 0; return n; }

    // تفضيلات تالفة (JSON غير صالح): لا تكسر التطبيق؛ تعود الإعدادات الافتراضية وتُكتب قيمة سليمة عند أول حفظ
    (function checkUi() {
      var raw, d;
      try { raw = rawGet(K.ui); } catch (e) { return; }
      if (raw === null || raw === undefined || raw === '') return;
      try { d = JSON.parse(raw); } catch (e2) { d = null; }
      if (!isPlain(d)) note('تفضيلات الواجهة (الدور والمظهر) المحفوظة على هذا الجهاز تالفة، فعادت الإعدادات الافتراضية.');
    })();

    return {
      persistent: !memoryMode, KEYS: K, BACKUP_PREFIX: BACKUP, LIMITS: MAX,
      validateInput: validateInput,
      listMine: listMine, getMine: getMine, createMine: createMine, updateMine: updateMine, deleteMine: deleteMine,
      listSaved: listSaved, getSaved: getSaved, classifySaved: classifySaved, addSaved: addSaved, replaceSaved: replaceSaved, deleteSaved: deleteSaved,
      loadDraft: loadDraft, saveDraft: saveDraft, clearDraft: clearDraft, loadUi: loadUi, saveUi: saveUi, loadPrefs: loadPrefs, savePrefs: savePrefs,
      loadDemo: loadDemo, saveDemo: saveDemo, clearDemo: clearDemo,
      takeNotices: takeNotices
    };
  }

  return { create: create, SCHEMA: SCHEMA, KEYS: K, sameContent: sameContent };
});
