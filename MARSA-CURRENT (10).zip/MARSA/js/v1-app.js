/* MARSA V1 — واجهة «التحاضير بالكود»
 * الممثل: إنشاء ← معاينة ← حفظ ← كود مشاركة ← رسالة واتساب.   الطالب: لصق الكود ← معاينة ← إضافة ← تحضيراتي.
 * كل العرض بـ createElement وtextContent فقط (لا إدراج HTML نصي). التوجيه بـ location.hash ليعمل زر الرجوع في الهاتف.
 * المنطق في ملفات مستقلة: preps-model.js (التحقق والتنسيق)، v1-share.js (الكود)، v1-store.js (التخزين).
 * 01.03: الرئيسية ببطاقات ملخص، اليوم/باچر، الامتحان القريب، الترحيب مع اختيار الدور، الإعدادات (المظهر ثلاثي والدور والبيانات التجريبية)،
 * وشريط تنقل (سفلي على الهاتف / جانبي يميناً من 1024). الانترو في v1-boot.js، والبيانات الاصطناعية في v1-demo.js بمفتاح مستقل. */
(function () {
  'use strict';
  var M = window.MarsaPrepsModel, S = window.MarsaV1Share, ST = window.MarsaV1Store, T = window.MarsaSafeText, D = window.MarsaV1Demo;
  var app = document.getElementById('app'), statusEl = document.getElementById('status'), dlg = document.getElementById('dlg'), dlgBody = document.getElementById('dlg-body');
  var root = document.documentElement, NS = 'http://www.w3.org/2000/svg';
  if (!M || !S || !ST || !T || !D) {
    var bad = document.createElement('p'); bad.className = 'note err';
    bad.textContent = 'تعذّر تحميل ملفات التطبيق. أعد تحميل الصفحة وتأكد أن مجلد js كامل بجانب index.html.';
    app.appendChild(bad); return;
  }

  var ui = ST.loadUi(), prefs = ST.loadPrefs();
  var state = { preview: null, justSaved: null, demoErr: '' };
  var navEl = document.getElementById('nav'), navLinks = {}, navNow = '';
  var renderToken = 0, sayTimer = 0;
  var REP_ROUTES = { 'new': 1, edit: 1, preview: 1, mine: 1, share: 1 };
  var SHARED_ROUTES = { home: 1, day: 1, exam: 1, settings: 1, about: 1, welcome: 1 }; // مشتركة بين الدورين: لا تغيّر الدور
  var TOP_ROUTES = { home: 1, day: 1, saved: 1, mine: 1, exam: 1, settings: 1 };         // مستوى أعلى: يظهر لها الشريط السفلي على الهاتف
  var DIRECTIONAL = { back: 1, fwd: 1 };                                                   // أسهم تنعكس في RTL؛ بقية الأيقونات رمزية فلا تنعكس
  var ROLE_WARN = 'تبديل الدور تجريبي وغير آمن للإنتاج';
  var THEMES = [['auto', 'تلقائي'], ['light', 'فاتح'], ['dark', 'داكن']];
  var ICONS = {
    plus: 'M12 5v14M5 12h14', list: 'M5 6h14M5 12h14M5 18h9', pencil: 'M4 20l1-4L16 5l3 3L8 19zM14 7l3 3',
    back: 'M15 6l-6 6 6 6', fwd: 'M9 6l6 6-6 6', copy: 'M9 9h10v11H9zM5 15V4h10', share: 'M4 12v7h16v-7M12 15V3M8 7l4-4 4 4',
    chat: 'M4 20l1.4-4A8 8 0 1 1 8 18.6z', trash: 'M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13', check: 'M5 13l4 4 10-10', paste: 'M9 4h6v3H9zM7 6H5v14h14V6h-2M9 13h6M9 17h4',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
    clock: 'M12 7v5l3 2M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z', home: 'M4 11l8-7 8 7M6 10v10h12V10M10 20v-5h4v5', day: 'M5 5h14v15H5zM5 10h14M9 3v4M15 3v4', book: 'M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11',
    sliders: 'M5 7h9M18 7h1M5 17h1M10 17h9M14 5v4M8 15v4', exam: 'M9 4h6v3H9zM7 6H5v15h14V6h-2M9 14l2 2 4-4', info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5v.5'
  };

  // ===== أدوات صغيرة =====
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function icon(name, cls) {
    var s = document.createElementNS(NS, 'svg'), p = document.createElementNS(NS, 'path'), c = (DIRECTIONAL[name] ? 'dir ' : '') + (cls || '');
    if (c.trim()) s.setAttribute('class', c.trim());
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '2');
    s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false');
    p.setAttribute('d', ICONS[name]); s.appendChild(p); return s;
  }
  function button(cls, text, fn, ic) {
    var b = el('button', 'btn ' + cls); b.type = 'button';
    if (ic) b.appendChild(icon(ic));
    b.appendChild(document.createTextNode(text));
    if (fn) b.addEventListener('click', fn);
    return b;
  }
  function linkBtn(cls, text, href, ic) {
    var a = el('a', 'btn ' + cls); a.href = href;
    if (ic) a.appendChild(icon(ic));
    a.appendChild(document.createTextNode(text));
    return a;
  }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function todayStr() { var d = new Date(); return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
  function dateBadge(date) {
    var t = todayStr();
    if (date === t) return { text: 'اليوم', cls: 'badge today' };
    if (date === M.addDays(t, 1)) return { text: 'غداً', cls: 'badge today' };
    return null;
  }
  function snippet(text) { var s = String(text || '').replace(/\s+/g, ' ').trim(); return s.length > 140 ? s.slice(0, 140) + '…' : s; }
  function say(msg, ms) {
    clearTimeout(sayTimer); statusEl.classList.remove('on'); statusEl.textContent = '';
    setTimeout(function () { statusEl.textContent = msg; statusEl.classList.add('on'); }, 20);
    sayTimer = setTimeout(function () { statusEl.classList.remove('on'); }, ms || 3500);
  }
  function note(kind, title, text, role) {
    var n = el('div', 'note ' + kind);
    if (role) n.setAttribute('role', role);
    if (title) n.appendChild(el('strong', null, title));
    if (text) n.appendChild(el('p', null, text));
    return n;
  }

  function applyTheme(t) { if (t === 'light' || t === 'dark') root.setAttribute('data-theme', t); else root.removeAttribute('data-theme'); }
  function roleName(m) { return m === 'rep' ? 'ممثل الصف' : 'طالب'; }
  function roleSwitchMsg(m) { return 'تم التبديل إلى وضع ' + roleName(m) + '. ' + ROLE_WARN + '.'; }

  // ===== نسخ ولصق =====
  function copyText(text, sel, okMsg) {
    function manual() {
      if (sel) { try { sel.focus(); sel.select(); sel.setSelectionRange(0, sel.value.length); } catch (e) { /* لا شيء */ } }
      say('تعذّر النسخ تلقائياً. النص محدّد الآن، انسخه يدوياً.', 6000);
    }
    function legacy() {
      var ta = document.createElement('textarea'), ok = false;
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:0;inset-inline-start:0;opacity:0;';
      document.body.appendChild(ta); ta.select();
      try { ta.setSelectionRange(0, text.length); ok = document.execCommand('copy'); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      return ok;
    }
    if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () { say(okMsg); }, function () { if (legacy()) say(okMsg); else manual(); });
    } else if (legacy()) say(okMsg); else manual();
  }

  // ===== نافذة تأكيد =====
  function openDlg() { if (dlg.showModal) { if (!dlg.open) dlg.showModal(); } else dlg.setAttribute('open', ''); }
  function closeDlg() { if (dlg.close) dlg.close(); else dlg.removeAttribute('open'); }
  function dlgFrame(title) {
    dlgBody.textContent = '';
    var h = el('h2', null, title); h.id = 'dlg-t'; h.tabIndex = -1; dlgBody.appendChild(h);
    return h;
  }
  function confirmDlg(o) {
    var h = dlgFrame(o.title), row = el('div', 'row'), trigger = document.activeElement;
    dlgBody.appendChild(el('p', null, o.text));
    row.appendChild(button(o.danger ? 'danger' : 'primary', o.okLabel, function () { closeDlg(); o.onOk(); }));
    row.appendChild(button('', 'إلغاء', function () { closeDlg(); }));
    dlgBody.appendChild(row);
    dlg.addEventListener('close', function back() { dlg.removeEventListener('close', back); if (trigger && trigger.focus && document.contains(trigger)) trigger.focus(); });
    openDlg(); h.focus();
  }
  function openHow() {
    var h = dlgFrame('كيف تعمل المشاركة بالكود؟'), ol = el('ol'), ul = el('ul'), row = el('div', 'row');
    ['ينشئ الممثل التحضير ويحفظه، فيُولّد مَرسى كوداً يحمل التحضير كاملاً.', 'يرسل الممثل الكود (أو الرسالة الجاهزة) إلى مجموعة الواتساب.', 'يلصق الطالب الكود في «إضافة تحضير»، فيُحفظ التحضير على جهازه ويقرؤه حتى بلا إنترنت.'].forEach(function (t) { ol.appendChild(el('li', null, t)); });
    dlgBody.appendChild(ol);
    ['الكود يحمل نص التحضير نفسه، فيطول بطول التحضير. التحضير القصير كود قصير، والطويل كود طويل.', 'لا يوجد خادم ولا حسابات ولا مزامنة: التحضير يصل بالكود فقط.', 'إذا عدّل الممثل تحضيراً بعد إرساله فلا يصل التعديل إلا بإرسال الكود الجديد.', 'مسح بيانات المتصفح يحذف التحاضير المحفوظة على ذلك الجهاز.'].forEach(function (t) { ul.appendChild(el('li', null, t)); });
    dlgBody.appendChild(ul);
    row.appendChild(button('primary', 'حسناً', function () { closeDlg(); }));
    dlgBody.appendChild(row);
    openDlg(); h.focus();
  }

  // ===== هيكل الصفحة =====
  function backLink(href, text) {
    var a = el('a', 'back'); a.href = href; a.appendChild(icon('back')); a.appendChild(document.createTextNode(text || 'رجوع')); return a;
  }
  function begin(title, lead, backHref, backText) {
    var h = el('h1', null, title);
    app.textContent = '';
    if (backHref) app.appendChild(backLink(backHref, backText));
    h.tabIndex = -1; app.appendChild(h);
    if (lead) app.appendChild(el('p', 'lead', lead));
    ST.takeNotices().forEach(function (n) { var x = note('warn', null, n); x.style.marginBottom = '12px'; app.appendChild(x); });
    return h;
  }
  function tile(href, cls, ic, title, sub, count) {
    var a = el('a', 'tile ' + cls), i = el('span', 'ic'), t = el('span');
    a.href = href; i.appendChild(icon(ic)); a.appendChild(i);
    t.appendChild(el('b', null, title)); t.appendChild(el('small', null, sub)); a.appendChild(t);
    if (count != null) a.appendChild(el('span', 'count', String(count)));
    return a;
  }
  function notFound(backHref, backText, title, text) {
    begin('غير موجود', null, backHref, backText);
    app.appendChild(note('warn', title || 'لم يعد هذا التحضير موجوداً', text || 'ربما حُذف، أو فُتح الرابط على جهاز آخر.'));
  }

  // عرض التحضير للقراءة. p: { subject, title, date, content, pages?, homework?, notes?, group? }
  function rich(text) {
    var p = el('p', 'body');
    T.segments(text).forEach(function (seg) {
      var a;
      if (seg.href) { a = el('a', null, seg.text); a.href = seg.href; a.target = '_blank'; a.rel = 'noopener noreferrer'; p.appendChild(a); }
      else p.appendChild(document.createTextNode(seg.text));
    });
    return p;
  }
  function prepView(p, extraMeta) {
    var art = el('article', 'prep'), meta = el('div', 'meta'), b = dateBadge(p.date);
    meta.appendChild(el('span', 'badge', p.subject));
    if (p.group) meta.appendChild(el('span', null, p.group));
    meta.appendChild(el('span', null, M.formatDate(p.date)));
    if (b) meta.appendChild(el('span', b.cls, b.text));
    art.appendChild(meta);
    art.appendChild(el('h2', null, p.title));
    art.appendChild(rich(p.content));
    [['homework', 'الواجب'], ['pages', 'صفحات الكتاب / المصدر'], ['notes', 'ملاحظات']].forEach(function (s) {
      if (p[s[0]]) { art.appendChild(el('h3', null, s[1])); art.appendChild(rich(p[s[0]])); }
    });
    if (extraMeta) art.appendChild(el('p', 'foot-meta', extraMeta));
    return art;
  }
  function addedLine(rec) {
    var d = new Date(rec.addedAt);
    return isNaN(d.getTime()) ? '' : 'أُضيف إلى تحضيراتي في ' + M.formatDate(d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()));
  }
  function codecPrep(rec) {
    var o = { id: rec.id, subject: rec.subject, title: rec.title, date: rec.date, content: rec.content, updatedAt: Date.parse(rec.updatedAt) || 0 };
    ['pages', 'homework', 'notes', 'group'].forEach(function (k) { if (rec[k]) o[k] = rec[k]; });
    return o;
  }

  // ===== الصفحة الرئيسية =====
  function ownList() { return ui.mode === 'rep' ? ST.listMine() : ST.listSaved(); }
  function dayCounts(data, own, ymd) {
    var preps = own.filter(function (r) { return r.date === ymd; });
    return { lessons: D.lessonsOn(data, ymd).length, preps: preps.length, homework: preps.filter(function (r) { return r.homework && String(r.homework).trim(); }).length };
  }
  function summaryCard(href, ic, title, sub, demoOn) {
    var a = el('a', 'scard'), i = el('span', 'ic'), t = el('span', 'tx'), b = el('b', null, title);
    a.href = href; i.appendChild(icon(ic)); a.appendChild(i);
    if (demoOn) b.appendChild(el('span', 'demo-tag', 'تجريبي'));
    t.appendChild(b); t.appendChild(el('small', null, sub)); a.appendChild(t); a.appendChild(icon('fwd', 'go'));
    return a;
  }
  function renderHome() {
    var rep = ui.mode === 'rep', box = el('div', 'stack'), cards = el('div', 'cards3'), draft, demo = ST.loadDemo(), data = demo.data, own = ownList(), today = todayStr(), g = D.examGroups(data, today), nx = g.nearest;
    begin('أهلاً بك في مَرسى', D.greeting(new Date().getHours()) + ' · ' + D.shortDate(today));
    app.className = 'page wide';
    cards.appendChild(summaryCard('#/day', 'day', 'اليوم', D.summaryText(dayCounts(data, own, today), 'لا شيء اليوم'), !!data));
    cards.appendChild(summaryCard('#/day/tomorrow', 'clock', 'باچر', D.summaryText(dayCounts(data, own, M.addDays(today, 1)), 'لا شيء باچر'), !!data));
    cards.appendChild(summaryCard('#/exam', 'exam', 'أقرب امتحان', nx ? nx.subject + ' · ' + D.daysLabel(D.daysBetween(today, nx.date)) : 'لا امتحانات قادمة', !!data));
    app.appendChild(cards);
    if (rep) {
      box.appendChild(tile('#/new', 'primary', 'plus', 'إنشاء تحضير', 'اكتب التحضير واحصل على كود المشاركة'));
      box.appendChild(tile('#/mine', '', 'list', 'تحاضير أنشأتها', 'أعد نسخ الكود أو الرسالة', ST.listMine().length));
      draft = ST.loadDraft();
      if (draft) {
        var d = note('', 'لديك مسودة تحضير غير مكتملة', null), a = el('a', 'linkbtn', 'متابعة المسودة');
        a.href = draft.editingId ? '#/edit/' + draft.editingId : '#/new'; d.appendChild(a); box.appendChild(d);
      }
    } else {
      box.appendChild(tile('#/add', 'primary', 'plus', 'إضافة تحضير', 'الصق الكود الذي وصلك'));
      box.appendChild(tile('#/saved', '', 'list', 'تحضيراتي', 'اقرأ التحاضير المحفوظة', ST.listSaved().length));
    }
    if (demo.corrupt) {
      var bad = note('warn', null, demo.error), fix = el('a', 'linkbtn', 'فتح الإعدادات'); fix.href = '#/settings'; bad.appendChild(fix); box.appendChild(bad);
    } else if (data) {
      box.appendChild(el('p', 'hint', 'البطاقات أعلاه تعرض بيانات تجريبية اصطناعية، وليست جدولك الحقيقي. يمكنك حذفها من الإعدادات.'));
    } else {
      var none = note('', 'لا جدول ولا امتحانات بعد', 'تظهر هنا حين تتوفر بيانات. يمكنك تجربة الشاشات ببيانات تجريبية اصطناعية من الإعدادات.'), go = el('a', 'linkbtn', 'فتح الإعدادات');
      go.href = '#/settings'; none.appendChild(go); box.appendChild(none);
    }
    app.appendChild(box);
  }

  // ===== الممثل: نموذج الإنشاء والتعديل =====
  function blankValues() { return { subject: '', title: '', date: '', content: '', pages: '', homework: '', notes: '', group: '' }; }
  function valuesOf(rec) { var v = blankValues(), k; for (k in v) v[k] = typeof rec[k] === 'string' ? rec[k] : ''; return v; }
  function isBlank(v) { return !v.subject.trim() && !v.title.trim() && !v.content.trim() && !v.pages.trim() && !v.homework.trim() && !v.notes.trim() && !v.group.trim(); }

  function renderForm(editId) {
    var rec = null, draft = ST.loadDraft(), vals = blankValues(), restored = false, form = el('form', 'stack'), inputs = {}, errs = {}, timer = 0, more = el('details', 'more'), counter;
    if (editId) { rec = ST.getMine(editId); if (!rec) return notFound('#/mine', 'تحاضير أنشأتها'); vals = valuesOf(rec); }
    if (draft && draft.editingId === (editId || null)) { vals = draft.values; restored = true; }
    else if (!rec) vals.date = todayStr();
    begin(editId ? 'تعديل التحضير' : 'إنشاء تحضير', editId ? 'عدّل ما تريد، ثم عاين التحضير واحفظه.' : 'اكتب التحضير ثم اضغط «معاينة التحضير». تُحفظ مسودتك تلقائياً على جهازك.', editId ? '#/mine' : '#/', editId ? 'تحاضير أنشأتها' : 'الرئيسية');
    form.noValidate = true;

    function field(parent, o) {
      var wrap = el('div', 'f'), id = 'f-' + o.key, lab = el('label', null, o.label), err = el('p', 'err'), inp = o.area ? el('textarea', 'field' + (o.short ? ' short' : '')) : el('input', 'field'), hintId = '';
      lab.htmlFor = id;
      if (o.optional) lab.appendChild(el('span', 'opt', ' (اختياري)'));
      if (!o.area) inp.type = o.type || 'text';
      inp.id = id; inp.name = o.key; inp.value = vals[o.key] || ''; inp.setAttribute('dir', o.type === 'date' ? 'ltr' : 'auto'); inp.autocomplete = 'off';
      if (o.list) inp.setAttribute('list', o.list);
      err.id = id + '-err';
      wrap.appendChild(lab); wrap.appendChild(inp);
      if (o.hint) { var h = el('p', 'hint', o.hint); h.id = id + '-hint'; hintId = h.id + ' '; wrap.appendChild(h); }
      inp.setAttribute('aria-describedby', hintId + err.id);
      wrap.appendChild(err); parent.appendChild(wrap);
      inputs[o.key] = inp; errs[o.key] = err;
      inp.addEventListener('input', function () { err.textContent = ''; inp.removeAttribute('aria-invalid'); schedule(); });
      return wrap;
    }
    function collect() { var v = {}, k; for (k in inputs) v[k] = inputs[k].value; return v; }
    function persist() { var v = collect(); if (isBlank(v)) ST.clearDraft(); else ST.saveDraft(editId || null, v); }
    function schedule() { clearTimeout(timer); timer = setTimeout(persist, 300); drawCounter(); }
    function drawCounter() {
      var n = inputs.content.value.length, max = M.LIMITS.content;
      counter.textContent = n + ' / ' + max; counter.className = 'counter' + (n > max ? ' over' : '');
    }

    var subjects = M.subjectsOf(ST.listMine()), dl = el('datalist');
    dl.id = 'subjects';
    subjects.forEach(function (s) { var o = el('option'); o.value = s; dl.appendChild(o); });
    if (subjects.length) form.appendChild(dl);
    field(form, { key: 'subject', label: 'المادة', list: subjects.length ? 'subjects' : null });
    field(form, { key: 'title', label: 'عنوان الدرس' });
    field(form, { key: 'date', label: 'تاريخ التحضير', type: 'date' });
    field(form, { key: 'content', label: 'محتوى التحضير', area: true });
    counter = el('span', 'counter'); form.lastChild.insertBefore(counter, form.lastChild.lastChild);
    field(form, { key: 'homework', label: 'الواجب', area: true, short: true, optional: true });
    more.appendChild(el('summary', null, 'إضافات اختيارية (الصف أو الشعبة، الصفحات، ملاحظات)'));
    var inner = el('div', 'stack');
    field(inner, { key: 'group', label: 'الصف أو الشعبة', optional: true, hint: 'مثال: الخامس العلمي — ب. يظهر في الرسالة وعند الطالب.' });
    field(inner, { key: 'pages', label: 'صفحات الكتاب أو المصدر', optional: true });
    field(inner, { key: 'notes', label: 'ملاحظات', area: true, short: true, optional: true });
    more.appendChild(inner); form.appendChild(more);
    if (vals.group || vals.pages || vals.notes) more.open = true;
    drawCounter();

    var acts = el('div', 'row');
    acts.appendChild((function () { var b = button('primary', 'معاينة التحضير', null, 'eye'); b.type = 'submit'; return b; })());
    if (editId) acts.appendChild(linkBtn('', 'إلغاء', '#/mine'));
    else acts.appendChild(button('', 'مسح الحقول', function () {
      if (isBlank(collect())) return;
      confirmDlg({ title: 'مسح الحقول؟', text: 'سيُحذف كل ما كتبته في هذا النموذج ولن يمكن استرجاعه.', okLabel: 'مسح', danger: true, onOk: function () { ST.clearDraft(); renderForm(null); say('مُسحت الحقول.'); } });
    }));
    form.appendChild(acts);

    form.addEventListener('submit', function (ev) {
      var v = collect(), r, k, first = null, order = ['subject', 'title', 'date', 'content', 'homework', 'group', 'pages', 'notes'], i, pv = {};
      ev.preventDefault();
      clearTimeout(timer); persist();
      r = ST.validateInput(v);
      for (k in errs) { errs[k].textContent = ''; inputs[k].removeAttribute('aria-invalid'); }
      if (!r.ok) {
        for (i = 0; i < order.length; i++) if (r.errors[order[i]]) { errs[order[i]].textContent = r.errors[order[i]]; inputs[order[i]].setAttribute('aria-invalid', 'true'); if (!first) first = order[i]; }
        if (first === 'group' || first === 'pages' || first === 'notes') more.open = true;
        inputs[first].focus(); say('راجع الحقول المحددة بالأحمر ثم أعد المحاولة.', 5000);
        return;
      }
      for (k in r.values) pv[k] = r.values[k];
      if (r.group) pv.group = r.group;
      state.preview = { editId: editId || null, values: pv };
      nav('preview');
    });

    app.appendChild(form);
    if (restored && !state.preview) say('استُرجعت مسودتك غير المكتملة.');
  }

  function renderPreview() {
    var pv = state.preview, acts = el('div', 'row sticky-actions'), box = el('div', 'stack'), msg = el('div');
    if (!pv) { nav('new', true); return; }
    begin('معاينة التحضير', 'هكذا سيراه الطالب. راجعه ثم احفظه لإنشاء كود المشاركة.', pv.editId ? '#/edit/' + pv.editId : '#/new', 'تعديل');
    box.appendChild(prepView(pv.values));
    box.appendChild(msg);
    acts.appendChild(button('primary', pv.editId ? 'حفظ التعديل وإنشاء الكود' : 'حفظ وإنشاء الكود', function () {
      var res = pv.editId ? ST.updateMine(pv.editId, pv.values) : ST.createMine(pv.values);
      msg.textContent = '';
      if (!res.ok) {
        if (res.errors) { nav(pv.editId ? 'edit/' + pv.editId : 'new'); return; }
        msg.appendChild(note('err', 'تعذّر الحفظ', res.error, 'alert')); return;
      }
      ST.clearDraft(); state.preview = null;
      state.justSaved = { id: res.record.id, edited: !!pv.editId, unchanged: !!res.unchanged };
      say(pv.editId ? 'حُفظ التعديل.' : 'حُفظ التحضير على جهازك.');
      nav('share/' + res.record.id);
    }, 'check'));
    acts.appendChild(linkBtn('', 'تعديل', pv.editId ? '#/edit/' + pv.editId : '#/new', 'pencil'));
    box.appendChild(acts);
    app.appendChild(box);
  }

  // ===== الممثل: الكود والرسالة =====
  function autoUrl() {
    if (!/^https?:$/.test(location.protocol)) return '';
    return location.href.split('#')[0].split('?')[0].replace(/index\.html$/, '');
  }

  function renderShare(id) {
    var rec = ST.getMine(id), token = ++renderToken, js = state.justSaved, h, wrap = el('div', 'stack'), wait = el('p', 'note', 'جارٍ تجهيز الكود…');
    state.justSaved = null;
    if (!rec) return notFound('#/mine', 'تحاضير أنشأتها');
    h = begin(js ? 'تم حفظ التحضير' : 'الكود والرسالة', 'أرسل الرسالة إلى مجموعة واتساب الصف، أو انسخ الكود وحده.', '#/mine', 'تحاضير أنشأتها');
    if (js && js.edited && !js.unchanged) app.appendChild(note('ok', 'حُفظ التعديل', 'أرسل الكود الجديد. الطالب الذي أضاف النسخة السابقة سيُسأل إن كان يريد تحديثها.'));
    if (js && js.unchanged) app.appendChild(note('', 'لم يتغيّر شيء في التحضير', 'الكود نفسه كما هو، فلا حاجة لإرساله من جديد.'));
    app.appendChild(wait);
    S.encode(codecPrep(rec)).then(function (enc) {
      if (token !== renderToken) return;
      app.removeChild(wait);
      var panels = sharePanels(rec, enc);
      wrap.appendChild(panels);
      app.appendChild(wrap);
      panels.fit();
    }, function (err) {
      if (token !== renderToken) return;
      wait.className = 'note err'; wait.setAttribute('role', 'alert');
      wait.textContent = 'تعذّر إنشاء الكود: ' + (err && err.message ? err.message : 'خطأ غير متوقع') + '. اختصر التحضير ثم أعد المحاولة.';
    });
    return h;
  }

  function sharePanels(rec, enc) {
    var box = el('div', 'stack'), prep = codecPrep(rec), code = enc.code, urlIn, urlErr = el('p', 'err'), msgTa, wa = el('a', 'btn'), waHint = el('p', 'hint'), tools = el('div', 'row');
    var head = el('div', 'meta'), canShare = typeof navigator.share === 'function', codeTa = el('textarea', 'codebox'), cl = rec.group ? rec.group + ' — ' : '';

    var summary = el('div', 'card');
    head.appendChild(el('span', 'badge', rec.subject)); head.appendChild(el('span', null, cl + M.formatDate(rec.date)));
    summary.appendChild(head); summary.appendChild(el('h3', null, rec.title));
    box.appendChild(summary);

    box.appendChild(el('h2', 'sec-t', 'كود المشاركة'));
    codeTa.readOnly = true; codeTa.value = code; codeTa.rows = 5; codeTa.setAttribute('dir', 'ltr'); codeTa.setAttribute('aria-label', 'كود المشاركة');
    codeTa.addEventListener('focus', function () { codeTa.select(); });
    box.appendChild(codeTa);
    box.appendChild(el('p', 'hint', 'طول الكود: ' + code.length + ' حرفاً' + (enc.method === 0 ? '، بلا ضغط لأن هذا المتصفح لا يدعم الضغط المدمج' : '') + '. كلما طال التحضير طال الكود.'));
    if (code.length > 3000) box.appendChild(note('warn', 'الكود طويل', 'أرسله في رسالة واحدة كما هو ولا تقسّمه إلى عدة رسائل، وتأكد أن الطالب ينسخه كاملاً. اختصار التحضير يقصّر الكود.'));
    box.appendChild(button('', 'نسخ الكود', function () { copyText(code, codeTa, 'تم نسخ الكود.'); }, 'copy'));

    box.appendChild(el('h2', 'sec-t', 'رسالة واتساب'));
    var f = el('div', 'f'), lab = el('label', null, 'رابط التطبيق في الرسالة'), hint = el('p', 'hint', 'اختياري: إن وضعته فتح الطلاب مَرسى منه مباشرة.');
    urlIn = el('input', 'field'); urlIn.type = 'url'; urlIn.id = 'app-url'; urlIn.setAttribute('dir', 'ltr'); urlIn.placeholder = 'https://…'; urlIn.autocomplete = 'off'; lab.htmlFor = 'app-url';
    urlIn.value = ui.appUrl || autoUrl(); urlErr.id = 'app-url-err'; urlIn.setAttribute('aria-describedby', 'app-url-hint app-url-err'); hint.id = 'app-url-hint';
    f.appendChild(lab); f.appendChild(urlIn); f.appendChild(hint); f.appendChild(urlErr); box.appendChild(f);

    msgTa = el('textarea', 'codebox msg'); msgTa.readOnly = true; msgTa.rows = 11; msgTa.setAttribute('aria-label', 'نص رسالة واتساب');
    msgTa.addEventListener('focus', function () { msgTa.select(); });
    box.appendChild(msgTa);

    function urlValue() {
      var v = urlIn.value.trim(), ok;
      urlErr.textContent = '';
      if (!v) return '';
      ok = T.safeHref(v);
      if (!ok) { urlErr.textContent = 'الرابط غير صالح. اكتب رابطاً كاملاً يبدأ بـ https:// أو اتركه فارغاً.'; return ''; }
      return ok;
    }
    function drawMessage() {
      var msg = S.buildMessage(prep, code, urlValue()), href = 'https://wa.me/?text=' + encodeURIComponent(msg);
      msgTa.value = msg;
      if (href.length > 7000) { wa.hidden = true; waHint.textContent = 'الرسالة طويلة على رابط واتساب. استخدم «نسخ الرسالة» ثم الصقها في المجموعة.'; }
      else { wa.hidden = false; wa.href = href; waHint.textContent = ''; }
      return msg;
    }
    urlIn.addEventListener('change', function () { var ok = urlValue(); ui.appUrl = ok; ST.saveUi(ui); drawMessage(); });

    wa.target = '_blank'; wa.rel = 'noopener noreferrer'; wa.appendChild(icon('chat')); wa.appendChild(document.createTextNode('فتح واتساب'));
    var shareBtn = canShare ? button('primary', 'مشاركة الرسالة', function () {
      navigator.share({ text: drawMessage() }).catch(function (e) { if (!e || e.name !== 'AbortError') say('تعذّرت المشاركة من هذا المتصفح. انسخ الرسالة والصقها في واتساب.', 6000); });
    }, 'share') : null;
    wa.className = 'btn' + (canShare ? '' : ' primary');
    if (shareBtn) tools.appendChild(shareBtn);
    tools.appendChild(wa);
    tools.appendChild(button('', 'نسخ الرسالة', function () { copyText(drawMessage(), msgTa, 'تم نسخ الرسالة.'); }, 'copy'));
    box.appendChild(tools); box.appendChild(waHint);
    drawMessage();
    // يتمدد مربعا الكود والرسالة ليظهر محتواهما كاملاً (بحد أقصى 60% من ارتفاع الشاشة ثم يُمرَّر داخلياً)
    function fit(ta) { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight + 6, Math.round(window.innerHeight * 0.6)) + 'px'; }
    box.fit = function () { fit(codeTa); fit(msgTa); };
    urlIn.addEventListener('change', box.fit);

    var nxt = el('div', 'row');
    nxt.appendChild(linkBtn('', 'تحاضير أنشأتها', '#/mine', 'list'));
    nxt.appendChild(linkBtn('', 'إنشاء تحضير آخر', '#/new', 'plus'));
    box.appendChild(nxt);
    return box;
  }

  // ===== الممثل: قائمة تحاضيره =====
  function renderMine() {
    var list = ST.listMine(), ul = el('ul', 'list'), sorted = M.sortRecords(list, todayStr());
    begin('تحاضير أنشأتها', list.length ? 'افتح تحضيراً لإعادة نسخ الكود أو الرسالة.' : null, '#/', 'الرئيسية');
    if (!list.length) {
      var e = el('div', 'empty'); e.appendChild(el('strong', null, 'لم تنشئ أي تحضير بعد'));
      e.appendChild(document.createTextNode('أنشئ تحضيراً واحصل على كود تشاركه مع الطلاب.')); e.appendChild(linkBtn('primary', 'إنشاء تحضير', '#/new', 'plus')); app.appendChild(e); return;
    }
    sorted.forEach(function (r) {
      var li = el('li'), card = el('div', 'card'), meta = el('div', 'meta'), b = dateBadge(r.date), acts = el('div', 'acts');
      meta.appendChild(el('span', 'badge', r.subject));
      if (r.group) meta.appendChild(el('span', null, r.group));
      meta.appendChild(el('span', null, M.formatDate(r.date)));
      if (b) meta.appendChild(el('span', b.cls, b.text));
      card.appendChild(meta); card.appendChild(el('h3', null, r.title)); card.appendChild(el('p', 'snip', snippet(r.content)));
      acts.appendChild(linkBtn('primary sm', 'الكود والرسالة', '#/share/' + r.id, 'share'));
      acts.appendChild(linkBtn('sm', 'تعديل', '#/edit/' + r.id, 'pencil'));
      var del = button('sm danger', 'حذف', function () {
        confirmDlg({ title: 'حذف التحضير؟', text: 'سيُحذف «' + r.title + '» من تحاضيرك على هذا الجهاز. لن يُحذف من الطلاب الذين أضافوه سابقاً.', okLabel: 'حذف', danger: true, onOk: function () {
          var res = ST.deleteMine(r.id);
          if (!res.ok) { say(res.error, 6000); return; }
          say('حُذف التحضير من تحاضيرك.'); renderMine();
        } });
      }, 'trash');
      del.setAttribute('aria-label', 'حذف «' + r.title + '»'); acts.appendChild(del);
      card.appendChild(acts); li.appendChild(card); ul.appendChild(li);
    });
    app.appendChild(ul);
  }

  // ===== الطالب: إضافة تحضير بالكود =====
  function renderAdd() {
    var f = el('div', 'f'), lab = el('label', null, 'كود التحضير'), ta = el('textarea', 'field pastebox'), err = el('div'), res = el('div', 'stack'), acts = el('div', 'row'), pv;
    begin('إضافة تحضير', 'الصق الكود الذي أرسله الممثل. يمكنك لصق رسالة واتساب كاملة، والتطبيق يلتقط الكود منها.', '#/', 'الرئيسية');
    lab.htmlFor = 'code-in'; ta.id = 'code-in'; ta.setAttribute('dir', 'auto'); ta.rows = 5; ta.placeholder = 'الصق الكود هنا (يبدأ بـ MARSA1-)';
    ta.autocomplete = 'off'; ta.setAttribute('autocapitalize', 'off'); ta.spellcheck = false; ta.setAttribute('aria-describedby', 'code-err');
    err.id = 'code-err'; res.style.marginTop = '14px'; res.setAttribute('aria-live', 'polite');
    f.appendChild(lab); f.appendChild(ta); f.appendChild(err); app.appendChild(f);

    function clearOut() { err.textContent = ''; res.textContent = ''; ta.removeAttribute('aria-invalid'); }
    function showError(msg) { clearOut(); err.appendChild(note('err', 'تعذّرت معاينة الكود', msg, 'alert')); err.firstChild.style.marginTop = '8px'; ta.setAttribute('aria-invalid', 'true'); ta.focus(); }
    function success(rec, updated) {
      res.textContent = '';
      var n = note('ok', updated ? 'تم تحديث «' + rec.title + '»' : 'تمت إضافة «' + rec.title + '» إلى تحضيراتي', 'حُفظ التحضير على هذا الجهاز ويمكنك قراءته بلا إنترنت.', 'status'), row = el('div', 'row');
      row.appendChild(linkBtn('primary', 'فتح التحضير', '#/saved/' + rec.id, 'eye'));
      row.appendChild(linkBtn('', 'تحضيراتي', '#/saved', 'list'));
      row.appendChild(button('', 'إضافة تحضير آخر', function () { ta.value = ''; clearOut(); ta.focus(); }, 'plus'));
      res.appendChild(n); res.appendChild(row); ta.value = '';
      say(updated ? 'تم تحديث التحضير.' : 'تمت إضافة التحضير إلى تحضيراتي.');
    }
    function showPreview(prep, cls, saveError) {
      var row = el('div', 'row sticky-actions'), msg = null;
      res.textContent = '';
      if (cls.status === 'error') { res.appendChild(note('err', 'تعذّرت الإضافة', cls.error, 'alert')); return; }
      if (saveError) res.appendChild(note('err', 'تعذّر الحفظ', saveError + ' يمكنك إعادة المحاولة.', 'alert'));
      if (cls.status === 'duplicate') msg = note('warn', 'هذا التحضير موجود عندك مسبقاً', 'لن يُضاف مرة ثانية. يمكنك فتح النسخة المحفوظة.');
      else if (cls.status === 'update') msg = note('warn', 'عندك نسخة سابقة من هذا التحضير', 'عدّل الممثل التحضير بعد إرساله. هل تريد استبدال نسختك بهذه النسخة المعدّلة؟');
      else if (cls.status === 'older') msg = note('warn', 'عندك نسخة أحدث من هذا التحضير', 'هذا الكود أقدم مما هو محفوظ عندك، فلم يتغيّر شيء.');
      if (msg) res.appendChild(msg);
      res.appendChild(el('h2', 'sec-t', 'معاينة التحضير'));
      res.appendChild(prepView(prep));
      if (cls.status === 'new') row.appendChild(button('primary', 'إضافة إلى تحضيراتي', function () { doAdd(prep); }, 'plus'));
      else if (cls.status === 'update') {
        row.appendChild(button('primary', 'تحديث نسختي', function () {
          var r = ST.replaceSaved(prep);
          if (!r.ok) { res.insertBefore(note('err', 'تعذّر التحديث', r.error, 'alert'), res.firstChild); return; }
          success(r.record, true);
        }, 'check'));
        row.appendChild(button('', 'إبقاء نسختي', function () { clearOut(); ta.value = ''; say('بقيت نسختك كما هي.'); }));
      } else if (cls.record || cls.existing) row.appendChild(linkBtn('primary', 'فتح النسخة المحفوظة', '#/saved/' + (cls.record || cls.existing).id, 'eye'));
      res.appendChild(row);
    }
    function doAdd(prep) {
      var r = ST.addSaved(prep);
      if (r.status === 'added') success(r.record, false);
      else if (r.status === 'error') showPreview(prep, { status: 'new' }, r.error);
      else showPreview(prep, r);
    }
    function doPreview() {
      var d = S.decode(ta.value);
      if (!d.ok) { showError(d.message); return; }
      clearOut(); pv = d.prep;
      showPreview(pv, ST.classifySaved(pv));
      res.scrollIntoView({ block: 'nearest' });
    }
    acts.appendChild(button('primary', 'معاينة التحضير', doPreview, 'eye'));
    if (navigator.clipboard && navigator.clipboard.readText) {
      acts.appendChild(button('', 'لصق من الحافظة', function () {
        navigator.clipboard.readText().then(function (t) { ta.value = t; clearOut(); ta.focus(); if (/marsa/i.test(t)) doPreview(); },
          function () { say('تعذّر اللصق تلقائياً. اضغط مطولاً داخل الحقل ثم اختر «لصق».', 6000); });
      }, 'paste'));
    }
    app.appendChild(acts); app.appendChild(res);
    ta.addEventListener('input', function () { if (res.firstChild || err.firstChild) clearOut(); });
  }

  // ===== الطالب: تحضيراتي والقراءة =====
  function renderSaved() {
    var all = ST.listSaved(), today = todayStr(), ul = el('ul', 'list'), q = '', search = null, host = el('div', 'stack');
    begin(all.length ? 'تحضيراتي (' + all.length + ')' : 'تحضيراتي', null, '#/', 'الرئيسية');
    if (!all.length) {
      var e = el('div', 'empty'); e.appendChild(el('strong', null, 'لا توجد تحضيرات بعد'));
      e.appendChild(document.createTextNode('اضغط «إضافة تحضير» والصق الكود الذي أرسله الممثل.')); e.appendChild(linkBtn('primary', 'إضافة تحضير', '#/add', 'plus')); app.appendChild(e); return;
    }
    if (all.length >= 6) {
      var f = el('div', 'f'); search = el('input', 'field'); search.type = 'search'; search.setAttribute('aria-label', 'بحث في تحضيراتي'); search.placeholder = 'ابحث بالمادة أو العنوان'; search.autocomplete = 'off';
      f.appendChild(search); host.appendChild(f);
    }
    function draw() {
      var shown = M.sortRecords(M.filterRecords(all, q), today);
      ul.textContent = '';
      if (!shown.length) { var li0 = el('li', 'empty', 'لا نتائج مطابقة.'); ul.appendChild(li0); return; }
      shown.forEach(function (r) {
        var li = el('li'), a = el('a', 'card'), meta = el('div', 'meta'), b = dateBadge(r.date);
        a.href = '#/saved/' + r.id;
        meta.appendChild(el('span', 'badge', r.subject)); meta.appendChild(el('span', null, M.formatDate(r.date)));
        if (b) meta.appendChild(el('span', b.cls, b.text));
        a.appendChild(meta); a.appendChild(el('h3', null, r.title)); a.appendChild(el('p', 'snip', snippet(r.content)));
        li.appendChild(a); ul.appendChild(li);
      });
    }
    if (search) search.addEventListener('input', function () { q = search.value; draw(); });
    draw(); host.appendChild(ul);
    host.appendChild(linkBtn('primary', 'إضافة تحضير', '#/add', 'plus'));
    app.appendChild(host);
  }

  function renderSavedDetail(id) {
    var rec = ST.getSaved(id), box = el('div', 'stack'), acts = el('div', 'row');
    if (!rec) return notFound('#/saved', 'تحضيراتي');
    begin(rec.title, null, '#/saved', 'تحضيراتي').className = 'sr';
    box.appendChild(prepView(rec, addedLine(rec)));
    acts.appendChild(button('danger', 'حذف من تحضيراتي', function () {
      confirmDlg({ title: 'حذف التحضير؟', text: 'سيُحذف «' + rec.title + '» من تحضيراتك على هذا الجهاز فقط. يمكنك إضافته من جديد إن احتفظت بالكود.', okLabel: 'حذف', danger: true, onOk: function () {
        var r = ST.deleteSaved(rec.id);
        if (!r.ok) { say(r.error, 6000); return; }
        say('حُذف التحضير من تحضيراتك.'); nav('saved');
      } });
    }, 'trash'));
    box.appendChild(acts); app.appendChild(box);
  }

  // ===== اليوم وباچر (S11) =====
  function prepHref(r) { return (ui.mode === 'rep' ? '#/share/' : '#/saved/') + r.id; }
  function prepCard(r, text) {
    var li = el('li'), a = el('a', 'card'), meta = el('div', 'meta');
    a.href = prepHref(r);
    meta.appendChild(el('span', 'badge', r.subject));
    if (r.group) meta.appendChild(el('span', null, r.group));
    a.appendChild(meta); a.appendChild(el('h3', null, r.title)); a.appendChild(el('p', 'snip', text)); li.appendChild(a);
    return li;
  }
  function demoNotice(demo, text) {
    var n, a;
    if (demo.corrupt) { n = note('err', null, demo.error, 'alert'); a = el('a', 'linkbtn', 'فتح الإعدادات'); a.href = '#/settings'; n.appendChild(a); return n; }
    return demo.data ? note('', 'بيانات تجريبية', text) : null;
  }
  function emptyBlock(title, text, linkText, href, ic) {
    var e = el('div', 'empty sm');
    e.appendChild(el('strong', null, title));
    if (text) e.appendChild(document.createTextNode(text));
    if (linkText) e.appendChild(linkBtn('', linkText, href, ic));
    return e;
  }
  function renderDay(offset) {
    var today = todayStr(), ymd = offset ? M.addDays(today, offset) : today, demo = ST.loadDemo(), data = demo.data, rep = ui.mode === 'rep', box = el('div', 'stack'), tabs = el('div', 'tabs'),
        lessons = D.lessonsOn(data, ymd), preps = ownList().filter(function (r) { return r.date === ymd; }),
        hw = preps.filter(function (r) { return r.homework && String(r.homework).trim(); }), blk, ul, dn;
    begin(offset ? 'باچر' : 'اليوم', M.formatDate(ymd));
    tabs.setAttribute('role', 'group'); tabs.setAttribute('aria-label', 'اختر اليوم');
    [['#/day', 'اليوم', 0], ['#/day/tomorrow', 'باچر', 1]].forEach(function (t) {
      var a = el('a', null, t[1]); a.href = t[0]; if (t[2] === offset) a.setAttribute('aria-current', 'page'); tabs.appendChild(a);
    });
    app.appendChild(tabs);
    dn = demoNotice(demo, 'الدروس هنا اصطناعية لتجربة الشاشة، وليست جدولك الحقيقي.'); if (dn) box.appendChild(dn);
    blk = el('section', 'block'); blk.appendChild(el('h2', 'sec-t', 'الدروس'));
    if (lessons.length) {
      ul = el('ul', 'slist');
      lessons.forEach(function (l) { var li = el('li', 'lrow'); li.appendChild(el('span', 'time', l.start + '–' + l.end)); li.appendChild(el('b', null, l.subject)); ul.appendChild(li); });
      blk.appendChild(ul);
    } else if (D.hasTimetable(data)) blk.appendChild(emptyBlock(offset ? 'لا دروس باچر' : 'لا دروس اليوم'));
    else blk.appendChild(emptyBlock('لا جدول بعد', 'لا يوجد جدول محفوظ على هذا الجهاز. يمكنك تجربة الشاشة ببيانات تجريبية من الإعدادات.', 'فتح الإعدادات', '#/settings', 'sliders'));
    box.appendChild(blk);
    blk = el('section', 'block'); blk.appendChild(el('h2', 'sec-t', 'التحاضير'));
    if (preps.length) { ul = el('ul', 'list'); preps.forEach(function (r) { ul.appendChild(prepCard(r, snippet(r.content))); }); blk.appendChild(ul); }
    else blk.appendChild(emptyBlock(offset ? 'لا تحاضير ليوم باچر' : 'لا تحاضير لليوم', null, rep ? 'إنشاء تحضير' : 'إضافة تحضير', rep ? '#/new' : '#/add', 'plus'));
    box.appendChild(blk);
    blk = el('section', 'block'); blk.appendChild(el('h2', 'sec-t', 'الواجب'));
    if (hw.length) { ul = el('ul', 'list'); hw.forEach(function (r) { ul.appendChild(prepCard(r, snippet(r.homework))); }); blk.appendChild(ul); }
    else blk.appendChild(emptyBlock('لا واجب مسجّل', offset ? 'لم يُسجَّل واجب لتحاضير يوم باچر.' : 'لم يُسجَّل واجب لتحاضير اليوم.'));
    box.appendChild(blk);
    app.appendChild(box);
  }

  // ===== الامتحان القريب (S12) وتفاصيله (S13) =====
  function examCard(x, today) {
    var a = el('a', 'xcard'), t = el('span', 'tx');
    a.href = '#/exam/' + x.id;
    t.appendChild(el('b', null, x.subject));
    t.appendChild(el('small', null, M.formatDate(x.date) + (x.time ? ' · ' + x.time : '') + ' · ' + D.daysLabel(D.daysBetween(today, x.date))));
    a.appendChild(t); a.appendChild(icon('fwd', 'go'));
    return a;
  }
  function examList(list, today) {
    var ul = el('ul', 'slist');
    list.forEach(function (x) { var li = el('li'); li.appendChild(examCard(x, today)); ul.appendChild(li); });
    return ul;
  }
  function renderExams() {
    var today = todayStr(), demo = ST.loadDemo(), data = demo.data, g = D.examGroups(data, today), nx = g.nearest, box = el('div', 'stack'), dn, a, blk, det, inner, e;
    begin('الامتحان القريب', null, '#/', 'الرئيسية');
    dn = demoNotice(demo, 'الامتحانات هنا اصطناعية لتجربة الشاشة، وليست امتحاناتك الحقيقية.'); if (dn) box.appendChild(dn);
    if (nx) {
      a = el('a', 'nearest'); a.href = '#/exam/' + nx.id;
      a.appendChild(el('span', 'kick', 'الأقرب'));
      a.appendChild(el('h2', null, nx.subject));
      a.appendChild(el('span', 'when', D.daysLabel(D.daysBetween(today, nx.date))));
      a.appendChild(el('span', null, M.formatDate(nx.date) + (nx.time ? ' · ' + nx.time : '')));
      box.appendChild(a);
    } else {
      e = el('div', 'empty'); e.appendChild(el('strong', null, 'لا امتحانات قادمة'));
      e.appendChild(document.createTextNode(data ? 'لا يوجد امتحان قادم في البيانات التجريبية.' : 'لا توجد بيانات امتحانات على هذا الجهاز. يمكنك تجربة الشاشة ببيانات تجريبية من الإعدادات.'));
      if (!data) e.appendChild(linkBtn('', 'فتح الإعدادات', '#/settings', 'sliders'));
      box.appendChild(e);
    }
    if (g.upcoming.length) { blk = el('section', 'block'); blk.appendChild(el('h2', 'sec-t', 'القادمة')); blk.appendChild(examList(g.upcoming, today)); box.appendChild(blk); }
    if (g.finished.length) {
      det = el('details', 'more'); det.appendChild(el('summary', null, 'المنتهية (' + g.finished.length + ')'));
      inner = el('div', 'stack'); inner.appendChild(examList(g.finished, today)); det.appendChild(inner); box.appendChild(det);
    }
    app.appendChild(box);
  }
  function renderExamDetail(id) {
    var today = todayStr(), demo = ST.loadDemo(), x = D.getExam(demo.data, id), box = el('div', 'stack'), dl;
    if (!x) return notFound('#/exam', 'الامتحان القريب', 'لم يعد هذا الامتحان موجوداً', 'ربما حُذفت البيانات التجريبية.');
    begin('امتحان ' + x.subject, null, '#/exam', 'الامتحان القريب');
    box.appendChild(note('', 'بيانات تجريبية', 'هذا الامتحان اصطناعي لتجربة الشاشة.'));
    dl = el('dl', 'kv');
    [['التاريخ', M.formatDate(x.date)], ['الوقت', x.time], ['الموعد', D.daysLabel(D.daysBetween(today, x.date))], ['المواضيع', x.topics], ['ملاحظات', x.notes]].forEach(function (kv) {
      if (!kv[1]) return;
      dl.appendChild(el('dt', null, kv[0])); dl.appendChild(el('dd', null, kv[1]));
    });
    box.appendChild(dl); app.appendChild(box);
  }

  // ===== الترحيب (S01) واختيار الدور (S02): أول مرة فقط، ويعود من «إعادة الترحيب» في الإعدادات =====
  var SLIDES = [
    { art: 'logo', title: 'ما هو مَرسى؟', body: 'تطبيق خفيف يجمع تحاضير صفّك في مكان واحد: يكتبها ممثل الصف وتصلك لتقرأها متى شئت، حتى بلا إنترنت. شاشات اليوم وباچر والامتحان القريب ما زالت قيد التجربة وتعرض بيانات تجريبية.' },
    { art: 'code', title: 'التحضير بالكود عبر واتساب', body: 'ينشئ الممثل التحضير فيُولّد مَرسى كوداً يرسله إلى مجموعة الصف في واتساب. تلصق الكود في «إضافة تحضير» فيُحفظ في «تحضيراتي».' },
    { art: 'device', title: 'بياناتك على جهازك', body: 'يُحفظ كل شيء على هذا الجهاز فقط: لا حسابات ولا مزامنة ولا خادم. الكود غير مشفّر ولا يُلغى، فمن وصله الكود يستطيع قراءة التحضير. ومسح بيانات المتصفح يحذف ما حفظته.' }
  ];
  function svgEl(tag, attrs) { var e = document.createElementNS(NS, tag), k; for (k in attrs) e.setAttribute(k, attrs[k]); return e; }
  function art(kind) {
    var s = svgEl('svg', { viewBox: '0 0 160 120', fill: 'none', stroke: 'currentColor', 'stroke-width': '4', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true', focusable: 'false' });
    if (kind === 'logo') s.appendChild(svgEl('use', { href: '#marsa-mark', x: '32', y: '12', width: '96', height: '96' }));
    else if (kind === 'code') {
      s.appendChild(svgEl('rect', { x: '20', y: '16', width: '120', height: '66', rx: '14' }));
      s.appendChild(svgEl('path', { d: 'M48 82l-10 20 30-20M42 40h76M42 58h48' }));
    } else {
      s.appendChild(svgEl('rect', { x: '52', y: '8', width: '56', height: '104', rx: '12' }));
      s.appendChild(svgEl('path', { d: 'M70 62l8 8 14-16M72 20h16' }));
    }
    return s;
  }
  function wLink(cls, text, href, before, after) {
    var a = el('a', 'btn ' + cls);
    a.href = href;
    if (before) a.appendChild(icon(before));
    a.appendChild(document.createTextNode(text));
    if (after) a.appendChild(icon(after));
    return a;
  }
  function roleButton(m, ic, title, desc) {
    var b = el('button', 'rolebtn'), i = el('span', 'ic'), t = el('span');
    b.type = 'button'; b.setAttribute('data-role', m); i.appendChild(icon(ic)); b.appendChild(i);
    t.appendChild(el('b', null, title)); t.appendChild(el('small', null, desc)); b.appendChild(t);
    b.addEventListener('click', function () { chooseRole(m); });
    return b;
  }
  function chooseRole(m) {
    setMode(m);
    prefs.welcomed = true;
    if (!ST.savePrefs({ welcomed: true })) say('تعذّر حفظ اختيارك على هذا الجهاز، فقد يظهر الترحيب مجدداً عند الفتح القادم.', 7000);
    else say('تم اختيار دور: ' + roleName(m) + '. يمكنك تغييره من الإعدادات.');
    nav('home', true);
  }
  function renderWelcome(id) {
    var n = id === 'role' ? 4 : /^[1-3]$/.test(id) ? +id : 1, box = el('section', 'welcome'), top = el('div', 'w-top'), h, s, dots, acts, skip, i, li, stackR;
    app.textContent = '';
    ST.takeNotices().forEach(function (x) { var nn = note('warn', null, x); nn.style.marginBottom = '12px'; app.appendChild(nn); });
    if (n === 4) {
      top.appendChild(el('p', 'step', 'الخطوة الأخيرة'));
      box.appendChild(top);
      h = el('h1', null, 'من أنت؟'); h.tabIndex = -1; box.appendChild(h);
      box.appendChild(el('p', 'w-body', 'اختر دورك لتظهر لك الأدوات المناسبة. يمكنك تغييره لاحقاً من الإعدادات.'));
      stackR = el('div', 'stack');
      stackR.appendChild(roleButton('student', 'book', 'أنا طالب', 'ألصق الأكواد التي تصلني وأقرأ التحاضير'));
      stackR.appendChild(roleButton('rep', 'pencil', 'أنا ممثل الصف', 'أنشئ التحاضير وأرسل كودها إلى المجموعة'));
      box.appendChild(stackR);
      box.appendChild(note('warn', ROLE_WARN, 'لا حسابات ولا كلمة مرور في هذا الإصدار: أي شخص يفتح الصفحة يستطيع اختيار أي دور.'));
      acts = el('div', 'w-acts'); acts.appendChild(wLink('', 'السابق', '#/welcome/3', 'back')); box.appendChild(acts);
      app.appendChild(box);
      return;
    }
    s = SLIDES[n - 1];
    top.appendChild(el('p', 'step', 'الشريحة ' + n + ' من ' + SLIDES.length));
    skip = el('a', 'linkbtn', 'تخطّي'); skip.href = '#/welcome/role'; top.appendChild(skip);
    box.appendChild(top);
    h = el('div', 'w-art'); h.appendChild(art(s.art)); box.appendChild(h);
    h = el('h1', null, s.title); h.tabIndex = -1; box.appendChild(h);
    box.appendChild(el('p', 'w-body', s.body));
    dots = el('ol', 'dots'); dots.setAttribute('aria-hidden', 'true');
    for (i = 1; i <= SLIDES.length; i++) { li = el('li'); if (i === n) li.className = 'on'; dots.appendChild(li); }
    box.appendChild(dots);
    acts = el('div', 'w-acts');
    if (n > 1) acts.appendChild(wLink('', 'السابق', n === 2 ? '#/welcome' : '#/welcome/' + (n - 1), 'back')); // الشريحة 1 رابطها الأصلي #/welcome
    acts.appendChild(n < SLIDES.length ? wLink('primary', 'التالي', '#/welcome/' + (n + 1), null, 'fwd') : wLink('primary', 'اختيار دوري', '#/welcome/role', null, 'fwd'));
    box.appendChild(acts);
    app.appendChild(box);
  }

  // ===== الإعدادات (S40) وعن مَرسى (S41) =====
  function onTheme(val, radios, msg) {
    var prev = prefs.theme;
    if (val === prev) return;
    applyTheme(val); prefs.theme = val;
    msg.textContent = '';
    if (!ST.savePrefs({ theme: val })) {
      prefs.theme = prev; applyTheme(prev);
      radios.forEach(function (r) { r.checked = r.value === prev; });
      msg.appendChild(note('err', null, 'تعذّر حفظ المظهر على هذا الجهاز، فبقي المظهر السابق.', 'alert'));
      say('تعذّر حفظ المظهر، فبقي المظهر السابق.', 6000);
      return;
    }
    say('المظهر الآن: ' + THEMES.filter(function (t) { return t[0] === val; })[0][1] + '.');
  }
  function renderSettings(focusSel) {
    var box = el('div', 'stack'), demo = ST.loadDemo(), msg = el('div'), radios = [], sec, grp, who, other = ui.mode === 'rep' ? 'student' : 'rep', f, b;
    begin('الإعدادات', null);
    if (!ST.persistent) box.appendChild(note('warn', 'التخزين غير متاح', 'تعذّر استخدام تخزين المتصفح على هذا الجهاز، فلن يُحفظ المظهر ولا الدور ولا البيانات التجريبية بعد إغلاق الصفحة.'));

    sec = el('section', 'set'); sec.appendChild(el('h2', 'set-t', 'المظهر')); sec.firstChild.id = 'set-theme';
    grp = el('div', 'choices'); grp.setAttribute('role', 'radiogroup'); grp.setAttribute('aria-labelledby', 'set-theme');
    THEMES.forEach(function (t) {
      var lab = el('label', 'choice'), inp = el('input'), sp = el('span', null, t[1]);
      inp.type = 'radio'; inp.name = 'theme'; inp.value = t[0]; inp.checked = prefs.theme === t[0];
      inp.addEventListener('change', function () { if (inp.checked) onTheme(t[0], radios, msg); });
      radios.push(inp); lab.appendChild(inp); lab.appendChild(sp); grp.appendChild(lab);
    });
    sec.appendChild(grp);
    sec.appendChild(el('p', 'hint', '«تلقائي» يتبع مظهر جهازك (فاتح أو داكن). يُحفظ اختيارك على هذا الجهاز.'));
    msg.setAttribute('aria-live', 'polite'); sec.appendChild(msg);
    box.appendChild(sec);

    sec = el('section', 'set'); sec.appendChild(el('h2', 'set-t', 'الحساب والدور'));
    who = el('p', 'who', 'أنت الآن: '); who.appendChild(el('strong', null, roleName(ui.mode))); sec.appendChild(who);
    sec.appendChild(note('warn', ROLE_WARN, 'لا حسابات ولا كلمة مرور في هذا الإصدار: أي شخص يفتح الصفحة يستطيع التبديل، فلا تعتمد عليه لحماية أي شيء.'));
    b = button('', ui.mode === 'rep' ? 'التبديل إلى وضع الطالب' : 'التبديل إلى وضع ممثل الصف', function () { setMode(other); say(roleSwitchMsg(other), 6000); renderSettings('#btn-role'); });
    b.id = 'btn-role'; f = el('div', 'row'); f.appendChild(b); sec.appendChild(f);
    box.appendChild(sec);

    sec = el('section', 'set'); sec.appendChild(el('h2', 'set-t', 'بيانات تجريبية'));
    sec.appendChild(el('p', null, 'جدول ودروس وامتحانات اصطناعية لتجربة شاشات «اليوم» و«باچر» و«الامتحان القريب». تُحفظ في مكان منفصل على هذا الجهاز ولا تمسّ تحضيراتي ولا تحاضير أنشأتها، ولا يحملها كود المشاركة.'));
    if (state.demoErr) sec.appendChild(note('err', null, state.demoErr, 'alert'));
    if (demo.corrupt && !state.demoErr) sec.appendChild(note('err', null, demo.error, 'alert'));
    f = el('div', 'row');
    if (demo.data || demo.corrupt) {
      sec.appendChild(el('p', 'who', demo.data ? 'الحالة: البيانات التجريبية محمَّلة.' : 'الحالة: البيانات التجريبية تالفة.'));
      b = button('danger', 'حذف البيانات التجريبية', function () {
        confirmDlg({ title: 'حذف البيانات التجريبية؟', text: 'سيُحذف الجدول والامتحانات التجريبية فقط، ولن يُمسّ أي تحضير محفوظ.', okLabel: 'حذف', danger: true, onOk: function () {
          var r = ST.clearDemo();
          state.demoErr = r.ok ? '' : r.error;
          say(r.ok ? 'حُذفت البيانات التجريبية.' : r.error, r.ok ? 3500 : 7000);
          renderSettings('#btn-demo');
        } });
      }, 'trash');
    } else {
      b = button('primary', 'تجربة ببيانات تجريبية', function () {
        var r = ST.saveDemo(D.build(todayStr()));
        state.demoErr = r.ok ? '' : r.error;
        say(r.ok ? 'تم تحميل بيانات تجريبية اصطناعية.' : r.error, r.ok ? 3500 : 7000);
        renderSettings('#btn-demo');
      }, 'plus');
    }
    b.id = 'btn-demo'; f.appendChild(b); sec.appendChild(f);
    box.appendChild(sec);

    sec = el('section', 'set'); sec.appendChild(el('h2', 'set-t', 'المساعدة'));
    f = el('div', 'row');
    b = button('', 'إعادة الترحيب', function () { location.hash = '#/welcome'; }, 'info'); b.id = 'btn-welcome'; f.appendChild(b);
    f.appendChild(button('', 'كيف تعمل المشاركة بالكود؟', openHow, 'chat'));
    f.appendChild(linkBtn('', 'عن مَرسى وحدوده', '#/about', 'info'));
    sec.appendChild(f); box.appendChild(sec);
    app.appendChild(box);
    if (focusSel) { f = app.querySelector(focusSel); if (f) f.focus({ preventScroll: true }); }
  }
  function renderAbout() {
    var ul = el('ul', 'facts');
    begin('عن مَرسى وحدوده', 'نموذج تجريبي لتحاضير الصف بالكود.', '#/settings', 'الإعدادات');
    ['يعمل التطبيق كله على هذا الجهاز: لا حسابات ولا مزامنة ولا خادم.',
     'التحضير يصلك بالكود فقط، والكود يحمل نص التحضير نفسه فيطول بطول التحضير.',
     'الكود غير مشفّر ولا يُلغى: من وصله الكود يستطيع قراءة التحضير، وتعديل الممثل لا يصل إلا بكود جديد.',
     'مسح بيانات المتصفح يحذف ما حفظته على هذا الجهاز.',
     'تبديل الدور (طالب أو ممثل الصف) تجريبي وغير آمن للإنتاج: أي شخص يفتح الصفحة يستطيع التبديل.',
     'شاشات اليوم وباچر والامتحان القريب تعرض في هذا الإصدار بيانات تجريبية اصطناعية فقط.'
    ].forEach(function (t) { ul.appendChild(el('li', null, t)); });
    app.appendChild(ul);
  }

  // ===== شريط التنقل: سفلي على الهاتف، جانبي يميناً من 1024 =====
  var NAV_ITEMS = [['home', 'الرئيسية', 'home'], ['day', 'اليوم', 'day'], ['preps', 'التحاضير', 'book'], ['settings', 'الإعدادات', 'sliders']];
  function navKeyFor(scr) {
    if (scr === 'home' || scr === 'exam' || scr === 'examDetail') return 'home';
    if (scr === 'day') return 'day';
    if (scr === 'settings' || scr === 'about') return 'settings';
    if (scr === 'welcome') return '';
    return 'preps';
  }
  function syncNav(key) {
    if (!navLinks.home) return;
    if (key !== undefined && key !== null) navNow = key;
    navLinks.home.href = '#/'; navLinks.day.href = '#/day'; navLinks.settings.href = '#/settings';
    navLinks.preps.href = ui.mode === 'rep' ? '#/mine' : '#/saved';
    Object.keys(navLinks).forEach(function (k) { if (k === navNow) navLinks[k].setAttribute('aria-current', 'page'); else navLinks[k].removeAttribute('aria-current'); });
  }
  function buildNav() {
    if (!navEl) return;
    NAV_ITEMS.forEach(function (it) {
      var a = el('a');
      a.setAttribute('data-nav', it[0]); a.appendChild(icon(it[2])); a.appendChild(el('span', null, it[1]));
      navEl.appendChild(a); navLinks[it[0]] = a;
    });
    syncNav('');
  }

  // ===== التوجيه =====
  function parse() {
    var h = String(location.hash || '').replace(/^#\/?/, '').split('?')[0], p = h.split('/').filter(Boolean);
    return { name: p[0] || 'home', id: p[1] || '' };
  }
  function nav(path, replace) {
    var target = '#/' + (path === 'home' ? '' : path);
    if (location.hash === target || (!location.hash && target === '#/')) { route(); return; }
    if (replace && history.replaceState) { history.replaceState(null, '', target); route(); return; }
    location.hash = target;
  }
  function setMode(m, quiet) {
    ui.mode = m === 'rep' ? 'rep' : 'student';
    root.setAttribute('data-mode', ui.mode);
    Array.prototype.forEach.call(document.querySelectorAll('.seg button'), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-m') === ui.mode)); });
    syncNav();
    if (!quiet) ST.saveUi(ui);
  }
  var ID_OK = /^[A-Za-z0-9_-]{6,64}$/;
  function route() {
    var r = parse(), h, scr = 'home';
    renderToken++;
    if (dlg.open) closeDlg();
    // أول فتح: الترحيب أولاً (يُسجَّل «تمّ» عند اختيار الدور). استبدال لا إضافة كي لا يعود الرجوع إلى مسار فارغ
    if (!prefs.welcomed && r.name !== 'welcome' && history.replaceState) { history.replaceState(null, '', '#/welcome'); r = parse(); }
    if (REP_ROUTES[r.name] && ui.mode !== 'rep') { setMode('rep'); }
    else if (!REP_ROUTES[r.name] && !SHARED_ROUTES[r.name] && ui.mode !== 'student') { setMode('student'); }
    app.className = 'page';
    try {
      if (r.name === 'welcome') { scr = 'welcome'; renderWelcome(r.id); }
      else if (r.name === 'new') { scr = 'new'; renderForm(null); }
      else if (r.name === 'edit' && ID_OK.test(r.id)) { scr = 'edit'; renderForm(r.id); }
      else if (r.name === 'preview') { scr = 'preview'; renderPreview(); }
      else if (r.name === 'mine') { scr = 'mine'; renderMine(); }
      else if (r.name === 'share' && ID_OK.test(r.id)) { scr = 'share'; renderShare(r.id); }
      else if (r.name === 'add') { scr = 'add'; renderAdd(); }
      else if (r.name === 'saved' && !r.id) { scr = 'saved'; renderSaved(); }
      else if (r.name === 'saved' && ID_OK.test(r.id)) { scr = 'savedDetail'; renderSavedDetail(r.id); }
      else if (r.name === 'day' && (!r.id || r.id === 'tomorrow')) { scr = 'day'; renderDay(r.id ? 1 : 0); }
      else if (r.name === 'exam' && !r.id) { scr = 'exam'; renderExams(); }
      else if (r.name === 'exam' && ID_OK.test(r.id)) { scr = 'examDetail'; renderExamDetail(r.id); }
      else if (r.name === 'settings') { scr = 'settings'; renderSettings(); }
      else if (r.name === 'about') { scr = 'about'; renderAbout(); }
      else renderHome();
    } catch (e) {
      app.textContent = '';
      app.appendChild(note('err', 'حدث خطأ غير متوقع', 'أعد تحميل الصفحة. بياناتك المحفوظة لم تتأثر.', 'alert'));
      app.appendChild(linkBtn('primary', 'الصفحة الرئيسية', '#/'));
      if (window.console) console.error(e);
    }
    root.setAttribute('data-route', scr);
    if (TOP_ROUTES[scr]) root.setAttribute('data-top', '1'); else root.removeAttribute('data-top');
    syncNav(navKeyFor(scr));
    h = app.querySelector('h1');
    if (h) { h.tabIndex = -1; h.focus({ preventScroll: true }); }
    window.scrollTo(0, 0);
  }

  // ===== بدء التشغيل =====
  applyTheme(prefs.theme);
  buildNav();
  Array.prototype.forEach.call(document.querySelectorAll('.seg button'), function (b) {
    b.addEventListener('click', function () { var m = b.getAttribute('data-m'); setMode(m); nav('home'); say(roleSwitchMsg(m), 6000); });
  });
  document.getElementById('how').addEventListener('click', openHow);
  if (!ST.persistent) { var fp = document.querySelector('.foot p'); if (fp) fp.textContent = 'تنبيه: تعذّر استخدام تخزين المتصفح، فما تضيفه يُفقد عند إغلاق الصفحة.'; }
  document.getElementById('brand').addEventListener('click', function (ev) { if (!location.hash || location.hash === '#/') { ev.preventDefault(); route(); } });
  // بعد زوال الانترو يعود التركيز إلى عنوان الصفحة (كان الانترو يحجب بقية الصفحة بـinert)
  document.addEventListener('marsa:intro-done', function () {
    var h = app.querySelector('h1');
    if (h && (!document.activeElement || document.activeElement === document.body)) h.focus({ preventScroll: true });
  });
  setMode(ui.mode, true);
  window.addEventListener('hashchange', route);
  route();
})();
