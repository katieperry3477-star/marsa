/* MARSA — منطق «الدرجات والتقييمات» (المرحلة 4.04)
 * دوال نقية بلا DOM ولا تخزين: تنظيف وتحقق وتفرّد وبحث وفرز وحساب النسب والمتوسطات.
 * التخزين يمرّ حصراً عبر MarsaAcademicStore (النوع grades). المعرّف الثابت للطالب هو studentId.
 * هذا النموذج منفصل تماماً عن «الامتحانات» (exams-model): الامتحان موعد ومواضيع، أما هنا فدرجة فعلية حصل عليها طالب.
 * الحقول وفق DATA-MODEL.md: recordId, classId, studentId, subject, title, date, score, maxScore, note.
 * (الاسم النهائي لعنوان التقييم في المتجر هو title وليس assessmentTitle.) */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaGradesModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var SUBJECT_MAX = 80, TITLE_MAX = 80, NOTE_MAX = 200, MAX_SCORE_LIMIT = 1000, MIN_YEAR = 2000, MAX_YEAR = 2100;
  var ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
  var SORTS = ['date', 'student', 'subject', 'title', 'percent'];
  var SORT_LABELS = { date: 'التاريخ', student: 'الطالب', subject: 'المادة', title: 'العنوان', percent: 'النسبة' };
  var AVG_BASIS = 'المجموع ÷ مجموع الدرجات القصوى';

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  function searchKey(s) {
    return oneLine(s).replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (typeof s !== 'string' || !m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }
  // تاريخ محلي من أجزاء Date المحلية (لا toISOString فلا ينتقل اليوم بسبب UTC)
  function localDate(d) {
    d = d || new Date();
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function formatDate(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(iso));
    return m && isLocalDate(iso) ? m[3] + '/' + m[2] + '/' + m[1] : (str(iso) || '(بلا تاريخ)');
  }
  function twoDec(n) { return Math.round(n * 100) / 100 === n; }

  // ===== تحويل رقم مكتوب إلى عدد (صارم) =====
  // يقبل الأرقام العربية-الهندية والفارسية، والفاصلة العشرية «٫» أو «,» أو «.»، ويرفض ما عدا ذلك (لا parseFloat المتساهل).
  // النتيجة: { ok, value } أو { ok:false, reason:'empty'|'format'|'separator'|'decimals' }
  function parseNumber(input) {
    var s, n;
    if (typeof input === 'number') return isFinite(input) ? { ok: true, value: input } : { ok: false, reason: 'format' };
    s = oneLine(input);
    if (!s) return { ok: false, reason: 'empty' };
    s = s.replace(/[\u0660-\u0669]/g, function (c) { return String(c.charCodeAt(0) - 0x660); })
      .replace(/[\u06F0-\u06F9]/g, function (c) { return String(c.charCodeAt(0) - 0x6F0); });
    // 4.08: «٬» (U+066C) هي فاصلة آلاف عربية وليست فاصلة عشرية؛ كانت تُقرأ كعشرية فيصير «١٬٠٠٠» واحداً. تُرفض الآن صراحةً
    if (/\u066C/.test(s)) return { ok: false, reason: 'separator' };
    s = s.replace(/[\u066B,]/g, '.');
    if (!/^\d+(\.\d+)?$/.test(s) && !/^\.\d+$/.test(s)) return { ok: false, reason: 'format' };
    // 4.08: أكثر من خانتين بعد الفاصلة («1,000» أو «7,500») ملتبس مع فاصلة الآلاف؛ كان يُقرأ بصمت 1 أو 7.5. يُرفض ولا نخمّن
    if (/\.\d{3,}$/.test(s)) return { ok: false, reason: 'decimals' };
    n = Number(s);
    return isFinite(n) ? { ok: true, value: n } : { ok: false, reason: 'format' };
  }

  // ===== التحقق =====
  function validateDate(date, today) {
    var d = str(date).trim(), y;
    if (!d) return 'اختر تاريخ التقييم.';
    if (!isLocalDate(d)) return 'التاريخ غير صالح. استخدم يوماً موجوداً في التقويم بصيغة YYYY-MM-DD.';
    y = +d.slice(0, 4);
    if (y < MIN_YEAR || y > MAX_YEAR) return 'التاريخ خارج النطاق المنطقي (' + MIN_YEAR + ' إلى ' + MAX_YEAR + ').';
    if (today && d > today) return 'لا يمكن تسجيل درجة بتاريخ بعد اليوم المحلي.';
    return null;
  }
  // رسالة خطأ الرقم حسب السبب (4.08): الفاصلة الملتبسة مع الآلاف لها نص يشرح الحل
  function numMsg(reason, fallback) {
    if (reason === 'separator') return 'لا تستعمل فاصلة الآلاف «٬». اكتب الرقم بلا فاصلة (مثل 1000).';
    if (reason === 'decimals') return 'خانتان عشريتان كحد أقصى. إن كنت تقصد فاصلة آلاف فاكتب الرقم بلا فاصلة (مثل 1000).';
    return fallback;
  }
  // input: { studentId, subject, title, date, score, maxScore, note } (score/maxScore نص أو رقم)
  // ctx: { today, activeIds:[..] }  → { ok, values, errors }
  function validateEntry(input, ctx) {
    var e = {}, v = {}, sc, mx, i, found = false;
    input = input || {}; ctx = ctx || {};
    v.studentId = str(input.studentId).trim();
    v.subject = oneLine(input.subject);
    v.title = oneLine(input.title);
    v.date = str(input.date).trim();
    v.note = oneLine(input.note);
    if (!ID_RE.test(v.studentId)) e.studentId = 'اختر الطالب.';
    else if (Array.isArray(ctx.activeIds)) {
      for (i = 0; i < ctx.activeIds.length; i++) if (ctx.activeIds[i] === v.studentId) { found = true; break; }
      if (!found) e.studentId = 'الطالب ليس ضمن الطلاب الفعّالين في هذا الصف.';
    }
    if (!v.subject) e.subject = 'اكتب اسم المادة.';
    else if (v.subject.length > SUBJECT_MAX) e.subject = 'اسم المادة أطول من ' + SUBJECT_MAX + ' حرفاً.';
    if (!v.title) e.title = 'اكتب عنوان التقييم أو الامتحان.';
    else if (v.title.length > TITLE_MAX) e.title = 'العنوان أطول من ' + TITLE_MAX + ' حرفاً.';
    if (validateDate(v.date, ctx.today)) e.date = validateDate(v.date, ctx.today);
    if (v.note.length > NOTE_MAX) e.note = 'الملاحظة أطول من ' + NOTE_MAX + ' حرفاً (طولها الآن ' + v.note.length + ').';
    mx = parseNumber(input.maxScore);
    if (!mx.ok) e.maxScore = mx.reason === 'empty' ? 'اكتب الدرجة القصوى.' : numMsg(mx.reason, 'الدرجة القصوى يجب أن تكون رقماً (مثل 10 أو 20 أو 100).');
    else if (mx.value <= 0) e.maxScore = 'الدرجة القصوى يجب أن تكون أكبر من صفر.';
    else if (mx.value > MAX_SCORE_LIMIT) e.maxScore = 'الدرجة القصوى لا تتجاوز ' + MAX_SCORE_LIMIT + '.';
    else if (!twoDec(mx.value)) e.maxScore = 'الدرجة القصوى بخانتين عشريتين كحد أقصى.';
    sc = parseNumber(input.score);
    if (!sc.ok) e.score = sc.reason === 'empty' ? 'اكتب الدرجة. الدرجة المفقودة لا تُعدّ صفراً؛ اترك الطالب بلا سجل إن لم تُدخل له درجة.' : numMsg(sc.reason, 'الدرجة يجب أن تكون رقماً (مثل 7.5).');
    else if (!twoDec(sc.value)) e.score = 'الدرجة بخانتين عشريتين كحد أقصى.';
    else if (mx.ok && mx.value > 0 && sc.value > mx.value) e.score = 'الدرجة (' + sc.value + ') أكبر من الدرجة القصوى (' + mx.value + ').';
    if (sc.ok) v.score = sc.value;
    if (mx.ok) v.maxScore = mx.value;
    return { ok: Object.keys(e).length === 0, values: v, errors: e };
  }

  // ===== التفرّد (نفس قاعدة المتجر تماماً): (studentId, subject, title, date) بعد توحيد النص =====
  // إعادة امتحان أو تقييم آخر مماثل مسموح بتغيير العنوان (مثل «اختبار شهري - إعادة») أو التاريخ.
  function uniqueKey(r) { return str(r && r.studentId) + '\u0001' + searchKey(r && r.subject) + '\u0001' + searchKey(r && r.title) + '\u0001' + str(r && r.date); }
  function findDuplicate(records, candidate, exceptRecordId) {
    var k = uniqueKey(candidate), i, r;
    for (i = 0; i < (records || []).length; i++) { r = records[i]; if (r.recordId !== exceptRecordId && uniqueKey(r) === k) return r; }
    return null;
  }
  function findConflicts(records) {
    var map = Object.create(null), out = [], k;
    (records || []).forEach(function (r) { var key = uniqueKey(r); (map[key] = map[key] || []).push(r); });
    for (k in map) if (map[k].length > 1) out.push({ studentId: map[k][0].studentId, recordIds: map[k].map(function (r) { return r.recordId; }) });
    return out;
  }
  function findById(records, id) { var i; for (i = 0; i < (records || []).length; i++) if (records[i].recordId === id) return records[i]; return null; }

  // ===== تخطيط الحفظ =====
  // editing: السجل القائم عند التعديل (أو null للإضافة). fresh: السجلات الحالية من المتجر لحظة الحفظ.
  // النتيجة: { ok, record, mode:'create'|'update'|'unchanged', errors, duplicate }
  // التعديل ينسخ السجل القائم كاملاً فيبقى recordId وclassId وcreatedAt؛ لا يُنشأ recordId هنا أبداً (يُنشئه المتجر).
  // studentId لا يتغير عند التعديل (المتجر يرفض ذلك)، فيُؤخذ من السجل القائم.
  function planSave(input, fresh, ctx, editing) {
    var res, ex, rec, k, dup, activeIds;
    ctx = ctx || {};
    input = input || {};
    if (editing) {
      ex = findById(fresh, editing.recordId);
      if (!ex) return { ok: false, errors: { _: 'السجل لم يعد موجوداً (ربما حُذف من تبويب آخر). أُعيد تحميل القائمة.' }, status: 'not-found' };
      input = shallow(input); input.studentId = ex.studentId;
      // التعديل لا يشترط أن يكون الطالب فعّالاً (سجل طالب مؤرشف قابل للتصحيح كسجل تاريخي؟ لا: القراءة والحذف فقط للمؤرشفين)
      activeIds = ctx.activeIds;
    } else activeIds = ctx.activeIds;
    res = validateEntry(input, { today: ctx.today, activeIds: activeIds });
    if (!res.ok) return { ok: false, errors: res.errors };
    dup = findDuplicate(fresh, res.values, ex ? ex.recordId : null);
    if (dup) return { ok: false, errors: { _: 'يوجد تقييم بالبيانات نفسها لهذا الطالب (المادة والعنوان والتاريخ). عدّل ذلك السجل بدل إنشاء آخر، أو غيّر العنوان إن كان تقييماً مختلفاً كإعادة امتحان.' }, status: 'duplicate', duplicate: dup };
    if (ex) {
      if (ex.subject === res.values.subject && ex.title === res.values.title && ex.date === res.values.date && ex.score === res.values.score && ex.maxScore === res.values.maxScore && str(ex.note) === res.values.note) return { ok: true, mode: 'unchanged', record: ex };
      rec = shallow(ex);
    } else rec = { studentId: res.values.studentId };
    rec.subject = res.values.subject; rec.title = res.values.title; rec.date = res.values.date; rec.score = res.values.score; rec.maxScore = res.values.maxScore;
    if (res.values.note) rec.note = res.values.note; else delete rec.note;
    return { ok: true, mode: ex ? 'update' : 'create', record: rec };
  }
  function shallow(o) { var r = {}, k; for (k in o) if (Object.prototype.hasOwnProperty.call(o, k)) r[k] = o[k]; return r; }

  // ===== النسب والمتوسطات (تُحسب للعرض فقط ولا تُخزَّن) =====
  // سجل غير صالح (score/maxScore ليست أرقاماً منتهية أو maxScore ≤ 0) يُرجع null ولا يُعامل صفراً.
  function percent(r) {
    if (!r || typeof r.score !== 'number' || typeof r.maxScore !== 'number' || !isFinite(r.score) || !isFinite(r.maxScore) || r.maxScore <= 0) return null;
    return r.score / r.maxScore * 100;
  }
  function fmtNum(n) { return typeof n === 'number' && isFinite(n) ? String(Math.round(n * 100) / 100) : '—'; }
  function fmtPercent(p) { return p == null ? '—' : fmtNum(p) + '%'; }
  // الطريقة الوحيدة المعتمدة في الواجهة: المجموع ÷ مجموع الدرجات القصوى × 100. (لا نخلطها بمتوسط النسب.)
  // السجلات غير الصالحة تُستثنى من الحساب ويُعاد عددها في invalid حتى تُعلَن ولا تُخفى.
  function pooledAverage(records) {
    var s = 0, m = 0, n = 0, bad = 0;
    (records || []).forEach(function (r) { if (percent(r) == null) { bad++; return; } s += r.score; m += r.maxScore; n++; });
    return { count: n, invalid: bad, sumScore: Math.round(s * 100) / 100, sumMax: Math.round(m * 100) / 100, percent: n ? s / m * 100 : null };
  }
  // متوسط النسب (غير مستعمل في الواجهة؛ متاح للمقارنة والاختبار ويثبت أن الطريقتين تختلفان)
  function meanOfPercents(records) {
    var s = 0, n = 0;
    (records || []).forEach(function (r) { var p = percent(r); if (p != null) { s += p; n++; } });
    return n ? s / n : null;
  }
  // ملخص لكل مادة: [{subject, key, ...pooledAverage}] مرتب أبجدياً
  function summarizeBySubject(records) {
    var map = Object.create(null), out = [];
    (records || []).forEach(function (r) { var k = searchKey(r.subject); (map[k] = map[k] || { subject: oneLine(r.subject), list: [] }).list.push(r); });
    Object.keys(map).forEach(function (k) { var a = pooledAverage(map[k].list); a.subject = map[k].subject; a.key = k; out.push(a); });
    return out.sort(function (a, b) { return a.subject < b.subject ? -1 : a.subject > b.subject ? 1 : 0; });
  }

  // ===== تصنيف السجلات حسب حالة الطالب =====
  // allStudents: كل طلاب الصف (فعّالون ومؤرشفون). كل سجل → 'active' | 'archived' | 'unknown'
  function studentKind(studentId, allStudents) {
    var i, s;
    for (i = 0; i < (allStudents || []).length; i++) { s = allStudents[i]; if (s.studentId === studentId) return s.status === 'archived' ? 'archived' : 'active'; }
    return 'unknown';
  }

  // ===== البحث والفرز =====
  // opts: { query, nameOf, studentId, subject, title, from, to }
  // query يبحث في اسم الطالب والمادة والعنوان والتاريخ (YYYY-MM-DD أو DD/MM/YYYY) والملاحظة
  function filterRecords(records, opts) {
    var q = searchKey(opts && opts.query), nameOf = opts && opts.nameOf, sid = opts && opts.studentId, sj = searchKey(opts && opts.subject), from = opts && opts.from, to = opts && opts.to;
    return (records || []).filter(function (r) {
      var hay;
      if (sid && sid !== 'all' && r.studentId !== sid) return false;
      if (sj && searchKey(r.subject) !== sj) return false;
      if (from && r.date < from) return false;
      if (to && r.date > to) return false;
      if (q) {
        hay = [nameOf ? nameOf(r.studentId) : '', r.subject, r.title, r.date, formatDate(r.date), r.note].map(searchKey).join(' ');
        if (hay.indexOf(q) < 0) return false;
      }
      return true;
    });
  }
  // الفرز للعرض فقط. dir: 'asc' | 'desc'. الاستقرار: عند التساوي يُرتَّب بالتاريخ الأحدث ثم recordId (ترتيب حتمي).
  function sortRecords(records, key, dir, nameOf) {
    var sign = dir === 'asc' ? 1 : -1;
    if (SORTS.indexOf(key) < 0) key = 'date';
    function val(r) {
      if (key === 'student') return searchKey(nameOf ? nameOf(r.studentId) : r.studentId);
      if (key === 'subject') return searchKey(r.subject);
      if (key === 'title') return searchKey(r.title);
      if (key === 'percent') { var p = percent(r); return p == null ? -1 : p; }
      return str(r.date);
    }
    return (records || []).slice().sort(function (a, b) {
      var x = val(a), y = val(b);
      if (x !== y) return (x < y ? -1 : 1) * sign;
      if (a.date !== b.date) return a.date < b.date ? 1 : -1;
      return str(a.recordId) < str(b.recordId) ? -1 : str(a.recordId) > str(b.recordId) ? 1 : 0;
    });
  }
  function distinctSubjects(records) {
    var seen = Object.create(null), out = [];
    (records || []).forEach(function (r) { var k = searchKey(r.subject); if (k && !seen[k]) { seen[k] = 1; out.push(oneLine(r.subject)); } });
    return out.sort();
  }

  return {
    SUBJECT_MAX: SUBJECT_MAX, TITLE_MAX: TITLE_MAX, NOTE_MAX: NOTE_MAX, MAX_SCORE_LIMIT: MAX_SCORE_LIMIT, MIN_YEAR: MIN_YEAR, MAX_YEAR: MAX_YEAR,
    SORTS: SORTS.slice(), SORT_LABELS: SORT_LABELS, AVG_BASIS: AVG_BASIS,
    oneLine: oneLine, searchKey: searchKey, isLocalDate: isLocalDate, localDate: localDate, formatDate: formatDate, parseNumber: parseNumber,
    validateDate: validateDate, validateEntry: validateEntry, uniqueKey: uniqueKey, findDuplicate: findDuplicate, findConflicts: findConflicts, findById: findById,
    planSave: planSave, percent: percent, fmtNum: fmtNum, fmtPercent: fmtPercent, pooledAverage: pooledAverage, meanOfPercents: meanOfPercents,
    summarizeBySubject: summarizeBySubject, studentKind: studentKind, filterRecords: filterRecords, sortRecords: sortRecords, distinctSubjects: distinctSubjects
  };
});
