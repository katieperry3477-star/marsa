/* MARSA — منطق «ما أُخذ اليوم / سجل الدروس» (المرحلة 03.2)
 * دوال نقية بلا DOM ولا تخزين: تحقق، تنظيف، فرز، بحث، وتنسيق تاريخ محلي.
 * التخزين نفسه يمرّ حصراً عبر MarsaAcademicStore (النوع dailyLessons). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaLessonsModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // حدود الأطوال (بوحدات UTF-16 كما يعدّها maxlength في المتصفح)
  var LIMITS = { subject: 80, title: 120, pages: 80, summary: 1000, homework: 500, notes: 1000 };
  var MIN_YEAR = 2000, MAX_YEAR = 2100;
  var ORDER = ['subject', 'title', 'date', 'summary', 'pages', 'homework', 'notes'];
  var OPTIONAL = ['summary', 'pages', 'homework', 'notes'];
  var LABELS = { subject: 'المادة', title: 'عنوان الدرس', date: 'تاريخ الشرح', summary: 'الملخص', pages: 'صفحات الكتاب / المصدر', homework: 'الواجب أو المطلوب', notes: 'الملاحظات' };
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  // حقل بسطر واحد: يزيل المحارف الخفية والتحكم ويضغط الفراغات
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  // حقل متعدد الأسطر: يحافظ على الأسطر الجديدة ويحدّ الأسطر الفارغة المتتالية
  function multiLine(s) {
    return str(s).replace(/\r\n?|\u2028|\u2029/g, '\n').replace(CTRL, '').replace(INVIS, '')
      .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  // مفتاح بحث: يوحّد الألف والياء والتاء المربوطة ويزيل التشكيل والتطويل (مطابق لمنطق البحث في قائمة الطلاب)
  function searchKey(s) {
    return oneLine(s).replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (!m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }

  // يتحقق من مدخلات النموذج. today = تاريخ اليوم المحلي YYYY-MM-DD (لتنبيه التاريخ المستقبلي).
  // النتيجة: { ok, values, errors:{حقل:رسالة}, firstError, future }
  function validate(input, opts) {
    var errors = {}, v = {}, today = opts && opts.today, i, k, first = null, y;
    input = input || {};
    v.subject = oneLine(input.subject); v.title = oneLine(input.title); v.pages = oneLine(input.pages);
    v.summary = multiLine(input.summary); v.homework = multiLine(input.homework); v.notes = multiLine(input.notes);
    v.date = str(input.date).trim();
    if (!v.subject) errors.subject = 'اكتب اسم المادة. لا يمكن تركه فارغاً.';
    if (!v.title) errors.title = 'اكتب عنوان الدرس أو موضوعه. لا يمكن تركه فارغاً.';
    if (!v.date) errors.date = 'اختر تاريخ الشرح.';
    else if (!isLocalDate(v.date)) errors.date = 'التاريخ غير صالح. استخدم الصيغة YYYY-MM-DD ويوماً موجوداً في التقويم.';
    else { y = +v.date.slice(0, 4); if (y < MIN_YEAR || y > MAX_YEAR) errors.date = 'التاريخ خارج النطاق المنطقي (' + MIN_YEAR + ' إلى ' + MAX_YEAR + ').'; }
    for (k in LIMITS) if (!errors[k] && v[k].length > LIMITS[k]) errors[k] = LABELS[k] + ' أطول من ' + LIMITS[k] + ' حرفاً (طوله الآن ' + v[k].length + '). اختصره ثم احفظ.';
    for (i = 0; i < ORDER.length; i++) if (errors[ORDER[i]]) { first = ORDER[i]; break; }
    return { ok: first === null, values: v, errors: errors, firstError: first, future: !errors.date && !!today && v.date > today };
  }

  // يبني السجل للحفظ. existing (عند التعديل) يُنسخ كاملاً فيبقى recordId وclassId وأي حقل آخر كما هو؛
  // الحقول الاختيارية الفارغة تُحذف بدل تخزين نص فارغ. لا يُنشأ recordId هنا أبداً.
  function buildRecord(values, existing) {
    var r = {}, k, i;
    if (existing && typeof existing === 'object') for (k in existing) if (Object.prototype.hasOwnProperty.call(existing, k)) r[k] = existing[k];
    r.subject = values.subject; r.title = values.title; r.date = values.date;
    for (i = 0; i < OPTIONAL.length; i++) { k = OPTIONAL[i]; if (values[k]) r[k] = values[k]; else delete r[k]; }
    return r;
  }

  // قراءة آمنة لحقل نصي من سجل قد يكون من مصدر غير موثوق
  function field(r, k) { return r && typeof r[k] === 'string' ? r[k] : ''; }

  // الأحدث أولاً: التاريخ (نص YYYY-MM-DD يُقارن حرفياً)، ثم وقت الإنشاء، ثم المعرّف
  function sortRecords(list) {
    return list.slice().sort(function (a, b) {
      var da = field(a, 'date'), db = field(b, 'date'), ca, cb;
      if (da !== db) return da < db ? 1 : -1;
      ca = field(a, 'createdAt'); cb = field(b, 'createdAt');
      if (ca !== cb) return ca < cb ? 1 : -1;
      return field(a, 'recordId') < field(b, 'recordId') ? 1 : -1;
    });
  }
  // بحث بالموضوع أو المادة فقط
  function filterRecords(list, query) {
    var q = searchKey(query);
    if (!q) return list.slice();
    return list.filter(function (r) { return searchKey(field(r, 'title')).indexOf(q) > -1 || searchKey(field(r, 'subject')).indexOf(q) > -1; });
  }
  // المواد التي كتبها المستخدم نفسه في هذا الصف (لاقتراحات الإدخال فقط؛ لا قائمة ثابتة)
  function subjectsOf(list) {
    var seen = {}, out = [];
    sortRecords(list).forEach(function (r) {
      var s = oneLine(field(r, 'subject')), k = searchKey(s);
      if (s && !seen[k]) { seen[k] = 1; out.push(s); }
    });
    return out;
  }

  // تنسيق تاريخ دراسي محلي: يبني Date محلياً من الأجزاء (لا Date.parse على النص) فلا ينزاح اليوم بسبب UTC
  function formatDate(ymd) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(ymd)), d;
    if (!m || !isLocalDate(ymd)) return str(ymd) ? str(ymd) : 'بلا تاريخ';
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    try { return new Intl.DateTimeFormat('ar-u-ca-gregory-nu-latn', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(d); }
    catch (e) { return ymd; }
  }

  return { LIMITS: LIMITS, MIN_YEAR: MIN_YEAR, MAX_YEAR: MAX_YEAR, LABELS: LABELS, validate: validate, buildRecord: buildRecord, sortRecords: sortRecords, filterRecords: filterRecords, subjectsOf: subjectsOf, formatDate: formatDate, searchKey: searchKey, isLocalDate: isLocalDate, oneLine: oneLine, multiLine: multiLine, field: field };
});
