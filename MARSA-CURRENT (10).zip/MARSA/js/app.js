(function () {
  'use strict';
  var intro = document.getElementById('intro');
  var skip = document.getElementById('skip-intro');
  var shell = ['top', 'main', 'foot'].map(function (id) { return document.getElementById(id); });
  var reduceMQ = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : null;
  var reduce = !!(reduceMQ && reduceMQ.matches);
  if (reduceMQ && reduceMQ.addEventListener) reduceMQ.addEventListener('change', function () { reduce = reduceMQ.matches; });
  var introTimer = null, toastTimer = null;

  // المقدمة تظهر عند كل تحميل جديد للصفحة: لا تعتمد على أي مفتاح تخزين ولا تكتب علامة «شوهدت».
  // (القيمة القديمة marsa.intro.seen إن وُجدت في المتصفح تُترك كما هي وتُتجاهل.)

  function setInert(on) {
    shell.forEach(function (el) { if (on) el.setAttribute('inert', ''); else el.removeAttribute('inert'); });
  }

  function openIntro() {
    if (typeof endModeFx === 'function') endModeFx();
    clearTimeout(introTimer);
    intro.classList.remove('play', 'leaving');
    intro.hidden = false;
    setInert(true);
    void intro.offsetWidth; // إعادة تشغيل الحركة
    requestAnimationFrame(function () { intro.classList.add('play'); });
    skip.focus({ preventScroll: true });
    introTimer = setTimeout(closeIntro, reduce ? 2200 : 4800);
  }

  function closeIntro() {
    clearTimeout(introTimer);
    if (intro.hidden) return;
    intro.classList.add('leaving');
    setTimeout(function () {
      intro.hidden = true;
      intro.classList.remove('play', 'leaving');
      setInert(false);
      var t = document.getElementById(state.view === 'home' ? 'welcome' : 'page-title');
      if (t) t.focus({ preventScroll: true });
    }, reduce ? 0 : 450);
  }

  function say(msg, ms) {
    var s = document.getElementById('status');
    // تفريغ ثم كتابة: يُعاد إعلان الرسالة لقارئ الشاشة حتى لو تطابق نصها مع السابقة
    clearTimeout(toastTimer);
    // رسالة مكررة: نغيّر النص بحرف غير مرئي (U+200B) ليُعاد إعلانها لقارئ الشاشة دون تفريغ مرئي
    s.textContent = s.textContent === msg ? msg + '​' : msg;
    s.classList.add('on');
    toastTimer = setTimeout(function () { s.classList.remove('on'); setTimeout(function () { if (!s.classList.contains('on')) s.textContent = ''; }, 250); }, ms || 3200);
  }

  // ===== هيكل التطبيق: الأقسام والتنقّل ومبدّل الوضع =====
  // ملاحظة للمطور: المبدّل نموذج واجهة محلي فقط ولا يحمي أي بيانات.
  // السجلات المستقبلية (تحضير، امتحان، غياب) تشير إلى classId وstudentId ثابتين، لا إلى ترتيب القائمة.
  var DEMO_ID = 'cls_demo_001'; // معرّف ثابت للصف التجريبي: لا يُغيَّر أبداً
  var PREF_KEY = 'marsa.ui';
  var LATER = 'هذا القسم جاهز للربط، وستُضاف وظيفته في مرحلة لاحقة.';
  var DEV_NOTE = 'مبدّل الوضع نموذج واجهة محلي فقط، والرمز التجريبي في الإعدادات حاجز واجهة غير آمن لا يحمي أي بيانات: لا يوجد تسجيل دخول ولا صلاحيات، وتغيير الواجهة لا يمنع الوصول إلى أي بيانات. صفحتا «التحاضير» و«الأرشيف» في وضع الطالب للقراءة فقط بحكم الواجهة (لا أزرار إضافة أو تعديل أو حذف)، وهذا قيد واجهة محلي وليس حماية: أي شخص يستطيع تعديل التخزين المحلي من أدوات المتصفح. التحقق من الصلاحيات يجب أن يتم على الخادم عند بنائه. الكود الشخصي للطالب معرّف فقط وليس وسيلة مصادقة. يُحفظ في هذا المتصفح القسم الأخير والصفوف وقوائم الطلاب، وهي بيانات محلية غير مشتركة.';
  var MODES = {
    student: { label: 'وضع الطالب', start: 'home', views: ['home', 'schedule', 'prep', 'archive', 'exams', 'news', 'subjects', 'grades', 'absence', 'settings'] },
    rep: { label: 'وضع ممثل الصف', start: 'dash', views: ['dash', 'students', 'r-schedule', 'r-lessons', 'r-prep', 'r-exams', 'r-grades', 'r-news', 'attendance', 'payments', 'reports', 'r-settings'] }
  };
  // nav: اسم التبويب، t: العنوان، d: الوصف، a: الإجراء الرئيسي (غير مفعّل بعد)، p: أجزاء الصفحة [عنوان، نص الحالة الفارغة]
  var V = {
    home: { nav: 'الرئيسية' },
    schedule: { nav: 'الجدول', t: 'الجدول الدراسي', d: 'حصص الأسبوع ومواعيدها.', kind: 'stSchedule' },
    prep: { nav: 'التحاضير', t: 'تحاضير اليوم وباجر', d: 'ما سيُشرح اليوم وما سيُشرح غداً.', kind: 'stPreps' },
    archive: { nav: 'الأرشيف', t: 'الأرشيف الدراسي', d: 'الدروس المشروحة والتحاضير والامتحانات السابقة، من الأحدث إلى الأقدم.', kind: 'stArchive' },
    exams: { nav: 'الامتحانات', t: 'الامتحانات', d: 'القادمة والسابقة، ومواضيع كل امتحان.', kind: 'stExams' },
    news: { nav: 'الإعلانات', t: 'الإعلانات', d: 'إعلانات الصف من الأحدث إلى الأقدم.', p: [['الإعلانات', 'لا توجد إعلانات منشورة.']] },
    subjects: { nav: 'المواد والملازم', t: 'المواد والأساتذة والملازم', d: 'مواد الصف ومدرّسوها وملازمها.', p: [['المواد', 'لم تُضف مواد بعد.'], ['الأساتذة', 'لم يُضف أساتذة بعد.'], ['الملازم', 'لا توجد ملازم مضافة.']] },
    grades: { nav: 'درجاتي', t: 'درجاتي', d: 'درجاتك أنت فقط.', priv: 1, kind: 'stGrades' },
    absence: { nav: 'غيابي', t: 'سجل غيابي', d: 'أيام غيابك أنت فقط.', priv: 1, kind: 'stAbsence' },
    settings: { nav: 'الإعدادات', t: 'الإعدادات', d: 'تفضيلات العرض.', kind: 'settings' },
    dash: { nav: 'اللوحة', t: 'لوحة ممثل الصف', d: 'مدخلك إلى أقسام إدارة الصف.', kind: 'tiles' },
    classes: { nav: 'إدارة الصفوف', t: 'إدارة الصفوف', d: 'إضافة الصفوف وتعديلها واختيار الصف النشط وأرشفتها.', parent: 'dash', kind: 'classes' },
    students: { nav: 'الطلاب', t: 'إدارة الطلاب', d: 'قائمة طلاب الصف مرتبة أبجدياً، مع إضافتهم وأرشفتهم.', kind: 'roster' },
    'r-schedule': { nav: 'الجدول', t: 'الجدول الدراسي الأسبوعي', d: 'ابنِ جدول حصص الصف: اليوم والحصة والوقت والمادة، بالعدد الذي تحتاجه من الحصص لكل يوم.', kind: 'schedule' },
    'r-lessons': { nav: 'ما أُخذ اليوم', t: 'ما أُخذ اليوم — سجل الدروس', d: 'سجّل ما شرحته فعلياً في الصف: المادة والموضوع والتاريخ، ثم راجعه وعدّله.', kind: 'lessons' },
    'r-prep': { nav: 'التحاضير', t: 'التحاضير', d: 'حضّر لما سيأتي: تحاضير اليوم وباجر وما بعدها، مرتبة بالأقرب موعداً.', kind: 'preps' },
    'r-exams': { nav: 'الامتحانات', t: 'إدارة الامتحانات', d: 'مواعيد الامتحانات ونطاق مواضيعها: القادمة من الأقرب للأبعد، ثم السابقة والمنتهية.', kind: 'exams' },
    'r-grades': { nav: 'الدرجات', t: 'الدرجات والتقييمات', d: 'سجّل درجات الطلاب الفعلية في كل تقييم، وابحث فيها وعدّلها، واطّلع على النسب والمتوسطات.', kind: 'grades' },
    'r-news': { nav: 'الإعلانات', t: 'الإعلانات', d: 'إعلانات تظهر لطلاب الصف.', a: 'نشر إعلان', p: [['الإعلانات', 'لا توجد إعلانات منشورة.']] },
    attendance: { nav: 'الحضور', t: 'الحضور والغياب', d: 'سجّل حضور طلاب الصف النشط يوماً بيوم، وراجع الأيام السابقة وعدّلها.', kind: 'attendance' },
    payments: { nav: 'المدفوعات', t: 'المدفوعات وسجل المقبوضات', d: 'سجّل المبالغ التي استلمتها فعلاً من الطلاب بالدينار العراقي، وراجعها وعدّلها، واطّلع على مجموع المقبوضات في أي فترة.', kind: 'payments' },
    reports: { nav: 'التقارير', t: 'الملخصات والتقارير', d: 'ملخصات تُبنى من بيانات الأقسام الأخرى.', a: 'إنشاء ملخص', p: [['الملخصات', 'لا توجد تقارير بعد.']] },
    'r-settings': { nav: 'الإعدادات', t: 'الإعدادات', d: 'إعدادات الصف والعرض.', kind: 'settings' },
    deleted: { nav: 'الطلاب المحذوفون', t: 'الطلاب المحذوفون', d: 'الطلاب المؤرشفون. سجلاتهم محفوظة ويمكن استعادتهم.', parent: 'r-settings', kind: 'deleted' },
    'student-detail': { nav: 'تفاصيل الطالب', t: 'تفاصيل الطالب', d: 'بيانات الطالب وحالة سجله.', kind: 'detail' }
  };
  var state = { mode: 'student', view: 'home' };
  var host = document.getElementById('v-page');
  var homeView = document.getElementById('v-home');
  var navList = document.getElementById('nav-list');
  var segBtns = document.querySelectorAll('.seg button');
  var mainEl = document.getElementById('main');


  // ===== انتقال تبديل الوضع (منفصل عن المقدمة #intro) =====
  // يُستدعى فقط من نقرة المستخدم على المبدّل (انظر مستمع segBtns). لا يُستدعى من التحميل ولا من initUI ولا من go() ولا من إعادة الرسم.
  // لا يستخدم inert ولا يلمس حالة المقدمة؛ الحالة (الوضع والصف والصفحة) تتغير فوراً تحت الطبقة، والطبقة شكلية فقط.
  var fxEl = document.getElementById('mode-fx');
  var fxSkip = document.getElementById('skip-fx');
  var fxLabel = document.getElementById('fx-label');
  var fxTimer = null;

  function endModeFx() {
    clearTimeout(fxTimer); fxTimer = null;
    if (!fxEl || fxEl.hidden) return;
    var wasRep = fxEl.getAttribute('data-to') === 'rep';
    fxEl.hidden = true;
    fxEl.removeAttribute('data-to');
    fxEl.style.pointerEvents = '';
    if (wasRep && intro.hidden) {
      var t = document.getElementById(state.view === 'home' ? 'welcome' : 'page-title');
      if (t) t.focus({ preventScroll: true });
    }
  }
  function playModeFx(to) {
    if (!fxEl || !intro.hidden) return; // لا نعرضه فوق المقدمة الرئيسية
    if (reduce) { say(to === 'rep' ? 'وضع ممثل الصف' : 'وضع الطالب'); return; } // حركة مخفّفة: إعلان نصي بلا طبقة بصرية
    endModeFx();
    fxLabel.textContent = to === 'rep' ? 'وضع ممثل الصف' : 'وضع الطالب';
    fxEl.setAttribute('data-to', to);
    fxEl.hidden = false;
    void fxEl.offsetWidth; // إعادة تشغيل الحركة
    if (to === 'rep' && !reduce) fxSkip.tabIndex = 0; else fxSkip.tabIndex = -1;
    var ms = reduce ? 260 : (to === 'rep' ? 1500 : 560);
    fxTimer = setTimeout(endModeFx, ms + 80); // مؤقت أمان: لا تبقى طبقة بعد الانتهاء مهما حدث
  }
  if (fxSkip) fxSkip.addEventListener('click', endModeFx);
  if (fxEl) fxEl.addEventListener('click', function () { if (fxEl.getAttribute('data-to') === 'rep') endModeFx(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && fxEl && !fxEl.hidden) endModeFx(); });

  function mk(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt != null) e.textContent = txt;
    return e;
  }
  var NS = 'http://www.w3.org/2000/svg';
  var TILE_ICONS = {
    classes: 'M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6',
    students: 'M16 20v-1a4 4 0 00-4-4H8a4 4 0 00-4 4v1M10 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM20 20v-1a4 4 0 00-3-3.8M16 4.2a3.5 3.5 0 010 6.6',
    'r-schedule': 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4M8 14h3M13 14h3M8 17h3',
    'r-lessons': 'M4 19.5A2.5 2.5 0 016.5 17H20V3H6.5A2.5 2.5 0 004 5.5zM8 7h8M8 11h6',
    'r-prep': 'M4 20l1-4L16 5l3 3L8 19zM14 7l3 3',
    'r-exams': 'M6 3h9l4 4v14H6zM9 14l2 2 4-4',
    'r-grades': 'M5 20V6M5 20h14M9 16V11M13 16V8M17 16v-3',
    'r-news': 'M6 17V11a6 6 0 0112 0v6l2 2H4zM10 21h4',
    attendance: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4M9 15l2 2 4-4',
    payments: 'M3 7h18v12H3zM3 11h18M7 15h3',
    reports: 'M5 20V10M12 20V4M19 20v-7',
    'r-settings': 'M4 7h10M18 7h2M4 17h2M10 17h10M14 5v4M6 15v4'
  };
  function svgIcon(d) {
    var sv = document.createElementNS(NS, 'svg'), p = document.createElementNS(NS, 'path');
    sv.setAttribute('viewBox', '0 0 24 24'); sv.setAttribute('class', 'ico'); sv.setAttribute('aria-hidden', 'true');
    p.setAttribute('d', d); sv.appendChild(p);
    return sv;
  }
  function emptyBlock(title) {
    var p = mk('p', 'empty');
    p.appendChild(mk('strong', null, title));
    p.appendChild(document.createTextNode(LATER));
    return p;
  }

  function renderPage(id) {
    var v = V[id], start = MODES[state.mode].start;
    host.textContent = '';
    var head = mk('div', 'page-head');
    if (id !== start) {
      var target = parentOf(id) || start;
      var back = mk('button', 'back', 'رجوع إلى ' + V[target].nav);
      back.type = 'button';
      back.addEventListener('click', function () { go(target); });
      head.appendChild(back);
    }
    var t = mk('h1', null, v.t);
    t.id = 'page-title'; t.tabIndex = -1;
    head.appendChild(t);
    head.appendChild(mk('p', null, v.d));
    if (v.priv) head.appendChild(mk('span', 'priv', 'خاص بك وحدك: لا تُعرض هنا بيانات أي طالب آخر.'));
    if (v.a) {
      var act = mk('div', 'act'), b = mk('button', 'btn', v.a);
      b.type = 'button'; b.disabled = true;
      act.appendChild(b);
      act.appendChild(mk('span', 'soon', 'يُفعّل في مرحلة لاحقة'));
      head.appendChild(act);
    }
    host.appendChild(head);

    if (v.kind === 'roster') renderRoster();
    if (v.kind === 'deleted') renderDeleted();
    if (v.kind === 'detail') renderDetail();
    if (v.kind === 'classes') renderClasses();
    if (v.kind === 'lessons') renderLessons();
    if (v.kind === 'preps') renderPreps();
    if (v.kind === 'exams') renderExams();
    if (v.kind === 'attendance') renderAttendance();
    if (v.kind === 'grades') renderGrades();
    if (v.kind === 'payments') renderPayments();
    if (v.kind === 'stGrades') renderStudentGrades();
    if (v.kind === 'stAbsence') renderStudentAbsence();
    if (v.kind === 'schedule') renderSchedule();
    if (v.kind === 'stPreps') renderStudentPreps();
    if (v.kind === 'stArchive') renderStudentArchive();
    if (v.kind === 'stSchedule') renderStudentSchedule();
    if (v.kind === 'stExams') renderStudentExams();
    if (v.kind === 'tiles') {
      var grid = mk('div', 'tiles');
      ['classes'].concat(MODES.rep.views).forEach(function (k) {
        if (k === 'dash') return;
        var tb = mk('button', 'tile');
        tb.type = 'button';
        var tx = mk('span', 'tt');
        if (TILE_ICONS[k]) tb.appendChild(svgIcon(TILE_ICONS[k]));
        tx.appendChild(mk('b', null, V[k].t));
        tx.appendChild(mk('span', null, V[k].d + (k === 'students' ? ' (الفعّالون: ' + activeList().length + ')' : '')));
        tb.appendChild(tx);
        tb.addEventListener('click', function () { go(k); });
        grid.appendChild(tb);
      });
      host.appendChild(grid);
      host.appendChild(repSummary());
    }
    if (v.kind === 'settings') {
      var list = mk('div', 'part');
      var addRow = function (label, desc, btnText, fn) {
        var r = mk('div', 'row'), d = mk('div');
        d.appendChild(mk('b', null, label));
        d.appendChild(mk('div', 'muted', desc));
        var bb = mk('button', 'link', btnText);
        bb.type = 'button';
        bb.addEventListener('click', fn);
        r.appendChild(d); r.appendChild(bb);
        list.appendChild(r);
      };
      addRow('المقدمة', 'عرض مقدمة مَرسى مرة أخرى.', 'إعادة التشغيل', openIntro);
      if (state.mode === 'rep') addRow('الطلاب المحذوفون', 'راجع الطلاب المؤرشفين واستعدهم عند الحاجة.', 'فتح', function () { go('deleted'); });
      host.appendChild(list);
      if (state.mode === 'student') host.appendChild(repCodePart());
      var det = mk('details', 'dev');
      det.appendChild(mk('summary', null, 'ملاحظة للمطور'));
      det.appendChild(mk('p', null, DEV_NOTE));
      host.appendChild(det);
    }
    (v.p || []).forEach(function (part) {
      var s = mk('section', 'part');
      s.appendChild(mk('h2', null, part[0]));
      s.appendChild(emptyBlock(part[1]));
      host.appendChild(s);
    });
  }

  // قسم «الرمز التجريبي» في إعدادات وضع الطالب فقط، وهو المكان الوحيد لحقل الرمز
  function repCodePart() {
    var part = mk('section', 'part rep-code');
    part.appendChild(mk('h2', null, 'وضع ممثل الصف (تجريبي)'));
    part.appendChild(mk('p', 'muted', 'حاجز تجريبي لاختبار الواجهة فقط وليس تسجيل دخول ولا حماية للبيانات. وضع ممثل الصف في هذه النسخة المحلية ليس صلاحية أمنية فعلية: أي شخص يستخدم هذا الجهاز يستطيع قراءة التخزين المحلي وتعديله من أدوات المتصفح. يُطلب الرمز من جديد بعد كل إعادة تحميل للصفحة.'));
    var msg = mk('p', 'muted code-msg');
    msg.setAttribute('role', 'status');
    msg.setAttribute('aria-live', 'polite');
    if (repModeAvailable()) {
      msg.textContent = 'تم السماح بوضع ممثل الصف في هذه الجلسة. يظهر المبدّل أعلى الصفحة.';
      part.appendChild(msg);
      var off = mk('button', 'link', 'إيقاف السماح');
      off.type = 'button';
      off.addEventListener('click', function () { lockRep(); say('أُوقف السماح بوضع ممثل الصف.'); refreshSettings(); });
      part.appendChild(off);
      return part;
    }
    var lab = mk('label', null, 'رمز التجربة');
    lab.setAttribute('for', 'rep-code-in');
    var inp = mk('input', 'field');
    inp.id = 'rep-code-in'; inp.type = 'text'; inp.maxLength = 40;
    inp.setAttribute('dir', 'ltr');
    inp.setAttribute('autocomplete', 'off'); inp.setAttribute('autocapitalize', 'characters');
    inp.setAttribute('autocorrect', 'off'); inp.setAttribute('spellcheck', 'false');
    inp.setAttribute('enterkeyhint', 'done');
    inp.setAttribute('aria-describedby', 'rep-code-msg');
    msg.id = 'rep-code-msg';
    var btn = mk('button', 'primary', 'تفعيل');
    btn.type = 'button';
    var submit = function () {
      if (tryUnlockRep(inp.value)) {
        inp.value = '';
        say('تم السماح بوضع ممثل الصف في هذه الجلسة.');
        refreshSettings();
      } else {
        inp.value = '';
        inp.setAttribute('aria-invalid', 'true');
        msg.textContent = 'الرمز غير صحيح. تأكد من الرمز التجريبي وأعد المحاولة.';
        inp.focus();
      }
    };
    btn.addEventListener('click', submit);
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
    inp.addEventListener('input', function () { inp.removeAttribute('aria-invalid'); msg.textContent = ''; });
    part.appendChild(lab); part.appendChild(inp); part.appendChild(msg); part.appendChild(btn);
    return part;
  }
  function refreshSettings() { if (state.view === 'settings') renderPage('settings'); }

  function renderNav() {
    var active = navOf(state.view);
    navList.textContent = '';
    MODES[state.mode].views.forEach(function (id) {
      var li = mk('li'), b = mk('button', null, V[id].nav);
      b.type = 'button';
      if (id === active) b.setAttribute('aria-current', 'page');
      b.addEventListener('click', function () { go(id); });
      li.appendChild(b);
      navList.appendChild(li);
    });
    var cur = navList.querySelector('[aria-current]');
    if (cur && cur.scrollIntoView) cur.scrollIntoView({ inline: 'center', block: 'nearest' });
    navFade();
  }
  // مؤشر بصري على أن الشريط العلوي قابل للتمرير الأفقي: تلاشٍ عند الطرف الذي فيه عناصر مخفية (يعمل مع RTL: scrollLeft سالب أو موجب)
  function navFade() {
    var nav = navList.parentNode, max = navList.scrollWidth - navList.clientWidth, pos = Math.abs(navList.scrollLeft);
    if (max < 4) { nav.classList.remove('more-start', 'more-end'); return; }
    nav.classList.toggle('more-start', pos > 4);
    nav.classList.toggle('more-end', pos < max - 4);
  }
  navList.addEventListener('scroll', navFade, { passive: true });
  window.addEventListener('resize', navFade);

  function savePrefs() { try { var inRep = state.mode === 'rep'; localStorage.setItem(PREF_KEY, JSON.stringify({ mode: 'student', view: inRep ? 'home' : state.view })); } catch (e) { /* تجاهل */ } } // وضع الممثل لا يُحفظ أبداً
  function loadPrefs() { try { var p = JSON.parse(localStorage.getItem(PREF_KEY) || 'null'); return p && typeof p === 'object' ? p : null; } catch (e) { return null; } }

  function go(id, noFocus) {
    // الحضور: مسودة غير محفوظة لا تُفقد بصمت عند مغادرة الصفحة (الانتقال داخل وضع الممثل)
    if (state.mode === 'rep' && state.view === 'attendance' && id !== 'attendance' && attCtl && attCtl.dirty()) {
      askConfirm('تجاهل الحضور غير المحفوظ؟', 'في صفحة الحضور تغييرات لم تُحفظ بعد. إن غادرت الصفحة فستُفقد.', 'تجاهل والمتابعة', function () { attCtl = null; go(id, noFocus); });
      return;
    }
    if (state.mode === 'rep' && state.view === 'r-grades' && id !== 'r-grades' && grCtl && grCtl.dirty()) {
      askConfirm('تجاهل بيانات الدرجة غير المحفوظة؟', 'في نموذج الدرجات بيانات لم تُحفظ بعد. إن غادرت الصفحة فستُفقد.', 'تجاهل والمتابعة', function () { grCtl = null; go(id, noFocus); });
      return;
    }
    if (state.mode === 'rep' && state.view === 'payments' && id !== 'payments' && payCtl && payCtl.dirty()) {
      askConfirm('تجاهل بيانات الدفعة غير المحفوظة؟', 'في نموذج المدفوعات بيانات لم تُحفظ بعد. إن غادرت الصفحة فستُفقد.', 'تجاهل والمتابعة', function () { payCtl = null; go(id, noFocus); });
      return;
    }
    // حارس إضافي: لا انتقال إلى أي صفحة من وضع الممثل ما لم يكن الوضع مسموحاً ونشطاً
    if (state.mode === 'rep' && !repModeAvailable()) { setMode('student'); return; }
    if (V[id] && state.mode !== 'rep' && MODES.rep.views.indexOf(navOf(id)) > -1) id = MODES[state.mode].start;
    if (!V[id]) id = MODES[state.mode].start;
    state.view = id;
    document.documentElement.setAttribute('data-view', id);
    var isHome = id === 'home';
    if (isHome) renderHome(true); // لوحة اليوم تُقرأ من التخزين عند كل عرض للرئيسية (بعد التعديل أو الرجوع)
    homeView.hidden = !isHome;
    host.hidden = isHome;
    // 4.05: عند العودة للرئيسية (وضع الطالب خصوصاً) يُفرَّغ جسم صفحة الممثل المخفية فلا تبقى في DOM درجات أو حضور أو مبالغ لصفحة سابقة
    if (isHome) host.textContent = '';
    if (!isHome) renderPage(id);
    renderNav();
    var shown = isHome ? homeView : host;
    shown.classList.remove('view-in'); void shown.offsetWidth; shown.classList.add('view-in');
    savePrefs();
    document.title = (isHome ? '' : V[id].t + ' — ') + 'مَرسى | MARSA';
    window.scrollTo(0, 0);
    if (!noFocus) {
      var t = document.getElementById(isHome ? 'welcome' : 'page-title');
      if (t) t.focus({ preventScroll: true });
    }
  }

  // ===== بوابة وضع ممثل الصف (حاجز تجريبي للواجهة فقط) =====
  // تحذير: هذا ليس تسجيل دخول ولا حماية. أي رمز في JavaScript يمكن لأي شخص قراءته أو تجاوزه من أدوات المتصفح،
  // فلا يحمي أي بيانات. يجب استبداله بمصادقة وصلاحيات على الخادم عند مرحلة المزامنة.
  // الرمز التجريبي موجود في هذا السطر وحده ولا يُكتب في أي مكان آخر من الكود.
  var REP_DEMO_CODE = 'MRS-REP-DEMO-26';
  // حالة السماح في ذاكرة الصفحة فقط: لا تُحفظ في localStorage ولا sessionStorage ولا أي ملف، وتزول بإعادة التحميل.
  var repUnlocked = false;
  // كل الطرق إلى وضع الممثل تمر عبر هذه الدالة (setMode وgo وrepModeAvailable تعتمد عليها)
  function repModeAvailable() { return repUnlocked === true; }
  function normCode(x) { return String(x == null ? '' : x).replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '').trim().toUpperCase(); }
  // دالة التحقق الوحيدة: تقارن الإدخال بالرمز التجريبي وتحدّث الحالة المؤقتة
  function tryUnlockRep(input) {
    if (normCode(input) === REP_DEMO_CODE) { repUnlocked = true; applyModeAvailability(); return true; }
    return false;
  }
  function lockRep() {
    repUnlocked = false;
    applyModeAvailability();
    if (state.mode === 'rep') setMode('student');
  }
  function applyModeAvailability() {
    var seg = document.querySelector('.seg');
    if (seg) seg.hidden = !repModeAvailable();
    segBtns.forEach(function (b) { if (b.getAttribute('data-m') === 'rep') b.hidden = !repModeAvailable(); });
  }

  function setMode(m, quiet) {
    if (!MODES[m] || (m === 'rep' && !repModeAvailable())) m = 'student';
    if (!quiet && m === state.mode) return;
    // 4.08: مغادرة وضع الممثل بمسودة غير محفوظة (حضور أو درجة أو دفعة) كانت تُفقد بصمت لأن حارس go() يتحقق من state.mode وقد تغيّر؛ نسأل أولاً
    if (!quiet && state.mode === 'rep' && m !== 'rep' && repModeAvailable()) {
      var dr = state.view === 'attendance' && attCtl && attCtl.dirty() ? ['الحضور', function () { attCtl = null; }]
        : state.view === 'r-grades' && grCtl && grCtl.dirty() ? ['بيانات الدرجة', function () { grCtl = null; }]
        : state.view === 'payments' && payCtl && payCtl.dirty() ? ['بيانات الدفعة', function () { payCtl = null; }] : null;
      if (dr) {
        askConfirm('تجاهل ' + dr[0] + ' غير المحفوظ؟', 'في هذه الصفحة تغييرات لم تُحفظ بعد. إن انتقلت إلى وضع الطالب فستُفقد.', 'تجاهل والمتابعة', function () { var prev = state.mode; dr[1](); setMode(m, quiet); if (state.mode !== prev) playModeFx(state.mode); });
        return;
      }
    }
    state.mode = m;
    document.documentElement.setAttribute('data-mode', m);
    var sync = function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-m') === m)); };
    segBtns.forEach(sync);
    go(MODES[m].start, quiet);
  }

  function initUI() {
    applyModeAvailability();
    loadClasses();
    migrateAllRosters();
    loadRoster();
    renderClassUI();
    var p = loadPrefs();
    if (p && p.view === 'student-detail') p.view = 'students';
    // نبدأ دائماً في وضع الطالب حتى لو حملت التفضيلات القديمة mode: rep
    var m = 'student';
    setMode(m, true);
    var v = p && p.mode !== 'rep' && V[p.view];
    if (v && MODES[m].views.indexOf(navOf(p.view)) > -1) go(p.view, true);
  }

  // ===== إدارة الطلاب: بيانات محلية في هذا المتصفح فقط، غير مشتركة مع أي جهاز آخر =====
  // كل طالب له studentId ثابت وstudentCode شخصي ثابت (الإصدار 2 من سجل القائمة). رقم القائمة يُحسب للعرض فقط ولا يُخزَّن ولا يُستعمل مفتاحاً.
  // أي سجل مستقبلي (غياب/درجات/مدفوعات) يجب أن يشير إلى studentId.
  var STORE_KEY = 'marsa.roster', SCHEMA = 2, MAX_NAME = 80;
  var roster = { schemaVersion: SCHEMA, classId: null, students: [] };
  var storeMsg = '', readOnlyStore = false, addBusy = false, curRosterKey = null;
  var collator = null;
  try { collator = new Intl.Collator('ar', { sensitivity: 'base', numeric: true }); } catch (e) { collator = null; }
  var dlgAdd = document.getElementById('dlg-add'), addBox = document.getElementById('dlg-add-body');
  var dlgConf = document.getElementById('dlg-confirm'), confBox = document.getElementById('dlg-confirm-body');

  // صياغة العدد العربية: 1 مفرد، 2 مثنى، 3–10 جمع، 11 فأكثر تمييز مفرد منصوب. f = [مفرد، مثنى، جمع، تمييز]
  function countPeriods(n) { return n === 0 ? 'لا حصص' : n === 1 ? 'حصة واحدة' : n === 2 ? 'حصتان' : n <= 10 ? n + ' حصص' : n + ' حصة'; }
  function plural(n, f) { return n === 1 ? f[0] : n === 2 ? f[1] : n + ' ' + (n <= 10 ? f[2] : f[3]); }
  var F_NAME = ['اسم واحد', 'اسمان', 'أسماء', 'اسماً'], F_STU = ['طالب واحد', 'طالبين', 'طلاب', 'طالباً'];
  function cmpAr(a, b) { return collator ? collator.compare(a, b) : (a < b ? -1 : a > b ? 1 : 0); }
  function byName(a, b) { return cmpAr(a.name, b.name) || (a.studentId < b.studentId ? -1 : 1); }
  function cleanName(s) { return String(s).replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '').replace(/\s+/g, ' ').trim(); }
  // مفتاح مقارنة: يوحّد الألف والياء والتاء المربوطة ويزيل التشكيل والتطويل
  function simKey(s) { return cleanName(s).replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase(); }
  function within1(a, b) {
    var la = a.length, lb = b.length, i = 0;
    if (a === b) return true;
    if (Math.abs(la - lb) > 1) return false;
    while (i < la && i < lb && a[i] === b[i]) i++;
    if (la === lb) return a.slice(i + 1) === b.slice(i + 1);
    return la > lb ? a.slice(i + 1) === b.slice(i) : b.slice(i + 1) === a.slice(i);
  }
  function validDate(x) { return typeof x === 'string' && !isNaN(Date.parse(x)) ? x : null; }
  function fmtDate(iso) {
    if (!iso) return 'غير معروف';
    try { return new Intl.DateTimeFormat('ar-u-nu-latn', { dateStyle: 'medium' }).format(new Date(iso)); } catch (e) { return String(iso).slice(0, 10); }
  }
  function newId(used) {
    var id, r, a, i;
    do {
      if (window.crypto && crypto.randomUUID) { id = crypto.randomUUID(); }
      else {
        r = '';
        if (window.crypto && crypto.getRandomValues) { a = new Uint8Array(12); crypto.getRandomValues(a); for (i = 0; i < a.length; i++) r += ('0' + a[i].toString(16)).slice(-2); }
        else r = Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2);
        id = 'stu-' + Date.now().toString(36) + '-' + r;
      }
    } while (used[id]);
    return id;
  }

  // كل صف له سجل قائمة مستقل يحمل classId صريحاً: { schemaVersion, classId, students: [...] }.
  // الصف التجريبي يبقى على المفتاح القديم marsa.roster؛ بقية الصفوف على marsa.roster.<classId>.
  // لا تُعرض قائمة إلا إذا طابق classId داخل السجل الصف المطلوب، ولا يُكتب فوق بيانات غير مفهومة.
  var MSG_UNSAVED = 'تعذّر الحفظ في تخزين المتصفح، فما تراه الآن مؤقت.';
  var memRosters = {}; // قوائم لم تُحفظ بسبب تعذّر التخزين: تبقى في الذاكرة حتى لا تضيع عند تبديل الصف
  function rosterKeyFor(id) { return id === DEMO_ID ? STORE_KEY : STORE_KEY + '.' + id; }
  // نسخة خام احتياطية: لا تُكتب فوق نسخة سابقة مختلفة، ولا تتكرر إن كانت محفوظة أصلاً
  function backupRaw(key, raw) {
    var base = key + '.backup', i, k;
    try {
      for (i = 0; i < localStorage.length; i++) { k = localStorage.key(i); if (k && k.indexOf(base) === 0 && localStorage.getItem(k) === raw) return; }
      localStorage.setItem(localStorage.getItem(base) === null ? base : base + '.' + Date.now().toString(36), raw);
    } catch (e) { /* تجاهل */ }
  }
  function lockRoster(key, raw, msg) { backupRaw(key, raw); readOnlyStore = true; storeMsg = msg + ' لم يُعدَّل شيء ولم يُكتب فوق البيانات الأصلية، وحُفظت نسخة خام احتياطية. الإضافة والتعديل متوقفان على هذه القائمة حتى تُعالَج البيانات.'; }
  // ===== الأكواد الشخصية (studentCode) =====
  // الصيغة MR-XXXXXX من أبجدية بلا حروف وأرقام متشابهة (بلا I وL وO و0 و1) لتسهل القراءة والنسخ.
  // الكود معرّف للطالب وليس سراً ولا كلمة مرور. يُولَّد مرة واحدة عند إنشاء الطالب (أو عند ترحيل بيانات قديمة)
  // ثم يُحفظ كما هو، ولا يُشتق من الاسم ولا من رقم القائمة ولا من الصف، فلا يتغير بتغيّرها. لا يُسجَّل في console ولا يُوضع في رابط.
  var CODE_CHARS = '23456789ABCDEFGHJKMNPQRSTUVWXYZ', CODE_LEN = 6, CODE_RE = /^MR-[23456789A-HJKMNP-Z]{6}$/;
  var fbCounter = 0;
  function codeKey(c) { return String(c).toUpperCase(); }
  function randomCode() {
    var out = '', cr = window.crypto || window.msCrypto, bytes, hex, i, b, guard = 0;
    while (out.length < CODE_LEN && guard++ < 500) {
      try {
        if (cr && cr.getRandomValues) {
          bytes = new Uint8Array(16); cr.getRandomValues(bytes);
          // رفض القيم >= 248 يمنع انحياز القسمة على 31
          for (i = 0; i < bytes.length && out.length < CODE_LEN; i++) if (bytes[i] < 248) out += CODE_CHARS.charAt(bytes[i] % 31);
          continue;
        }
        if (cr && cr.randomUUID) {
          hex = cr.randomUUID().replace(/-/g, '');
          for (i = 0; i + 1 < hex.length && out.length < CODE_LEN; i += 2) { b = parseInt(hex.substr(i, 2), 16); if (b < 248) out += CODE_CHARS.charAt(b % 31); }
          continue;
        }
      } catch (e) { cr = null; }
      // بديل أخير لمتصفح قديم بلا مولّد آمن: يكفي للتعريف (التفرّد يضمنه فحص التصادم) ولا يصلح سراً أو كلمة مرور
      fbCounter++;
      out += CODE_CHARS.charAt((Math.floor(Math.random() * 31) + fbCounter + (new Date().getTime() % 31)) % 31);
    }
    if (out.length < CODE_LEN) throw new Error('code-gen');
    return 'MR-' + out;
  }
  // يعيد التوليد عند أي تصادم؛ avoid = كل ما هو مستعمل (حتى في النسخ الاحتياطية)، claimed = ما حُجز في هذه العملية
  function newCode(avoid, claimed) {
    var i, c;
    for (i = 0; i < 2000; i++) { c = randomCode(); if (!avoid[c] && !(claimed && claimed[c])) return c; }
    throw new Error('code-unique');
  }
  // كل الأكواد الموجودة في أي قائمة طلاب (كل الصفوف، المؤرشفة، التالفة القابلة للقراءة، والنسخ الاحتياطية، والذاكرة).
  // live: قوائم فعلية مرحَّلة فقط (بلا النسخ الاحتياطية)، all: كل شيء. لا يُعاد تدوير كود أُعطي لطالب سابق حتى لو بقي في نسخة احتياطية.
  function scanCodes(skipKey) {
    var out = { live: {}, all: {} }, i, k, raw, d, bak;
    function addList(list, live) {
      (list || []).forEach(function (s) {
        var c;
        if (s && typeof s.studentCode === 'string' && s.studentCode) { c = codeKey(s.studentCode); out.all[c] = 1; if (live) out.live[c] = 1; }
      });
    }
    try {
      for (i = 0; i < localStorage.length; i++) {
        k = localStorage.key(i);
        if (!k || k.indexOf(STORE_KEY) !== 0) continue;
        bak = /\.(backup|premigrate-v1)/.test(k);
        if (!bak && k === skipKey) continue;
        raw = localStorage.getItem(k);
        if (!raw) continue;
        try { d = JSON.parse(raw); } catch (e) { continue; }
        // live = قوائم مرحَّلة فعلاً فقط: قائمة قديمة لم يُحسم أمرها بعد لا تحجز أكواداً على غيرها، فيحتفظ الصف الأول المعالَج بكوده
        if (d && Array.isArray(d.students)) addList(d.students, !bak && typeof d.schemaVersion === 'number' && d.schemaVersion >= SCHEMA);
      }
    } catch (e) { /* التخزين غير متاح: نكتفي بالذاكرة */ }
    Object.keys(memRosters).forEach(function (cid) { if (rosterKeyFor(cid) !== skipKey) addList(memRosters[cid].students, true); });
    return out;
  }
  // يمنح كل طالب بلا كود صالح كوداً جديداً. الأكواد الصالحة الفريدة تبقى كما هي.
  // fillOnly=true: لا يُفحص تصادم الأكواد الصالحة مع الصفوف الأخرى (حارس عند الحفظ لا يغيّر كوداً قائماً).
  function assignCodes(students, skipKey, fillOnly) {
    var scan = scanCodes(skipKey), claimed = {}, res = { generated: 0, replaced: 0, changed: false }, need = [];
    students.forEach(function (s) {
      var c = typeof s.studentCode === 'string' ? s.studentCode : '', k = codeKey(c);
      if (CODE_RE.test(c) && !claimed[k] && (fillOnly || !scan.live[k])) { claimed[k] = 1; return; }
      need.push(s);
    });
    need.forEach(function (s) {
      var nc = newCode(scan.all, claimed);
      if (s.studentCode) res.replaced++; else res.generated++;
      claimed[nc] = 1; s.studentCode = nc;
    });
    res.changed = need.length > 0;
    return res;
  }

  // قراءة سجل قائمة خام دون لمس الحالة العامة: st = ok | corrupt | foreign | newer
  function parseRoster(raw, cid) {
    var data, seen = {}, out = { st: 'ok', students: [], dropped: 0, schemaVersion: 0 };
    try { data = JSON.parse(raw); } catch (e) { data = null; }
    if (!data || typeof data !== 'object' || Array.isArray(data) || !Array.isArray(data.students) || typeof data.schemaVersion !== 'number') return { st: 'corrupt' };
    // ربط صريح بالصف: سجل الصف التجريبي القديم بلا classId يُعدّ تابعاً له ويُختم عند أول حفظ
    if (!(data.classId === cid || (cid === DEMO_ID && (data.classId === undefined || data.classId === null)))) return { st: 'foreign', other: data.classId };
    out.schemaVersion = data.schemaVersion;
    if (data.schemaVersion > SCHEMA) out.st = 'newer';
    data.students.forEach(function (s) {
      var name = s && typeof s.name === 'string' ? cleanName(s.name) : '';
      var id = s && typeof s.studentId === 'string' ? s.studentId : '';
      if (!name || !id || seen[id] || !s || (s.status !== 'active' && s.status !== 'archived')) { out.dropped++; return; }
      seen[id] = 1;
      var rec = { studentId: id, name: name, status: s.status, createdAt: validDate(s.createdAt), archivedAt: s.status === 'archived' ? validDate(s.archivedAt) : null };
      if (typeof s.studentCode === 'string' && s.studentCode) rec.studentCode = s.studentCode;
      out.students.push(rec);
    });
    return out;
  }

  // ----- الكتابة الآمنة والترحيل -----
  // نسخة من البيانات الأصلية قبل أول ترحيل: لا تُكتب فوق نسخة مختلفة ولا تُحذف تلقائياً. true فقط إن قُرئت مطابقة بعد الكتابة.
  function backupOriginal(key, raw) {
    var base = key + '.premigrate-v1', i, k, name;
    for (i = 0; i < localStorage.length; i++) { k = localStorage.key(i); if (k && k.indexOf(base) === 0 && localStorage.getItem(k) === raw) return true; }
    name = localStorage.getItem(base) === null ? base : base + '.' + new Date().getTime().toString(36);
    localStorage.setItem(name, raw);
    return localStorage.getItem(name) === raw;
  }
  // يكتب السجل ثم يقرأه ويقارنه. إن مُرّر orig (الخام القديم) تُحفظ منه نسخة أولاً ولا تُكتب البيانات الجديدة إن فشلت النسخة.
  // النتيجة: ok | fail | stale (تغيّر المخزن من مكان آخر أثناء العملية). 'ok' وحدها تعني أن الحفظ نجح وتم التحقق منه.
  function commitRoster(key, rec, orig) {
    var prev, json, back;
    try {
      prev = localStorage.getItem(key);
      if (orig !== null && orig !== undefined) {
        if (prev !== orig) return 'stale';
        if (!backupOriginal(key, orig)) return 'fail';
      }
      json = JSON.stringify(rec);
      localStorage.setItem(key, json);
      back = localStorage.getItem(key);
      if (back === json) return 'ok';
      if (prev !== null) localStorage.setItem(key, prev); // فشل التحقق: نعيد ما كان
      return 'fail';
    } catch (e) { return 'fail'; }
  }
  var pendingOrig = {}; // الخام القديم لقوائم رُحِّلت في الذاكرة ولم تُحفظ بعد: تؤخذ منه نسخة احتياطية قبل أول حفظ ناجح
  var migNotes = [];
  function migrateOne(cid) {
    var key = rosterKeyFor(cid), raw, p, res, rec, r, c = getClass(cid), lbl = c ? '«' + classLabel(c) + '»' : cid;
    if (memRosters[cid]) return;
    try { raw = localStorage.getItem(key); } catch (e) { return; }
    if (raw === null) return;
    p = parseRoster(raw, cid);
    if (p.st !== 'ok') return; // تالف أو لصف آخر أو بنسخة أحدث: لا يُلمس هنا (تظهر رسالته عند فتح الصف)
    res = assignCodes(p.students, key, false);
    if (p.schemaVersion >= SCHEMA && !res.changed) return;
    rec = { schemaVersion: SCHEMA, classId: cid, students: p.students };
    r = commitRoster(key, rec, raw);
    if (r === 'stale') return; // غيّره تبويب آخر في اللحظة نفسها؛ يُعاد الفحص عند حدث التخزين أو إعادة التحميل
    if (r !== 'ok') {
      memRosters[cid] = rec; pendingOrig[cid] = raw;
      migNotes.push('تعذّر حفظ الأكواد الشخصية لطلاب الصف ' + lbl + ' في تخزين المتصفح. الأكواد المعروضة مؤقتة وستتغيّر عند إعادة فتح الصفحة، فلا تعتمد عليها. بياناتك الأصلية لم تُمسّ.');
      return;
    }
    if (p.dropped) migNotes.push('الصف ' + lbl + ': استُبعد ' + p.dropped + ' سجل غير صالح من القائمة عند الترحيل، وبقيت النسخة الأصلية الكاملة محفوظة في المتصفح باسم ' + key + '.premigrate-v1.');
    if (res.replaced) migNotes.push('الصف ' + lbl + ': استُبدل ' + res.replaced + ' كود موجود مسبقاً لأنه غير صالح أو مكرر، لضمان تفرّد الأكواد.');
  }
  // ترحيل كل قوائم الصفوف (الفعّالة والمؤرشفة) قبل عرض أي شيء، حتى تُوزَّع الأكواد على الجميع دفعة واحدة وبلا تكرار
  function migrateAllRosters() {
    var ids = classes.classes.map(function (c) { return c.classId; }).sort(function (a, b) { return a === DEMO_ID ? -1 : b === DEMO_ID ? 1 : (a < b ? -1 : a > b ? 1 : 0); });
    migNotes = [];
    ids.forEach(function (id) {
      try { migrateOne(id); }
      catch (e) { migNotes.push('تعذّر ترحيل قائمة أحد الصفوف (' + id + ') ولم يُغيَّر فيها شيء.'); }
    });
  }

  function loadRoster() {
    var raw = null, p, cid = activeId(), key;
    storeMsg = ''; readOnlyStore = false;
    roster = { schemaVersion: SCHEMA, classId: cid, students: [] };
    curRosterKey = null;
    if (!cid) return;
    key = curRosterKey = rosterKeyFor(cid);
    if (memRosters[cid]) { roster = memRosters[cid]; storeMsg = MSG_UNSAVED; return; }
    try { raw = localStorage.getItem(key); } catch (e) { storeMsg = 'التخزين المحلي غير متاح في هذا المتصفح، لذلك ستُفقد القائمة عند إغلاق الصفحة.'; return; }
    if (raw === null) return; // صف جديد: قائمة فارغة حقيقية
    p = parseRoster(raw, cid);
    if (p.st === 'corrupt') { lockRoster(key, raw, 'تعذّرت قراءة قائمة طلاب هذا الصف لأن بياناتها تالفة أو غير معروفة البنية.'); return; }
    if (p.st === 'foreign') { lockRoster(key, raw, 'هذه القائمة مرتبطة بصف آخر (' + String(p.other).slice(0, 60) + ') وليست لهذا الصف، فلم تُعرض حتى لا تختلط الصفوف.'); return; }
    if (p.st === 'newer') { readOnlyStore = true; storeMsg = 'بيانات الطلاب محفوظة بنسخة أحدث من هذه الصفحة، لذلك لن تُعدَّل ولن يُكتب فوقها.'; }
    roster.students = p.students;
    if (p.dropped) { backupRaw(key, raw); storeMsg += (storeMsg ? ' ' : '') + 'تم تجاهل ' + p.dropped + ' سجل غير صالح عند قراءة البيانات، وحُفظت نسخة خام احتياطية بكل السجلات الأصلية.'; }
  }
  function saveRoster() {
    var cid = activeId(), res = 'fail', tries = 0, cur;
    if (readOnlyStore || !curRosterKey || !cid || roster.classId !== cid) return false;
    // حارس: أي سجل بلا كود صالح يُمنح كوداً قبل الحفظ، ولا يُغيَّر كود صالح قائم
    try { assignCodes(roster.students, curRosterKey, true); } catch (e) { memRosters[cid] = roster; storeMsg = MSG_UNSAVED; return false; }
    roster.schemaVersion = SCHEMA;
    while (tries++ < 2) {
      res = commitRoster(curRosterKey, roster, pendingOrig[cid] !== undefined ? pendingOrig[cid] : null);
      if (res !== 'stale') break;
      try { cur = localStorage.getItem(curRosterKey); } catch (e) { res = 'fail'; break; }
      if (cur === null) delete pendingOrig[cid]; else pendingOrig[cid] = cur;
    }
    if (res === 'ok') { delete memRosters[cid]; delete pendingOrig[cid]; if (storeMsg === MSG_UNSAVED) storeMsg = ''; return true; }
    memRosters[cid] = roster; storeMsg = MSG_UNSAVED;
    return false;
  }
  // كل studentId مستعمل في أي صف، ليبقى المعرّف فريداً عبر الصفوف
  function usedStudentIds() {
    var used = {};
    function add(list) { (list || []).forEach(function (s) { if (s && typeof s.studentId === 'string') used[s.studentId] = 1; }); }
    add(roster.students);
    classes.classes.forEach(function (c) {
      var raw, d;
      if (c.classId === activeId()) return;
      if (memRosters[c.classId]) { add(memRosters[c.classId].students); return; }
      try { raw = localStorage.getItem(rosterKeyFor(c.classId)); } catch (e) { return; }
      if (!raw) return;
      try { d = JSON.parse(raw); add(d && d.students); } catch (e) { /* تجاهل */ }
    });
    return used;
  }

  function activeList() { return roster.students.filter(function (s) { return s.status === 'active'; }).sort(byName); }
  function archivedList() { return roster.students.filter(function (s) { return s.status === 'archived'; }).sort(byName); }
  function findStudent(id) { for (var i = 0; i < roster.students.length; i++) if (roster.students[i].studentId === id) return roster.students[i]; return null; }
  function parentOf(id) {
    if (id === 'student-detail') { var s = findStudent(state.detailId); return s && s.status === 'archived' ? 'deleted' : 'students'; }
    return V[id].parent || null;
  }
  function navOf(id) {
    var p;
    while (MODES[state.mode].views.indexOf(id) < 0 && (p = parentOf(id))) id = p;
    return id;
  }
  function refreshView() {
    if (state.view === 'home') { renderHome(); return; } // لوحة اليوم: تُعاد قراءتها فقط إن تغيّرت البيانات أو اليوم أو الصف
    // صفحتا الطالب (التحاضير/الأرشيف) للقراءة فقط: لا نموذج مفتوح فيهما، وتُعيدان القراءة من المخزن نفسه
    if (state.view === 'prep' || state.view === 'archive' || state.view === 'schedule' || state.view === 'exams') { if (stCtl) stCtl.check(); else renderPage(state.view); return; }
    if (['students', 'deleted', 'student-detail', 'dash', 'classes', 'r-lessons', 'r-prep', 'r-schedule', 'r-exams', 'r-grades', 'attendance', 'payments'].indexOf(state.view) < 0) return;
    // نموذج سجل الدرس داخل الصفحة (لا نافذة): لا نُعيد رسمه من تحديث خلفي ما دام فيه نص غير محفوظ لنفس الصف
    if (state.view === 'r-lessons' && lessonsCtl && lessonsCtl.cid === activeId() && lessonsCtl.dirty()) return;
    if (state.view === 'r-prep' && prepsCtl && prepsCtl.cid === activeId() && prepsCtl.dirty()) return;
    if (state.view === 'r-schedule' && scheduleCtl && scheduleCtl.cid === activeId() && scheduleCtl.dirty()) return;
    if (state.view === 'r-exams' && examsCtl && examsCtl.cid === activeId() && examsCtl.dirty()) return;
    if (state.view === 'attendance' && attCtl && attCtl.cid === activeId() && attCtl.dirty()) return;
    if (state.view === 'r-grades' && grCtl && grCtl.cid === activeId() && grCtl.dirty()) return;
    if (state.view === 'payments' && payCtl && payCtl.cid === activeId() && payCtl.dirty()) return;
    renderPage(state.view); renderNav();
    var t = document.getElementById('page-title');
    if (t) t.focus({ preventScroll: true });
  }
  function blocked() { if (!activeClass()) { say('اختر صفاً نشطاً من «إدارة الصفوف» أولاً.'); return true; } if (readOnlyStore) { say(storeMsg); return true; } return false; }
  function report(msg, ok) { say(ok ? msg : msg + ' لكن تعذّر الحفظ في المتصفح، فالتغيير مؤقت.'); }

  // ----- تحليل الأسماء والمعاينة -----
  function parseNames(text) {
    var items = [], blanks = 0, tooLong = 0, pool = [];
    roster.students.forEach(function (s) { var k = simKey(s.name); pool.push({ key: k, tk: k.split(' ').sort().join(' '), name: s.name, where: s.status }); });
    String(text).split(/\r\n|\r|\n|\u2028|\u2029/).forEach(function (line) {
      var name = cleanName(line), k, tk, hit = null, i, p;
      if (!name) { blanks++; return; }
      if (name.length > MAX_NAME) { tooLong++; return; }
      k = simKey(name); tk = k.split(' ').sort().join(' ');
      for (i = 0; i < pool.length; i++) {
        p = pool[i];
        if (p.key === k) { hit = { kind: 'dup', w: p }; break; }
        if (!hit && (p.tk === tk || (k.length >= 6 && within1(k, p.key)))) hit = { kind: 'sim', w: p };
      }
      items.push({ name: name, match: hit });
      pool.push({ key: k, tk: tk, name: name, where: 'batch' });
    });
    return { items: items, blanks: blanks, tooLong: tooLong };
  }
  function addStudents(names) {
    var used = usedStudentIds(), now = new Date().toISOString(), sc = scanCodes(null), avoid = {}, claimed = {}, fresh = [], k;
    for (k in sc.all) avoid[k] = 1;
    roster.students.forEach(function (s) { if (s.studentCode) avoid[codeKey(s.studentCode)] = 1; });
    // تُولَّد كل الأكواد أولاً: إن تعذّر الإنشاء لا يُضاف أي طالب بنصف بيانات
    names.forEach(function (n) {
      var id = newId(used), code = newCode(avoid, claimed);
      used[id] = 1; claimed[code] = 1;
      fresh.push({ studentId: id, name: n, status: 'active', createdAt: now, archivedAt: null, studentCode: code });
    });
    fresh.forEach(function (st) { roster.students.push(st); });
    return saveRoster();
  }

  // ----- النوافذ -----
  function openDlg(d) { if (d.showModal) { if (!d.open) d.showModal(); } else d.setAttribute('open', ''); }
  function closeDlg(d) { if (d.close) d.close(); else d.removeAttribute('open'); }
  // 4.07: حماية المدخلات غير المحفوظة في نوافذ الإضافة. Escape لا يُغلق نافذة فيها كتابة دون تنبيه.
  function guardDlg(d) {
    d.addEventListener('cancel', function (ev) {
      if (d.getAttribute('data-dirty') !== '1') return;
      ev.preventDefault();
      askConfirm('تجاهل ما كتبته؟', 'في النافذة بيانات لم تُحفظ بعد. إن أغلقتها فستُفقد.', 'تجاهل والإغلاق', function () { d.removeAttribute('data-dirty'); closeDlg(d); });
    });
    d.addEventListener('close', function () { d.removeAttribute('data-dirty'); });
  }
  function markDirty(d, on) { if (on) d.setAttribute('data-dirty', '1'); else d.removeAttribute('data-dirty'); }
  function dlgHead(box, text, id) { box.textContent = ''; var t = mk('h2', null, text); t.id = id; t.tabIndex = -1; box.appendChild(t); return t; }
  function btn(cls, text, fn) { var b = mk('button', cls, text); b.type = 'button'; b.addEventListener('click', fn); return b; }

  function openAdd(prefill) { if (blocked()) return; markDirty(dlgAdd, false); addStep1(prefill || ''); openDlg(dlgAdd); }
  function addStep1(text) {
    dlgHead(addBox, 'إضافة طلاب', 'dlg-add-t');
    addBox.appendChild(mk('p', 'muted', 'اكتب اسم كل طالب في سطر مستقل (الاسم الثلاثي أو الكامل). Enter ينشئ سطراً جديداً ولا يحفظ شيئاً.'));
    var ta = mk('textarea', 'field'), msg = mk('p', 'muted'), tl = mk('label', 'fl', 'أسماء الطلاب (مطلوب): اسم في كل سطر');
    ta.id = 'add-names'; tl.htmlFor = ta.id; msg.id = 'add-names-m';
    ta.value = text; ta.autocomplete = 'off'; ta.setAttribute('aria-required', 'true'); ta.setAttribute('aria-describedby', msg.id);
    msg.setAttribute('role', 'status'); msg.setAttribute('aria-live', 'polite');
    var acts = mk('div', 'dacts');
    acts.appendChild(btn('primary', 'معاينة الأسماء', function () {
      var r = parseNames(ta.value);
      if (!r.items.length) { msg.textContent = 'لا توجد أسماء صالحة للمعاينة. اكتب اسماً واحداً على الأقل.' + (r.tooLong ? ' (الأسماء الأطول من ' + MAX_NAME + ' حرفاً تُتجاهل.)' : ''); return; }
      addStep2(r, ta.value);
    }));
    acts.appendChild(btn('link', 'إلغاء', function () { closeDlg(dlgAdd); }));
    var cnt = mk('p', 'resc');
    function upd() { var n = ta.value.split(/\r\n|\r|\n|\u2028|\u2029/).filter(function (l) { return cleanName(l); }).length; cnt.textContent = n ? 'عدد الأسماء المكتوبة: ' + n : ''; }
    ta.addEventListener('input', function () { markDirty(dlgAdd, !!ta.value.trim()); }); ta.addEventListener('input', upd); upd();
    addBox.appendChild(tl); addBox.appendChild(ta); addBox.appendChild(cnt); addBox.appendChild(msg); addBox.appendChild(acts);
  }
  function addStep2(r, raw) {
    var t = dlgHead(addBox, 'معاينة الأسماء', 'dlg-add-t'), n = r.items.length;
    markDirty(dlgAdd, true);
    var flagged = r.items.filter(function (i) { return i.match; }).length;
    var info = 'سيُضاف ' + plural(n, F_NAME) + '.';
    if (r.blanks) info += ' تم تجاهل ' + r.blanks + ' سطر فارغ.';
    if (r.tooLong) info += ' تم تجاهل ' + r.tooLong + ' سطر أطول من ' + MAX_NAME + ' حرفاً.';
    addBox.appendChild(mk('p', 'stat', info));
    var ol = mk('ol', 'prev');
    r.items.forEach(function (it) {
      var li = mk('li', null, it.name);
      if (it.match) {
        var w = it.match.w, where = w.where === 'archived' ? ' (ضمن المحذوفين)' : w.where === 'batch' ? ' (في هذه القائمة)' : '';
        li.appendChild(mk('span', 'flag', (it.match.kind === 'dup' ? 'مكرر مع «' : 'مشابه لـ «') + w.name + '»' + where));
      }
      ol.appendChild(li);
    });
    addBox.appendChild(ol);
    var ok = mk('button', 'primary', 'تأكيد الإضافة');
    ok.type = 'button';
    if (flagged) {
      addBox.appendChild(mk('p', 'notice warnbox', 'يوجد ' + flagged + ' اسم مكرر أو مشابه. لا يُرفض أي اسم تلقائياً، فقد يوجد طالبان بالاسم نفسه.'));
      var chk = mk('input'), lab = mk('label', 'chk');
      chk.type = 'checkbox';
      lab.appendChild(chk); lab.appendChild(mk('span', null, 'أؤكد أن هذه الأسماء صحيحة وأريد إضافتها'));
      chk.addEventListener('change', function () { ok.disabled = !chk.checked; });
      ok.disabled = true;
      addBox.appendChild(lab);
    }
    ok.addEventListener('click', function () {
      // حماية من النقر المزدوج: تُفرَّغ المعاينة قبل الحفظ ويُمنع التكرار
      if (addBusy || blocked()) return;
      var names = r.items.map(function (i) { return i.name; }), kept = r.items;
      r.items = [];
      if (!names.length) return;
      addBusy = true; ok.disabled = true;
      var saved;
      // إن فشل التوليد نعيد عناصر المعاينة والزر ليمكن إعادة المحاولة (وإلا تبقى المعاينة فارغة ولا يحدث شيء)
      try { saved = addStudents(names); }
      catch (err) { r.items = kept; addBusy = false; ok.disabled = false; say('تعذّر إنشاء كود شخصي فريد، فلم تُضف الأسماء. أعد المحاولة.', 5000); return; }
      closeDlg(dlgAdd); addBusy = false;
      refreshView();
      report('تمت إضافة ' + plural(names.length, F_STU) + '.', saved);
    });
    var acts = mk('div', 'dacts');
    acts.appendChild(ok);
    acts.appendChild(btn('link', 'تعديل الأسماء', function () { addStep1(raw); }));
    acts.appendChild(btn('link', 'إلغاء', function () { closeDlg(dlgAdd); }));
    addBox.appendChild(acts);
    t.focus();
  }
  // نافذة التأكيد: يذهب التركيز إلى العنوان (لا إلى زر الإجراء) حتى لا يُنفَّذ حذف بضغطة Enter عن غير قصد،
  // ويُقرأ النص عبر aria-describedby. الإجراءات الخطرة (حذف/أرشفة/تجاهل) تُميَّز بنمط خطر إضافة إلى نص الزر.
  function askConfirm(title, text, okLabel, onOk) {
    var h = dlgHead(confBox, title, 'dlg-conf-t'), p = mk('p', 'desc', text), danger = /^(حذف|تجاهل|أرشفة)/.test(okLabel);
    p.id = 'dlg-conf-d';
    dlgConf.setAttribute('aria-describedby', 'dlg-conf-d');
    confBox.appendChild(p);
    var acts = mk('div', 'dacts');
    acts.appendChild(btn('primary' + (danger ? ' danger' : ''), okLabel, function () { closeDlg(dlgConf); onOk(); }));
    acts.appendChild(btn('link', 'إلغاء', function () { closeDlg(dlgConf); }));
    confBox.appendChild(acts);
    openDlg(dlgConf);
    h.focus();
  }

  // ----- الأرشفة والاستعادة -----
  function archiveStudent(id) {
    var s = findStudent(id);
    if (!s || s.status !== 'active' || blocked()) return;
    s.status = 'archived'; s.archivedAt = new Date().toISOString();
    var ok = saveRoster();
    refreshView();
    report('تمت أرشفة «' + s.name + '». يمكنك استعادته من الطلاب المحذوفين.', ok);
  }
  function restoreStudent(id) {
    var s = findStudent(id);
    if (!s || s.status !== 'archived' || blocked()) return;
    s.status = 'active'; s.archivedAt = null;
    var ok = saveRoster();
    refreshView();
    report('تمت استعادة «' + s.name + '» إلى القائمة الفعّالة.', ok);
  }
  function askArchive(s) {
    askConfirm('أرشفة الطالب', '«' + s.name + '» سيُنقل إلى الطلاب المحذوفين. لا يُحذف سجله ولا معرّفه، ويمكنك استعادته في أي وقت.', 'أرشفة الطالب', function () { archiveStudent(s.studentId); });
  }
  function openDetail(id) { state.detailId = id; go('student-detail'); }

  // ----- تعديل بيانات الطالب (الاسم الكامل فقط في هذه المرحلة) -----
  // يتغيّر name فقط: studentId وclassId والحالة والتواريخ (وstudentCode إن وُجد) تبقى كما هي.
  // الطالب المؤرشف: التعديل معطّل برسالة تفسيرية حتى يُستعاد، لأن المؤرشف في التطبيق للمراجعة والاستعادة فقط.
  var MSG_ARCHIVED_EDIT = 'هذا الطالب مؤرشف، لذلك تعديل بياناته معطّل. استعده أولاً من «الطلاب المحذوفون» ثم عدّل اسمه.';
  function tokKey(k) { return k.split(' ').sort().join(' '); }
  // نفس منطق التكرار/التشابه عند الإضافة، مع استثناء الطالب نفسه
  function matchFor(name, excludeId) {
    var k = simKey(name), tk = tokKey(k), hit = null, i, o, ok;
    for (i = 0; i < roster.students.length; i++) {
      o = roster.students[i];
      if (o.studentId === excludeId) continue;
      ok = simKey(o.name);
      if (ok === k) return { kind: 'dup', name: o.name, archived: o.status === 'archived' };
      if (!hit && (tokKey(ok) === tk || (k.length >= 6 && within1(k, ok)))) hit = { kind: 'sim', name: o.name, archived: o.status === 'archived' };
    }
    return hit;
  }
  function openEdit(id) {
    var s = findStudent(id), cid = activeId();
    if (!s || blocked()) return;
    if (s.status !== 'active') { say(MSG_ARCHIVED_EDIT, 5000); return; }
    var form = mk('form', 'eform'), g = mk('div', 'fg'), lab = mk('label', 'fl', 'الاسم الكامل (مطلوب)'), inp = mk('input', 'field'), er = mk('p', 'err');
    var warn = mk('div'), chk = null, warnFor = null, busy = false, acts = mk('div', 'dacts');
    dlgHead(addBox, 'تعديل بيانات الطالب', 'dlg-add-t');
    addBox.appendChild(mk('p', 'muted', 'في هذه المرحلة يمكن تعديل الاسم الكامل فقط. معرّف الطالب وصفه وحالة سجله لا تتغير.'));
    form.noValidate = true;
    lab.htmlFor = inp.id = 'edit-name'; inp.type = 'text'; inp.autocomplete = 'off'; inp.value = s.name; inp.setAttribute('aria-required', 'true'); inp.setAttribute('enterkeyhint', 'done');
    er.id = 'edit-name-e'; er.setAttribute('aria-live', 'polite'); inp.setAttribute('aria-describedby', er.id);
    function clearErr() { er.textContent = ''; inp.removeAttribute('aria-invalid'); }
    function fail(text, el) { er.textContent = text; inp.setAttribute('aria-invalid', 'true'); (el || inp).focus(); }
    inp.addEventListener('input', function () { clearErr(); warn.textContent = ''; chk = null; warnFor = null; });
    g.appendChild(lab); g.appendChild(inp); g.appendChild(er);
    form.appendChild(g); form.appendChild(warn);
    acts.appendChild(mk('button', 'primary', 'حفظ التعديل')); acts.firstChild.type = 'submit';
    acts.appendChild(btn('link', 'إلغاء', function () { closeDlg(dlgAdd); }));
    form.appendChild(acts);
    form.addEventListener('submit', function (e) {
      var cur, name, m, oldName, saved, n = 0;
      e.preventDefault();
      if (busy) return;
      if (activeId() !== cid) { closeDlg(dlgAdd); return; }
      cur = findStudent(id);
      if (!cur || cur.status !== 'active') { closeDlg(dlgAdd); say(cur ? MSG_ARCHIVED_EDIT : 'لم يُعثر على هذا الطالب.', 5000); refreshView(); return; }
      if (readOnlyStore) { closeDlg(dlgAdd); say(storeMsg, 6000); return; }
      name = cleanName(inp.value);
      if (!name) { fail('اكتب اسم الطالب. لا يمكن حفظ اسم فارغ.'); return; }
      if (name.length > MAX_NAME) { fail('الاسم أطول من ' + MAX_NAME + ' حرفاً (طوله الآن ' + name.length + '). اختصره ثم احفظ.'); return; }
      if (name === cur.name) { fail('لم يتغير الاسم، فلا يوجد شيء لحفظه.'); return; }
      m = matchFor(name, id);
      if (m) {
        if (warnFor !== name) {
          warnFor = name; warn.textContent = '';
          warn.appendChild(mk('p', 'notice warnbox', (m.kind === 'dup' ? 'يوجد طالب بالاسم نفسه: «' : 'يوجد اسم مشابه: «') + m.name + '»' + (m.archived ? ' (ضمن المحذوفين)' : '') + '. لا يُمنع الحفظ، فقد يوجد طالبان بالاسم نفسه. إن كان الاسم صحيحاً فأكّد ذلك ثم احفظ.'));
          var l2 = mk('label', 'chk'); chk = mk('input'); chk.type = 'checkbox';
          l2.appendChild(chk); l2.appendChild(mk('span', null, 'أؤكد أن هذا الاسم صحيح وأريد حفظه'));
          warn.appendChild(l2); chk.focus();
          return;
        }
        if (!chk || !chk.checked) { fail('حدّد خانة التأكيد أعلاه إن كنت تريد حفظ هذا الاسم.', chk); return; }
      }
      busy = true;
      oldName = cur.name; cur.name = name; // الاسم فقط: لا يمسّ studentId ولا classId ولا الحالة ولا التواريخ
      saved = saveRoster();
      busy = false;
      closeDlg(dlgAdd);
      refreshView();
      activeList().forEach(function (x, i) { if (x.studentId === id) n = i + 1; });
      if (saved) say('تم حفظ التعديل: صار اسم الطالب «' + name + '» ورقمه في القائمة ' + n + '.', 4500);
      else say('تم تغيير الاسم من «' + oldName + '» إلى «' + name + '» لكن تعذّر الحفظ في تخزين المتصفح، فالتغيير مؤقت وسيضيع عند إغلاق الصفحة.', 8000);
    });
    addBox.appendChild(form);
    openDlg(dlgAdd);
    inp.focus(); inp.select();
  }

  // ----- العرض -----
  function storeNotices() {
    host.appendChild(mk('div', 'notice', 'القائمة محفوظة في متصفح هذا الجهاز فقط، ولا تصل تلقائياً إلى بقية الطلاب. المزامنة بين الأجهزة تحتاج قاعدة بيانات وصلاحيات من جهة الخادم، وستأتي في مرحلة لاحقة.'));
    if (storeMsg) host.appendChild(mk('div', 'notice warnbox', storeMsg));
    migNotes.forEach(function (m) { host.appendChild(mk('div', 'notice warnbox', m)); });
  }
  function studentRow(s, n, archived) {
    var li = mk('li', 'stu'), nm = mk('div', 'nm'), acts = mk('div', 'acts');
    if (!archived) li.appendChild(mk('span', 'num', String(n)));
    var av = mk('span', 'av', Array.from(s.name)[0]); av.setAttribute('aria-hidden', 'true'); li.appendChild(av);
    nm.appendChild(btn('stu-name', s.name, function () { openDetail(s.studentId); }));
    if (archived) nm.appendChild(mk('small', 'muted', 'أُرشف في ' + fmtDate(s.archivedAt)));
    li.appendChild(nm);
    if (archived) {
      acts.appendChild(btn('link', 'مراجعة التفاصيل', function () { openDetail(s.studentId); }));
      acts.appendChild(btn('link', 'استعادة الطالب', function () { restoreStudent(s.studentId); }));
    } else {
      acts.appendChild(btn('link', 'تفاصيل الطالب', function () { openDetail(s.studentId); }));
      var eb = btn('link', 'تعديل الاسم', function () { openEdit(s.studentId); });
      eb.setAttribute('aria-label', 'تعديل بيانات الطالب ' + s.name);
      acts.appendChild(eb);
      acts.appendChild(btn('link', 'أرشفة الطالب', function () { askArchive(s); }));
    }
    li.appendChild(acts);
    return li;
  }
  function listUI(items, archived) {
    var wrap = mk('div', 'part'), inp = mk('input', 'field'), ul = mk('ol', 'stus'), rc = mk('p', 'resc');
    rc.setAttribute('aria-live', 'polite');
    inp.type = 'search'; inp.placeholder = 'ابحث بالاسم'; inp.autocomplete = 'off'; inp.setAttribute('aria-label', 'ابحث عن طالب بالاسم');
    function draw() {
      var qk = simKey(inp.value);
      var shown = items.filter(function (it) { return !qk || simKey(it.s.name).indexOf(qk) > -1; });
      ul.textContent = '';
      rc.textContent = qk ? 'النتائج: ' + shown.length + ' من ' + items.length : '';
      if (!shown.length) { ul.appendChild(mk('li', 'muted', 'لا توجد نتائج مطابقة.')); return; }
      shown.forEach(function (it) { ul.appendChild(studentRow(it.s, it.n, archived)); });
    }
    inp.addEventListener('input', draw);
    wrap.appendChild(inp); wrap.appendChild(rc); wrap.appendChild(ul); host.appendChild(wrap);
    draw();
  }
  // شريط الصف النشط في صفحات الطلاب: اسم الصف + تبديل سريع إلى صف فعّال آخر + رابط إدارة الصفوف
  function classBar() {
    var c = activeClass(), bar = mk('div', 'classbar'), nm = mk('div', 'cb-n'), list = classes.classes.filter(function (x) { return x.status === 'active'; }).sort(byLabel);
    nm.appendChild(mk('small', 'muted', 'الصف النشط'));
    nm.appendChild(mk('b', null, classLabel(c)));
    bar.appendChild(nm);
    if (list.length > 1) {
      var g = mk('div', 'cb-s'), lab = mk('label', 'fl', 'التبديل إلى صف آخر'), sel = mk('select', 'field');
      lab.htmlFor = sel.id = 'cb-sel';
      list.forEach(function (x) {
        var extra = [x.schoolName, x.year].filter(Boolean).join(' · '), o = mk('option', null, classLabel(x) + (extra ? ' (' + extra + ')' : ''));
        o.value = x.classId; o.selected = x.classId === c.classId; sel.appendChild(o);
      });
      sel.addEventListener('change', function () { selectClass(sel.value); });
      g.appendChild(lab); g.appendChild(sel); bar.appendChild(g);
    }
    bar.appendChild(btn('link', 'إدارة الصفوف', function () { go('classes'); }));
    host.appendChild(bar);
  }
  function noClassBlock() {
    var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا يوجد صف نشط'));
    e.appendChild(document.createTextNode('اختر صفاً نشطاً من «إدارة الصفوف» ليظهر عرض طلابه.'));
    host.appendChild(e);
    host.appendChild(mk('div', 'toolbar')).appendChild(btn('primary', 'فتح إدارة الصفوف', function () { go('classes'); }));
  }
  function renderRoster() {
    if (!activeClass()) { noClassBlock(); return; }
    classBar();
    storeNotices();
    var list = activeList(), arch = archivedList(), bar = mk('div', 'toolbar');
    bar.appendChild(mk('span', 'count', 'عدد الطلاب الفعّالين: ' + list.length));
    bar.appendChild(btn('primary', 'إضافة طلاب', function () { openAdd(''); }));
    bar.appendChild(btn('link', 'الطلاب المحذوفون (' + arch.length + ')', function () { go('deleted'); }));
    host.appendChild(bar);
    if (!list.length) {
      var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا يوجد طلاب بعد'));
      e.appendChild(document.createTextNode('اضغط «إضافة طلاب» ثم اكتب اسم كل طالب في سطر مستقل، وستظهر القائمة مرتبة أبجدياً ومرقّمة.'));
      host.appendChild(e);
      return;
    }
    listUI(list.map(function (s, i) { return { s: s, n: i + 1 }; }), false);
  }
  function renderDeleted() {
    if (!activeClass()) { noClassBlock(); return; }
    classBar();
    storeNotices();
    var arch = archivedList();
    host.appendChild(mk('div', 'toolbar')).appendChild(mk('span', 'count', 'عدد الطلاب المحذوفين: ' + arch.length));
    if (!arch.length) {
      var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا يوجد طلاب محذوفون'));
      e.appendChild(document.createTextNode('عند أرشفة طالب من «إدارة الطلاب» يظهر هنا ويمكن استعادته. لا يوجد حذف نهائي في هذه المرحلة.'));
      host.appendChild(e);
      return;
    }
    listUI(arch.map(function (s) { return { s: s, n: 0 }; }), true);
  }
  // ----- الكود الشخصي وحالة الحساب (عرض ونسخ فقط) -----
  // لا يوجد هنا تسجيل دخول ولا مقارنة كود ولا حالة حساب محفوظة: الكود معرّف فقط، والمصادقة الفعلية تحتاج خادماً.
  var MSG_AUTH_NOTE = 'الكود الشخصي معرّف الطالب، وتفعيل تسجيل الدخول الفعلي يتطلب خدمة مصادقة وصلاحيات خلفية.';
  function copyText(text, el, label) {
    function done(ok) { say(ok ? 'تم نسخ الكود الشخصي.' : 'تعذّر النسخ تلقائياً. الكود محدّد الآن، انسخه يدوياً.', 4000); }
    function fallback() {
      var ok = false, r, sel;
      try {
        r = document.createRange(); r.selectNodeContents(el);
        sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
        ok = !!(document.execCommand && document.execCommand('copy'));
      } catch (e) { ok = false; }
      done(ok);
    }
    if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () { done(true); }, fallback);
    } else fallback();
  }
  function renderAccount(s) {
    var sec = mk('section', 'part acct'), box = mk('div', 'panel'), dl = mk('dl', 'kv'), d1 = mk('div'), d2 = mk('div'), dd = mk('dd', 'cd'), code = s.studentCode, cEl;
    sec.appendChild(mk('h2', null, 'حساب الطالب'));
    d1.appendChild(mk('dt', null, 'الكود الشخصي'));
    if (code) {
      cEl = mk('code', 'scode', code); cEl.lang = 'en'; cEl.dir = 'ltr'; cEl.tabIndex = 0;
      dd.appendChild(cEl);
      var cb = btn('link', 'نسخ الكود', function () { copyText(code, cEl); });
      cb.setAttribute('aria-label', 'نسخ الكود الشخصي للطالب ' + s.name);
      dd.appendChild(cb);
    } else dd.appendChild(mk('span', 'muted', 'لا يوجد كود لهذا السجل. أعد تحميل الصفحة.'));
    d1.appendChild(dd); dl.appendChild(d1);
    d2.appendChild(mk('dt', null, 'حالة الحساب'));
    d2.appendChild(mk('dd', null, 'بانتظار تفعيل الحساب (لا يوجد تسجيل دخول فعلي بعد)'));
    dl.appendChild(d2);
    box.appendChild(dl);
    if (memRosters[activeId()]) box.appendChild(mk('p', 'notice warnbox', 'هذا الكود لم يُحفظ في تخزين المتصفح، فقد يتغير عند إعادة فتح الصفحة. لا تعتمد عليه.'));
    box.appendChild(mk('p', 'muted', MSG_AUTH_NOTE));
    box.appendChild(mk('p', 'muted', 'الكود ثابت: لا يتغير بتعديل الاسم أو الأرشفة أو الاستعادة أو تغيّر رقم القائمة، ولا يُعاد لطالب آخر. وهو ليس كلمة مرور: من يعرف الكود وحده لا يثبت أنه الطالب.'));
    sec.appendChild(box); host.appendChild(sec);
  }
  function renderDetail() {
    var s = findStudent(state.detailId), n = 0;
    if (!s) { host.appendChild(mk('p', 'empty', 'لم يُعثر على هذا الطالب.')); return; }
    if (storeMsg) host.appendChild(mk('div', 'notice warnbox', storeMsg));
    migNotes.forEach(function (m) { host.appendChild(mk('div', 'notice warnbox', m)); });
    if (s.status === 'active') activeList().forEach(function (x, i) { if (x.studentId === s.studentId) n = i + 1; });
    var dl = mk('dl', 'kv');
    function kv(k, v) { var d = mk('div'); d.appendChild(mk('dt', null, k)); d.appendChild(mk('dd', null, v)); dl.appendChild(d); }
    kv('الاسم', s.name);
    kv('الصف الحالي', activeClass() ? classLabel(activeClass()) : '');
    kv('رقم القائمة الحالي', s.status === 'active' ? String(n) : 'بلا رقم: الطالب مؤرشف');
    kv('حالة السجل', s.status === 'active' ? 'فعّال' : 'مؤرشف (ضمن الطلاب المحذوفين)');
    kv('تاريخ الإضافة', fmtDate(s.createdAt));
    if (s.status === 'archived') kv('تاريخ الأرشفة', fmtDate(s.archivedAt));
    var panel = mk('section', 'panel');
    panel.appendChild(dl); host.appendChild(panel);
    var acts = mk('div', 'toolbar');
    if (s.status === 'active') {
      acts.appendChild(btn('primary', 'تعديل بيانات الطالب', function () { openEdit(s.studentId); }));
      acts.appendChild(btn('link', 'أرشفة الطالب', function () { askArchive(s); }));
    } else {
      var eb = mk('button', 'primary', 'تعديل بيانات الطالب');
      eb.type = 'button'; eb.disabled = true; eb.setAttribute('aria-describedby', 'edit-off');
      acts.appendChild(eb);
      acts.appendChild(btn('primary', 'استعادة الطالب', function () { restoreStudent(s.studentId); }));
    }
    host.appendChild(acts);
    if (s.status !== 'active') { var why = mk('p', 'muted', MSG_ARCHIVED_EDIT); why.id = 'edit-off'; host.appendChild(why); }
    renderAccount(s);
    var f = mk('p', 'empty'); f.appendChild(mk('strong', null, 'السجل الدراسي'));
    f.appendChild(document.createTextNode('سيتوفر السجل الدراسي (الغياب والدرجات والمدفوعات) عندما تُنفَّذ تلك الأقسام لاحقاً، وستُربط بهذا الطالب عبر معرّفه الداخلي. لا توجد سجلات الآن.'));
    host.appendChild(f);
    var det = mk('details', 'dev');
    det.appendChild(mk('summary', null, 'معلومات إضافية'));
    var d = mk('div'); d.appendChild(mk('p', null, 'المعرّف الداخلي الثابت (studentId). لا يتغير بتغيّر الاسم أو الترتيب أو رقم القائمة:'));
    d.appendChild(mk('code', 'id', s.studentId)); det.appendChild(d);
    host.appendChild(det);
  }

  // ===== 03.2: «ما أُخذ اليوم» (سجل الدروس) — وضع ممثل الصف =====
  // كل القراءة والكتابة عبر MarsaAcademicStore (النوع dailyLessons) وclassId الصف النشط وقت فتح الصفحة؛
  // لا يوجد تخزين مؤقت للسجلات بين الصفوف: كل رسم يقرأ مجموعة الصف النشط من جديد، فلا يختلط صف بآخر.
  // كل نص يدخله المستخدم يُعرض بـ textContent فقط. التحقق والفرز والبحث في js/lessons-model.js.
  var LESSON_TYPE = 'dailyLessons', lessonsCtl = null;
  function lessonCard(r, model, today, onEdit, onDelete) {
    var li = mk('li', 'lcard'), top = mk('div', 'lc-top'), title = model.field(r, 'title'), subj = model.field(r, 'subject'), date = model.field(r, 'date'), meta = mk('p', 'lc-meta');
    li.tabIndex = -1; li.setAttribute('data-record-id', model.field(r, 'recordId'));
    top.appendChild(mk('h3', null, title || '(بلا عنوان)'));
    li.appendChild(top);
    meta.appendChild(mk('span', 'tag', subj || '(بلا مادة)'));
    meta.appendChild(mk('span', 'lc-date', model.formatDate(date)));
    if (date && date === today) meta.appendChild(mk('span', 'tag on', 'اليوم'));
    li.appendChild(meta);
    [['summary', 'الملخص'], ['pages', 'الصفحات / المصدر'], ['homework', 'الواجب أو المطلوب'], ['notes', 'ملاحظات']].forEach(function (f) {
      var v = model.field(r, f[0]), d;
      if (!v) return;
      d = mk('div', 'lc-f'); d.appendChild(mk('small', 'muted', f[1])); d.appendChild(mk('p', 'lc-t', v)); li.appendChild(d);
    });
    var acts = mk('div', 'acts'), eb = btn('link', 'تعديل', onEdit), db = btn('link danger', 'حذف', onDelete);
    eb.setAttribute('aria-label', 'تعديل سجل الدرس ' + (title || ''));
    db.setAttribute('aria-label', 'حذف سجل الدرس ' + (title || ''));
    acts.appendChild(eb); acts.appendChild(db); li.appendChild(acts);
    return li;
  }
  function renderLessons() {
    var store = window.MarsaAcademicStore, model = window.MarsaLessonsModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, formOpen = false, dirty = false, editingId = null;
    lessonsCtl = null;
    if (!activeClass()) { noClassBlock(); return; }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل طبقة التخزين الأكاديمي أو منطق سجل الدروس (js/academic-store.js و js/lessons-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return; }
    classBar();
    host.appendChild(mk('div', 'notice', 'سجل الدروس محفوظ في متصفح هذا الجهاز فقط، ولا يصل إلى الطلاب ولا إلى أجهزة أخرى. المزامنة تحتاج خادماً وستأتي في مرحلة لاحقة.'));
    var bannerBox = mk('div'), bar = mk('div', 'toolbar'), count = mk('span', 'count'), addBtn;
    var formHost = mk('section', 'part lform'), listWrap = mk('div', 'part'), search = mk('input', 'field'), rc = mk('p', 'resc'), emptyBox = mk('div'), ul = mk('ul', 'llist');
    host.appendChild(bannerBox);

    function load() {
      var r = store.readCollection(LESSON_TYPE, cid);
      persistent = r.persistent !== false;
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت قراءة سجلات الدروس.'; return false; }
      blockedMsg = ''; records = r.records; return true;
    }
    function banner() {
      bannerBox.textContent = '';
      if (blockedMsg) bannerBox.appendChild(mk('div', 'notice warnbox', blockedMsg));
      else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك السجلات مؤقتة في ذاكرة هذه الصفحة وتزول بإغلاقها أو إعادة تحميلها.'));
      if (addBtn) addBtn.disabled = !!blockedMsg;
    }
    function sameClass() { if (activeId() !== cid) { say('تغيّر الصف النشط. أعد فتح «ما أُخذ اليوم».'); return false; } return true; }

    function drawList() {
      var all = model.sortRecords(records), shown = model.filterRecords(all, search.value), today = store.toLocalDate();
      count.textContent = 'عدد السجلات: ' + records.length;
      ul.textContent = ''; emptyBox.textContent = '';
      search.hidden = !records.length;
      rc.textContent = records.length && search.value.trim() ? 'النتائج: ' + shown.length + ' من ' + records.length : '';
      if (!records.length) {
        if (!blockedMsg) {
          var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لم تُسجَّل أي دروس لهذا الصف بعد'));
          e.appendChild(document.createTextNode('اضغط «إضافة سجل درس» ثم اكتب المادة وموضوع الدرس وتاريخ الشرح. أما الملخص والصفحات والواجب والملاحظات فاختيارية.'));
          emptyBox.appendChild(e);
        }
        return;
      }
      if (!shown.length) { emptyBox.appendChild(mk('p', 'muted', 'لا توجد سجلات مطابقة للبحث.')); return; }
      shown.forEach(function (r) {
        ul.appendChild(lessonCard(r, model, today, function () { guard(function () { openForm(r); }); }, function () { askDelete(r); }));
      });
    }
    function closeForm() { formOpen = false; dirty = false; editingId = null; formHost.hidden = true; formHost.textContent = ''; }
    function guard(fn) {
      if (formOpen && dirty) askConfirm('تجاهل ما كتبته؟', 'النموذج المفتوح فيه بيانات لم تُحفظ بعد. إن تابعت فستُفقد.', 'تجاهل والمتابعة', fn);
      else fn();
    }
    function focusCard(id) {
      var items = ul.children, i;
      for (i = 0; i < items.length; i++) if (items[i].getAttribute('data-record-id') === id) { items[i].scrollIntoView({ block: 'nearest' }); items[i].focus({ preventScroll: true }); return; }
    }

    function openForm(rec) {
      var editing = !!rec, form = mk('form', 'lf'), msg = mk('p', 'err'), els = {}, errs = {}, busy = false, warnedDate = null, today = store.toLocalDate(), submit;
      formOpen = true; dirty = false; editingId = editing ? model.field(rec, 'recordId') : null;
      formHost.hidden = false; formHost.textContent = '';
      var h = mk('h2', null, editing ? 'تعديل سجل درس' : 'إضافة سجل درس'); h.tabIndex = -1; formHost.appendChild(h);
      formHost.appendChild(mk('p', 'muted', editing ? 'تعديل السجل لا يغيّر معرّفه الداخلي ولا صفه.' : 'المطلوب فقط: المادة والموضوع والتاريخ. اكتب ما شرحته فعلياً.'));
      form.noValidate = true;
      function addField(key, el, parent) {
        var g = mk('div', 'fg'), lab = mk('label', 'fl', model.LABELS[key] + (key === 'subject' || key === 'title' || key === 'date' ? ' (مطلوب)' : ' (اختياري)')), er = mk('p', 'err');
        el.id = 'lf-' + key; lab.htmlFor = el.id; er.id = 'lf-' + key + '-e'; er.setAttribute('aria-live', 'polite'); el.setAttribute('aria-describedby', er.id);
        if (key === 'subject' || key === 'title' || key === 'date') el.setAttribute('aria-required', 'true');
        if (model.LIMITS[key]) el.maxLength = model.LIMITS[key];
        el.addEventListener('input', function () { dirty = true; er.textContent = ''; el.removeAttribute('aria-invalid'); msg.textContent = ''; if (key === 'date') warnedDate = null; });
        els[key] = el; errs[key] = er;
        g.appendChild(lab); g.appendChild(el); g.appendChild(er); parent.appendChild(g);
      }
      function text(key, hint) { var i = mk('input', 'field'); i.type = 'text'; i.autocomplete = 'off'; if (hint) i.placeholder = hint; i.setAttribute('enterkeyhint', 'next'); return i; }
      function area(key, rows) { var t = mk('textarea', 'field'); t.rows = rows; t.autocomplete = 'off'; return t; }
      var s = text('subject', 'مثال: اسم المادة كما تكتبه أنت'), t = text('title'), d = mk('input', 'field');
      d.type = 'date'; d.min = model.MIN_YEAR + '-01-01'; d.max = model.MAX_YEAR + '-12-31';
      var subs = model.subjectsOf(records);
      if (subs.length) {
        var dl = mk('datalist'); dl.id = 'lf-subjects';
        subs.forEach(function (x) { var o = mk('option'); o.value = x; dl.appendChild(o); });
        s.setAttribute('list', dl.id); form.appendChild(dl);
      }
      if (editing) { s.value = model.field(rec, 'subject'); t.value = model.field(rec, 'title'); d.value = model.isLocalDate(model.field(rec, 'date')) ? model.field(rec, 'date') : ''; }
      else d.value = today; // تاريخ اليوم المحلي (من أجزاء Date المحلية لا من UTC)
      addField('subject', s, form); addField('title', t, form); addField('date', d, form);
      var det = mk('details', 'opt'), sum = mk('summary', null, 'تفاصيل اختيارية (ملخص، صفحات، واجب، ملاحظات)'), body = mk('div', 'opt-b');
      det.appendChild(sum); det.appendChild(body);
      addField('summary', area('summary', 3), body); addField('pages', text('pages'), body); addField('homework', area('homework', 3), body); addField('notes', area('notes', 3), body);
      if (editing) els.summary.value = model.field(rec, 'summary'), els.pages.value = model.field(rec, 'pages'), els.homework.value = model.field(rec, 'homework'), els.notes.value = model.field(rec, 'notes');
      if (editing && (els.summary.value || els.pages.value || els.homework.value || els.notes.value)) det.open = true;
      det.addEventListener('toggle', function () { /* لا شيء: الفتح والإغلاق لا يغيّران البيانات */ });
      form.appendChild(det);
      msg.id = 'lf-msg'; msg.setAttribute('role', 'alert'); form.appendChild(msg);
      var acts = mk('div', 'dacts'); submit = mk('button', 'primary', editing ? 'حفظ التعديل' : 'حفظ السجل'); submit.type = 'submit';
      acts.appendChild(submit);
      acts.appendChild(btn('link', 'إلغاء', function () { guard(function () { closeForm(); }); }));
      form.appendChild(acts);

      form.addEventListener('submit', function (e) {
        var res, g, existing = null, out, id;
        e.preventDefault();
        if (busy) return;
        if (!sameClass()) { closeForm(); return; }
        Object.keys(errs).forEach(function (k) { errs[k].textContent = ''; els[k].removeAttribute('aria-invalid'); });
        msg.textContent = '';
        res = model.validate({ subject: els.subject.value, title: els.title.value, date: els.date.value, summary: els.summary.value, pages: els.pages.value, homework: els.homework.value, notes: els.notes.value }, { today: store.toLocalDate() });
        if (!res.ok) {
          Object.keys(res.errors).forEach(function (k) { errs[k].textContent = res.errors[k]; els[k].setAttribute('aria-invalid', 'true'); });
          if (res.errors.summary || res.errors.pages || res.errors.homework || res.errors.notes) det.open = true;
          els[res.firstError].focus(); return;
        }
        // تاريخ بعد اليوم: ما أُخذ اليوم يسجّل ما شُرح فعلاً، فنطلب تأكيداً صريحاً بضغطة ثانية
        if (res.future && warnedDate !== res.values.date) {
          warnedDate = res.values.date; msg.textContent = 'تاريخ الشرح بعد اليوم. هذا السجل لما شُرح فعلاً. إن كان التاريخ صحيحاً فاضغط «' + submit.textContent + '» مرة أخرى للتأكيد.'; els.date.focus(); return;
        }
        busy = true; submit.disabled = true;
        try {
          if (editing) {
            g = store.getRecord(LESSON_TYPE, cid, editingId);
            if (!g.ok) { msg.textContent = 'لم يُحفظ شيء: ' + (g.status === 'not-found' ? 'هذا السجل لم يعد موجوداً (ربما حُذف من تبويب آخر). أنشئ سجلاً جديداً إن أردت.' : (g.error || 'تعذّرت قراءة السجل.')) + ' بياناتك ما زالت في النموذج.'; return; }
            existing = g.record;
          }
          out = store.upsertRecord(LESSON_TYPE, cid, model.buildRecord(res.values, existing));
        } catch (err) { out = { ok: false, error: 'خطأ غير متوقع أثناء الحفظ.' }; }
        finally { busy = false; submit.disabled = false; }
        if (!out.ok) { msg.textContent = 'لم يُحفظ السجل: ' + (out.error || 'تعذّر الحفظ.') + ' بياناتك ما زالت في النموذج، أعد المحاولة.'; return; }
        persistent = out.persistent !== false;
        records = out.records; id = out.record.recordId;
        closeForm(); banner(); search.value = ''; drawList(); focusCard(id);
        if (persistent) say(editing ? 'تم حفظ التعديل.' : 'تم حفظ سجل الدرس.', 3200);
        else say((editing ? 'حُفظ التعديل' : 'حُفظ السجل') + ' في ذاكرة هذه الصفحة فقط وليس بشكل دائم. سيزول بإغلاقها أو إعادة تحميلها.', 8000);
      });
      formHost.appendChild(form);
      formHost.scrollIntoView({ block: 'start' });
      (editing ? els.title : els.subject).focus({ preventScroll: true });
    }

    function askDelete(r) {
      var title = model.field(r, 'title') || '(بلا عنوان)', id = model.field(r, 'recordId');
      askConfirm('حذف سجل الدرس', 'سيُحذف نهائياً من هذا الصف سجل «' + title + '» (' + (model.field(r, 'subject') || 'بلا مادة') + '، ' + model.formatDate(model.field(r, 'date')) + '). لا يمكن التراجع عن الحذف. هل تريد المتابعة؟', 'حذف السجل', function () {
        var out;
        if (!sameClass()) return;
        out = store.deleteRecord(LESSON_TYPE, cid, id);
        if (!out.ok) { say('لم يُحذف السجل: ' + (out.error || 'تعذّر الحذف.'), 6000); if (out.status === 'not-found') { load(); banner(); drawList(); } return; }
        persistent = out.persistent !== false; records = out.records;
        if (editingId === id) closeForm();
        banner(); drawList(); count.tabIndex = -1; count.focus({ preventScroll: true });
        say(persistent ? 'تم حذف سجل الدرس.' : 'حُذف السجل من ذاكرة هذه الصفحة فقط وليس بشكل دائم.', persistent ? 3200 : 8000);
      });
    }

    addBtn = btn('primary', 'إضافة سجل درس', function () { guard(function () { openForm(null); }); });
    bar.appendChild(count); bar.appendChild(addBtn); host.appendChild(bar);
    formHost.hidden = true; host.appendChild(formHost);
    search.type = 'search'; search.placeholder = 'ابحث بالموضوع أو المادة'; search.autocomplete = 'off'; search.setAttribute('aria-label', 'ابحث في سجلات الدروس بالموضوع أو المادة');
    search.addEventListener('input', drawList);
    rc.setAttribute('aria-live', 'polite');
    listWrap.appendChild(search); listWrap.appendChild(rc); listWrap.appendChild(emptyBox); listWrap.appendChild(ul); host.appendChild(listWrap);
    load(); banner(); drawList();
    lessonsCtl = { cid: cid, dirty: function () { return formOpen && dirty; }, reload: function () { if (activeId() !== cid) return; load(); banner(); drawList(); } };
  }

  // ===== 03.3: التحاضير (التحضير لما سيأتي) — وضع ممثل الصف =====
  // التخزين عبر MarsaAcademicStore (النوع preparations) وclassId الصف النشط وقت فتح الصفحة، منفصل تماماً عن dailyLessons:
  // لا يُنسخ تحضير إلى «ما أُخذ اليوم» تلقائياً. اليوم وباجر بالتقويم المحلي (store.toLocalDate وmodel.addDays). كل نص بـ textContent.
  var PREP_TYPE = 'preparations', prepsCtl = null;
  function prepCard(r, model, kind, today, onEdit, onDelete) {
    var li = mk('li', 'lcard pcard' + (kind === 'today' ? ' is-today' : ''), null), title = model.field(r, 'title'), subj = model.field(r, 'subject'), date = model.field(r, 'date'), meta = mk('p', 'lc-meta');
    li.tabIndex = -1; li.setAttribute('data-record-id', model.field(r, 'recordId'));
    li.appendChild(mk('div', 'lc-top')).appendChild(mk('h3', null, title || '(بلا عنوان)'));
    meta.appendChild(mk('span', 'tag', subj || '(بلا مادة)'));
    meta.appendChild(mk('span', 'lc-date', model.formatDate(date)));
    if (kind === 'today') meta.appendChild(mk('span', 'tag on', 'اليوم'));
    else if (kind === 'tomorrow') meta.appendChild(mk('span', 'tag on', 'باجر'));
    else if (model.isLocalDate(date) && date < today) meta.appendChild(mk('span', 'tag', 'مضى موعده'));
    li.appendChild(meta);
    [['content', 'المحتوى / النقاط'], ['pages', 'الصفحات / المصدر'], ['homework', 'المطلوب / الواجب'], ['notes', 'ملاحظات']].forEach(function (f) {
      var v = model.field(r, f[0]), d;
      if (!v) return;
      d = mk('div', 'lc-f'); d.appendChild(mk('small', 'muted', f[1])); d.appendChild(mk('p', 'lc-t', v)); li.appendChild(d);
    });
    var acts = mk('div', 'acts'), eb = btn('link', 'تعديل', onEdit), db = btn('link danger', 'حذف', onDelete);
    eb.setAttribute('aria-label', 'تعديل التحضير ' + (title || '')); db.setAttribute('aria-label', 'حذف التحضير ' + (title || ''));
    acts.appendChild(eb); acts.appendChild(db); li.appendChild(acts);
    return li;
  }
  function renderPreps() {
    var store = window.MarsaAcademicStore, model = window.MarsaPrepsModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, formOpen = false, dirty = false, editingId = null, shownToday = '';
    prepsCtl = null;
    if (!activeClass()) { noClassBlock(); return; }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل طبقة التخزين الأكاديمي أو منطق التحاضير (js/academic-store.js و js/preps-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return; }
    classBar();
    host.appendChild(mk('div', 'notice', 'التحاضير محفوظة في متصفح هذا الجهاز فقط، ولا تصل إلى الطلاب ولا إلى أجهزة أخرى. المزامنة تحتاج خادماً وستأتي في مرحلة لاحقة.'));
    var sep = mk('div', 'notice sepnote');
    sep.appendChild(mk('span', null, 'هنا التحضير لما سيأتي. ما شرحته فعلاً يُسجَّل بصورة مستقلة في «ما أُخذ اليوم»، ولا يُنسخ إليه أي تحضير تلقائياً. '));
    sep.appendChild(btn('link', 'فتح «ما أُخذ اليوم»', function () { go('r-lessons'); }));
    host.appendChild(sep);
    var bannerBox = mk('div'), bar = mk('div', 'toolbar'), count = mk('span', 'count'), addBtn;
    var formHost = mk('section', 'part lform'), listWrap = mk('div', 'part'), search = mk('input', 'field'), rc = mk('p', 'resc'), groupsBox = mk('div', 'pgroups');
    host.appendChild(bannerBox);

    function load() {
      var r = store.readCollection(PREP_TYPE, cid);
      persistent = r.persistent !== false;
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت قراءة التحاضير.'; return false; }
      blockedMsg = ''; records = r.records; return true;
    }
    function banner() {
      bannerBox.textContent = '';
      if (blockedMsg) bannerBox.appendChild(mk('div', 'notice warnbox', blockedMsg));
      else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك التحاضير مؤقتة في ذاكرة هذه الصفحة وتزول بإغلاقها أو إعادة تحميلها.'));
      if (addBtn) addBtn.disabled = !!blockedMsg;
    }
    function sameClass() { if (activeId() !== cid) { say('تغيّر الصف النشط. أعد فتح «التحاضير».'); return false; } return true; }

    function drawList() {
      var today = store.toLocalDate(), q = search.value.trim(), shown = model.filterRecords(records, search.value), g = model.groupByDay(shown, today);
      shownToday = today;
      count.textContent = 'عدد التحاضير: ' + records.length;
      groupsBox.textContent = '';
      search.hidden = !records.length;
      rc.textContent = records.length && q ? 'النتائج: ' + shown.length + ' من ' + records.length : '';
      if (!records.length) {
        if (!blockedMsg) {
          var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لم تُضف أي تحاضير لهذا الصف بعد'));
          e.appendChild(document.createTextNode('اضغط «إضافة تحضير» ثم اكتب المادة وعنوان الموضوع والتاريخ ومحتوى التحضير. أما الصفحات والمطلوب والملاحظات فاختيارية.'));
          groupsBox.appendChild(e);
        }
        return;
      }
      if (!shown.length) { groupsBox.appendChild(mk('p', 'muted', 'لا توجد تحاضير مطابقة للبحث.')); return; }
      [['today', 'اليوم', g.today, 'لا يوجد تحضير لليوم.', today], ['tomorrow', 'باجر', g.tomorrow, 'لا يوجد تحضير لباجر.', g.tomorrowDate], ['other', 'تحاضير أخرى', g.other, 'لا توجد تحاضير أخرى.', '']].forEach(function (x) {
        var sec, h, ul;
        if (q && !x[2].length) return;
        sec = mk('section', 'pgroup'); sec.setAttribute('data-group', x[0]);
        h = mk('h2', null, x[1] + (x[2].length ? ' (' + x[2].length + ')' : '')); sec.appendChild(h);
        if (x[4]) sec.appendChild(mk('p', 'muted pg-date', model.formatDate(x[4])));
        if (!x[2].length) sec.appendChild(mk('p', 'muted', x[3]));
        else {
          ul = mk('ul', 'llist');
          x[2].forEach(function (r) { ul.appendChild(prepCard(r, model, x[0], today, function () { guard(function () { openForm(r); }); }, function () { askDelete(r); })); });
          sec.appendChild(ul);
        }
        groupsBox.appendChild(sec);
      });
    }
    function closeForm() { formOpen = false; dirty = false; editingId = null; formHost.hidden = true; formHost.textContent = ''; }
    function guard(fn) {
      if (formOpen && dirty) askConfirm('تجاهل ما كتبته؟', 'النموذج المفتوح فيه بيانات لم تُحفظ بعد. إن تابعت فستُفقد.', 'تجاهل والمتابعة', fn);
      else fn();
    }
    function focusCard(id) {
      var items = groupsBox.querySelectorAll('li[data-record-id]'), i;
      for (i = 0; i < items.length; i++) if (items[i].getAttribute('data-record-id') === id) { items[i].scrollIntoView({ block: 'nearest' }); items[i].focus({ preventScroll: true }); return; }
    }

    function openForm(rec) {
      var editing = !!rec, form = mk('form', 'lf'), msg = mk('p', 'err'), els = {}, errs = {}, busy = false, submit, tomorrow = model.addDays(store.toLocalDate(), 1);
      formOpen = true; dirty = false; editingId = editing ? model.field(rec, 'recordId') : null;
      formHost.hidden = false; formHost.textContent = '';
      var h = mk('h2', null, editing ? 'تعديل تحضير' : 'إضافة تحضير'); h.tabIndex = -1; formHost.appendChild(h);
      formHost.appendChild(mk('p', 'muted', editing ? 'تعديل التحضير لا يغيّر معرّفه الداخلي ولا صفه.' : 'المطلوب: المادة والعنوان والتاريخ والمحتوى. التاريخ المقترح هو باجر، وغيّره إن أردت.'));
      form.noValidate = true;
      var REQ = { subject: 1, title: 1, date: 1, content: 1 };
      function addField(key, el, parent) {
        var g = mk('div', 'fg'), lab = mk('label', 'fl', model.LABELS[key] + (REQ[key] ? ' (مطلوب)' : ' (اختياري)')), er = mk('p', 'err');
        el.id = 'pf-' + key; lab.htmlFor = el.id; er.id = 'pf-' + key + '-e'; er.setAttribute('aria-live', 'polite'); el.setAttribute('aria-describedby', er.id);
        if (REQ[key]) el.setAttribute('aria-required', 'true');
        if (model.LIMITS[key]) el.maxLength = model.LIMITS[key];
        el.addEventListener('input', function () { dirty = true; er.textContent = ''; el.removeAttribute('aria-invalid'); msg.textContent = ''; });
        els[key] = el; errs[key] = er;
        g.appendChild(lab); g.appendChild(el); g.appendChild(er); parent.appendChild(g);
      }
      function text() { var i = mk('input', 'field'); i.type = 'text'; i.autocomplete = 'off'; i.setAttribute('enterkeyhint', 'next'); return i; }
      function area(rows) { var t = mk('textarea', 'field'); t.rows = rows; t.autocomplete = 'off'; return t; }
      var s = text(), t = text(), d = mk('input', 'field'), c = area(5);
      s.placeholder = 'اسم المادة كما تكتبه أنت';
      d.type = 'date'; d.min = model.MIN_YEAR + '-01-01'; d.max = model.MAX_YEAR + '-12-31';
      var subs = model.subjectsOf(records);
      if (subs.length) {
        var dl = mk('datalist'); dl.id = 'pf-subjects';
        subs.forEach(function (x) { var o = mk('option'); o.value = x; dl.appendChild(o); });
        s.setAttribute('list', dl.id); form.appendChild(dl);
      }
      addField('subject', s, form); addField('title', t, form); addField('date', d, form); addField('content', c, form);
      var det = mk('details', 'opt'), body = mk('div', 'opt-b');
      det.appendChild(mk('summary', null, 'تفاصيل اختيارية (صفحات، مطلوب، ملاحظات)')); det.appendChild(body);
      addField('pages', text(), body); addField('homework', area(3), body); addField('notes', area(3), body);
      if (editing) {
        s.value = model.field(rec, 'subject'); t.value = model.field(rec, 'title'); c.value = model.field(rec, 'content');
        d.value = model.isLocalDate(model.field(rec, 'date')) ? model.field(rec, 'date') : '';
        els.pages.value = model.field(rec, 'pages'); els.homework.value = model.field(rec, 'homework'); els.notes.value = model.field(rec, 'notes');
        if (els.pages.value || els.homework.value || els.notes.value) det.open = true;
      } else d.value = tomorrow;
      form.appendChild(det);
      msg.id = 'pf-msg'; msg.setAttribute('role', 'alert'); form.appendChild(msg);
      var acts = mk('div', 'dacts'); submit = mk('button', 'primary', editing ? 'حفظ التعديل' : 'حفظ التحضير'); submit.type = 'submit';
      acts.appendChild(submit);
      acts.appendChild(btn('link', 'إلغاء', function () { guard(function () { closeForm(); }); }));
      form.appendChild(acts);

      form.addEventListener('submit', function (e) {
        var res, g, existing = null, out, id;
        e.preventDefault();
        if (busy) return;
        if (!sameClass()) { closeForm(); return; }
        Object.keys(errs).forEach(function (k) { errs[k].textContent = ''; els[k].removeAttribute('aria-invalid'); });
        msg.textContent = '';
        res = model.validate({ subject: els.subject.value, title: els.title.value, date: els.date.value, content: els.content.value, pages: els.pages.value, homework: els.homework.value, notes: els.notes.value });
        if (!res.ok) {
          Object.keys(res.errors).forEach(function (k) { errs[k].textContent = res.errors[k]; els[k].setAttribute('aria-invalid', 'true'); });
          if (res.errors.pages || res.errors.homework || res.errors.notes) det.open = true;
          els[res.firstError].focus(); return;
        }
        busy = true; submit.disabled = true;
        try {
          if (editing) {
            g = store.getRecord(PREP_TYPE, cid, editingId);
            if (!g.ok) { msg.textContent = 'لم يُحفظ شيء: ' + (g.status === 'not-found' ? 'هذا التحضير لم يعد موجوداً (ربما حُذف من تبويب آخر). أنشئ تحضيراً جديداً إن أردت.' : (g.error || 'تعذّرت قراءة التحضير.')) + ' بياناتك ما زالت في النموذج.'; return; }
            existing = g.record;
          }
          out = store.upsertRecord(PREP_TYPE, cid, model.buildRecord(res.values, existing));
        } catch (err) { out = { ok: false, error: 'خطأ غير متوقع أثناء الحفظ.' }; }
        finally { busy = false; submit.disabled = false; }
        if (!out.ok) { msg.textContent = 'لم يُحفظ التحضير: ' + (out.error || 'تعذّر الحفظ.') + ' بياناتك ما زالت في النموذج، أعد المحاولة.'; return; }
        persistent = out.persistent !== false;
        records = out.records; id = out.record.recordId;
        closeForm(); banner(); search.value = ''; drawList(); focusCard(id);
        if (persistent) say(editing ? 'تم حفظ التعديل.' : 'تم حفظ التحضير.', 3200);
        else say((editing ? 'حُفظ التعديل' : 'حُفظ التحضير') + ' في ذاكرة هذه الصفحة فقط وليس بشكل دائم. سيزول بإغلاقها أو إعادة تحميلها.', 8000);
      });
      formHost.appendChild(form);
      formHost.scrollIntoView({ block: 'start' });
      (editing ? els.title : els.subject).focus({ preventScroll: true });
    }

    function askDelete(r) {
      var title = model.field(r, 'title') || '(بلا عنوان)', id = model.field(r, 'recordId');
      askConfirm('حذف التحضير', 'سيُحذف نهائياً من هذا الصف تحضير «' + title + '» (' + (model.field(r, 'subject') || 'بلا مادة') + '، ' + model.formatDate(model.field(r, 'date')) + '). لا يمكن التراجع عن الحذف، ولا يتأثر سجل «ما أُخذ اليوم». هل تريد المتابعة؟', 'حذف التحضير', function () {
        var out;
        if (!sameClass()) return;
        out = store.deleteRecord(PREP_TYPE, cid, id);
        if (!out.ok) { say('لم يُحذف التحضير: ' + (out.error || 'تعذّر الحذف.'), 6000); if (out.status === 'not-found') { load(); banner(); drawList(); } return; }
        persistent = out.persistent !== false; records = out.records;
        if (editingId === id) closeForm();
        banner(); drawList(); count.tabIndex = -1; count.focus({ preventScroll: true });
        say(persistent ? 'تم حذف التحضير.' : 'حُذف التحضير من ذاكرة هذه الصفحة فقط وليس بشكل دائم.', persistent ? 3200 : 8000);
      });
    }

    addBtn = btn('primary', 'إضافة تحضير', function () { guard(function () { openForm(null); }); });
    bar.appendChild(count); bar.appendChild(addBtn); host.appendChild(bar);
    formHost.hidden = true; host.appendChild(formHost);
    search.type = 'search'; search.placeholder = 'ابحث بالمادة أو العنوان'; search.autocomplete = 'off'; search.setAttribute('aria-label', 'ابحث في التحاضير بالمادة أو العنوان');
    search.addEventListener('input', drawList);
    rc.setAttribute('aria-live', 'polite');
    listWrap.appendChild(search); listWrap.appendChild(rc); listWrap.appendChild(groupsBox); host.appendChild(listWrap);
    load(); banner(); drawList();
    prepsCtl = {
      cid: cid, dirty: function () { return formOpen && dirty; },
      reload: function () { if (activeId() !== cid) return; load(); banner(); drawList(); },
      // عند عبور منتصف الليل والصفحة مفتوحة: أعد التجميع (اليوم/باجر) دون المساس بالنموذج
      dayCheck: function () { if (activeId() === cid && shownToday && store.toLocalDate() !== shownToday) drawList(); }
    };
  }

  // ===== 03.6: عرض الطالب للقراءة فقط — التحاضير (prep) وما أُخذ سابقاً (archive) =====
  // يقرأ مباشرة من MarsaAcademicStore (preparations وdailyLessons) بـ classId الصف النشط؛ لا مخزن ثانٍ ولا نسخ.
  // لا توجد أي أزرار أو نماذج كتابة هنا (البحث فقط). هذا قيد واجهة محلي وليس حماية: الصلاحيات الفعلية تحتاج خادماً لاحقاً.
  // كل نص يُعرض بـ textContent/createTextNode؛ الروابط (http/https فقط) تُبنى من MarsaSafeText.segments.
  // حقل «الملاحظات» لا يُعرض للطالب لأنه ليس ضمن المطلوب وقد يكون داخلياً للممثل.
  var stCtl = null;
  function stRich(cls, text) {
    var p = mk('p', cls), segs = window.MarsaSafeText ? window.MarsaSafeText.segments(text) : [{ text: text }];
    segs.forEach(function (sg) {
      var a;
      if (sg.href) {
        a = mk('a', 'st-link', sg.text); a.href = sg.href; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow';
        p.appendChild(a);
      } else p.appendChild(document.createTextNode(sg.text));
    });
    return p;
  }
  // يضيف الحقل فقط إذا كانت قيمته نصاً غير فارغ؛ لا يظهر null/undefined/فراغ أبداً
  function stField(li, model, r, key, label) {
    var v = model.field(r, key), d;
    if (!v || !v.trim()) return;
    d = mk('div', 'lc-f'); d.appendChild(mk('small', 'muted', label)); d.appendChild(stRich('lc-t', v)); li.appendChild(d);
  }
  function stCard(model, r, tags, fields, extraCls) {
    var li = mk('li', 'lcard st-card' + (extraCls ? ' ' + extraCls : '')), title = model.field(r, 'title'), subj = model.field(r, 'subject'), meta = mk('p', 'lc-meta');
    li.setAttribute('data-record-id', model.field(r, 'recordId'));
    li.appendChild(mk('div', 'lc-top')).appendChild(mk('h3', null, title.trim() ? title : '(بلا عنوان)'));
    meta.appendChild(mk('span', 'tag', subj.trim() ? subj : '(بلا مادة)'));
    meta.appendChild(mk('span', 'lc-date', model.formatDate(model.field(r, 'date'))));
    tags.forEach(function (t) { meta.appendChild(mk('span', t[1], t[0])); });
    li.appendChild(meta);
    fields.forEach(function (f) { stField(li, model, r, f[0], f[1]); });
    return li;
  }
  // هيكل مشترك: ملاحظة القراءة فقط، حالة الصف/المكتبات، قراءة من المخزن، فراغ/خطأ/بحث، وفحص التغيّر بلا إعادة رسم لا لزوم لها
  function renderStudentView(cfg) {
    var store = window.MarsaAcademicStore, model = window[cfg.modelName], cid = activeId();
    var records = [], blockedMsg = '', persistent = true, sig = '';
    stCtl = null;
    host.appendChild(mk('div', 'notice st-note', cfg.note));
    if (!activeClass()) {
      var e0 = mk('p', 'empty'); e0.appendChild(mk('strong', null, 'لا يوجد صف نشط'));
      e0.appendChild(document.createTextNode('لم يُختر صف بعد، لذلك لا توجد بيانات لعرضها. يختار ممثل الصف الصف النشط من وضع ممثل الصف.'));
      host.appendChild(e0);
      return;
    }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox st-err', 'تعذّر تحميل ملفات العرض (' + cfg.files + '). تأكد أن المجلد كاملاً ثم أعد التحميل. لا يعني هذا أن لا بيانات للصف.')); return; }
    var bannerBox = mk('div'), count = mk('p', 'count st-count'), search = mk('input', 'field st-search'), rc = mk('p', 'resc'), body = mk('div', 'st-body');
    bannerBox.setAttribute('role', 'status');
    search.type = 'search'; search.placeholder = cfg.searchHint; search.autocomplete = 'off'; search.setAttribute('enterkeyhint', 'search'); search.setAttribute('aria-label', cfg.searchLabel);
    rc.setAttribute('aria-live', 'polite');
    host.appendChild(bannerBox); host.appendChild(count); host.appendChild(search); host.appendChild(rc); host.appendChild(body);

    function load() {
      var r = store.readCollection(cfg.type, cid), today = store.toLocalDate();
      persistent = r.persistent !== false;
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت القراءة.'; }
      else { blockedMsg = ''; records = r.records; }
      sig = today + '|' + persistent + '|' + blockedMsg + '|' + JSON.stringify(records);
    }
    function draw() {
      var q = search.value.trim(), shown, today = store.toLocalDate(), eb;
      bannerBox.textContent = '';
      if (blockedMsg) {
        eb = mk('div', 'notice warnbox st-err', 'تعذّرت قراءة ' + cfg.noun + ' لهذا الصف، ولذلك لا يمكن الجزم بأن القائمة فارغة: قد توجد بيانات لكنها غير مقروءة الآن. السبب: ' + blockedMsg + ' أخبر ممثل الصف ليراجعها.');
        eb.setAttribute('role', 'alert'); bannerBox.appendChild(eb);
      } else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك ما تراه مؤقت في ذاكرة هذه الصفحة وقد لا يعكس كل ما أضافه الممثل.'));
      body.textContent = '';
      count.textContent = blockedMsg ? '' : cfg.countLabel + records.length;
      search.hidden = !records.length || !!blockedMsg;
      rc.textContent = '';
      if (blockedMsg) return;
      if (!records.length) {
        var e = mk('p', 'empty'); e.appendChild(mk('strong', null, cfg.emptyTitle)); e.appendChild(document.createTextNode(cfg.emptyHelp)); body.appendChild(e);
        return;
      }
      shown = model.filterRecords(records, search.value);
      rc.textContent = q ? 'النتائج: ' + shown.length + ' من ' + records.length : '';
      if (!shown.length) { body.appendChild(mk('p', 'muted', 'لا توجد نتائج مطابقة للبحث.')); return; }
      cfg.draw(body, shown, today, q, model);
    }
    search.addEventListener('input', draw);
    load(); draw();
    stCtl = {
      cid: cid,
      // يُستدعى بعد تغيّر التخزين أو الصف أو اليوم أو عودة التبويب: يقرأ من المخزن نفسه ويعيد الرسم فقط إن تغيّر شيء
      check: function () {
        var before = sig;
        if (activeId() !== cid) { renderPage(state.view); return; }
        load();
        if (sig !== before) draw();
      }
    };
  }

  function renderStudentPreps() {
    renderStudentView({
      type: 'preparations', modelName: 'MarsaPrepsModel', files: 'js/academic-store.js و js/preps-model.js', noun: 'التحاضير',
      note: 'عرض للقراءة فقط: تظهر هنا التحاضير التي يضيفها ممثل الصف. البيانات محفوظة في متصفح هذا الجهاز ولا تصل إلى أجهزة أخرى قبل بناء المزامنة.',
      countLabel: 'عدد التحاضير: ', searchHint: 'ابحث بالمادة أو الموضوع', searchLabel: 'ابحث في التحاضير بالمادة أو الموضوع',
      emptyTitle: 'لا توجد تحاضير مضافة لهذا الصف بعد', emptyHelp: 'حين يضيف ممثل الصف تحضيراً سيظهر هنا تحت «اليوم» أو «باجر» أو «تحاضير أخرى».',
      draw: function (body, shown, today, q, model) {
        var g = model.groupByDay(shown, today);
        [['today', 'اليوم', g.today, 'لا يوجد تحضير لليوم.', today], ['tomorrow', 'باجر', g.tomorrow, 'لا يوجد تحضير لباجر.', g.tomorrowDate], ['other', 'تحاضير أخرى', g.other, 'لا توجد تحاضير أخرى.', '']].forEach(function (x) {
          var sec, ul;
          if (q && !x[2].length) return;
          sec = mk('section', 'pgroup'); sec.setAttribute('data-group', x[0]);
          sec.appendChild(mk('h2', null, x[1] + (x[2].length ? ' (' + x[2].length + ')' : '')));
          if (x[4]) sec.appendChild(mk('p', 'muted pg-date', model.formatDate(x[4])));
          if (!x[2].length) sec.appendChild(mk('p', 'muted', x[3]));
          else {
            ul = mk('ul', 'llist');
            x[2].forEach(function (r) {
              var d = model.field(r, 'date'), tags = [];
              if (x[0] === 'today') tags.push(['اليوم', 'tag on']); else if (x[0] === 'tomorrow') tags.push(['باجر', 'tag on']);
              else if (model.isLocalDate(d) && d < today) tags.push(['مضى موعده', 'tag']);
              ul.appendChild(stCard(model, r, tags, [['content', 'المحتوى / النقاط'], ['pages', 'الصفحات / المصدر'], ['homework', 'الواجب']], 'pcard' + (x[0] === 'today' ? ' is-today' : '')));
            });
            sec.appendChild(ul);
          }
          body.appendChild(sec);
        });
      }
    });
  }

  // ===== 03.9: الأرشيف الدراسي (عرض الطالب للقراءة فقط) =====
  // عرض مشتق: يقرأ dailyLessons وpreparations وexams من MarsaAcademicStore بـ classId الصف النشط ويبني العناصر عبر MarsaArchiveModel.
  // لا مخزن للأرشيف ولا نسخ ولا نقل ولا حذف: كل سجل يبقى في مصدره، والتعديل من شاشة الممثل المناسبة. لا غياب ولا درجات ولا مدفوعات.
  // البحث والفلاتر حالة واجهة في الذاكرة فقط (لا تُكتب في التخزين) وتُصفّي العرض دون المساس بالسجلات.
  // خطأ قراءة أي مصدر لا يُعرض كفراغ: تظهر رسالة ويُعرض ما أمكن قراءته. هذا قيد واجهة محلي وليس حماية (انظر تنبيه 03.6).
  var AK_SRC = [['lesson', 'dailyLessons', 'MarsaLessonsModel', 'الدروس'], ['prep', 'preparations', 'MarsaPrepsModel', 'التحاضير'], ['exam', 'exams', 'MarsaExamsModel', 'الامتحانات']];
  function akCard(e, today) {
    var M = window.MarsaArchiveModel, LM = window.MarsaLessonsModel, r = e.record, li, meta, st, over;
    var model = window[AK_SRC[M.KINDS.indexOf(e.kind)][2]], title = model.field(r, 'title'), subj = model.field(r, 'subject');
    over = e.kind === 'exam' && e.status === 'scheduled' && e.date && e.date < today;
    li = mk('li', 'lcard st-card ak-card ak-' + e.kind + (e.kind === 'exam' ? ' ecard st-ecard' : '') + (e.status === 'cancelled' ? ' is-cancelled' : '') + (over ? ' is-overdue' : ''));
    li.setAttribute('data-record-id', e.recordId); li.setAttribute('data-kind', e.kind);
    li.appendChild(mk('div', 'lc-top')).appendChild(mk('h3', null, title.trim() ? title : '(بلا عنوان)'));
    meta = mk('p', 'lc-meta');
    meta.appendChild(mk('span', 'tag ak-kind ak-kind-' + e.kind, M.KIND_LABELS[e.kind]));
    meta.appendChild(mk('span', 'tag', subj.trim() ? subj : '(بلا مادة)'));
    meta.appendChild(mk('span', 'lc-date', e.date ? LM.formatDate(e.date) : 'بلا تاريخ صالح'));
    if (e.kind === 'exam') { st = e.status; meta.appendChild(mk('span', 'tag st-' + st, model.STATUS_LABELS[st])); }
    if (over) meta.appendChild(mk('span', 'tag warn', 'مضى موعده ولم تُحدَّث حالته'));
    if (e.kind === 'lesson' && e.date === today) meta.appendChild(mk('span', 'tag on', 'اليوم'));
    if (e.kind === 'lesson' && e.date && e.date > today) meta.appendChild(mk('span', 'tag warn', 'تاريخه بعد اليوم'));
    li.appendChild(meta);
    if (e.kind === 'lesson') { stField(li, model, r, 'summary', 'الملخص'); stField(li, model, r, 'pages', 'الصفحات / المصدر'); stField(li, model, r, 'homework', 'الواجب'); }
    else if (e.kind === 'prep') { stField(li, model, r, 'content', 'المحتوى / النقاط'); stField(li, model, r, 'pages', 'الصفحات / المصدر'); stField(li, model, r, 'homework', 'الواجب'); }
    else { stField(li, model, r, 'topics', 'المواضيع المطلوبة'); stField(li, model, r, 'notes', 'التعليمات'); }
    return li;
  }
  function renderStudentArchive() {
    var store = window.MarsaAcademicStore, M = window.MarsaArchiveModel, cid = activeId(), fs, src = {}, persistent = true, sig = '', allEntries = [], today = '';
    stCtl = null;
    host.appendChild(mk('div', 'notice st-note', 'عرض للقراءة فقط: أرشيف الصف الدراسي المشترك، مشتق من سجلات ممثل الصف: الدروس المشروحة، والتحاضير التي مضى تاريخها، والامتحانات التي أُجريت أو مضى موعدها، من الأحدث إلى الأقدم. لا يُنقل شيء إلى الأرشيف ولا يُنسخ؛ كل سجل يبقى في مصدره. التحاضير والامتحانات القادمة في صفحتيهما. البيانات محفوظة في متصفح هذا الجهاز فقط.'));
    if (!activeClass()) {
      var e0 = mk('p', 'empty'); e0.appendChild(mk('strong', null, 'لا يوجد صف نشط'));
      e0.appendChild(document.createTextNode('لم يُختر صف بعد، لذلك لا توجد بيانات لعرضها. يختار ممثل الصف الصف النشط من وضع ممثل الصف.'));
      host.appendChild(e0);
      return;
    }
    if (!store || !M || !window.MarsaLessonsModel || !window.MarsaPrepsModel || !window.MarsaExamsModel) { host.appendChild(mk('div', 'notice warnbox st-err', 'تعذّر تحميل ملفات العرض (js/academic-store.js و js/archive-model.js و js/lessons-model.js و js/preps-model.js و js/exams-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل. لا يعني هذا أن لا بيانات للصف.')); return; }
    fs = M.defaults();
    var bannerBox = mk('div'), count = mk('p', 'count st-count'), ctrl = mk('div', 'akf'), body = mk('div', 'st-body'), rc = mk('p', 'resc ak-res');
    var row = mk('div', 'akf-row'), search = mk('input', 'field st-search'), tog = mk('button', 'link akf-toggle'), panel = mk('div', 'akf-panel'), clearTop = mk('button', 'link akf-clear', 'مسح الفلاتر');
    bannerBox.setAttribute('role', 'status');
    search.type = 'search'; search.placeholder = 'ابحث بالمادة أو العنوان'; search.autocomplete = 'off'; search.setAttribute('enterkeyhint', 'search'); search.setAttribute('aria-label', 'ابحث في الأرشيف بالمادة أو العنوان');
    tog.type = 'button'; tog.setAttribute('aria-expanded', 'false'); tog.setAttribute('aria-controls', 'akf-panel'); panel.id = 'akf-panel'; panel.hidden = true;
    clearTop.type = 'button'; clearTop.hidden = true;
    rc.setAttribute('aria-live', 'polite');
    // لوحة الفلاتر: نوع السجل + الفترة (مكان واحد)
    var kLab = mk('p', 'akf-lab', 'نوع السجل'), kRow = mk('div', 'akf-kinds'), kBtns = {};
    kRow.setAttribute('role', 'group'); kRow.setAttribute('aria-label', 'نوع السجل');
    ['all'].concat(M.KINDS).forEach(function (k) {
      var b = mk('button', 'link akf-kind'); b.type = 'button'; b.setAttribute('data-kind', k); kBtns[k] = b;
      b.addEventListener('click', function () { fs.kind = k; sync(); draw(); });
      kRow.appendChild(b);
    });
    var pLab = mk('label', 'akf-lab', 'الفترة'), pSel = mk('select', 'field akf-period'), dRow = mk('div', 'akf-dates'), fromIn = mk('input', 'field'), toIn = mk('input', 'field');
    pLab.setAttribute('for', 'akf-period'); pSel.id = 'akf-period';
    M.PERIODS.forEach(function (p) { var o = mk('option', null, M.PERIOD_LABELS[p]); o.value = p; pSel.appendChild(o); });
    fromIn.type = 'date'; toIn.type = 'date'; fromIn.id = 'akf-from'; toIn.id = 'akf-to';
    var fl = mk('label', 'akf-dl'), tl = mk('label', 'akf-dl');
    fl.appendChild(mk('span', null, 'من')); fl.appendChild(fromIn); tl.appendChild(mk('span', null, 'إلى')); tl.appendChild(toIn);
    dRow.appendChild(fl); dRow.appendChild(tl); dRow.hidden = true;
    var pMsg = mk('p', 'muted akf-msg'); pMsg.setAttribute('role', 'status');
    var clearIn = mk('button', 'link akf-clear', 'مسح الفلاتر'); clearIn.type = 'button';
    panel.appendChild(kLab); panel.appendChild(kRow); panel.appendChild(pLab); panel.appendChild(pSel); panel.appendChild(dRow); panel.appendChild(pMsg); panel.appendChild(clearIn);
    row.appendChild(search); row.appendChild(tog); ctrl.appendChild(row); ctrl.appendChild(panel);
    host.appendChild(bannerBox); host.appendChild(count); host.appendChild(ctrl); host.appendChild(rc); host.appendChild(body);

    function load() {
      var errs = [], recs = { lesson: [], prep: [], exam: [] }, raw = 0, all = true;
      today = store.toLocalDate(); persistent = true;
      AK_SRC.forEach(function (s) {
        var r = store.readCollection(s[1], cid);
        if (r.persistent === false) persistent = false;
        if (!r.ok) { errs.push(s[3] + ': ' + (r.error || 'تعذّرت القراءة.')); all = false; }
        else { recs[s[0]] = r.records; raw += r.records.length; }
      });
      src = { errors: errs, raw: raw, allReadable: all, recs: recs };
      allEntries = M.sortEntries(M.buildEntries({ classId: cid, today: today, lessons: recs.lesson, preps: recs.prep, exams: recs.exam }));
      sig = today + '|' + persistent + '|' + errs.join('~') + '|' + JSON.stringify(recs);
    }
    function sync() {
      var n = M.activeFilterCount(fs, today), cnt = M.countByKind(allEntries), pr = M.periodRange(fs, today);
      tog.textContent = 'تصفية' + (n ? ' (' + n + ')' : '');
      tog.setAttribute('aria-label', n ? 'تصفية، ' + n + ' فلتر نشط' : 'تصفية');
      tog.classList.toggle('on', n > 0);
      ['all'].concat(M.KINDS).forEach(function (k) { kBtns[k].textContent = M.KIND_FILTER_LABELS[k] + ' (' + cnt[k] + ')'; kBtns[k].setAttribute('aria-pressed', fs.kind === k ? 'true' : 'false'); });
      if (pSel.value !== fs.period) pSel.value = fs.period;
      dRow.hidden = fs.period !== 'custom';
      pMsg.textContent = pr.message;
      clearTop.hidden = !M.hasAnyFilter(fs, today); clearIn.hidden = clearTop.hidden;
    }
    function draw() {
      var shown, n, eb, ul, any = M.hasAnyFilter(fs, today);
      bannerBox.textContent = ''; body.textContent = ''; rc.textContent = '';
      if (src.errors.length) {
        eb = mk('div', 'notice warnbox st-err', 'تعذّرت قراءة بعض سجلات هذا الصف، ولذلك لا يمكن الجزم بأن الأرشيف كامل أو فارغ: قد توجد سجلات غير مقروءة الآن، وما يظهر أدناه مما أمكن قراءته فقط. ' + src.errors.join(' — ') + ' أخبر ممثل الصف ليراجعها.');
        eb.setAttribute('role', 'alert'); bannerBox.appendChild(eb);
      } else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك ما تراه مؤقت في ذاكرة هذه الصفحة وقد لا يعكس كل ما أضافه الممثل.'));
      ctrl.hidden = !allEntries.length;
      count.textContent = allEntries.length ? 'عدد سجلات الأرشيف: ' + allEntries.length : '';
      sync();
      if (!allEntries.length) {
        if (src.errors.length) return; // لا نقول «فارغ» ونحن لا نعرف
        var e = mk('p', 'empty');
        if (!src.raw) { e.appendChild(mk('strong', null, 'لا توجد سجلات دراسية لهذا الصف بعد')); e.appendChild(document.createTextNode('حين يسجّل ممثل الصف ما شُرح في «ما أُخذ اليوم» أو يضيف تحاضير وامتحانات سيظهر منها هنا ما أصبح سابقاً، مع نوع كل سجل ومادته وتاريخه.')); }
        else { e.appendChild(mk('strong', null, 'لا توجد سجلات سابقة بعد')); e.appendChild(document.createTextNode('للصف سجلات دراسية، لكن لم يصبح منها سابقاً ما يدخل الأرشيف: التحاضير والامتحانات القادمة تظهر في صفحتيهما، وتنتقل إلى هنا في العرض فقط بعد مرور تاريخها.')); }
        body.appendChild(e); return;
      }
      shown = M.filterEntries(allEntries, fs, today); n = M.activeFilterCount(fs, today);
      rc.textContent = 'النتائج: ' + shown.length + ' من ' + allEntries.length + (n ? ' — الفلاتر النشطة: ' + n : '');
      if (!shown.length) {
        var ne = mk('div', 'empty ak-none'); ne.appendChild(mk('strong', null, 'لا توجد نتائج مطابقة'));
        ne.appendChild(document.createTextNode(any ? 'السجلات موجودة في الأرشيف، لكن لا شيء منها يطابق البحث أو الفلاتر الحالية. السجلات الأصلية لم تتغير.' : ''));
        if (any) { var cb = mk('button', 'link akf-clear', 'مسح الفلاتر'); cb.type = 'button'; cb.addEventListener('click', clearAll); ne.appendChild(document.createElement('br')); ne.appendChild(cb); }
        body.appendChild(ne); return;
      }
      ul = mk('ul', 'llist ak-list');
      shown.forEach(function (x) { ul.appendChild(akCard(x, today)); });
      body.appendChild(ul);
    }
    function clearAll() { fs = M.defaults(); search.value = ''; fromIn.value = ''; toIn.value = ''; sync(); draw(); tog.focus({ preventScroll: true }); }
    search.addEventListener('input', function () { fs.q = search.value; sync(); draw(); });
    tog.addEventListener('click', function () { panel.hidden = !panel.hidden; tog.setAttribute('aria-expanded', panel.hidden ? 'false' : 'true'); });
    pSel.addEventListener('change', function () { fs.period = pSel.value; sync(); draw(); });
    fromIn.addEventListener('input', function () { fs.from = fromIn.value; sync(); draw(); });
    toIn.addEventListener('input', function () { fs.to = toIn.value; sync(); draw(); });
    clearTop.addEventListener('click', clearAll); clearIn.addEventListener('click', clearAll);
    // زر المسح الخارجي يُوضع بعد سطر النتائج لسهولة الوصول
    rc.parentNode.insertBefore(clearTop, rc.nextSibling);
    load(); draw();
    stCtl = {
      cid: cid,
      // بعد تغيّر التخزين أو الصف أو اليوم أو عودة التبويب: يقرأ المصادر الثلاثة ويعيد الرسم فقط إن تغيّر شيء (حالة البحث والفلاتر تبقى)
      check: function () {
        var before = sig;
        if (activeId() !== cid) { renderPage(state.view); return; }
        load();
        if (sig !== before) draw();
      }
    };
  }


  // ===== 03.8: الامتحانات — عرض الطالب للقراءة فقط =====
  // يقرأ النوع exams من MarsaAcademicStore بـ classId الصف النشط عبر هيكل renderStudentView نفسه (فراغ ≠ خطأ، بحث، فحص تغيّر)، ولا يكتب شيئاً.
  // التقسيم من MarsaExamsModel.partition نفسه المستعمل في شاشة الممثل: «قادم» = الحالة مجدول والتاريخ اليوم أو بعده (بالتقويم المحلي).
  // أقرب امتحان = أول القادمة. الملغى و«أُجري» لا يدخلان القادمة أبداً، ومضيّ التاريخ لا يحذف سجلاً ولا يغيّر حالته (المجدول الفائت يُوسَم فقط).
  // لا درجات ولا أسئلة ولا أزرار تعديل/حذف. هذا قيد واجهة محلي وليس حماية (انظر تنبيه الصلاحيات في 03.6).
  function stExamCard(model, r, today, hero) {
    var st = model.statusOf(r), date = model.field(r, 'examDate'), title = model.field(r, 'title'), subj = model.field(r, 'subject');
    var up = model.isUpcoming(r, today), over = model.isOverdue(r, today), rel = up ? model.relativeLabel(date, today) : '';
    var li = mk('li', 'lcard st-card pcard ecard st-ecard' + (hero ? ' is-hero' : '') + (st === 'cancelled' ? ' is-cancelled' : '') + (over ? ' is-overdue' : '') + (rel === 'اليوم' ? ' is-today' : '')), meta = mk('p', 'lc-meta');
    li.setAttribute('data-record-id', model.field(r, 'recordId')); li.setAttribute('data-status', st);
    li.appendChild(mk('div', 'lc-top')).appendChild(mk('h3', null, title.trim() ? title : '(بلا عنوان)'));
    meta.appendChild(mk('span', 'tag', subj.trim() ? subj : '(بلا مادة)'));
    meta.appendChild(mk('span', 'lc-date', model.formatDate(date)));
    meta.appendChild(mk('span', 'tag st-' + st + (st === 'scheduled' && up ? ' on' : ''), model.STATUS_LABELS[st]));
    if (rel) meta.appendChild(mk('span', 'tag rel', rel));
    if (over) meta.appendChild(mk('span', 'tag warn', 'مضى موعده ولم تُحدَّث حالته'));
    if (!model.isLocalDate(date)) meta.appendChild(mk('span', 'tag warn', 'بلا تاريخ صالح'));
    li.appendChild(meta);
    stField(li, model, r, 'topics', 'المواضيع المطلوبة');
    stField(li, model, r, 'notes', 'التعليمات');
    return li;
  }
  function renderStudentExams() {
    renderStudentView({
      type: 'exams', modelName: 'MarsaExamsModel', files: 'js/academic-store.js و js/exams-model.js', noun: 'الامتحانات',
      note: 'عرض للقراءة فقط: هذه الامتحانات كما أضافها ممثل الصف. لا تُحذف الامتحانات السابقة بمرور التاريخ. البيانات محفوظة في متصفح هذا الجهاز ولا تصل إلى أجهزة أخرى قبل بناء المزامنة.',
      countLabel: 'عدد الامتحانات: ', searchHint: 'ابحث بالمادة أو العنوان أو المواضيع', searchLabel: 'ابحث في الامتحانات بالمادة أو العنوان أو المواضيع',
      emptyTitle: 'لا توجد امتحانات مضافة لهذا الصف بعد', emptyHelp: 'حين يضيف ممثل الصف امتحاناً سيظهر هنا مع المادة والتاريخ والمواضيع المطلوبة، ويبقى بعد انتهائه في «السابقة والمنتهية».',
      draw: function (body, shown, today, q, model) {
        var parts = model.partition(shown, today), up = parts.upcoming, rest = up.slice(1), sec, ul;
        function section(key, title, count, hint) {
          var s = mk('section', 'pgroup'); s.setAttribute('data-group', key);
          s.appendChild(mk('h2', null, title + (count ? ' (' + count + ')' : '')));
          if (hint) s.appendChild(mk('p', 'muted', hint));
          return s;
        }
        function list(items, hero) { var u = mk('ul', 'llist'); items.forEach(function (r) { u.appendChild(stExamCard(model, r, today, hero)); }); return u; }
        // 1) أقرب امتحان مجدول
        sec = section('nearest', 'أقرب امتحان', 0, up.length ? '' : (q ? 'لا يوجد امتحان قادم ضمن نتائج البحث.' : 'لا يوجد امتحان مجدول قادم.'));
        if (up.length) sec.appendChild(list([up[0]], true));
        body.appendChild(sec);
        // 2) بقية القادمة (دون تكرار الأقرب)
        if (!(q && !rest.length)) {
          sec = section('upcoming', 'الامتحانات القادمة', rest.length, rest.length ? '' : (up.length ? 'لا توجد امتحانات قادمة أخرى بعد الأقرب.' : ''));
          if (rest.length) sec.appendChild(list(rest, false));
          if (rest.length || up.length) body.appendChild(sec);
        }
        // 3) السابقة والمنتهية: أُجري، أُلغي، ومجدول فات تاريخه
        if (!(q && !parts.finished.length)) {
          sec = section('finished', 'السابقة والمنتهية', parts.finished.length, parts.finished.length ? 'تشمل ما أُجري وما أُلغي وما فات موعده. الملغى لا يُعدّ موعداً قادماً.' : 'لا توجد امتحانات سابقة أو منتهية.');
          if (parts.finished.length) sec.appendChild(list(parts.finished, false));
          body.appendChild(sec);
        }
      }
    });
  }

  // ===== 03.5: الامتحانات ومواعيدها ومواضيعها — وضع ممثل الصف =====
  // التخزين عبر MarsaAcademicStore (النوع exams) وclassId الصف النشط وقت فتح الصفحة. بلا درجات ولا أسئلة (مرحلة لاحقة).
  // «قادمة» = الحالة مجدول والتاريخ اليوم أو بعده (بالتقويم المحلي). غير ذلك في «السابقة والمنتهية».
  // مضيّ التاريخ وحده لا يُلغي الامتحان ولا يجعله «أُجري»: يُوسَم «مضى موعده» وتبقى حالته مجدول حتى يغيّرها الممثل. كل نص بـ textContent.
  var EXAM_TYPE = 'exams', examsCtl = null;
  function examCard(r, model, today, onEdit, onDelete) {
    var st = model.statusOf(r), date = model.field(r, 'examDate'), title = model.field(r, 'title'), subj = model.field(r, 'subject');
    var up = model.isUpcoming(r, today), over = model.isOverdue(r, today), rel = up ? model.relativeLabel(date, today) : '';
    var li = mk('li', 'lcard pcard ecard' + (st === 'cancelled' ? ' is-cancelled' : '') + (over ? ' is-overdue' : '') + (rel === 'اليوم' ? ' is-today' : ''), null), meta = mk('p', 'lc-meta');
    li.tabIndex = -1; li.setAttribute('data-record-id', model.field(r, 'recordId')); li.setAttribute('data-status', st);
    li.appendChild(mk('div', 'lc-top')).appendChild(mk('h3', null, title || '(بلا عنوان)'));
    meta.appendChild(mk('span', 'tag', subj || '(بلا مادة)'));
    meta.appendChild(mk('span', 'lc-date', model.formatDate(date)));
    meta.appendChild(mk('span', 'tag st-' + st + (st === 'scheduled' && up ? ' on' : ''), model.STATUS_LABELS[st]));
    if (rel) meta.appendChild(mk('span', 'tag rel', rel));
    if (over) meta.appendChild(mk('span', 'tag warn', 'مضى موعده ولم تُحدَّث حالته'));
    if (!model.isLocalDate(date)) meta.appendChild(mk('span', 'tag warn', 'بلا تاريخ صالح'));
    li.appendChild(meta);
    [['topics', 'نطاق المواضيع / الفصول'], ['notes', 'ملاحظات أو تعليمات']].forEach(function (f) {
      var v = model.field(r, f[0]), d;
      if (!v) return;
      d = mk('div', 'lc-f'); d.appendChild(mk('small', 'muted', f[1])); d.appendChild(mk('p', 'lc-t', v)); li.appendChild(d);
    });
    var acts = mk('div', 'acts'), eb = btn('link', 'تعديل', onEdit), db = btn('link danger', 'حذف', onDelete);
    eb.setAttribute('aria-label', 'تعديل الامتحان ' + (title || '')); db.setAttribute('aria-label', 'حذف الامتحان ' + (title || ''));
    acts.appendChild(eb); acts.appendChild(db); li.appendChild(acts);
    return li;
  }
  function renderExams() {
    var store = window.MarsaAcademicStore, model = window.MarsaExamsModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, formOpen = false, dirty = false, editingId = null, shownToday = '';
    examsCtl = null;
    if (!activeClass()) { noClassBlock(); return; }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل طبقة التخزين الأكاديمي أو منطق الامتحانات (js/academic-store.js و js/exams-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return; }
    classBar();
    host.appendChild(mk('div', 'notice', 'الامتحانات محفوظة في متصفح هذا الجهاز فقط، ولا تصل إلى الطلاب ولا إلى أجهزة أخرى. المزامنة تحتاج خادماً وستأتي في مرحلة لاحقة.'));
    host.appendChild(mk('div', 'notice sepnote', 'هنا مواعيد الامتحانات ونطاق مواضيعها فقط. لا درجات ولا أسئلة امتحان في هذه المرحلة، ولا ربط بدرجات الطلاب بعد.'));
    var bannerBox = mk('div'), bar = mk('div', 'toolbar'), count = mk('span', 'count'), addBtn;
    var formHost = mk('section', 'part lform'), listWrap = mk('div', 'part'), groupsBox = mk('div', 'pgroups');
    host.appendChild(bannerBox);

    function load() {
      var r = store.readCollection(EXAM_TYPE, cid);
      persistent = r.persistent !== false;
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت قراءة الامتحانات.'; return false; }
      blockedMsg = ''; records = r.records; return true;
    }
    function banner() {
      bannerBox.textContent = '';
      if (blockedMsg) bannerBox.appendChild(mk('div', 'notice warnbox', blockedMsg));
      else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك الامتحانات مؤقتة في ذاكرة هذه الصفحة وتزول بإغلاقها أو إعادة تحميلها.'));
      if (addBtn) addBtn.disabled = !!blockedMsg;
    }
    function sameClass() { if (activeId() !== cid || !activeClass()) { say('تغيّر الصف النشط أو لم يعد متاحاً. أعد فتح «الامتحانات».', 6000); return false; } return true; }

    function drawList() {
      var today = store.toLocalDate(), parts = model.partition(records, today);
      shownToday = today;
      count.textContent = 'عدد الامتحانات: ' + records.length;
      groupsBox.textContent = '';
      if (!records.length) {
        if (!blockedMsg) {
          var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لم تُضف أي امتحانات لهذا الصف بعد'));
          e.appendChild(document.createTextNode('اضغط «إضافة امتحان» ثم اكتب المادة وعنوان الامتحان وتاريخه. نطاق المواضيع والملاحظات اختياريان.'));
          groupsBox.appendChild(e);
        }
        return;
      }
      [['upcoming', 'الامتحانات القادمة', parts.upcoming, 'لا يوجد امتحان قادم. أضف امتحاناً بحالة «مجدول» وتاريخ اليوم أو ما بعده.'], ['finished', 'الامتحانات السابقة والمنتهية', parts.finished, 'لا توجد امتحانات سابقة أو منتهية.']].forEach(function (x) {
        var sec = mk('section', 'pgroup'), ul;
        sec.setAttribute('data-group', x[0]);
        sec.appendChild(mk('h2', null, x[1] + (x[2].length ? ' (' + x[2].length + ')' : '')));
        if (!x[2].length) sec.appendChild(mk('p', 'muted', x[3]));
        else {
          ul = mk('ul', 'llist');
          x[2].forEach(function (r) { ul.appendChild(examCard(r, model, today, function () { guard(function () { openForm(r); }); }, function () { askDelete(r); })); });
          sec.appendChild(ul);
        }
        groupsBox.appendChild(sec);
      });
    }
    function closeForm() { formOpen = false; dirty = false; editingId = null; formHost.hidden = true; formHost.textContent = ''; }
    function guard(fn) {
      if (formOpen && dirty) askConfirm('تجاهل ما كتبته؟', 'النموذج المفتوح فيه بيانات لم تُحفظ بعد. إن تابعت فستُفقد.', 'تجاهل والمتابعة', fn);
      else fn();
    }
    function focusCard(id) {
      var items = groupsBox.querySelectorAll('li[data-record-id]'), i;
      for (i = 0; i < items.length; i++) if (items[i].getAttribute('data-record-id') === id) { items[i].scrollIntoView({ block: 'nearest' }); items[i].focus({ preventScroll: true }); return; }
    }

    function openForm(rec) {
      var editing = !!rec, form = mk('form', 'lf'), msg = mk('p', 'err'), els = {}, errs = {}, busy = false, finished = false, submit;
      formOpen = true; dirty = false; editingId = editing ? model.field(rec, 'recordId') : null;
      formHost.hidden = false; formHost.textContent = '';
      var h = mk('h2', null, editing ? 'تعديل امتحان' : 'إضافة امتحان'); h.tabIndex = -1; formHost.appendChild(h);
      formHost.appendChild(mk('p', 'muted', editing ? 'تعديل الامتحان لا يغيّر معرّفه الداخلي ولا صفه.' : 'المطلوب: المادة والعنوان والتاريخ والحالة. نطاق المواضيع والملاحظات اختياريان.'));
      form.noValidate = true;
      var REQ = { subject: 1, title: 1, examDate: 1, status: 1 };
      function addField(key, el, parent) {
        var g = mk('div', 'fg'), lab = mk('label', 'fl', model.LABELS[key] + (REQ[key] ? ' (مطلوب)' : ' (اختياري)')), er = mk('p', 'err');
        el.id = 'ef-' + key; lab.htmlFor = el.id; er.id = 'ef-' + key + '-e'; er.setAttribute('aria-live', 'polite'); el.setAttribute('aria-describedby', er.id);
        if (REQ[key]) el.setAttribute('aria-required', 'true');
        if (model.LIMITS[key]) el.maxLength = model.LIMITS[key];
        el.addEventListener('input', function () { dirty = true; er.textContent = ''; el.removeAttribute('aria-invalid'); msg.textContent = ''; });
        el.addEventListener('change', function () { dirty = true; er.textContent = ''; el.removeAttribute('aria-invalid'); msg.textContent = ''; });
        els[key] = el; errs[key] = er;
        g.appendChild(lab); g.appendChild(el); g.appendChild(er); parent.appendChild(g);
      }
      function text() { var i = mk('input', 'field'); i.type = 'text'; i.autocomplete = 'off'; i.setAttribute('enterkeyhint', 'next'); return i; }
      function area(rows) { var t = mk('textarea', 'field'); t.rows = rows; t.autocomplete = 'off'; return t; }
      var s = text(), t = text(), d = mk('input', 'field'), st = mk('select', 'field'), tp = area(4), nt = area(3);
      s.placeholder = 'اسم المادة كما تكتبه أنت'; t.placeholder = 'مثال: امتحان شهري، امتحان نصف السنة';
      tp.placeholder = 'الفصول أو المواضيع التي يشملها الامتحان'; nt.placeholder = 'تعليمات أو ما يجب إحضاره';
      d.type = 'date'; d.min = model.MIN_YEAR + '-01-01'; d.max = model.MAX_YEAR + '-12-31';
      model.STATUSES.forEach(function (k) { var o = mk('option', null, model.STATUS_LABELS[k]); o.value = k; st.appendChild(o); });
      var subs = model.subjectsOf(records);
      if (subs.length) {
        var dl = mk('datalist'); dl.id = 'ef-subjects';
        subs.forEach(function (x) { var o = mk('option'); o.value = x; dl.appendChild(o); });
        s.setAttribute('list', dl.id); form.appendChild(dl);
      }
      addField('subject', s, form); addField('title', t, form); addField('examDate', d, form); addField('status', st, form); addField('topics', tp, form); addField('notes', nt, form);
      if (editing) {
        s.value = model.field(rec, 'subject'); t.value = model.field(rec, 'title'); tp.value = model.field(rec, 'topics'); nt.value = model.field(rec, 'notes');
        d.value = model.isLocalDate(model.field(rec, 'examDate')) ? model.field(rec, 'examDate') : '';
        st.value = model.statusOf(rec);
      } else st.value = 'scheduled';
      msg.id = 'ef-msg'; msg.setAttribute('role', 'alert'); form.appendChild(msg);
      var acts = mk('div', 'dacts'); submit = mk('button', 'primary', editing ? 'حفظ التعديل' : 'حفظ الامتحان'); submit.type = 'submit';
      acts.appendChild(submit);
      acts.appendChild(btn('link', 'إلغاء', function () { guard(function () { closeForm(); }); }));
      form.appendChild(acts);

      form.addEventListener('submit', function (e) {
        var res, g, existing = null, out, id;
        e.preventDefault();
        // منع الإرسال المكرر: النقر المزدوج أو تكرار حدث النموذج لا يكتب سجلاً ثانياً
        if (busy || finished || !formOpen) return;
        if (!sameClass()) { closeForm(); return; }
        Object.keys(errs).forEach(function (k) { errs[k].textContent = ''; els[k].removeAttribute('aria-invalid'); });
        msg.textContent = '';
        res = model.validate({ subject: els.subject.value, title: els.title.value, examDate: els.examDate.value, status: els.status.value, topics: els.topics.value, notes: els.notes.value });
        if (!res.ok) {
          Object.keys(res.errors).forEach(function (k) { errs[k].textContent = res.errors[k]; els[k].setAttribute('aria-invalid', 'true'); });
          els[res.firstError].focus(); return;
        }
        busy = true; submit.disabled = true;
        try {
          if (editing) {
            g = store.getRecord(EXAM_TYPE, cid, editingId);
            if (!g.ok) { msg.textContent = 'لم يُحفظ شيء: ' + (g.status === 'not-found' ? 'هذا الامتحان لم يعد موجوداً (ربما حُذف من تبويب آخر). أنشئ امتحاناً جديداً إن أردت.' : (g.error || 'تعذّرت قراءة الامتحان.')) + ' بياناتك ما زالت في النموذج.'; return; }
            existing = g.record;
          }
          out = store.upsertRecord(EXAM_TYPE, cid, model.buildRecord(res.values, existing));
        } catch (err) { out = { ok: false, error: 'خطأ غير متوقع أثناء الحفظ.' }; }
        finally { busy = false; submit.disabled = false; }
        if (!out.ok) { msg.textContent = 'لم يُحفظ الامتحان: ' + (out.error || 'تعذّر الحفظ.') + ' بياناتك ما زالت في النموذج، أعد المحاولة.'; return; }
        finished = true;
        persistent = out.persistent !== false;
        records = out.records; id = out.record.recordId;
        closeForm(); banner(); drawList(); focusCard(id);
        if (persistent) say(editing ? 'تم حفظ التعديل.' : 'تم حفظ الامتحان.', 3200);
        else say((editing ? 'حُفظ التعديل' : 'حُفظ الامتحان') + ' في ذاكرة هذه الصفحة فقط وليس بشكل دائم. سيزول بإغلاقها أو إعادة تحميلها.', 8000);
      });
      formHost.appendChild(form);
      formHost.scrollIntoView({ block: 'start' });
      (editing ? els.title : els.subject).focus({ preventScroll: true });
    }

    function askDelete(r) {
      var title = model.field(r, 'title') || '(بلا عنوان)', id = model.field(r, 'recordId');
      askConfirm('حذف الامتحان', 'سيُحذف نهائياً من هذا الصف امتحان «' + title + '» (' + (model.field(r, 'subject') || 'بلا مادة') + '، ' + model.formatDate(model.field(r, 'examDate')) + '). لا يمكن التراجع عن الحذف. هل تريد المتابعة؟', 'حذف الامتحان', function () {
        var out;
        if (!sameClass()) return;
        out = store.deleteRecord(EXAM_TYPE, cid, id);
        if (!out.ok) { say('لم يُحذف الامتحان: ' + (out.error || 'تعذّر الحذف.'), 6000); if (out.status === 'not-found') { load(); banner(); drawList(); } return; }
        persistent = out.persistent !== false; records = out.records;
        if (editingId === id) closeForm();
        banner(); drawList(); count.tabIndex = -1; count.focus({ preventScroll: true });
        say(persistent ? 'تم حذف الامتحان.' : 'حُذف الامتحان من ذاكرة هذه الصفحة فقط وليس بشكل دائم.', persistent ? 3200 : 8000);
      });
    }

    addBtn = btn('primary', 'إضافة امتحان', function () { guard(function () { openForm(null); }); });
    bar.appendChild(count); bar.appendChild(addBtn); host.appendChild(bar);
    formHost.hidden = true; host.appendChild(formHost);
    listWrap.appendChild(groupsBox); host.appendChild(listWrap);
    load(); banner(); drawList();
    examsCtl = {
      cid: cid, dirty: function () { return formOpen && dirty; },
      reload: function () { if (activeId() !== cid) return; load(); banner(); drawList(); },
      // عند عبور منتصف الليل والصفحة مفتوحة: أعد التقسيم (قادم/سابق) دون المساس بالنموذج
      dayCheck: function () { if (activeId() === cid && shownToday && store.toLocalDate() !== shownToday) drawList(); }
    };
  }

  // ===== 4.03: الحضور والغياب — وضع ممثل الصف =====
  // التخزين عبر MarsaAcademicStore (النوع attendance) وclassId الصف النشط وقت فتح الصفحة؛ المنطق كله في MarsaAttendanceModel.
  // سجل واحد لكل (studentId, date). الطالب بلا سجل «لم يُسجَّل» ولا يتحول إلى حاضر تلقائياً. الحفظ الجماعي ذرّي (upsertMany).
  // الخصوصية: لا يُقرأ هذا النوع من أي واجهة طالب. هذا حاجز واجهة فقط وليس حماية (localStorage مقروء من أدوات المتصفح).
  var ATT_TYPE = 'attendance', attCtl = null;
  function renderAttendance() {
    var store = window.MarsaAcademicStore, model = window.MarsaAttendanceModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, date = '', draft = {}, snapshot = null, busy = false, shownToday = '', day = { rows: [], legacy: [] };
    attCtl = null;
    if (!activeClass()) { noClassBlock(); return; }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل طبقة التخزين الأكاديمي أو منطق الحضور (js/academic-store.js و js/attendance-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return; }
    classBar();
    host.appendChild(mk('div', 'notice', 'الحضور محفوظ في متصفح هذا الجهاز فقط، ولا يظهر في وضع الطالب ولا على أجهزة أخرى. هذا حاجز واجهة وليس حماية: أي شخص يستعمل هذا المتصفح يستطيع قراءة البيانات من أدوات المتصفح.'));
    var bannerBox = mk('div'), sheet = mk('section', 'part att-sheet'), histBox = mk('section', 'part att-hist');
    var dateIn = mk('input', 'field'), dateErr = mk('p', 'err'), search = mk('input', 'field'), stSel = mk('select', 'field');
    var counts = mk('ul', 'att-counts'), dirtyP = mk('p', 'att-dirty'), msgP = mk('p', 'err'), rc = mk('p', 'resc'), emptyBox = mk('div'), ul = mk('ul', 'att-list'), legacyBox = mk('div');
    var saveBtn, bulkBtn, undoBulkBtn, revertBtn, nextBtn, rowEls = {};
    host.appendChild(bannerBox);

    function today() { return store.toLocalDate(); }
    function sameClass() { if (activeId() !== cid) { say('تغيّر الصف النشط. أعد فتح «الحضور».'); return false; } return true; }
    function nameOf(id) { var s = findStudent(id); return s ? s.name : ''; }
    function load() {
      var r = store.readCollection(ATT_TYPE, cid);
      persistent = r.persistent !== false;
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت قراءة سجلات الحضور.'; return false; }
      blockedMsg = ''; records = r.records; return true;
    }
    function compute() { day = model.buildDay(activeList(), roster.students, records, date); }
    function resetDraft() {
      draft = {}; snapshot = null;
      day.rows.forEach(function (r) { if (r.record) draft[r.studentId] = { status: r.record.status, note: r.record.note || '' }; });
    }
    function isDirty() { return !blockedMsg && model.isDirty(draft, day.rows); }
    function changedCount() {
      var n = 0;
      day.rows.forEach(function (r) { var d = draft[r.studentId] || {}; if ((d.status || null) !== (r.status || null) || model.cleanNote(d.note) !== model.cleanNote(r.record && r.record.note)) n++; });
      return n;
    }
    function banner() {
      bannerBox.textContent = '';
      if (blockedMsg) bannerBox.appendChild(mk('div', 'notice warnbox', blockedMsg));
      else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك السجلات مؤقتة في ذاكرة هذه الصفحة وتزول بإغلاقها أو إعادة تحميلها.'));
      var c = model.findConflicts(records);
      if (c.length) bannerBox.appendChild(mk('div', 'notice warnbox', 'وُجد تكرار في سجلات الحضور (' + c.length + ' حالة). لم يُحذف شيء تلقائياً؛ راجع النسخة الاحتياطية قبل أي تعديل.'));
    }
    function drawCounts() {
      var c = model.countRows(day.rows), items = [['present', 'حاضر'], ['absent', 'غائب'], ['late', 'متأخر'], ['excused', 'بعذر'], ['unrecorded', 'غير مسجّل']];
      counts.textContent = '';
      items.forEach(function (it) { var li = mk('li', 'ac-' + it[0]); li.appendChild(mk('b', null, String(c[it[0]]))); li.appendChild(mk('span', null, it[1])); counts.appendChild(li); });
      counts.setAttribute('aria-label', 'عدّادات يوم ' + model.formatDate(date) + ' للطلاب الفعّالين (' + c.total + ')، من السجلات المحفوظة فقط');
    }
    function drawControls() {
      var n = changedCount(), disabled = !!blockedMsg || !day.rows.length;
      dirtyP.textContent = n ? 'تغييرات غير محفوظة: ' + n + '. لن تُسجَّل حتى تضغط «حفظ الحضور».' : '';
      saveBtn.disabled = disabled || busy || n === 0;
      revertBtn.disabled = disabled || n === 0;
      bulkBtn.disabled = disabled;
      undoBulkBtn.hidden = !snapshot;
      dateIn.disabled = !!blockedMsg;
      nextBtn.disabled = !!blockedMsg || date >= today();
    }
    function touch() { snapshot = null; msgP.textContent = ''; drawControls(); }

    function updateRowState(sid) {
      var el = rowEls[sid], r, d, base;
      if (!el) return;
      r = day.rows.filter(function (x) { return x.studentId === sid; })[0]; d = draft[sid] || {};
      base = r.status || null;
      el.li.classList.toggle('chg', (d.status || null) !== base || model.cleanNote(d.note) !== model.cleanNote(r.record && r.record.note));
      el.flag.textContent = el.li.classList.contains('chg') ? 'غير محفوظ' : '';
      el.note.disabled = !model.isStatus(d.status) || !!blockedMsg;
      el.clear.hidden = !!r.record || !model.isStatus(d.status);
    }
    function rowItem(r) {
      var sid = r.studentId, li = mk('li', 'arow'), top = mk('div', 'ar-top'), fs = mk('fieldset', 'ar-st'), lg = mk('legend', 'vh', 'حالة حضور ' + r.name), d = draft[sid] || {};
      var num = mk('span', 'num', String(r.number)), nm = mk('b', 'ar-n', r.name), tag = mk('span', 'tag' + (r.record ? ' on' : ''), model.label(r.status)), flag = mk('span', 'ar-flag');
      li.setAttribute('data-student-id', sid);
      top.appendChild(num); top.appendChild(nm); top.appendChild(tag); top.appendChild(flag); li.appendChild(top);
      fs.appendChild(lg);
      model.STATUSES.forEach(function (s) {
        var lab = mk('label', 'ar-o st-' + s), inp = mk('input'), sp = mk('span', null, model.LABELS[s]);
        inp.type = 'radio'; inp.name = 'att-' + sid; inp.value = s; inp.checked = d.status === s; inp.disabled = !!blockedMsg;
        inp.addEventListener('change', function () {
          draft[sid] = { status: s, note: (draft[sid] && draft[sid].note) || '' };
          touch(); updateRowState(sid);
        });
        lab.appendChild(inp); lab.appendChild(sp); fs.appendChild(lab);
      });
      li.appendChild(fs);
      var nrow = mk('div', 'ar-note'), note = mk('input', 'field'), clear = btn('link', 'إلغاء الاختيار', function () {
        delete draft[sid]; fs.querySelectorAll('input').forEach(function (i) { i.checked = false; }); note.value = ''; touch(); updateRowState(sid);
      });
      note.type = 'text'; note.maxLength = model.NOTE_MAX; note.autocomplete = 'off'; note.value = d.note || ''; note.placeholder = 'ملاحظة (اختيارية)';
      note.setAttribute('aria-label', 'ملاحظة حضور ' + r.name);
      note.addEventListener('input', function () { var cur = draft[sid] || {}; draft[sid] = { status: cur.status, note: note.value }; touch(); updateRowState(sid); });
      clear.setAttribute('aria-label', 'إلغاء اختيار حالة ' + r.name);
      nrow.appendChild(note); nrow.appendChild(clear); li.appendChild(nrow);
      if (r.record) {
        var acts = mk('div', 'acts'), del = btn('link danger', 'حذف السجل', function () { askDelete(r.record, r.name); });
        del.setAttribute('aria-label', 'حذف سجل حضور ' + r.name + ' ليوم ' + model.formatDate(date));
        acts.appendChild(del); li.appendChild(acts);
      }
      rowEls[sid] = { li: li, flag: flag, note: note, clear: clear };
      updateRowState(sid);
      return li;
    }
    function drawRows() {
      var shown = model.filterRows(day.rows, { query: search.value, status: stSel.value });
      ul.textContent = ''; emptyBox.textContent = ''; rowEls = {};
      rc.textContent = (search.value.trim() || stSel.value !== 'all') ? 'النتائج: ' + shown.length + ' من ' + day.rows.length : '';
      if (blockedMsg) return;
      if (!day.rows.length) {
        var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا يوجد طلاب فعّالون في هذا الصف'));
        e.appendChild(document.createTextNode('أضف الطلاب من قسم «الطلاب» ثم عُد لتسجيل الحضور. الطلاب المؤرشفون لا يظهرون هنا.'));
        emptyBox.appendChild(e); emptyBox.appendChild(btn('primary', 'فتح قسم الطلاب', function () { go('students'); }));
        return;
      }
      if (!shown.length) { emptyBox.appendChild(mk('p', 'muted', 'لا يوجد طلاب مطابقون للبحث أو الفلتر.')); return; }
      shown.forEach(function (r) { ul.appendChild(rowItem(r)); });
    }
    function drawLegacy() {
      legacyBox.textContent = '';
      if (blockedMsg || !day.legacy.length) return;
      legacyBox.appendChild(mk('h3', null, 'سجلات طلاب غير فعّالين في هذا اليوم (للقراءة والحذف فقط)'));
      legacyBox.appendChild(mk('p', 'muted', 'لا تدخل في العدّادات أعلاه، ولا يمكن تسجيل حضور جديد لهؤلاء الطلاب.'));
      var l = mk('ul', 'att-legacy');
      day.legacy.forEach(function (it) {
        var li = mk('li', 'arow'), top = mk('div', 'ar-top'), nm = it.name || 'طالب غير موجود في قائمة هذا الصف';
        top.appendChild(mk('b', 'ar-n', nm));
        top.appendChild(mk('span', 'tag', it.kind === 'archived' ? 'مؤرشف' : 'غير معروف'));
        top.appendChild(mk('span', 'tag', model.label(it.record.status)));
        li.appendChild(top);
        if (it.record.note) li.appendChild(mk('p', 'lc-t', it.record.note));
        var del = btn('link danger', 'حذف السجل', function () { askDelete(it.record, nm); });
        del.setAttribute('aria-label', 'حذف سجل حضور ' + nm + ' ليوم ' + model.formatDate(it.record.date));
        li.appendChild(del); l.appendChild(li);
      });
      legacyBox.appendChild(l);
    }
    function drawHistory() {
      histBox.textContent = '';
      if (blockedMsg) return;
      histBox.appendChild(mk('h2', null, 'سجل الأيام'));
      histBox.appendChild(mk('p', 'muted', 'الأيام التي سُجّل فيها حضور، من الأحدث، مع عدّاد كل حالة لطلاب الصف الفعّالين.'));
      var fr = mk('div', 'att-filters'), f = mk('input', 'field'), t = mk('input', 'field'), s = mk('select', 'field'), list = mk('ul', 'att-days'), note = mk('p', 'resc');
      function fld(lbl, el, id) { var g = mk('div', 'fg'), l = mk('label', 'fl', lbl); el.id = id; l.htmlFor = id; g.appendChild(l); g.appendChild(el); fr.appendChild(g); }
      f.type = 'date'; t.type = 'date'; f.min = t.min = model.MIN_YEAR + '-01-01'; f.max = t.max = today();
      f.value = histState.from; t.value = histState.to;
      [['all', 'كل الحالات']].concat(model.STATUSES.map(function (k) { return [k, model.LABELS[k]]; })).forEach(function (o) { var op = mk('option', null, o[1]); op.value = o[0]; op.selected = histState.status === o[0]; s.appendChild(op); });
      fld('من تاريخ', f, 'ah-from'); fld('إلى تاريخ', t, 'ah-to'); fld('الحالة', s, 'ah-st');
      note.setAttribute('aria-live', 'polite');
      function draw() {
        var days;
        histState.from = f.value; histState.to = t.value; histState.status = s.value;
        list.textContent = '';
        if (f.value && t.value && f.value > t.value) { note.textContent = 'تاريخ البداية بعد تاريخ النهاية.'; return; }
        days = model.summarizeDays(records, { from: f.value || null, to: t.value || null, status: s.value, activeIds: activeList().map(function (x) { return x.studentId; }) });
        if (!days.length) { note.textContent = records.length ? 'لا توجد أيام مطابقة.' : 'لم يُسجَّل حضور لهذا الصف بعد.'; return; }
        note.textContent = 'عدد الأيام: ' + days.length + (days.length > 60 ? ' (يُعرض أحدث 60 يوماً؛ ضيّق المدى لرؤية الباقي)' : '');
        days.slice(0, 60).forEach(function (d) {
          var li = mk('li', 'adr'), info = mk('div', 'adr-i');
          info.appendChild(mk('b', null, model.formatDate(d.date)));
          info.appendChild(mk('span', 'muted', 'حاضر ' + d.present + ' · غائب ' + d.absent + ' · متأخر ' + d.late + ' · بعذر ' + d.excused + (d.legacy ? ' · طلاب غير فعّالين ' + d.legacy : '')));
          li.appendChild(info);
          var ob = btn('link', 'فتح هذا اليوم', function () { changeDate(d.date); });
          ob.setAttribute('aria-label', 'فتح حضور يوم ' + model.formatDate(d.date));
          li.appendChild(ob); list.appendChild(li);
        });
      }
      f.addEventListener('change', draw); t.addEventListener('change', draw); s.addEventListener('change', draw);
      histBox.appendChild(fr); histBox.appendChild(note); histBox.appendChild(list);
      draw();
    }
    var histState = { from: '', to: '', status: 'all' };

    function drawAll(keepFocus) {
      compute(); banner(); drawCounts(); drawRows(); drawLegacy(); drawControls(); drawHistory();
      dateIn.value = date; dateIn.max = today(); shownToday = today();
    }
    function applyDate(d) {
      date = d; dateErr.textContent = ''; dateIn.removeAttribute('aria-invalid'); msgP.textContent = '';
      compute(); resetDraft(); drawAll();
    }
    function changeDate(d) {
      var err = model.validateDate(d, today());
      if (err) { dateErr.textContent = err; dateIn.setAttribute('aria-invalid', 'true'); dateIn.value = date; return; }
      if (d === date) return;
      if (isDirty()) { dateIn.value = date; askConfirm('تجاهل التغييرات غير المحفوظة؟', 'في هذا اليوم تغييرات حضور لم تُحفظ بعد. إن انتقلت إلى يوم آخر فستُفقد.', 'تجاهل والمتابعة', function () { applyDate(d); }); return; }
      applyDate(d);
    }

    function msg(t) { msgP.textContent = t; }
    function save() {
      var r, plan, out, activeIds, n;
      if (busy || blockedMsg || !sameClass()) return;
      msg('');
      if (model.validateDate(date, today())) { msg(model.validateDate(date, today())); return; }
      r = store.readCollection(ATT_TYPE, cid);
      if (!r.ok) { msg('لم يُحفظ شيء: ' + (r.error || 'تعذّرت قراءة السجلات.') + ' اختياراتك ما زالت في الصفحة.'); return; }
      activeIds = activeList().map(function (s) { return s.studentId; });
      plan = model.planSave(draft, r.records, { date: date, today: today(), activeIds: activeIds });
      if (!plan.ok) { msg('لم يُحفظ شيء: ' + plan.errors.map(function (e) { return (nameOf(e.studentId) || e.studentId) + ' — ' + e.message; }).join(' | ')); return; }
      if (!plan.records.length) { say('لا توجد تغييرات لحفظها.'); return; }
      busy = true; saveBtn.disabled = true;
      try { out = store.upsertMany(ATT_TYPE, cid, plan.records); }
      catch (err) { out = { ok: false, error: 'خطأ غير متوقع أثناء الحفظ.' }; }
      finally { busy = false; }
      if (!out.ok) {
        msg('لم يُحفظ الحضور: ' + (out.error || 'تعذّر الحفظ.') + (out.status === 'duplicate' ? ' ربما سُجّل أحد الطلاب من تبويب آخر؛ حُدِّثت القائمة، راجع اختياراتك ثم احفظ مرة أخرى.' : '') + ' اختياراتك ما زالت في الصفحة، أعد المحاولة.');
        if (out.status === 'duplicate') { load(); drawAll(); } else drawControls();
        return;
      }
      n = plan.records.length; persistent = out.persistent !== false; records = out.records;
      compute(); resetDraft(); drawAll();
      if (persistent) say('تم حفظ الحضور: ' + plan.created + ' جديد و' + plan.updated + ' معدَّل.', 3600);
      else say('حُفظ الحضور في ذاكرة هذه الصفحة فقط وليس بشكل دائم. سيزول بإغلاقها أو إعادة تحميلها.', 8000);
    }
    function askDelete(rec, name) {
      askConfirm('حذف سجل الحضور', 'سيُحذف نهائياً سجل حضور الطالب «' + name + '» بتاريخ ' + model.formatDate(rec.date) + ' (الحالة: ' + model.label(rec.status) + '). لا يمكن التراجع عن الحذف. هل تريد المتابعة؟', 'حذف السجل', function () {
        var out;
        if (!sameClass()) return;
        out = store.deleteRecord(ATT_TYPE, cid, rec.recordId);
        if (!out.ok) { say('لم يُحذف السجل: ' + (out.error || 'تعذّر الحذف.'), 6000); if (out.status === 'not-found') { load(); drawAll(); } return; }
        persistent = out.persistent !== false; records = out.records;
        delete draft[rec.studentId]; compute(); drawAll();
        say(persistent ? 'تم حذف سجل الحضور.' : 'حُذف السجل من ذاكرة هذه الصفحة فقط وليس بشكل دائم.', persistent ? 3200 : 8000);
      });
    }
    function bulkPresent() {
      var n = 0, before = JSON.parse(JSON.stringify(draft));
      day.rows.forEach(function (r) { var d = draft[r.studentId]; if (!r.record && !(d && model.isStatus(d.status))) { draft[r.studentId] = { status: 'present', note: '' }; n++; } });
      if (!n) { say('لا يوجد طلاب بلا حالة ليُحدَّدوا.'); return; }
      snapshot = before; msg(''); drawRows(); drawControls();
      say('حُدِّد ' + n + ' طالب حاضراً (غير محفوظ بعد). راجعهم ثم احفظ، أو اضغط «تراجع عن التحديد الجماعي».', 5000);
    }
    function revert() { resetDraft(); msg(''); drawRows(); drawControls(); say('أُلغيت التغييرات غير المحفوظة.'); }

    // ----- بناء الواجهة -----
    var h = mk('h2', null, 'حضور اليوم'); sheet.appendChild(h);
    var dg = mk('div', 'fg'), dl = mk('label', 'fl', 'تاريخ الحضور'), drow = mk('div', 'att-date');
    dateIn.type = 'date'; dateIn.id = 'att-date'; dl.htmlFor = 'att-date'; dateIn.min = model.MIN_YEAR + '-01-01'; dateIn.max = today();
    dateErr.id = 'att-date-e'; dateErr.setAttribute('aria-live', 'polite'); dateIn.setAttribute('aria-describedby', dateErr.id);
    dateIn.addEventListener('change', function () { changeDate(dateIn.value); });
    var prevBtn = btn('link', 'اليوم السابق', function () { changeDate(model.addDays(date, -1)); });
    nextBtn = btn('link', 'اليوم التالي', function () { changeDate(model.addDays(date, 1)); });
    var todayBtn = btn('link', 'اليوم', function () { changeDate(today()); });
    drow.appendChild(dateIn); drow.appendChild(prevBtn); drow.appendChild(nextBtn); drow.appendChild(todayBtn);
    dg.appendChild(dl); dg.appendChild(drow); dg.appendChild(dateErr); sheet.appendChild(dg);
    sheet.appendChild(counts);
    search.type = 'search'; search.placeholder = 'ابحث بالاسم أو الكود'; search.autocomplete = 'off'; search.setAttribute('aria-label', 'ابحث عن طالب بالاسم أو الكود');
    search.addEventListener('input', drawRows);
    [['all', 'كل الحالات'], ['unrecorded', 'غير مسجّل']].concat(model.STATUSES.map(function (k) { return [k, model.LABELS[k]]; })).forEach(function (o) { var op = mk('option', null, o[1]); op.value = o[0]; stSel.appendChild(op); });
    stSel.setAttribute('aria-label', 'فلتر حالة الحضور (للمحفوظ)'); stSel.addEventListener('change', drawRows);
    var fl = mk('div', 'att-filters'); fl.appendChild(search); fl.appendChild(stSel); sheet.appendChild(fl); sheet.appendChild(rc);
    var bar = mk('div', 'toolbar');
    saveBtn = btn('primary', 'حفظ الحضور', save);
    bulkBtn = btn('link', 'تحديد غير المسجّلين حاضرين', bulkPresent);
    undoBulkBtn = btn('link', 'تراجع عن التحديد الجماعي', function () { if (snapshot) { draft = snapshot; snapshot = null; msg(''); drawRows(); drawControls(); say('تم التراجع عن التحديد الجماعي.'); } });
    revertBtn = btn('link', 'إلغاء التغييرات غير المحفوظة', revert);
    undoBulkBtn.hidden = true;
    bar.appendChild(saveBtn); bar.appendChild(bulkBtn); bar.appendChild(undoBulkBtn); bar.appendChild(revertBtn);
    sheet.appendChild(bar);
    dirtyP.setAttribute('aria-live', 'polite'); msgP.setAttribute('role', 'alert'); sheet.appendChild(dirtyP); sheet.appendChild(msgP);
    sheet.appendChild(emptyBox); sheet.appendChild(ul); sheet.appendChild(legacyBox);
    host.appendChild(sheet); host.appendChild(histBox);

    load(); date = today(); compute(); resetDraft(); drawAll();
    attCtl = {
      cid: cid, dirty: function () { return isDirty(); },
      reload: function () { if (activeId() !== cid) return; load(); drawAll(); },
      dayCheck: function () { if (activeId() === cid && shownToday && today() !== shownToday) { shownToday = today(); dateIn.max = shownToday; drawControls(); } }
    };
  }
  function renderStudentAbsence() {
    // وضع الطالب العام: لا قراءة لنوع attendance هنا إطلاقاً (لا توجد مصادقة أو هوية طالب موثوقة في هذه النسخة)
    var s = mk('section', 'part'), e = mk('p', 'empty');
    s.appendChild(mk('h2', null, 'سجل الغياب'));
    e.appendChild(mk('strong', null, 'عرض الغياب الفردي غير متاح بعد'));
    e.appendChild(document.createTextNode('عرض سجل غياب كل طالب يحتاج مصادقة وهوية طالب موثوقة غير متوفرتين في هذه النسخة، وتأتي في مرحلة لاحقة. لذلك لا تُعرض هنا سجلات حضور أي طالب، ولا يُعدّ كود الطالب كلمة مرور.'));
    s.appendChild(e); host.appendChild(s);
  }

  // ===== 4.04: الدرجات والتقييمات — وضع ممثل الصف =====
  // منفصلة عن «الامتحانات» (مواعيد ومواضيع، النوع exams): هنا درجة فعلية حصل عليها طالب، النوع grades.
  // التخزين عبر MarsaAcademicStore وclassId الصف النشط وقت فتح الصفحة؛ المنطق كله في MarsaGradesModel. كل سجل مرتبط بـ studentId الثابت.
  // الطالب المؤرشف أو غير الموجود: سجلاته تُقرأ وتُحذف فقط (لا إدخال جديد ولا تعديل). النسبة والمتوسط يُحسبان عند العرض ولا يُخزَّنان.
  // الخصوصية: لا يُقرأ هذا النوع من أي واجهة طالب. هذا حاجز واجهة فقط وليس حماية (localStorage مقروء من أدوات المتصفح).
  var GR_TYPE = 'grades', grCtl = null, grUi = { sort: 'date', dir: 'desc' }, GR_LIST_MAX = 100;
  function renderGrades() {
    var store = window.MarsaAcademicStore, model = window.MarsaGradesModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, editing = null, dirty = false, busy = false, shownToday = '';
    var fl = { query: '', studentId: 'all', subject: 'all', from: '', to: '' };
    grCtl = null;
    if (!activeClass()) { noClassBlock(); return; }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل طبقة التخزين الأكاديمي أو منطق الدرجات (js/academic-store.js و js/grades-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return; }
    classBar();
    host.appendChild(mk('div', 'notice', 'الدرجات محفوظة في متصفح هذا الجهاز فقط، ولا تظهر في وضع الطالب ولا على أجهزة أخرى. هذا حاجز واجهة وليس حماية: أي شخص يستعمل هذا المتصفح يستطيع قراءة البيانات من أدوات المتصفح. وهذه الصفحة غير صفحة «الامتحانات»: هناك مواعيد الامتحانات ومواضيعها، وهنا الدرجات الفعلية.'));
    var bannerBox = mk('div'), formSec = mk('section', 'part gr-form'), sumBox = mk('section', 'part gr-sum'), listSec = mk('section', 'part gr-listsec');
    var formTitle = mk('h2', null, 'تسجيل درجة'), F = {}, msgP = mk('p', 'err'), dupBox = mk('div'), noStudents = mk('div');
    var stSel = mk('select', 'field'), subjIn = mk('input', 'field'), titleIn = mk('input', 'field'), dateIn = mk('input', 'field'), scoreIn = mk('input', 'field'), maxIn = mk('input', 'field'), noteIn = mk('input', 'field'), subjList = mk('datalist');
    var saveBtn, cancelBtn, qIn = mk('input', 'field'), fSt = mk('select', 'field'), fSub = mk('select', 'field'), fFrom = mk('input', 'field'), fTo = mk('input', 'field'), sSel = mk('select', 'field'), dSel = mk('select', 'field');
    var rc = mk('p', 'resc'), ul = mk('ul', 'gr-list'), emptyBox = mk('div');
    host.appendChild(bannerBox);

    function today() { return store.toLocalDate(); }
    function sameClass() { if (activeId() !== cid) { say('تغيّر الصف النشط. أعد فتح «الدرجات».'); return false; } return true; }
    function nameOf(id) { var s = findStudent(id); return s ? s.name : ''; }
    function load() {
      var r = store.readCollection(GR_TYPE, cid);
      persistent = r.persistent !== false;
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت قراءة سجلات الدرجات.'; return false; }
      blockedMsg = ''; records = r.records; return true;
    }
    function banner() {
      bannerBox.textContent = '';
      if (blockedMsg) bannerBox.appendChild(mk('div', 'notice warnbox', blockedMsg));
      else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك الدرجات مؤقتة في ذاكرة هذه الصفحة وتزول بإغلاقها أو إعادة تحميلها.'));
      var c = model.findConflicts(records);
      if (c.length) bannerBox.appendChild(mk('div', 'notice warnbox', 'وُجد تكرار في سجلات الدرجات (' + c.length + ' حالة). لم يُحذف شيء تلقائياً؛ راجع النسخة الاحتياطية قبل أي تعديل.'));
    }

    // ----- النموذج -----
    function fld(key, text, el, hint) {
      var g = mk('div', 'fg'), l = mk('label', 'fl', text), err = mk('p', 'err'), desc = [];
      el.id = 'gr-' + key; l.htmlFor = el.id; err.id = 'gr-' + key + '-e'; desc.push(err.id);
      if (hint) { var h = mk('p', 'hint muted', hint); h.id = 'gr-' + key + '-h'; desc.unshift(h.id); }
      el.setAttribute('aria-describedby', desc.join(' '));
      g.appendChild(l); g.appendChild(el); if (hint) g.appendChild(h); g.appendChild(err);
      F[key] = { el: el, err: err };
      return g;
    }
    function clearErrors() { Object.keys(F).forEach(function (k) { F[k].err.textContent = ''; F[k].el.removeAttribute('aria-invalid'); }); msgP.textContent = ''; dupBox.textContent = ''; }
    function showErrors(errs) {
      var first = null;
      clearErrors();
      ['studentId', 'subject', 'title', 'date', 'score', 'maxScore', 'note'].forEach(function (k) {
        if (errs[k]) { F[k].err.textContent = errs[k]; F[k].el.setAttribute('aria-invalid', 'true'); if (!first) first = F[k].el; }
      });
      if (errs._) msgP.textContent = errs._;
      if (first) first.focus();
    }
    function drawStudentOptions() {
      var cur = stSel.value, act = activeList();
      stSel.textContent = '';
      var ph = mk('option', null, 'اختر الطالب'); ph.value = ''; stSel.appendChild(ph);
      act.forEach(function (s) { var o = mk('option', null, s.name); o.value = s.studentId; stSel.appendChild(o); });
      stSel.value = act.some(function (s) { return s.studentId === cur; }) ? cur : '';
    }
    function drawSubjectList() {
      subjList.textContent = '';
      model.distinctSubjects(records).forEach(function (s) { var o = mk('option'); o.value = s; subjList.appendChild(o); });
    }
    function setFormEnabled() {
      var off = !!blockedMsg || !activeList().length;
      [stSel, subjIn, titleIn, dateIn, scoreIn, maxIn, noteIn].forEach(function (e) { e.disabled = off; });
      stSel.disabled = off || !!editing;
      saveBtn.disabled = off || busy;
      noStudents.textContent = '';
      if (!blockedMsg && !activeList().length) {
        var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا يوجد طلاب فعّالون في هذا الصف'));
        e.appendChild(document.createTextNode('أضف الطلاب من قسم «الطلاب» ثم عُد لتسجيل الدرجات. الطلاب المؤرشفون لا تُسجَّل لهم درجات جديدة.'));
        noStudents.appendChild(e); noStudents.appendChild(btn('primary', 'فتح قسم الطلاب', function () { go('students'); }));
      }
    }
    function drawFormMode() {
      formTitle.textContent = editing ? 'تعديل درجة' : 'تسجيل درجة';
      saveBtn.textContent = editing ? 'حفظ التعديل' : 'حفظ الدرجة';
      cancelBtn.hidden = !editing;
      setFormEnabled();
    }
    function resetForm(keep) {
      editing = null; dirty = false; clearErrors();
      // الطالب والدرجة والملاحظة تُمسح دائماً (اختيار الطالب التالي صريح)؛ المادة والعنوان والتاريخ والقصوى تبقى لتسريع إدخال صف كامل لنفس التقييم
      if (!keep) { subjIn.value = ''; titleIn.value = ''; maxIn.value = ''; dateIn.value = today(); }
      stSel.value = ''; scoreIn.value = ''; noteIn.value = '';
      dateIn.max = today(); shownToday = today();
      drawFormMode();
    }
    function startEdit(rec, force) {
      if (model.studentKind(rec.studentId, roster.students) !== 'active') { say('سجل طالب غير فعّال للقراءة والحذف فقط.'); return; }
      function go2() {
        editing = rec; clearErrors(); drawStudentOptions();
        stSel.value = rec.studentId; subjIn.value = rec.subject; titleIn.value = rec.title; dateIn.value = rec.date;
        scoreIn.value = String(rec.score); maxIn.value = String(rec.maxScore); noteIn.value = rec.note || '';
        dirty = false; drawFormMode();
        if (formSec.scrollIntoView) formSec.scrollIntoView({ block: 'start' });
        scoreIn.focus();
      }
      if (dirty && !force) { askConfirm('تجاهل التغييرات غير المحفوظة؟', 'في النموذج بيانات لم تُحفظ بعد. إن بدأت تعديل سجل آخر فستُفقد.', 'تجاهل والمتابعة', go2); return; }
      go2();
      if (force) say('فُتح السجل الموجود للتعديل. عدّل الدرجة ثم احفظ.');
    }
    function save() {
      var r, plan, out, wasEdit;
      if (busy || blockedMsg || !sameClass()) return;
      clearErrors();
      r = store.readCollection(GR_TYPE, cid);
      if (!r.ok) { msgP.textContent = 'لم تُحفظ الدرجة: ' + (r.error || 'تعذّرت قراءة السجلات.') + ' بياناتك ما زالت في النموذج.'; return; }
      plan = model.planSave({ studentId: stSel.value, subject: subjIn.value, title: titleIn.value, date: dateIn.value, score: scoreIn.value, maxScore: maxIn.value, note: noteIn.value },
        r.records, { today: today(), activeIds: activeList().map(function (s) { return s.studentId; }) }, editing);
      if (!plan.ok) {
        showErrors(plan.errors);
        if (plan.status === 'duplicate' && plan.duplicate && model.studentKind(plan.duplicate.studentId, roster.students) === 'active') {
          dupBox.appendChild(btn('link', 'فتح السجل الموجود للتعديل', function () { records = r.records; startEdit(plan.duplicate, true); }));
        }
        if (plan.status === 'not-found') { editing = null; records = r.records; drawAll(); drawFormMode(); }
        return;
      }
      if (plan.mode === 'unchanged') { say('لا توجد تغييرات لحفظها.'); return; }
      wasEdit = !!editing; busy = true; saveBtn.disabled = true;
      try { out = store.upsertRecord(GR_TYPE, cid, plan.record); }
      catch (err) { out = { ok: false, error: 'خطأ غير متوقع أثناء الحفظ.' }; }
      finally { busy = false; }
      if (!out.ok) {
        msgP.textContent = 'لم تُحفظ الدرجة: ' + (out.error || 'تعذّر الحفظ.') + ' بياناتك ما زالت في النموذج، أعد المحاولة.';
        if (out.status === 'duplicate') { load(); drawAll(); }
        setFormEnabled();
        return;
      }
      persistent = out.persistent !== false; records = out.records;
      resetForm(!wasEdit); drawAll();
      if (!wasEdit) stSel.focus(); else if (formSec.scrollIntoView) { /* يبقى المستخدم قرب القائمة */ }
      if (persistent) say(wasEdit ? 'تم حفظ تعديل الدرجة.' : 'تم حفظ الدرجة.', 3200);
      else say('حُفظت الدرجة في ذاكرة هذه الصفحة فقط وليس بشكل دائم. ستزول بإغلاقها أو إعادة تحميلها.', 8000);
    }
    function askDelete(rec) {
      var nm = nameOf(rec.studentId) || 'طالب غير موجود في قائمة هذا الصف';
      askConfirm('حذف الدرجة', 'سيُحذف نهائياً سجل درجة الطالب «' + nm + '» في «' + rec.subject + ' — ' + rec.title + '» بتاريخ ' + model.formatDate(rec.date) + ' (' + model.fmtNum(rec.score) + ' من ' + model.fmtNum(rec.maxScore) + '). لا يمكن التراجع عن الحذف. هل تريد المتابعة؟', 'حذف السجل', function () {
        var out;
        if (!sameClass()) return;
        out = store.deleteRecord(GR_TYPE, cid, rec.recordId);
        if (!out.ok) { say('لم يُحذف السجل: ' + (out.error || 'تعذّر الحذف.'), 6000); if (out.status === 'not-found') { load(); drawAll(); } return; }
        persistent = out.persistent !== false; records = out.records;
        if (editing && editing.recordId === rec.recordId) resetForm(false);
        drawAll();
        say(persistent ? 'تم حذف سجل الدرجة.' : 'حُذف السجل من ذاكرة هذه الصفحة فقط وليس بشكل دائم.', persistent ? 3200 : 8000);
      });
    }

    // ----- القائمة والملخص -----
    function filtered() {
      var list = model.filterRecords(records, { query: fl.query, nameOf: nameOf, studentId: fl.studentId, subject: fl.subject === 'all' ? '' : fl.subject, from: fl.from, to: fl.to });
      return model.sortRecords(list, grUi.sort, grUi.dir, nameOf);
    }
    function drawFilters() {
      var cur = fSt.value || fl.studentId, curSub = fSub.value || fl.subject;
      fSt.textContent = ''; fSub.textContent = '';
      var a = mk('option', null, 'كل الطلاب'); a.value = 'all'; fSt.appendChild(a);
      activeList().forEach(function (s) { var o = mk('option', null, s.name); o.value = s.studentId; fSt.appendChild(o); });
      roster.students.filter(function (s) { return s.status === 'archived'; }).forEach(function (s) { var o = mk('option', null, s.name + ' (مؤرشف)'); o.value = s.studentId; fSt.appendChild(o); });
      fSt.value = Array.prototype.some.call(fSt.options, function (o) { return o.value === cur; }) ? cur : 'all'; fl.studentId = fSt.value;
      var b = mk('option', null, 'كل المواد'); b.value = 'all'; fSub.appendChild(b);
      model.distinctSubjects(records).forEach(function (s) { var o = mk('option', null, s); o.value = s; fSub.appendChild(o); });
      fSub.value = Array.prototype.some.call(fSub.options, function (o) { return o.value === curSub; }) ? curSub : 'all'; fl.subject = fSub.value;
    }
    function drawSummary(list) {
      var a, subs, box, ulS;
      sumBox.textContent = '';
      if (blockedMsg) return;
      sumBox.appendChild(mk('h2', null, fl.studentId !== 'all' ? 'متوسط ' + (nameOf(fl.studentId) || 'الطالب') : 'متوسط السجلات المعروضة'));
      if (!list.length) { sumBox.appendChild(mk('p', 'muted', records.length ? 'لا توجد سجلات مطابقة لحساب متوسطها.' : 'لا توجد درجات مسجلة بعد، لذلك لا يوجد متوسط.')); return; }
      a = model.pooledAverage(list);
      if (a.percent == null) { sumBox.appendChild(mk('p', 'muted', 'تعذّر حساب المتوسط: لا توجد سجلات ذات درجة صالحة.')); return; }
      box = mk('p', 'gr-avg'); box.appendChild(mk('b', 'gr-avg-n', model.fmtPercent(a.percent)));
      box.appendChild(mk('span', 'muted', ' على ' + a.count + ' تقييم'));
      sumBox.appendChild(box);
      sumBox.appendChild(mk('p', 'muted gr-basis', 'أساس الحساب: ' + model.AVG_BASIS + ' = ' + model.fmtNum(a.sumScore) + ' ÷ ' + model.fmtNum(a.sumMax) + '. لا يُحسب المتوسط من متوسط النسب.'));
      if (a.invalid) sumBox.appendChild(mk('p', 'notice warnbox', 'استُثني ' + a.invalid + ' سجل ببيانات درجة غير صالحة من الحساب (لم يُعامَل كصفر).'));
      subs = model.summarizeBySubject(list);
      if (subs.length > 1 || (subs.length === 1 && fl.subject === 'all')) {
        sumBox.appendChild(mk('h3', null, 'حسب المادة'));
        ulS = mk('ul', 'gr-subs');
        subs.forEach(function (s) {
          var li = mk('li'); li.appendChild(mk('b', null, s.subject));
          li.appendChild(mk('span', 'muted', s.percent == null ? '—' : model.fmtPercent(s.percent) + ' (' + s.count + ' تقييم)'));
          ulS.appendChild(li);
        });
        sumBox.appendChild(ulS);
      }
    }
    function card(r) {
      var li = mk('li', 'arow grow'), top = mk('div', 'ar-top'), kind = model.studentKind(r.studentId, roster.students), nm = nameOf(r.studentId) || 'طالب غير موجود في قائمة هذا الصف', p = model.percent(r), sc = mk('p', 'gr-score');
      li.setAttribute('data-record-id', r.recordId); li.setAttribute('data-student-id', r.studentId);
      top.appendChild(mk('b', 'ar-n', nm));
      if (kind !== 'active') top.appendChild(mk('span', 'tag', kind === 'archived' ? 'مؤرشف' : 'غير معروف'));
      li.appendChild(top);
      li.appendChild(mk('h3', 'gr-t', r.subject + ' — ' + r.title));
      li.appendChild(mk('p', 'muted gr-d', model.formatDate(r.date)));
      sc.appendChild(mk('b', null, model.fmtNum(r.score) + ' / ' + model.fmtNum(r.maxScore)));
      sc.appendChild(mk('span', 'tag' + (p == null ? ' warn' : ' on'), p == null ? 'درجة غير صالحة' : model.fmtPercent(p)));
      li.appendChild(sc);
      if (r.note) li.appendChild(mk('p', 'lc-t', r.note));
      var acts = mk('div', 'acts'), lab = nm + ' — ' + r.subject + ' — ' + r.title;
      if (kind === 'active') { var eb = btn('link', 'تعديل', function () { startEdit(r); }); eb.setAttribute('aria-label', 'تعديل درجة ' + lab); acts.appendChild(eb); }
      var db = btn('link danger', 'حذف', function () { askDelete(r); }); db.setAttribute('aria-label', 'حذف درجة ' + lab); acts.appendChild(db);
      li.appendChild(acts);
      if (kind !== 'active') li.appendChild(mk('p', 'muted', 'سجل تاريخي للقراءة والحذف فقط؛ لا يُعدَّل ولا تُسجَّل درجات جديدة لهذا الطالب.'));
      return li;
    }
    function drawList() {
      var list, shown;
      ul.textContent = ''; emptyBox.textContent = '';
      if (blockedMsg) { rc.textContent = ''; drawSummary([]); return; }
      list = filtered(); drawSummary(list);
      rc.textContent = records.length ? 'النتائج: ' + list.length + ' من ' + records.length + (list.length > GR_LIST_MAX ? ' (يُعرض أول ' + GR_LIST_MAX + '؛ ضيّق البحث لرؤية الباقي)' : '') : '';
      if (!records.length) { var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا توجد درجات مسجلة بعد')); e.appendChild(document.createTextNode('سجّل أول درجة من النموذج أعلاه. لا تُنشأ أي درجات تلقائياً، والطالب بلا درجة يبقى «لم تُسجَّل» وليس صفراً.')); emptyBox.appendChild(e); return; }
      if (!list.length) { emptyBox.appendChild(mk('p', 'muted', 'لا توجد درجات مطابقة للبحث أو الفلاتر.')); return; }
      shown = list.slice(0, GR_LIST_MAX);
      shown.forEach(function (r) { ul.appendChild(card(r)); });
    }
    function drawAll() { banner(); drawStudentOptions(); drawSubjectList(); drawFilters(); drawFormMode(); drawList(); }

    // ----- بناء الواجهة -----
    stSel.setAttribute('autocomplete', 'off');
    subjIn.type = 'text'; subjIn.maxLength = model.SUBJECT_MAX; subjIn.autocomplete = 'off'; subjList.id = 'gr-subject-list'; subjIn.setAttribute('list', subjList.id);
    titleIn.type = 'text'; titleIn.maxLength = model.TITLE_MAX; titleIn.autocomplete = 'off';
    dateIn.type = 'date'; dateIn.min = model.MIN_YEAR + '-01-01'; dateIn.max = today(); dateIn.value = today();
    [scoreIn, maxIn].forEach(function (e) { e.type = 'text'; e.inputMode = 'decimal'; e.autocomplete = 'off'; e.setAttribute('dir', 'ltr'); e.maxLength = 12; });
    noteIn.type = 'text'; noteIn.maxLength = model.NOTE_MAX; noteIn.autocomplete = 'off';
    formSec.appendChild(formTitle);
    formSec.appendChild(mk('p', 'muted', 'لكل طالب ولكل تقييم سجل مستقل. الدرجة القصوى تكتبها أنت (10 أو 20 أو 100…) ولا تُفترض.'));
    formSec.appendChild(noStudents);
    formSec.appendChild(fld('studentId', 'الطالب', stSel));
    formSec.appendChild(fld('subject', 'المادة', subjIn, 'نص حرّ؛ تظهر المواد المستعملة سابقاً كاقتراحات.')); formSec.appendChild(subjList);
    formSec.appendChild(fld('title', 'عنوان التقييم أو الامتحان', titleIn, 'مثل: اختبار الفصل الأول، أو واجب الأسبوع الثالث.'));
    formSec.appendChild(fld('date', 'تاريخ التقييم', dateIn));
    var pair = mk('div', 'gr-pair'); pair.appendChild(fld('score', 'الدرجة', scoreIn)); pair.appendChild(fld('maxScore', 'الدرجة القصوى', maxIn)); formSec.appendChild(pair);
    formSec.appendChild(fld('note', 'ملاحظة (اختيارية)', noteIn));
    msgP.setAttribute('role', 'alert'); msgP.id = 'gr-msg'; formSec.appendChild(msgP); formSec.appendChild(dupBox);
    var bar = mk('div', 'toolbar');
    saveBtn = btn('primary', 'حفظ الدرجة', save); cancelBtn = btn('link', 'إلغاء التعديل', function () {
      if (dirty) askConfirm('تجاهل التعديل؟', 'ستُفقد التغييرات غير المحفوظة في النموذج.', 'تجاهل والمتابعة', function () { resetForm(true); }); else resetForm(true);
    });
    cancelBtn.hidden = true; bar.appendChild(saveBtn); bar.appendChild(cancelBtn); formSec.appendChild(bar);
    [stSel, subjIn, titleIn, dateIn, scoreIn, maxIn, noteIn].forEach(function (e) { e.addEventListener('input', function () { dirty = true; }); e.addEventListener('change', function () { dirty = true; }); });
    [stSel, subjIn, titleIn, dateIn, scoreIn, maxIn, noteIn].forEach(function (e) { e.addEventListener('input', function () { e.removeAttribute('aria-invalid'); var k = e.id.replace('gr-', ''); if (F[k]) F[k].err.textContent = ''; }); });
    formSec.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' && ev.target && ev.target.tagName === 'INPUT') { ev.preventDefault(); save(); } });

    listSec.appendChild(mk('h2', null, 'سجل الدرجات'));
    qIn.type = 'search'; qIn.autocomplete = 'off'; qIn.placeholder = 'ابحث بالطالب أو المادة أو العنوان أو التاريخ'; qIn.setAttribute('aria-label', 'ابحث في الدرجات بالطالب أو المادة أو العنوان أو التاريخ');
    qIn.addEventListener('input', function () { fl.query = qIn.value; drawList(); });
    fSt.setAttribute('aria-label', 'فلتر الطالب'); fSt.addEventListener('change', function () { fl.studentId = fSt.value; drawList(); });
    fSub.setAttribute('aria-label', 'فلتر المادة'); fSub.addEventListener('change', function () { fl.subject = fSub.value; drawList(); });
    fFrom.type = 'date'; fTo.type = 'date'; fFrom.setAttribute('aria-label', 'من تاريخ'); fTo.setAttribute('aria-label', 'إلى تاريخ');
    fFrom.addEventListener('change', function () { fl.from = fFrom.value; drawList(); }); fTo.addEventListener('change', function () { fl.to = fTo.value; drawList(); });
    model.SORTS.forEach(function (k) { var o = mk('option', null, 'الفرز حسب: ' + model.SORT_LABELS[k]); o.value = k; o.selected = grUi.sort === k; sSel.appendChild(o); });
    [['desc', 'تنازلي (الأحدث/الأعلى أولاً)'], ['asc', 'تصاعدي']].forEach(function (d) { var o = mk('option', null, d[1]); o.value = d[0]; o.selected = grUi.dir === d[0]; dSel.appendChild(o); });
    sSel.setAttribute('aria-label', 'معيار الفرز'); dSel.setAttribute('aria-label', 'اتجاه الفرز');
    sSel.addEventListener('change', function () { grUi.sort = sSel.value; drawList(); }); dSel.addEventListener('change', function () { grUi.dir = dSel.value; drawList(); });
    var fg = mk('div', 'att-filters'); [qIn, fSt, fSub].forEach(function (e) { fg.appendChild(e); }); listSec.appendChild(fg);
    var dg = mk('div', 'att-filters');
    [['من تاريخ', fFrom, 'gr-from'], ['إلى تاريخ', fTo, 'gr-to']].forEach(function (x) { var g = mk('div', 'fg'), l = mk('label', 'fl', x[0]); x[1].id = x[2]; l.htmlFor = x[2]; g.appendChild(l); g.appendChild(x[1]); dg.appendChild(g); });
    dg.appendChild(sSel); dg.appendChild(dSel); listSec.appendChild(dg);
    rc.setAttribute('aria-live', 'polite'); listSec.appendChild(rc); listSec.appendChild(emptyBox); listSec.appendChild(ul);
    host.appendChild(formSec); host.appendChild(sumBox); host.appendChild(listSec);

    load(); shownToday = today(); drawAll();
    grCtl = {
      cid: cid, dirty: function () { return !blockedMsg && dirty; },
      reload: function () { if (activeId() !== cid) return; load(); drawAll(); },
      dayCheck: function () { if (activeId() === cid && shownToday && today() !== shownToday) { shownToday = today(); dateIn.max = shownToday; } }
    };
  }
  // ===== 4.05: المدفوعات وسجل المقبوضات (وضع ممثل الصف فقط) =====
  // مبلغ استُلم فعلاً، بالدينار العراقي (عدد صحيح). لا رسوم ولا ديون ولا «متبقٍ». الإجماليات مشتقة عند العرض من السجلات المخزنة.
  // لا يوجد route للطالب لهذا النوع، ولا يُقرأ payments من أي واجهة طالب (قاعدة الخصوصية 10).
  var PAY_TYPE = 'payments', payCtl = null, payUi = { sort: 'date', dir: 'desc' }, PAY_LIST_MAX = 100;
  function renderPayments() {
    var store = window.MarsaAcademicStore, model = window.MarsaPaymentsModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, editing = null, dirty = false, busy = false, shownToday = '';
    var fl = { query: '', studentId: 'all', from: '', to: '' };
    payCtl = null;
    if (!activeClass()) { noClassBlock(); return; }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل طبقة التخزين الأكاديمي أو منطق المدفوعات (js/academic-store.js و js/payments-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return; }
    classBar();
    host.appendChild(mk('div', 'notice', 'هذا السجل للمبالغ التي استُلمت فعلاً فقط، بالدينار العراقي. لا يُنشئ التطبيق مستحقات أو ديوناً أو غرامات ولا يفترض رسماً على أي طالب، ولا يتصل ببنك أو بوابة دفع. السجلات محفوظة في متصفح هذا الجهاز فقط، ولا تظهر في وضع الطالب ولا على أجهزة أخرى. هذا حاجز واجهة وليس حماية: أي شخص يستعمل هذا المتصفح يستطيع قراءة البيانات من أدوات المتصفح.'));
    var bannerBox = mk('div'), formSec = mk('section', 'part gr-form pay-form'), sumBox = mk('section', 'part gr-sum pay-sum'), listSec = mk('section', 'part gr-listsec pay-listsec');
    var formTitle = mk('h2', null, 'تسجيل دفعة مستلمة'), F = {}, msgP = mk('p', 'err'), noStudents = mk('div');
    var stSel = mk('select', 'field'), amtIn = mk('input', 'field'), purIn = mk('input', 'field'), dateIn = mk('input', 'field'), recIn = mk('input', 'field'), noteIn = mk('input', 'field'), purList = mk('datalist');
    var saveBtn, cancelBtn, qIn = mk('input', 'field'), fSt = mk('select', 'field'), fFrom = mk('input', 'field'), fTo = mk('input', 'field'), sSel = mk('select', 'field'), dSel = mk('select', 'field');
    var recHint = mk('p', 'hint muted'), periodErr = mk('p', 'err'), rc = mk('p', 'resc'), ul = mk('ul', 'gr-list pay-list'), emptyBox = mk('div');
    host.appendChild(bannerBox);

    function today() { return store.toLocalDate(); }
    function sameClass() { if (activeId() !== cid) { say('تغيّر الصف النشط. أعد فتح «المدفوعات».'); return false; } return true; }
    function nameOf(id) { var s = findStudent(id); return s ? s.name : ''; }
    function load() {
      var r = store.readCollection(PAY_TYPE, cid);
      persistent = r.persistent !== false;
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت قراءة سجلات المدفوعات.'; return false; }
      blockedMsg = ''; records = r.records; return true;
    }
    function banner() {
      bannerBox.textContent = '';
      if (blockedMsg) bannerBox.appendChild(mk('div', 'notice warnbox', blockedMsg));
      else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك المدفوعات مؤقتة في ذاكرة هذه الصفحة وتزول بإغلاقها أو إعادة تحميلها.'));
    }

    // ----- النموذج -----
    function fld(key, text, el, hint, extra) {
      var g = mk('div', 'fg'), l = mk('label', 'fl', text), err = mk('p', 'err'), desc = [];
      el.id = 'pay-' + key; l.htmlFor = el.id; err.id = 'pay-' + key + '-e'; desc.push(err.id);
      if (hint) { var h = mk('p', 'hint muted', hint); h.id = 'pay-' + key + '-h'; desc.unshift(h.id); }
      if (extra) { desc.unshift(extra.id); }
      el.setAttribute('aria-describedby', desc.join(' '));
      g.appendChild(l); g.appendChild(el); if (hint) g.appendChild(h); if (extra) g.appendChild(extra); g.appendChild(err);
      F[key] = { el: el, err: err };
      return g;
    }
    function clearErrors() { Object.keys(F).forEach(function (k) { F[k].err.textContent = ''; F[k].el.removeAttribute('aria-invalid'); }); msgP.textContent = ''; }
    function showErrors(errs) {
      var first = null;
      clearErrors();
      ['studentId', 'amount', 'purpose', 'date', 'receiptNo', 'note'].forEach(function (k) {
        if (errs[k]) { F[k].err.textContent = errs[k]; F[k].el.setAttribute('aria-invalid', 'true'); if (!first) first = F[k].el; }
      });
      if (errs._) msgP.textContent = errs._;
      if (first) first.focus();
    }
    function drawStudentOptions() {
      var cur = stSel.value, act = activeList();
      stSel.textContent = '';
      var ph = mk('option', null, 'اختر الطالب'); ph.value = ''; stSel.appendChild(ph);
      act.forEach(function (s) { var o = mk('option', null, s.name); o.value = s.studentId; stSel.appendChild(o); });
      // عند تعديل سجل طالب فعّال يبقى مختاراً
      stSel.value = act.some(function (s) { return s.studentId === cur; }) ? cur : '';
    }
    function drawPurposeList() {
      var seen = Object.create(null), out = [];
      purList.textContent = '';
      records.forEach(function (r) { var k = model.searchKey(r.purpose); if (k && !seen[k]) { seen[k] = 1; out.push(model.oneLine(r.purpose)); } });
      out.sort().forEach(function (s) { var o = mk('option'); o.value = s; purList.appendChild(o); });
    }
    function setFormEnabled() {
      var off = !!blockedMsg || !activeList().length;
      [stSel, amtIn, purIn, dateIn, recIn, noteIn].forEach(function (e) { e.disabled = off; });
      stSel.disabled = off || !!editing;
      saveBtn.disabled = off || busy;
      noStudents.textContent = '';
      if (!blockedMsg && !activeList().length) {
        var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا يوجد طلاب فعّالون في هذا الصف'));
        e.appendChild(document.createTextNode('أضف الطلاب من قسم «الطلاب» ثم عُد لتسجيل المدفوعات. الطلاب المؤرشفون لا تُسجَّل لهم دفعات جديدة، وتبقى دفعاتهم القديمة محفوظة.'));
        noStudents.appendChild(e); noStudents.appendChild(btn('primary', 'فتح قسم الطلاب', function () { go('students'); }));
      }
    }
    function drawFormMode() {
      formTitle.textContent = editing ? 'تعديل دفعة' : 'تسجيل دفعة مستلمة';
      saveBtn.textContent = editing ? 'حفظ التعديل' : 'حفظ الدفعة';
      cancelBtn.hidden = !editing;
      setFormEnabled();
    }
    function updateRecHint() {
      var m = model.findReceiptMatches(records, recIn.value, editing ? editing.recordId : null);
      recHint.textContent = m.length ? 'تنبيه: رقم الوصل هذا مستخدم في ' + m.length + ' دفعة أخرى في هذا الصف. هذا مسموح (قد يغطي وصل واحد عدة طلاب) لكن تأكد أنه ليس خطأ إدخال.' : '';
    }
    function resetForm(keep) {
      editing = null; dirty = false; clearErrors();
      // الطالب والمبلغ ورقم الوصل والملاحظة تُمسح دائماً؛ الغرض والتاريخ يبقيان لتسريع إدخال عدة دفعات للغرض نفسه
      if (!keep) { purIn.value = ''; dateIn.value = today(); }
      stSel.value = ''; amtIn.value = ''; recIn.value = ''; noteIn.value = '';
      dateIn.max = today(); shownToday = today();
      updateRecHint(); drawFormMode();
    }
    function startEdit(rec, force) {
      if (model.studentKind(rec.studentId, roster.students) !== 'active') { say('سجل طالب غير فعّال للقراءة والحذف فقط.'); return; }
      function go2() {
        editing = rec; clearErrors(); drawStudentOptions();
        stSel.value = rec.studentId; amtIn.value = String(rec.amount); purIn.value = rec.purpose; dateIn.value = rec.date;
        recIn.value = rec.receiptNo || ''; noteIn.value = rec.note || '';
        dirty = false; updateRecHint(); drawFormMode();
        if (formSec.scrollIntoView) formSec.scrollIntoView({ block: 'start' });
        amtIn.focus();
      }
      if (dirty && !force) { askConfirm('تجاهل التغييرات غير المحفوظة؟', 'في النموذج بيانات لم تُحفظ بعد. إن بدأت تعديل سجل آخر فستُفقد.', 'تجاهل والمتابعة', go2); return; }
      go2();
    }
    function save() {
      var r, plan, out, wasEdit, warn = '', m;
      if (busy || blockedMsg || !sameClass()) return;
      clearErrors();
      r = store.readCollection(PAY_TYPE, cid);
      if (!r.ok) { msgP.textContent = 'لم تُحفظ الدفعة: ' + (r.error || 'تعذّرت قراءة السجلات.') + ' بياناتك ما زالت في النموذج.'; return; }
      plan = model.planSave({ studentId: stSel.value, amount: amtIn.value, purpose: purIn.value, date: dateIn.value, receiptNo: recIn.value, note: noteIn.value },
        r.records, { today: today(), activeIds: activeList().map(function (s) { return s.studentId; }) }, editing);
      if (!plan.ok) {
        showErrors(plan.errors);
        if (plan.status === 'not-found') { editing = null; records = r.records; drawAll(); drawFormMode(); }
        return;
      }
      if (plan.mode === 'unchanged') { say('لا توجد تغييرات لحفظها.'); return; }
      wasEdit = !!editing; busy = true; saveBtn.disabled = true;
      try { out = store.upsertRecord(PAY_TYPE, cid, plan.record); }
      catch (err) { out = { ok: false, error: 'خطأ غير متوقع أثناء الحفظ.' }; }
      finally { busy = false; }
      if (!out.ok) {
        msgP.textContent = 'لم تُحفظ الدفعة: ' + (out.error || 'تعذّر الحفظ.') + ' بياناتك ما زالت في النموذج، أعد المحاولة.';
        setFormEnabled();
        return;
      }
      m = plan.warnings && plan.warnings.receiptMatches ? plan.warnings.receiptMatches.length : 0;
      if (m) warn = ' تنبيه: رقم الوصل مستخدم في ' + m + ' دفعة أخرى.';
      persistent = out.persistent !== false; records = out.records;
      resetForm(!wasEdit); drawAll();
      if (!wasEdit) stSel.focus();
      if (persistent) say((wasEdit ? 'تم حفظ تعديل الدفعة.' : 'تم حفظ الدفعة.') + warn, warn ? 7000 : 3200);
      else say('حُفظت الدفعة في ذاكرة هذه الصفحة فقط وليس بشكل دائم. ستزول بإغلاقها أو إعادة تحميلها.' + warn, 8000);
    }
    function askDelete(rec) {
      var nm = nameOf(rec.studentId) || 'طالب غير موجود في قائمة هذا الصف';
      askConfirm('حذف الدفعة', 'سيُحذف نهائياً سجل دفعة الطالب «' + nm + '» بمبلغ ' + model.formatAmount(rec.amount, true) + ' بتاريخ ' + model.formatDate(rec.date) + ' (الغرض: ' + rec.purpose + '). لا يمكن التراجع عن الحذف. هل تريد المتابعة؟', 'حذف السجل', function () {
        var out;
        if (!sameClass()) return;
        out = store.deleteRecord(PAY_TYPE, cid, rec.recordId);
        if (!out.ok) { say('لم يُحذف السجل: ' + (out.error || 'تعذّر الحذف.'), 6000); if (out.status === 'not-found') { load(); drawAll(); } return; }
        persistent = out.persistent !== false; records = out.records;
        if (editing && editing.recordId === rec.recordId) resetForm(false);
        drawAll();
        say(persistent ? 'تم حذف سجل الدفعة.' : 'حُذف السجل من ذاكرة هذه الصفحة فقط وليس بشكل دائم.', persistent ? 3200 : 8000);
      });
    }

    // ----- القائمة والإجماليات -----
    function periodBad() { return model.validatePeriod(fl.from, fl.to); }
    function filtered() {
      var list = model.filterRecords(records, { query: fl.query, nameOf: nameOf, studentId: fl.studentId, from: fl.from, to: fl.to });
      return model.sortRecords(list, payUi.sort, payUi.dir, nameOf);
    }
    function drawFilters() {
      var cur = fSt.value || fl.studentId;
      fSt.textContent = '';
      var a = mk('option', null, 'كل الطلاب'); a.value = 'all'; fSt.appendChild(a);
      activeList().forEach(function (s) { var o = mk('option', null, s.name); o.value = s.studentId; fSt.appendChild(o); });
      roster.students.filter(function (s) { return s.status === 'archived'; }).forEach(function (s) { var o = mk('option', null, s.name + ' (مؤرشف)'); o.value = s.studentId; fSt.appendChild(o); });
      fSt.value = Array.prototype.some.call(fSt.options, function (o) { return o.value === cur; }) ? cur : 'all'; fl.studentId = fSt.value;
    }
    function drawSummary(list) {
      var s, notes = [], box, per, ulS;
      sumBox.textContent = '';
      if (blockedMsg) return;
      sumBox.appendChild(mk('h2', null, 'المستلم المسجَّل'));
      if (periodBad()) { sumBox.appendChild(mk('p', 'muted', 'صحّح الفترة أولاً لحساب الإجمالي.')); return; }
      sumBox.appendChild(mk('p', 'muted pay-period', 'الفترة التي يغطيها الإجمالي: ' + model.periodLabel(fl.from, fl.to)));
      if (fl.studentId !== 'all') notes.push('الطالب: ' + (nameOf(fl.studentId) || 'طالب غير موجود في قائمة هذا الصف'));
      if (fl.query.trim()) notes.push('بحث: «' + fl.query.trim() + '»');
      if (notes.length) sumBox.appendChild(mk('p', 'muted pay-period', 'مقيَّد أيضاً بـ ' + notes.join('، ')));
      if (!list.length) { sumBox.appendChild(mk('p', 'muted', records.length ? 'لا توجد دفعات مطابقة في هذه الفترة، فالإجمالي لا ينطبق.' : 'لا توجد دفعات مسجلة بعد، لذلك لا يوجد إجمالي.')); return; }
      s = model.sumRecords(list);
      box = mk('p', 'gr-avg'); box.appendChild(mk('b', 'gr-avg-n pay-total', model.formatAmount(s.total, true)));
      box.appendChild(mk('span', 'muted', ' في ' + s.count + ' دفعة'));
      sumBox.appendChild(box);
      sumBox.appendChild(mk('p', 'muted gr-basis', 'هذا مجموع ما سُجِّل أنه استُلم فعلاً ضمن هذه الفترة والفلاتر، وليس مبلغاً مطلوباً أو متبقياً. تغيير الفترة يغيّر الإجمالي؛ ولرؤية كل ما سُجّل امسح الفترة.'));
      if (s.invalid) sumBox.appendChild(mk('p', 'notice warnbox', 'استُثني ' + s.invalid + ' سجل ببيانات مبلغ غير صالحة من الإجمالي (لم يُعامل كصفر).'));
      if (s.overflow) sumBox.appendChild(mk('p', 'notice warnbox', 'المجموع تجاوز الحد الآمن للحساب؛ لم تُحتسب بعض السجلات.'));
      per = model.totalsByStudent(list, nameOf);
      if (fl.studentId === 'all' && per.length > 0) {
        sumBox.appendChild(mk('h3', null, 'إجمالي كل طالب (ضمن الفترة نفسها)'));
        ulS = mk('ul', 'gr-subs pay-per');
        per.forEach(function (p) {
          var li = mk('li'), nm = nameOf(p.studentId) || 'طالب غير موجود في قائمة هذا الصف', kind = model.studentKind(p.studentId, roster.students), b = mk('b', null, nm);
          li.setAttribute('data-student-id', p.studentId);
          li.appendChild(b);
          if (kind !== 'active') li.appendChild(mk('span', 'tag', kind === 'archived' ? 'مؤرشف' : 'غير معروف'));
          li.appendChild(mk('span', 'muted pay-amt', model.formatAmount(p.total, true) + ' (' + p.count + ' دفعة)'));
          ulS.appendChild(li);
        });
        sumBox.appendChild(ulS);
      }
    }
    function card(r) {
      var li = mk('li', 'arow grow'), top = mk('div', 'ar-top'), kind = model.studentKind(r.studentId, roster.students), nm = nameOf(r.studentId) || 'طالب غير موجود في قائمة هذا الصف', sc = mk('p', 'gr-score');
      li.setAttribute('data-record-id', r.recordId); li.setAttribute('data-student-id', r.studentId);
      top.appendChild(mk('b', 'ar-n', nm));
      if (kind !== 'active') top.appendChild(mk('span', 'tag', kind === 'archived' ? 'مؤرشف' : 'غير معروف'));
      li.appendChild(top);
      li.appendChild(mk('h3', 'gr-t', r.purpose));
      li.appendChild(mk('p', 'muted gr-d', model.formatDate(r.date) + (r.receiptNo ? ' — وصل: ' + r.receiptNo : '')));
      sc.appendChild(mk('b', 'pay-amt', model.formatAmount(r.amount, true)));
      li.appendChild(sc);
      if (r.note) li.appendChild(mk('p', 'lc-t', r.note));
      var acts = mk('div', 'acts'), lab = nm + ' — ' + r.purpose + ' — ' + model.formatDate(r.date);
      if (kind === 'active') { var eb = btn('link', 'تعديل', function () { startEdit(r); }); eb.setAttribute('aria-label', 'تعديل دفعة ' + lab); acts.appendChild(eb); }
      var db = btn('link danger', 'حذف', function () { askDelete(r); }); db.setAttribute('aria-label', 'حذف دفعة ' + lab); acts.appendChild(db);
      li.appendChild(acts);
      if (kind !== 'active') li.appendChild(mk('p', 'muted', 'سجل تاريخي للقراءة والحذف فقط؛ لا يُعدَّل ولا تُسجَّل دفعات جديدة لهذا الطالب.'));
      return li;
    }
    function drawList() {
      var list, shown;
      ul.textContent = ''; emptyBox.textContent = ''; periodErr.textContent = periodBad() || '';
      if (blockedMsg) { rc.textContent = ''; drawSummary([]); return; }
      list = periodBad() ? [] : filtered(); drawSummary(list);
      rc.textContent = records.length ? 'النتائج: ' + list.length + ' من ' + records.length + (list.length > PAY_LIST_MAX ? ' (يُعرض أول ' + PAY_LIST_MAX + '؛ ضيّق البحث لرؤية الباقي. الإجمالي أعلاه يشمل كل النتائج)' : '') : '';
      if (!records.length) { var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لا توجد دفعات مسجلة بعد')); e.appendChild(document.createTextNode('سجّل أول دفعة مستلمة من النموذج أعلاه. لا تُنشأ أي مبالغ أو مستحقات تلقائياً.')); emptyBox.appendChild(e); return; }
      if (!list.length) { if (!periodBad()) emptyBox.appendChild(mk('p', 'muted', 'لا توجد دفعات مطابقة للبحث أو الفلاتر.')); return; }
      shown = list.slice(0, PAY_LIST_MAX);
      shown.forEach(function (r) { ul.appendChild(card(r)); });
    }
    function drawAll() { banner(); drawStudentOptions(); drawPurposeList(); drawFilters(); drawFormMode(); updateRecHint(); drawList(); }

    // ----- بناء الواجهة -----
    stSel.setAttribute('autocomplete', 'off');
    amtIn.type = 'text'; amtIn.inputMode = 'numeric'; amtIn.autocomplete = 'off'; amtIn.setAttribute('dir', 'ltr'); amtIn.maxLength = 20;
    purIn.type = 'text'; purIn.maxLength = model.PURPOSE_MAX; purIn.autocomplete = 'off'; purList.id = 'pay-purpose-list'; purIn.setAttribute('list', purList.id);
    dateIn.type = 'date'; dateIn.min = model.MIN_YEAR + '-01-01'; dateIn.max = today(); dateIn.value = today();
    recIn.type = 'text'; recIn.maxLength = model.RECEIPT_MAX; recIn.autocomplete = 'off'; recIn.setAttribute('dir', 'ltr');
    noteIn.type = 'text'; noteIn.maxLength = model.NOTE_MAX; noteIn.autocomplete = 'off';
    recHint.id = 'pay-receiptNo-w'; recHint.setAttribute('aria-live', 'polite');
    formSec.appendChild(formTitle);
    formSec.appendChild(mk('p', 'muted', 'سجّل فقط ما استلمته فعلاً. المبلغ بالدينار العراقي عدداً صحيحاً بلا كسور، ولا يوجد مبلغ افتراضي.'));
    formSec.appendChild(noStudents);
    formSec.appendChild(fld('studentId', 'الطالب', stSel));
    formSec.appendChild(fld('amount', 'المبلغ المستلم (دينار عراقي)', amtIn, 'مثل 5000 أو 25,000.'));
    formSec.appendChild(fld('purpose', 'الغرض', purIn, 'نص حرّ؛ تظهر الأغراض المستعملة سابقاً كاقتراحات.')); formSec.appendChild(purList);
    formSec.appendChild(fld('date', 'تاريخ الاستلام', dateIn));
    formSec.appendChild(fld('receiptNo', 'رقم الوصل أو المرجع (اختياري)', recIn, null, recHint));
    formSec.appendChild(fld('note', 'ملاحظة (اختيارية)', noteIn));
    msgP.setAttribute('role', 'alert'); msgP.id = 'pay-msg'; formSec.appendChild(msgP);
    var bar = mk('div', 'toolbar');
    saveBtn = btn('primary', 'حفظ الدفعة', save); cancelBtn = btn('link', 'إلغاء التعديل', function () {
      if (dirty) askConfirm('تجاهل التعديل؟', 'ستُفقد التغييرات غير المحفوظة في النموذج.', 'تجاهل والمتابعة', function () { resetForm(true); }); else resetForm(true);
    });
    cancelBtn.hidden = true; bar.appendChild(saveBtn); bar.appendChild(cancelBtn); formSec.appendChild(bar);
    [stSel, amtIn, purIn, dateIn, recIn, noteIn].forEach(function (e) { e.addEventListener('input', function () { dirty = true; }); e.addEventListener('change', function () { dirty = true; }); });
    [stSel, amtIn, purIn, dateIn, recIn, noteIn].forEach(function (e) { e.addEventListener('input', function () { e.removeAttribute('aria-invalid'); var k = e.id.replace('pay-', ''); if (F[k]) F[k].err.textContent = ''; }); });
    recIn.addEventListener('input', updateRecHint);
    formSec.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' && ev.target && ev.target.tagName === 'INPUT') { ev.preventDefault(); save(); } });

    listSec.appendChild(mk('h2', null, 'سجل المقبوضات'));
    qIn.type = 'search'; qIn.autocomplete = 'off'; qIn.placeholder = 'ابحث بالطالب أو الغرض أو رقم الوصل أو التاريخ'; qIn.setAttribute('aria-label', 'ابحث في المدفوعات بالطالب أو الغرض أو رقم الوصل أو التاريخ');
    qIn.addEventListener('input', function () { fl.query = qIn.value; drawList(); });
    fSt.setAttribute('aria-label', 'فلتر الطالب'); fSt.addEventListener('change', function () { fl.studentId = fSt.value; drawList(); });
    fFrom.type = 'date'; fTo.type = 'date'; fFrom.setAttribute('aria-label', 'من تاريخ'); fTo.setAttribute('aria-label', 'إلى تاريخ');
    fFrom.addEventListener('change', function () { fl.from = fFrom.value; drawList(); }); fTo.addEventListener('change', function () { fl.to = fTo.value; drawList(); });
    model.SORTS.forEach(function (k) { var o = mk('option', null, 'الفرز حسب: ' + model.SORT_LABELS[k]); o.value = k; o.selected = payUi.sort === k; sSel.appendChild(o); });
    [['desc', 'تنازلي (الأحدث/الأعلى أولاً)'], ['asc', 'تصاعدي']].forEach(function (d) { var o = mk('option', null, d[1]); o.value = d[0]; o.selected = payUi.dir === d[0]; dSel.appendChild(o); });
    sSel.setAttribute('aria-label', 'معيار الفرز'); dSel.setAttribute('aria-label', 'اتجاه الفرز');
    sSel.addEventListener('change', function () { payUi.sort = sSel.value; drawList(); }); dSel.addEventListener('change', function () { payUi.dir = dSel.value; drawList(); });
    var fg = mk('div', 'att-filters'); [qIn, fSt].forEach(function (e) { fg.appendChild(e); }); listSec.appendChild(fg);
    var dg = mk('div', 'att-filters');
    [['من تاريخ', fFrom, 'pay-from'], ['إلى تاريخ', fTo, 'pay-to']].forEach(function (x) { var g = mk('div', 'fg'), l = mk('label', 'fl', x[0]); x[1].id = x[2]; l.htmlFor = x[2]; g.appendChild(l); g.appendChild(x[1]); dg.appendChild(g); });
    dg.appendChild(sSel); dg.appendChild(dSel); listSec.appendChild(dg);
    var pb = mk('div', 'toolbar pay-period-bar');
    pb.appendChild(btn('link', 'هذا الشهر', function () { var t = today(); fl.from = t.slice(0, 8) + '01'; fl.to = t; fFrom.value = fl.from; fTo.value = fl.to; drawList(); }));
    pb.appendChild(btn('link', 'مسح الفترة', function () { fl.from = ''; fl.to = ''; fFrom.value = ''; fTo.value = ''; drawList(); }));
    listSec.appendChild(pb);
    periodErr.setAttribute('role', 'alert'); listSec.appendChild(periodErr);
    rc.setAttribute('aria-live', 'polite'); listSec.appendChild(rc); listSec.appendChild(emptyBox); listSec.appendChild(ul);
    host.appendChild(formSec); host.appendChild(sumBox); host.appendChild(listSec);

    load(); shownToday = today(); drawAll();
    payCtl = {
      cid: cid, dirty: function () { return !blockedMsg && dirty; },
      reload: function () { if (activeId() !== cid) return; load(); drawAll(); },
      dayCheck: function () { if (activeId() === cid && shownToday && today() !== shownToday) { shownToday = today(); dateIn.max = shownToday; } }
    };
  }
  function renderStudentGrades() {
    // وضع الطالب العام: لا قراءة لنوع grades هنا إطلاقاً (لا توجد مصادقة أو هوية طالب موثوقة في هذه النسخة)
    var s = mk('section', 'part'), e = mk('p', 'empty');
    s.appendChild(mk('h2', null, 'الدرجات'));
    e.appendChild(mk('strong', null, 'عرض الدرجات الفردية غير متاح بعد'));
    e.appendChild(document.createTextNode('عرض درجات كل طالب يحتاج مصادقة وهوية طالب موثوقة غير متوفرتين في هذه النسخة، وتأتي في مرحلة لاحقة. لذلك لا تُعرض هنا درجات أي طالب، ولا يُعدّ كود الطالب كلمة مرور. مواعيد الامتحانات القادمة والسابقة متاحة في صفحة «الامتحانات».'));
    s.appendChild(e); host.appendChild(s);
  }

  // ===== 03.4: الجدول الدراسي الأسبوعي — وضع ممثل الصف =====
  // التخزين عبر MarsaAcademicStore (النوع schedule) وclassId الصف النشط وقت فتح الصفحة، منفصل تماماً عن dailyLessons وpreparations:
  // الجدول يصف الموعد المخطَّط فقط، ولا يُنشأ منه أي سجل «ما أُخذ» ولا تحضير. كل نص يدخله المستخدم يُعرض بـ textContent.
  // الأيام الظاهرة إعداد عرض لكل صف في المفتاح marsa.scheduleDays.<classId> (ليست سجلات)، ولا يُخفى أي يوم فيه حصص.
  // الترتيب الظاهر (رقم الحصة والوقت) يُحسب عند العرض ولا يُستعمل معرّفاً؛ المعرّف الثابت هو recordId.
  var SCHED_TYPE = 'schedule', SCHED_DAYS_PREFIX = 'marsa.scheduleDays.', scheduleCtl = null, schedUi = { mode: 'day', day: null };
  function schedRow(r, model, onEdit, onDelete) {
    var li = mk('li', 'prow'), n = mk('div', 'pr-n'), b = mk('div', 'pr-b'), subj = model.field(r, 'subject'), p = model.periodOf(r), tr = model.timeRange(r), note = model.field(r, 'notes'), acts = mk('div', 'acts'), eb, db;
    li.tabIndex = -1; li.setAttribute('data-record-id', model.field(r, 'recordId'));
    n.appendChild(mk('span', 'pnum' + (p ? '' : ' none'), p ? String(p) : '—'));
    n.appendChild(mk('small', 'muted', p ? 'الحصة' : 'بلا رقم'));
    b.appendChild(mk('h3', null, subj || '(بلا مادة)'));
    if (tr) b.appendChild(mk('p', 'pr-t', tr));
    if (note) b.appendChild(mk('p', 'lc-t pr-note', note));
    li.appendChild(n); li.appendChild(b);
    eb = btn('link', 'تعديل', onEdit); db = btn('link danger', 'حذف', onDelete);
    eb.setAttribute('aria-label', 'تعديل حصة ' + (subj || '') + (p ? ' رقم ' + p : ''));
    db.setAttribute('aria-label', 'حذف حصة ' + (subj || '') + (p ? ' رقم ' + p : ''));
    acts.appendChild(eb); acts.appendChild(db); li.appendChild(acts);
    return li;
  }
  function renderSchedule() {
    var store = window.MarsaAcademicStore, model = window.MarsaScheduleModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, formOpen = false, dirty = false, editingId = null;
    var enabled = [], daysStatus = 'none', daysMsg = '';
    scheduleCtl = null;
    if (!activeClass()) { noClassBlock(); return; }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل طبقة التخزين الأكاديمي أو منطق الجدول (js/academic-store.js و js/schedule-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return; }
    classBar();
    host.appendChild(mk('div', 'notice', 'الجدول محفوظ في متصفح هذا الجهاز فقط، ولا يصل إلى الطلاب ولا إلى أجهزة أخرى. المزامنة تحتاج خادماً وستأتي في مرحلة لاحقة.'));
    var sep = mk('div', 'notice sepnote');
    sep.appendChild(mk('span', null, 'الجدول هنا هو الموعد المخطَّط للحصص. ما شرحته فعلاً يُسجَّل بصورة مستقلة في «ما أُخذ اليوم»، والتحضير لما سيأتي في «التحاضير»، ولا يُنشأ أيٌّ منهما من الجدول تلقائياً. '));
    sep.appendChild(btn('link', 'فتح «ما أُخذ اليوم»', function () { go('r-lessons'); }));
    host.appendChild(sep);
    var bannerBox = mk('div'), ctrl = mk('div', 'sctrl'), setBox = mk('details', 'opt dayset-box'), tabsBox = mk('div', 'dtabs'), bar = mk('div', 'toolbar'), count = mk('span', 'count'), addBtn;
    var formHost = mk('section', 'part lform'), body = mk('div', 'part sbody');
    host.appendChild(bannerBox);

    function readDays() {
      var raw = null, p;
      try { raw = localStorage.getItem(SCHED_DAYS_PREFIX + cid); } catch (e) { raw = null; }
      p = model.parseDaysSetting(raw, cid);
      daysStatus = p.status; enabled = p.days; daysMsg = '';
      if (p.status === 'corrupt') { backupRaw(SCHED_DAYS_PREFIX + cid, raw); daysMsg = 'إعداد أيام الأسبوع المحفوظ تالف، فعادت الأيام الافتراضية (الأحد إلى الخميس) وحُفظت نسخة خام احتياطية. اضبط الأيام من جديد إن لزم.'; }
      else if (p.status === 'newer') daysMsg = 'إعداد أيام الأسبوع محفوظ بنسخة أحدث من التطبيق، لذلك لن يُعدَّل هنا.';
    }
    function load() {
      var r = store.readCollection(SCHED_TYPE, cid);
      persistent = r.persistent !== false;
      readDays();
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت قراءة الجدول.'; return false; }
      blockedMsg = ''; records = r.records; return true;
    }
    function banner() {
      bannerBox.textContent = '';
      if (blockedMsg) bannerBox.appendChild(mk('div', 'notice warnbox', blockedMsg));
      else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك الجدول مؤقت في ذاكرة هذه الصفحة ويزول بإغلاقها أو إعادة تحميلها.'));
      if (daysMsg) bannerBox.appendChild(mk('div', 'notice warnbox', daysMsg));
      if (addBtn) addBtn.disabled = !!blockedMsg;
    }
    function sameClass() { if (activeId() !== cid) { say('تغيّر الصف النشط. أعد فتح «الجدول».'); return false; } return true; }
    function grouped() { return model.groupByDay(records); }
    function visible() { return model.visibleDays(enabled, grouped()); }
    function defaultDay() {
      var vis = visible(), t = model.dayKeyOfDate(new Date());
      return vis.indexOf(schedUi.day) > -1 ? schedUi.day : (vis.indexOf(t) > -1 ? t : (vis[0] || 'sun'));
    }

    // ----- ضبط الأيام الظاهرة -----
    function drawSettings() {
      var g = grouped(), box = mk('div', 'opt-b'), sum = mk('summary', null, 'ضبط أيام الأسبوع (' + visible().map(model.dayLabel).join('، ') + ')'), list = mk('div', 'dayset'), checks = {};
      var wasOpen = setBox.open;
      setBox.textContent = '';
      box.appendChild(mk('p', 'muted', 'اختر الأيام التي تُعرض في جدول هذا الصف. اليوم الذي فيه حصص يبقى ظاهراً دائماً حتى لا تُخفى بياناته.'));
      model.DAYS.forEach(function (d) {
        var n = g.byDay[d.key].length, lab = mk('label', 'dchk'), cb = mk('input'), tx = mk('span', null, d.label);
        cb.type = 'checkbox'; cb.checked = enabled.indexOf(d.key) > -1 || n > 0; cb.disabled = n > 0 || daysStatus === 'newer'; cb.setAttribute('data-day', d.key);
        lab.appendChild(cb); lab.appendChild(tx);
        if (n > 0) lab.appendChild(mk('small', 'muted', 'فيه ' + n + ' ' + (n === 1 ? 'حصة' : n === 2 ? 'حصتان' : n <= 10 ? 'حصص' : 'حصة') + ' (ظاهر دائماً)'));
        checks[d.key] = cb; list.appendChild(lab);
        cb.addEventListener('change', function () {
          var next = model.DAYS.map(function (x) { return x.key; }).filter(function (k) { return checks[k].checked; });
          if (!next.length) { cb.checked = true; say('يجب أن يبقى يوم واحد على الأقل ظاهراً.'); return; }
          saveDays(next);
        });
      });
      box.appendChild(list);
      setBox.appendChild(sum); setBox.appendChild(box); setBox.open = wasOpen;
    }
    function saveDays(next) {
      var ok = true;
      if (daysStatus === 'newer') { say(daysMsg); return; }
      try { localStorage.setItem(SCHED_DAYS_PREFIX + cid, model.serializeDaysSetting(next, cid)); if (localStorage.getItem(SCHED_DAYS_PREFIX + cid) === null) ok = false; } catch (e) { ok = false; }
      enabled = next; daysStatus = ok ? 'ok' : daysStatus;
      drawSettings(); drawTabs(); drawBody();
      say(ok ? 'تم حفظ أيام الأسبوع.' : 'تعذّر حفظ ضبط الأيام في المتصفح، فالتغيير مؤقت في هذه الصفحة فقط.', ok ? 3200 : 7000);
    }

    // ----- شريط الأيام وعرض اليوم/الأسبوع -----
    function drawCtrl() {
      ctrl.textContent = '';
      var grp = mk('div', 'sv'); grp.setAttribute('role', 'group'); grp.setAttribute('aria-label', 'طريقة عرض الجدول');
      [['day', 'يوم واحد'], ['week', 'الأسبوع كله']].forEach(function (x) {
        var b = btn('', x[1], function () { schedUi.mode = x[0]; drawCtrl(); drawTabs(); drawBody(); });
        b.setAttribute('aria-pressed', String(schedUi.mode === x[0])); grp.appendChild(b);
      });
      ctrl.appendChild(grp);
    }
    function drawTabs() {
      var g = grouped(), vis = visible(), today = model.dayKeyOfDate(new Date());
      tabsBox.textContent = '';
      tabsBox.hidden = schedUi.mode !== 'day';
      if (vis.indexOf(schedUi.day) < 0) schedUi.day = defaultDay();
      tabsBox.setAttribute('role', 'group'); tabsBox.setAttribute('aria-label', 'اختيار اليوم');
      vis.forEach(function (k) {
        var n = g.byDay[k].length, b = btn('dtab', '', function () { schedUi.day = k; drawTabs(); drawBody(); }), l = mk('span', 'dn', model.dayLabel(k)), c = mk('span', 'dc', String(n));
        b.appendChild(l); b.appendChild(c);
        if (k === today) { var tm = mk('span', 'dt', 'اليوم'); tm.setAttribute('aria-hidden', 'true'); b.appendChild(tm); }
        b.setAttribute('aria-pressed', String(k === schedUi.day));
        b.setAttribute('aria-label', model.dayLabel(k) + '، ' + countPeriods(n) + (k === today ? '، اليوم' : ''));
        if (k === today) b.classList.add('is-today');
        tabsBox.appendChild(b);
      });
    }
    function rowFor(r) { return schedRow(r, model, function () { guard(function () { openForm(r); }); }, function () { askDelete(r); }); }
    function dayEmptyText(k) { return 'لا توجد حصص يوم ' + model.dayLabel(k) + ' بعد. اضغط «إضافة حصة»، ويمكنك إضافة أي عدد من الحصص لهذا اليوم.'; }
    function drawBody() {
      var g = grouped(), vis = visible(), total = records.length, ul;
      body.textContent = '';
      count.textContent = 'عدد الحصص: ' + total;
      if (!total && !blockedMsg) {
        var e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لم يُبنَ جدول هذا الصف بعد'));
        e.appendChild(document.createTextNode('اضغط «إضافة حصة» ثم اختر اليوم واكتب اسم المادة. رقم الحصة والوقت وملاحظتها اختيارية، ولكل يوم عدد حصص مرن. ويمكنك ضبط الأيام الظاهرة من «ضبط أيام الأسبوع».'));
        body.appendChild(e);
      }
      if (schedUi.mode === 'day') {
        var k = schedUi.day, list = k ? g.byDay[k] : [], sec = mk('section', 'pgroup'), h = mk('h2', null, 'يوم ' + model.dayLabel(k) + (list.length ? ' (' + list.length + ')' : ''));
        sec.appendChild(h);
        if (!list.length) { if (total) sec.appendChild(mk('p', 'muted', dayEmptyText(k))); }
        else { ul = mk('ul', 'llist'); list.forEach(function (r) { ul.appendChild(rowFor(r)); }); sec.appendChild(ul); }
        if (total || list.length) body.appendChild(sec);
      } else {
        vis.forEach(function (k) {
          var list = g.byDay[k], sec = mk('section', 'pgroup daycard'), head = mk('div', 'dc-h'), h = mk('h2', null, model.dayLabel(k) + (list.length ? ' (' + list.length + ')' : ''));
          sec.setAttribute('data-day', k);
          head.appendChild(h);
          var ab = btn('link', 'إضافة حصة', function () { guard(function () { openForm(null, { day: k }); }); });
          ab.setAttribute('aria-label', 'إضافة حصة ليوم ' + model.dayLabel(k)); ab.disabled = !!blockedMsg;
          head.appendChild(ab); sec.appendChild(head);
          if (!list.length) sec.appendChild(mk('p', 'muted', 'لا توجد حصص.'));
          else { ul = mk('ul', 'llist'); list.forEach(function (r) { ul.appendChild(rowFor(r)); }); sec.appendChild(ul); }
          body.appendChild(sec);
        });
      }
      if (g.unknown.length) {
        var us = mk('section', 'pgroup daycard unk'), uh = mk('h2', null, 'حصص بيوم غير معروف (' + g.unknown.length + ')');
        us.appendChild(uh);
        us.appendChild(mk('p', 'muted', 'هذه السجلات يومها مفقود أو غير صالح (ربما من نسخة بيانات قديمة أو معدَّلة يدوياً). عدّل كل حصة واختر يومها، أو احذفها.'));
        ul = mk('ul', 'llist'); g.unknown.forEach(function (r) { ul.appendChild(rowFor(r)); }); us.appendChild(ul); body.appendChild(us);
      }
    }

    function closeForm() { formOpen = false; dirty = false; editingId = null; formHost.hidden = true; formHost.textContent = ''; }
    function guard(fn) {
      if (formOpen && dirty) askConfirm('تجاهل ما كتبته؟', 'النموذج المفتوح فيه بيانات لم تُحفظ بعد. إن تابعت فستُفقد.', 'تجاهل والمتابعة', fn);
      else fn();
    }
    function focusRow(id) {
      var items = body.querySelectorAll('li[data-record-id]'), i;
      for (i = 0; i < items.length; i++) if (items[i].getAttribute('data-record-id') === id) { items[i].scrollIntoView({ block: 'nearest' }); items[i].focus({ preventScroll: true }); return; }
    }

    function openForm(rec, pre) {
      var editing = !!rec, form = mk('form', 'lf'), msg = mk('p', 'err'), warn = mk('div', 'sfwarn'), els = {}, errs = {}, busy = false, warnedSig = null, submit, again = null, firstLabel;
      pre = pre || {};
      formOpen = true; dirty = false; editingId = editing ? model.field(rec, 'recordId') : null;
      formHost.hidden = false; formHost.textContent = '';
      var h = mk('h2', null, editing ? 'تعديل حصة' : 'إضافة حصة'); h.tabIndex = -1; formHost.appendChild(h);
      formHost.appendChild(mk('p', 'muted', editing ? 'تعديل الحصة لا يغيّر معرّفها الداخلي ولا صفها.' : 'المطلوب فقط: اليوم واسم المادة. رقم الحصة والوقت والملاحظة اختيارية.'));
      form.noValidate = true;
      var REQ = { day: 1, subject: 1 };
      function addField(key, el, parent) {
        var g = mk('div', 'fg'), lab = mk('label', 'fl', model.LABELS[key] + (REQ[key] ? ' (مطلوب)' : ' (اختياري)')), er = mk('p', 'err');
        el.id = 'sf-' + key; lab.htmlFor = el.id; er.id = 'sf-' + key + '-e'; er.setAttribute('aria-live', 'polite'); el.setAttribute('aria-describedby', er.id);
        if (REQ[key]) el.setAttribute('aria-required', 'true');
        if (model.LIMITS[key]) el.maxLength = model.LIMITS[key];
        el.addEventListener('input', function () { dirty = true; er.textContent = ''; el.removeAttribute('aria-invalid'); msg.textContent = ''; clearWarn(); });
        el.addEventListener('change', function () { clearWarn(); });
        els[key] = el; errs[key] = er;
        g.appendChild(lab); g.appendChild(el); g.appendChild(er); parent.appendChild(g);
      }
      function clearWarn() { if (warnedSig !== null) { warnedSig = null; warn.textContent = ''; if (firstLabel) submit.textContent = firstLabel; } }
      var day = mk('select', 'field'), s = mk('input', 'field'), p = mk('input', 'field'), st = mk('input', 'field'), en = mk('input', 'field'), nt = mk('textarea', 'field');
      var o0 = mk('option', null, 'اختر اليوم'); o0.value = ''; day.appendChild(o0);
      model.DAYS.forEach(function (d) { var o = mk('option', null, d.label); o.value = d.key; day.appendChild(o); });
      s.type = 'text'; s.autocomplete = 'off'; s.placeholder = 'اسم المادة كما تكتبه أنت'; s.setAttribute('enterkeyhint', 'next');
      p.type = 'number'; p.min = '1'; p.max = String(model.MAX_PERIOD); p.step = '1'; p.setAttribute('inputmode', 'numeric'); p.autocomplete = 'off'; p.placeholder = 'مثال: 1'; p.setAttribute('enterkeyhint', 'next');
      st.type = 'time'; en.type = 'time'; st.step = '60'; en.step = '60';
      nt.rows = 2; nt.autocomplete = 'off';
      var subs = model.subjectsOf(records);
      if (subs.length) {
        var dl = mk('datalist'); dl.id = 'sf-subjects';
        subs.forEach(function (x) { var o = mk('option'); o.value = x; dl.appendChild(o); });
        s.setAttribute('list', dl.id); form.appendChild(dl);
      }
      addField('day', day, form); addField('subject', s, form); addField('period', p, form);
      var tg = mk('div', 'tgrid'); addField('startTime', st, tg); addField('endTime', en, tg); form.appendChild(tg);
      addField('notes', nt, form);
      if (editing) {
        day.value = model.isDay(model.field(rec, 'day')) ? model.field(rec, 'day') : '';
        s.value = model.field(rec, 'subject'); p.value = model.periodOf(rec) ? String(model.periodOf(rec)) : '';
        st.value = model.field(rec, 'startTime'); en.value = model.field(rec, 'endTime'); nt.value = model.field(rec, 'notes');
      } else {
        day.value = model.isDay(pre.day) ? pre.day : defaultDay();
        if (pre.period) p.value = String(pre.period);
        if (pre.startTime) st.value = pre.startTime;
      }
      form.appendChild(warn);
      warn.setAttribute('role', 'alert');
      msg.id = 'sf-msg'; msg.setAttribute('role', 'alert'); form.appendChild(msg);
      var acts = mk('div', 'dacts'); firstLabel = editing ? 'حفظ التعديل' : 'حفظ الحصة'; submit = mk('button', 'primary', firstLabel); submit.type = 'submit';
      acts.appendChild(submit);
      if (!editing) { again = btn('link', 'حفظ وإضافة حصة أخرى', function () { doSave(true); }); acts.appendChild(again); }
      acts.appendChild(btn('link', 'إلغاء', function () { guard(function () { closeForm(); }); }));
      form.appendChild(acts);

      function setBusy(b) { busy = b; submit.disabled = b; if (again) again.disabled = b; }
      function doSave(keepOpen) {
        var res, g, existing = null, out, id, conflicts, sig, saved;
        if (busy) return;
        if (!sameClass()) { closeForm(); return; }
        Object.keys(errs).forEach(function (k) { errs[k].textContent = ''; els[k].removeAttribute('aria-invalid'); });
        msg.textContent = '';
        res = model.validate({ day: els.day.value, subject: els.subject.value, period: els.period.value, startTime: els.startTime.value, endTime: els.endTime.value, notes: els.notes.value });
        if (!res.ok) {
          clearWarn();
          Object.keys(res.errors).forEach(function (k) { errs[k].textContent = res.errors[k]; els[k].setAttribute('aria-invalid', 'true'); });
          els[res.firstError].focus(); return;
        }
        // تعارض (رقم حصة مكرر أو تداخل وقت): تنبيه يُظهَر مرة، والضغطة الثانية بعد قراءته تحفظ. لا يُحذف أي سجل آخر ولا يُعدَّل بصمت.
        conflicts = model.findConflicts(records, res.values, editingId);
        if (conflicts.length) {
          sig = model.conflictSignature(conflicts, res.values);
          if (warnedSig !== sig) {
            warnedSig = sig; warn.textContent = '';
            warn.appendChild(mk('strong', null, 'تنبيه: يوجد تعارض مع حصص أخرى'));
            var wl = mk('ul'); conflicts.forEach(function (c) { wl.appendChild(mk('li', null, c.message)); }); warn.appendChild(wl);
            warn.appendChild(mk('p', null, 'التنبيه لا يمنع الحفظ، ولن يُحذف أو يتغير أي سجل آخر. إن كان ما أدخلته مقصوداً فاضغط «حفظ رغم التنبيه»، وإلا عدّل اليوم أو الحصة أو الوقت.'));
            submit.textContent = 'حفظ رغم التنبيه';
            warn.scrollIntoView({ block: 'nearest' });
            return;
          }
        }
        setBusy(true);
        try {
          if (editing) {
            g = store.getRecord(SCHED_TYPE, cid, editingId);
            if (!g.ok) { msg.textContent = 'لم يُحفظ شيء: ' + (g.status === 'not-found' ? 'هذه الحصة لم تعد موجودة (ربما حُذفت من تبويب آخر). أضف حصة جديدة إن أردت.' : (g.error || 'تعذّرت قراءة الحصة.')) + ' بياناتك ما زالت في النموذج.'; return; }
            existing = g.record;
          }
          out = store.upsertRecord(SCHED_TYPE, cid, model.buildRecord(res.values, existing));
        } catch (err) { out = { ok: false, error: 'خطأ غير متوقع أثناء الحفظ.' }; }
        finally { setBusy(false); }
        if (!out.ok) { msg.textContent = 'لم تُحفظ الحصة: ' + (out.error || 'تعذّر الحفظ.') + ' بياناتك ما زالت في النموذج، أعد المحاولة.'; return; }
        persistent = out.persistent !== false;
        records = out.records; id = out.record.recordId; saved = res.values;
        schedUi.day = saved.day;
        closeForm(); banner(); drawSettings(); drawTabs(); drawBody();
        if (keepOpen) { openForm(null, { day: saved.day, period: saved.period ? saved.period + 1 : null, startTime: saved.endTime || '' }); }
        else focusRow(id);
        if (persistent) say(editing ? 'تم حفظ التعديل.' : 'تم حفظ الحصة.', 3200);
        else say((editing ? 'حُفظ التعديل' : 'حُفظت الحصة') + ' في ذاكرة هذه الصفحة فقط وليس بشكل دائم. سيزول بإغلاقها أو إعادة تحميلها.', 8000);
      }
      form.addEventListener('submit', function (e) { e.preventDefault(); doSave(false); });
      formHost.appendChild(form);
      formHost.scrollIntoView({ block: 'start' });
      (editing ? els.subject : (pre.day || !els.day.value ? els.subject : els.subject)).focus({ preventScroll: true });
    }

    function askDelete(r) {
      var subj = model.field(r, 'subject') || '(بلا مادة)', id = model.field(r, 'recordId'), p = model.periodOf(r), tr = model.timeRange(r);
      askConfirm('حذف الحصة', 'سيُحذف نهائياً من جدول هذا الصف: «' + subj + '» يوم ' + model.dayLabel(model.field(r, 'day')) + (p ? '، الحصة ' + p : '') + (tr ? ' (' + tr + ')' : '') + '. لا يمكن التراجع عن الحذف، ولا يتأثر «ما أُخذ اليوم» ولا التحاضير. هل تريد المتابعة؟', 'حذف الحصة', function () {
        var out;
        if (!sameClass()) return;
        out = store.deleteRecord(SCHED_TYPE, cid, id);
        if (!out.ok) { say('لم تُحذف الحصة: ' + (out.error || 'تعذّر الحذف.'), 6000); if (out.status === 'not-found') { load(); banner(); drawSettings(); drawTabs(); drawBody(); } return; }
        persistent = out.persistent !== false; records = out.records;
        if (editingId === id) closeForm();
        banner(); drawSettings(); drawTabs(); drawBody(); count.tabIndex = -1; count.focus({ preventScroll: true });
        say(persistent ? 'تم حذف الحصة.' : 'حُذفت الحصة من ذاكرة هذه الصفحة فقط وليس بشكل دائم.', persistent ? 3200 : 8000);
      });
    }

    addBtn = btn('primary', 'إضافة حصة', function () { guard(function () { openForm(null, { day: defaultDay() }); }); });
    bar.appendChild(count); bar.appendChild(addBtn);
    load();
    drawCtrl(); drawSettings(); drawTabs();
    host.appendChild(ctrl); host.appendChild(setBox); host.appendChild(tabsBox); host.appendChild(bar);
    formHost.hidden = true; host.appendChild(formHost);
    host.appendChild(body);
    banner(); drawBody();
    scheduleCtl = {
      cid: cid, dirty: function () { return formOpen && dirty; },
      reload: function () { if (activeId() !== cid) return; load(); banner(); drawSettings(); drawTabs(); drawBody(); }
    };
  }

  // ===== إدارة الصفوف: بيانات محلية في هذا المتصفح فقط =====
  // لكل صف classId ثابت وفريد لا يُشتق من الاسم ولا من الترتيب. عنوان الصف يُحسب من حقوله،
  // فتعديل الحقول لا يغيّر المعرّف. قائمة طلاب الصف التجريبي تبقى في marsa.roster كما هي،
  // وبقية الصفوف تحفظ قوائمها في marsa.roster.<classId>. أي بيانات مستقبلية مرتبطة بصف
  // (امتحانات، غياب...) يجب أن تُحسب في relatedCount قبل السماح بالحذف النهائي.
  var CLASSES_KEY = 'marsa.classes', CLASSES_SCHEMA = 1, MAX_FIELD = 80, ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
  var classes = { schemaVersion: CLASSES_SCHEMA, activeClassId: null, classes: [] };
  var classMsg = '', readOnlyClasses = false;
  var dlgClass = document.getElementById('dlg-class'), classBox = document.getElementById('dlg-class-body');
  guardDlg(dlgAdd); guardDlg(dlgClass);
  var FIELD_DEFS = [
    { k: 'schoolName', id: 'cf-school', label: 'اسم المدرسة (اختياري)' },
    { k: 'stage', id: 'cf-stage', label: 'المرحلة / الصف (مطلوب)', req: true },
    { k: 'branch', id: 'cf-branch', label: 'الفرع أو التخصص (اختياري)' },
    { k: 'section', id: 'cf-section', label: 'الشعبة (اختياري)' },
    { k: 'year', id: 'cf-year', label: 'السنة الدراسية (اختياري)' }
  ];

  // الصف التجريبي الأصلي: يعكس بيانات النسخة الحالية ولا يُضاف إليه أي قيم أخرى
  function demoClass() {
    return { classId: DEMO_ID, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null };
  }
  function normClass(s) {
    var o;
    if (!s || typeof s !== 'object' || typeof s.classId !== 'string' || !ID_RE.test(s.classId)) return null;
    if (s.status !== 'active' && s.status !== 'archived') return null;
    o = { classId: s.classId, status: s.status, createdAt: validDate(s.createdAt), archivedAt: s.status === 'archived' ? validDate(s.archivedAt) : null };
    FIELD_DEFS.forEach(function (f) { o[f.k] = typeof s[f.k] === 'string' ? cleanName(s[f.k]).slice(0, MAX_FIELD) : ''; });
    return o.stage ? o : null;
  }
  function getClass(id) { for (var i = 0; i < classes.classes.length; i++) if (classes.classes[i].classId === id) return classes.classes[i]; return null; }
  function activeId() { return classes.activeClassId; }
  function activeClass() { var c = classes.activeClassId ? getClass(classes.activeClassId) : null; return c && c.status === 'active' ? c : null; }
  function classLabel(c) { return [c.stage, c.branch, c.section ? 'شعبة ' + c.section : ''].filter(Boolean).join(' — '); }
  function classKey(c) { return [c.schoolName, c.stage, c.branch, c.section, c.year].map(simKey).join('|'); }
  function byLabel(a, b) { return cmpAr(classLabel(a), classLabel(b)) || (a.classId < b.classId ? -1 : 1); }
  function newClassId() {
    var used = {}, id, r, a, i;
    classes.classes.forEach(function (c) { used[c.classId] = 1; });
    do {
      r = '';
      if (window.crypto && crypto.getRandomValues) { a = new Uint8Array(8); crypto.getRandomValues(a); for (i = 0; i < a.length; i++) r += ('0' + a[i].toString(16)).slice(-2); }
      else r = (Math.random().toString(16) + '0000000000000000').slice(2, 18);
      id = 'cls_' + Date.now().toString(36) + '_' + r;
    } while (used[id]);
    return id;
  }

  function seedClasses() { classes.classes = [demoClass()]; classes.activeClassId = DEMO_ID; }
  function loadClasses() {
    var raw = null, data, seen = {}, dropped = 0, hasDemo = false;
    classMsg = ''; readOnlyClasses = false;
    classes = { schemaVersion: CLASSES_SCHEMA, activeClassId: null, classes: [] };
    try { raw = localStorage.getItem(CLASSES_KEY); }
    catch (e) { classMsg = 'التخزين المحلي غير متاح في هذا المتصفح، لذلك لن يُحفظ اختيار الصف بعد إغلاق الصفحة.'; seedClasses(); return; }
    // أول تشغيل: لا يوجد مفتاح صفوف سابق، فنهيّئه بالصف التجريبي دون المساس بقائمة الطلاب
    if (raw === null) { seedClasses(); saveClasses(); return; }
    try { data = JSON.parse(raw); } catch (e) { data = null; }
    if (!data || typeof data !== 'object' || !Array.isArray(data.classes) || typeof data.schemaVersion !== 'number') {
      backupRaw(CLASSES_KEY, raw);
      classMsg = 'تعذّرت قراءة إعدادات الصفوف لأنها تالفة. حُفظت نسخة خام احتياطية وعاد الصف التجريبي فقط. قوائم الطلاب لم تُمسّ.';
      seedClasses();
      return;
    }
    if (data.schemaVersion > CLASSES_SCHEMA) { readOnlyClasses = true; classMsg = 'إعدادات الصفوف محفوظة بنسخة أحدث من هذه الصفحة، لذلك لن تُعدَّل ولن يُكتب فوقها.'; }
    data.classes.forEach(function (s) {
      var c = normClass(s);
      if (!c || seen[c.classId]) { dropped++; return; }
      seen[c.classId] = 1;
      if (c.classId === DEMO_ID) hasDemo = true;
      classes.classes.push(c);
    });
    if (!hasDemo) classes.classes.unshift(demoClass());
    if (dropped) { backupRaw(CLASSES_KEY, raw); classMsg += (classMsg ? ' ' : '') + 'تم تجاهل ' + dropped + ' صف غير صالح عند قراءة البيانات، وحُفظت نسخة خام احتياطية.'; }
    var act = typeof data.activeClassId === 'string' ? getClass(data.activeClassId) : null;
    classes.activeClassId = act && act.status === 'active' ? act.classId : null;
  }
  function saveClasses() {
    if (readOnlyClasses) return false;
    try { localStorage.setItem(CLASSES_KEY, JSON.stringify(classes)); return true; }
    catch (e) { classMsg = 'تعذّر حفظ إعدادات الصفوف في تخزين المتصفح، فما تراه الآن مؤقت.'; return false; }
  }
  function classBlocked() { if (readOnlyClasses) { say(classMsg); return true; } return false; }
  function persistClasses(okMsg) { var ok = saveClasses(); renderClassUI(); refreshView(); report(okMsg, ok); }

  // عدد الطلاب المرتبطين بالصف. ok=false يعني تعذّر التأكد (تخزين غير متاح أو بيانات تالفة)
  function rosterInfo(id) {
    var raw, d, list;
    function pack(l) { return { n: l.length, act: l.filter(function (x) { return x && x.status === 'active'; }).length, ok: true }; }
    if (id === activeId()) { var r = pack(roster.students); r.ok = !(storeMsg || readOnlyStore); return r; }
    if (memRosters[id]) return pack(memRosters[id].students);
    try { raw = localStorage.getItem(rosterKeyFor(id)); } catch (e) { return { n: 0, act: 0, ok: false }; }
    if (raw === null) return { n: 0, act: 0, ok: true };
    try { d = JSON.parse(raw); } catch (e) { d = null; }
    if (d && Array.isArray(d.students) && (d.classId === id || (id === DEMO_ID && (d.classId === undefined || d.classId === null)))) return pack(d.students);
    return { n: 0, act: 0, ok: false };
  }
  function relatedCount(id) { return rosterInfo(id); }
  // عدد السجلات في كل مجموعات التخزين الأكاديمي للصف. ok=false: تعذّر التأكد (الطبقة غير محمّلة أو مجموعة تالفة)
  function academicCount(id) {
    var st = window.MarsaAcademicStore, n = 0, i, r;
    if (!st) return { n: 0, ok: false };
    for (i = 0; i < st.TYPES.length; i++) { r = st.readCollection(st.TYPES[i], id); if (!r.ok) return { n: 0, ok: false }; n += r.records.length; }
    return { n: n, ok: true };
  }
  function deleteCheck(c) {
    var info;
    if (c.classId === DEMO_ID) return { ok: false, reason: 'الصف التجريبي الأصلي محمي من الحذف النهائي لأن قائمة الطلاب الحالية مرتبطة به. يمكنك أرشفته بدلاً من ذلك، وتبقى كل بياناته محفوظة.' };
    info = relatedCount(c.classId);
    if (!info.ok) return { ok: false, reason: 'تعذّر التأكد من أن الصف خالٍ من البيانات (التخزين غير متاح أو بياناته تالفة)، لذلك لا يُحذف نهائياً. يمكنك أرشفته بدلاً من ذلك.' };
    if (info.n > 0) return { ok: false, reason: 'يحتوي هذا الصف على ' + info.n + ' من الطلاب المرتبطين به، والحذف النهائي سيفقدهم وسجلاتهم. لذلك الأرشفة هي الخيار الآمن: يبقى كل شيء محفوظاً ويمكنك استعادة الصف لاحقاً.' };
    // 03.2: السجلات الأكاديمية (ما أُخذ اليوم وغيرها) تمنع الحذف النهائي أيضاً حتى لا تُترك يتيمة
    var ac = academicCount(c.classId);
    if (!ac.ok) return { ok: false, reason: 'تعذّر التأكد من أن الصف خالٍ من السجلات الدراسية (طبقة التخزين الأكاديمي غير متاحة أو بياناتها تالفة)، لذلك لا يُحذف نهائياً. يمكنك أرشفته بدلاً من ذلك.' };
    if (ac.n > 0) return { ok: false, reason: 'يحتوي هذا الصف على ' + ac.n + ' من السجلات الدراسية (مثل سجل «ما أُخذ اليوم»)، والحذف النهائي سيفقدها. لذلك الأرشفة هي الخيار الآمن: يبقى كل شيء محفوظاً ويمكنك استعادة الصف لاحقاً.' };
    return { ok: true, reason: '' };
  }

  function selectClass(id) {
    var c = getClass(id);
    if (!c || c.status !== 'active' || classBlocked()) return;
    classes.activeClassId = id; state.detailId = null;
    loadRoster();
    persistClasses('الصف النشط الآن: «' + classLabel(c) + '».');
  }
  function archiveClass(id) {
    var c = getClass(id);
    if (!c || c.status !== 'active' || classBlocked()) return;
    c.status = 'archived'; c.archivedAt = new Date().toISOString();
    if (classes.activeClassId === id) { classes.activeClassId = null; state.detailId = null; loadRoster(); }
    persistClasses('تمت أرشفة «' + classLabel(c) + '». يمكنك استعادته من الصفوف المؤرشفة.');
  }
  function restoreClass(id) {
    var c = getClass(id);
    if (!c || c.status !== 'archived' || classBlocked()) return;
    c.status = 'active'; c.archivedAt = null;
    persistClasses('تمت استعادة «' + classLabel(c) + '». اختره كصف نشط عند الحاجة.');
  }
  function deleteClass(id) {
    var c = getClass(id), d;
    if (!c || classBlocked()) return;
    d = deleteCheck(c);
    if (!d.ok) { showInfo('لا يمكن حذف هذا الصف نهائياً', d.reason); return; }
    classes.classes = classes.classes.filter(function (x) { return x.classId !== id; });
    if (classes.activeClassId === id) { classes.activeClassId = null; state.detailId = null; loadRoster(); }
    delete memRosters[id];
    try { localStorage.removeItem(rosterKeyFor(id)); } catch (e) { /* تجاهل */ }
    try { localStorage.removeItem(SCHED_DAYS_PREFIX + id); } catch (e) { /* تجاهل */ } // إعداد أيام الجدول (عرض فقط، ليس سجلات)
    // مجموعات أكاديمية فارغة فقط (تحققت deleteCheck أنها بلا سجلات): نزيل مفاتيحها حتى لا تبقى يتيمة. النسخ .backup لا تُلمس.
    if (window.MarsaAcademicStore) window.MarsaAcademicStore.TYPES.forEach(function (t) { try { localStorage.removeItem(window.MarsaAcademicStore.keyFor(t, id)); } catch (e) { /* تجاهل */ } });
    persistClasses('تم حذف الصف «' + classLabel(c) + '» نهائياً.');
  }
  function showInfo(title, text) {
    var h = dlgHead(confBox, title, 'dlg-conf-t'), p = mk('p', 'desc', text);
    p.id = 'dlg-conf-d';
    dlgConf.setAttribute('aria-describedby', 'dlg-conf-d');
    confBox.appendChild(p);
    var acts = mk('div', 'dacts');
    acts.appendChild(btn('primary', 'حسناً', function () { closeDlg(dlgConf); }));
    confBox.appendChild(acts);
    openDlg(dlgConf);
    h.focus();
  }
  function askArchiveClass(c) {
    var isA = c.classId === activeId();
    askConfirm('أرشفة الصف', '«' + classLabel(c) + '» سيُنقل إلى الصفوف المؤرشفة. لا تُحذف بياناته ولا طلابه' + (isA ? '، وسيبقى التطبيق بلا صف نشط حتى تختار صفاً آخر' : '') + '. يمكنك استعادته في أي وقت.', 'أرشفة الصف', function () { archiveClass(c.classId); });
  }
  function askDeleteClass(c) {
    var d = deleteCheck(c);
    if (!d.ok) { showInfo('لا يمكن حذف هذا الصف نهائياً', d.reason); return; }
    askConfirm('حذف الصف نهائياً', '«' + classLabel(c) + '» فارغ ولا يحتوي طلاباً. الحذف النهائي لا يمكن التراجع عنه. هل تريد المتابعة؟', 'حذف نهائي', function () { deleteClass(c.classId); });
  }

  // ----- نموذج إضافة/تعديل صف -----
  function openClassForm(c) {
    if (classBlocked()) return;
    var editing = !!c, form = mk('form', 'cform'), inputs = {}, errs = {}, chk = null, acts = mk('div', 'dacts');
    dlgHead(classBox, editing ? 'تعديل بيانات الصف' : 'إضافة صف', 'dlg-class-t');
    classBox.appendChild(mk('p', 'muted', editing ? 'تعديل الحقول لا يغيّر المعرّف الداخلي للصف ولا يمسّ طلابه.' : 'أدخل بيانات الصف كما هي عندك. لا تُضاف أي قيم دراسية تلقائياً.'));
    form.noValidate = true;
    FIELD_DEFS.forEach(function (f) {
      var g = mk('div', 'fg'), lab = mk('label', 'fl', f.label), inp = mk('input', 'field'), er = mk('p', 'err');
      lab.htmlFor = f.id; inp.id = f.id; inp.type = 'text'; inp.maxLength = MAX_FIELD; inp.autocomplete = 'off';
      inp.value = c ? c[f.k] : '';
      er.id = f.id + '-e'; er.setAttribute('aria-live', 'polite');
      inp.setAttribute('aria-describedby', er.id);
      if (f.req) inp.setAttribute('aria-required', 'true');
      inp.addEventListener('input', function () { er.textContent = ''; inp.removeAttribute('aria-invalid'); });
      inputs[f.k] = inp; errs[f.k] = er;
      g.appendChild(lab); g.appendChild(inp); g.appendChild(er);
      form.appendChild(g);
    });
    if (!editing) {
      var lab2 = mk('label', 'chk');
      chk = mk('input'); chk.type = 'checkbox';
      lab2.appendChild(chk); lab2.appendChild(mk('span', null, 'اجعله الصف النشط بعد الإضافة'));
      form.appendChild(lab2);
    }
    var ok = mk('button', 'primary', editing ? 'حفظ التعديلات' : 'إضافة الصف');
    ok.type = 'submit';
    acts.appendChild(ok);
    acts.appendChild(btn('link', 'إلغاء', function () { closeDlg(dlgClass); }));
    form.appendChild(acts);
    form.addEventListener('submit', function (e) {
      var v = {}, bad = null, dup = null, msg, nc, now;
      e.preventDefault();
      if (classBlocked()) return;
      FIELD_DEFS.forEach(function (f) { v[f.k] = cleanName(inputs[f.k].value); errs[f.k].textContent = ''; inputs[f.k].removeAttribute('aria-invalid'); });
      function fail(k, text) { errs[k].textContent = text; inputs[k].setAttribute('aria-invalid', 'true'); if (!bad) bad = k; }
      if (!v.stage) fail('stage', 'أدخل المرحلة أو الصف.');
      FIELD_DEFS.forEach(function (f) { if (v[f.k].length > MAX_FIELD) fail(f.k, 'الحد الأقصى ' + MAX_FIELD + ' حرفاً.'); });
      if (!bad) {
        classes.classes.forEach(function (x) { if (!dup && (!c || x.classId !== c.classId) && classKey(x) === classKey(v)) dup = x; });
        if (dup) fail('stage', 'يوجد صف بالبيانات نفسها («' + classLabel(dup) + '»). غيّر أحد الحقول لتمييز الصفين.');
      }
      if (bad) { inputs[bad].focus(); return; }
      if (editing) {
        FIELD_DEFS.forEach(function (f) { c[f.k] = v[f.k]; });
        msg = 'تم حفظ تعديلات الصف «' + classLabel(c) + '».';
      } else {
        now = new Date().toISOString();
        nc = { classId: newClassId(), status: 'active', createdAt: now, archivedAt: null };
        FIELD_DEFS.forEach(function (f) { nc[f.k] = v[f.k]; });
        classes.classes.push(nc);
        msg = 'تمت إضافة الصف «' + classLabel(nc) + '».';
        if (chk.checked) { classes.activeClassId = nc.classId; state.detailId = null; loadRoster(); msg += ' وهو الآن الصف النشط.'; }
      }
      closeDlg(dlgClass);
      persistClasses(msg);
    });
    classBox.appendChild(form);
    markDirty(dlgClass, false);
    form.addEventListener('input', function () { markDirty(dlgClass, true); });
    openDlg(dlgClass);
    inputs.stage.focus();
  }

  // ----- العرض -----
  function classCard(c, archived) {
    var isA = c.classId === activeId(), li = mk('li', 'cls' + (isA ? ' on' : '')), head = mk('div', 'cls-h'), info = rosterInfo(c.classId), meta = [], acts = mk('div', 'acts'), lbl = classLabel(c);
    function ab(cls, text, fn) { var b = btn(cls, text, fn); b.setAttribute('aria-label', text + ' «' + lbl + '»'); acts.appendChild(b); }
    head.appendChild(mk('h3', null, lbl));
    if (isA) head.appendChild(mk('span', 'tag on', 'الصف النشط'));
    if (c.classId === DEMO_ID) head.appendChild(mk('span', 'tag demo', 'تجريبي'));
    if (archived) head.appendChild(mk('span', 'tag', 'مؤرشف'));
    li.appendChild(head);
    if (c.schoolName) meta.push('المدرسة: ' + c.schoolName);
    if (c.year) meta.push('السنة الدراسية: ' + c.year);
    meta.push(info.ok ? 'الطلاب الفعّالون: ' + info.act + (info.n > info.act ? '، والمحذوفون: ' + (info.n - info.act) : '') : 'عدد الطلاب: غير معروف');
    if (archived) meta.push('أُرشف في ' + fmtDate(c.archivedAt));
    li.appendChild(mk('p', 'muted cls-m', meta.join(' · ')));
    if (archived) ab('link', 'استعادة', function () { restoreClass(c.classId); });
    else if (!isA) ab('primary', 'اختيار كصف نشط', function () { selectClass(c.classId); });
    ab('link', 'تعديل', function () { openClassForm(c); });
    if (!archived) ab('link', 'أرشفة', function () { askArchiveClass(c); });
    ab('link danger', 'حذف نهائي', function () { askDeleteClass(c); });
    li.appendChild(acts);
    return li;
  }
  function renderClasses() {
    var act = classes.classes.filter(function (c) { return c.status === 'active'; }).sort(byLabel);
    var arch = classes.classes.filter(function (c) { return c.status === 'archived'; }).sort(byLabel);
    host.appendChild(mk('div', 'notice', 'الصفوف وقوائم طلابها محفوظة في متصفح هذا الجهاز فقط ولا تُشارك بين الأجهزة. الأرشفة هي الخيار المفضّل، والحذف النهائي لا يُسمح به إلا لصف فارغ تماماً.'));
    if (classMsg) host.appendChild(mk('div', 'notice warnbox', classMsg));
    var bar = mk('div', 'toolbar');
    bar.appendChild(mk('span', 'count', 'عدد الصفوف الفعّالة: ' + act.length));
    bar.appendChild(btn('primary', 'إضافة صف', function () { openClassForm(null); }));
    host.appendChild(bar);
    if (!activeClass()) {
      var w = mk('p', 'empty'); w.appendChild(mk('strong', null, 'لا يوجد صف نشط'));
      w.appendChild(document.createTextNode(act.length ? 'اختر أحد الصفوف أدناه ليصبح الصف النشط.' : 'أضف صفاً أو استعد صفاً مؤرشفاً للبدء.'));
      host.appendChild(w);
    }
    var ul = mk('ul', 'clist');
    act.forEach(function (c) { ul.appendChild(classCard(c, false)); });
    host.appendChild(ul);
    var sec = mk('section', 'part');
    sec.appendChild(mk('h2', null, 'الصفوف المؤرشفة (' + arch.length + ')'));
    if (!arch.length) sec.appendChild(mk('p', 'muted', 'لا توجد صفوف مؤرشفة.'));
    else { var ua = mk('ul', 'clist'); arch.forEach(function (c) { ua.appendChild(classCard(c, true)); }); sec.appendChild(ua); }
    host.appendChild(sec);
  }

  // الشريط العلوي وبطاقة الصفحة الرئيسية تعرضان الصف النشط (أو حالة «لا يوجد صف نشط»)
  function renderClassUI() {
    renderHome(true);
    var c = activeClass(), k = document.getElementById('chip-k'), v = document.getElementById('chip-v');
    var card = document.getElementById('home-card'), note = document.getElementById('home-notice'), dl;
    if (c) mainEl.setAttribute('data-class-id', c.classId); else mainEl.removeAttribute('data-class-id');
    if (k) k.textContent = c && c.classId === DEMO_ID ? 'الصف النشط (تجريبي)' : 'الصف النشط';
    if (v) v.textContent = c ? classLabel(c) : 'لم يُختر صف';
    if (note) note.textContent = c && c.classId === DEMO_ID
      ? 'نسخة أولية: بيانات الصف المعروضة تجريبية. قائمة الطلاب (في وضع ممثل الصف) تُحفظ في هذا المتصفح فقط ولا تُشارك بين الأجهزة.'
      : 'نسخة أولية: الصفوف وقوائم الطلاب (في وضع ممثل الصف) تُحفظ في هذا المتصفح فقط ولا تُشارك بين الأجهزة.';
    if (!card) return;
    card.textContent = '';
    if (!c) {
      card.setAttribute('aria-label', 'لا يوجد صف نشط');
      card.appendChild(mk('span', 'badge', 'لا يوجد صف نشط'));
      card.appendChild(mk('h2', null, 'لم يُختر صف بعد'));
      card.appendChild(mk('p', 'card-note', 'يختار ممثل الصف الصف النشط من «إدارة الصفوف» في وضع ممثل الصف.'));
      return;
    }
    card.setAttribute('aria-label', c.classId === DEMO_ID ? 'بطاقة الصف التجريبي' : 'بطاقة الصف النشط');
    card.appendChild(mk('span', 'badge', c.classId === DEMO_ID ? 'صف تجريبي' : 'الصف النشط'));
    card.appendChild(mk('h2', null, classLabel(c)));
    dl = mk('dl');
    [['المدرسة', c.schoolName], ['المرحلة / الصف', c.stage], ['الفرع / التخصص', c.branch], ['الشعبة', c.section], ['السنة الدراسية', c.year]].forEach(function (r) {
      if (!r[1]) return;
      var d = mk('div'); d.appendChild(mk('dt', null, r[0])); d.appendChild(mk('dd', null, r[1])); dl.appendChild(d);
    });
    card.appendChild(dl);
  }

  // ===== 03.7: الجدول الدراسي — عرض الطالب للقراءة فقط =====
  // يقرأ مباشرة من MarsaAcademicStore (النوع schedule) بـ classId الصف النشط وقت الفتح؛ لا مخزن ثانٍ ولا نسخ ولا كتابة.
  // لا توجد هنا أي أزرار تعديل أو إضافة أو حذف ولا نماذج: أزرار التنقل بين الأيام تغيّر العرض فقط. هذا قيد واجهة محلي وليس حماية.
  // الأيام الظاهرة: إعداد marsa.scheduleDays.<classId> يُقرأ فقط (لا نسخة احتياطية ولا كتابة من وضع الطالب) + أي يوم فيه حصص.
  // الترتيب والتجميع من MarsaScheduleModel نفسه المستعمل في شاشة الممثل (groupByDay)، فيتطابق العرضان.
  // الوقت نص HH:MM محفوظ كما أدخله الممثل ويُنسَّق بدوال نصية فقط (بلا Date)، فلا يتأثر بالمنطقة الزمنية. Date تُستعمل لتمييز «اليوم» فقط.
  var stSchedUi = { cid: null, mode: 'day', day: null };
  function renderStudentSchedule() {
    var store = window.MarsaAcademicStore, model = window.MarsaScheduleModel, cid = activeId();
    var records = [], blockedMsg = '', persistent = true, enabled = [], sig = '';
    stCtl = null;
    host.appendChild(mk('div', 'notice st-note', 'عرض للقراءة فقط: هذا جدول الحصص الذي بناه ممثل الصف. لا يظهر وقت أو رقم حصة إلا إذا أدخله الممثل. البيانات محفوظة في متصفح هذا الجهاز ولا تصل إلى أجهزة أخرى قبل بناء المزامنة.'));
    if (!activeClass()) {
      var e0 = mk('p', 'empty'); e0.appendChild(mk('strong', null, 'لا يوجد صف نشط'));
      e0.appendChild(document.createTextNode('لم يُختر صف بعد، لذلك لا يوجد جدول لعرضه. يختار ممثل الصف الصف النشط من وضع ممثل الصف.'));
      host.appendChild(e0);
      return;
    }
    if (!store || !model) { host.appendChild(mk('div', 'notice warnbox st-err', 'تعذّر تحميل ملفات العرض (js/academic-store.js و js/schedule-model.js). تأكد أن المجلد كاملاً ثم أعد التحميل. لا يعني هذا أن لا جدول للصف.')); return; }
    if (stSchedUi.cid !== cid) stSchedUi = { cid: cid, mode: 'day', day: null }; // لا يُنقل اختيار يوم من صف إلى صف آخر
    var bannerBox = mk('div'), count = mk('p', 'count st-count'), ctrl = mk('div', 'sctrl'), nav = mk('div', 'dnav'), tabsBox = mk('div', 'dtabs'), body = mk('div', 'st-body sbody');
    bannerBox.setAttribute('role', 'status');
    host.appendChild(bannerBox); host.appendChild(count); host.appendChild(ctrl); host.appendChild(nav); host.appendChild(tabsBox); host.appendChild(body);

    function readDays() {
      var raw = null;
      try { raw = localStorage.getItem(SCHED_DAYS_PREFIX + cid); } catch (e) { raw = null; }
      enabled = model.parseDaysSetting(raw, cid).days; // تالف/أحدث → الافتراضي دون أي كتابة
    }
    function load() {
      var r = store.readCollection(SCHED_TYPE, cid);
      persistent = r.persistent !== false;
      readDays();
      if (!r.ok) { records = []; blockedMsg = r.error || 'تعذّرت القراءة.'; }
      else { blockedMsg = ''; records = r.records; }
      sig = [model.dayKeyOfDate(new Date()), persistent, blockedMsg, enabled.join(','), JSON.stringify(records)].join('|');
    }
    function grouped() { return model.groupByDay(records); }
    function visible() { return model.visibleDays(enabled, grouped()); }
    function pickDay() {
      var vis = visible(), t = model.dayKeyOfDate(new Date());
      return vis.indexOf(stSchedUi.day) > -1 ? stSchedUi.day : (vis.indexOf(t) > -1 ? t : (vis[0] || null));
    }
    function sRow(r) {
      var li = mk('li', 'prow st-prow'), n = mk('div', 'pr-n'), b = mk('div', 'pr-b'), subj = model.field(r, 'subject'), p = model.periodOf(r), tr = model.timeRange(r), note = model.field(r, 'notes');
      li.setAttribute('data-record-id', model.field(r, 'recordId'));
      n.appendChild(mk('span', 'pnum' + (p ? '' : ' none'), p ? String(p) : '—'));
      n.appendChild(mk('small', 'muted', p ? 'الحصة' : 'بلا رقم'));
      b.appendChild(mk('h3', null, subj || '(بلا مادة)'));
      if (tr) b.appendChild(mk('p', 'pr-t', tr));
      if (note && note.trim()) b.appendChild(stRich('lc-t pr-note', note));
      li.appendChild(n); li.appendChild(b);
      return li;
    }
    function listOf(list) { var ul = mk('ul', 'llist'); list.forEach(function (r) { ul.appendChild(sRow(r)); }); return ul; }
    function drawCtrl() {
      var grp = mk('div', 'sv');
      ctrl.textContent = '';
      ctrl.hidden = !!blockedMsg || !records.length;
      grp.setAttribute('role', 'group'); grp.setAttribute('aria-label', 'طريقة عرض الجدول');
      [['day', 'يوم واحد'], ['week', 'الأسبوع كله']].forEach(function (x) {
        var b = btn('', x[1], function () { stSchedUi.mode = x[0]; drawNav(); drawBody(); drawCtrl(); });
        b.setAttribute('aria-pressed', String(stSchedUi.mode === x[0])); grp.appendChild(b);
      });
      ctrl.appendChild(grp);
    }
    function drawNav() {
      var g = grouped(), vis = visible(), today = model.dayKeyOfDate(new Date()), i, prev, next, pb, nb;
      nav.textContent = ''; tabsBox.textContent = '';
      var hide = !!blockedMsg || !records.length || stSchedUi.mode !== 'day' || !vis.length;
      nav.hidden = hide; tabsBox.hidden = hide;
      stSchedUi.day = pickDay();
      if (hide) return;
      i = vis.indexOf(stSchedUi.day); prev = i > 0 ? vis[i - 1] : null; next = i < vis.length - 1 ? vis[i + 1] : null;
      // في RTL: «السابق» يمين و«التالي» يسار (ترتيب DOM الطبيعي)
      pb = btn('dstep', prev ? '‹ ' + model.dayLabel(prev) : '‹', function () { if (prev) { stSchedUi.day = prev; drawNav(); drawBody(); } });
      pb.disabled = !prev; pb.setAttribute('aria-label', prev ? 'اليوم السابق: ' + model.dayLabel(prev) : 'لا يوجد يوم سابق');
      nb = btn('dstep', next ? model.dayLabel(next) + ' ›' : '›', function () { if (next) { stSchedUi.day = next; drawNav(); drawBody(); } });
      nb.disabled = !next; nb.setAttribute('aria-label', next ? 'اليوم التالي: ' + model.dayLabel(next) : 'لا يوجد يوم تالٍ');
      nav.appendChild(pb); nav.appendChild(nb);
      tabsBox.setAttribute('role', 'group'); tabsBox.setAttribute('aria-label', 'اختيار اليوم');
      vis.forEach(function (k) {
        var n = g.byDay[k].length, b = btn('dtab', '', function () { stSchedUi.day = k; drawNav(); drawBody(); });
        b.appendChild(mk('span', 'dn', model.dayLabel(k))); b.appendChild(mk('span', 'dc', String(n)));
        if (k === today) { var tm = mk('span', 'dt', 'اليوم'); tm.setAttribute('aria-hidden', 'true'); b.appendChild(tm); }
        b.setAttribute('data-day', k); b.setAttribute('aria-pressed', String(k === stSchedUi.day));
        b.setAttribute('aria-label', model.dayLabel(k) + '، ' + countPeriods(n) + (k === today ? '، اليوم' : ''));
        if (k === today) b.classList.add('is-today');
        tabsBox.appendChild(b);
      });
    }
    function drawBody() {
      var g = grouped(), vis = visible(), today = model.dayKeyOfDate(new Date()), total = records.length, e;
      body.textContent = '';
      count.textContent = blockedMsg ? '' : 'عدد الحصص: ' + total;
      if (blockedMsg) return;
      if (!total) {
        e = mk('p', 'empty'); e.appendChild(mk('strong', null, 'لم يُضف ممثل الصف جدول الحصص بعد'));
        e.appendChild(document.createTextNode('حين يبني ممثل الصف الجدول من وضعه (قسم «الجدول الدراسي الأسبوعي») ستظهر حصص كل يوم هنا مرتبة بأرقامها وأوقاتها إن أدخلها.'));
        body.appendChild(e); return;
      }
      function dayCard(k, one) {
        var list = g.byDay[k], sec = mk('section', 'pgroup' + (one ? '' : ' daycard')), h = mk('h2', null, (one ? 'يوم ' : '') + model.dayLabel(k) + (list.length ? ' (' + list.length + ')' : ''));
        sec.setAttribute('data-day', k);
        if (k === today) { var hh = mk('div', 'dc-h'); hh.appendChild(h); hh.appendChild(mk('span', 'tag on', 'اليوم')); sec.appendChild(hh); } else sec.appendChild(h);
        if (!list.length) sec.appendChild(mk('p', 'muted', 'لا توجد حصص مضافة ليوم ' + model.dayLabel(k) + '.'));
        else sec.appendChild(listOf(list));
        return sec;
      }
      if (stSchedUi.mode === 'day') { if (stSchedUi.day) body.appendChild(dayCard(stSchedUi.day, true)); }
      else vis.forEach(function (k) { body.appendChild(dayCard(k, false)); });
      if (g.unknown.length) {
        var us = mk('section', 'pgroup daycard unk');
        us.setAttribute('data-day', 'unknown');
        us.appendChild(mk('h2', null, 'حصص بلا يوم معروف (' + g.unknown.length + ')'));
        us.appendChild(mk('p', 'muted', 'يومها مفقود أو غير صالح في البيانات المحفوظة. أخبر ممثل الصف ليصحّحها.'));
        us.appendChild(listOf(g.unknown)); body.appendChild(us);
      }
    }
    function draw() {
      var eb;
      bannerBox.textContent = '';
      if (blockedMsg) {
        eb = mk('div', 'notice warnbox st-err', 'تعذّرت قراءة جدول هذا الصف، ولذلك لا يمكن الجزم بأنه فارغ: قد يوجد جدول لكنه غير مقروء الآن. السبب: ' + blockedMsg + ' أخبر ممثل الصف ليراجعه.');
        eb.setAttribute('role', 'alert'); bannerBox.appendChild(eb);
      } else if (!persistent) bannerBox.appendChild(mk('div', 'notice warnbox', 'التخزين الدائم غير متاح في هذا المتصفح، لذلك ما تراه مؤقت في ذاكرة هذه الصفحة وقد لا يعكس كل ما أضافه الممثل.'));
      drawNav(); drawBody(); drawCtrl();
    }
    load(); draw();
    stCtl = {
      cid: cid,
      // بعد تغيّر التخزين أو الصف أو اليوم أو عودة التبويب: يقرأ من المخزن نفسه ويعيد الرسم فقط إن تغيّر شيء
      check: function () {
        var before = sig;
        if (activeId() !== cid) { renderPage(state.view); return; }
        load();
        if (sig !== before) draw();
      }
    };
  }

  // تحديث القائمة إذا تغيّر التخزين من تبويب آخر في المتصفح نفسه
  window.addEventListener('storage', function (e) {
    if (e.key === null || e.key === CLASSES_KEY) { loadClasses(); migrateAllRosters(); loadRoster(); renderClassUI(); refreshView(); }
    else if (e.key && e.key.indexOf('marsa.academic.dailyLessons.') === 0) { if (state.view === 'r-lessons' && lessonsCtl) lessonsCtl.reload(); else if (state.view === 'archive' && stCtl) stCtl.check(); }
    else if (e.key && e.key.indexOf('marsa.academic.preparations.') === 0) { if (state.view === 'r-prep' && prepsCtl) prepsCtl.reload(); else if ((state.view === 'prep' || state.view === 'archive') && stCtl) stCtl.check(); }
    else if (e.key && e.key.indexOf('marsa.academic.attendance.') === 0) { if (state.view === 'attendance' && attCtl) attCtl.reload(); }
    else if (e.key && e.key.indexOf('marsa.academic.grades.') === 0) { if (state.view === 'r-grades' && grCtl) grCtl.reload(); }
    else if (e.key && e.key.indexOf('marsa.academic.payments.') === 0) { if (state.view === 'payments' && payCtl) payCtl.reload(); }
    else if (e.key && e.key.indexOf('marsa.academic.exams.') === 0) { if (state.view === 'r-exams' && examsCtl) examsCtl.reload(); else if ((state.view === 'exams' || state.view === 'archive') && stCtl) stCtl.check(); }
    else if (e.key && (e.key.indexOf('marsa.academic.schedule.') === 0 || e.key.indexOf(SCHED_DAYS_PREFIX) === 0)) { if (state.view === 'r-schedule' && scheduleCtl) scheduleCtl.reload(); else if (state.view === 'schedule' && stCtl) stCtl.check(); }
    else if (e.key === curRosterKey) { loadRoster(); refreshView(); }
  });

  // تغيّر اليوم أثناء بقاء صفحة التحاضير مفتوحة (منتصف الليل) أو عند العودة للتبويب: أعد تجميع اليوم/باجر
  // ===== 03.10: لوحة اليوم وملخص لوحة الممثل من البيانات الفعلية =====
  // القراءة فقط من MarsaAcademicStore بـ classId الصف النشط (لا نسخ ولا مخزن ثانٍ ولا كتابة). الحساب كله في MarsaDashboardModel.
  // تُرسم أجسام البطاقات فقط (#dash-*) وتبقى الأزرار والمستمعون كما هم: لا تكرار للأحداث ولا لنسخ السجلات.
  // لا عدّاد يظهر إلا لمجموعة قُرئت بنجاح وفيها سجل؛ المجموعة التالفة تُعرض رسالة خطأ بدل صفر.
  var DASH_SRC = [['lessons', 'dailyLessons'], ['schedule', 'schedule'], ['preps', 'preparations'], ['exams', 'exams']];
  var dashSig = null, repSumSig = null;
  function dashReady() {
    return !!(window.MarsaAcademicStore && window.MarsaDashboardModel && window.MarsaLessonsModel && window.MarsaScheduleModel && window.MarsaPrepsModel && window.MarsaExamsModel);
  }
  function dashModels() { return { lessons: window.MarsaLessonsModel, schedule: window.MarsaScheduleModel, preps: window.MarsaPrepsModel, exams: window.MarsaExamsModel }; }
  function dashInput() {
    var st = window.MarsaAcademicStore, cid = activeId(), inp = { classId: cid, today: st.toLocalDate(), dayKey: window.MarsaScheduleModel.dayKeyOfDate(new Date()) };
    DASH_SRC.forEach(function (p) {
      var r = st.readCollection(p[1], cid);
      inp[p[0]] = r.ok ? { ok: true, records: r.records } : { ok: false, records: [], error: r.error || 'تعذّرت القراءة.' };
    });
    return inp;
  }
  function dashSignature() { return dashReady() && activeClass() ? window.MarsaDashboardModel.signature(dashInput()) + '|' + activeList().length + '|' + archivedList().length : 'none'; }
  // 4.06: عدّادات الحضور والدرجات والمدفوعات تُقرأ فقط داخل ملخص ممثل الصف (repSummary) ولا تدخل dashInput ولا لوحة وضع الطالب.
  // كل عدّاد = عدد سجلات فعلية للصف النشط مقروءة من MarsaAcademicStore (attendance وgrades وpayments)؛ لا مبالغ ولا أسماء ولا درجات.
  var REP_SRC = ['attendance', 'grades', 'payments'];
  function repInput() {
    var st = window.MarsaAcademicStore, cid = activeId(), inp = { classId: cid, today: st.toLocalDate() };
    REP_SRC.forEach(function (t) { var r = st.readCollection(t, cid); inp[t] = r.ok ? { ok: true, records: r.records } : { ok: false, records: [], error: r.error || 'تعذّرت القراءة.' }; });
    return inp;
  }
  function repSummarySignature() { return dashSignature() + '|' + (dashReady() && activeClass() ? window.MarsaDashboardModel.signatureRep(repInput()) : ''); }
  function dEmpty(title, text) { var p = mk('p', 'empty'); p.appendChild(mk('strong', null, title)); p.appendChild(document.createTextNode(text)); return p; }
  function dErr(label, msg) { return mk('div', 'notice warnbox', 'تعذّرت قراءة ' + label + ': ' + msg); }
  function dTitle(model, r) { var t = model.field(r, 'title'); return t.trim() ? t : '(بلا عنوان)'; }
  function dSubj(model, r) { var t = model.field(r, 'subject'); return t.trim() ? t : '(بلا مادة)'; }
  function putBody(id, nodes) { var el = document.getElementById(id); if (!el) return; el.textContent = ''; nodes.forEach(function (n) { el.appendChild(n); }); }

  function renderHome(force) {
    var kp = document.getElementById('dash-kpis'), ids = ['dash-day', 'dash-sched', 'dash-exam', 'dash-prep'], S, inp, sig, M, X, L, SC, P, E, today, nodes, ul, li, i, n;
    if (!document.getElementById('dash-day')) return;
    if (!activeClass()) {
      if (!force && dashSig === 'none') return;
      dashSig = 'none'; if (kp) { kp.textContent = ''; kp.hidden = true; }
      ids.forEach(function (id) { putBody(id, [dEmpty('لا يوجد صف نشط', 'يختار ممثل الصف الصف النشط من «إدارة الصفوف» في وضع ممثل الصف، ثم تظهر هنا بياناته.')]); });
      return;
    }
    if (!dashReady()) {
      dashSig = null; if (kp) { kp.textContent = ''; kp.hidden = true; }
      ids.forEach(function (id) { putBody(id, [mk('div', 'notice warnbox', 'تعذّر تحميل ملفات اللوحة (js/academic-store.js و js/dashboard-model.js و ملفات النماذج). تأكد أن المجلد كاملاً ثم أعد التحميل. لا يعني هذا أن البيانات فارغة.')]); });
      return;
    }
    inp = dashInput(); sig = window.MarsaDashboardModel.signature(inp);
    if (!force && sig === dashSig) return;
    dashSig = sig; M = dashModels(); S = window.MarsaDashboardModel.summarize(inp, M); today = inp.today;
    X = M.exams; L = M.lessons; SC = M.schedule; P = M.preps; E = M.exams;

    // العدادات
    if (kp) {
      kp.textContent = '';
      S.counters.forEach(function (c) { li = mk('li'); li.setAttribute('data-k', c.key); li.appendChild(mk('b', null, String(c.value))); li.appendChild(mk('span', null, c.label)); kp.appendChild(li); });
      kp.hidden = !S.counters.length;
    }

    // ملخص ما أُخذ اليوم
    nodes = [mk('p', 'muted dd-date', X.formatDate(today))];
    if (S.lessons.status === 'error') nodes.push(dErr('سجل الدروس', S.lessons.error));
    else if (S.lessons.todayCount) {
      nodes.push(mk('p', 'stat', 'أُخذ اليوم: ' + plural(S.lessons.todayCount, ['درس واحد', 'درسان', 'دروس', 'درساً'])));
      ul = mk('ul', 'mini');
      S.lessons.shown.forEach(function (r) { li = mk('li'); li.setAttribute('data-record-id', L.field(r, 'recordId')); li.appendChild(mk('b', null, dTitle(L, r))); li.appendChild(mk('span', 'tag', dSubj(L, r))); ul.appendChild(li); });
      nodes.push(ul);
      if (S.lessons.more > 0) nodes.push(mk('p', 'muted', 'و' + plural(S.lessons.more, ['درس آخر', 'درسين آخرين', 'دروس أخرى', 'درساً آخر']) + '.'));
    } else if (S.lessons.total) {
      nodes.push(dEmpty('لم يُسجَّل درس اليوم بعد', S.lessons.lastBefore ? 'آخر درس مسجّل قبل اليوم: ' + dTitle(L, S.lessons.lastBefore) + ' (' + dSubj(L, S.lessons.lastBefore) + ') — ' + L.formatDate(L.field(S.lessons.lastBefore, 'date')) + '.' : 'لا يوجد درس مسجّل بتاريخ اليوم.'));
    } else nodes.push(dEmpty('لم يُسجَّل أي درس بعد', 'يسجّل ممثل الصف ما شُرح في الصف من «ما أُخذ اليوم»، وسيظهر هنا ملخص اليوم.'));
    putBody('dash-day', nodes);

    // جدول حصص اليوم
    nodes = [];
    if (S.schedule.status === 'error') nodes.push(dErr('الجدول الدراسي', S.schedule.error));
    else if (!S.schedule.total) nodes.push(dEmpty('لا يوجد جدول بعد', 'لم يضف ممثل الصف حصصاً إلى الجدول الدراسي.'));
    else if (!S.schedule.todayCount) nodes.push(dEmpty('لا حصص ليوم ' + SC.dayLabel(S.schedule.dayKey), 'ليس في الجدول حصص مسجّلة لهذا اليوم. افتح الجدول لعرض بقية الأيام.'));
    else {
      nodes.push(mk('p', 'muted dd-date', 'حصص يوم ' + SC.dayLabel(S.schedule.dayKey)));
      ul = mk('ul', 'mini sched');
      S.schedule.shown.forEach(function (r) {
        var pn = SC.periodOf(r), tr = SC.timeRange(r);
        li = mk('li'); li.setAttribute('data-record-id', SC.field(r, 'recordId'));
        if (pn) li.appendChild(mk('span', 'pn', 'حصة ' + pn)); // رقم الحصة كما أدخله الممثل فقط
        n = mk('span', 'pt'); n.appendChild(mk('b', null, SC.field(r, 'subject').trim() || '(بلا مادة)'));
        if (tr) n.appendChild(mk('small', 'muted', tr));
        li.appendChild(n); ul.appendChild(li);
      });
      nodes.push(ul);
      if (S.schedule.more > 0) nodes.push(mk('p', 'muted', 'و' + plural(S.schedule.more, ['حصة أخرى', 'حصتين أخريين', 'حصص أخرى', 'حصة أخرى']) + '.'));
    }
    putBody('dash-sched', nodes);

    // أقرب امتحان قادم
    nodes = [];
    if (S.exams.status === 'error') nodes.push(dErr('الامتحانات', S.exams.error));
    else if (!S.exams.total) nodes.push(dEmpty('لا توجد امتحانات مضافة', 'حين يضيف ممثل الصف امتحاناً سيظهر هنا أقربها موعداً.'));
    else if (!S.exams.next) nodes.push(dEmpty('لا يوجد امتحان قادم', 'لا امتحان مجدول بتاريخ اليوم أو بعده. السابقة والمنتهية تجدها في «الامتحانات».'));
    else {
      var ex = S.exams.next, rel = E.relativeLabel(E.field(ex, 'examDate'), today), tp = E.field(ex, 'topics');
      nodes.push(mk('p', 'd-title', dTitle(E, ex)));
      n = mk('p', 'lc-meta'); n.appendChild(mk('span', 'tag', dSubj(E, ex))); if (rel) n.appendChild(mk('span', 'tag rel' + (rel === 'اليوم' ? ' on' : ''), rel));
      nodes.push(n);
      nodes.push(mk('p', 'muted', E.formatDate(E.field(ex, 'examDate'))));
      if (tp.trim()) nodes.push(mk('p', 'clamp', tp));
      if (S.exams.upcomingCount > 1) nodes.push(mk('p', 'muted', 'وبعده ' + plural(S.exams.upcomingCount - 1, ['امتحان واحد', 'امتحانان', 'امتحانات', 'امتحاناً']) + ' قادمة.'));
    }
    putBody('dash-exam', nodes);

    // آخر تحضير (الأحدث إضافةً) + عدد التحاضير القادمة
    nodes = [];
    if (S.preps.status === 'error') nodes.push(dErr('التحاضير', S.preps.error));
    else if (!S.preps.total) nodes.push(dEmpty('لم يُضف أي تحضير بعد', 'يضيف ممثل الصف التحاضير من «التحاضير»، وسيظهر هنا آخر ما أُضيف.'));
    else {
      var pr = S.preps.latest, pd = P.field(pr, 'date'), prel = pd === today ? 'اليوم' : pd === S.preps.tomorrow ? 'باجر' : (P.isLocalDate(pd) && pd < today ? 'مضى تاريخه' : '');
      nodes.push(mk('small', 'muted', 'آخر تحضير أُضيف'));
      nodes.push(mk('p', 'd-title', dTitle(P, pr)));
      n = mk('p', 'lc-meta'); n.appendChild(mk('span', 'tag', dSubj(P, pr))); if (prel) n.appendChild(mk('span', 'tag rel' + (prel === 'اليوم' ? ' on' : ''), prel));
      nodes.push(n);
      nodes.push(mk('p', 'muted', P.isLocalDate(pd) ? P.formatDate(pd) : 'بلا تاريخ صالح'));
      nodes.push(mk('p', 'muted', 'التحاضير القادمة (اليوم فما بعده): ' + S.preps.upcomingCount));
    }
    putBody('dash-prep', nodes);
  }

  // ملخص لوحة ممثل الصف: أعداد السجلات الموجودة فعلاً (بلا أرقام لأقسام لم تُنفَّذ كالحضور والمدفوعات والإعلانات)
  function repSummary() {
    var sum = mk('section', 'part'), nA = activeList().length, nD = archivedList().length, S, rows, ul, li, M, inp, R, rinp;
    sum.appendChild(mk('h2', null, 'ملخص الصف'));
    sum.appendChild(mk('p', 'stat', 'الصف النشط: ' + (activeClass() ? classLabel(activeClass()) : 'لا يوجد صف نشط')));
    sum.appendChild(mk('p', nA ? 'stat' : 'empty', nA ? 'الطلاب الفعّالون: ' + nA + (nD ? '، والمحذوفون: ' + nD : '') + '.' : 'لا يوجد طلاب بعد. ابدأ من «إدارة الطلاب».'));
    repSumSig = null;
    if (!activeClass()) return sum;
    if (!dashReady()) { sum.appendChild(mk('div', 'notice warnbox', 'تعذّر تحميل ملفات الملخص (js/dashboard-model.js وملفات النماذج). تأكد أن المجلد كاملاً ثم أعد التحميل.')); return sum; }
    M = dashModels(); inp = dashInput(); rinp = repInput(); S = window.MarsaDashboardModel.summarize(inp, M);
    repSumSig = repSummarySignature();
    rows = [
      ['ما أُخذ اليوم', S.lessons, 'سجلات الدروس', function (x) { return x.total + ' (منها اليوم: ' + x.todayCount + ')'; }, 'لا توجد سجلات دروس بعد. ابدأ من «ما أُخذ اليوم».'],
      ['الجدول الدراسي', S.schedule, 'الجدول', function (x) { return x.total + ' (حصص اليوم: ' + x.todayCount + ')'; }, 'لا حصص في الجدول بعد. ابدأ من «الجدول الدراسي الأسبوعي».'],
      ['التحاضير', S.preps, 'التحاضير', function (x) { return x.total + ' (القادمة: ' + x.upcomingCount + ')'; }, 'لا تحاضير بعد. ابدأ من «التحاضير».'],
      ['الامتحانات', S.exams, 'الامتحانات', function (x) { return x.total + ' (القادمة: ' + x.upcomingCount + ')'; }, 'لا امتحانات بعد. ابدأ من «إدارة الامتحانات».']
    ];
    ul = mk('ul', 'sumlist');
    rows.forEach(function (r) {
      li = mk('li'); li.appendChild(mk('b', null, r[0]));
      if (r[1].status === 'error') li.appendChild(mk('span', 'warn', 'تعذّرت قراءتها: ' + r[1].error));
      else if (!r[1].total) li.appendChild(mk('span', 'muted', r[4]));
      else li.appendChild(mk('span', 'sv', r[3](r[1])));
      ul.appendChild(li);
    });
    // 4.06: حضور/درجات/مدفوعات (عدد سجلات فقط)؛ لا تظهر هذه الصفوف إلا هنا (وضع ممثل الصف)
    R = window.MarsaDashboardModel.summarizeRep(rinp, window.MarsaLessonsModel);
    [['الحضور', R.attendance, function (x) { return x.total + ' سجل (اليوم: ' + x.todayCount + (x.absentToday ? '، غياب: ' + x.absentToday : '') + ')'; }, 'لم يُسجَّل حضور بعد. ابدأ من «الحضور».'],
     ['الدرجات', R.grades, function (x) { return x.total + ' درجة في ' + x.assessmentCount + ' تقييم (سُجّل اليوم: ' + x.todayCount + ')'; }, 'لا درجات بعد. ابدأ من «الدرجات».'],
     ['المدفوعات', R.payments, function (x) { return x.total + ' وصل (اليوم: ' + x.todayCount + ')'; }, 'لا وصولات بعد. ابدأ من «المدفوعات».']
    ].forEach(function (r) {
      li = mk('li'); li.setAttribute('data-sum', r[0]); li.appendChild(mk('b', null, r[0]));
      if (r[1].status === 'error') li.appendChild(mk('span', 'warn', 'تعذّرت قراءتها: ' + r[1].error));
      else if (!r[1].total) li.appendChild(mk('span', 'muted', r[3]));
      else li.appendChild(mk('span', 'sv', r[2](r[1])));
      ul.appendChild(li);
    });
    sum.appendChild(ul);
    sum.appendChild(mk('p', 'muted', 'هذه أعداد سجلات فقط. وضع ممثل الصف تجريبي وليس حماية أمنية حقيقية حتى مرحلة المصادقة.'));
    return sum;
  }

  function prepDayCheck() {
    if (state.view === 'r-prep' && prepsCtl) prepsCtl.dayCheck();
    if (state.view === 'attendance' && attCtl) attCtl.dayCheck();
    if (state.view === 'r-grades' && grCtl) grCtl.dayCheck();
    if (state.view === 'payments' && payCtl) payCtl.dayCheck();
    if (state.view === 'r-exams' && examsCtl) examsCtl.dayCheck(); // الامتحانات: اليوم يحدد «قادم» أو «سابق»
    if ((state.view === 'prep' || state.view === 'archive' || state.view === 'schedule' || state.view === 'exams') && stCtl) stCtl.check(); // عرض الطالب: عبور منتصف الليل أو عودة للتبويب
    if (state.view === 'home') renderHome(); // لا يُعاد الرسم إلا إن تغيّر التوقيع (بيانات/يوم/صف)
    if (state.view === 'dash' && repSumSig !== null && repSummarySignature() !== repSumSig) { renderPage('dash'); renderNav(); }
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden) prepDayCheck(); });
  window.addEventListener('focus', prepDayCheck);
  window.addEventListener('pageshow', prepDayCheck); // رجوع من ذاكرة الصفحة (bfcache)
  window.addEventListener('storage', prepDayCheck); // تعديل من تبويب آخر لنفس المتصفح
  setInterval(prepDayCheck, 60000);

  segBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      var m = b.getAttribute('data-m'), prev = state.mode;
      setMode(m);
      // انتقال بصري فقط عند تبديل فعلي اختاره المستخدم (لا عند التحميل ولا إعادة الرسم ولا الضغط على الوضع الحالي)
      if (state.mode !== prev) playModeFx(state.mode);
    });
  });
  document.querySelectorAll('[data-go]').forEach(function (b) { b.addEventListener('click', function () { go(b.getAttribute('data-go')); }); });

  document.getElementById('skip-main').addEventListener('click', function (e) { e.preventDefault(); var t = document.getElementById(state.view === 'home' ? 'welcome' : 'page-title'); if (t) t.focus(); });
  skip.addEventListener('click', closeIntro);
  document.getElementById('replay').addEventListener('click', openIntro);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !intro.hidden) closeIntro(); });
  window.marsaReplayIntro = openIntro; // لاستدعائها من الإعدادات لاحقاً

  var topEl = document.getElementById('top');
  function syncHead() { document.documentElement.style.setProperty('--hh', topEl.offsetHeight + 'px'); }
  window.addEventListener('resize', syncHead); window.addEventListener('load', syncHead);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(syncHead);
  initUI();
  syncHead();
  openIntro(); // مرة واحدة عند التحميل؛ التنقل وإعادة الرسم لا يستدعيانها
})();
