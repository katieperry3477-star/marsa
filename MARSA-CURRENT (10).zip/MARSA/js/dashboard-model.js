/* MARSA — نموذج لوحة اليوم (المرحلة 03.10)
 * دوال نقية فقط: تأخذ ما قُرئ من التخزين وتحسب الملخصات والعدادات. لا تقرأ ولا تكتب أي تخزين ولا تلمس DOM.
 * لا أرقام ولا نصوص ثابتة عن بيانات: كل ما يخرج مشتق من السجلات الممرَّرة.
 * الاستعمال: summarize({ today, dayKey, lessons, schedule, preps, exams }, models)
 *   كل مجموعة: { ok: true|false, records: [...], error: 'نص' }  (ok=false → status 'error' ولا عدّاد لها)
 *   models: { lessons, schedule, preps, exams } النماذج الموجودة أصلاً (MarsaLessonsModel وغيرها). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaDashboardModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var MAX_SHOWN = { lessons: 3, schedule: 6 };

  function list(c) { return c && c.ok && Array.isArray(c.records) ? c.records : []; }
  function base(c) {
    if (!c || c.ok !== true) return { status: 'error', error: (c && c.error) || 'تعذّرت قراءة البيانات.', total: 0 };
    return { status: 'ok', error: '', total: list(c).length };
  }
  function str(r, k) { return r && typeof r[k] === 'string' ? r[k] : ''; }
  function valid(M, d) { return typeof d === 'string' && M.isLocalDate(d); }

  // الأحدث إضافةً: createdAt ثم updatedAt ثم recordId (ترتيب ثابت؛ لا يعتمد على موضع السجل)
  function newestAdded(records) {
    return records.slice().sort(function (a, b) {
      var ca = str(a, 'createdAt'), cb = str(b, 'createdAt'), ua, ub;
      if (ca !== cb) return ca < cb ? 1 : -1;
      ua = str(a, 'updatedAt'); ub = str(b, 'updatedAt');
      if (ua !== ub) return ua < ub ? 1 : -1;
      return str(a, 'recordId') < str(b, 'recordId') ? 1 : str(a, 'recordId') > str(b, 'recordId') ? -1 : 0;
    })[0] || null;
  }

  function summarize(input, M) {
    var today = input.today, out = {}, recs, up, parts, i, c;

    // ما أُخذ اليوم (سجل الدروس)
    out.lessons = base(input.lessons);
    recs = list(input.lessons);
    out.lessons.todayList = M.lessons.sortRecords(recs.filter(function (r) { return str(r, 'date') === today; }));
    out.lessons.todayCount = out.lessons.todayList.length;
    out.lessons.lastBefore = M.lessons.sortRecords(recs.filter(function (r) { var d = str(r, 'date'); return valid(M.lessons, d) && d < today; }))[0] || null;
    out.lessons.shown = out.lessons.todayList.slice(0, MAX_SHOWN.lessons);
    out.lessons.more = out.lessons.todayCount - out.lessons.shown.length;

    // جدول حصص اليوم (حسب مفتاح اليوم الأسبوعي؛ سجلات اليوم المجهول لا تُحسب لأي يوم)
    out.schedule = base(input.schedule);
    recs = list(input.schedule);
    out.schedule.dayKey = input.dayKey || null;
    out.schedule.todayList = input.dayKey ? M.schedule.sortDay(recs.filter(function (r) { return str(r, 'day') === input.dayKey; })) : [];
    out.schedule.todayCount = out.schedule.todayList.length;
    out.schedule.shown = out.schedule.todayList.slice(0, MAX_SHOWN.schedule);
    out.schedule.more = out.schedule.todayCount - out.schedule.shown.length;

    // التحاضير: «قادم» = تاريخ صالح اليوم أو بعده. «آخر تحضير» = الأحدث إضافةً (لا الأقرب موعداً).
    out.preps = base(input.preps);
    recs = list(input.preps);
    up = recs.filter(function (r) { var d = str(r, 'date'); return valid(M.preps, d) && d >= today; });
    out.preps.upcomingCount = up.length;
    out.preps.latest = newestAdded(recs);
    out.preps.tomorrow = M.preps.addDays(today, 1);

    // الامتحانات: التقسيم نفسه المستعمل في صفحتي الممثل والطالب (partition)
    out.exams = base(input.exams);
    recs = list(input.exams);
    parts = M.exams.partition(recs, today);
    out.exams.upcomingCount = parts.upcoming.length;
    out.exams.next = parts.upcoming[0] || null;

    // العدادات: لا يظهر عدّاد إلا إذا قُرئت مجموعته بنجاح وكان فيها سجل واحد على الأقل
    // (مجموعة فارغة أو غير مقروءة لا تُنتج رقماً يوحي باكتمال القسم)
    out.counters = [];
    c = out.lessons; if (c.status === 'ok' && c.total > 0) out.counters.push({ key: 'lessons', label: 'دروس أُخذت اليوم', value: c.todayCount });
    c = out.schedule; if (c.status === 'ok' && c.total > 0) out.counters.push({ key: 'periods', label: 'حصص اليوم', value: c.todayCount });
    c = out.preps; if (c.status === 'ok' && c.total > 0) out.counters.push({ key: 'preps', label: 'تحاضير قادمة', value: c.upcomingCount });
    c = out.exams; if (c.status === 'ok' && c.total > 0) out.counters.push({ key: 'exams', label: 'امتحانات قادمة', value: c.upcomingCount });
    for (i = 0; i < out.counters.length; i++) out.counters[i].value = Math.max(0, out.counters[i].value | 0);
    return out;
  }

  // 4.06 — عدّادات ملخص ممثل الصف فقط (الحضور والدرجات والمدفوعات). دالة نقية مشتقة من السجلات الممرَّرة.
  // لا تدخل لوحة اليوم العامة (وضع الطالب)، ولا تُخرج اسماً ولا معرّف طالب ولا درجة ولا مبلغاً: أعداد سجلات فقط.
  //  - attendance.todayCount: سجلات حضور تاريخها اليوم؛ absentToday/lateToday منها بحالتي absent وlate
  //  - grades.todayCount: تقييمات (سجلات درجات) تاريخها اليوم؛ assessmentCount: عدد التقييمات المميّزة (المادة + العنوان + التاريخ)
  //  - payments.todayCount: وصولات تاريخها اليوم (عدد فقط؛ لا مجموع ولا مبلغ)
  // مجموعة غير مقروءة → status 'error' ولا رقم لها. التاريخ غير الصالح لا يُحسب لأي يوم.
  function summarizeRep(input, M) {
    var today = input && input.today, out = {};
    function isToday(r) { var d = str(r, 'date'); return d === today && typeof today === 'string' && (!M || !M.isLocalDate || M.isLocalDate(d)); }
    ['attendance', 'grades', 'payments'].forEach(function (k) {
      var c = input && input[k], recs = list(c), todays;
      out[k] = base(c);
      todays = recs.filter(isToday);
      out[k].todayCount = todays.length;
      if (k === 'attendance') {
        out[k].absentToday = todays.filter(function (r) { return str(r, 'status') === 'absent'; }).length;
        out[k].lateToday = todays.filter(function (r) { return str(r, 'status') === 'late'; }).length;
      }
      if (k === 'grades') {
        var seen = {};
        recs.forEach(function (r) { seen[str(r, 'subject') + '\u0001' + str(r, 'title') + '\u0001' + str(r, 'date')] = 1; });
        out[k].assessmentCount = Object.keys(seen).length;
      }
    });
    return out;
  }

  // توقيع نصي للمدخلات: يستعمله التطبيق ليعيد الرسم فقط عند تغيّر البيانات أو اليوم أو الصف
  function signature(input) {
    return JSON.stringify([input.classId || '', input.today || '', input.dayKey || '',
      ['lessons', 'schedule', 'preps', 'exams'].map(function (k) { var c = input[k]; return c && c.ok ? [1, c.records] : [0, c && c.error || '']; })]);
  }

  function signatureRep(input) {
    return JSON.stringify([input.classId || '', input.today || '',
      ['attendance', 'grades', 'payments'].map(function (k) { var c = input[k]; return c && c.ok ? [1, c.records] : [0, c && c.error || '']; })]);
  }

  return { summarize: summarize, summarizeRep: summarizeRep, signature: signature, signatureRep: signatureRep, MAX_SHOWN: MAX_SHOWN };
});
