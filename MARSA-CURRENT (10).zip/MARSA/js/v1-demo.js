/* MARSA V1 — نموذج البيانات التجريبية الاصطناعية لشاشات «اليوم» و«باچر» و«الامتحان القريب» (01.03).
 * دوال نقية بلا تخزين ولا DOM ولا شبكة: البناء، التحقق، حساب الأيام، تجميع الامتحانات، وصياغة النصوص العربية.
 * كل ما هنا اصطناعي لتجربة الشاشات فقط (جدول أسبوعي وامتحانات وهمية). لا يحمل أي بيانات حقيقية، ولا يدخل في كود المشاركة MARSA1.
 * التخزين في v1-store.js تحت المفتاح المنفصل marsa.v1.demo. أسبوع الدراسة المفترض: الأحد–الخميس. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaV1Demo = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var SCHEMA = 1;
  var ID_RE = /^[A-Za-z0-9_-]{6,64}$/, YMD_RE = /^(\d{4})-(\d{2})-(\d{2})$/, TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
  var LIMITS = { exams: 40, lessonsPerDay: 12, short: 80, long: 400 };
  var DAY_MS = 86400000;

  // ===== تواريخ (ymd = YYYY-MM-DD محلي؛ الحساب بـUTC فلا يتأثر بالتوقيت الصيفي) =====
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function parse(ymd) {
    var m = YMD_RE.exec(typeof ymd === 'string' ? ymd : ''), y, mo, d, t, dt;
    if (!m) return null;
    y = +m[1]; mo = +m[2]; d = +m[3]; t = Date.UTC(y, mo - 1, d); dt = new Date(t);
    if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return null;
    return t;
  }
  function isYmd(s) { return parse(s) !== null; }
  function weekday(ymd) { var t = parse(ymd); return t === null ? -1 : new Date(t).getUTCDay(); } // 0 = الأحد … 6 = السبت
  function shift(ymd, n) {
    var t = parse(ymd), d;
    if (t === null) return ymd;
    d = new Date(t + n * DAY_MS);
    return d.getUTCFullYear() + '-' + p2(d.getUTCMonth() + 1) + '-' + p2(d.getUTCDate());
  }
  function daysBetween(a, b) { var ta = parse(a), tb = parse(b); return ta === null || tb === null ? NaN : Math.round((tb - ta) / DAY_MS); }
  function isSchoolDay(ymd) { var w = weekday(ymd); return w >= 0 && w <= 4; }
  function snapForward(ymd) { var i = 0; if (parse(ymd) === null) return ymd; while (!isSchoolDay(ymd) && i++ < 7) ymd = shift(ymd, 1); return ymd; }
  function snapBack(ymd) { var i = 0; if (parse(ymd) === null) return ymd; while (!isSchoolDay(ymd) && i++ < 7) ymd = shift(ymd, -1); return ymd; }

  // ===== بيانات اصطناعية =====
  var SLOTS = [['08:00', '08:45'], ['08:50', '09:35'], ['09:40', '10:25'], ['10:45', '11:30'], ['11:35', '12:20']];
  // أسماء مواد محايدة عمداً: المادة في مَرسى نص حر ولا تُفرض مواد في الكود (يفحصه isolation-static)، والاسم هنا يُظهر أن البيانات اصطناعية
  var PLAN = [ // الأحد … الخميس
    ['مادة تجريبية أ', 'مادة تجريبية ب', 'مادة تجريبية ج', 'مادة تجريبية د', 'مادة تجريبية هـ'],
    ['مادة تجريبية ب', 'مادة تجريبية و', 'مادة تجريبية أ', 'مادة تجريبية ج', 'مادة تجريبية د'],
    ['مادة تجريبية ج', 'مادة تجريبية هـ', 'مادة تجريبية ب', 'مادة تجريبية أ', 'مادة تجريبية و'],
    ['مادة تجريبية د', 'مادة تجريبية ب', 'مادة تجريبية و', 'مادة تجريبية ج', 'مادة تجريبية هـ'],
    ['مادة تجريبية و', 'مادة تجريبية أ', 'مادة تجريبية د', 'مادة تجريبية ب', 'مادة تجريبية ج']
  ];
  var EXAM_PLAN = [ // off = بعد كم يوماً من تاريخ التحميل (سالب = منتهٍ)
    { off: 3, subject: 'مادة تجريبية أ', time: '09:00', topics: 'موضوع تجريبي: الفصل الأول، والتمارين المرافقة له.', notes: 'ملاحظة اصطناعية: أحضر أدواتك. الامتحان تجريبي.' },
    { off: 9, subject: 'مادة تجريبية ب', time: '10:30', topics: 'موضوع تجريبي: الفصل الثاني.', notes: 'ملاحظة اصطناعية للتجربة فقط.' },
    { off: 16, subject: 'مادة تجريبية ج', time: '09:00', topics: 'موضوع تجريبي: مراجعة عامة.', notes: '' },
    { off: -6, subject: 'مادة تجريبية د', time: '09:00', topics: 'موضوع تجريبي: الفصل الثالث.', notes: 'امتحان منتهٍ (بيانات تجريبية).' },
    { off: -13, subject: 'مادة تجريبية هـ', time: '11:00', topics: 'موضوع تجريبي: الفصل الرابع.', notes: '' }
  ];

  function build(today) {
    var base = isYmd(today) ? today : '2026-01-01', timetable = [], d, s, exams = [], i, e, date;
    for (d = 0; d < 7; d++) {
      timetable.push([]);
      if (d <= 4) for (s = 0; s < SLOTS.length; s++) timetable[d].push({ start: SLOTS[s][0], end: SLOTS[s][1], subject: PLAN[d][s] });
    }
    for (i = 0; i < EXAM_PLAN.length; i++) {
      e = EXAM_PLAN[i];
      date = e.off >= 0 ? snapForward(shift(base, e.off)) : snapBack(shift(base, e.off));
      exams.push({ id: 'demo-exam-' + (i + 1), subject: e.subject, date: date, time: e.time, topics: e.topics, notes: e.notes });
    }
    return { schemaVersion: SCHEMA, synthetic: true, builtFor: base, timetable: timetable, exams: exams };
  }

  // ===== التحقق (صارم: كل ما يُقرأ من التخزين غير موثوق) =====
  function isPlain(o) { return !!o && typeof o === 'object' && !Array.isArray(o); }
  function okText(s, max, required) { return typeof s === 'string' && s.length <= max && (!required || s.trim().length > 0); }
  function validate(d) {
    var i, j, day, l, e, seen = {};
    if (!isPlain(d) || d.schemaVersion !== SCHEMA || d.synthetic !== true || !isYmd(d.builtFor)) return false;
    if (!Array.isArray(d.timetable) || d.timetable.length !== 7 || !Array.isArray(d.exams) || d.exams.length > LIMITS.exams) return false;
    for (i = 0; i < 7; i++) {
      day = d.timetable[i];
      if (!Array.isArray(day) || day.length > LIMITS.lessonsPerDay) return false;
      for (j = 0; j < day.length; j++) {
        l = day[j];
        if (!isPlain(l) || typeof l.start !== 'string' || !TIME_RE.test(l.start) || typeof l.end !== 'string' || !TIME_RE.test(l.end) || !okText(l.subject, LIMITS.short, true)) return false;
      }
    }
    for (i = 0; i < d.exams.length; i++) {
      e = d.exams[i];
      if (!isPlain(e) || typeof e.id !== 'string' || !ID_RE.test(e.id) || seen[e.id]) return false;
      seen[e.id] = 1;
      if (!okText(e.subject, LIMITS.short, true) || !isYmd(e.date) || typeof e.time !== 'string' || (e.time !== '' && !TIME_RE.test(e.time)) || !okText(e.topics, LIMITS.long) || !okText(e.notes, LIMITS.long)) return false;
    }
    return true;
  }

  // ===== استعلامات =====
  function byStart(a, b) { return a.start < b.start ? -1 : a.start > b.start ? 1 : 0; }
  function lessonsOn(data, ymd) { var w = weekday(ymd); return !data || w < 0 ? [] : (data.timetable[w] || []).slice().sort(byStart); }
  function hasTimetable(data) { var i; if (!data) return false; for (i = 0; i < data.timetable.length; i++) if (data.timetable[i].length) return true; return false; }
  function examGroups(data, today) {
    var list = data ? data.exams.slice() : [], up, fin;
    list.sort(function (a, b) { var x = a.date + ' ' + a.time, y = b.date + ' ' + b.time; return x < y ? -1 : x > y ? 1 : 0; });
    up = list.filter(function (e) { return e.date >= today; });
    fin = list.filter(function (e) { return e.date < today; }).reverse();
    return { nearest: up[0] || null, upcoming: up.slice(1), finished: fin };
  }
  function getExam(data, id) { var i; if (!data || typeof id !== 'string') return null; for (i = 0; i < data.exams.length; i++) if (data.exams[i].id === id) return data.exams[i]; return null; }

  // ===== صياغة عربية =====
  var NOUNS = { // [واحد، اثنان، 3–10، 11 فأكثر]
    lesson: ['درس واحد', 'درسان', 'دروس', 'درساً'],
    prep: ['تحضير واحد', 'تحضيران', 'تحضيرات', 'تحضيراً'],
    homework: ['واجب واحد', 'واجبان', 'واجبات', 'واجباً']
  };
  function countText(n, noun) {
    var f = NOUNS[noun];
    if (!f || !(n >= 1)) return '';
    if (n === 1) return f[0];
    if (n === 2) return f[1];
    return n + ' ' + (n <= 10 ? f[2] : f[3]);
  }
  function summaryText(c, emptyText) {
    var parts = [];
    if (c && c.lessons > 0) parts.push(countText(c.lessons, 'lesson'));
    if (c && c.preps > 0) parts.push(countText(c.preps, 'prep'));
    if (c && c.homework > 0) parts.push(countText(c.homework, 'homework'));
    return parts.length ? parts.join(' · ') : emptyText;
  }
  function daysLabel(n) {
    if (typeof n !== 'number' || !isFinite(n)) return '';
    if (n === 0) return 'اليوم';
    if (n === 1) return 'باچر';
    if (n === 2) return 'بعد يومين';
    if (n >= 3 && n <= 10) return 'بعد ' + n + ' أيام';
    if (n > 10) return 'بعد ' + n + ' يوماً';
    if (n === -1) return 'أمس';
    if (n === -2) return 'قبل يومين';
    if (n >= -10) return 'قبل ' + (-n) + ' أيام';
    return 'قبل ' + (-n) + ' يوماً';
  }
  function greeting(hour) { return typeof hour === 'number' && hour >= 12 ? 'مساء الخير' : 'صباح الخير'; }
  function shortDate(ymd) {
    var t = parse(ymd), parts, o = {}, i;
    if (t === null) return String(ymd || '');
    try {
      parts = new Intl.DateTimeFormat('ar-u-ca-gregory-nu-latn', { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'long' }).formatToParts(new Date(t));
      for (i = 0; i < parts.length; i++) o[parts[i].type] = parts[i].value;
      return [o.weekday, o.day, o.month].filter(Boolean).join(' ');
    } catch (e) { return ymd; }
  }

  return {
    SCHEMA: SCHEMA, LIMITS: LIMITS, build: build, validate: validate,
    weekday: weekday, shift: shift, daysBetween: daysBetween, isSchoolDay: isSchoolDay, isYmd: isYmd,
    lessonsOn: lessonsOn, hasTimetable: hasTimetable, examGroups: examGroups, getExam: getExam,
    countText: countText, summaryText: summaryText, daysLabel: daysLabel, greeting: greeting, shortDate: shortDate
  };
});
