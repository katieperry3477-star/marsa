/* MARSA V1 — غلاف التحقق من نص التحضير
 * يستعمل preps-model.js كما هو (الحقول المطلوبة والحدود والتاريخ والتنظيف)، ويضيف أمرين فقط:
 *  1) يحفظ رمز الربط U+200D داخل الرموز التعبيرية المركّبة (🏃‍♂️ 👨‍👩‍👧 ❤️‍🔥 🏳️‍🌈) لأن المنقّي القديم يحذفه فيفكّكها.
 *     أي U+200D خارج سياق الرموز التعبيرية يبقى محذوفاً كما في المنقّي القديم (وكذلك علامات الاتجاه ورموز التحكم).
 *  2) حقل «الصف أو الشعبة» (group) بحد 60 حرفاً.
 * الطريقة: يُستبدل U+200D الواقع بين رمزين تعبيريين بحرف مؤقت من المنطقة الخاصة (U+E000) قبل التحقق ويُعاد بعده،
 * وطوله وحدة واحدة مثل الأصل فلا يتغير عدّ الحروف. دوال نقية بلا DOM ولا تخزين. */
(function (root, factory) {
  'use strict';
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaV1Text = api;
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var GROUP_MAX = 60, MARK = '\uE000', ZWJ = '\u200D';
  var FIELDS = ['subject', 'title', 'date', 'content', 'pages', 'homework', 'notes'];
  // قبل الرابط: نهاية رمز خارج BMP (surrogate منخفض) أو محدد عرض الرمز FE0F أو رموز BMP الشائعة؛ بعده: بداية رمز خارج BMP أو رمز BMP
  var PRE = '[\\uDC00-\\uDFFF\\uFE0F\\u2190-\\u2BFF\\u00A9\\u00AE\\u203C\\u2049\\u2122\\u2139\\u3030\\u303D\\u3297\\u3299]';
  var POST = '(?=[\\uD800-\\uDBFF\\u2190-\\u2BFF])';
  var ZWJ_IN_EMOJI = new RegExp('(' + PRE + ')\\u200D' + POST, 'g');

  function getModel() {
    if (root && root.MarsaPrepsModel) return root.MarsaPrepsModel;
    if (typeof require === 'function') return require('./preps-model.js');
    throw new Error('preps-model.js غير محمَّل');
  }
  function protect(s) { return String(s == null ? '' : s).replace(/\uE000/g, '').replace(ZWJ_IN_EMOJI, '$1' + MARK); }
  function restore(s) { return typeof s === 'string' ? s.split(MARK).join(ZWJ) : s; }

  // يُرجع { ok, values, errors, firstError } مثل MarsaPrepsModel.validate مع values.group (إن وُجد)
  function validate(input) {
    var model = getModel(), prot = {}, i, k, r, g, first, errors, values;
    input = input || {};
    for (i = 0; i < FIELDS.length; i++) prot[FIELDS[i]] = protect(input[FIELDS[i]]);
    r = model.validate(prot);
    errors = r.errors; first = r.firstError; values = {};
    for (k in r.values) values[k] = restore(r.values[k]);
    g = restore(model.oneLine(protect(input.group)));
    if (g.length > GROUP_MAX) { errors.group = 'اسم الصف أو الشعبة أطول من ' + GROUP_MAX + ' حرفاً (طوله الآن ' + g.length + ').'; if (!first) first = 'group'; }
    if (g) values.group = g;
    return { ok: !first, values: values, errors: errors, firstError: first };
  }

  return { validate: validate, protect: protect, restore: restore, GROUP_MAX: GROUP_MAX };
});
