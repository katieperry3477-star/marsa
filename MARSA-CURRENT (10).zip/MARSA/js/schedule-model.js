/* MARSA — منطق «الجدول الدراسي الأسبوعي» (المرحلة 03.4)
 * دوال نقية بلا DOM ولا تخزين: تحقق، تنظيف، فرز الحصص، كشف التعارض، تنسيق الوقت، وقراءة إعداد أيام الأسبوع.
 * التخزين نفسه يمرّ حصراً عبر MarsaAcademicStore (النوع schedule).
 * الجدول يصف الموعد المخطَّط (يوم + حصة + وقت + مادة). أما ما شُرح فعلاً فله نوع مستقل (dailyLessons)، والتحضير له نوع مستقل (preparations). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaScheduleModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var LIMITS = { subject: 80, notes: 300 };
  var MAX_PERIOD = 30;
  // مفاتيح الأيام ثابتة (لا تُشتق من الاسم ولا من الترتيب الظاهر). الترتيب المعروض: السبت أولاً ثم الجمعة آخراً.
  var DAYS = [
    { key: 'sat', label: 'السبت', js: 6 }, { key: 'sun', label: 'الأحد', js: 0 }, { key: 'mon', label: 'الاثنين', js: 1 },
    { key: 'tue', label: 'الثلاثاء', js: 2 }, { key: 'wed', label: 'الأربعاء', js: 3 }, { key: 'thu', label: 'الخميس', js: 4 },
    { key: 'fri', label: 'الجمعة', js: 5 }
  ];
  // الأيام الظاهرة افتراضياً عند عدم وجود إعداد محفوظ: عرض فقط وليست بيانات ولا افتراضاً عن المدرسة، ويغيّرها الممثل.
  var DEFAULT_DAYS = ['sun', 'mon', 'tue', 'wed', 'thu'];
  var LABELS = { day: 'اليوم', period: 'رقم الحصة', startTime: 'وقت البداية', endTime: 'وقت النهاية', subject: 'المادة', notes: 'ملاحظة' };
  var ORDER = ['day', 'subject', 'period', 'startTime', 'endTime', 'notes'];
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
  var DAY_BY_KEY = {}, i0;
  for (i0 = 0; i0 < DAYS.length; i0++) DAY_BY_KEY[DAYS[i0].key] = DAYS[i0];

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  function multiLine(s) {
    return str(s).replace(/\r\n?|\u2028|\u2029/g, '\n').replace(CTRL, '').replace(INVIS, '')
      .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  function searchKey(s) {
    return oneLine(s).replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  // يحوّل الأرقام العربية الهندية والفارسية إلى لاتينية (لوحة مفاتيح عربية) ويزيل المحارف الخفية
  function digits(s) {
    return str(s).replace(INVIS, '').replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 0x660); })
      .replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 0x6F0); }).replace(/٫/g, '.').replace(/٬/g, ',').trim();
  }
  function isDay(k) { return typeof k === 'string' && Object.prototype.hasOwnProperty.call(DAY_BY_KEY, k); }
  function dayLabel(k) { return isDay(k) ? DAY_BY_KEY[k].label : 'يوم غير معروف'; }
  function dayKeyOfDate(d) { var j = d.getDay(), n; for (n = 0; n < DAYS.length; n++) if (DAYS[n].js === j) return DAYS[n].key; return null; }

  // وقت HH:MM → دقائق منذ منتصف الليل، أو null
  function toMin(t) { var m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(str(t)); return m ? +m[1] * 60 + +m[2] : null; }
  // يقبل H:MM وHH:MM وفاصلاً عربياً/نقطة ويعيد HH:MM أو ''
  function normTime(s) {
    var x = digits(s).replace(/[.۔：]/g, ':'), m = /^(\d{1,2}):(\d{2})$/.exec(x);
    if (!m) return '';
    x = (m[1].length === 1 ? '0' : '') + m[1] + ':' + m[2];
    return toMin(x) === null ? '' : x;
  }
  // عرض 12 ساعة بأرقام لاتينية: 08:05 → 8:05 ص، 13:30 → 1:30 م
  function formatTime(t) {
    var n = toMin(t), h, m;
    if (n === null) return '';
    h = Math.floor(n / 60); m = n % 60;
    return (h % 12 === 0 ? 12 : h % 12) + ':' + (m < 10 ? '0' : '') + m + ' ' + (h < 12 ? 'ص' : 'م');
  }
  function timeRange(r) {
    var s = formatTime(field(r, 'startTime')), e = formatTime(field(r, 'endTime'));
    if (s && e) return s + ' – ' + e;
    if (s) return 'من ' + s;
    return '';
  }

  // النتيجة: { ok, values, errors:{حقل:رسالة}, firstError }
  // المطلوب: اليوم والمادة. الباقي اختياري. الوقت: إن وُجدت النهاية وجبت البداية، والنهاية بعد البداية (لا حصة تعبر منتصف الليل).
  function validate(input) {
    var errors = {}, v = {}, i, first = null, p, sm, em;
    input = input || {};
    v.day = str(input.day).trim();
    v.subject = oneLine(input.subject);
    v.notes = multiLine(input.notes);
    p = digits(input.period);
    v.startTime = str(input.startTime).trim() === '' ? '' : normTime(input.startTime);
    v.endTime = str(input.endTime).trim() === '' ? '' : normTime(input.endTime);
    if (!v.day) errors.day = 'اختر اليوم.';
    else if (!isDay(v.day)) errors.day = 'اليوم غير صالح. اختر يوماً من القائمة.';
    if (!v.subject) errors.subject = 'اكتب اسم المادة. لا يمكن تركه فارغاً.';
    else if (v.subject.length > LIMITS.subject) errors.subject = 'اسم المادة أطول من ' + LIMITS.subject + ' حرفاً (طوله الآن ' + v.subject.length + '). اختصره ثم احفظ.';
    if (p === '') v.period = null;
    else if (!/^\d{1,3}$/.test(p) || +p < 1 || +p > MAX_PERIOD) { v.period = null; errors.period = 'رقم الحصة يجب أن يكون عدداً صحيحاً من 1 إلى ' + MAX_PERIOD + '، أو اتركه فارغاً.'; }
    else v.period = +p;
    if (str(input.startTime).trim() !== '' && !v.startTime) errors.startTime = 'وقت البداية غير صالح. استخدم الصيغة HH:MM مثل 08:00 (من 00:00 إلى 23:59).';
    if (str(input.endTime).trim() !== '' && !v.endTime) errors.endTime = 'وقت النهاية غير صالح. استخدم الصيغة HH:MM مثل 08:45 (من 00:00 إلى 23:59).';
    if (!errors.startTime && !errors.endTime && v.endTime && !v.startTime) errors.startTime = 'حدّد وقت البداية أولاً، أو امسح وقت النهاية.';
    if (!errors.startTime && !errors.endTime && v.startTime && v.endTime) {
      sm = toMin(v.startTime); em = toMin(v.endTime);
      if (em <= sm) errors.endTime = 'وقت النهاية (' + formatTime(v.endTime) + ') يجب أن يكون بعد وقت البداية (' + formatTime(v.startTime) + ').';
    }
    if (v.notes.length > LIMITS.notes) errors.notes = 'الملاحظة أطول من ' + LIMITS.notes + ' حرفاً (طولها الآن ' + v.notes.length + '). اختصرها ثم احفظ.';
    for (i = 0; i < ORDER.length; i++) if (errors[ORDER[i]]) { first = ORDER[i]; break; }
    return { ok: first === null, values: v, errors: errors, firstError: first };
  }

  // يبني السجل للحفظ. existing (عند التعديل) يُنسخ كاملاً فيبقى recordId وclassId وأي حقل آخر كما هو.
  // الحقول الاختيارية الفارغة تُحذف. لا يُنشأ recordId هنا أبداً. الترتيب الظاهر لا يُخزَّن.
  function buildRecord(values, existing) {
    var r = {}, k;
    if (existing && typeof existing === 'object') for (k in existing) if (Object.prototype.hasOwnProperty.call(existing, k)) r[k] = existing[k];
    r.day = values.day; r.subject = values.subject;
    if (values.period) r.period = values.period; else delete r.period;
    if (values.startTime) r.startTime = values.startTime; else delete r.startTime;
    if (values.endTime) r.endTime = values.endTime; else delete r.endTime;
    if (values.notes) r.notes = values.notes; else delete r.notes;
    return r;
  }

  function field(r, k) { return r && typeof r[k] === 'string' ? r[k] : ''; }
  function periodOf(r) { var p = r && r.period; return typeof p === 'number' && isFinite(p) && p >= 1 && p === Math.floor(p) ? p : null; }

  // ترتيب الحصص داخل اليوم (ترتيب كلي ثابت): رقم الحصة تصاعدياً (ما بلا رقم أخيراً)، ثم وقت البداية (ما بلا وقت أخيراً)،
  // ثم وقت الإنشاء، ثم المعرّف. لا يعتمد على موضع السجل في المصفوفة.
  function cmp(a, b) {
    var pa = periodOf(a), pb = periodOf(b), sa, sb, ca, cb, ia, ib;
    if (pa !== pb) { if (pa === null) return 1; if (pb === null) return -1; return pa - pb; }
    sa = toMin(field(a, 'startTime')); sb = toMin(field(b, 'startTime'));
    if (sa !== sb) { if (sa === null) return 1; if (sb === null) return -1; return sa - sb; }
    ca = field(a, 'createdAt'); cb = field(b, 'createdAt');
    if (ca !== cb) return ca < cb ? -1 : 1;
    ia = field(a, 'recordId'); ib = field(b, 'recordId');
    return ia < ib ? -1 : ia > ib ? 1 : 0;
  }
  function sortDay(list) { return list.slice().sort(cmp); }
  // يجمع الحصص حسب اليوم: { byDay:{key:[...]}, unknown:[...] } (unknown = سجلات بيوم غير معروف، لا تُخفى)
  function groupByDay(list) {
    var byDay = {}, unknown = [], i, r, k;
    for (i = 0; i < DAYS.length; i++) byDay[DAYS[i].key] = [];
    for (i = 0; i < list.length; i++) { r = list[i]; k = field(r, 'day'); if (isDay(k)) byDay[k].push(r); else unknown.push(r); }
    for (k in byDay) byDay[k] = sortDay(byDay[k]);
    return { byDay: byDay, unknown: sortDay(unknown) };
  }

  // الأيام الظاهرة: المفعّلة في الإعداد + أي يوم فيه حصص (لا تُخفى بيانات) بترتيب الأسبوع
  function visibleDays(enabled, grouped) {
    var on = {}, out = [], i, k;
    (enabled || []).forEach(function (x) { if (isDay(x)) on[x] = 1; });
    for (i = 0; i < DAYS.length; i++) { k = DAYS[i].key; if (on[k] || (grouped && grouped.byDay[k] && grouped.byDay[k].length)) out.push(k); }
    return out;
  }
  // إعداد الأيام المخزَّن: { schemaVersion:1, classId, days:[مفاتيح] }
  // لا يُكتب شيء هنا. status: 'none' (لا إعداد → الافتراضي) | 'ok' | 'corrupt' | 'newer'
  function parseDaysSetting(raw, classId) {
    var d, seen = {}, days = [];
    if (raw === null || raw === undefined) return { status: 'none', days: DEFAULT_DAYS.slice() };
    try { d = JSON.parse(raw); } catch (e) { d = null; }
    if (!d || typeof d !== 'object' || Array.isArray(d) || typeof d.schemaVersion !== 'number' || !Array.isArray(d.days) || d.classId !== classId) return { status: 'corrupt', days: DEFAULT_DAYS.slice() };
    if (d.schemaVersion > 1) return { status: 'newer', days: DEFAULT_DAYS.slice() };
    d.days.forEach(function (k) { if (isDay(k) && !seen[k]) { seen[k] = 1; days.push(k); } });
    if (!days.length) return { status: 'corrupt', days: DEFAULT_DAYS.slice() };
    return { status: 'ok', days: DAYS.map(function (x) { return x.key; }).filter(function (k) { return seen[k]; }) };
  }
  function serializeDaysSetting(days, classId) {
    var seen = {};
    (days || []).forEach(function (k) { if (isDay(k)) seen[k] = 1; });
    return JSON.stringify({ schemaVersion: 1, classId: classId, days: DAYS.map(function (x) { return x.key; }).filter(function (k) { return seen[k]; }) });
  }

  // اقتراحات المادة: ما كتبه المستخدم نفسه في جدول هذا الصف فقط (لا قائمة ثابتة)
  function subjectsOf(list) {
    var seen = {}, out = [];
    list.slice().sort(function (a, b) { var x = field(a, 'updatedAt'), y = field(b, 'updatedAt'); return x === y ? 0 : x < y ? 1 : -1; }).forEach(function (r) {
      var s = oneLine(field(r, 'subject')), k = searchKey(s);
      if (s && !seen[k]) { seen[k] = 1; out.push(s); }
    });
    return out;
  }

  // تحذيرات التعارض لحصة مرشَّحة في نفس اليوم (لا تمنع الحفظ؛ القرار للمستخدم، ولا يُحذف أي سجل آخر).
  // candidate: { day, period, startTime, endTime }؛ excludeId: معرّف السجل قيد التعديل (لا يتعارض مع نفسه).
  // النتيجة: قائمة { type:'period'|'overlap'|'start', other:سجل, message }
  function findConflicts(list, candidate, excludeId) {
    var out = [], cs = toMin(candidate.startTime), ce = toMin(candidate.endTime), cp = candidate.period || null, i, r, os, oe, rp, name;
    if (!isDay(candidate.day)) return out;
    sortDay(list).forEach(function (r0) {
      r = r0;
      if (field(r, 'recordId') === excludeId || field(r, 'day') !== candidate.day) return;
      name = '«' + (field(r, 'subject') || 'بلا مادة') + '»';
      rp = periodOf(r); os = toMin(field(r, 'startTime')); oe = toMin(field(r, 'endTime'));
      if (cp && rp === cp) { out.push({ type: 'period', other: r, message: 'الحصة رقم ' + cp + ' يوم ' + dayLabel(candidate.day) + ' مضافة مسبقاً (' + name + ').' }); return; }
      if (cs !== null && ce !== null && os !== null && oe !== null) {
        if (cs < oe && os < ce) out.push({ type: 'overlap', other: r, message: 'الوقت ' + formatTime(candidate.startTime) + ' – ' + formatTime(candidate.endTime) + ' يتداخل مع ' + name + ' (' + formatTime(field(r, 'startTime')) + ' – ' + formatTime(field(r, 'endTime')) + ').' });
      } else if (cs !== null && os !== null && cs === os) {
        out.push({ type: 'start', other: r, message: 'وقت البداية ' + formatTime(candidate.startTime) + ' هو نفسه وقت بداية ' + name + '.' });
      } else if (cs !== null && ce === null && os !== null && oe !== null && cs >= os && cs < oe) {
        out.push({ type: 'overlap', other: r, message: 'وقت البداية ' + formatTime(candidate.startTime) + ' يقع داخل وقت ' + name + ' (' + formatTime(field(r, 'startTime')) + ' – ' + formatTime(field(r, 'endTime')) + ').' });
      } else if (os !== null && oe === null && cs !== null && ce !== null && os >= cs && os < ce) {
        out.push({ type: 'overlap', other: r, message: 'وقت بداية ' + name + ' (' + formatTime(field(r, 'startTime')) + ') يقع داخل الوقت الذي أدخلته.' });
      }
    });
    return out;
  }
  // توقيع نص التحذيرات: إن لم يتغير بين الضغطتين فالضغطة الثانية تُعدّ تأكيداً
  function conflictSignature(conflicts, values) {
    return [values.day, values.period || '', values.startTime, values.endTime].join('|') + '#' + conflicts.map(function (c) { return field(c.other, 'recordId') + ':' + c.type; }).join(',');
  }

  return { LIMITS: LIMITS, MAX_PERIOD: MAX_PERIOD, DAYS: DAYS, DEFAULT_DAYS: DEFAULT_DAYS, LABELS: LABELS, validate: validate, buildRecord: buildRecord, sortDay: sortDay, groupByDay: groupByDay, visibleDays: visibleDays, parseDaysSetting: parseDaysSetting, serializeDaysSetting: serializeDaysSetting, subjectsOf: subjectsOf, findConflicts: findConflicts, conflictSignature: conflictSignature, normTime: normTime, toMin: toMin, formatTime: formatTime, timeRange: timeRange, isDay: isDay, dayLabel: dayLabel, dayKeyOfDate: dayKeyOfDate, field: field, periodOf: periodOf, oneLine: oneLine, multiLine: multiLine, digits: digits };
});
