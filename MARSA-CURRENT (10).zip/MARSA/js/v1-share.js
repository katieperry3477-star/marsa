/* MARSA V1 — كود المشاركة الذاتي المحتوى (التحاضير بالكود)
 * الكود نفسه يحمل بيانات التحضير كاملة: لا خادم ولا قاعدة بيانات ولا رمز عشوائي قصير.
 * الصيغة:  MARSA1-<base64>   حيث البايتات =
 *   [طريقة:1][طول البيانات:3][CRC32 للنص الأصلي:4][بيانات]
 *   طريقة 0 = JSON بصيغة UTF-8 كما هو، طريقة 1 = نفس الـ JSON مضغوطاً بـ deflate-raw.
 * التشفير بالضغط يستعمل CompressionStream المدمج في المتصفح إن وُجد (وإلا يُرسَل بلا ضغط)،
 * أما فك الضغط فبكود JavaScript محلي في هذا الملف، فيعمل على أي جهاز بلا مكتبات ولا إنترنت.
 * دوال بلا DOM وبلا تخزين. */
(function (root, factory) {
  'use strict';
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaV1Share = api;
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  var VERSION = 1, PREFIX = 'MARSA', MAX_PAYLOAD = 200 * 1024, MAX_CODE_CHARS = 400 * 1024;
  var ID_RE = /^[A-Za-z0-9_-]{6,64}$/;
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var B64_INDEX = (function () { var m = {}, i; for (i = 0; i < 64; i++) m[B64.charAt(i)] = i; return m; })();
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF\u00AD]/g;
  var GROUP_MAX = 60;

  function getModel() {
    if (root && root.MarsaPrepsModel) return root.MarsaPrepsModel;
    if (typeof require === 'function') return require('./preps-model.js');
    throw new Error('preps-model.js غير محمَّل');
  }
  function getText() {
    if (root && root.MarsaV1Text) return root.MarsaV1Text;
    if (typeof require === 'function') return require('./v1-text.js');
    throw new Error('v1-text.js غير محمَّل');
  }
  function fail(reason, message) { return { ok: false, reason: reason, message: message }; }
  function codedError(code) { var e = new Error(code); e.code = code; return e; }

  // ===== base64 (أبجدية قياسية بلا حشو =) =====
  function b64encode(bytes) {
    var out = '', i, n = bytes.length, a, b, c;
    for (i = 0; i < n; i += 3) {
      a = bytes[i]; b = i + 1 < n ? bytes[i + 1] : 0; c = i + 2 < n ? bytes[i + 2] : 0;
      out += B64.charAt(a >> 2) + B64.charAt(((a & 3) << 4) | (b >> 4));
      if (i + 1 < n) out += B64.charAt(((b & 15) << 2) | (c >> 6));
      if (i + 2 < n) out += B64.charAt(c & 63);
    }
    return out;
  }
  // يُرجع Uint8Array أو null إن وُجد حرف خارج الأبجدية. تُهمل المسافات والأسطر.
  function b64decode(s) {
    var clean = s.replace(/\s+/g, ''), n = clean.length, bytes, i, o = 0, v, acc = 0, bits = 0;
    if (n % 4 === 1) return null;
    bytes = new Uint8Array(Math.floor(n * 3 / 4));
    for (i = 0; i < n; i++) {
      v = B64_INDEX[clean.charAt(i)];
      if (v === undefined) return null;
      acc = (acc << 6) | v; bits += 6;
      if (bits >= 8) { bits -= 8; bytes[o++] = (acc >> bits) & 255; acc &= (1 << bits) - 1; }
    }
    return bytes.subarray(0, o);
  }

  // ===== CRC32 =====
  var CRC_TABLE = (function () {
    var t = new Uint32Array(256), n, k, c;
    for (n = 0; n < 256; n++) { c = n; for (k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; }
    return t;
  })();
  function crc32(bytes) {
    var c = 0xFFFFFFFF, i;
    for (i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 255] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  // ===== فك ضغط deflate-raw (RFC 1951) بكود محلي =====
  var LBASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
  var LEXT = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
  var DBASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  var DEXT = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
  var CLORD = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

  function buildHuff(lengths, n) {
    var count = new Uint16Array(16), symbol = new Uint16Array(n), offs = new Uint16Array(16), i;
    for (i = 0; i < n; i++) count[lengths[i]]++;
    offs[1] = 0;
    for (i = 1; i < 15; i++) offs[i + 1] = offs[i] + count[i];
    for (i = 0; i < n; i++) if (lengths[i]) symbol[offs[lengths[i]]++] = i;
    return { count: count, symbol: symbol };
  }
  var FIXED = null;
  function fixedTables() {
    var l = new Uint8Array(288), d = new Uint8Array(30), i;
    if (FIXED) return FIXED;
    for (i = 0; i < 144; i++) l[i] = 8;
    for (; i < 256; i++) l[i] = 9;
    for (; i < 280; i++) l[i] = 7;
    for (; i < 288; i++) l[i] = 8;
    for (i = 0; i < 30; i++) d[i] = 5;
    FIXED = { lit: buildHuff(l, 288), dist: buildHuff(d, 30) };
    return FIXED;
  }

  // يُرجع Uint8Array؛ يرمي Error بخاصية code: 'inflate' | 'toobig'
  function inflateRaw(src, maxOut) {
    var pos = 0, bitBuf = 0, bitCnt = 0, out = new Uint8Array(Math.min(Math.max(src.length * 4, 1024), maxOut)), op = 0, last, type;

    function bits(need) {
      var val = bitBuf;
      while (bitCnt < need) {
        if (pos >= src.length) throw codedError('inflate');
        val |= src[pos++] << bitCnt; bitCnt += 8;
      }
      bitBuf = val >>> need; bitCnt -= need;
      return val & ((1 << need) - 1);
    }
    function sym(h) {
      var code = 0, first = 0, index = 0, len, c;
      for (len = 1; len <= 15; len++) {
        code |= bits(1); c = h.count[len];
        if (code - c < first) return h.symbol[index + (code - first)];
        index += c; first += c; first <<= 1; code <<= 1;
      }
      throw codedError('inflate');
    }
    function put(b) {
      var bigger;
      if (op >= out.length) {
        if (out.length >= maxOut) throw codedError('toobig');
        bigger = new Uint8Array(Math.min(out.length * 2, maxOut)); bigger.set(out); out = bigger;
      }
      out[op++] = b;
    }
    function codes(lit, dist) {
      var s, len, ds, d;
      for (;;) {
        s = sym(lit);
        if (s < 256) { put(s); continue; }
        if (s === 256) return;
        s -= 257;
        if (s >= 29) throw codedError('inflate');
        len = LBASE[s] + bits(LEXT[s]);
        ds = sym(dist);
        if (ds >= 30) throw codedError('inflate');
        d = DBASE[ds] + bits(DEXT[ds]);
        if (d > op) throw codedError('inflate');
        while (len--) put(out[op - d]);
      }
    }
    function dynamic() {
      var nlen = bits(5) + 257, ndist = bits(5) + 1, ncode = bits(4) + 4, lengths = new Uint8Array(320), i, idx = 0, lc, dc, s, rep, prev;
      if (nlen > 286 || ndist > 30) throw codedError('inflate');
      for (i = 0; i < 19; i++) lengths[CLORD[i]] = i < ncode ? bits(3) : 0;
      lc = buildHuff(lengths.subarray(0, 19), 19);
      lengths = new Uint8Array(320);
      while (idx < nlen + ndist) {
        s = sym(lc);
        if (s < 16) { lengths[idx++] = s; continue; }
        prev = 0;
        if (s === 16) { if (idx === 0) throw codedError('inflate'); prev = lengths[idx - 1]; rep = 3 + bits(2); }
        else if (s === 17) rep = 3 + bits(3);
        else rep = 11 + bits(7);
        if (idx + rep > nlen + ndist) throw codedError('inflate');
        while (rep--) lengths[idx++] = prev;
      }
      if (lengths[256] === 0) throw codedError('inflate');
      lc = buildHuff(lengths.subarray(0, nlen), nlen);
      dc = buildHuff(lengths.subarray(nlen, nlen + ndist), ndist);
      codes(lc, dc);
    }

    do {
      last = bits(1); type = bits(2);
      if (type === 0) {
        var len, nlen2, k;
        bitBuf = 0; bitCnt = 0;
        if (pos + 4 > src.length) throw codedError('inflate');
        len = src[pos] | (src[pos + 1] << 8); nlen2 = src[pos + 2] | (src[pos + 3] << 8); pos += 4;
        if (len !== (~nlen2 & 0xFFFF)) throw codedError('inflate');
        if (pos + len > src.length) throw codedError('inflate');
        for (k = 0; k < len; k++) put(src[pos++]);
      } else if (type === 1) { var f = fixedTables(); codes(f.lit, f.dist); }
      else if (type === 2) dynamic();
      else throw codedError('inflate');
    } while (!last);
    return out.subarray(0, op);
  }

  // ===== ضغط (اختياري): CompressionStream المدمج. يُرجع Promise<Uint8Array|null> =====
  function nativeDeflate(bytes) {
    return new Promise(function (resolve) {
      var cs, writer, reader, chunks = [], total = 0;
      try {
        if (typeof CompressionStream === 'undefined') return resolve(null);
        cs = new CompressionStream('deflate-raw'); writer = cs.writable.getWriter(); reader = cs.readable.getReader();
      } catch (e) { return resolve(null); }
      function pump() {
        reader.read().then(function (r) {
          var out, off = 0, i;
          if (r.done) {
            out = new Uint8Array(total);
            for (i = 0; i < chunks.length; i++) { out.set(chunks[i], off); off += chunks[i].length; }
            return resolve(out);
          }
          chunks.push(r.value); total += r.value.length; pump();
        }, function () { resolve(null); });
      }
      pump();
      writer.write(bytes).then(function () { return writer.close(); }).catch(function () { resolve(null); });
    });
  }

  // ===== بناء الحمولة =====
  function utf8(s) { return new TextEncoder().encode(s); }

  function toPayload(prep) {
    var o = { v: VERSION, i: prep.id, s: prep.subject, t: prep.title, d: prep.date, c: prep.content, u: prep.updatedAt };
    if (prep.pages) o.p = prep.pages;
    if (prep.homework) o.h = prep.homework;
    if (prep.notes) o.n = prep.notes;
    if (prep.group) o.g = prep.group;
    return JSON.stringify(o);
  }

  function packHeader(method, dataLen, crc) {
    return [method, (dataLen >>> 16) & 255, (dataLen >>> 8) & 255, dataLen & 255, (crc >>> 24) & 255, (crc >>> 16) & 255, (crc >>> 8) & 255, crc & 255];
  }

  // prep: { id, subject, title, date, content, pages?, homework?, notes?, group?, updatedAt:number }
  // opts.deflate (اختبارات فقط): دالة تُرجع Promise<Uint8Array|null>. يُرجع Promise<{ code, method, rawBytes, codeLength }>
  function encode(prep, opts) {
    var deflate = (opts && opts.deflate) || nativeDeflate, raw, crc, head;
    if (!prep || !ID_RE.test(String(prep.id))) return Promise.reject(new Error('معرّف التحضير غير صالح.'));
    raw = utf8(toPayload(prep));
    if (raw.length > MAX_PAYLOAD) return Promise.reject(new Error('التحضير كبير جداً على كود مشاركة.'));
    crc = crc32(raw);
    return Promise.resolve(deflate(raw)).catch(function () { return null; }).then(function (z) {
      var method = 0, data = raw, body, all, i;
      if (z && z.length > 0 && z.length < raw.length) { method = 1; data = z; }
      head = packHeader(method, data.length, crc);
      all = new Uint8Array(head.length + data.length);
      for (i = 0; i < head.length; i++) all[i] = head[i];
      all.set(data, head.length);
      body = PREFIX + VERSION + '-' + b64encode(all);
      return { code: body, method: method, rawBytes: raw.length, codeLength: body.length };
    });
  }

  // ===== استخراج الكود من نص ملصوق (قد يكون رسالة واتساب كاملة) =====
  // يُرجع { version, body } أو null. body = أحرف base64 فقط (بلا مسافات).
  function extractCode(text) {
    var s = String(text == null ? '' : text).replace(INVIS, ''), m = /marsa\s*(\d{1,3})\s*[-\u2010-\u2015\u2212]\s*/i.exec(s), rest, i, ch, out = '', codeEnd;
    if (!m) return null;
    rest = s.slice(m.index + m[0].length);
    for (i = 0; i < rest.length && out.length < MAX_CODE_CHARS; i++) {
      ch = rest.charAt(i);
      if (B64_INDEX[ch] !== undefined) out += ch;
      else if (/\s/.test(ch)) continue;
      else break;
    }
    codeEnd = out.length;
    return { version: +m[1], body: out, length: codeEnd };
  }

  function sanitizePrep(obj) {
    var v, i, k, res, g, u, keys = { v: 1, i: 1, s: 1, t: 1, d: 1, c: 1, p: 1, h: 1, n: 1, g: 1, u: 1 };
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return fail('invalid', 'بيانات التحضير داخل الكود غير مفهومة.');
    for (k in obj) if (Object.prototype.hasOwnProperty.call(obj, k) && !Object.prototype.hasOwnProperty.call(keys, k)) return fail('invalid', 'الكود يحتوي بيانات غير معروفة.');
    if (obj.v !== VERSION) return fail('version', 'هذا الكود من إصدار غير مدعوم في هذه النسخة من مَرسى.');
    if (typeof obj.i !== 'string' || !ID_RE.test(obj.i)) return fail('invalid', 'معرّف التحضير داخل الكود غير صالح.');
    for (i = 0; i < ['s', 't', 'd', 'c', 'p', 'h', 'n', 'g'].length; i++) {
      k = ['s', 't', 'd', 'c', 'p', 'h', 'n', 'g'][i];
      if (obj[k] !== undefined && typeof obj[k] !== 'string') return fail('invalid', 'بيانات التحضير داخل الكود غير صالحة.');
    }
    u = obj.u;
    if (typeof u !== 'number' || !isFinite(u) || u < 0 || u > 4102444800000 || Math.floor(u) !== u) return fail('invalid', 'تاريخ تعديل التحضير داخل الكود غير صالح.');
    v = getText().validate({ subject: obj.s, title: obj.t, date: obj.d, content: obj.c, pages: obj.p, homework: obj.h, notes: obj.n, group: obj.g });
    if (!v.ok) return fail('invalid', 'بيانات التحضير داخل الكود غير صالحة: ' + v.errors[v.firstError]);
    g = v.values.group || '';
    res = { id: obj.i, subject: v.values.subject, title: v.values.title, date: v.values.date, content: v.values.content, updatedAt: u };
    if (v.values.pages) res.pages = v.values.pages;
    if (v.values.homework) res.homework = v.values.homework;
    if (v.values.notes) res.notes = v.values.notes;
    if (g) res.group = g;
    return { ok: true, prep: res };
  }

  var MSG = {
    empty: 'الصق الكود أولاً، ثم اضغط «معاينة التحضير».',
    noprefix: 'هذا ليس كود مَرسى. انسخ الكود كاملاً من رسالة الممثل؛ يبدأ بـ MARSA1- ثم أحرف وأرقام طويلة.',
    truncated: 'الكود ناقص: نُسخ جزء منه فقط. ارجع إلى رسالة الممثل وانسخ الكود كاملاً حتى آخره، ثم الصقه من جديد.',
    corrupt: 'الكود تالف: حرف أو أكثر تغيّر أثناء النسخ. انسخه من الرسالة الأصلية من جديد، أو اطلب من الممثل إعادة إرساله.',
    toobig: 'الكود يحتوي بيانات أكبر من المسموح، فلم يُفتح.'
  };

  // يُرجع { ok:true, prep, info } أو { ok:false, reason, message }
  function decode(text) {
    var ex, bytes, method, len, crc, data, raw, json, obj, expect, got, res;
    if (String(text == null ? '' : text).replace(/\s+/g, '').replace(INVIS, '') === '') return fail('empty', MSG.empty);
    ex = extractCode(text);
    if (!ex) return fail('noprefix', MSG.noprefix);
    if (ex.version !== VERSION) {
      return ex.version > VERSION
        ? fail('version', 'هذا الكود من إصدار أحدث من مَرسى (الإصدار ' + ex.version + ') ولا تدعمه هذه النسخة. حدّث التطبيق ثم أعد المحاولة.')
        : fail('version', 'هذا الكود من إصدار قديم غير مدعوم (الإصدار ' + ex.version + ').');
    }
    if (ex.body.length < 11) return fail('truncated', MSG.truncated);
    // نقرأ أول 8 بايتات (11 حرفاً) لمعرفة الطول المتوقع، ونتجاهل أي نص زائد بعد نهاية الكود
    bytes = b64decode(ex.body.slice(0, 11));
    if (!bytes || bytes.length < 8) return fail('truncated', MSG.truncated);
    method = bytes[0]; len = (bytes[1] << 16) | (bytes[2] << 8) | bytes[3];
    crc = ((bytes[4] << 24) | (bytes[5] << 16) | (bytes[6] << 8) | bytes[7]) >>> 0;
    if (method > 1) return fail('corrupt', MSG.corrupt);
    if (len > MAX_PAYLOAD || len === 0) return fail('corrupt', MSG.corrupt);
    expect = Math.ceil((8 + len) * 4 / 3);
    if (ex.body.length < expect) return fail('truncated', MSG.truncated);
    bytes = b64decode(ex.body.slice(0, expect));
    if (!bytes || bytes.length < 8 + len) return fail('corrupt', MSG.corrupt);
    data = bytes.subarray(8, 8 + len);
    try { raw = method === 1 ? inflateRaw(data, MAX_PAYLOAD) : data; }
    catch (e) { return fail(e && e.code === 'toobig' ? 'toobig' : 'corrupt', e && e.code === 'toobig' ? MSG.toobig : MSG.corrupt); }
    got = crc32(raw);
    if (got !== crc) return fail('corrupt', MSG.corrupt);
    try { json = new TextDecoder('utf-8', { fatal: true }).decode(raw); obj = JSON.parse(json); }
    catch (e2) { return fail('corrupt', MSG.corrupt); }
    res = sanitizePrep(obj);
    if (!res.ok) return res;
    res.info = { method: method, codeLength: ex.length + 6 };
    return res;
  }

  // ===== رسالة واتساب =====
  // appUrl اختياري (رابط يفتح التطبيق). يُرجع نصاً جاهزاً للصق.
  function buildMessage(prep, code, appUrl) {
    var model = getModel(), lines = [], url = typeof appUrl === 'string' ? appUrl.trim() : '';
    lines.push('📚 تحضير جديد من مَرسى');
    lines.push('المادة: ' + prep.subject);
    lines.push('العنوان: ' + prep.title);
    if (prep.group) lines.push('الصف: ' + prep.group);
    lines.push('التاريخ: ' + model.formatDate(prep.date));
    lines.push('');
    lines.push('لإضافته إلى تحضيراتك:');
    lines.push(url ? '1) افتح مَرسى: ' + url : '1) افتح تطبيق مَرسى');
    lines.push('2) اضغط «إضافة تحضير»');
    lines.push('3) انسخ الكود التالي كاملاً والصقه، ثم اضغط «معاينة التحضير» ثم «إضافة إلى تحضيراتي»');
    lines.push('');
    lines.push('```' + code + '```');
    return lines.join('\n');
  }

  return {
    VERSION: VERSION, MAX_PAYLOAD: MAX_PAYLOAD, GROUP_MAX: GROUP_MAX, ID_RE: ID_RE,
    encode: encode, decode: decode, extractCode: extractCode, buildMessage: buildMessage,
    inflateRaw: inflateRaw, crc32: crc32, b64encode: b64encode, b64decode: b64decode, toPayload: toPayload
  };
});
