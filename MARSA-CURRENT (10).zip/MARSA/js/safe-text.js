/* MARSA — تقسيم النص إلى أجزاء آمنة للعرض (المرحلة 03.6)
 * دالة نقية بلا DOM: تُرجع قائمة { text } أو { text, href } حيث href لا يكون إلا http: أو https: صالحاً.
 * أي بروتوكول آخر (javascript:, data:, file:, vbscript:, mailto: ...) يبقى نصاً عادياً غير قابل للنقر.
 * واجهة الطالب تبني العناصر بـ textContent وcreateElement فقط؛ لا innerHTML أبداً. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaSafeText = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var ALLOWED = { 'http:': 1, 'https:': 1 };
  var MAX_URL = 2000;
  // نمط مبدئي فقط؛ القرار النهائي بـ new URL ثم فحص البروتوكول
  var CANDIDATE = /https?:\/\/[^\s<>"'`​-‏‪-‮⁦-⁩﻿]+/gi;
  var TRAIL = /[.,;:!?،؛؟)\]}»"'،؛؟]+$/;

  // يُرجع الرابط المعقَّم أو '' إن لم يكن آمناً
  function safeHref(s) {
    var u;
    if (typeof s !== 'string' || !s || s.length > MAX_URL) return '';
    if (!/^https?:\/\/[^\/\\?#]/i.test(s)) return ''; // المضيف يلي «//» مباشرة (المحلِّل يصلح https:///x بصمت فيختلف الظاهر عن الهدف)
    try { u = new URL(s); } catch (e) { return ''; }
    if (!ALLOWED[u.protocol] || !u.hostname) return '';
    if (u.username || u.password) return ''; // لا بيانات دخول داخل الرابط (تضليل)
    return u.href;
  }

  function segments(text) {
    var s = typeof text === 'string' ? text : '', out = [], last = 0, m, raw, trail, href, end;
    CANDIDATE.lastIndex = 0;
    while ((m = CANDIDATE.exec(s)) !== null) {
      raw = m[0]; trail = TRAIL.exec(raw);
      if (trail) raw = raw.slice(0, raw.length - trail[0].length);
      href = safeHref(raw);
      if (!href) continue;
      end = m.index + raw.length;
      if (m.index > last) out.push({ text: s.slice(last, m.index) });
      out.push({ text: raw, href: href });
      last = end;
      CANDIDATE.lastIndex = end;
    }
    if (last < s.length) out.push({ text: s.slice(last) });
    return out;
  }

  return { segments: segments, safeHref: safeHref };
});
