/* MARSA — منطق «الأرشيف الدراسي» (المرحلة 03.9)
 * دوال نقية بلا DOM ولا تخزين. الأرشيف طريقة عرض مشتقة فقط: تُبنى عناصره عند كل قراءة من السجلات الأصلية
 * (dailyLessons وpreparations وexams في MarsaAcademicStore) ولا تُخزَّن ولا تُنسخ ولا تُنقل ولا تُحذف.
 * كل عنصر يشير (record) إلى السجل الأصلي نفسه كما قُرئ، والمصدر يبقى المكان الوحيد للتعديل.
 *
 * قواعد الإدراج (اليوم = تاريخ محلي YYYY-MM-DD؛ لا UTC):
 *  - درس مشروح (lesson): كل سجل في dailyLessons يدخل. «ما أُخذ» حدث وقع بتسجيله؛ التاريخ المستقبلي يُوسَم فقط ولا يُخفى.
 *  - تحضير (prep): فقط إذا كان تاريخه صالحاً وقبل اليوم. تحضير اليوم وباجر وما بعدهما وبلا تاريخ صالح يبقى في «التحاضير» فقط.
 *  - امتحان (exam): «أُجري» يدخل بأي تاريخ؛ «مجدول» أو «أُلغي» يدخلان فقط إذا مضى تاريخهما (قبل اليوم).
 *    الامتحان القادم أو الملغى المستقبلي لا يدخل. المجدول الفائت يدخل موسوماً «مضى موعده» وتبقى حالته مجدول.
 *  تغيّر التاريخ مع الزمن ينقل العنصر بين العرضين فقط، ولا يلمس السجل. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaArchiveModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var KINDS = ['lesson', 'prep', 'exam'];
  var KIND_LABELS = { lesson: 'درس مشروح', prep: 'تحضير', exam: 'امتحان' };
  var KIND_FILTER_LABELS = { all: 'الكل', lesson: 'الدروس', prep: 'التحاضير', exam: 'الامتحانات' };
  var PERIODS = ['all', '7', '30', 'custom'];
  var PERIOD_LABELS = { all: 'كل الفترات', '7': 'آخر 7 أيام', '30': 'آخر 30 يوماً', custom: 'من تاريخ إلى تاريخ' };
  var KIND_RANK = { lesson: 0, prep: 1, exam: 2 };
  var INVIS = /[​-‏‪-‮⁦-⁩﻿]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  function field(r, k) { return r && typeof r[k] === 'string' ? r[k] : ''; }
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  function searchKey(s) {
    return oneLine(s).replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (!m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function addDays(ymd, n) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(ymd)), d;
    if (!m || !isLocalDate(ymd)) return '';
    d = new Date(+m[1], +m[2] - 1, +m[3] + n);
    return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
  }
  function list(x) { return Array.isArray(x) ? x : []; }

  function entry(kind, r, date, status) {
    var id = field(r, 'recordId');
    return { kind: kind, key: kind + ':' + id, recordId: id, date: isLocalDate(date) ? date : '', subject: field(r, 'subject'), title: field(r, 'title'), status: status || '', record: r };
  }
  // opts: { classId?, today, lessons, preps, exams } (كل قائمة سجلات كما أرجعتها readCollection).
  // إن مُرّر classId يُتجاهل أي سجل لا يطابقه (حماية إضافية؛ الطبقة نفسها ترفض ذلك).
  function buildEntries(opts) {
    var today = opts && opts.today, cid = opts && opts.classId, out = [];
    function mine(r) { return r && typeof r === 'object' && (cid === undefined || r.classId === cid); }
    list(opts && opts.lessons).forEach(function (r) { if (mine(r)) out.push(entry('lesson', r, field(r, 'date'))); });
    list(opts && opts.preps).forEach(function (r) {
      var d = field(r, 'date');
      if (mine(r) && isLocalDate(d) && d < today) out.push(entry('prep', r, d));
    });
    list(opts && opts.exams).forEach(function (r) {
      var d = field(r, 'examDate'), st = field(r, 'status'), valid = isLocalDate(d);
      if (!mine(r)) return;
      if (st !== 'held' && st !== 'cancelled') st = 'scheduled'; // نفس قاعدة exams-model.statusOf
      if (st === 'held' || (valid && d < today)) out.push(entry('exam', r, d, st));
    });
    return out;
  }

  // الأحدث تاريخاً أولاً؛ بلا تاريخ صالح في النهاية. عند التساوي: الأحدث إنشاءً ثم نوع السجل ثم المعرّف (ترتيب ثابت).
  function sortEntries(entries) {
    return entries.slice().sort(function (a, b) {
      var ca, cb;
      if (a.date !== b.date) { if (!a.date) return 1; if (!b.date) return -1; return a.date < b.date ? 1 : -1; }
      ca = field(a.record, 'createdAt'); cb = field(b.record, 'createdAt');
      if (ca !== cb) return ca < cb ? 1 : -1;
      if (a.kind !== b.kind) return KIND_RANK[a.kind] - KIND_RANK[b.kind];
      return a.recordId < b.recordId ? -1 : a.recordId > b.recordId ? 1 : 0;
    });
  }

  function defaults() { return { q: '', kind: 'all', period: 'all', from: '', to: '' }; }
  function norm(f) {
    var d = defaults(), k;
    f = f || {};
    for (k in d) if (f[k] !== undefined && f[k] !== null) d[k] = str(f[k]);
    if (d.kind !== 'all' && KINDS.indexOf(d.kind) < 0) d.kind = 'all';
    if (PERIODS.indexOf(d.period) < 0) d.period = 'all';
    return d;
  }
  // نطاق الفترة: { active, from, to, reversed, message }. «آخر 7 أيام» = اليوم و6 أيام قبله (شاملة).
  // حد مكتوب بصيغة غير صالحة يُهمل. بداية بعد النهاية = لا نتائج مع رسالة (لا قلب صامت للتاريخين).
  function periodRange(f, today) {
    f = norm(f);
    var from, to;
    if (f.period === 'all') return { active: false, from: '', to: '', reversed: false, message: '' };
    if (f.period === '7' || f.period === '30') return { active: true, from: addDays(today, 1 - +f.period), to: today, reversed: false, message: '' };
    from = isLocalDate(f.from) ? f.from : ''; to = isLocalDate(f.to) ? f.to : '';
    if (from && to && from > to) return { active: true, from: from, to: to, reversed: true, message: 'تاريخ البداية بعد تاريخ النهاية، لذلك لا توجد نتائج. صحّح التاريخين.' };
    return { active: !!(from || to), from: from, to: to, reversed: false, message: '' };
  }
  // عدد الفلاتر النشطة: النوع والفترة فقط (البحث له حقله الظاهر وزره الخاص). فترة «مخصصة» بلا تاريخين غير نشطة.
  function activeFilterCount(f, today) {
    f = norm(f);
    return (f.kind !== 'all' ? 1 : 0) + (periodRange(f, today).active ? 1 : 0);
  }
  function hasAnyFilter(f, today) { return activeFilterCount(f, today) > 0 || !!searchKey(norm(f).q); }

  // يرجع قائمة جديدة ولا يعدّل المدخلات. العنصر بلا تاريخ صالح لا يطابق فترة نشطة.
  function filterEntries(entries, f, today) {
    f = norm(f);
    var q = searchKey(f.q), pr = periodRange(f, today);
    return entries.filter(function (e) {
      if (f.kind !== 'all' && e.kind !== f.kind) return false;
      if (pr.active) {
        if (pr.reversed) return false;
        if (!e.date) return false;
        if (pr.from && e.date < pr.from) return false;
        if (pr.to && e.date > pr.to) return false;
      }
      if (q && searchKey(e.subject).indexOf(q) < 0 && searchKey(e.title).indexOf(q) < 0) return false;
      return true;
    });
  }
  function countByKind(entries) {
    var c = { all: entries.length, lesson: 0, prep: 0, exam: 0 };
    entries.forEach(function (e) { c[e.kind]++; });
    return c;
  }

  return { KINDS: KINDS, KIND_LABELS: KIND_LABELS, KIND_FILTER_LABELS: KIND_FILTER_LABELS, PERIODS: PERIODS, PERIOD_LABELS: PERIOD_LABELS, buildEntries: buildEntries, sortEntries: sortEntries, filterEntries: filterEntries, defaults: defaults, normalize: norm, periodRange: periodRange, activeFilterCount: activeFilterCount, hasAnyFilter: hasAnyFilter, countByKind: countByKind, addDays: addDays, searchKey: searchKey, isLocalDate: isLocalDate };
});
