/* MARSA V1 — الانترو (شاشة البداية) عند كل فتح للصفحة (01.03 · S00).
 * شعار فقط ≈1.5 ثانية، قابل للتخطّي بلمسة أو بزر «تخطّي» أو Escape. لا تخزين ولا شبكة ولا اعتماد على بقية ملفات التطبيق،
 * فلو تعطّل أي ملف آخر لا يبقى الانترو عالقاً. يُحترم prefers-reduced-motion: لا حركة (الشعار ثابت ثم يُزال فوراً).
 * أثناء ظهوره تُعطَّل بقية الصفحة (inert) كي لا يصل إليها التركيز بلوحة المفاتيح، ثم يُطلق الحدث marsa:intro-done. */
(function () {
  'use strict';
  var intro = document.getElementById('intro');
  if (!intro) return;
  var DURATION = 1500, FADE = 200, done = false, timer = 0;
  var behind = Array.prototype.slice.call(document.querySelectorAll('.top, #shell, .foot'));
  var skipBtn = document.getElementById('intro-skip');
  var reduced = false;
  try { reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { reduced = false; }

  function setBehind(on) {
    behind.forEach(function (n) {
      if (on) { n.setAttribute('inert', ''); n.setAttribute('aria-hidden', 'true'); }
      else { n.removeAttribute('inert'); n.removeAttribute('aria-hidden'); }
    });
  }
  function finish() {
    if (done) return;
    done = true; clearTimeout(timer);
    document.removeEventListener('keydown', onKey, true);
    function remove() {
      if (intro.parentNode) intro.parentNode.removeChild(intro);
      setBehind(false);
      document.documentElement.removeAttribute('data-intro');
      document.dispatchEvent(new Event('marsa:intro-done'));
    }
    if (reduced) { remove(); return; }
    intro.classList.add('leave');
    setTimeout(remove, FADE);
  }
  function onKey(ev) { if (ev.key === 'Escape' || ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); finish(); } }

  document.documentElement.setAttribute('data-intro', 'on');
  setBehind(true);
  intro.addEventListener('click', finish);
  document.addEventListener('keydown', onKey, true);
  if (skipBtn) { try { skipBtn.focus({ preventScroll: true }); } catch (e2) { /* لا شيء */ } }
  timer = setTimeout(finish, DURATION);
})();
