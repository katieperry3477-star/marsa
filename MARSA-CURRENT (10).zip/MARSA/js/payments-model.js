/* MARSA — منطق «المدفوعات وسجل المقبوضات» (المرحلة 4.05)
 * دوال نقية بلا DOM ولا تخزين: تنظيف وتحقق وبحث وفرز وإجماليات مشتقة.
 * التخزين يمرّ حصراً عبر MarsaAcademicStore (النوع payments). المعرّف الثابت للطالب هو studentId.
 * المقصود: مبلغ استُلم فعلاً. لا رسوم ولا ديون ولا «متبقٍ» ولا غرامات ولا اشتراكات، ولا مبالغ افتراضية.
 * الحقول وفق DATA-MODEL.md: recordId, classId, studentId, date, amount (دينار عراقي صحيح), purpose, receiptNo?, note?.
 * ملاحظة التسمية: اسم حقل المبلغ المخزَّن هو amount (ثبّتته 4.02 في المتجر)؛ الوحدة الدينار العراقي تُعرض في الواجهة ولا تُخزَّن. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaPaymentsModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var PURPOSE_MAX = 80, RECEIPT_MAX = 40, NOTE_MAX = 200, MIN_YEAR = 2000, MAX_YEAR = 2100;
  var MAX_AMOUNT = 999999999999; // حد عقلاني للإدخال (أقل بكثير من Number.MAX_SAFE_INTEGER) لتفادي خطأ كتابة أصفار زائدة
  var CURRENCY = 'دينار عراقي';
  var ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
  var SORTS = ['date', 'student', 'purpose', 'amount'];
  var SORT_LABELS = { date: 'التاريخ', student: 'الطالب', purpose: 'الغرض', amount: 'المبلغ' };

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  function searchKey(s) {
    return oneLine(s).replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (typeof s !== 'string' || !m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }
  // تاريخ محلي من أجزاء Date المحلية (لا toISOString فلا ينتقل اليوم بسبب UTC)
  function localDate(d) {
    d = d || new Date();
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function formatDate(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(iso));
    return m && isLocalDate(iso) ? m[3] + '/' + m[2] + '/' + m[1] : (str(iso) || '(بلا تاريخ)');
  }

  // ===== المبلغ: عدد صحيح موجب بالدينار =====
  // يقبل الأرقام العربية-الهندية والفارسية وفواصل الآلاف («,» «٬» «،» ومسافة)، ويرفض الكسور والسالب والرموز والنص.
  // النقطة والفاصلة العشرية «٫» تُرفض صراحةً (قد تعني كسراً أو فاصل آلاف أوروبياً؛ لا نخمّن).
  // النتيجة: { ok, value } أو { ok:false, reason:'empty'|'format'|'fraction'|'negative'|'zero'|'toolarge' }
  function parseAmount(input) {
    var s, n;
    if (typeof input === 'number') {
      if (!isFinite(input)) return { ok: false, reason: 'format' };
      if (Math.floor(input) !== input) return { ok: false, reason: 'fraction' };
      if (input < 0) return { ok: false, reason: 'negative' };
      if (input === 0) return { ok: false, reason: 'zero' };
      return input > MAX_AMOUNT ? { ok: false, reason: 'toolarge' } : { ok: true, value: input };
    }
    s = oneLine(input);
    if (!s) return { ok: false, reason: 'empty' };
    s = s.replace(/[\u0660-\u0669]/g, function (c) { return String(c.charCodeAt(0) - 0x660); })
      .replace(/[\u06F0-\u06F9]/g, function (c) { return String(c.charCodeAt(0) - 0x6F0); });
    if (/^[-\u2212\u2013]/.test(s)) return { ok: false, reason: 'negative' };
    if (/[.\u066B]/.test(s)) return { ok: false, reason: 'fraction' };
    s = s.replace(/[,\u066C\u060C ]/g, '');
    if (!/^\d+$/.test(s)) return { ok: false, reason: 'format' };
    n = Number(s);
    if (!isFinite(n) || n > MAX_AMOUNT) return { ok: false, reason: 'toolarge' };
    if (n === 0) return { ok: false, reason: 'zero' };
    return { ok: true, value: n };
  }
  var AMOUNT_MSG = {
    empty: 'اكتب المبلغ المستلم بالدينار العراقي.',
    format: 'المبلغ يجب أن يكون رقماً بالدينار العراقي (مثل 5000 أو 25,000).',
    fraction: 'المبلغ عدد صحيح بالدينار بلا كسور أو فاصلة عشرية. اكتب 5000 وليس 5000.5.',
    negative: 'المبلغ يجب أن يكون موجباً. المقصود المبلغ المستلم فعلاً؛ لتصحيح خطأ عدّل السجل أو احذفه.',
    zero: 'المبلغ يجب أن يكون أكبر من صفر.',
    toolarge: 'المبلغ كبير جداً (الحد ' + MAX_AMOUNT + ' دينار). راجع الأصفار.'
  };

  // 5000 → «5,000»؛ long=true يضيف «دينار عراقي»
  function formatAmount(n, long) {
    var s;
    if (typeof n !== 'number' || !isFinite(n)) return '—';
    s = String(Math.abs(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (n < 0 ? '-' : '') + s + ' ' + (long ? CURRENCY : 'د.ع');
  }

  // ===== التحقق =====
  function validateDate(date, today) {
    var d = str(date).trim(), y;
    if (!d) return 'اختر تاريخ الاستلام.';
    if (!isLocalDate(d)) return 'التاريخ غير صالح. استخدم يوماً موجوداً في التقويم بصيغة YYYY-MM-DD.';
    y = +d.slice(0, 4);
    if (y < MIN_YEAR || y > MAX_YEAR) return 'التاريخ خارج النطاق المنطقي (' + MIN_YEAR + ' إلى ' + MAX_YEAR + ').';
    if (today && d > today) return 'لا يمكن تسجيل دفعة بتاريخ بعد اليوم المحلي: المسجَّل هنا مبلغ استُلم فعلاً.';
    return null;
  }
  // input: { studentId, date, amount, purpose, receiptNo, note } (amount نص أو رقم)
  // ctx: { today, activeIds:[..] } → { ok, values, errors }
  function validateEntry(input, ctx) {
    var e = {}, v = {}, am, i, found = false, d;
    input = input || {}; ctx = ctx || {};
    v.studentId = str(input.studentId).trim();
    v.purpose = oneLine(input.purpose);
    v.date = str(input.date).trim();
    v.receiptNo = oneLine(input.receiptNo);
    v.note = oneLine(input.note);
    if (!ID_RE.test(v.studentId)) e.studentId = 'اختر الطالب.';
    else if (Array.isArray(ctx.activeIds)) {
      for (i = 0; i < ctx.activeIds.length; i++) if (ctx.activeIds[i] === v.studentId) { found = true; break; }
      if (!found) e.studentId = 'الطالب ليس ضمن الطلاب الفعّالين في هذا الصف.';
    }
    if (!v.purpose) e.purpose = 'اكتب غرض الدفعة (مثل: ملزمة، رحلة، اشتراك مشترك).';
    else if (v.purpose.length > PURPOSE_MAX) e.purpose = 'الغرض أطول من ' + PURPOSE_MAX + ' حرفاً.';
    d = validateDate(v.date, ctx.today); if (d) e.date = d;
    if (v.receiptNo.length > RECEIPT_MAX) e.receiptNo = 'رقم الوصل أطول من ' + RECEIPT_MAX + ' حرفاً.';
    if (v.note.length > NOTE_MAX) e.note = 'الملاحظة أطول من ' + NOTE_MAX + ' حرفاً (طولها الآن ' + v.note.length + ').';
    am = parseAmount(input.amount);
    if (!am.ok) e.amount = AMOUNT_MSG[am.reason];
    else v.amount = am.value;
    return { ok: Object.keys(e).length === 0, values: v, errors: e };
  }

  function findById(records, id) { var i; for (i = 0; i < (records || []).length; i++) if (records[i].recordId === id) return records[i]; return null; }
  // رقم الوصل المكرر داخل الصف: تحذير وليس منعاً (وصل واحد قد يغطي عدة طلاب). المقارنة بعد توحيد النص.
  function findReceiptMatches(records, receiptNo, exceptRecordId) {
    var k = searchKey(receiptNo), out = [], i, r;
    if (!k) return out;
    for (i = 0; i < (records || []).length; i++) { r = records[i]; if (r.recordId !== exceptRecordId && searchKey(r.receiptNo) === k) out.push(r); }
    return out;
  }
  function shallow(o) { var r = {}, k; for (k in o) if (Object.prototype.hasOwnProperty.call(o, k)) r[k] = o[k]; return r; }

  // ===== تخطيط الحفظ =====
  // editing: السجل القائم عند التعديل (أو null للإضافة). fresh: السجلات الحالية من المتجر لحظة الحفظ.
  // النتيجة: { ok, record, mode:'create'|'update'|'unchanged', errors, warnings:{ receiptMatches } }
  // التعديل ينسخ السجل القائم كاملاً فيبقى recordId وclassId وcreatedAt؛ لا يُنشأ recordId هنا أبداً (يُنشئه المتجر).
  // studentId لا يتغير عند التعديل (المتجر يرفض ذلك)، فيُؤخذ من السجل القائم.
  // لا قيد تفرّد: دفعتان متطابقتان قد تكونان مشروعتين.
  function planSave(input, fresh, ctx, editing) {
    var res, ex = null, rec, matches;
    ctx = ctx || {}; input = input || {};
    if (editing) {
      ex = findById(fresh, editing.recordId);
      if (!ex) return { ok: false, status: 'not-found', errors: { _: 'السجل لم يعد موجوداً (ربما حُذف من تبويب آخر). أُعيد تحميل القائمة.' } };
      input = shallow(input); input.studentId = ex.studentId;
    }
    res = validateEntry(input, { today: ctx.today, activeIds: ctx.activeIds });
    if (!res.ok) return { ok: false, errors: res.errors };
    matches = findReceiptMatches(fresh, res.values.receiptNo, ex ? ex.recordId : null);
    if (ex) {
      if (ex.amount === res.values.amount && ex.purpose === res.values.purpose && ex.date === res.values.date && str(ex.receiptNo) === res.values.receiptNo && str(ex.note) === res.values.note) return { ok: true, mode: 'unchanged', record: ex, warnings: { receiptMatches: matches } };
      rec = shallow(ex);
    } else rec = { studentId: res.values.studentId };
    rec.amount = res.values.amount; rec.purpose = res.values.purpose; rec.date = res.values.date;
    if (res.values.receiptNo) rec.receiptNo = res.values.receiptNo; else delete rec.receiptNo;
    if (res.values.note) rec.note = res.values.note; else delete rec.note;
    return { ok: true, mode: ex ? 'update' : 'create', record: rec, warnings: { receiptMatches: matches } };
  }

  // ===== تصنيف السجلات حسب حالة الطالب =====
  // allStudents: كل طلاب الصف (فعّالون ومؤرشفون). → 'active' | 'archived' | 'unknown'
  function studentKind(studentId, allStudents) {
    var i, s;
    for (i = 0; i < (allStudents || []).length; i++) { s = allStudents[i]; if (s.studentId === studentId) return s.status === 'archived' ? 'archived' : 'active'; }
    return 'unknown';
  }

  // ===== البحث والفرز =====
  // opts: { query, nameOf, studentId, from, to } — from/to شاملتان
  function filterRecords(records, opts) {
    var q = searchKey(opts && opts.query), nameOf = opts && opts.nameOf, sid = opts && opts.studentId, from = opts && opts.from, to = opts && opts.to;
    return (records || []).filter(function (r) {
      var hay;
      if (sid && sid !== 'all' && r.studentId !== sid) return false;
      if (from && r.date < from) return false;
      if (to && r.date > to) return false;
      if (q) {
        hay = [nameOf ? nameOf(r.studentId) : '', r.purpose, r.receiptNo, r.date, formatDate(r.date), r.note, String(r.amount)].map(searchKey).join(' ');
        if (hay.indexOf(q) < 0) return false;
      }
      return true;
    });
  }
  // الفرز للعرض فقط. عند التساوي: التاريخ الأحدث ثم recordId (ترتيب حتمي)
  function sortRecords(records, key, dir, nameOf) {
    var sign = dir === 'asc' ? 1 : -1;
    if (SORTS.indexOf(key) < 0) key = 'date';
    function val(r) {
      if (key === 'student') return searchKey(nameOf ? nameOf(r.studentId) : r.studentId);
      if (key === 'purpose') return searchKey(r.purpose);
      if (key === 'amount') return typeof r.amount === 'number' && isFinite(r.amount) ? r.amount : -1;
      return str(r.date);
    }
    return (records || []).slice().sort(function (a, b) {
      var x = val(a), y = val(b);
      if (x !== y) return (x < y ? -1 : 1) * sign;
      if (a.date !== b.date) return a.date < b.date ? 1 : -1;
      return str(a.recordId) < str(b.recordId) ? -1 : str(a.recordId) > str(b.recordId) ? 1 : 0;
    });
  }

  // ===== الإجماليات (تُحسب للعرض فقط من السجلات المعطاة ولا تُخزَّن) =====
  function validAmount(r) { return r && typeof r.amount === 'number' && Number.isSafeInteger(r.amount) && r.amount > 0; }
  // مجموع قائمة سجلات: السجلات ذات المبلغ غير الصالح تُستثنى وتُعدّ في invalid (لا تُعامل صفراً). overflow إن تجاوز المجموع الحد الآمن.
  function sumRecords(records) {
    var s = 0, n = 0, bad = 0, over = false;
    (records || []).forEach(function (r) {
      if (!validAmount(r)) { bad++; return; }
      if (s + r.amount > Number.MAX_SAFE_INTEGER) { over = true; return; }
      s += r.amount; n++;
    });
    return { count: n, invalid: bad, total: s, overflow: over };
  }
  // مجموع المقبوضات في فترة [from, to] شاملة الطرفين؛ من/إلى فارغ = بلا حد من ذلك الطرف.
  function totalInPeriod(records, from, to) {
    var list = (records || []).filter(function (r) { return (!from || r.date >= from) && (!to || r.date <= to); });
    var s = sumRecords(list);
    s.from = from || ''; s.to = to || ''; s.bounded = !!(from || to);
    return s;
  }
  // إجمالي كل طالب ضمن القائمة المعطاة (التي يمررها المستدعي مفلترة بالفترة نفسها): [{studentId,count,total,invalid}] مرتبة بالأكبر ثم الاسم
  function totalsByStudent(records, nameOf) {
    var map = Object.create(null), out = [], k;
    (records || []).forEach(function (r) { (map[r.studentId] = map[r.studentId] || []).push(r); });
    for (k in map) { var s = sumRecords(map[k]); s.studentId = k; out.push(s); }
    return out.sort(function (a, b) {
      if (a.total !== b.total) return b.total - a.total;
      var x = searchKey(nameOf ? nameOf(a.studentId) : a.studentId), y = searchKey(nameOf ? nameOf(b.studentId) : b.studentId);
      return x < y ? -1 : x > y ? 1 : (a.studentId < b.studentId ? -1 : 1);
    });
  }
  // وصف الفترة للعرض: يوضّح ما يغطيه الإجمالي دائماً
  function periodLabel(from, to) {
    if (from && to) return from === to ? 'يوم ' + formatDate(from) : 'من ' + formatDate(from) + ' إلى ' + formatDate(to);
    if (from) return 'من ' + formatDate(from) + ' حتى الآن';
    if (to) return 'حتى ' + formatDate(to);
    return 'كل السجلات المسجَّلة (بلا تحديد فترة)';
  }
  function validatePeriod(from, to) {
    if (from && !isLocalDate(from)) return 'تاريخ البداية غير صالح.';
    if (to && !isLocalDate(to)) return 'تاريخ النهاية غير صالح.';
    if (from && to && from > to) return 'تاريخ البداية بعد تاريخ النهاية؛ صحّح الفترة.';
    return null;
  }

  return {
    PURPOSE_MAX: PURPOSE_MAX, RECEIPT_MAX: RECEIPT_MAX, NOTE_MAX: NOTE_MAX, MAX_AMOUNT: MAX_AMOUNT, MIN_YEAR: MIN_YEAR, MAX_YEAR: MAX_YEAR, CURRENCY: CURRENCY,
    SORTS: SORTS.slice(), SORT_LABELS: SORT_LABELS,
    oneLine: oneLine, searchKey: searchKey, isLocalDate: isLocalDate, localDate: localDate, formatDate: formatDate,
    parseAmount: parseAmount, formatAmount: formatAmount, validateDate: validateDate, validateEntry: validateEntry, findById: findById,
    findReceiptMatches: findReceiptMatches, planSave: planSave, studentKind: studentKind, filterRecords: filterRecords, sortRecords: sortRecords,
    sumRecords: sumRecords, totalInPeriod: totalInPeriod, totalsByStudent: totalsByStudent, periodLabel: periodLabel, validatePeriod: validatePeriod
  };
});
