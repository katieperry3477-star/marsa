/* MARSA — منطق «التحاضير» (المرحلة 03.3)
 * دوال نقية بلا DOM ولا تخزين: تحقق، تنظيف، تجميع (اليوم / باجر / أخرى)، فرز بالأقرب موعداً، بحث، وتنسيق تاريخ محلي.
 * التخزين نفسه يمرّ حصراً عبر MarsaAcademicStore (النوع preparations).
 * التحضير = ما سيأتي. أما «ما أُخذ فعلاً» فله نوع مستقل (dailyLessons) ولا يُنسخ إليه شيء من هنا. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaPrepsModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var LIMITS = { subject: 80, title: 120, content: 2000, pages: 80, homework: 500, notes: 1000 };
  var MIN_YEAR = 2000, MAX_YEAR = 2100;
  var ORDER = ['subject', 'title', 'date', 'content', 'pages', 'homework', 'notes'];
  var OPTIONAL = ['pages', 'homework', 'notes'];
  var LABELS = { subject: 'المادة', title: 'عنوان الموضوع', date: 'تاريخ التحضير / المذاكرة', content: 'محتوى التحضير / النقاط', pages: 'صفحات الكتاب / المصدر', homework: 'المطلوب / الواجب', notes: 'ملاحظات' };
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  function multiLine(s) {
    return str(s).replace(/\r\n?|\u2028|\u2029/g, '\n').replace(CTRL, '').replace(INVIS, '')
      .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  function searchKey(s) {
    return oneLine(s).replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (!m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  // اليوم + n بالتقويم المحلي (يُبنى Date من الأجزاء المحلية؛ لا UTC ولا Date.parse على النص)
  function addDays(ymd, n) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(ymd)), d;
    if (!m || !isLocalDate(ymd)) return '';
    d = new Date(+m[1], +m[2] - 1, +m[3] + n);
    return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
  }

  // النتيجة: { ok, values, errors:{حقل:رسالة}, firstError }
  // المطلوب: المادة والعنوان والتاريخ والمحتوى. الباقي اختياري.
  function validate(input) {
    var errors = {}, v = {}, i, k, first = null, y;
    input = input || {};
    v.subject = oneLine(input.subject); v.title = oneLine(input.title); v.pages = oneLine(input.pages);
    v.content = multiLine(input.content); v.homework = multiLine(input.homework); v.notes = multiLine(input.notes);
    v.date = str(input.date).trim();
    if (!v.subject) errors.subject = 'اكتب اسم المادة. لا يمكن تركه فارغاً.';
    if (!v.title) errors.title = 'اكتب عنوان الموضوع. لا يمكن تركه فارغاً.';
    if (!v.date) errors.date = 'اختر تاريخ التحضير.';
    else if (!isLocalDate(v.date)) errors.date = 'التاريخ غير صالح. استخدم الصيغة YYYY-MM-DD ويوماً موجوداً في التقويم.';
    else { y = +v.date.slice(0, 4); if (y < MIN_YEAR || y > MAX_YEAR) errors.date = 'التاريخ خارج النطاق المنطقي (' + MIN_YEAR + ' إلى ' + MAX_YEAR + ').'; }
    if (!v.content) errors.content = 'اكتب محتوى التحضير أو نقاطه. لا يمكن تركه فارغاً.';
    for (k in LIMITS) if (!errors[k] && v[k].length > LIMITS[k]) errors[k] = LABELS[k] + ' أطول من ' + LIMITS[k] + ' حرفاً (طوله الآن ' + v[k].length + '). اختصره ثم احفظ.';
    for (i = 0; i < ORDER.length; i++) if (errors[ORDER[i]]) { first = ORDER[i]; break; }
    return { ok: first === null, values: v, errors: errors, firstError: first };
  }

  // يبني السجل للحفظ. existing (عند التعديل) يُنسخ كاملاً فيبقى recordId وclassId وأي حقل آخر كما هو.
  // الحقول الاختيارية الفارغة تُحذف. لا يُنشأ recordId هنا أبداً.
  function buildRecord(values, existing) {
    var r = {}, k, i;
    if (existing && typeof existing === 'object') for (k in existing) if (Object.prototype.hasOwnProperty.call(existing, k)) r[k] = existing[k];
    r.subject = values.subject; r.title = values.title; r.date = values.date; r.content = values.content;
    for (i = 0; i < OPTIONAL.length; i++) { k = OPTIONAL[i]; if (values[k]) r[k] = values[k]; else delete r[k]; }
    return r;
  }

  function field(r, k) { return r && typeof r[k] === 'string' ? r[k] : ''; }

  // الأقرب موعداً أولاً: ما هو اليوم فما بعده تصاعدياً، ثم ما مضى موعده من الأحدث إلى الأقدم، ثم بلا تاريخ صالح.
  // عند تساوي اليوم: الأقدم إنشاءً أولاً ثم المعرّف (ترتيب ثابت).
  function rank(date, today) { return !isLocalDate(date) ? 2 : date >= today ? 0 : 1; }
  function sortRecords(list, today) {
    return list.slice().sort(function (a, b) {
      var da = field(a, 'date'), db = field(b, 'date'), ra = rank(da, today), rb = rank(db, today), ca, cb;
      if (ra !== rb) return ra - rb;
      if (da !== db && ra !== 2) return ra === 0 ? (da < db ? -1 : 1) : (da < db ? 1 : -1);
      ca = field(a, 'createdAt'); cb = field(b, 'createdAt');
      if (ca !== cb) return ca < cb ? -1 : 1;
      return field(a, 'recordId') < field(b, 'recordId') ? -1 : field(a, 'recordId') > field(b, 'recordId') ? 1 : 0;
    });
  }
  // today = اليوم المحلي YYYY-MM-DD. تُحسب «باجر» من اليوم بالتقويم المحلي.
  function groupByDay(list, today) {
    var sorted = sortRecords(list, today), tomorrow = addDays(today, 1), g = { today: [], tomorrow: [], other: [], tomorrowDate: tomorrow };
    sorted.forEach(function (r) {
      var d = field(r, 'date');
      if (d === today) g.today.push(r); else if (d === tomorrow) g.tomorrow.push(r); else g.other.push(r);
    });
    return g;
  }
  // بحث بالمادة أو العنوان فقط
  function filterRecords(list, query) {
    var q = searchKey(query);
    if (!q) return list.slice();
    return list.filter(function (r) { return searchKey(field(r, 'title')).indexOf(q) > -1 || searchKey(field(r, 'subject')).indexOf(q) > -1; });
  }
  // المواد التي كتبها المستخدم نفسه في تحاضير هذا الصف (اقتراحات إدخال فقط؛ لا قائمة ثابتة)
  function subjectsOf(list) {
    var seen = {}, out = [];
    list.slice().sort(function (a, b) { var x = field(a, 'updatedAt'), y = field(b, 'updatedAt'); return x === y ? 0 : x < y ? 1 : -1; }).forEach(function (r) {
      var s = oneLine(field(r, 'subject')), k = searchKey(s);
      if (s && !seen[k]) { seen[k] = 1; out.push(s); }
    });
    return out;
  }
  function formatDate(ymd) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(ymd)), d;
    if (!m || !isLocalDate(ymd)) return str(ymd) ? str(ymd) : 'بلا تاريخ';
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    try { return new Intl.DateTimeFormat('ar-u-ca-gregory-nu-latn', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(d); }
    catch (e) { return ymd; }
  }

  return { LIMITS: LIMITS, MIN_YEAR: MIN_YEAR, MAX_YEAR: MAX_YEAR, LABELS: LABELS, validate: validate, buildRecord: buildRecord, sortRecords: sortRecords, groupByDay: groupByDay, filterRecords: filterRecords, subjectsOf: subjectsOf, formatDate: formatDate, addDays: addDays, searchKey: searchKey, isLocalDate: isLocalDate, oneLine: oneLine, multiLine: multiLine, field: field };
});
