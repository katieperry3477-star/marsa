/* MARSA — منطق «الامتحانات» (المرحلة 03.5)
 * دوال نقية بلا DOM ولا تخزين: تحقق، تنظيف، تقسيم (قادمة / سابقة ومنتهية)، فرز بالأقرب موعداً، وتنسيق تاريخ محلي.
 * التخزين نفسه يمرّ حصراً عبر MarsaAcademicStore (النوع exams). السجل لا يحمل درجات ولا أسئلة: هذه مرحلة لاحقة.
 * القاعدة: التاريخ والحالة معاً يحددان المكان. مضيّ التاريخ وحده لا يجعل الامتحان «أُلغي» ولا «أُجري». */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaExamsModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var LIMITS = { subject: 80, title: 120, topics: 1500, notes: 1000 };
  var MIN_YEAR = 2000, MAX_YEAR = 2100;
  var ORDER = ['subject', 'title', 'examDate', 'status', 'topics', 'notes'];
  var OPTIONAL = ['topics', 'notes'];
  var STATUSES = ['scheduled', 'held', 'cancelled'];
  var STATUS_LABELS = { scheduled: 'مجدول', held: 'أُجري', cancelled: 'أُلغي' };
  var LABELS = { subject: 'المادة', title: 'عنوان / نوع الامتحان', examDate: 'تاريخ الامتحان', status: 'الحالة', topics: 'نطاق المواضيع / الفصول المطلوبة', notes: 'ملاحظات أو تعليمات' };
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  function multiLine(s) {
    return str(s).replace(/\r\n?|\u2028|\u2029/g, '\n').replace(CTRL, '').replace(INVIS, '')
      .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (!m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function addDays(ymd, n) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(ymd)), d;
    if (!m || !isLocalDate(ymd)) return '';
    d = new Date(+m[1], +m[2] - 1, +m[3] + n);
    return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
  }
  // عدد الأيام بين تاريخين محليين بالتقويم (Date.UTC من الأجزاء فقط: لا يتأثر بتغيير التوقيت الصيفي)
  function daysBetween(fromYmd, toYmd) {
    var a = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(fromYmd)), b = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(toYmd));
    if (!a || !b || !isLocalDate(fromYmd) || !isLocalDate(toYmd)) return null;
    return Math.round((Date.UTC(+b[1], +b[2] - 1, +b[3]) - Date.UTC(+a[1], +a[2] - 1, +a[3])) / 86400000);
  }

  // النتيجة: { ok, values, errors:{حقل:رسالة}, firstError }
  // المطلوب: المادة والعنوان والتاريخ والحالة. نطاق المواضيع والملاحظات اختياريان.
  function validate(input) {
    var errors = {}, v = {}, i, k, first = null, y;
    input = input || {};
    v.subject = oneLine(input.subject); v.title = oneLine(input.title);
    v.topics = multiLine(input.topics); v.notes = multiLine(input.notes);
    v.examDate = str(input.examDate).trim();
    v.status = input.status === undefined || input.status === null || input.status === '' ? 'scheduled' : str(input.status);
    if (!v.subject) errors.subject = 'اكتب اسم المادة. لا يمكن تركه فارغاً.';
    if (!v.title) errors.title = 'اكتب عنوان الامتحان أو نوعه (مثل: امتحان شهري). لا يمكن تركه فارغاً.';
    if (!v.examDate) errors.examDate = 'اختر تاريخ الامتحان.';
    else if (!isLocalDate(v.examDate)) errors.examDate = 'التاريخ غير صالح. استخدم الصيغة YYYY-MM-DD ويوماً موجوداً في التقويم.';
    else { y = +v.examDate.slice(0, 4); if (y < MIN_YEAR || y > MAX_YEAR) errors.examDate = 'التاريخ خارج النطاق المنطقي (' + MIN_YEAR + ' إلى ' + MAX_YEAR + ').'; }
    if (STATUSES.indexOf(v.status) < 0) errors.status = 'الحالة غير صالحة. اختر مجدول أو أُجري أو أُلغي.';
    for (k in LIMITS) if (!errors[k] && v[k].length > LIMITS[k]) errors[k] = LABELS[k] + ' أطول من ' + LIMITS[k] + ' حرفاً (طوله الآن ' + v[k].length + '). اختصره ثم احفظ.';
    for (i = 0; i < ORDER.length; i++) if (errors[ORDER[i]]) { first = ORDER[i]; break; }
    return { ok: first === null, values: v, errors: errors, firstError: first };
  }

  // يبني السجل للحفظ. existing (عند التعديل) يُنسخ كاملاً فيبقى recordId وclassId وأي حقل آخر كما هو.
  // الحقول الاختيارية الفارغة تُحذف. لا يُنشأ recordId هنا أبداً. لا حقل درجة ولا أسئلة.
  function buildRecord(values, existing) {
    var r = {}, k, i;
    if (existing && typeof existing === 'object') for (k in existing) if (Object.prototype.hasOwnProperty.call(existing, k)) r[k] = existing[k];
    r.subject = values.subject; r.title = values.title; r.examDate = values.examDate; r.status = values.status;
    for (i = 0; i < OPTIONAL.length; i++) { k = OPTIONAL[i]; if (values[k]) r[k] = values[k]; else delete r[k]; }
    return r;
  }

  function field(r, k) { return r && typeof r[k] === 'string' ? r[k] : ''; }
  // الحالة المخزّنة إن كانت معروفة، وإلا «مجدول» (سجل بلا حالة أو بحالة غير معروفة لا يُخفى ولا يُعدَّل تلقائياً)
  function statusOf(r) { var s = field(r, 'status'); return STATUSES.indexOf(s) > -1 ? s : 'scheduled'; }
  function dateOf(r) { return field(r, 'examDate'); }

  function cmpTail(a, b) {
    var ca = field(a, 'createdAt'), cb = field(b, 'createdAt'), ia = field(a, 'recordId'), ib = field(b, 'recordId');
    if (ca !== cb) return ca < cb ? -1 : 1;
    return ia < ib ? -1 : ia > ib ? 1 : 0;
  }
  // القادمة: الحالة «مجدول» والتاريخ اليوم أو بعده (يوم الامتحان نفسه يبقى «قادماً» حتى منتصف الليل؛ لا وقت محدد للامتحان).
  // السابقة والمنتهية: كل ما عدا ذلك — «أُجري» و«أُلغي» بأي تاريخ، و«مجدول» مضى تاريخه (يُوسَم «مضى موعده» ولا يُعدّ ملغى)، وبلا تاريخ صالح.
  function isUpcoming(r, today) { var d = dateOf(r); return statusOf(r) === 'scheduled' && isLocalDate(d) && d >= today; }
  function isOverdue(r, today) { var d = dateOf(r); return statusOf(r) === 'scheduled' && isLocalDate(d) && d < today; }
  function partition(list, today) {
    var up = [], fin = [];
    list.forEach(function (r) { (isUpcoming(r, today) ? up : fin).push(r); });
    up.sort(function (a, b) { var da = dateOf(a), db = dateOf(b); return da !== db ? (da < db ? -1 : 1) : cmpTail(a, b); });
    fin.sort(function (a, b) {
      var da = dateOf(a), db = dateOf(b), va = isLocalDate(da), vb = isLocalDate(db);
      if (va !== vb) return va ? -1 : 1;
      if (va && da !== db) return da < db ? 1 : -1; // الأحدث أولاً
      return cmpTail(a, b);
    });
    return { upcoming: up, finished: fin };
  }
  // وصف القرب من اليوم للقادمة فقط
  function relativeLabel(ymd, today) {
    var n = daysBetween(today, ymd);
    if (n === null) return '';
    if (n === 0) return 'اليوم';
    if (n === 1) return 'باجر';
    if (n === 2) return 'بعد يومين';
    if (n >= 3 && n <= 10) return 'بعد ' + n + ' أيام';
    if (n > 10) return 'بعد ' + n + ' يوماً';
    return '';
  }
  // المواد التي كتبها المستخدم نفسه في امتحانات هذا الصف (اقتراحات إدخال فقط؛ لا قائمة ثابتة)
  function subjectsOf(list) {
    var seen = {}, out = [];
    list.slice().sort(function (a, b) { var x = field(a, 'updatedAt'), y = field(b, 'updatedAt'); return x === y ? 0 : x < y ? 1 : -1; }).forEach(function (r) {
      var s = oneLine(field(r, 'subject')), k = s.replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
      if (s && !seen[k]) { seen[k] = 1; out.push(s); }
    });
    return out;
  }
  // بحث نصي (03.8) بالمادة أو العنوان أو المواضيع؛ يطبّع الهمزات والتشكيل. دالة نقية لا تعدّل القائمة.
  function searchKey(s) {
    return oneLine(s).replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function filterRecords(list, query) {
    var q = searchKey(query);
    if (!q) return list.slice();
    return list.filter(function (r) { return searchKey(field(r, 'subject')).indexOf(q) > -1 || searchKey(field(r, 'title')).indexOf(q) > -1 || searchKey(field(r, 'topics')).indexOf(q) > -1; });
  }
  function formatDate(ymd) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(ymd)), d;
    if (!m || !isLocalDate(ymd)) return str(ymd) ? str(ymd) : 'بلا تاريخ';
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    try { return new Intl.DateTimeFormat('ar-u-ca-gregory-nu-latn', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(d); }
    catch (e) { return ymd; }
  }

  return { LIMITS: LIMITS, MIN_YEAR: MIN_YEAR, MAX_YEAR: MAX_YEAR, STATUSES: STATUSES, STATUS_LABELS: STATUS_LABELS, LABELS: LABELS, validate: validate, buildRecord: buildRecord, partition: partition, isUpcoming: isUpcoming, isOverdue: isOverdue, statusOf: statusOf, relativeLabel: relativeLabel, daysBetween: daysBetween, subjectsOf: subjectsOf, filterRecords: filterRecords, searchKey: searchKey, formatDate: formatDate, addDays: addDays, isLocalDate: isLocalDate, oneLine: oneLine, multiLine: multiLine, field: field };
});
