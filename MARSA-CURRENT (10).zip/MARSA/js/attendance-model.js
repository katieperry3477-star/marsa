/* MARSA — منطق «الحضور والغياب» (المرحلة 4.03)
 * دوال نقية بلا DOM ولا تخزين: تنظيف وتحقق وترتيب وبحث وتجميع وتخطيط الحفظ.
 * التخزين يمرّ حصراً عبر MarsaAcademicStore (النوع attendance). المعرّف الثابت للطالب هو studentId، لا رقم القائمة ولا الاسم. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaAttendanceModel = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var STATUSES = ['present', 'absent', 'late', 'excused'];
  var LABELS = { present: 'حاضر', absent: 'غائب', late: 'متأخر', excused: 'بعذر' };
  var UNRECORDED = 'لم يُسجَّل';
  var NOTE_MAX = 200, MIN_YEAR = 2000, MAX_YEAR = 2100;
  var ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
  var INVIS = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

  function str(x) { return typeof x === 'string' ? x : (x == null ? '' : String(x)); }
  function oneLine(s) { return str(s).replace(CTRL, '').replace(INVIS, '').replace(/\s+/g, ' ').trim(); }
  // مفتاح بحث: يوحّد الألف والياء والتاء المربوطة ويزيل التشكيل والتطويل
  function searchKey(s) {
    return oneLine(s).replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (typeof s !== 'string' || !m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }
  // تاريخ محلي من أجزاء Date المحلية (لا toISOString فلا ينتقل اليوم بسبب UTC)
  function localDate(d) {
    d = d || new Date();
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function addDays(iso, n) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    if (!m) return null;
    return localDate(new Date(+m[1], +m[2] - 1, +m[3] + n));
  }
  function formatDate(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str(iso));
    return m && isLocalDate(iso) ? m[3] + '/' + m[2] + '/' + m[1] : (str(iso) || '(بلا تاريخ)');
  }
  function isStatus(s) { return STATUSES.indexOf(s) > -1; }
  function label(s) { return isStatus(s) ? LABELS[s] : UNRECORDED; }
  function cleanNote(s) { return oneLine(s); }

  // ===== التحقق =====
  // تاريخ الحضور: صيغة صالحة، داخل النطاق، وليس بعد اليوم المحلي (today)
  function validateDate(date, today) {
    var d = str(date).trim(), y;
    if (!d) return 'اختر تاريخ الحضور.';
    if (!isLocalDate(d)) return 'التاريخ غير صالح. استخدم يوماً موجوداً في التقويم بصيغة YYYY-MM-DD.';
    y = +d.slice(0, 4);
    if (y < MIN_YEAR || y > MAX_YEAR) return 'التاريخ خارج النطاق المنطقي (' + MIN_YEAR + ' إلى ' + MAX_YEAR + ').';
    if (today && d > today) return 'لا يمكن تسجيل حضور ليوم بعد اليوم المحلي.';
    return null;
  }
  // يتحقق من إدخال واحد { studentId, date, status, note } مقابل قائمة طلاب الصف الفعّالين (studentIds).
  // ctx = { today, activeIds: [..] }. النتيجة: { ok, values, errors }
  function validateEntry(input, ctx) {
    var e = {}, v = {}, ids, i, found = false;
    input = input || {}; ctx = ctx || {};
    v.studentId = str(input.studentId).trim();
    v.date = str(input.date).trim();
    v.status = str(input.status).trim();
    v.note = cleanNote(input.note);
    if (!ID_RE.test(v.studentId)) e.studentId = 'معرّف الطالب غير صالح.';
    else if (Array.isArray(ctx.activeIds)) {
      ids = ctx.activeIds;
      for (i = 0; i < ids.length; i++) if (ids[i] === v.studentId) { found = true; break; }
      if (!found) e.studentId = 'الطالب ليس ضمن الطلاب الفعّالين في هذا الصف.';
    }
    e.date = validateDate(v.date, ctx.today) || undefined; if (!e.date) delete e.date;
    if (!isStatus(v.status)) e.status = 'اختر حالة الحضور: حاضر أو غائب أو متأخر أو بعذر.';
    if (v.note.length > NOTE_MAX) e.note = 'الملاحظة أطول من ' + NOTE_MAX + ' حرفاً (طولها الآن ' + v.note.length + ').';
    return { ok: Object.keys(e).length === 0, values: v, errors: e };
  }

  // ===== التكرار والتضارب =====
  function pairKey(r) { return str(r && r.studentId) + '|' + str(r && r.date); }
  // مجموعات السجلات التي تشترك في (studentId, date). لا تحذف شيئاً ولا تختار فائزاً.
  function findConflicts(records) {
    var map = Object.create(null), out = [], k;
    (records || []).forEach(function (r) { var key = pairKey(r); (map[key] = map[key] || []).push(r); });
    for (k in map) if (map[k].length > 1) out.push({ studentId: map[k][0].studentId, date: map[k][0].date, recordIds: map[k].map(function (r) { return r.recordId; }) });
    return out;
  }
  function findByPair(records, studentId, date) {
    var i;
    for (i = 0; i < (records || []).length; i++) if (records[i].studentId === studentId && records[i].date === date) return records[i];
    return null;
  }

  // ===== بناء الصفوف ليوم واحد =====
  // students: الطلاب الفعّالون مرتبين أبجدياً [{studentId,name,studentCode}] — رقم القائمة = الترتيب + 1 (للعرض فقط).
  // allStudents: كل طلاب الصف (فعّالون ومؤرشفون) لتسمية السجلات القديمة.
  // النتيجة: { rows:[{studentId,name,studentCode,number,record,status}], legacy:[{record,name,kind}] }
  // لا تحويل تلقائي إلى «حاضر»: الطالب بلا سجل يبقى status=null.
  function buildDay(students, allStudents, records, date) {
    var act = Object.create(null), nm = Object.create(null), day = (records || []).filter(function (r) { return r.date === date; }), rows = [], legacy = [];
    (students || []).forEach(function (s) { act[s.studentId] = 1; });
    (allStudents || []).forEach(function (s) { nm[s.studentId] = s; });
    rows = (students || []).map(function (s, i) {
      var rec = findByPair(day, s.studentId, date);
      return { studentId: s.studentId, name: s.name, studentCode: s.studentCode || '', number: i + 1, record: rec, status: rec ? rec.status : null };
    });
    day.forEach(function (r) {
      var s;
      if (act[r.studentId]) return;
      s = nm[r.studentId];
      legacy.push({ record: r, name: s ? s.name : '', kind: s ? 'archived' : 'unknown' });
    });
    return { rows: rows, legacy: legacy };
  }

  // عدّادات اليوم من صفوف الطلاب الفعّالين فقط (السجلات القديمة لا تدخل العدّ)
  function countRows(rows) {
    var c = { present: 0, absent: 0, late: 0, excused: 0, unrecorded: 0, total: 0 };
    (rows || []).forEach(function (r) { c.total++; if (isStatus(r.status)) c[r.status]++; else c.unrecorded++; });
    return c;
  }

  // بحث بالاسم أو الكود + فلتر حالة ('all' | 'unrecorded' | أحد الحالات الأربع)
  function filterRows(rows, opts) {
    var q = searchKey(opts && opts.query), st = (opts && opts.status) || 'all';
    return (rows || []).filter(function (r) {
      if (st === 'unrecorded' && isStatus(r.status)) return false;
      if (isStatus(st) && r.status !== st) return false;
      if (q && searchKey(r.name).indexOf(q) < 0 && searchKey(r.studentCode).indexOf(q) < 0) return false;
      return true;
    });
  }

  // ===== ملخص الأيام (سجل الأيام) =====
  // from/to اختياريان (شاملان). activeIds: يعدّ سجلات الطلاب الفعّالين فقط؛ سجلات غيرهم تُعدّ في legacy منفصلة.
  // النتيجة: مصفوفة أيام من الأحدث: { date, present, absent, late, excused, legacy, total }
  function summarizeDays(records, opts) {
    var from = opts && opts.from, to = opts && opts.to, st = opts && opts.status, act = Object.create(null), map = Object.create(null), out = [];
    ((opts && opts.activeIds) || []).forEach(function (id) { act[id] = 1; });
    (records || []).forEach(function (r) {
      var d;
      if (from && r.date < from) return;
      if (to && r.date > to) return;
      d = map[r.date] = map[r.date] || { date: r.date, present: 0, absent: 0, late: 0, excused: 0, legacy: 0, total: 0 };
      if (!act[r.studentId]) { d.legacy++; return; }
      if (isStatus(r.status)) { d[r.status]++; d.total++; }
    });
    Object.keys(map).forEach(function (k) {
      var d = map[k];
      if (isStatus(st) && !d[st]) return;
      out.push(d);
    });
    return out.sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : 0; });
  }

  // ===== تخطيط الحفظ =====
  // draft: { studentId: { status, note } }؛ fresh: السجلات الحالية من المتجر (تُقرأ لحظة الحفظ لا من نسخة قديمة).
  // النتيجة: { ok, records:[..], created, updated, unchanged, errors:[{studentId,message}] }
  // سجل قائم لنفس (studentId,date) يُنسخ كاملاً فيبقى recordId وclassId؛ لا يُنشأ هنا recordId جديد أبداً (يُنشئه المتجر).
  function planSave(draft, fresh, ctx) {
    var out = { ok: true, records: [], created: 0, updated: 0, unchanged: 0, errors: [] }, ids = Object.keys(draft || {});
    ctx = ctx || {};
    ids.forEach(function (sid) {
      var d = draft[sid] || {}, res, ex, rec, k;
      if (!isStatus(d.status)) return; // لم يختر المستخدم حالة: لا سجل ولا تحويل تلقائي
      res = validateEntry({ studentId: sid, date: ctx.date, status: d.status, note: d.note }, { today: ctx.today, activeIds: ctx.activeIds });
      if (!res.ok) { out.ok = false; out.errors.push({ studentId: sid, message: res.errors.studentId || res.errors.date || res.errors.status || res.errors.note }); return; }
      ex = findByPair(fresh, sid, ctx.date);
      if (ex && ex.status === res.values.status && str(ex.note) === res.values.note) { out.unchanged++; return; }
      if (ex) { rec = {}; for (k in ex) if (Object.prototype.hasOwnProperty.call(ex, k)) rec[k] = ex[k]; out.updated++; }
      else { rec = { studentId: sid, date: ctx.date }; out.created++; }
      rec.status = res.values.status;
      if (res.values.note) rec.note = res.values.note; else delete rec.note;
      out.records.push(rec);
    });
    return out;
  }

  // هل المسودة تختلف عن المحفوظ؟ (لتحذير فقد التغييرات)
  function isDirty(draft, rows) {
    var i, r, d;
    for (i = 0; i < (rows || []).length; i++) {
      r = rows[i]; d = (draft || {})[r.studentId] || {};
      if ((d.status || null) !== (r.status || null)) return true;
      if (cleanNote(d.note) !== cleanNote(r.record && r.record.note)) return true;
    }
    return false;
  }

  // سجلات مرتبة من الأحدث تاريخاً ثم الاسم (nameOf: studentId → اسم للعرض فقط)
  function sortRecords(records, nameOf) {
    return (records || []).slice().sort(function (a, b) {
      if (a.date !== b.date) return a.date < b.date ? 1 : -1;
      var x = nameOf ? str(nameOf(a.studentId)) : a.studentId, y = nameOf ? str(nameOf(b.studentId)) : b.studentId;
      return x < y ? -1 : x > y ? 1 : 0;
    });
  }

  return {
    STATUSES: STATUSES.slice(), LABELS: LABELS, UNRECORDED: UNRECORDED, NOTE_MAX: NOTE_MAX, MIN_YEAR: MIN_YEAR, MAX_YEAR: MAX_YEAR,
    oneLine: oneLine, searchKey: searchKey, isLocalDate: isLocalDate, localDate: localDate, addDays: addDays, formatDate: formatDate,
    isStatus: isStatus, label: label, cleanNote: cleanNote, validateDate: validateDate, validateEntry: validateEntry,
    findConflicts: findConflicts, findByPair: findByPair, buildDay: buildDay, countRows: countRows, filterRows: filterRows,
    summarizeDays: summarizeDays, planSave: planSave, isDirty: isDirty, sortRecords: sortRecords
  };
});
