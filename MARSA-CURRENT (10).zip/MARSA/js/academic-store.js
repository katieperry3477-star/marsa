/* MARSA — طبقة التخزين الأكاديمي (المرحلة 03.1؛ وسّعتها 4.02 بأنواع attendance وgrades وpayments)
 * محلية فقط: لا قاعدة بيانات ولا مزامنة. لا تلمس مفاتيح الطلاب أو الصفوف.
 * المفتاح: marsa.academic.<type>.<classId> والقيمة { schemaVersion, classId, records }.
 * لاستبدال التخزين لاحقاً: مرّر كائناً بواجهة getItem/setItem/removeItem إلى create({ storage }). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MarsaAcademicStore = api.create();
  if (typeof window !== 'undefined') window.MarsaAcademicStoreFactory = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var SCHEMA = 1, PREFIX = 'marsa.academic.';
  var TYPES = ['dailyLessons', 'preparations', 'schedule', 'exams', 'attendance', 'grades', 'payments'];
  var ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
  var ID_PREFIX = { dailyLessons: 'dl', preparations: 'prep', schedule: 'sch', exams: 'exam', attendance: 'att', grades: 'grd', payments: 'pay' };
  // 4.02: الأنواع الجديدة فقط تخضع للتحقق النوعي؛ الأنواع الأربعة القديمة تبقى بسلوكها حرفياً
  var TYPED = { attendance: 1, grades: 1, payments: 1 };
  var ATTENDANCE_STATUSES = ['present', 'absent', 'late', 'excused'];
  var LIMITS = { note: 200, subject: 80, title: 80, purpose: 80, receiptNo: 40, maxScoreMax: 1000, batchMax: 500 };
  var BASE_FIELDS = ['recordId', 'classId', 'studentId', 'date', 'createdAt', 'updatedAt'];
  var TYPED_FIELDS = {
    attendance: BASE_FIELDS.concat(['status', 'note']),
    grades: BASE_FIELDS.concat(['subject', 'title', 'score', 'maxScore', 'note']),
    payments: BASE_FIELDS.concat(['amount', 'purpose', 'receiptNo', 'note'])
  };
  var TRIM_FIELDS = ['subject', 'title', 'purpose', 'receiptNo', 'note'];
  var DATE_FIELDS = ['date', 'dueDate', 'examDate'], TIME_FIELDS = ['time', 'startTime', 'endTime'];

  function isPlain(o) { return !!o && typeof o === 'object' && !Array.isArray(o); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  // تاريخ دراسي محلي YYYY-MM-DD (بلا UTC حتى لا ينزاح اليوم في العراق)
  function isLocalDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d;
    if (!m) return false;
    d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
  }
  function isTime(s) { return typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s); }
  function toLocalDate(d) {
    d = d || new Date();
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }

  // توحيد النص للمقارنة فقط (لا يُخزَّن): تقليم + طي المسافات + إزالة التشكيل + توحيد الهمزات (كما في بحث الدروس)
  function foldText(s) {
    return String(s).replace(/\s+/g, ' ').trim().replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();
  }
  function textLen(v, min, max) { return typeof v === 'string' && v.trim().length >= min && v.trim().length <= max; }
  function optText(v, max) { return v === undefined || (typeof v === 'string' && v.trim().length <= max); }
  function maxTwoDecimals(n) { return Math.round(n * 100) / 100 === n; }
  function isNum(n) { return typeof n === 'number' && isFinite(n); }
  // المفتاح الطبيعي الفريد داخل الصف؛ null = لا قيد تفرّد (المدفوعات: دفعتان متطابقتان قد تكونان مشروعتين)
  function uniqueKey(type, r) {
    if (type === 'attendance') return r.studentId + '\u0001' + r.date;
    if (type === 'grades') return r.studentId + '\u0001' + foldText(r.subject) + '\u0001' + foldText(r.title) + '\u0001' + r.date;
    return null;
  }
  // تحقق نوعي للأنواع الجديدة. يُرجع نص الخطأ أو null
  function validateTyped(r, type) {
    if (typeof r.studentId !== 'string' || !ID_RE.test(r.studentId)) return 'studentId مفقود أو غير صالح.';
    if (typeof r.date !== 'string' || !isLocalDate(r.date)) return 'date مطلوب بصيغة YYYY-MM-DD.';
    if (!optText(r.note, LIMITS.note)) return 'note ليست نصاً أو تتجاوز ' + LIMITS.note + ' حرفاً.';
    if (type === 'attendance') {
      if (ATTENDANCE_STATUSES.indexOf(r.status) < 0) return 'status غير صالح (present/absent/late/excused).';
    } else if (type === 'grades') {
      if (!textLen(r.subject, 1, LIMITS.subject)) return 'subject مطلوب (1–' + LIMITS.subject + ' حرفاً).';
      if (!textLen(r.title, 1, LIMITS.title)) return 'title مطلوب (1–' + LIMITS.title + ' حرفاً).';
      if (!isNum(r.maxScore) || r.maxScore <= 0 || r.maxScore > LIMITS.maxScoreMax || !maxTwoDecimals(r.maxScore)) return 'maxScore يجب أن يكون رقماً أكبر من 0 وحتى ' + LIMITS.maxScoreMax + ' بخانتين عشريتين كحد أقصى.';
      if (!isNum(r.score) || r.score < 0 || r.score > r.maxScore || !maxTwoDecimals(r.score)) return 'score يجب أن يكون رقماً بين 0 والدرجة القصوى بخانتين عشريتين كحد أقصى.';
    } else if (type === 'payments') {
      if (typeof r.amount !== 'number' || !Number.isSafeInteger(r.amount) || r.amount <= 0) return 'amount يجب أن يكون عدداً صحيحاً موجباً.';
      if (!textLen(r.purpose, 1, LIMITS.purpose)) return 'purpose مطلوب (1–' + LIMITS.purpose + ' حرفاً).';
      if (!optText(r.receiptNo, LIMITS.receiptNo)) return 'receiptNo ليس نصاً أو يتجاوز ' + LIMITS.receiptNo + ' حرفاً.';
    }
    return null;
  }
  function trimTyped(r) { TRIM_FIELDS.forEach(function (f) { if (typeof r[f] === 'string') r[f] = r[f].trim(); }); }
  function unknownField(r, type) { var k; for (k in r) if (Object.prototype.hasOwnProperty.call(r, k) && TYPED_FIELDS[type].indexOf(k) < 0) return k; return null; }

  function create(opts) {
    opts = opts || {};
    var memory = {}, memoryMode = false, counter = 0;
    var backend = opts.storage !== undefined ? opts.storage : null;
    if (opts.storage === undefined) { try { backend = typeof localStorage !== 'undefined' ? localStorage : null; } catch (e) { backend = null; } }
    var now = opts.now || function () { return new Date().getTime(); };

    function keyFor(type, classId) { return PREFIX + type + '.' + classId; }
    function checkArgs(type, classId) {
      if (TYPES.indexOf(type) < 0) return 'نوع بيانات غير مدعوم: ' + type;
      if (typeof classId !== 'string' || !ID_RE.test(classId)) return 'معرّف الصف غير صالح.';
      return null;
    }
    function fail(status, error, extra) { var r = { ok: false, status: status, error: error, records: [], persistent: !memoryMode }; for (var k in extra) r[k] = extra[k]; return r; }

    // قراءة خام: { avail, raw }
    function rawGet(key) {
      if (memoryMode) return { avail: true, raw: Object.prototype.hasOwnProperty.call(memory, key) ? memory[key] : null };
      try { if (!backend) throw new Error('none'); return { avail: true, raw: backend.getItem(key) }; }
      catch (e) { memoryMode = true; return { avail: true, raw: memory[key] === undefined ? null : memory[key] }; }
    }
    // كتابة مع تحقق بإعادة القراءة؛ تُرجع 'ok' | 'quota' | 'verify'
    function rawSet(key, value) {
      var prev, back;
      if (memoryMode) { memory[key] = value; return 'ok'; }
      try {
        prev = backend.getItem(key);
        backend.setItem(key, value);
        back = backend.getItem(key);
        if (back !== value) { try { if (prev === null) backend.removeItem(key); else backend.setItem(key, prev); } catch (e2) { /* تجاهل */ } return 'verify'; }
        return 'ok';
      } catch (e) {
        if (!backend) { memoryMode = true; memory[key] = value; return 'ok'; }
        return 'quota';
      }
    }
    function backupRaw(key, raw) {
      var base = key + '.backup', i, k, name;
      try {
        if (memoryMode) { for (k in memory) if (k.indexOf(base) === 0 && memory[k] === raw) return true; name = memory[base] === undefined ? base : base + '.' + now().toString(36) + '-' + (++counter); memory[name] = raw; return true; }
        for (i = 0; i < backend.length; i++) { k = backend.key(i); if (k && k.indexOf(base) === 0 && backend.getItem(k) === raw) return true; }
        name = backend.getItem(base) === null ? base : base + '.' + now().toString(36) + '-' + (++counter);
        backend.setItem(name, raw);
        return backend.getItem(name) === raw;
      } catch (e) { return false; }
    }

    function validateRecord(r, classId, type) {
      var i, f;
      if (!isPlain(r)) return 'سجل ليس كائناً.';
      if (typeof r.recordId !== 'string' || !ID_RE.test(r.recordId)) return 'recordId مفقود أو غير صالح.';
      if (r.classId !== classId) return 'classId السجل لا يطابق الصف.';
      for (i = 0; i < DATE_FIELDS.length; i++) { f = DATE_FIELDS[i]; if (r[f] !== undefined && r[f] !== null && r[f] !== '' && !isLocalDate(r[f])) return 'الحقل ' + f + ' ليس تاريخاً بصيغة YYYY-MM-DD.'; }
      for (i = 0; i < TIME_FIELDS.length; i++) { f = TIME_FIELDS[i]; if (r[f] !== undefined && r[f] !== null && r[f] !== '' && !isTime(r[f])) return 'الحقل ' + f + ' ليس وقتاً بصيغة HH:MM.'; }
      if (TYPED[type]) return validateTyped(r, type);
      return null;
    }
    function validateRecords(list, classId, type) {
      var seen = Object.create(null), keys = Object.create(null), i, e, k;
      if (!Array.isArray(list)) return 'records ليست قائمة.';
      for (i = 0; i < list.length; i++) {
        e = validateRecord(list[i], classId, type);
        if (e) return e;
        if (seen[list[i].recordId]) return 'recordId مكرر: ' + list[i].recordId;
        seen[list[i].recordId] = 1;
        k = TYPED[type] ? uniqueKey(type, list[i]) : null;
        if (k !== null) { if (keys[k]) return 'سجل مكرر لنفس المفتاح الطبيعي (' + type + ') — ' + list[i].recordId + ' و' + keys[k]; keys[k] = list[i].recordId; }
      }
      return null;
    }

    // قراءة مجموعة: لا تكتب شيئاً إلا نسخة احتياطية خام عند التلف
    function readCollection(type, classId) {
      var bad = checkArgs(type, classId), key, g, data, err, bk;
      if (bad) return fail('invalid-args', bad);
      key = keyFor(type, classId);
      g = rawGet(key);
      if (g.raw === null) return { ok: true, status: 'empty', records: [], persistent: !memoryMode, warning: memoryMode ? 'التخزين الدائم غير متاح؛ البيانات مؤقتة وتزول بإغلاق الصفحة.' : undefined };
      try { data = JSON.parse(g.raw); } catch (e) { data = undefined; }
      if (!isPlain(data) || typeof data.schemaVersion !== 'number') err = ['corrupt', 'بيانات هذه المجموعة تالفة.'];
      else if (data.schemaVersion > SCHEMA) err = ['newer', 'هذه المجموعة محفوظة بنسخة أحدث من التطبيق (schemaVersion ' + data.schemaVersion + ').'];
      else if (data.schemaVersion < 1) err = ['unsupported', 'schemaVersion غير مدعوم.'];
      else if (data.classId !== classId) err = ['class-mismatch', 'classId المخزّن لا يطابق الصف المطلوب.'];
      else { var ve = validateRecords(data.records, classId, type); if (ve) err = ['corrupt', 'سجلات غير صالحة: ' + ve]; }
      if (err) {
        bk = backupRaw(key, g.raw);
        return fail(err[0], err[1] + ' لم يُعدَّل شيء' + (bk ? '، وحُفظت نسخة خام احتياطية.' : '، وتعذّر حفظ نسخة احتياطية.') + ' الكتابة متوقفة على هذه المجموعة حتى تُراجَع.', { blocked: true, backedUp: bk });
      }
      return { ok: true, status: 'ok', records: clone(data.records), persistent: !memoryMode, warning: memoryMode ? 'التخزين الدائم غير متاح؛ البيانات مؤقتة وتزول بإغلاق الصفحة.' : undefined };
    }

    // حفظ المجموعة كاملة (يتحقق من الحالة الحالية أولاً فلا يطمس بيانات تالفة)
    function saveCollection(type, classId, records) {
      var cur = readCollection(type, classId), ve, rec, res;
      if (!cur.ok) return cur;
      ve = validateRecords(records, classId, type);
      if (ve) return fail('invalid-records', 'لم يُحفظ شيء: ' + ve);
      rec = { schemaVersion: SCHEMA, classId: classId, records: clone(records) };
      res = rawSet(keyFor(type, classId), JSON.stringify(rec));
      if (res === 'quota') return fail('write-failed', 'تعذّر الحفظ (التخزين ممتلئ أو محظور). لم يُحفظ التغيير.');
      if (res === 'verify') return fail('verify-failed', 'فشل التحقق بعد الكتابة؛ أُعيدت القيمة السابقة ولم يُحفظ التغيير.');
      return { ok: true, status: 'saved', records: clone(records), persistent: !memoryMode, warning: memoryMode ? 'حُفظ في ذاكرة الجلسة فقط وليس بشكل دائم؛ سيزول بإغلاق الصفحة.' : undefined };
    }

    function newId(type) {
      var a, s = '', i, p = ID_PREFIX[type] || 'rec';
      try { a = new Uint8Array(6); (self.crypto || window.crypto).getRandomValues(a); for (i = 0; i < a.length; i++) s += (a[i] % 36).toString(36); }
      catch (e) { for (i = 0; i < 6; i++) s += Math.floor(Math.random() * 36).toString(36); }
      return p + '_' + now().toString(36) + s + (++counter).toString(36);
    }

    function getRecord(type, classId, recordId) {
      var c = readCollection(type, classId), i;
      if (!c.ok) return c;
      for (i = 0; i < c.records.length; i++) if (c.records[i].recordId === recordId) return { ok: true, status: 'ok', record: c.records[i], persistent: c.persistent };
      return { ok: false, status: 'not-found', error: 'السجل غير موجود.', persistent: c.persistent };
    }

    // تجهيز سجل واحد فوق قائمة عمل `list` (لا يكتب). يُرجع { error } أو { r, idx }
    function prepare(type, classId, list, record, strict) {
      var i, idx = -1, r, ve, k, other;
      if (!isPlain(record)) return { error: fail('invalid-records', 'السجل ليس كائناً.') };
      if (record.classId !== undefined && record.classId !== classId) return { error: fail('class-mismatch', 'classId السجل لا يطابق الصف.') };
      r = clone(record); r.classId = classId;
      if (r.recordId === undefined) { r.recordId = newId(type); r.createdAt = new Date(now()).toISOString(); }
      for (i = 0; i < list.length; i++) if (list[i].recordId === r.recordId) idx = i;
      if (idx >= 0) { r.createdAt = list[idx].createdAt; }
      else if (record.recordId !== undefined && !r.createdAt) r.createdAt = new Date(now()).toISOString();
      r.updatedAt = new Date(now()).toISOString();
      if (TYPED[type]) {
        k = unknownField(r, type);
        if (k !== null && strict) return { error: fail('invalid-records', 'لم يُحفظ شيء: حقل غير معروف أو مشتق لا يُخزَّن: ' + k) };
        trimTyped(r);
        if (idx >= 0) {
          if (r.studentId !== list[idx].studentId) return { error: fail('immutable-field', 'لا يمكن تغيير studentId لسجل قائم؛ احذف السجل وأنشئ آخر عند الحاجة.') };
          if (type === 'attendance' && r.date !== list[idx].date) return { error: fail('immutable-field', 'لا يمكن تغيير تاريخ سجل حضور قائم؛ احذف السجل وأنشئ آخر عند الحاجة.') };
        }
      }
      ve = validateRecord(r, classId, type);
      if (ve) return { error: fail('invalid-records', 'لم يُحفظ شيء: ' + ve) };
      if (TYPED[type]) {
        k = uniqueKey(type, r);
        if (k !== null) for (i = 0; i < list.length; i++) {
          other = list[i];
          if (i !== idx && uniqueKey(type, other) === k) return { error: fail('duplicate', 'يوجد سجل لنفس المفتاح الطبيعي في هذا الصف؛ عدّل السجل القائم بدل إنشاء آخر.', { existingRecordId: other.recordId }) };
        }
      }
      return { r: r, idx: idx };
    }

    // إضافة (بلا recordId → يُنشأ معرّف جديد) أو تعديل (recordId موجود → يبقى المعرّف والصف ثابتين)
    function upsertRecord(type, classId, record) {
      var c = readCollection(type, classId), p, out, saved;
      if (!c.ok) return c;
      p = prepare(type, classId, c.records, record, true);
      if (p.error) return p.error;
      out = c.records.slice();
      if (p.idx >= 0) out[p.idx] = p.r; else out.push(p.r);
      saved = saveCollection(type, classId, out);
      if (saved.ok) { saved.record = clone(p.r); saved.created = p.idx < 0; }
      return saved;
    }

    // حفظ دفعة سجلات بكتابة واحدة ذرّية: تُحفظ كلها أو لا شيء (لا حفظ جزئي). يفيد الحضور اليومي لصف كامل
    function upsertMany(type, classId, records) {
      var c = readCollection(type, classId), work, ids = Object.create(null), results = [], i, p, saved, bad;
      if (!c.ok) return c;
      if (!Array.isArray(records) || records.length === 0) return fail('invalid-records', 'لم يُحفظ شيء: الدفعة فارغة أو ليست قائمة.');
      if (records.length > LIMITS.batchMax) return fail('invalid-records', 'لم يُحفظ شيء: الدفعة أكبر من الحد (' + LIMITS.batchMax + ' سجل).');
      work = c.records.slice();
      for (i = 0; i < records.length; i++) {
        if (isPlain(records[i]) && typeof records[i].recordId === 'string') {
          if (ids[records[i].recordId]) { bad = fail('invalid-records', 'لم يُحفظ شيء: recordId مكرر داخل الدفعة: ' + records[i].recordId); bad.index = i; return bad; }
          ids[records[i].recordId] = 1;
        }
        p = prepare(type, classId, work, records[i], true);
        if (p.error) { p.error.index = i; p.error.error = p.error.error + ' (السجل رقم ' + (i + 1) + ' في الدفعة؛ لم يُحفظ شيء من الدفعة)'; return p.error; }
        if (p.idx >= 0) work[p.idx] = p.r; else work.push(p.r);
        results.push({ recordId: p.r.recordId, created: p.idx < 0 });
      }
      saved = saveCollection(type, classId, work);
      if (saved.ok) { saved.results = results; saved.count = results.length; }
      return saved;
    }

    // الحذف يجب أن تسبقه واجهة تأكيد (تُبنى لاحقاً)
    function deleteRecord(type, classId, recordId) {
      var c = readCollection(type, classId), out;
      if (!c.ok) return c;
      out = c.records.filter(function (x) { return x.recordId !== recordId; });
      if (out.length === c.records.length) return fail('not-found', 'السجل غير موجود؛ لم يُحذف شيء.');
      return saveCollection(type, classId, out);
    }

    function isPersistent() { if (!memoryMode) { try { if (!backend) memoryMode = true; else backend.getItem(PREFIX + '__probe'); } catch (e) { memoryMode = true; } } return !memoryMode; }

    return {
      SCHEMA_VERSION: SCHEMA, TYPES: TYPES.slice(), keyFor: keyFor, newId: newId,
      readCollection: readCollection, saveCollection: saveCollection,
      getRecord: getRecord, upsertRecord: upsertRecord, upsertMany: upsertMany, deleteRecord: deleteRecord,
      isPersistent: isPersistent, isLocalDate: isLocalDate, isTime: isTime, toLocalDate: toLocalDate,
      ATTENDANCE_STATUSES: ATTENDANCE_STATUSES.slice(), LIMITS: clone(LIMITS), foldText: foldText, uniqueKey: uniqueKey
    };
  }

  return { create: create, SCHEMA_VERSION: SCHEMA, TYPES: TYPES.slice(), isLocalDate: isLocalDate, isTime: isTime, toLocalDate: toLocalDate, ATTENDANCE_STATUSES: ATTENDANCE_STATUSES.slice(), LIMITS: clone(LIMITS), foldText: foldText, uniqueKey: uniqueKey };
});
