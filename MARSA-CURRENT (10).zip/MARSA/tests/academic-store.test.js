// تشغيل: node tests/academic-store.test.js  (لا يحتاج مكتبات)
var assert = require('assert'), S = require('../js/academic-store.js');
function fake(opt) {
  opt = opt || {}; var d = {};
  return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; },
    getItem: function (k) { if (opt.blocked) throw new Error('blocked'); return k in d ? d[k] : null; },
    setItem: function (k, v) { if (opt.blocked || opt.full) throw new Error('quota'); d[k] = String(v); },
    removeItem: function (k) { delete d[k]; } };
}
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }

t('collections separate by type and class', function () {
  var st = fake(), s = S.create({ storage: st });
  s.upsertRecord('exams', 'cls_a', { title: 'x', examDate: '2026-11-01' });
  s.upsertRecord('exams', 'cls_b', { title: 'y' });
  s.upsertRecord('schedule', 'cls_a', { startTime: '08:00' });
  assert.deepStrictEqual(Object.keys(st.d).sort(), ['marsa.academic.exams.cls_a', 'marsa.academic.exams.cls_b', 'marsa.academic.schedule.cls_a']);
  assert.strictEqual(s.readCollection('exams', 'cls_a').records.length, 1);
  assert.strictEqual(s.readCollection('preparations', 'cls_a').status, 'empty');
});
t('reading does not write anything', function () {
  var st = fake(), s = S.create({ storage: st });
  s.readCollection('dailyLessons', 'cls_a'); assert.strictEqual(st.length, 0);
  s.upsertRecord('dailyLessons', 'cls_a', { date: '2026-10-21' });
  var before = JSON.stringify(st.d); s.readCollection('dailyLessons', 'cls_a'); assert.strictEqual(JSON.stringify(st.d), before);
});
t('add/edit/delete keep recordId and classId', function () {
  var s = S.create({ storage: fake() }), a = s.upsertRecord('preparations', 'cls_a', { title: 'one' }), id = a.record.recordId;
  assert.ok(a.created && a.record.classId === 'cls_a');
  var b = s.upsertRecord('preparations', 'cls_a', { recordId: id, title: 'two' });
  assert.ok(!b.created && b.record.recordId === id && b.record.classId === 'cls_a' && b.record.createdAt === a.record.createdAt);
  assert.strictEqual(s.readCollection('preparations', 'cls_a').records.length, 1);
  assert.strictEqual(s.upsertRecord('preparations', 'cls_a', { recordId: id, classId: 'cls_b' }).status, 'class-mismatch');
  assert.ok(s.deleteRecord('preparations', 'cls_a', id).ok);
  assert.strictEqual(s.readCollection('preparations', 'cls_a').records.length, 0);
  assert.strictEqual(s.deleteRecord('preparations', 'cls_a', id).status, 'not-found');
});
t('corrupt data: not overwritten, raw backup kept, writes blocked', function () {
  var st = fake(), s = S.create({ storage: st }), k = 'marsa.academic.exams.cls_a';
  st.d[k] = '{broken';
  var r = s.readCollection('exams', 'cls_a');
  assert.ok(!r.ok && r.status === 'corrupt' && r.blocked);
  assert.strictEqual(st.d[k], '{broken'); assert.strictEqual(st.d[k + '.backup'], '{broken');
  assert.ok(!s.upsertRecord('exams', 'cls_a', { title: 'x' }).ok); assert.strictEqual(st.d[k], '{broken');
});
t('older backup is never overwritten', function () {
  var st = fake(), s = S.create({ storage: st }), k = 'marsa.academic.exams.cls_a';
  st.d[k] = 'bad1'; s.readCollection('exams', 'cls_a'); st.d[k] = 'bad2'; s.readCollection('exams', 'cls_a'); s.readCollection('exams', 'cls_a');
  assert.strictEqual(st.d[k + '.backup'], 'bad1');
  var others = Object.keys(st.d).filter(function (x) { return x.indexOf(k + '.backup.') === 0; });
  assert.strictEqual(others.length, 1); assert.strictEqual(st.d[others[0]], 'bad2');
});
t('classId mismatch, newer schema, bad record are blocked', function () {
  var st = fake(), s = S.create({ storage: st }), k = 'marsa.academic.exams.cls_a';
  st.d[k] = JSON.stringify({ schemaVersion: 1, classId: 'cls_zzz', records: [] }); assert.strictEqual(s.readCollection('exams', 'cls_a').status, 'class-mismatch');
  st.d[k] = JSON.stringify({ schemaVersion: 99, classId: 'cls_a', records: [] }); assert.strictEqual(s.readCollection('exams', 'cls_a').status, 'newer');
  st.d[k] = JSON.stringify({ schemaVersion: 1, classId: 'cls_a', records: [{ recordId: 'r1', classId: 'cls_b' }] }); assert.strictEqual(s.readCollection('exams', 'cls_a').status, 'corrupt');
  assert.strictEqual(st.d[k], JSON.stringify({ schemaVersion: 1, classId: 'cls_a', records: [{ recordId: 'r1', classId: 'cls_b' }] }));
});
t('blocked localStorage: no false permanent-save claim', function () {
  var s = S.create({ storage: fake({ blocked: true }) }), r = s.upsertRecord('exams', 'cls_a', { title: 'x' });
  assert.ok(r.ok && r.persistent === false && /ليس بشكل دائم/.test(r.warning)); assert.strictEqual(s.isPersistent(), false);
  assert.strictEqual(s.readCollection('exams', 'cls_a').records.length, 1);
});
t('full storage: failure reported, no success', function () {
  var r = S.create({ storage: fake({ full: true }) }).upsertRecord('exams', 'cls_a', { title: 'x' });
  assert.ok(!r.ok && r.status === 'write-failed');
});
t('write verification failure restores previous value', function () {
  var st = fake(), s = S.create({ storage: st }); s.upsertRecord('exams', 'cls_a', { title: 'x' });
  var k = 'marsa.academic.exams.cls_a', old = st.d[k], realSet = st.setItem;
  st.setItem = function (kk, v) { if (kk === k) st.d[kk] = 'garbled'; else realSet(kk, v); };
  var r = s.upsertRecord('exams', 'cls_a', { title: 'y' }); assert.ok(!r.ok && r.status === 'verify-failed');
});
t('dates are local YYYY-MM-DD and validated', function () {
  assert.strictEqual(S.toLocalDate(new Date(2026, 9, 21, 0, 30)), '2026-10-21');
  assert.ok(S.isLocalDate('2026-02-28') && !S.isLocalDate('2026-02-30') && !S.isLocalDate('21-10-2026'));
  assert.ok(S.isTime('08:05') && !S.isTime('8:5') && !S.isTime('24:00'));
  var s = S.create({ storage: fake() });
  assert.strictEqual(s.upsertRecord('exams', 'cls_a', { examDate: '2026-13-01' }).status, 'invalid-records');
  assert.strictEqual(s.upsertRecord('schedule', 'cls_a', { startTime: '25:00' }).status, 'invalid-records');
});
t('unsupported type / bad classId rejected; ids unique and safe', function () {
  var s = S.create({ storage: fake() });
  assert.strictEqual(s.readCollection('students', 'cls_a').status, 'invalid-args');
  assert.strictEqual(s.readCollection('exams', '../x').status, 'invalid-args');
  var seen = {}, i, id; for (i = 0; i < 500; i++) { id = s.newId('exams'); assert.ok(/^[A-Za-z0-9_-]{1,64}$/.test(id) && !seen[id]); seen[id] = 1; }
});
t('existing student/class keys untouched', function () {
  var st = fake(), s = S.create({ storage: st }); st.d['marsa.roster'] = 'R'; st.d['marsa.classes'] = 'C'; st.d['marsa.roster.cls_a'] = 'R2';
  s.upsertRecord('exams', 'cls_a', { title: 'x' }); s.deleteRecord('exams', 'cls_a', s.readCollection('exams', 'cls_a').records[0].recordId);
  assert.ok(st.d['marsa.roster'] === 'R' && st.d['marsa.classes'] === 'C' && st.d['marsa.roster.cls_a'] === 'R2');
});
console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
