// اختبار واجهة 4.07: حماية المدخلات غير المحفوظة في النوافذ، وعدم وجود تمرير أفقي، وتسميات الحقول.
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-stage4-ux-review.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
function isOpen(page, id) { return page.evaluate(function (i) { return document.getElementById(i).open; }, id); }
(async function () {
  var browser = await pw.chromium.launch();
  var WIDTHS = [320, 360, 390, 430];
  for (var wi = 0; wi < WIDTHS.length; wi++) {
    var ctx = await browser.newContext({ viewport: { width: WIDTHS[wi], height: 760 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
    var page = await ctx.newPage(); page.on('pageerror', function (e) { jsErrors.push(e.message); });
    await page.goto(URL); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
    await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
    await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
    var navs = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
    var bad = [];
    for (var i = 0; i < navs.length; i++) {
      await page.click('.nav button >> nth=' + i); await page.waitForTimeout(80);
      var o = await page.evaluate(function () {
        var nl = [];
        document.querySelectorAll('main input:not([type=hidden]), main select, main textarea').forEach(function (e) {
          if (e.closest('[hidden]') || !e.getBoundingClientRect().width) return;
          if (!(e.getAttribute('aria-label') || e.getAttribute('aria-labelledby') || (e.id && document.querySelector('label[for="' + e.id + '"]')) || e.closest('label'))) nl.push(e.id || e.tagName);
        });
        return { ovf: document.documentElement.scrollWidth - document.documentElement.clientWidth, nl: nl };
      });
      if (o.ovf > 1 || o.nl.length) bad.push(navs[i] + ' ovf=' + o.ovf + ' nolabel=' + o.nl.join(','));
    }
    check(WIDTHS[wi] + 'px: لا تمرير أفقي ولا حقل بلا تسمية في كل الصفحات', bad.length === 0, bad.join(' | '));
    if (WIDTHS[wi] === 360) {
      // نافذة الصف
      await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")'); await page.click('button:has-text("إضافة صف")');
      await page.keyboard.press('Escape'); await page.waitForTimeout(150);
      check('نافذة الصف بلا كتابة: Escape يغلقها مباشرة', !(await isOpen(page, 'dlg-class')));
      await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', 'الرابع');
      await page.keyboard.press('Escape'); await page.waitForTimeout(150);
      check('نافذة الصف بعد الكتابة: Escape لا يغلقها بل يسأل', (await isOpen(page, 'dlg-class')) && (await isOpen(page, 'dlg-confirm')));
      check('المدخل محفوظ في النافذة بعد طلب التأكيد', (await page.inputValue('#cf-stage')) === 'الرابع');
      await page.click('#dlg-confirm button.link'); await page.waitForTimeout(100);
      check('الإلغاء في التأكيد يُبقي النافذة والمدخل', (await isOpen(page, 'dlg-class')) && !(await isOpen(page, 'dlg-confirm')) && (await page.inputValue('#cf-stage')) === 'الرابع');
      await page.keyboard.press('Escape'); await page.waitForTimeout(150);
      await page.click('#dlg-confirm button.primary'); await page.waitForTimeout(150);
      check('تأكيد التجاهل يغلق النافذة', !(await isOpen(page, 'dlg-class')) && !(await isOpen(page, 'dlg-confirm')));
      var n = await page.evaluate(function () { return JSON.parse(localStorage.getItem('marsa.classes')).classes.length; });
      await page.click('button:has-text("إضافة صف")');
      check('إعادة فتح النافذة تبدأ فارغة ولا تحمل حالة قديمة', (await page.inputValue('#cf-stage')) === '' && (await page.evaluate(function () { return document.getElementById('dlg-class').getAttribute('data-dirty'); })) === null);
      await page.keyboard.press('Escape'); await page.waitForTimeout(150);
      check('لم يُنشأ صف من التجاهل', n === (await page.evaluate(function () { return JSON.parse(localStorage.getItem('marsa.classes')).classes.length; })));
      // حفظ ناجح لا يترك حالة dirty
      await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', 'الخامس'); await page.click('#dlg-class button.primary'); await page.waitForSelector('#dlg-class', { state: 'hidden' });
      await page.click('button:has-text("إضافة صف")'); await page.keyboard.press('Escape'); await page.waitForTimeout(150);
      check('بعد حفظ ناجح: فتح نافذة جديدة وEscape يغلقها بلا سؤال', !(await isOpen(page, 'dlg-class')) && !(await isOpen(page, 'dlg-confirm')));
      // نافذة الطلاب
      var card = page.locator('li.cls', { hasText: 'الخامس' }).filter({ has: page.locator('button:has-text("اختيار كصف نشط")') });
      if (await card.count()) await card.first().locator('button:has-text("اختيار كصف نشط")').click();
      await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")'); await page.fill('#add-names', 'علي\nأحمد');
      await page.keyboard.press('Escape'); await page.waitForTimeout(150);
      check('نافذة الطلاب بعد كتابة أسماء: Escape يسأل ولا يفقد الأسماء', (await isOpen(page, 'dlg-add')) && (await isOpen(page, 'dlg-confirm')) && (await page.inputValue('#add-names')) === 'علي\nأحمد');
      await page.click('#dlg-confirm button.link'); await page.waitForTimeout(100);
      await page.fill('#add-names', ''); await page.keyboard.press('Escape'); await page.waitForTimeout(150);
      check('بعد مسح الأسماء يُغلق Escape مباشرة', !(await isOpen(page, 'dlg-add')));
      check('التركيز عاد إلى زر «إضافة طلاب»', (await page.evaluate(function () { return document.activeElement.textContent.trim(); })) === 'إضافة طلاب');
    }
    await ctx.close();
  }
  check('لا أخطاء JavaScript', jsErrors.length === 0, jsErrors.join(' ; '));
  await browser.close();
  var f = results.filter(function (r) { return !r.ok; }).length;
  console.log('\n' + (results.length - f) + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
})();
