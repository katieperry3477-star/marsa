// 5.05 — اختبارات خوارزمية ترحيل localStorage على بيانات صناعية. تشغيل: node tests/migration/migration.test.js
'use strict';
var fs = require('fs'), path = require('path'), vm = require('vm');
var S = require('./synthetic.js'), O = require('./oracle.js'), Store = require('../../js/academic-store.js');
var ROOT = path.resolve(__dirname, '..', '..'), pass = 0, fail = 0;
function check(n, c, d) { if (c) { pass++; console.log('PASS ' + n); } else { fail++; console.log('FAIL ' + n + (d ? ' :: ' + d : '')); } }
var DEV = { userId: 'dev1', role: 'developer' }, DEMO = S.DEMO_ID;
function approvalCtx(plan, extra) { return Object.assign({ actor: DEV, deviceId: 'A', approval: O.approve(plan), backup: { verified: true } }, extra || {}); }
function go(plan, srv, extra) { return O.runMigration(plan, srv, approvalCtx(plan, extra)); }
function ds(seed, o) { return S.makeDataset(Object.assign({ seed: seed }, o || {})); }
function snap(st) { return JSON.stringify(st.dump()); }
function codes(plan, sev) { return plan.anomalies.filter(function (a) { return !sev || a.severity === sev; }).map(function (a) { return a.code; }); }
function setRaw(st, key, fn) { var raw = st.getItem(key), v = fn(raw === null ? null : JSON.parse(raw)); st.setItem(key, typeof v === 'string' ? v : JSON.stringify(v)); }
function cidOf(d, n) { return d.truth.order[n]; }

// ===== A: الجرد والمفاتيح =====
var d = ds(1), before = snap(d.storage);
var inv = O.inventory(d.storage);
check('MT-A01 الجرد يجد الصفين ويتجاهل marsa.ui', inv.registry.list.length === 2 && inv.ignored.indexOf('marsa.ui') >= 0 && inv.orphans.length === 0);
d.storage.setItem('other.app.key', 'x'); d.storage.setItem('marsa.roster.backup', '{}'); d.storage.setItem('marsa.academic.payments.' + cidOf(d, 1) + '.backup.k1', '{}'); d.storage.setItem('marsa.academic.zzz.' + DEMO, '{}'); d.storage.setItem('marsa.migration.state', '{}');
inv = O.inventory(d.storage);
check('MT-A02 مفاتيح غريبة تُعدّ ولا تُرحَّل؛ النسخ الاحتياطية artifacts؛ نوع مجهول unknown', inv.foreign === 1 && inv.artifacts.length === 2 && inv.unknown.length === 1 && inv.ignored.indexOf('marsa.migration.state') >= 0);
d.storage.resetLog(); var ro0 = snap(d.storage); O.buildPlan(d.storage);
check('MT-A03 buildPlan لا يكتب ولا يحذف أي مفتاح (read-only)', d.storage.sets.length === 0 && d.storage.removes.length === 0 && snap(d.storage) === ro0);
var d2 = ds(2); d2.storage.setItem('marsa.roster.cls_ghost', JSON.stringify({ schemaVersion: 2, classId: 'cls_ghost', students: [] }));
var p2 = O.buildPlan(d2.storage);
check('MT-A04 بيانات صف غير مسجَّل في marsa.classes = مانع عام ORPHAN-CLASS-DATA ويوقف الخطة', p2.state === 'blocked' && codes(p2, 'blocker').indexOf('ORPHAN-CLASS-DATA') >= 0);
check('MT-A05 إقرار صريح acknowledgeOrphans يحوّله إلى تحذير ويُكمل الخطة دون لمس المفتاح', O.buildPlan(d2.storage, { decisions: { acknowledgeOrphans: true } }).state === 'ready');
var d3 = ds(3); setRaw(d3.storage, 'marsa.classes', function (r) { r.classes.push({ classId: 'backup', stage: 'س', status: 'active' }); return r; });
d3.storage.setItem('marsa.roster.backup', JSON.stringify({ schemaVersion: 2, classId: 'backup', students: [] }));
check('MT-A06 classId = "backup" يصطدم بمفتاح نسخة الصف التجريبي ⇒ KEY-AMBIGUOUS يحجب ذلك الصف فقط', (function () { var p = O.buildPlan(d3.storage); return p.classes.filter(function (c) { return c.state === 'blocked'; }).map(function (c) { return c.classId; }).join() === 'backup' && p.classes.filter(function (c) { return c.state === 'ready'; }).length === 2; })());
var d4 = ds(4, { classes: 1 }); d4.storage.m.delete('marsa.classes');
check('MT-A07 غياب marsa.classes (أول تشغيل) = الصف التجريبي المزروع origin=seed ولا مانع', (function () { var p = O.buildPlan(d4.storage); return p.classes.length === 1 && p.classes[0].origin === 'seed' && p.state === 'ready'; })());
var d5 = ds(5); d5.storage.setItem('marsa.classes', '{{تالف');
check('MT-A08 marsa.classes تالف = REGISTRY-CORRUPT مانع عام (قد تختفي صفوف أخرى) ولا يُرحَّل شيء', (function () { var p = O.buildPlan(d5.storage); return p.state === 'blocked' && codes(p, 'blocker').indexOf('REGISTRY-CORRUPT') >= 0 && p.rows.students.length === 0; })());

// ===== B: المعاينة والأعداد =====
var dB = ds(11, { classes: 2, students: 8, days: 5 }), planB = O.buildPlan(dB.storage), T0 = dB.truth.classes[DEMO], T1 = dB.truth.classes[cidOf(dB, 1)];
function cnt(plan, kind, cid) { return plan.rows[kind].filter(function (r) { return r.class_id === cid; }).length; }
check('MT-B01 أعداد الطلاب (فعّالون + مؤرشفون) تطابق الحقيقة المرجعية', cnt(planB, 'students', DEMO) === T0.students && cnt(planB, 'students', cidOf(dB, 1)) === T1.students && planB.rows.students.filter(function (r) { return r.status === 'archived'; }).length === T0.archived + T1.archived);
check('MT-B02 أعداد الحضور والدرجات والمقبوضات تطابق الحقيقة', cnt(planB, 'attendance', DEMO) === T0.attendance && cnt(planB, 'grades', DEMO) === T0.grades && cnt(planB, 'payments', DEMO) === T0.payments && cnt(planB, 'payments', cidOf(dB, 1)) === T1.payments);
check('MT-B03 مجموع المقبوضات في الخطة = الحقيقة (أعداد صحيحة)', planB.expected[DEMO].payments.sums.amount === T0.paymentSum && planB.expected[cidOf(dB, 1)].payments.sums.amount === T1.paymentSum);
check('MT-B04 مجاميع الدرجات (×100) وتوزيع الحضور تطابق الحقيقة', planB.expected[DEMO].grades.sums.scoreX100 === T0.scoreX100 && planB.expected[DEMO].grades.sums.maxX100 === T0.maxX100 && JSON.stringify(planB.expected[DEMO].attendance.sums.byStatus) === JSON.stringify(T0.byStatus));
var twin = planB.rows.payments.filter(function (r) { return r.class_id === DEMO && r.student_id === T0.twinStudent && r.amount === 5000 && r.purpose === 'دفعة متطابقة'; });
check('MT-B05 دفعتان متطابقتان شرعياً (معرّفان مختلفان) تبقيان دفعتين في الخطة', twin.length === 2 && twin[0].record_id !== twin[1].record_id && codes(planB).indexOf('IDENTICAL-PAYMENTS') >= 0 && codes(planB, 'blocker').length === 0);
check('MT-B06 المحتوى الأربعة محفوظ حقلاً بحقل بما فيه حقل غير معروف (payload)', planB.rows.content.some(function (r) { return r.type === 'exams' && r.payload.futureField === 'يُحفظ كما هو'; }) && planB.rows.content.length === 8);
check('MT-B07 مفاتيح الصف التجريبي القديمة تُحفظ: marsa.roster ⇒ cls_demo_001', cnt(planB, 'students', DEMO) === T0.students);
check('MT-B08 أيام الجدول تُرحَّل كإعداد صف', planB.rows.classSettings.length === 2 && planB.rows.classSettings[0].schedule_days.join() === 'sun,mon,tue,wed');
check('MT-B09 الخطة حتمية: بناؤها مرتين = البصمة نفسها', O.buildPlan(dB.storage).sourceFingerprint === planB.sourceFingerprint);
check('MT-B10 تغيير activeClassId (اختيار جهاز) لا يغيّر البصمة', (function () { var c = dB.storage.clone(); setRaw(c, 'marsa.classes', function (r) { r.activeClassId = cidOf(dB, 1); return r; }); return O.buildPlan(c).sourceFingerprint === planB.sourceFingerprint; })());
check('MT-B11 تغيير سجل واحد يغيّر البصمة', (function () { var c = dB.storage.clone(); setRaw(c, 'marsa.academic.payments.' + DEMO, function (r) { r.records[0].amount += 1; return r; }); return O.buildPlan(c).sourceFingerprint !== planB.sourceFingerprint; })());
check('MT-B12 الطالب المؤرشف سجلاته التاريخية تبقى (لا أيتام)', codes(planB).indexOf('ORPHAN-RECORDS') < 0);

// ===== C: بيانات تالفة/قديمة — يوافق المخزن الحقيقي، ويحجب الصف المعني فقط =====
function variant(name, mut, expectCode, expectStatus) {
  var x = ds(21), cid = cidOf(x, 1), orig = snap(x.storage);
  mut(x.storage, cid);
  var pre = snap(x.storage), p = O.buildPlan(x.storage), c = p.classes.filter(function (k) { return k.classId === cid; })[0], other = p.classes.filter(function (k) { return k.classId === DEMO; })[0];
  var real = expectStatus ? Store.create({ storage: O.readOnly(x.storage) }).readCollection(expectStatus[0], cid).status : null;
  check('MT-C ' + name + ' ⇒ الصف محجوب بـ' + expectCode + ' والصف الآخر جاهز ولا مفتاح تغيّر', c.state === 'blocked' && c.blockers.join().indexOf(expectCode) >= 0 && other.state === 'ready' && snap(x.storage) === pre && p.rows.students.every(function (r) { return r.class_id !== cid; }));
  if (expectStatus) check('MT-C ' + name + ' ⇒ حالة المخزن الحقيقي = ' + expectStatus[1], real === expectStatus[1], String(real));
}
var AK = function (c) { return 'marsa.academic.attendance.' + c; }, PK = function (c) { return 'marsa.academic.payments.' + c; }, GK = function (c) { return 'marsa.academic.grades.' + c; }, RK = function (c) { return 'marsa.roster.' + c; };
variant('JSON تالف (حضور)', function (s, c) { s.setItem(AK(c), '{oops'); }, 'COLLECTION-CORRUPT', ['attendance', 'corrupt']);
variant('جذر مصفوفة (مقبوضات)', function (s, c) { s.setItem(PK(c), '[]'); }, 'COLLECTION-CORRUPT', ['payments', 'corrupt']);
variant('بلا schemaVersion', function (s, c) { setRaw(s, AK(c), function (r) { delete r.schemaVersion; return r; }); }, 'COLLECTION-CORRUPT', ['attendance', 'corrupt']);
variant('schemaVersion أحدث', function (s, c) { setRaw(s, GK(c), function (r) { r.schemaVersion = 9; return r; }); }, 'COLLECTION-NEWER', ['grades', 'newer']);
variant('schemaVersion = 0', function (s, c) { setRaw(s, GK(c), function (r) { r.schemaVersion = 0; return r; }); }, 'COLLECTION-UNSUPPORTED', ['grades', 'unsupported']);
variant('classId لا يطابق', function (s, c) { setRaw(s, PK(c), function (r) { r.classId = 'cls_other'; return r; }); }, 'COLLECTION-CLASS-MISMATCH', ['payments', 'class-mismatch']);
variant('records ليست قائمة', function (s, c) { setRaw(s, PK(c), function (r) { r.records = {}; return r; }); }, 'COLLECTION-CORRUPT', ['payments', 'corrupt']);
variant('recordId مكرر (مقبوضات)', function (s, c) { setRaw(s, PK(c), function (r) { r.records.push(JSON.parse(JSON.stringify(r.records[0]))); return r; }); }, 'COLLECTION-CORRUPT', ['payments', 'corrupt']);
variant('تاريخ غير صالح', function (s, c) { setRaw(s, AK(c), function (r) { r.records[0].date = '2026-02-31'; return r; }); }, 'COLLECTION-CORRUPT', ['attendance', 'corrupt']);
variant('حالة حضور غير معروفة', function (s, c) { setRaw(s, AK(c), function (r) { r.records[0].status = 'sick'; return r; }); }, 'COLLECTION-CORRUPT', ['attendance', 'corrupt']);
variant('حضور مكرر لنفس (طالب، تاريخ)', function (s, c) { setRaw(s, AK(c), function (r) { var x = JSON.parse(JSON.stringify(r.records[0])); x.recordId = 'att_dupe'; r.records.push(x); return r; }); }, 'COLLECTION-CORRUPT', ['attendance', 'corrupt']);
variant('درجة أكبر من القصوى', function (s, c) { setRaw(s, GK(c), function (r) { r.records[0].score = r.records[0].maxScore + 1; return r; }); }, 'COLLECTION-CORRUPT', ['grades', 'corrupt']);
variant('مبلغ كسري', function (s, c) { setRaw(s, PK(c), function (r) { r.records[0].amount = 10.5; return r; }); }, 'COLLECTION-CORRUPT', ['payments', 'corrupt']);
variant('مبلغ سالب', function (s, c) { setRaw(s, PK(c), function (r) { r.records[0].amount = -5; return r; }); }, 'COLLECTION-CORRUPT', ['payments', 'corrupt']);
variant('مبلغ نص', function (s, c) { setRaw(s, PK(c), function (r) { r.records[0].amount = '5000'; return r; }); }, 'COLLECTION-CORRUPT', ['payments', 'corrupt']);
variant('قائمة طلاب تالفة', function (s, c) { s.setItem(RK(c), 'not json'); }, 'ROSTER-CORRUPT');
variant('قائمة طلاب لصف آخر', function (s, c) { setRaw(s, RK(c), function (r) { r.classId = DEMO; return r; }); }, 'ROSTER-FOREIGN');
variant('قائمة طلاب بنسخة أحدث', function (s, c) { setRaw(s, RK(c), function (r) { r.schemaVersion = 3; return r; }); }, 'ROSTER-NEWER');
variant('قائمة طلاب v1 قديمة (بلا أكواد)', function (s, c) { setRaw(s, RK(c), function (r) { r.schemaVersion = 1; r.students.forEach(function (x) { delete x.studentCode; }); return r; }); }, 'ROSTER-LEGACY-V1');
// طلاب غير صالحين داخل قائمة سليمة ⇒ تحذير + حجر السجلات اليتيمة (لا حذف ولا حجب الصف)
(function () {
  var x = ds(22), cid = cidOf(x, 1), victim = x.truth.classes[cid].studentIds[0];
  setRaw(x.storage, RK(cid), function (r) { r.students[0].name = '   '; r.students.push({ studentId: 'dup', name: 'ا', status: 'active' }, { studentId: 'dup', name: 'ب', status: 'active' }, null, { studentId: 'x9', name: 'ج', status: 'weird' }); return r; });
  var raw0 = snap(x.storage), p = O.buildPlan(x.storage), c = p.classes.filter(function (k) { return k.classId === cid; })[0];
  var orphPay = p.quarantine.filter(function (q) { return q.kind === 'payments' && q.class_id === cid; }), expSum = p.expected[cid].payments.sums.amount;
  check('MT-C طلاب غير صالحين: الصف جاهز + ROSTER-DROPPED (4) + سجلات الطالب المُسقط تُحجَر لا تُحذف', c.state === 'ready' && p.anomalies.some(function (a) { return a.code === 'ROSTER-DROPPED' && a.detail.n === 4; }) && orphPay.length > 0 && p.quarantine.every(function (q) { return q.reason === 'ORPHAN-STUDENT'; }) && snap(x.storage) === raw0);
  check('MT-C المقبوضات المحجورة يظهر مبلغها للمستخدم (المال المعلّق مرئي)', orphPay.every(function (q) { return Number.isSafeInteger(q.amount); }) && orphPay.reduce(function (a, q) { return a + q.amount; }, 0) + expSum === x.truth.classes[cid].paymentSum);
  var srv = new O.FakeServer(), rep = go(p, srv);
  check('MT-C الاستيراد مع الحجر: verified-with-exceptions والميزان يُغلق (المستورد + المحجور = المصدر)', rep.status === 'verified-with-exceptions' && rep.reconcile.ok && rep.reconcile.rows.filter(function (r) { return r.classId === cid; }).every(function (r) { return r.balanced; }));
})();
// أكواد الطلاب: لا توليد صامت؛ المكرر/الباطل ⇒ NULL + needs_code وتحذير، والاستيراد لا يفقد طالباً
(function () {
  var x = ds(23), c0 = cidOf(x, 0), c1 = cidOf(x, 1), dupCode = x.truth.classes[c0] && JSON.parse(x.storage.getItem('marsa.roster')).students[0].studentCode;
  setRaw(x.storage, RK(c1), function (r) { r.students[0].studentCode = dupCode; r.students[1].studentCode = 'bad'; return r; });
  var p = O.buildPlan(x.storage), c1s = p.rows.students.filter(function (r) { return r.class_id === c1; });
  check('MT-C كود مكرر عبر صفين ⇒ الأول (الصف التجريبي) يحتفظ به، والثاني NULL + STUDENT-CODE-DUPLICATE', JSON.parse(x.storage.getItem('marsa.roster')).students[0].studentCode === p.rows.students.filter(function (r) { return r.class_id === c0; })[0].student_code && c1s[0].student_code === null && c1s[0].needs_code && codes(p).indexOf('STUDENT-CODE-DUPLICATE') >= 0);
  check('MT-C كود بصيغة غير صالحة ⇒ NULL + STUDENT-CODE-INVALID، وعدد الطلاب لم ينقص', c1s[1].student_code === null && codes(p).indexOf('STUDENT-CODE-INVALID') >= 0 && c1s.length === x.truth.classes[c1].students);
})();
// طالبان بنفس الاسم ومعرّفين مختلفين ⇒ تحذير فقط (لا دمج تلقائي)
(function () {
  var x = ds(24), c1 = cidOf(x, 1);
  setRaw(x.storage, RK(c1), function (r) { r.students[1].name = r.students[0].name; return r; });
  var p = O.buildPlan(x.storage);
  check('MT-C تشابه اسم بمعرّفين مختلفين ⇒ POSSIBLE-DUPLICATE-PERSON بلا دمج ولا حجب', codes(p).indexOf('POSSIBLE-DUPLICATE-PERSON') >= 0 && p.classes.every(function (c) { return c.state === 'ready'; }) && cnt(p, 'students', c1) === x.truth.classes[c1].students);
})();
// سجلات بحقول غير معروفة / مفاتيح خطرة
(function () {
  var x = ds(25), c1 = cidOf(x, 1);
  setRaw(x.storage, PK(c1), function (r) { r.records[0].mystery = 1; return r; });
  var p = O.buildPlan(x.storage);
  check('MT-C حقل غير معروف في مقبوضة ⇒ UNKNOWN-FIELDS تحذير؛ الحقل لا يُرحَّل والسجل يُرحَّل', codes(p).indexOf('UNKNOWN-FIELDS') >= 0 && p.rows.payments.every(function (r) { return !('mystery' in r); }) && cnt(p, 'payments', c1) === x.truth.classes[c1].payments);
  var y = ds(26), cc = cidOf(y, 1);
  setRaw(y.storage, 'marsa.academic.exams.' + cc, function (r) { r.records[0] = JSON.parse(JSON.stringify(r.records[0]).replace('{', '{"__proto__":{"polluted":true},')); return r; });
  var pp = O.buildPlan(y.storage);
  check('MT-C مفتاح __proto__ في محتوى ⇒ حجر UNSAFE-OR-OVERSIZE ولا تلوّث للنموذج الأولي', pp.quarantine.some(function (q) { return q.reason === 'UNSAFE-OR-OVERSIZE'; }) && ({}).polluted === undefined);
})();

// ===== D: idempotency والترتيب =====
(function () {
  var x = ds(31), p = O.buildPlan(x.storage), srv = new O.FakeServer(), r1 = go(p, srv), n1 = srv.totalRows(), snapSrv = JSON.stringify(srv.exportAll());
  check('MT-D01 التشغيل الأول: verified وكل الأعداد متوازنة', r1.status === 'verified' && r1.reconcile.ok && n1 > 0);
  var r2 = go(p, srv), r3 = go(p, srv);
  var ins = 0; Object.keys(r2.tally).forEach(function (c) { Object.keys(r2.tally[c]).forEach(function (k) { ins += r2.tally[c][k].inserted; }); });
  check('MT-D02 إعادة التشغيل مرتين: 0 إدراج، كل شيء already، الخادم بلا تغيير', ins === 0 && r2.status === 'verified' && r3.status === 'verified' && srv.totalRows() === n1 && JSON.stringify(srv.exportAll()) === snapSrv);
  check('MT-D03 مجاميع المقبوضات على الخادم = الحقيقة بعد 3 تشغيلات (لا تكرار للمتطابقتين)', Object.keys(x.truth.classes).every(function (c) { var a = srv.aggregates(c); return a.payments.sum === x.truth.classes[c].paymentSum && a.payments.total === x.truth.classes[c].payments; }));
  var small = new O.FakeServer(), r4 = go(p, small, { limits: { maxRecords: 3 } }), big = new O.FakeServer(); go(p, big);
  check('MT-D04 حجم الدفعة لا يغيّر النتيجة النهائية (3 سجلات مقابل 200)', r4.status === 'verified' && JSON.stringify(small.exportAll()) === JSON.stringify(big.exportAll()) && r4.batches.total > 20);
  var s5 = new O.FakeServer(); s5.runs.set('x', {}); // لا شيء
  check('MT-D05 أحداث التدقيق: بلا حقول ممنوعة، وفيها الحقول الإلزامية، وعدد فقط', (function () {
    var spec = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs/stage5/security/audit-events.json'), 'utf8'));
    return srv.audit.length >= 3 && srv.audit.every(function (e) { return spec.requiredFields.every(function (f) { return e[f] !== undefined; }) && Object.keys(e).every(function (k) { return spec.forbiddenFields.indexOf(k) < 0 && (spec.requiredFields.concat(spec.optionalFields)).indexOf(k) >= 0; }); });
  })());
})();

// ===== E: فشل وانقطاع وإعادة محاولة =====
(function () {
  var x = ds(41), p = O.buildPlan(x.storage), base = new O.FakeServer(); go(p, base); var want = JSON.stringify(base.exportAll());
  var s1 = new O.FakeServer(); s1.faults.push({ op: 'importBatch', nth: 5, kind: 'drop-before-commit' });
  var r1 = go(p, s1);
  check('MT-E01 إسقاط قبل الحفظ: إعادة المحاولة تنجح (retries=1) والنتيجة مطابقة', r1.status === 'verified' && r1.batches.retries === 1 && JSON.stringify(s1.exportAll()) === want);
  var s2 = new O.FakeServer(); s2.faults.push({ op: 'importBatch', nth: 12, kind: 'timeout-after-commit' }, { op: 'importBatch', nth: 15, kind: 'timeout-after-commit' });
  var r2 = go(p, s2);
  check('MT-E02 انتهاء المهلة بعد الحفظ فعلاً (الأخطر): لا تكرار، المقبوضات سليمة', r2.status === 'verified' && JSON.stringify(s2.exportAll()) === want && s2.aggregates(DEMO).payments.sum === x.truth.classes[DEMO].paymentSum);
  var s3 = new O.FakeServer(); s3.faults.push({ op: 'importBatch', nth: 4, kind: 'error500' }, { op: 'importBatch', nth: 5, kind: 'error500' }, { op: 'importBatch', nth: 6, kind: 'error500' });
  var r3 = go(p, s3);
  check('MT-E03 ثلاث إخفاقات متتالية ⇒ paused (لا حلقة لانهائية) والتأخيرات متصاعدة', r3.status === 'paused' && r3.blockers[0] === 'RETRY-EXHAUSTED' && r3.delays.join() === '1000,3000,9000' && r3.batches.committed === 3);
  var r3b = go(p, s3, { resumeRunId: r3.runId });
  check('MT-E04 الاستئناف بنفس runId يكمل من أول دفعة غير مُنجزة ويتطابق مع التشغيل النظيف', r3b.status === 'verified' && r3b.batches.resumedSkipped === 3 && JSON.stringify(s3.exportAll()) === want);
  var s4 = new O.FakeServer(), crashed = false;
  try { go(p, s4, { crashAfterBatches: 7 }); } catch (e) { crashed = e.message === 'CRASH'; }
  var partial = s4.totalRows();
  check('MT-E05 انهيار العميل في المنتصف يترك الخادم جزئياً (متوقع) بلا صفوف نصف مكتوبة', crashed && partial > 0 && partial < base.totalRows());
  var r4 = go(p, s4);
  check('MT-E06 فقد حالة العميل تماماً ⇒ تشغيل جديد (بلا runId) يكمل ويتطابق (already للمنجَز)', r4.status === 'verified' && JSON.stringify(s4.exportAll()) === want && r4.batches.total > 0);
  var s5 = new O.FakeServer(); s5.online = false;
  check('MT-E07 بلا اتصال ⇒ محجوب OFFLINE قبل أي كتابة', go(p, s5).blockers.indexOf('OFFLINE') >= 0 && s5.totalRows() === 0);
  var s6 = new O.FakeServer({ maxRows: 30 }), r6 = go(p, s6);
  check('MT-E08 سقف الحصة المجانية ⇒ paused QUOTA بلا دفع ولا تجاوز ولا صفوف نصف دفعة (Q7)', r6.status === 'paused' && r6.blockers[0] === 'QUOTA' && s6.totalRows() <= 30);
  var s7 = new O.FakeServer({ schemaVersion: 1 });
  check('MT-E09 خادم بمخطط أقدم من المطلوب ⇒ SERVER-SCHEMA-OLD', go(p, s7, { requiredServerSchema: 2 }).blockers.indexOf('SERVER-SCHEMA-OLD') >= 0);
  var s8 = new O.FakeServer(), rr = O.runMigration(p, s8, approvalCtx(p, { limits: {} }));
  var runId = rr.runId, b0 = s8.batches.get(runId + ':3');
  check('MT-E10 إعادة معرّف دفعة بمحتوى مختلف مرفوضة (batch-id-reuse)', (function () { var res = s8.importBatch({ runId: runId, actor: DEV, batchId: runId + ':3', kind: 'students', classId: DEMO, rows: [], hash: 'other' }); return res.status === 'batch-id-reuse'; })());
  check('MT-E11 إعادة إرسال دفعة بنفس المحتوى تُرجع النتيجة المخزَّنة (idempotent)', (function () { var res = s8.importBatch({ runId: runId, actor: DEV, batchId: runId + ':3', kind: 'x', classId: DEMO, rows: [], hash: b0.hash }); return res === b0.result; })());
  // رفض خادم لسجل واحد (مثلاً تلاعب) ⇒ bisect يعزل السجل ويكمل الباقي
  var tam = O.buildPlan(x.storage), victim = tam.rows.payments[3];
  victim.amount = -1; victim.content_hash = O.H(O.canon(Object.fromEntries(O.MAP.targets.payments.contentFields.map(function (k) { return [k, victim[k]]; }))));
  var s9 = new O.FakeServer(), r9 = O.runMigration(tam, s9, approvalCtx(tam));
  check('MT-E12 سجل واحد فاسد يرفضه الخادم ⇒ تقسيم ثنائي يعزله (serverQuarantine=1) وبقية الدفعة تُحفظ', r9.serverQuarantine.length === 1 && r9.serverQuarantine[0].record_id === victim.record_id && r9.batches.bisected >= 1 && s9.aggregates(victim.class_id).payments.total === x.truth.classes[victim.class_id].payments - 1 && r9.reconcile.ok);
  var sa = new O.FakeServer(), ra = go(p, sa, { deviceId: 'A', crashAfterBatches: undefined }); // ينتهي
  var sb = new O.FakeServer(); sb.runs.set('busy', { runId: 'busy', status: 'running', deviceId: 'B', classIds: [DEMO], leaseUntil: Date.parse(sb.now()) + 600000, actor: DEV });
  check('MT-E13 جهاز آخر يحمل lease على نفس الصف ⇒ RUN-BUSY ولا كتابة', (function () { var r = go(p, sb); return r.blockers.indexOf('RUN-BUSY') >= 0 && sb.totalRows() === 0; })());
  var sc = new O.FakeServer(); sc.runs.set('old', { runId: 'old', status: 'running', deviceId: 'B', classIds: [DEMO], leaseUntil: Date.parse(sc.now()) - 1, actor: DEV });
  check('MT-E14 lease منتهٍ يُستولى عليه (لا قفل أبدي بعد انهيار جهاز)', go(p, sc).status === 'verified');
  var sd = new O.FakeServer(); sd.faults.push({ op: 'importBatch', nth: 1, kind: 'timeout-after-commit' });
  check('MT-E15 مهلة بعد حفظ أول دفعة (الصفوف) لا تكرر الصف', go(p, sd).status === 'verified' && sd.liveRows('classes').length === 2);
})();

// ===== F: تعارض جهازين =====
function twoDevices(seed) { var a = ds(seed), b = a.storage.clone(); return { A: a, B: b, planA: O.buildPlan(a.storage) }; }
(function () {
  var t = twoDevices(51), srv = new O.FakeServer(), ra = go(t.planA, srv), pb = O.buildPlan(t.B), rb = go(pb, srv, { deviceId: 'B' });
  check('MT-F01 جهازان بنسخة متطابقة من نفس البيانات: الثاني كله already (لا مضاعفة)', ra.status === 'verified' && rb.status === 'verified' && JSON.stringify(rb.tally).indexOf('"inserted":0') >= 0 && Object.keys(rb.tally).every(function (c) { return Object.keys(rb.tally[c]).every(function (k) { return rb.tally[c][k].inserted === 0; }); }));
  // نفس recordId بمحتوى مختلف
  var t2 = twoDevices(52), srv2 = new O.FakeServer(); go(t2.planA, srv2);
  setRaw(t2.B, PK(DEMO), function (r) { r.records[0].amount += 500; return r; });
  var pb2 = O.buildPlan(t2.B), rb2 = go(pb2, srv2, { deviceId: 'B' }), rid = JSON.parse(t2.B.getItem(PK(DEMO))).records[0].recordId, serverAmt = srv2.getRow('payments', DEMO, rid).amount;
  check('MT-F02 نفس recordId بمبلغ مختلف: الخادم يبقى كما هو (keep-server) ويُبلَّغ التعارض ولا يُطمس', rb2.status === 'verified-with-exceptions' && rb2.conflicts.length === 1 && rb2.conflicts[0].type === 'conflict-id' && serverAmt === JSON.parse(t2.A.storage.getItem(PK(DEMO))).records[0].amount);
  check('MT-F03 قرار take-local الصريح فقط يغيّر القيمة (ويُحسب taken-local ويتوازن)', (function () {
    var dec = { conflicts: {} }; dec.conflicts['payments|' + DEMO + '|' + rid] = 'take-local';
    var p3 = O.buildPlan(t2.B, { decisions: dec }), r3 = go(p3, srv2, { deviceId: 'B' });
    return r3.reconcile.ok && srv2.getRow('payments', DEMO, rid).amount === JSON.parse(t2.B.getItem(PK(DEMO))).records[0].amount && r3.conflicts.length === 0;
  })());
  // تعارض مفتاح طبيعي: حضور لنفس (طالب، تاريخ) بمعرّف مختلف
  var t3 = twoDevices(53), srv3 = new O.FakeServer(); go(t3.planA, srv3);
  var recA = JSON.parse(t3.A.storage.getItem(AK(DEMO))).records[0];
  setRaw(t3.B, AK(DEMO), function (r) { r.records = r.records.filter(function (x) { return x.recordId !== recA.recordId; }); r.records.push({ recordId: 'att_B_same', classId: DEMO, studentId: recA.studentId, date: recA.date, status: recA.status, note: recA.note || '', createdAt: recA.createdAt, updatedAt: recA.updatedAt }); return r; });
  var rb3 = go(O.buildPlan(t3.B), srv3, { deviceId: 'B' });
  check('MT-F04 حضور مكافئ بمعرّف مختلف ⇒ equivalent (لا صف ثانٍ ولا تعارض)', rb3.status === 'verified' && Object.keys(rb3.tally[DEMO].attendance).length && rb3.tally[DEMO].attendance.equivalent === 1 && srv3.liveRows('attendance', DEMO).filter(function (r) { return r.student_id === recA.studentId && r.date === recA.date; }).length === 1);
  setRaw(t3.B, AK(DEMO), function (r) { r.records.forEach(function (x) { if (x.recordId === 'att_B_same') x.status = recA.status === 'absent' ? 'present' : 'absent'; }); return r; });
  var rb3b = go(O.buildPlan(t3.B), srv3, { deviceId: 'B' });
  check('MT-F05 حضور بحالة مختلفة لنفس (طالب، تاريخ) ⇒ conflict-natural، الخادم دون تغيير، والتوازن سليم', rb3b.conflicts.some(function (c) { return c.type === 'conflict-natural'; }) && srv3.liveRows('attendance', DEMO).filter(function (r) { return r.student_id === recA.studentId && r.date === recA.date; }).length === 1 && rb3b.reconcile.ok);
  // دفعتان متطابقتان من جهازين بمعرّفين مختلفين: لا إزالة تلقائية
  var t4 = twoDevices(54), srv4 = new O.FakeServer(); go(t4.planA, srv4);
  var stu = t4.A.truth.classes[DEMO].studentIds[1];
  setRaw(t4.B, PK(DEMO), function (r) { r.records.push({ recordId: 'pay_B_twin', classId: DEMO, studentId: stu, amount: 7000, purpose: 'مبلغ اختباري', date: '2026-09-25', receiptNo: '', note: '', createdAt: '2026-09-25T08:00:00.000Z', updatedAt: '2026-09-25T08:00:00.000Z' }, { recordId: 'pay_A_twin', classId: DEMO, studentId: stu, amount: 7000, purpose: 'مبلغ اختباري', date: '2026-09-25', receiptNo: '', note: '', createdAt: '2026-09-25T08:00:00.000Z', updatedAt: '2026-09-25T08:00:00.000Z' }); return r; });
  var before4 = srv4.aggregates(DEMO).payments, rb4 = go(O.buildPlan(t4.B), srv4, { deviceId: 'B' });
  check('MT-F06 مقبوضات متطابقة بمعرّفين مختلفين تُستورد كلتاهما (لا حذف تكرار تلقائي للمال) + تُحسب', rb4.status === 'verified' && srv4.aggregates(DEMO).payments.sum === before4.sum + 14000 && srv4.aggregates(DEMO).payments.total === before4.total + 2);
  // الصف التجريبي بإعدادات مختلفة على جهازين
  var t5 = twoDevices(55), srv5 = new O.FakeServer(); go(t5.planA, srv5);
  setRaw(t5.B, 'marsa.classes', function (r) { r.classes[0].section = 'ب'; return r; });
  var rb5 = go(O.buildPlan(t5.B), srv5, { deviceId: 'B' });
  check('MT-F07 الصف التجريبي بحقول مختلفة (نفس classId الثابت) ⇒ تعارض صف، الخادم يبقى', rb5.conflicts.some(function (c) { return c.kind === 'classes'; }) && srv5.getRow('classes', DEMO).section === '');
  // دمج هوية صريح
  var t6 = twoDevices(56), srv6 = new O.FakeServer(); go(t6.planA, srv6);
  var oldId = t6.A.truth.classes[DEMO].studentIds[0], newId = 'stu-B-same-person';
  setRaw(t6.B, RK(DEMO).replace('marsa.roster.' + DEMO, 'marsa.roster'), function (r) { var s = r.students.filter(function (x) { return x.studentId === oldId; })[0]; s.studentId = newId; s.studentCode = 'MR-ZZZZZ2'; return r; });
  ['attendance', 'grades', 'payments'].forEach(function (ty) { setRaw(t6.B, 'marsa.academic.' + ty + '.' + DEMO, function (r) { r.records.forEach(function (x) { if (x.studentId === oldId) { x.studentId = newId; x.recordId = x.recordId + '_B'; } }); return r; }); });
  var p6 = O.buildPlan(t6.B), rb6 = go(p6, srv6, { deviceId: 'B' });
  check('MT-F08 بلا قرار دمج: الطالب المكرر (معرّف جديد) يُستورد كشخص ثانٍ — لا دمج صامت', rb6.status !== 'blocked' && srv6.liveRows('students', DEMO).some(function (r) { return r.student_id === newId; }) && srv6.liveRows('students', DEMO).some(function (r) { return r.student_id === oldId; }));
  var t7 = twoDevices(56), srv7 = new O.FakeServer(); go(t7.planA, srv7);
  setRaw(t7.B, 'marsa.roster', function (r) { var s = r.students.filter(function (x) { return x.studentId === oldId; })[0]; s.studentId = newId; s.studentCode = 'MR-ZZZZZ2'; return r; });
  ['attendance', 'grades', 'payments'].forEach(function (ty) { setRaw(t7.B, 'marsa.academic.' + ty + '.' + DEMO, function (r) { r.records.forEach(function (x) { if (x.studentId === oldId) { x.studentId = newId; x.recordId = x.recordId + '_B'; } }); return r; }); });
  var dec7 = { studentRemap: {} }; dec7.studentRemap[DEMO] = {}; dec7.studentRemap[DEMO][newId] = oldId;
  var p7 = O.buildPlan(t7.B, { decisions: dec7 }), rb7 = go(p7, srv7, { deviceId: 'B' }), payBefore = srv7.aggregates(DEMO).payments.sum;
  check('MT-F09 قرار studentRemap صريح: لا طالب جديد، السجلات تُنسب للمعرّف الأصلي، تتبّع legacy_student_id، والميزان سليم', rb7.reconcile.ok && !srv7.liveRows('students', DEMO).some(function (r) { return r.student_id === newId; }) && srv7.liveRows('payments', DEMO).some(function (r) { return r.legacy_student_id === newId && r.student_id === oldId; }) && payBefore > 0);
})();

// ===== G: المطابقة تكشف التلف =====
(function () {
  var x = ds(61), p = O.buildPlan(x.storage), srv = new O.FakeServer(), rep = go(p, srv);
  var pr = srv.liveRows('payments', DEMO)[0]; srv.serverEdit('payments', DEMO, pr.record_id, { amount: pr.amount + 1 });
  var rc = O.reconcile(p, rep, srv);
  check('MT-G01 تعديل مبلغ على الخادم بعد الاستيراد يُكشف في read-back (READBACK-MISMATCH)', !rc.ok && rc.problems.some(function (q) { return q.code === 'READBACK-MISMATCH' && q.kind === 'payments'; }));
  var y = ds(62), p2 = O.buildPlan(y.storage), s2 = new O.FakeServer(), r2 = go(p2, s2), at = s2.liveRows('attendance', DEMO)[0];
  s2.t.attendance.get(DEMO + '|' + at.record_id).deleted_at = 'x';
  check('MT-G02 فقدان سجل حضور من الخادم يُكشف', !O.reconcile(p2, r2, s2).ok);
  check('MT-G03 كل صف في تقرير المطابقة متوازن: المصدر = المستورد + المحجور (دفتر الحساب)', (function () { var z = ds(63), pz = O.buildPlan(z.storage), sz = new O.FakeServer(), rz = go(pz, sz); return rz.reconcile.rows.length === 2 * 9 && rz.reconcile.rows.every(function (r) { return r.balanced && r.readback; }); })());
  check('MT-G04 مجموع المقبوضات المصدر = الخادم لكل صف', (function () { var z = ds(64), pz = O.buildPlan(z.storage), sz = new O.FakeServer(), rz = go(pz, sz); return rz.reconcile.rows.filter(function (r) { return r.kind === 'payments'; }).every(function (r) { return r.sums.ok; }); })());
})();

// ===== H: التراجع =====
(function () {
  var x = ds(71), before = snap(x.storage), p = O.buildPlan(x.storage), srv = new O.FakeServer(), rep = go(p, srv);
  check('MT-H01 بعد الاستيراد: المحلي لم يتغير إطلاقاً (كل المفاتيح والقيم)', snap(x.storage) === before);
  var rb = srv.rollbackRun(rep.runId, DEV);
  check('MT-H02 تراجع نظيف: كل الصفوف المستوردة علامة حذف، 0 باقٍ، المحلي سليم', rb.ok && rb.tombstoned === p.rows.classes.length + p.rows.classSettings.length + p.rows.students.length + p.rows.content.length + p.rows.attendance.length + p.rows.grades.length + p.rows.payments.length && srv.totalRows() === 0 && snap(x.storage) === before);
  var rep2 = go(p, srv);
  check('MT-H03 إعادة الاستيراد بعد التراجع تُحيي الصفوف (revived) وتتطابق مع الأصل', rep2.status === 'verified' && rep2.reconcile.ok && srv.aggregates(DEMO).payments.sum === x.truth.classes[DEMO].paymentSum);
  var y = ds(72), p2 = O.buildPlan(y.storage), s2 = new O.FakeServer(), r2 = go(p2, s2);
  var edited = s2.liveRows('payments', DEMO)[0]; s2.serverEdit('payments', DEMO, edited.record_id, { note: 'عُدّلت بعد الاستيراد' });
  var rb2 = s2.rollbackRun(r2.runId, DEV);
  check('MT-H04 التراجع لا يمسّ ما عُدِّل بعد الاستيراد (keptEdited=1) ولا الطلاب الذين لهم سجلات باقية', rb2.keptEdited === 1 && rb2.keptDependents >= 1 && s2.getRow('payments', DEMO, edited.record_id).deleted_at === null);
  var z = ds(73), p3 = O.buildPlan(z.storage), s3 = new O.FakeServer(), r3 = go(p3, s3); s3.markCutover(DEMO);
  check('MT-H05 بعد cutover يُمنع التراجع العادي (يلزم force صريح)', s3.rollbackRun(r3.runId, DEV).status === 'cutover-blocks-rollback' && s3.rollbackRun(r3.runId, DEV, { force: true }).ok);
  check('MT-H06 التراجع للمطور فقط', (function () { var w = ds(74), pw = O.buildPlan(w.storage), sw = new O.FakeServer(), rw = go(pw, sw); return sw.rollbackRun(rw.runId, { userId: 'r', role: 'rep', classIds: [DEMO] }).status === 'denied' && sw.totalRows() > 0; })());
})();

// ===== I: النسخ الاحتياطي والاستعادة =====
(function () {
  var x = ds(81), exp = O.makeLocalExport(x.storage), v = O.verifyExport(exp);
  check('MT-I01 التصدير: كل مفاتيح marsa.* ما عدا marsa.ui وmarsa.migration.*، وبصمة لكل مفتاح وللملف', v.ok && exp.entries.every(function (e) { return O.exportable(e.key); }) && exp.entries.some(function (e) { return e.key === 'marsa.roster'; }) && !exp.entries.some(function (e) { return e.key === 'marsa.ui'; }));
  var bad = JSON.parse(JSON.stringify(exp)); bad.entries[2].raw += ' ';
  check('MT-I02 تلاعب بسطر واحد يُكشف (ENTRY-HASH + MANIFEST-HASH)', O.verifyExport(bad).errors.some(function (e) { return e.indexOf('ENTRY-HASH') === 0; }));
  var bad2 = JSON.parse(JSON.stringify(exp)); bad2.entries.pop();
  check('MT-I03 حذف مفتاح من الملف يُكشف (MANIFEST-HASH)', O.verifyExport(bad2).errors.indexOf('MANIFEST-HASH') >= 0);
  var empty = new S.MemStorage(), r = O.restoreLocal(empty, exp);
  var same = Object.keys(x.storage.dump()).filter(O.exportable).every(function (k) { return empty.getItem(k) === x.storage.getItem(k); });
  check('MT-I04 الاستعادة إلى تخزين فارغ: مطابقة بايت-ببايت وبنفس بصمة الخطة', r.ok && same && O.buildPlan(empty).sourceFingerprint === O.buildPlan(x.storage).sourceFingerprint);
  var dirty = new S.MemStorage(); dirty.setItem('marsa.roster', 'قيمة مختلفة'); var rc = O.restoreLocal(dirty, exp);
  check('MT-I05 تعارض مفتاح موجود: لا كتابة فوقه افتراضياً (conflicts) ولا يُلمس شيء', !rc.ok && rc.status === 'conflicts' && dirty.getItem('marsa.roster') === 'قيمة مختلفة' && dirty.length === 1);
  var ro = O.restoreLocal(dirty, exp, { mode: 'backup-then-overwrite', ts: 't1' });
  check('MT-I06 backup-then-overwrite: القديم محفوظ تحت اللاحقة الآمنة ثم يُكتب الجديد ويُتحقق', ro.ok && dirty.getItem('marsa.roster.backup.prerestore-t1') === 'قيمة مختلفة' && dirty.getItem('marsa.roster') === x.storage.getItem('marsa.roster'));
  var tiny = new S.MemStorage({ limit: 300 }), rq = O.restoreLocal(tiny, exp);
  check('MT-I07 تخزين ممتلئ في المنتصف ⇒ failed-reverted وتُعاد الحالة لما كانت (لا استعادة نصفية)', !rq.ok && rq.status === 'failed-reverted' && tiny.length === 0);
  var src = fs.readFileSync(path.join(ROOT, 'js/app.js'), 'utf8'), rx = /bak = (\/\\\.\(backup\|premigrate-v1\)\/)\.test\(k\)/.exec(src);
  var bakRe = rx ? new RegExp('\\.(backup|premigrate-v1)') : null;
  check('MT-I08 مخطط app.js: scanCodes يعدّ النسخ عبر /\\.(backup|premigrate-v1)/ (لا يزال كما افترضه التصميم)', !!rx);
  check('MT-I09 لاحقة الاستعادة .backup.prerestore-* تُعدّ نسخة (لا تحجز أكواداً حيّة)، بينما لاحقة .prerestore وحدها لا (خطر موثّق)', bakRe.test('marsa.roster.x.backup.prerestore-t1') && !bakRe.test('marsa.roster.x.prerestore-t1'));
  // نسخة الخادم ثم استعادتها
  var y = ds(82), py = O.buildPlan(y.storage), srv = new O.FakeServer(); go(py, srv);
  var sexp = srv.exportAll(), fresh = new O.FakeServer(), rs = O.restoreServerExport(sexp, fresh, DEV);
  check('MT-I10 تصدير الخادم ثم استعادته إلى خادم فارغ عبر نفس خط الاستيراد: تطابق كامل وأعداد ومجاميع', rs.ok && JSON.stringify(fresh.exportAll()) === JSON.stringify(sexp) && Object.keys(y.truth.classes).every(function (c) { return fresh.aggregates(c).payments.sum === y.truth.classes[c].paymentSum; }));
  check('MT-I11 الاستعادة للمطور فقط (restore_op في 5.04)', O.restoreServerExport(sexp, new O.FakeServer(), { userId: 'r', role: 'rep', classIds: [DEMO] }).status === 'denied');
})();

// ===== J: أمان / رفض =====
(function () {
  var x = ds(91), p = O.buildPlan(x.storage);
  check('MT-J01 الاستيراد للمطور فقط افتراضياً: ممثل الصف نفسه مرفوض (متوافق مع 5.04) ولا كتابة', (function () { var s = new O.FakeServer(), r = go(p, s, { actor: { userId: 'rep', role: 'rep', classIds: [DEMO, cidOf(x, 1)] } }); return r.blockers.indexOf('DENIED') >= 0 && s.totalRows() === 0 && s.audit.some(function (e) { return e.eventType === 'access.denied'; }); })());
  check('MT-J02 طالب/مجهول مرفوضان', ['student', 'anonymous'].every(function (role) { var s = new O.FakeServer(); return go(p, s, { actor: { userId: 'u', role: role, classIds: [DEMO] } }).blockers.indexOf('DENIED') >= 0 && s.totalRows() === 0; }));
  check('MT-J03 قرار DEC-15 (allowRepImport) يسمح لممثل صفه فقط لا لصف آخر', (function () { var s = new O.FakeServer({ allowRepImport: true }); var ok = go(p, s, { actor: { userId: 'rep', role: 'rep', classIds: [DEMO, cidOf(x, 1)] } }).status === 'verified'; var s2 = new O.FakeServer({ allowRepImport: true }); var no = go(p, s2, { actor: { userId: 'rep', role: 'rep', classIds: [DEMO] } }).blockers.indexOf('DENIED') >= 0; return ok && no && s2.totalRows() === 0; })());
  // دفعة معدّلة من العميل
  var s = new O.FakeServer(), run = s.startRun({ actor: DEV, deviceId: 'A', classIds: [DEMO], planFingerprint: p.sourceFingerprint }), b = O.makeBatches(p, run.runId)[0];
  function send(kind, cid, rows, extra) { return s.importBatch(Object.assign({ runId: run.runId, actor: DEV, batchId: run.runId + ':t' + Math.random(), kind: kind, classId: cid, rows: rows, hash: 'h' }, extra || {})); }
  send(b.kind, b.classId, b.rows);
  var stuRows = O.makeBatches(p, run.runId).filter(function (q) { return q.kind === 'students' && q.classId === DEMO; })[0].rows;
  send('students', DEMO, stuRows);
  var payRow = JSON.parse(JSON.stringify(p.rows.payments.filter(function (r) { return r.class_id === DEMO; })[0]));
  function fix(r) { r.content_hash = O.H(O.canon(Object.fromEntries(O.MAP.targets.payments.contentFields.map(function (k) { return [k, r[k]]; })))); return r; }
  check('MT-J04 صف من صف آخر داخل دفعة صف ⇒ مرفوض CLASS-MISMATCH', send('payments', cidOf(x, 1), [payRow]).errors[0].code === 'CLASS-MISMATCH');
  check('MT-J05 مبلغ سالب/كسري مع بصمة صحيحة ⇒ مرفوض من الخادم (لا يثق بالعميل)', [-5, 1.5, 0, 2 ** 60].every(function (a) { var r = fix(Object.assign({}, payRow, { amount: a })); return send('payments', DEMO, [r]).errors[0].code === 'BAD-PAYMENT'; }));
  check('MT-J06 بصمة لا تطابق المحتوى ⇒ HASH-MISMATCH (سلامة النقل)', send('payments', DEMO, [Object.assign({}, payRow, { purpose: 'مغيَّر' })]).errors[0].code === 'HASH-MISMATCH');
  check('MT-J07 عمود غير معروف أو __proto__ ⇒ مرفوض', send('payments', DEMO, [Object.assign({}, payRow, { is_admin: true })]).errors[0].code.indexOf('UNKNOWN-COLUMN') === 0 && send('payments', DEMO, [JSON.parse(JSON.stringify(payRow).replace('{', '{"__proto__":{"x":1},'))]).status === 'rejected');
  check('MT-J08 طالب غير موجود (FK) ⇒ دفعة كاملة مرفوضة بلا كتابة جزئية', (function () { var r = fix(Object.assign({}, payRow, { student_id: 'ghost' })), before = s.totalRows(), res = send('payments', DEMO, [payRow, r]); return res.errors[0].code === 'FK-STUDENT' && s.totalRows() === before; })());
  check('MT-J09 دفعة أكبر من الحد مرفوضة too-large', send('payments', DEMO, new Array(O.MAP.limits.batchMaxRecords + 1).fill(payRow)).status === 'too-large');
  check('MT-J10 درجة > القصوى وnat_key خاطئ للدرجات ⇒ مرفوضان', (function () { var g = JSON.parse(JSON.stringify(p.rows.grades.filter(function (r) { return r.class_id === DEMO; })[0])); function fg(r) { r.content_hash = O.H(O.canon(Object.fromEntries(O.MAP.targets.grades.contentFields.map(function (k) { return [k, r[k]]; })))); return r; } return send('grades', DEMO, [fg(Object.assign({}, g, { score: g.max_score + 1 }))]).errors[0].code === 'BAD-GRADE' && send('grades', DEMO, [Object.assign({}, g, { nat_key: 'x' })]).errors[0].code === 'BAD-NATKEY'; })());
  check('MT-J12 importBatch مباشرة بدور طالب/ممثل غير مصرَّح/مجهول على run سليم ⇒ denied ولا كتابة (الفحص على كل دفعة لا عند البدء فقط)', (function () { var before = s.totalRows(); return [{ userId: 'u', role: 'student', classIds: [DEMO] }, { userId: 'r', role: 'rep', classIds: [DEMO] }, null].every(function (a) { return send('payments', DEMO, [payRow], { actor: a }).status === 'denied'; }) && s.totalRows() === before; })());
  check('MT-J13 payload محتوى بمفتاح __proto__ ببصمة صحيحة ⇒ UNSAFE-KEY من الخادم', (function () { var c = JSON.parse(JSON.stringify(p.rows.content.filter(function (r) { return r.class_id === DEMO; })[0])); c.payload = JSON.parse('{"__proto__":{"x":1},"subject":"س"}'); c.content_hash = O.H(O.canon(Object.fromEntries(O.MAP.targets.content.contentFields.map(function (k) { return [k, c[k]]; })))); return send('content', DEMO, [c]).errors[0].code === 'UNSAFE-KEY'; })());
  check('MT-J11 لا أسرار/مفاتيح/بيانات طلاب في الخطة: لا مفاتيح service أو رموز دخول', (function () { var j = JSON.stringify(p); return !/service_role|apikey|api_key|password|secret|eyJ[A-Za-z0-9_-]{20,}/i.test(j) && !/marsa\.roster/.test(JSON.stringify(Object.keys(p.rows))); })());
})();

// ===== K: بوابات المنع =====
(function () {
  var x = ds(101), p = O.buildPlan(x.storage), s = new O.FakeServer();
  function blocked(extra, code) { var r = O.runMigration(p, new O.FakeServer(), Object.assign(approvalCtx(p), extra)); return r.status === 'blocked' && r.blockers.indexOf(code) >= 0; }
  check('MT-K01 بلا موافقة ⇒ NOT-APPROVED', blocked({ approval: null }, 'NOT-APPROVED'));
  check('MT-K02 موافقة على بصمة قديمة (المصدر تغيّر بعد المعاينة) ⇒ NOT-APPROVED', (function () { var old = O.approve(p), c = x.storage.clone(); setRaw(c, PK(DEMO), function (r) { r.records[0].amount += 1; return r; }); var p2 = O.buildPlan(c); return O.runMigration(p2, new O.FakeServer(), { actor: DEV, deviceId: 'A', approval: old, backup: { verified: true } }).blockers.indexOf('NOT-APPROVED') >= 0; })());
  check('MT-K03 بلا نسخة احتياطية موثَّقة ⇒ NO-VERIFIED-BACKUP', blocked({ backup: { verified: false } }, 'NO-VERIFIED-BACKUP') && blocked({ backup: null }, 'NO-VERIFIED-BACKUP'));
  check('MT-K04 تخزين متصفح غير دائم (ذاكرة جلسة) ⇒ LOCAL-STORAGE-VOLATILE', blocked({ persistent: false }, 'LOCAL-STORAGE-VOLATILE'));
  check('MT-K05 المصدر تغيّر أثناء/قبل التشغيل (currentStorage) ⇒ SOURCE-CHANGED', (function () { var c = x.storage.clone(); setRaw(c, AK(DEMO), function (r) { r.records.pop(); return r; }); return blocked({ currentStorage: c }, 'SOURCE-CHANGED'); })());
  check('MT-K06 خطة محجوبة كلياً (سجل صفوف تالف) ⇒ PLAN-BLOCKED', (function () { var c = x.storage.clone(); c.setItem('marsa.classes', '#'); var pb = O.buildPlan(c); return O.runMigration(pb, new O.FakeServer(), { actor: DEV, deviceId: 'A', approval: O.approve(pb), backup: { verified: true } }).blockers.indexOf('PLAN-BLOCKED') >= 0; })());
  check('MT-K07 صف محجوب لا يمنع صفاً سليماً: يُرحَّل السليم ويُسرد المحجوب (skippedClasses)', (function () { var c = x.storage.clone(); c.setItem(PK(cidOf(x, 1)), '{x'); var pb = O.buildPlan(c), sv = new O.FakeServer(), r = O.runMigration(pb, sv, { actor: DEV, deviceId: 'A', approval: O.approve(pb), backup: { verified: true } }); return r.status.indexOf('verified') === 0 && r.skippedClasses.length === 1 && sv.liveRows('classes').length === 1; })());
  check('MT-K08 مصدر ثابت أثناء التشغيل (فحص currentStorage بعده) ⇒ verified بلا driftAfter', (function () { var c = x.storage.clone(), pb = O.buildPlan(c), sv = new O.FakeServer(), r = O.runMigration(pb, sv, Object.assign(approvalCtx(pb), { currentStorage: c })); return r.status === 'verified'; })());
  var spy = x.storage.clone(); spy.resetLog(); var pk = O.buildPlan(spy), r = go(pk, new O.FakeServer(), { currentStorage: spy });
  check('MT-K09 دورة كاملة (جرد+خطة+ترحيل+مطابقة) لا تكتب ولا تحذف أي مفتاح محلي إطلاقاً', spy.sets.length === 0 && spy.removes.length === 0 && snap(spy) === snap(x.storage));
})();

// ===== L: مطابقة الكود الحالي (لا انجراف بين التصميم والتطبيق) =====
(function () {
  var src = fs.readFileSync(path.join(ROOT, 'js/app.js'), 'utf8'), asrc = fs.readFileSync(path.join(ROOT, 'js/academic-store.js'), 'utf8');
  function line(re) { var m = re.exec(src); if (!m) throw new Error('missing ' + re); return m[0]; }
  function fnSrc(name) { var i = src.indexOf('function ' + name + '('), d = 0, j, started = false; for (j = src.indexOf('{', i); j < src.length; j++) { if (src[j] === '{') { d++; started = true; } else if (src[j] === '}') { d--; if (started && d === 0) return src.slice(i, j + 1); } } throw new Error('fn ' + name); }
  var ctx = vm.createContext({ Date: Date, Array: Array, String: String, Object: Object, JSON: JSON, isNaN: isNaN });
  vm.runInContext(line(/var DEMO_ID = '[^']+';/) + line(/var STORE_KEY = [^;]+;/) + line(/var CLASSES_KEY = [^;]+;/), ctx);
  vm.runInContext(line(/var FIELD_DEFS = \[[\s\S]*?\n  \];/), ctx);
  ['cleanName', 'validDate', 'parseRoster', 'normClass'].forEach(function (n) { vm.runInContext(fnSrc(n), ctx); });
  check('MT-L01 ثوابت app.js: DEMO_ID وSCHEMA=2 وSTORE_KEY وCLASSES_KEY كما بُني عليها التصميم', vm.runInContext("DEMO_ID === 'cls_demo_001' && SCHEMA === 2 && STORE_KEY === 'marsa.roster' && CLASSES_KEY === 'marsa.classes' && CLASSES_SCHEMA === 1 && MAX_FIELD === 80", ctx));
  var rnd = S.rng(777), N = 700, agree = 0, base = { schemaVersion: 2, classId: 'cls_x', students: [{ studentId: 'a1', name: 'اسم', status: 'active', createdAt: '2026-01-01T00:00:00Z', archivedAt: null, studentCode: 'MR-ABCDEF' }, { studentId: 'a2', name: ' م‏حمد  علي ', status: 'archived', createdAt: 'bad', archivedAt: '2026-02-01', studentCode: '' }] };
  var muts = [function (o) { delete o.schemaVersion; }, function (o) { o.schemaVersion = 5; }, function (o) { o.schemaVersion = '2'; }, function (o) { o.classId = null; }, function (o) { o.classId = 'cls_demo_001'; }, function (o) { delete o.classId; }, function (o) { o.students = {}; }, function (o) { o.students.push(null); }, function (o) { o.students.push({ studentId: 'a1', name: 'مكرر', status: 'active' }); }, function (o) { o.students[0].name = '‏ '; }, function (o) { o.students[0].status = 'x'; }, function (o) { o.students[0].studentId = 7; }, function (o) { o.students[1].archivedAt = 'nope'; }, function (o) { o.students[0].extra = { a: 1 }; }, function (o) { o.students[0].studentCode = 12; }, function () { }];
  var cls = ['cls_x', 'cls_demo_001', 'cls_y'];
  for (var i = 0; i < N; i++) {
    var o = JSON.parse(JSON.stringify(base)), k = 1 + Math.floor(rnd() * 3), j; for (j = 0; j < k; j++) { try { muts[Math.floor(rnd() * muts.length)](o); } catch (e) { /* طفرة غير قابلة للتطبيق بعد طفرة سابقة */ } }
    var raw = rnd() < 0.05 ? '{bad' + i : JSON.stringify(o), cid = cls[Math.floor(rnd() * 3)];
    var real = vm.runInContext('JSON.stringify(parseRoster(' + JSON.stringify(raw) + ',' + JSON.stringify(cid) + '))', ctx);
    if (real === JSON.stringify(O.parseRosterRef(raw, cid))) agree++;
  }
  check('MT-L02 differential: parseRoster الحقيقي من app.js = مرآة المحاكي في ' + N + ' حالة مولَّدة', agree === N, agree + '/' + N);
  agree = 0; var cm = [{ classId: 'c1', status: 'active', stage: ' س ', createdAt: '2026-01-01' }, { classId: 'bad id', status: 'active', stage: 'س' }, { classId: 'c2', status: 'archived', stage: 'س', archivedAt: 'x', branch: 7 }, { classId: 'c3', status: 'weird', stage: 'س' }, { classId: 'c4', status: 'active', stage: '' }, null, 5, { classId: 'c5', status: 'active', stage: 'ص'.repeat(200), section: ' ب​ ' }];
  cm.forEach(function (c) { if (vm.runInContext('JSON.stringify(normClass(' + JSON.stringify(c) + '))', ctx) === JSON.stringify(O.normClassRef(c))) agree++; });
  check('MT-L03 differential: normClass الحقيقي = المرآة (8 حالات حدّية)', agree === cm.length);
  var tf = /var TYPED_FIELDS = (\{[\s\S]*?\n  \});/.exec(asrc), bf = /var BASE_FIELDS = (\[[^\]]+\]);/.exec(asrc), real = vm.runInNewContext('(function(){var BASE_FIELDS=' + bf[1] + ';return ' + tf[1].replace(/BASE_FIELDS\.concat/g, 'BASE_FIELDS.concat') + ';})()');
  var camel = { attendance: O.MAP.targets.attendance.sourceFields, grades: O.MAP.targets.grades.sourceFields, payments: O.MAP.targets.payments.sourceFields };
  check('MT-L04 حقول الأنواع الثلاثة في قاموس mapping = TYPED_FIELDS الحقيقية تماماً (لا حقل بلا تعيين)', ['attendance', 'grades', 'payments'].every(function (t) { return JSON.stringify(camel[t].slice().sort()) === JSON.stringify(real[t].slice().sort()); }));
  check('MT-L05 الأنواع السبعة في المخزن = ما يغطيه الترحيل (4 محتوى + 3 مقيَّدة)', JSON.stringify(Store.TYPES.slice().sort()) === JSON.stringify(O.CONTENT.concat(O.CHILD).sort()));
  var sf = ['abc', 'أحمد', 'إِبراهيم  ', 'مدرسة', 'عليـً', 'ى', 'ABC def'];
  check('MT-L06 fold_v1 للخادم المحاكى = foldText الحقيقي (نفس nat_key)', sf.every(function (s) { return O.serverFold(s) === Store.foldText(s); }) && (function () { var r = S.rng(5), ok = true, i2, s2, al = 'أإآابةىيءئ ـًحمد'; for (i2 = 0; i2 < 300; i2++) { s2 = ''; for (var q = 0; q < 8; q++) s2 += al.charAt(Math.floor(r() * al.length)); if (O.serverFold(s2) !== Store.foldText(s2)) ok = false; } return ok; })());
  var d9 = ds(111), pk = O.buildPlan(d9.storage);
  check('MT-L07 nat_key المرسَل = Store.uniqueKey الحقيقي لكل درجة/حضور', pk.rows.grades.every(function (r) { return r.nat_key === Store.uniqueKey('grades', { studentId: r.student_id, subject: r.subject, title: r.title, date: r.date }); }) && pk.rows.attendance.every(function (r) { return r.nat_key === Store.uniqueKey('attendance', { studentId: r.student_id, date: r.date }); }));
  check('MT-L08 طبقة المخزن تقبل بناء سجلاتها عبر read-only (المحاكي يقرأ بالكود الحقيقي): لا مفتاح .backup جديد عند قراءة تالفة', (function () { var c = ds(112); c.storage.setItem(PK(DEMO), '{'); var n0 = c.storage.length; O.buildPlan(c.storage); return c.storage.length === n0; })());
})();

console.log('\nالنتيجة: ' + pass + ' نجاح، ' + fail + ' فشل');
process.exit(fail ? 1 : 0);
