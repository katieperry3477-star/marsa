/* 5.05 — محاكٍ مرجعي لخوارزمية ترحيل localStorage ← النظام المشترك (تصميم قابل للتنفيذ؛ لا يُحمَّل في التطبيق).
 * - القراءة المحلية: read-only بالكامل، وتستعمل MarsaAcademicStore الحقيقي لتصنيف المجموعات.
 * - الخادم: FakeServer يحاكي دلالات Postgres/RPC المقترحة (idempotency، تفرّد، FK، lease، tombstone) بتحقق مستقل.
 * كل شيء متزامن عمداً ليسهل الاختبار؛ التنفيذ الحقيقي async بنفس المنطق. */
'use strict';
var crypto = require('crypto'), fs = require('fs'), path = require('path');
var Store = require('../../js/academic-store.js');
var Sched = require('../../js/schedule-model.js');
var MAP = JSON.parse(fs.readFileSync(path.join(__dirname, '../../docs/stage5/migration/mapping-dictionary.json'), 'utf8'));

var DEMO_ID = 'cls_demo_001', ROSTER_SCHEMA = 2, ID_RE = /^[A-Za-z0-9_-]{1,64}$/, CODE_RE = /^MR-[23456789A-HJKMNP-Z]{6}$/;
var CONTENT = ['dailyLessons', 'preparations', 'schedule', 'exams'], CHILD = ['attendance', 'grades', 'payments'];
var KINDS = ['students'].concat(CONTENT, CHILD);
var LIM = MAP.limits, U1 = '\u0001';

function H(s) { return crypto.createHash('sha256').update(s, 'utf8').digest('hex'); }
function canon(v) {
  if (v === undefined) return 'null';
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']';
  return '{' + Object.keys(v).sort().filter(function (k) { return v[k] !== undefined; }).map(function (k) { return JSON.stringify(k) + ':' + canon(v[k]); }).join(',') + '}';
}
function pick(o, keys) { var r = {}; keys.forEach(function (k) { r[k] = o[k] === undefined ? null : o[k]; }); return r; }
function safeCopy(o) { return Object.fromEntries(Object.keys(o).map(function (k) { return [k, o[k]]; })); } // لا يستعمل setter __proto__
function hasUnsafeKey(v) {
  if (v === null || typeof v !== 'object') return false;
  if (Array.isArray(v)) return v.some(hasUnsafeKey);
  return Object.keys(v).some(function (k) { return k === '__proto__' || hasUnsafeKey(v[k]); });
}
function readOnly(st) { return { get length() { return st.length; }, key: function (i) { return st.key(i); }, getItem: function (k) { return st.getItem(k); }, setItem: function () { throw new Error('read-only'); }, removeItem: function () { throw new Error('read-only'); } }; }

// ===== مرايا دقيقة لدوال app.js (تُقارَن بالأصل في differential test) =====
function cleanName(s) { return String(s).replace(/[​-‏‪-‮⁦-⁩﻿]/g, '').replace(/\s+/g, ' ').trim(); }
function validDate(x) { return typeof x === 'string' && !isNaN(Date.parse(x)) ? x : null; }
function simKey(s) { return cleanName(s).replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase(); }
function parseRosterRef(raw, cid) {
  var data, seen = {}, out = { st: 'ok', students: [], dropped: 0, schemaVersion: 0 };
  try { data = JSON.parse(raw); } catch (e) { data = null; }
  if (!data || typeof data !== 'object' || Array.isArray(data) || !Array.isArray(data.students) || typeof data.schemaVersion !== 'number') return { st: 'corrupt' };
  if (!(data.classId === cid || (cid === DEMO_ID && (data.classId === undefined || data.classId === null)))) return { st: 'foreign', other: data.classId };
  out.schemaVersion = data.schemaVersion;
  if (data.schemaVersion > ROSTER_SCHEMA) out.st = 'newer';
  data.students.forEach(function (s) {
    var name = s && typeof s.name === 'string' ? cleanName(s.name) : '';
    var id = s && typeof s.studentId === 'string' ? s.studentId : '';
    if (!name || !id || seen[id] || !s || (s.status !== 'active' && s.status !== 'archived')) { out.dropped++; return; }
    seen[id] = 1;
    var rec = { studentId: id, name: name, status: s.status, createdAt: validDate(s.createdAt), archivedAt: s.status === 'archived' ? validDate(s.archivedAt) : null };
    if (typeof s.studentCode === 'string' && s.studentCode) rec.studentCode = s.studentCode;
    out.students.push(rec);
  });
  return out;
}
var FIELD_KEYS = ['schoolName', 'stage', 'branch', 'section', 'year'];
function normClassRef(s) {
  var o;
  if (!s || typeof s !== 'object' || typeof s.classId !== 'string' || !ID_RE.test(s.classId)) return null;
  if (s.status !== 'active' && s.status !== 'archived') return null;
  o = { classId: s.classId, status: s.status, createdAt: validDate(s.createdAt), archivedAt: s.status === 'archived' ? validDate(s.archivedAt) : null };
  FIELD_KEYS.forEach(function (k) { o[k] = typeof s[k] === 'string' ? cleanName(s[k]).slice(0, 80) : ''; });
  return o.stage ? o : null;
}
function demoClass() { return { classId: DEMO_ID, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null }; }
function rosterKeyFor(id) { return id === DEMO_ID ? 'marsa.roster' : 'marsa.roster.' + id; }

// ===== الجرد (read-only) =====
function parseRegistry(raw) {
  var data, seen = {}, list = [], dropped = 0, hasDemo = false, status = 'ok';
  if (raw === null) return { status: 'none', list: [Object.assign(demoClass(), { origin: 'seed' })], dropped: 0 };
  try { data = JSON.parse(raw); } catch (e) { data = null; }
  if (!data || typeof data !== 'object' || !Array.isArray(data.classes) || typeof data.schemaVersion !== 'number') return { status: 'corrupt', list: [Object.assign(demoClass(), { origin: 'seed' })], dropped: 0 };
  if (data.schemaVersion > 1) status = 'newer';
  data.classes.forEach(function (s) { var c = normClassRef(s); if (!c || seen[c.classId]) { dropped++; return; } seen[c.classId] = 1; if (c.classId === DEMO_ID) hasDemo = true; c.origin = 'registry'; list.push(c); });
  if (!hasDemo) list.unshift(Object.assign(demoClass(), { origin: 'seed' }));
  list.sort(function (a, b) { return a.classId === DEMO_ID ? -1 : b.classId === DEMO_ID ? 1 : a.classId < b.classId ? -1 : a.classId > b.classId ? 1 : 0; });
  return { status: status, list: list, dropped: dropped };
}
function inventory(st) {
  var keys = [], i, inv = { registry: null, artifacts: [], unknown: [], ignored: [], foreign: 0, orphans: [], ambiguous: [], stray: [] }, ids = {};
  for (i = 0; i < st.length; i++) keys.push(st.key(i));
  keys.sort();
  inv.registry = parseRegistry(st.getItem('marsa.classes'));
  inv.registry.list.forEach(function (c) { ids[c.classId] = 1; });
  keys.forEach(function (k) {
    var m, x;
    if (k.indexOf('marsa.') !== 0) { inv.foreign++; return; }
    if (k === 'marsa.classes' || k === 'marsa.roster') return;
    if (k === 'marsa.ui' || k.indexOf('marsa.migration.') === 0) { inv.ignored.push(k); return; }
    if (k.indexOf('marsa.roster.') === 0) {
      x = k.slice(13);
      if (x === DEMO_ID) { inv.stray.push(k); return; }
      if (ids[x]) { if (x === 'backup' || x === 'premigrate-v1') inv.ambiguous.push(k); return; }
      if (x.indexOf('.') >= 0 || x === 'backup' || x === 'premigrate-v1') inv.artifacts.push(k); else inv.orphans.push({ key: k, kind: 'roster', classId: x });
      return;
    }
    if (k.indexOf('marsa.scheduleDays.') === 0) { x = k.slice(19); if (x.indexOf('.') >= 0) inv.artifacts.push(k); else if (!ids[x]) inv.orphans.push({ key: k, kind: 'setting', classId: x }); return; }
    m = /^marsa\.academic\.([^.]+)\.(.+)$/.exec(k);
    if (m) {
      if (Store.TYPES.indexOf(m[1]) < 0) { inv.unknown.push(k); return; }
      if (m[2].indexOf('.') >= 0) inv.artifacts.push(k); else if (!ids[m[2]]) inv.orphans.push({ key: k, kind: 'collection', classId: m[2] });
      return;
    }
    inv.unknown.push(k);
  });
  return inv;
}

// ===== بناء الصفوف الهدف =====
function natKeyGrade(r) { return Store.uniqueKey('grades', r); }
function withHash(kind, row) { row.content_hash = H(canon(pick(row, MAP.targets[kind].contentFields))); return row; }
function rowKey(kind, row) { return kind === 'classes' || kind === 'classSettings' ? row.class_id : kind === 'students' ? row.class_id + '|' + row.student_id : kind === 'content' ? row.class_id + '|' + row.type + '|' + row.record_id : row.class_id + '|' + row.record_id; }

function buildPlan(st, opts) {
  opts = opts || {};
  var dec = opts.decisions || {}, inv = inventory(st), ro = Store.create({ storage: readOnly(st) });
  var plan = { planVersion: 1, state: 'ready', classes: [], anomalies: [], rows: { classes: [], classSettings: [], students: [], content: [], attendance: [], grades: [], payments: [] }, quarantine: [], expected: {}, decisions: dec, inventory: { artifacts: inv.artifacts.length, unknown: inv.unknown.length, foreign: inv.foreign, ignored: inv.ignored.length } };
  var rosters = {}, codeSeen = {}, allStudents = [];
  function add(code, sev, classId, detail) { var a = { code: code, severity: sev, classId: classId || null, detail: detail || {} }; plan.anomalies.push(a); return a; }

  if (inv.registry.status === 'corrupt') add('REGISTRY-CORRUPT', 'blocker', null);
  if (inv.registry.status === 'newer') add('REGISTRY-NEWER', 'blocker', null);
  if (inv.registry.dropped) add('REGISTRY-DROPPED', 'warning', null, { n: inv.registry.dropped });
  inv.orphans.filter(function (o) { return o.kind !== 'setting'; }).forEach(function (o) { add('ORPHAN-CLASS-DATA', dec.acknowledgeOrphans ? 'warning' : 'blocker', null, { key: o.key }); });
  inv.orphans.filter(function (o) { return o.kind === 'setting'; }).forEach(function (o) { add('ORPHAN-SETTING', 'warning', null, { key: o.key }); });
  inv.ambiguous.forEach(function (k) { add('KEY-AMBIGUOUS', 'blocker', k.slice(13), { key: k }); });
  inv.stray.forEach(function (k) { add('STRAY-KEY', 'warning', null, { key: k }); });
  inv.unknown.forEach(function (k) { add('UNKNOWN-KEY', 'warning', null, { key: k }); });
  if (inv.artifacts.length) add('BACKUP-ARTIFACTS-PRESENT', 'info', null, { n: inv.artifacts.length });

  // 1) قوائم الطلاب لكل الصفوف (لفحص الأكواد عبر الصفوف)
  inv.registry.list.forEach(function (c) {
    var raw = st.getItem(rosterKeyFor(c.classId)), info = { classId: c.classId, students: [], dropped: 0, blocked: null };
    rosters[c.classId] = info;
    if (inv.ambiguous.some(function (k) { return k.slice(13) === c.classId; })) { info.blocked = 'KEY-AMBIGUOUS'; return; }
    if (raw === null) return;
    var p = parseRosterRef(raw, c.classId);
    if (p.st === 'corrupt') { info.blocked = 'ROSTER-CORRUPT'; return; }
    if (p.st === 'foreign') { info.blocked = 'ROSTER-FOREIGN'; return; }
    if (p.st === 'newer') { info.blocked = 'ROSTER-NEWER'; return; }
    if (p.schemaVersion < ROSTER_SCHEMA) { info.blocked = 'ROSTER-LEGACY-V1'; return; }
    info.students = p.students; info.dropped = p.dropped;
    p.students.forEach(function (s) { allStudents.push({ classId: c.classId, s: s }); });
  });
  allStudents.sort(function (a, b) { return a.classId < b.classId ? -1 : a.classId > b.classId ? 1 : a.s.studentId < b.s.studentId ? -1 : 1; });
  var codeOwner = {}, idSeen = {};
  allStudents.forEach(function (e) {
    var c = e.s.studentCode, k = c ? c.toUpperCase() : '';
    e.needsCode = false; e.code = null;
    if (c && CODE_RE.test(c) && !codeOwner[k]) { codeOwner[k] = e.classId + '|' + e.s.studentId; e.code = c; }
    else { e.needsCode = true; add(c && CODE_RE.test(c) ? 'STUDENT-CODE-DUPLICATE' : 'STUDENT-CODE-INVALID', 'warning', e.classId, { studentId: e.s.studentId }); }
    if (idSeen[e.s.studentId] && idSeen[e.s.studentId] !== e.classId) add('STUDENT-ID-CROSS-CLASS', 'info', e.classId, { studentId: e.s.studentId, other: idSeen[e.s.studentId] });
    idSeen[e.s.studentId] = idSeen[e.s.studentId] || e.classId;
  });
  function ent(classId, sid) { for (var i = 0; i < allStudents.length; i++) if (allStudents[i].classId === classId && allStudents[i].s.studentId === sid) return allStudents[i]; return null; }

  // 2) لكل صف
  inv.registry.list.forEach(function (c) {
    var cid = c.classId, ri = rosters[cid], blockers = [], exp = plan.expected[cid] = {}, remap = (dec.studentRemap || {})[cid] || {}, studentSet = {};
    function block(code, detail) { blockers.push(code); add(code, 'blocker', cid, detail); }
    if (ri.blocked) block(ri.blocked);
    if (inv.registry.status === 'corrupt' || inv.registry.status === 'newer') blockers.push('REGISTRY');
    if (ri.dropped) add('ROSTER-DROPPED', 'warning', cid, { n: ri.dropped });
    ri.students.forEach(function (s) { studentSet[s.studentId] = 1; });
    var colls = {};
    Store.TYPES.forEach(function (t) {
      var r = ro.readCollection(t, cid);
      if (r.ok) colls[t] = r.records;
      else block('COLLECTION-' + String(r.status).toUpperCase(), { type: t });
    });
    var sraw = st.getItem('marsa.scheduleDays.' + cid), days = null;
    if (sraw !== null) { var pd = Sched.parseDaysSetting(sraw, cid); if (pd.status === 'ok') days = pd.days; else add('SETTINGS-' + pd.status.toUpperCase(), 'warning', cid); }
    var st_ = blockers.length ? 'blocked' : 'ready';
    plan.classes.push({ classId: cid, label: c.stage + (c.branch ? ' — ' + c.branch : ''), status: c.status, origin: c.origin, state: st_, blockers: blockers });
    exp.classes = { source_total: 1, quarantined: 0, importable: 1 };
    if (st_ === 'blocked') return;
    plan.rows.classes.push(withHash('classes', { class_id: cid, school_name: c.schoolName, stage: c.stage, branch: c.branch, section: c.section, year: c.year, status: c.status, created_at: c.createdAt, archived_at: c.archivedAt, origin: c.origin }));
    if (days) plan.rows.classSettings.push(withHash('classSettings', { class_id: cid, schedule_days: days }));
    // الطلاب
    var nStu = 0;
    ri.students.forEach(function (s) {
      if (remap[s.studentId]) return; // مدموج بقرار صريح: لا يُستورد صفّه
      var e = ent(cid, s.studentId);
      plan.rows.students.push(withHash('students', { class_id: cid, student_id: s.studentId, name: s.name, status: s.status, student_code: e.code, created_at: s.createdAt, archived_at: s.archivedAt, needs_code: e.needsCode }));
      nStu++;
    });
    exp.students = { source_total: ri.students.length + ri.dropped, quarantined: ri.dropped + Object.keys(remap).length, importable: nStu };
    // تشابه الأسماء (لا دمج تلقائياً)
    var names = {};
    ri.students.forEach(function (s) { var k = simKey(s.name); (names[k] = names[k] || []).push(s.studentId); });
    Object.keys(names).forEach(function (k) { if (names[k].length > 1) add('POSSIBLE-DUPLICATE-PERSON', 'warning', cid, { ids: names[k] }); });
    // المحتوى
    CONTENT.forEach(function (t) {
      var recs = colls[t] || [], n = 0, q = 0;
      recs.forEach(function (r) {
        var payload = safeCopy(r); ['classId', 'recordId', 'createdAt', 'updatedAt'].forEach(function (k) { delete payload[k]; });
        if (hasUnsafeKey(payload) || Buffer.byteLength(JSON.stringify(payload)) > LIM.contentPayloadMaxBytes) { plan.quarantine.push({ kind: t, class_id: cid, record_id: r.recordId, reason: 'UNSAFE-OR-OVERSIZE' }); q++; return; }
        var row = { class_id: cid, type: t, record_id: r.recordId, payload: payload, source_created_at: r.createdAt || null, source_updated_at: r.updatedAt || null };
        plan.rows.content.push(withHash('content', row)); n++;
      });
      exp[t] = { source_total: recs.length, quarantined: q, importable: n };
    });
    // الحضور/الدرجات/المقبوضات
    CHILD.forEach(function (t) {
      var recs = colls[t] || [], n = 0, q = 0, sums = { amount: 0, scoreX100: 0, maxX100: 0, byStatus: {} }, unk = {};
      recs.forEach(function (r) {
        Object.keys(r).forEach(function (k) { if (MAP.targets[t].sourceFields.indexOf(k) < 0) unk[k] = 1; });
        var sid = remap[r.studentId] || r.studentId;
        if (!studentSet[r.studentId] && !remap[r.studentId]) { plan.quarantine.push({ kind: t, class_id: cid, record_id: r.recordId, reason: 'ORPHAN-STUDENT', amount: t === 'payments' ? r.amount : undefined }); q++; return; }
        var row = { class_id: cid, record_id: r.recordId, student_id: sid, date: r.date, source_created_at: r.createdAt || null, source_updated_at: r.updatedAt || null };
        if (remap[r.studentId]) row.legacy_student_id = r.studentId;
        if (t === 'attendance') { row.status = r.status; row.note = r.note || ''; row.nat_key = sid + U1 + r.date; sums.byStatus[r.status] = (sums.byStatus[r.status] || 0) + 1; }
        if (t === 'grades') { row.subject = r.subject; row.title = r.title; row.score = r.score; row.max_score = r.maxScore; row.note = r.note || ''; row.nat_key = natKeyGrade({ studentId: sid, subject: r.subject, title: r.title, date: r.date }); sums.scoreX100 += Math.round(r.score * 100); sums.maxX100 += Math.round(r.maxScore * 100); }
        if (t === 'payments') { row.amount = r.amount; row.purpose = r.purpose; row.receipt_no = r.receiptNo || ''; row.note = r.note || ''; sums.amount += r.amount; }
        plan.rows[t].push(withHash(t, row)); n++;
      });
      if (Object.keys(unk).length) add('UNKNOWN-FIELDS', 'warning', cid, { type: t, fields: Object.keys(unk).sort() });
      if (q) add('ORPHAN-RECORDS', 'warning', cid, { type: t, n: q });
      exp[t] = { source_total: recs.length, quarantined: q, importable: n, sums: sums };
      if (t === 'payments') { var seenP = {}, twin = 0; plan.rows.payments.filter(function (p) { return p.class_id === cid; }).forEach(function (p) { var k = canon(pick(p, ['student_id', 'amount', 'purpose', 'date'])); if (seenP[k]) twin++; seenP[k] = 1; }); if (twin) add('IDENTICAL-PAYMENTS', 'info', cid, { n: twin }); }
    });
  });
  if (plan.anomalies.some(function (a) { return a.severity === 'blocker' && !a.classId; })) plan.state = 'blocked';
  if (!plan.classes.some(function (c) { return c.state === 'ready'; })) plan.state = 'blocked';
  var hs = []; Object.keys(plan.rows).forEach(function (k) { plan.rows[k].forEach(function (r) { hs.push(k + '|' + rowKey(k, r) + '|' + r.content_hash); }); });
  hs.sort();
  plan.sourceFingerprint = H(canon({ rows: hs, quarantine: plan.quarantine, blocked: plan.classes.filter(function (c) { return c.state === 'blocked'; }).map(function (c) { return c.classId + ':' + c.blockers.join(','); }), decisions: dec }));
  return plan;
}
function approvalToken(plan) { return H('approve:' + plan.planVersion + ':' + plan.sourceFingerprint); }
function approve(plan) { return { token: approvalToken(plan), planFingerprint: plan.sourceFingerprint }; }

// ===== الخادم المحاكى =====
function Transient(msg) { var e = new Error(msg); e.transient = true; return e; }
function serverFold(s) { return String(s).replace(/\s+/g, ' ').trim().replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase(); }
function sDate(s) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s), d; if (!m) return false; d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])); return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3]; }
var DAY_KEYS = Sched.DAYS.map(function (d) { return d.key; });
function strOk(v, min, max) { return typeof v === 'string' && v.length >= min && v.length <= max; }
function two(n) { return typeof n === 'number' && isFinite(n) && Math.round(n * 100) / 100 === n; }
function serverValidate(kind, row, classId) {
  var allowed = MAP.targets[kind].contentFields.concat(MAP.metaFields), k;
  if (!row || typeof row !== 'object') return 'ROW-NOT-OBJECT';
  for (k in row) if (Object.prototype.hasOwnProperty.call(row, k) && allowed.indexOf(k) < 0) return 'UNKNOWN-COLUMN:' + k;
  if (hasUnsafeKey(row)) return 'UNSAFE-KEY';
  if (row.class_id !== classId) return 'CLASS-MISMATCH';
  if (!ID_RE.test(row.class_id)) return 'BAD-ID';
  if (row.content_hash !== H(canon(pick(row, MAP.targets[kind].contentFields)))) return 'HASH-MISMATCH';
  if (kind === 'classes') { if (!strOk(row.stage, 1, 80) || ['school_name', 'branch', 'section', 'year'].some(function (f) { return !strOk(row[f], 0, 80); }) || ['active', 'archived'].indexOf(row.status) < 0) return 'BAD-CLASS'; return null; }
  if (kind === 'classSettings') return Array.isArray(row.schedule_days) && row.schedule_days.length && row.schedule_days.every(function (d) { return DAY_KEYS.indexOf(d) >= 0; }) ? null : 'BAD-SETTINGS';
  if (kind === 'students') { if (!ID_RE.test(row.student_id) || !strOk(row.name, 1, 80) || ['active', 'archived'].indexOf(row.status) < 0) return 'BAD-STUDENT'; if (row.student_code !== null && !CODE_RE.test(String(row.student_code))) return 'BAD-CODE'; return null; }
  if (!ID_RE.test(row.record_id || '')) return 'BAD-RECORD-ID';
  if (kind === 'content') { if (CONTENT.indexOf(row.type) < 0 || !row.payload || typeof row.payload !== 'object' || Array.isArray(row.payload)) return 'BAD-CONTENT'; if (Buffer.byteLength(JSON.stringify(row.payload)) > LIM.contentPayloadMaxBytes) return 'PAYLOAD-TOO-LARGE'; return null; }
  if (!ID_RE.test(row.student_id) || !sDate(row.date)) return 'BAD-REF-OR-DATE';
  if (kind === 'attendance') { if (['present', 'absent', 'late', 'excused'].indexOf(row.status) < 0 || !strOk(row.note, 0, 200)) return 'BAD-ATTENDANCE'; if (row.nat_key !== row.student_id + U1 + row.date) return 'BAD-NATKEY'; }
  if (kind === 'grades') {
    if (!strOk(row.subject.trim ? row.subject.trim() : '', 1, 80) || !strOk(row.title.trim ? row.title.trim() : '', 1, 80) || !two(row.max_score) || row.max_score <= 0 || row.max_score > 1000 || !two(row.score) || row.score < 0 || row.score > row.max_score || !strOk(row.note, 0, 200)) return 'BAD-GRADE';
    if (row.nat_key !== row.student_id + U1 + serverFold(row.subject) + U1 + serverFold(row.title) + U1 + row.date) return 'BAD-NATKEY';
  }
  if (kind === 'payments') { if (typeof row.amount !== 'number' || !Number.isSafeInteger(row.amount) || row.amount <= 0 || !strOk(row.purpose.trim ? row.purpose.trim() : '', 1, 80) || !strOk(row.receipt_no, 0, 40) || !strOk(row.note, 0, 200)) return 'BAD-PAYMENT'; }
  return null;
}
function contentEq(kind, a, b) { var f = kind === 'attendance' ? ['status', 'note'] : kind === 'grades' ? ['score', 'max_score', 'note'] : null; return !!f && f.every(function (k) { return a[k] === b[k]; }); }

function FakeServer(o) {
  o = o || {};
  this.t = { classes: new Map(), classSettings: new Map(), students: new Map(), content: new Map(), attendance: new Map(), grades: new Map(), payments: new Map() };
  this.runs = new Map(); this.batches = new Map(); this.audit = []; this.faults = []; this.counts = {}; this.online = true;
  this.schemaVersion = o.schemaVersion === undefined ? 1 : o.schemaVersion; this.maxRows = o.maxRows || Infinity; this.allowRepImport = !!o.allowRepImport;
  this.t0 = Date.parse('2026-11-01T09:00:00Z'); this.tick = 0; this.cutover = {}; this.req = 0;
  this.now = o.now || function () { return new Date(this.t0 + (this.tick += 1000)).toISOString(); }.bind(this);
}
FakeServer.prototype.ping = function () { if (!this.online) throw Transient('offline'); return { ok: true, schemaVersion: this.schemaVersion }; };
FakeServer.prototype._fault = function (op) { this.counts[op] = (this.counts[op] || 0) + 1; for (var i = 0; i < this.faults.length; i++) if (this.faults[i].op === op && this.faults[i].nth === this.counts[op]) return this.faults.splice(i, 1)[0].kind; return null; };
FakeServer.prototype._audit = function (type, actor, classId, outcome, extra) { this.audit.push(Object.assign({ eventId: 'ev' + this.audit.length, eventType: type, occurredAt: this.now(), actorUserId: actor.userId, actorRole: actor.role, classId: classId || 'multi', outcome: outcome, requestId: 'rq' + (++this.req) }, extra || {})); };
FakeServer.prototype._auth = function (actor, classId) { if (!actor) return false; if (actor.role === 'developer') return true; return actor.role === 'rep' && this.allowRepImport && (actor.classIds || []).indexOf(classId) >= 0; };
FakeServer.prototype.startRun = function (r) {
  var self = this, now = Date.parse(this.now()), bad = r.classIds.filter(function (c) { return !self._auth(r.actor, c); }), busy = null;
  if (bad.length) { this._audit('access.denied', r.actor, bad[0], 'denied'); return { ok: false, status: 'denied' }; }
  this.runs.forEach(function (run) { if (run.status === 'running' && run.deviceId !== r.deviceId && run.leaseUntil > now && run.classIds.some(function (c) { return r.classIds.indexOf(c) >= 0; })) busy = run; });
  if (busy) return { ok: false, status: 'busy' };
  var id = 'run' + (this.runs.size + 1);
  this.runs.set(id, { runId: id, status: 'running', deviceId: r.deviceId, classIds: r.classIds.slice(), planFingerprint: r.planFingerprint, leaseUntil: now + LIM.leaseMinutes * 60000, actor: r.actor });
  this._audit('migration.started', r.actor, r.classIds.length === 1 ? r.classIds[0] : null, 'success', { count: r.classIds.length });
  return { ok: true, runId: id };
};
FakeServer.prototype.getRun = function (runId) { var run = this.runs.get(runId), out = []; this.batches.forEach(function (b, id) { if (b.runId === runId) out.push({ batchId: id, result: b.result }); }); return run ? { ok: true, run: run, committed: out } : { ok: false, status: 'no-run' }; };
FakeServer.prototype.finishRun = function (runId, count, outcome) { var run = this.runs.get(runId); run.status = 'finished'; this._audit('restore.executed', run.actor, null, outcome || 'success', { count: count }); };
FakeServer.prototype._live = function (kind, key, pending) { var k = kind + '|' + key, r = pending.has(k) ? pending.get(k) : this.t[kind].get(key); return r; };
FakeServer.prototype.liveRows = function (kind, classId) { var out = []; this.t[kind].forEach(function (r) { if (!r.deleted_at && (!classId || r.class_id === classId)) out.push(r); }); return out; };
FakeServer.prototype.totalRows = function () { var n = 0, self = this; Object.keys(this.t).forEach(function (k) { self.t[k].forEach(function (r) { if (!r.deleted_at) n++; }); }); return n; };
FakeServer.prototype.getRow = function (kind, classId, id) { var key = kind === 'students' ? classId + '|' + id : kind === 'classes' || kind === 'classSettings' ? classId : kind === 'content' ? classId + '|' + id : classId + '|' + id; return this.t[kind].get(key) || null; };
FakeServer.prototype.importBatch = function (q) {
  var self = this, dry = !!q.dryRun, fault = dry ? null : this._fault('importBatch'), kind = q.kind, now = this.now(), pending = new Map(), outcomes = [], writes = [], rejects = [], i;
  if (!this.online) throw Transient('offline');
  if (fault === 'drop-before-commit') throw Transient('dropped');
  if (fault === 'error500') throw Transient('500');
  if (!dry) {
    var run = this.runs.get(q.runId);
    if (!run) return { ok: false, status: 'no-run' };
    if (!this._auth(q.actor, q.classId)) { this._audit('access.denied', q.actor || { userId: 'anon', role: 'anonymous' }, q.classId, 'denied'); return { ok: false, status: 'denied' }; }
    var prev = this.batches.get(q.batchId);
    if (prev) { if (prev.hash !== q.hash) return { ok: false, status: 'batch-id-reuse' }; if (fault === 'timeout-after-commit') throw Transient('timeout'); return prev.result; }
    if (run.status !== 'running') return { ok: false, status: 'no-run' };
    if (run.leaseUntil < Date.parse(now)) return { ok: false, status: 'lease-expired' };
  } else if (!this._auth(q.actor, q.classId)) return { ok: false, status: 'denied' };
  if (!Array.isArray(q.rows) || q.rows.length > LIM.batchMaxRecords || Buffer.byteLength(JSON.stringify(q.rows)) > LIM.batchMaxBytes) return { ok: false, status: 'too-large' };
  if (!MAP.targets[kind]) return { ok: false, status: 'bad-kind' };
  for (i = 0; i < q.rows.length; i++) { var e = serverValidate(kind, q.rows[i], q.classId); if (e) rejects.push({ index: i, code: e }); }
  if (rejects.length) return { ok: false, status: 'rejected', errors: rejects };
  var dk = function (row) { return kind + '|' + rowKey(kind, row); };
  for (i = 0; i < q.rows.length; i++) {
    var row = q.rows[i], key = rowKey(kind, row), ex = this._live(kind, key, pending), oc = null, mapTo = null, dkey = kind + '|' + row.class_id + '|' + (row.record_id || row.student_id || ''), take = q.decisions && q.decisions[dkey] === 'take-local';
    if (kind !== 'classes') { var cls = this._live('classes', row.class_id, pending); if (!cls || cls.deleted_at) return { ok: false, status: 'rejected', errors: [{ index: i, code: 'FK-CLASS' }] }; }
    if (CHILD.indexOf(kind) >= 0) { var stu = this._live('students', row.class_id + '|' + row.student_id, pending); if (!stu || stu.deleted_at) return { ok: false, status: 'rejected', errors: [{ index: i, code: 'FK-STUDENT' }] }; }
    if (ex && !ex.deleted_at) {
      if (ex.content_hash === row.content_hash) oc = 'already';
      else if (take) { oc = 'taken-local'; mapTo = ex; } else oc = 'conflict-id';
    } else if (row.nat_key && (kind === 'attendance' || kind === 'grades')) {
      var other = null; this.t[kind].forEach(function (r) { if (!r.deleted_at && r.class_id === row.class_id && r.nat_key === row.nat_key && r.record_id !== row.record_id) other = r; });
      pending.forEach(function (r, k) { if (k.indexOf(kind + '|') === 0 && !r.deleted_at && r.class_id === row.class_id && r.nat_key === row.nat_key && r.record_id !== row.record_id) other = r; });
      if (other) { if (contentEq(kind, other, row)) { oc = 'equivalent'; mapTo = other; } else if (take) { oc = 'taken-local'; mapTo = other; } else { oc = 'conflict-natural'; mapTo = other; } }
    }
    if (!oc) oc = ex && ex.deleted_at ? 'revived' : 'inserted';
    outcomes.push({ i: i, outcome: oc, mapTo: mapTo ? (mapTo.record_id || mapTo.student_id || mapTo.class_id) : null });
    if (!dry) {
      if (oc === 'inserted' || oc === 'revived') { var nr = Object.assign({}, row, { import_run_id: q.runId, imported_at: now, updated_at: now, deleted_at: null }); pending.set(dk(row), nr); writes.push([kind, key, nr]); }
      if (oc === 'taken-local') { var tgt = mapTo || ex, upd = Object.assign({}, tgt, row, { record_id: tgt.record_id, student_id: kind === 'students' ? tgt.student_id : row.student_id, updated_at: now, import_run_id: q.runId, imported_at: now }); var tkey = rowKey(kind, upd); pending.set(kind + '|' + tkey, upd); writes.push([kind, tkey, upd]); }
    }
  }
  var newLive = writes.filter(function (w) { return !self.t[w[0]].has(w[1]) || self.t[w[0]].get(w[1]).deleted_at; }).length;
  if (!dry && this.totalRows() + newLive > this.maxRows) return { ok: false, status: 'quota' };
  var result = { ok: true, status: dry ? 'dry-run' : 'committed', outcomes: outcomes };
  if (!dry) { writes.forEach(function (w) { self.t[w[0]].set(w[1], w[2]); }); this.batches.set(q.batchId, { runId: q.runId, hash: q.hash, result: result }); this.runs.get(q.runId).leaseUntil = Date.parse(now) + LIM.leaseMinutes * 60000; if (fault === 'timeout-after-commit') throw Transient('timeout'); }
  return result;
};
FakeServer.prototype.serverEdit = function (kind, classId, id, patch) { var r = this.getRow(kind, classId, id); if (!r) throw new Error('no row'); Object.assign(r, patch); r.updated_at = this.now(); r.content_hash = H(canon(pick(r, MAP.targets[kind].contentFields))); return r; };
FakeServer.prototype.aggregates = function (classId) {
  var a = { students: this.liveRows('students', classId).length, attendance: { total: 0, byStatus: {} }, grades: { total: 0, scoreX100: 0, maxX100: 0 }, payments: { total: 0, sum: 0 }, content: {} };
  this.liveRows('attendance', classId).forEach(function (r) { a.attendance.total++; a.attendance.byStatus[r.status] = (a.attendance.byStatus[r.status] || 0) + 1; });
  this.liveRows('grades', classId).forEach(function (r) { a.grades.total++; a.grades.scoreX100 += Math.round(r.score * 100); a.grades.maxX100 += Math.round(r.max_score * 100); });
  this.liveRows('payments', classId).forEach(function (r) { a.payments.total++; a.payments.sum += r.amount; });
  this.liveRows('content', classId).forEach(function (r) { a.content[r.type] = (a.content[r.type] || 0) + 1; });
  return a;
};
FakeServer.prototype.markCutover = function (classId) { this.cutover[classId] = true; };
FakeServer.prototype.rollbackRun = function (runId, actor, o) {
  var self = this, res = { tombstoned: 0, keptEdited: 0, keptDependents: 0, blocked: null }, now = this.now(), ids = (this.runs.get(runId) || { classIds: [] }).classIds;
  if (!actor || actor.role !== 'developer') return { ok: false, status: 'denied' };
  if (ids.some(function (c) { return self.cutover[c]; }) && !(o && o.force)) return { ok: false, status: 'cutover-blocks-rollback' };
  ['payments', 'grades', 'attendance', 'content', 'classSettings', 'students', 'classes'].forEach(function (kind) {
    self.t[kind].forEach(function (r) {
      if (r.import_run_id !== runId || r.deleted_at) return;
      if (r.updated_at !== r.imported_at) { res.keptEdited++; return; }
      if (kind === 'students' && CHILD.some(function (k) { return self.liveRows(k, r.class_id).some(function (x) { return x.student_id === r.student_id; }); })) { res.keptDependents++; return; }
      if (kind === 'classes' && (self.liveRows('students', r.class_id).length || self.liveRows('content', r.class_id).length)) { res.keptDependents++; return; }
      r.deleted_at = now; r.rolled_back_run = runId; res.tombstoned++;
    });
  });
  this._audit('migration.rolled_back', actor, null, 'success', { count: res.tombstoned });
  return Object.assign({ ok: true }, res);
};
FakeServer.prototype.exportAll = function () { var out = { format: 'marsa-server-export', rows: {} }, self = this; Object.keys(this.t).forEach(function (k) { out.rows[k] = []; self.t[k].forEach(function (r) { if (!r.deleted_at) out.rows[k].push(pick(r, MAP.targets[k].contentFields.concat(MAP.metaFields.filter(function (m) { return r[m] !== undefined; })))); }); }); return out; };

// ===== التنفيذ =====
function makeBatches(plan, runId, lim) {
  var out = [], idx = 0, maxN = (lim && lim.maxRecords) || LIM.batchMaxRecords;
  function push(kind, classId, rows) { for (var i = 0; i < rows.length; i += maxN) { var chunk = rows.slice(i, i + maxN); out.push({ batchId: runId + ':' + (idx++), kind: kind, classId: classId, rows: chunk, hash: H(canon(chunk.map(function (r) { return r.content_hash; }))) }); } }
  var ready = plan.classes.filter(function (c) { return c.state === 'ready'; }).map(function (c) { return c.classId; });
  function of(kind, cid) { return plan.rows[kind].filter(function (r) { return r.class_id === cid; }); }
  ready.forEach(function (cid) { push('classes', cid, of('classes', cid)); });
  ready.forEach(function (cid) {
    push('classSettings', cid, of('classSettings', cid)); push('students', cid, of('students', cid));
    CONTENT.forEach(function (t) { push('content', cid, of('content', cid).filter(function (r) { return r.type === t; })); });
    CHILD.forEach(function (t) { push(t, cid, of(t, cid)); });
  });
  return out;
}
function expKind(row, kind) { return kind === 'content' ? row.type : kind; }

function runMigration(plan, server, ctx) {
  var rep = { status: null, runId: null, blockers: [], batches: { total: 0, committed: 0, retries: 0, bisected: 0, resumedSkipped: 0 }, tally: {}, rowOutcomes: {}, quarantine: plan.quarantine.slice(), skippedClasses: [], delays: [], conflicts: [], serverQuarantine: [] };
  var pre = [], batches, run, committedMap = {}, crashAfter = ctx.crashAfterBatches, doneNow = 0;
  if (plan.state === 'blocked') pre.push('PLAN-BLOCKED');
  if (!ctx.approval || ctx.approval.token !== approvalToken(plan)) pre.push('NOT-APPROVED');
  if (ctx.persistent === false) pre.push('LOCAL-STORAGE-VOLATILE');
  if (!ctx.backup || ctx.backup.verified !== true) pre.push('NO-VERIFIED-BACKUP');
  if (ctx.currentStorage && buildPlan(ctx.currentStorage, { decisions: plan.decisions }).sourceFingerprint !== plan.sourceFingerprint) pre.push('SOURCE-CHANGED');
  var info = null;
  try { info = server.ping(); } catch (e) { pre.push('OFFLINE'); }
  if (info && info.schemaVersion < (ctx.requiredServerSchema || 1)) pre.push('SERVER-SCHEMA-OLD');
  if (pre.length) { rep.status = 'blocked'; rep.blockers = pre; return rep; }

  var ready = plan.classes.filter(function (c) { return c.state === 'ready'; }).map(function (c) { return c.classId; });
  rep.skippedClasses = plan.classes.filter(function (c) { return c.state === 'blocked'; }).map(function (c) { return { classId: c.classId, blockers: c.blockers }; });
  function retry(fn) { var n = 0, last; while (n < LIM.retryAttempts) { try { return fn(); } catch (e) { if (!e.transient) throw e; last = e; rep.delays.push(LIM.retryDelaysMs[n]); n++; if (n < LIM.retryAttempts) rep.batches.retries++; } } var err = new Error('retry-exhausted:' + last.message); err.exhausted = true; throw err; }
  try {
    if (ctx.resumeRunId) { var g = retry(function () { return server.getRun(ctx.resumeRunId); }); if (!g.ok) { rep.status = 'blocked'; rep.blockers = ['NO-SUCH-RUN']; return rep; } run = g.run; g.committed.forEach(function (c) { committedMap[c.batchId] = c.result; }); rep.runId = run.runId; }
    else { var s = retry(function () { return server.startRun({ actor: ctx.actor, deviceId: ctx.deviceId, classIds: ready, planFingerprint: plan.sourceFingerprint }); }); if (!s.ok) { rep.status = 'blocked'; rep.blockers = [s.status === 'busy' ? 'RUN-BUSY' : 'DENIED']; return rep; } rep.runId = s.runId; }
  } catch (e) { rep.status = e.exhausted ? 'paused' : 'blocked'; rep.blockers = ['OFFLINE']; return rep; }

  ready.forEach(function (c) { rep.tally[c] = {}; KINDS.concat(['classes']).forEach(function (k) { rep.tally[c][k] = { inserted: 0, revived: 0, already: 0, equivalent: 0, conflicts: 0, takenLocal: 0, serverQuarantined: 0 }; }); });
  function record(b, res, rows, off) {
    res.outcomes.forEach(function (o) {
      var row = rows[o.i], kk = b.kind === 'content' ? row.type : b.kind, t = rep.tally[b.classId][kk], key = kk + '|' + rowKey(b.kind, row);
      var m = { inserted: 'inserted', revived: 'revived', already: 'already', equivalent: 'equivalent', 'taken-local': 'takenLocal', 'conflict-id': 'conflicts', 'conflict-natural': 'conflicts' }[o.outcome];
      if (b.kind === 'classSettings') return;
      t[m]++; rep.rowOutcomes[key] = { outcome: o.outcome, mapTo: o.mapTo, kind: kk, classId: b.classId, row: row };
      if (m === 'conflicts') rep.conflicts.push({ kind: kk, classId: b.classId, recordId: row.record_id || row.student_id || row.class_id, type: o.outcome });
    });
  }
  function send(b, rows, bid) {
    var res;
    if (committedMap[bid]) { rep.batches.resumedSkipped++; record(b, committedMap[bid], rows); return 'ok'; }
    res = retry(function () { return server.importBatch({ runId: rep.runId, actor: ctx.actor, batchId: bid, kind: b.kind, classId: b.classId, rows: rows, hash: H(canon(rows.map(function (r) { return r.content_hash; }))), decisions: (plan.decisions || {}).conflicts }); });
    if (res.ok) { rep.batches.committed++; record(b, res, rows); doneNow++; if (crashAfter !== undefined && doneNow >= crashAfter) throw new Error('CRASH'); return 'ok'; }
    if (res.status === 'rejected') {
      rep.batches.bisected++;
      if (rows.length === 1) { var kk = b.kind === 'content' ? rows[0].type : b.kind; rep.serverQuarantine.push({ kind: kk, class_id: b.classId, record_id: rows[0].record_id || rows[0].student_id, reason: res.errors[0].code }); rep.tally[b.classId][kk].serverQuarantined++; return 'ok'; }
      var half = Math.ceil(rows.length / 2);
      send(b, rows.slice(0, half), bid + '.0'); send(b, rows.slice(half), bid + '.1'); return 'ok';
    }
    var er = new Error(res.status); er.final = res.status; throw er;
  }
  batches = makeBatches(plan, rep.runId, ctx.limits); rep.batches.total = batches.length;
  try { batches.forEach(function (b) { if (committedMap[b.batchId] || true) send(b, b.rows, b.batchId); }); }
  catch (e) {
    if (e.message === 'CRASH') throw e;
    if (e.exhausted) { rep.status = 'paused'; rep.blockers = ['RETRY-EXHAUSTED']; return rep; }
    rep.status = e.final === 'quota' ? 'paused' : 'blocked'; rep.blockers = [e.final === 'quota' ? 'QUOTA' : String(e.final || e.message).toUpperCase()]; return rep;
  }
  rep.reconcile = reconcile(plan, rep, server);
  var drift = ctx.currentStorage && buildPlan(ctx.currentStorage, { decisions: plan.decisions }).sourceFingerprint !== plan.sourceFingerprint;
  var attention = rep.conflicts.length || rep.serverQuarantine.length || rep.quarantine.length || drift;
  rep.driftAfter = !!drift;
  rep.status = !rep.reconcile.ok ? 'failed-verification' : attention ? 'verified-with-exceptions' : 'verified';
  var inserted = 0; Object.keys(rep.tally).forEach(function (c) { Object.keys(rep.tally[c]).forEach(function (k) { inserted += rep.tally[c][k].inserted + rep.tally[c][k].revived; }); });
  server.finishRun(rep.runId, inserted, rep.reconcile.ok ? 'success' : 'error');
  return rep;
}

// ===== المطابقة =====
function reconcile(plan, rep, server) {
  var out = { ok: true, rows: [], problems: [] };
  plan.classes.filter(function (c) { return c.state === 'ready'; }).forEach(function (c) {
    KINDS.concat(['classes']).forEach(function (k) {
      var e = plan.expected[c.classId][k], t = rep.tally[c.classId][k], r;
      if (!e) return;
      var serverQ = t.serverQuarantined, acc = t.inserted + t.revived + t.already + t.equivalent + t.conflicts + t.takenLocal + serverQ;
      r = { classId: c.classId, kind: k, source_total: e.source_total, quarantined_local: e.quarantined, importable: e.importable, inserted: t.inserted, revived: t.revived, already: t.already, equivalent: t.equivalent, conflicts: t.conflicts, takenLocal: t.takenLocal, serverQuarantined: serverQ, balanced: e.importable === acc && e.source_total === e.importable + e.quarantined, readback: true, sums: null };
      var srcSum = 0, srvSum = 0;
      Object.keys(rep.rowOutcomes).forEach(function (key) {
        var o = rep.rowOutcomes[key];
        if (o.kind !== k || o.classId !== c.classId) return;
        if (['inserted', 'revived', 'already', 'taken-local'].indexOf(o.outcome) >= 0) {
          var tk = CONTENT.indexOf(k) >= 0 ? 'content' : k, srv = server.t[tk].get(rowKey(tk, o.row));
          if (!srv || srv.deleted_at || srv.content_hash !== o.row.content_hash) { r.readback = false; out.problems.push({ code: 'READBACK-MISMATCH', classId: c.classId, kind: k, id: o.row.record_id || o.row.student_id }); }
          else if (k === 'payments') { srcSum += o.row.amount; srvSum += srv.amount; }
        } else if (o.outcome === 'equivalent' && !server.getRow(k, c.classId, o.mapTo)) { r.readback = false; out.problems.push({ code: 'EQUIVALENT-MISSING', classId: c.classId, kind: k }); }
      });
      if (k === 'payments') r.sums = { source: srcSum, server: srvSum, ok: srcSum === srvSum };
      if (!r.balanced) out.problems.push({ code: 'UNBALANCED', classId: c.classId, kind: k });
      if (r.sums && !r.sums.ok) out.problems.push({ code: 'SUM-MISMATCH', classId: c.classId, kind: k });
      out.rows.push(r);
    });
  });
  out.ok = out.problems.length === 0;
  return out;
}

// ===== النسخ الاحتياطي المحلي والاستعادة =====
function exportable(k) { return k.indexOf('marsa.') === 0 && k !== 'marsa.ui' && k.indexOf('marsa.migration.') !== 0; }
function makeLocalExport(st, meta) {
  var keys = [], i, m;
  for (i = 0; i < st.length; i++) if (exportable(st.key(i))) keys.push(st.key(i));
  keys.sort();
  m = { format: 'marsa-local-export', formatVersion: 1, createdAt: (meta && meta.now) || '2026-11-01T09:00:00Z', appVersion: (meta && meta.appVersion) || '4.08-final', entries: keys.map(function (k) { var raw = st.getItem(k); return { key: k, raw: raw, sha: H(raw) }; }) };
  m.manifestSha = H(canon({ format: m.format, formatVersion: m.formatVersion, createdAt: m.createdAt, appVersion: m.appVersion, entries: m.entries }));
  return m;
}
function verifyExport(x) {
  var errs = [];
  if (!x || x.format !== 'marsa-local-export' || x.formatVersion !== 1 || !Array.isArray(x.entries)) return { ok: false, errors: ['BAD-FORMAT'] };
  x.entries.forEach(function (e) { if (typeof e.raw !== 'string' || H(e.raw) !== e.sha) errs.push('ENTRY-HASH:' + e.key); if (!exportable(e.key)) errs.push('KEY-NOT-ALLOWED:' + e.key); });
  if (H(canon({ format: x.format, formatVersion: x.formatVersion, createdAt: x.createdAt, appVersion: x.appVersion, entries: x.entries })) !== x.manifestSha) errs.push('MANIFEST-HASH');
  return { ok: errs.length === 0, errors: errs };
}
function previewRestore(st, x) { return x.entries.map(function (e) { var cur = st.getItem(e.key); return { key: e.key, action: cur === null ? 'add' : cur === e.raw ? 'same' : 'conflict' }; }); }
function restoreLocal(st, x, o) {
  o = o || {};
  var v = verifyExport(x), pv, conflicts, made = [], wrote = [], ts = o.ts || 'ts', i, e;
  if (!v.ok) return { ok: false, status: 'bad-export', errors: v.errors };
  pv = previewRestore(st, x); conflicts = pv.filter(function (p) { return p.action === 'conflict'; });
  if (conflicts.length && o.mode !== 'backup-then-overwrite') return { ok: false, status: 'conflicts', conflicts: conflicts.map(function (c) { return c.key; }) };
  function undo() { wrote.slice().reverse().forEach(function (w) { try { if (w.prev === null) st.removeItem(w.key); else st.setItem(w.key, w.prev); } catch (e2) { /* أفضل جهد */ } }); made.forEach(function (k) { try { st.removeItem(k); } catch (e3) { /* */ } }); }
  try {
    for (i = 0; i < conflicts.length; i++) { var bk = conflicts[i].key + '.backup.prerestore-' + ts; st.setItem(bk, st.getItem(conflicts[i].key)); made.push(bk); if (st.getItem(bk) !== st.getItem(conflicts[i].key)) throw new Error('backup-verify'); }
    for (i = 0; i < pv.length; i++) { if (pv[i].action === 'same') continue; e = x.entries.filter(function (z) { return z.key === pv[i].key; })[0]; var prev = st.getItem(e.key); st.setItem(e.key, e.raw); wrote.push({ key: e.key, prev: prev }); if (st.getItem(e.key) !== e.raw) throw new Error('write-verify'); }
  } catch (err) { undo(); return { ok: false, status: 'failed-reverted', error: err.message }; }
  return { ok: true, status: 'restored', added: pv.filter(function (p) { return p.action === 'add'; }).length, overwritten: conflicts.length, backups: made };
}
function restoreServerExport(exp, server, actor) {
  var run = server.startRun({ actor: actor, deviceId: 'restore', classIds: Object.keys(exp.rows.classes.reduce(function (a, r) { a[r.class_id] = 1; return a; }, {})), planFingerprint: 'restore' });
  if (!run.ok) return { ok: false, status: run.status };
  var n = 0, order = ['classes', 'classSettings', 'students', 'content', 'attendance', 'grades', 'payments'], bad = 0;
  order.forEach(function (k) {
    var byClass = {}; (exp.rows[k] || []).forEach(function (r) { (byClass[r.class_id] = byClass[r.class_id] || []).push(r); });
    Object.keys(byClass).forEach(function (cid) { for (var i = 0; i < byClass[cid].length; i += LIM.batchMaxRecords) { var rows = byClass[cid].slice(i, i + LIM.batchMaxRecords), r = server.importBatch({ runId: run.runId, actor: actor, batchId: run.runId + ':' + (n++), kind: k, classId: cid, rows: rows, hash: H(canon(rows.map(function (x) { return x.content_hash; }))) }); if (!r.ok) bad++; } });
  });
  server.finishRun(run.runId, n, bad ? 'error' : 'success');
  return { ok: bad === 0, runId: run.runId };
}

module.exports = { H: H, canon: canon, readOnly: readOnly, inventory: inventory, buildPlan: buildPlan, approve: approve, FakeServer: FakeServer, makeBatches: makeBatches, runMigration: runMigration, reconcile: reconcile, makeLocalExport: makeLocalExport, verifyExport: verifyExport, previewRestore: previewRestore, restoreLocal: restoreLocal, restoreServerExport: restoreServerExport, parseRosterRef: parseRosterRef, normClassRef: normClassRef, serverFold: serverFold, serverValidate: serverValidate, MAP: MAP, DEMO_ID: DEMO_ID, KINDS: KINDS, CONTENT: CONTENT, CHILD: CHILD, rowKey: rowKey, exportable: exportable };
