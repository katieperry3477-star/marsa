/* 5.05 — بيانات صناعية فقط لاختبارات الترحيل (لا أسماء ولا مبالغ حقيقية).
 * تُكتب عبر طبقة التخزين الحقيقية MarsaAcademicStore فتكون الصيغة أصيلة. حتمية بالبذرة (seed). */
'use strict';
var Store = require('../../js/academic-store.js');

var DEMO_ID = 'cls_demo_001';
var CODE_CHARS = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';

function rng(seed) { // mulberry32
  var a = seed >>> 0;
  return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

function MemStorage(opts) { this.m = new Map(); this.sets = []; this.removes = []; this.limit = opts && opts.limit ? opts.limit : Infinity; }
Object.defineProperty(MemStorage.prototype, 'length', { get: function () { return this.m.size; } });
MemStorage.prototype.key = function (i) { var ks = Array.from(this.m.keys()); return i < ks.length ? ks[i] : null; };
MemStorage.prototype.getItem = function (k) { return this.m.has(k) ? this.m.get(k) : null; };
MemStorage.prototype.size = function () { var n = 0; this.m.forEach(function (v, k) { n += k.length + v.length; }); return n; };
MemStorage.prototype.setItem = function (k, v) {
  v = String(v);
  var old = this.m.has(k) ? this.m.get(k) : null, delta = k.length + v.length - (old === null ? 0 : k.length + old.length);
  if (this.size() + delta > this.limit) { var e = new Error('QuotaExceededError'); e.name = 'QuotaExceededError'; throw e; }
  this.sets.push(k); this.m.set(k, v);
};
MemStorage.prototype.removeItem = function (k) { this.removes.push(k); this.m.delete(k); };
MemStorage.prototype.clone = function () { var c = new MemStorage({ limit: this.limit }); this.m.forEach(function (v, k) { c.m.set(k, v); }); return c; };
MemStorage.prototype.dump = function () { var o = {}; Array.from(this.m.keys()).sort().forEach(function (k) { o[k] = this.m.get(k); }, this); return o; };
MemStorage.prototype.resetLog = function () { this.sets = []; this.removes = []; };

function demoClassEntry() { return { classId: DEMO_ID, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null }; }

/* يبني مجموعة بيانات كاملة. truth = الحقيقة المرجعية المحسوبة أثناء التوليد (لا من الكود المُختبَر). */
function makeDataset(o) {
  o = o || {};
  var seed = o.seed || 1, nClasses = o.classes || 2, nStu = o.students || 8, nDays = o.days || 5;
  var rnd = rng(seed), st = o.storage || new MemStorage(), tick = Date.parse('2026-09-01T08:00:00.000Z') + seed * 1000;
  var store = Store.create({ storage: st, now: function () { return (tick += 7); } });
  var truth = { classes: {}, order: [] }, registry = { schemaVersion: 1, activeClassId: DEMO_ID, classes: [] };
  var codes = {}, c, i, d, s;
  function code() { var x, k; do { x = 'MR-'; for (k = 0; k < 6; k++) x += CODE_CHARS.charAt(Math.floor(rnd() * 31)); } while (codes[x]); codes[x] = 1; return x; }
  function pick(a) { return a[Math.floor(rnd() * a.length)]; }
  function iso(n) { return new Date(Date.parse('2026-09-01T08:00:00.000Z') + n * 60000).toISOString(); }
  var STATUS = ['present', 'present', 'present', 'absent', 'late', 'excused'];

  for (c = 0; c < nClasses; c++) {
    var cid = c === 0 ? DEMO_ID : 'cls_synth' + seed + '_' + c, T = { students: 0, archived: 0, attendance: 0, grades: 0, payments: 0, paymentSum: 0, scoreX100: 0, maxX100: 0, content: {}, ids: [], studentIds: [], byStatus: {} };
    truth.classes[cid] = T; truth.order.push(cid);
    registry.classes.push(c === 0 ? demoClassEntry() : { classId: cid, schoolName: 'مدرسة اختبارية', stage: 'صف اختباري ' + c, branch: 'فرع ' + c, section: 'أ', year: '2026', status: 'active', createdAt: iso(c), archivedAt: null });
    var students = [];
    for (i = 0; i < nStu; i++) {
      s = { studentId: 'stu-' + seed + '-' + c + '-' + i, name: 'طالب اختباري ' + c + '-' + (i + 1), status: i === nStu - 1 ? 'archived' : 'active', createdAt: iso(10 + i), archivedAt: i === nStu - 1 ? iso(900) : null, studentCode: code() };
      students.push(s); T.students++; if (s.status === 'archived') T.archived++; T.studentIds.push(s.studentId);
    }
    st.setItem(c === 0 ? 'marsa.roster' : 'marsa.roster.' + cid, JSON.stringify({ schemaVersion: 2, classId: cid, students: students }));
    var active = students.filter(function (x) { return x.status === 'active'; });
    var recs = [];
    for (d = 0; d < nDays; d++) active.forEach(function (stu) { if (rnd() < 0.85) { var stt = pick(STATUS); recs.push({ studentId: stu.studentId, date: '2026-09-' + (d + 1 < 10 ? '0' : '') + (d + 1), status: stt, note: rnd() < 0.1 ? 'ملاحظة اختبارية' : '' }); T.byStatus[stt] = (T.byStatus[stt] || 0) + 1; } });
    if (recs.length) { var r1 = store.upsertMany('attendance', cid, recs); if (!r1.ok) throw new Error('seed attendance ' + r1.status); T.attendance = recs.length; }
    var grs = [];
    active.forEach(function (stu, k) { if (k % 2 === 0) ['رياضيات', 'حاسوب'].forEach(function (sub) { var mx = pick([10, 20, 100]), sc = Math.round(rnd() * mx * 4) / 4; grs.push({ studentId: stu.studentId, subject: sub, title: 'اختبار قصير', date: '2026-09-10', score: sc, maxScore: mx, note: '' }); T.scoreX100 += Math.round(sc * 100); T.maxX100 += Math.round(mx * 100); }); });
    if (grs.length) { var r2 = store.upsertMany('grades', cid, grs); if (!r2.ok) throw new Error('seed grades ' + r2.status); T.grades = grs.length; }
    active.forEach(function (stu, k) {
      var n = 1 + (k % 3), j, amt, pr;
      for (j = 0; j < n; j++) { amt = 1000 * (1 + ((k + j) % 5)); pr = store.upsertRecord('payments', cid, { studentId: stu.studentId, amount: amt, purpose: 'مبلغ اختباري', date: '2026-09-0' + (1 + j), receiptNo: j === 0 ? 'R-' + c + '-' + k : '', note: '' }); if (!pr.ok) throw new Error('seed pay ' + pr.status); T.payments++; T.paymentSum += amt; }
    });
    if (c === 0 && active.length) { // دفعتان متطابقتان تماماً بمعرّفين مختلفين (مشروعتان) — اختبار حاسم
      for (i = 0; i < 2; i++) { var q = store.upsertRecord('payments', cid, { studentId: active[0].studentId, amount: 5000, purpose: 'دفعة متطابقة', date: '2026-09-20', receiptNo: '', note: '' }); if (!q.ok) throw new Error('seed twin ' + q.status); T.payments++; T.paymentSum += 5000; }
      T.twinStudent = active[0].studentId;
    }
    var lessons = store.upsertRecord('dailyLessons', cid, { subject: 'حاسوب', title: 'درس اختباري', date: '2026-09-02', summary: 'ملخص', pages: '1-2' });
    var preps = store.upsertRecord('preparations', cid, { subject: 'حاسوب', title: 'تحضير اختباري', date: '2026-09-03', content: 'محتوى' });
    var sch = store.upsertRecord('schedule', cid, { day: 'sun', subject: 'حاسوب', period: 1, startTime: '08:00', endTime: '08:45' });
    var exm = store.upsertRecord('exams', cid, { subject: 'حاسوب', title: 'امتحان اختباري', examDate: '2026-10-01', status: 'scheduled', futureField: 'يُحفظ كما هو' });
    [['dailyLessons', lessons], ['preparations', preps], ['schedule', sch], ['exams', exm]].forEach(function (p) { if (!p[1].ok) throw new Error('seed ' + p[0] + ' ' + p[1].status); T.content[p[0]] = 1; });
    st.setItem('marsa.scheduleDays.' + cid, JSON.stringify({ schemaVersion: 1, classId: cid, days: ['sun', 'mon', 'tue', 'wed'] }));
  }
  st.setItem('marsa.classes', JSON.stringify(registry));
  st.setItem('marsa.ui', JSON.stringify({ mode: 'student', view: 'home' }));
  st.resetLog();
  return { storage: st, truth: truth, store: store, registry: registry };
}

module.exports = { MemStorage: MemStorage, makeDataset: makeDataset, rng: rng, DEMO_ID: DEMO_ID, demoClassEntry: demoClassEntry };
