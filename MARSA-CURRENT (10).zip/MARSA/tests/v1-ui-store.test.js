// تشغيل: node tests/v1-ui-store.test.js  (لا يحتاج مكتبات)
// تخزين واجهة 01.03: المظهر وعلم «تمّ الترحيب» داخل marsa.v1.ui، والبيانات التجريبية بمفتاح مستقل لا يمسّ mine/saved ولا مفاتيح التطبيق القديم.
var assert = require('assert');
var St = require('../js/v1-store.js'), D = require('../js/v1-demo.js');
var n = 0, f = 0;
function T(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '::', e && e.message); } }
function fake(init) {
  var m = {}, k, o = { writes: 0, failSet: null, lie: null, throwGet: false };
  for (k in (init || {})) m[k] = init[k];
  o.m = m;
  o.getItem = function (key) { if (o.throwGet) throw new Error('get blocked'); return Object.prototype.hasOwnProperty.call(m, key) ? m[key] : null; };
  o.setItem = function (key, v) {
    if (o.failSet && o.failSet(key)) { var e = new Error('QuotaExceededError'); e.name = 'QuotaExceededError'; throw e; }
    o.writes++; m[key] = o.lie && o.lie(key) ? 'تالف-' + String(v) : String(v);
  };
  o.removeItem = function (key) { delete m[key]; };
  return o;
}
function once(key) { var done = false; return function (k) { if (k === key && !done) { done = true; return true; } return false; }; } // يكذب مرة واحدة فقط: كتابة الاسترجاع بعد الفشل تنجح
function store(storage) { return St.create({ storage: storage, now: function () { return 1780000000000; } }); }
var TODAY = '2026-11-03';
var LEGACY = { 'marsa.academic.preparations.cls_demo': '{"schemaVersion":1,"records":[{"recordId":"x1"}]}', 'marsa.students': '[{"name":"طالب تجريبي"}]', 'marsa.ui.v1': '{"a":1}', 'other.app.key': 'قيمة 😀' };
var MINE = '{"schemaVersion":1,"records":[{"id":"mine00001","subject":"أ","title":"ب","date":"2026-11-03","content":"ج","createdAt":"2026-11-03T05:00:00.000Z","updatedAt":"2026-11-03T05:00:00.000Z"}]}';
var SAVED = '{"schemaVersion":1,"records":[{"id":"sav000001","subject":"ك","title":"ل","date":"2026-11-03","content":"م","homework":"و","sourceUpdatedAt":5,"addedAt":"2026-11-03T05:00:00.000Z","createdAt":"2026-11-03T05:00:00.000Z","updatedAt":"2026-11-03T05:00:00.000Z"}]}';
function seeded() { var i = {}, k; for (k in LEGACY) i[k] = LEGACY[k]; i['marsa.v1.mine'] = MINE; i['marsa.v1.saved'] = SAVED; i['marsa.v1.draft'] = '{"schemaVersion":1,"values":{}}'; return i; }

T('الافتراضي: مظهر تلقائي ولم يُرحَّب بعد', function () { assert.deepStrictEqual(store(fake()).loadPrefs(), { theme: 'auto', welcomed: false }); });
T('savePrefs يحفظ المظهر والترحيب معاً أو منفصلين ويبقيان بعد إعادة الفتح', function () {
  var st = fake(), a = store(st);
  assert.strictEqual(a.savePrefs({ theme: 'dark' }), true); assert.deepStrictEqual(store(st).loadPrefs(), { theme: 'dark', welcomed: false });
  assert.strictEqual(a.savePrefs({ welcomed: true }), true); assert.deepStrictEqual(store(st).loadPrefs(), { theme: 'dark', welcomed: true });
  assert.strictEqual(a.savePrefs({ theme: 'light', welcomed: true }), true); assert.deepStrictEqual(store(st).loadPrefs(), { theme: 'light', welcomed: true });
});
T('قيمة مظهر غير معروفة تُطبَّع إلى تلقائي، وعلم الترحيب لا يصير صحيحاً إلا بـtrue صريحة', function () {
  var st = fake(), a = store(st);
  a.savePrefs({ theme: 'sepia' }); assert.strictEqual(store(st).loadPrefs().theme, 'auto');
  a.savePrefs({ welcomed: 'yes' }); assert.strictEqual(store(st).loadPrefs().welcomed, false);
  st.m['marsa.v1.ui'] = JSON.stringify({ schemaVersion: 1, mode: 'rep', appUrl: '', theme: 'neon', welcomed: 1 }); assert.deepStrictEqual(store(st).loadPrefs(), { theme: 'auto', welcomed: false });
});
T('حفظ التفضيلات لا يمسّ الدور ولا رابط التطبيق، وحفظ الدور لا يمسّ المظهر ولا الترحيب', function () {
  var st = fake(), a = store(st);
  a.saveUi({ mode: 'rep', appUrl: 'https://example.com/marsa/' }); a.savePrefs({ theme: 'dark', welcomed: true });
  assert.deepStrictEqual(a.loadUi(), { mode: 'rep', appUrl: 'https://example.com/marsa/' });
  a.saveUi({ mode: 'student', appUrl: 'https://example.com/marsa/' });
  assert.deepStrictEqual(a.loadPrefs(), { theme: 'dark', welcomed: true }); assert.strictEqual(a.loadUi().mode, 'student');
  assert.deepStrictEqual(Object.keys(JSON.parse(st.m['marsa.v1.ui'])).sort(), ['appUrl', 'mode', 'schemaVersion', 'theme', 'welcomed']);
});
T('فشل الكتابة (امتلاء المساحة): savePrefs ترجع false والقيمة السابقة سليمة', function () {
  var st = fake(), a = store(st), before;
  a.savePrefs({ theme: 'dark', welcomed: true }); before = st.m['marsa.v1.ui'];
  st.failSet = function (k) { return k === 'marsa.v1.ui'; };
  assert.strictEqual(a.savePrefs({ theme: 'light' }), false); assert.strictEqual(st.m['marsa.v1.ui'], before); assert.deepStrictEqual(a.loadPrefs(), { theme: 'dark', welcomed: true });
});
T('تخزين يكذب (القراءة بعد الكتابة لا تطابق): savePrefs ترجع false وتعيد القيمة السابقة', function () {
  var st = fake(), a = store(st), before;
  a.savePrefs({ theme: 'dark' }); before = st.m['marsa.v1.ui'];
  st.lie = once('marsa.v1.ui');
  assert.strictEqual(a.savePrefs({ theme: 'light' }), false); assert.strictEqual(st.m['marsa.v1.ui'], before);
});
T('تفضيلات تالفة (JSON غير صالح أو ليس كائناً): افتراضات بلا انهيار ورسالة عربية، ثم يصلحها أول حفظ', function () {
  ['{ملعوب', '[1,2]', '"نص"', '5'].forEach(function (bad) {
    var st = fake({ 'marsa.v1.ui': bad }), a = store(st), msgs = a.takeNotices().join('|');
    assert.deepStrictEqual(a.loadUi(), { mode: 'student', appUrl: '' }); assert.deepStrictEqual(a.loadPrefs(), { theme: 'auto', welcomed: false });
    assert.ok(/تالفة/.test(msgs) && /[\u0600-\u06FF]/.test(msgs), 'لا رسالة عربية لـ ' + bad);
    assert.strictEqual(a.savePrefs({ theme: 'dark' }), true); assert.deepStrictEqual(store(fake(st.m)).loadPrefs(), { theme: 'dark', welcomed: false });
  });
  assert.strictEqual(store(fake({ 'marsa.v1.ui': '{"schemaVersion":1,"mode":"rep","appUrl":""}' })).takeNotices().join('').indexOf('تالفة'), -1);
});
T('تخزين غير متاح كلياً: لا انهيار، savePrefs وsaveDemo تفشلان بنص عربي، وloadDemo آمنة', function () {
  var a = store(null), r;
  assert.strictEqual(a.persistent, false); assert.deepStrictEqual(a.loadPrefs(), { theme: 'auto', welcomed: false });
  assert.ok(a.takeNotices().join('').length > 0);
  assert.deepStrictEqual(a.loadDemo(), { data: null });
  r = a.saveDemo(D.build(TODAY)); assert.ok(r.ok, 'وضع الذاكرة يقبل داخل الجلسة'); assert.ok(a.loadDemo().data);
  var st = fake(), b = store(st); st.throwGet = true;
  assert.strictEqual(b.savePrefs({ theme: 'dark' }), false);
  r = b.loadDemo(); assert.strictEqual(r.data, null); assert.ok(/[\u0600-\u06FF]/.test(r.error));
  r = b.saveDemo(D.build(TODAY)); assert.strictEqual(r.ok, false); assert.ok(/[\u0600-\u06FF]/.test(r.error));
  r = b.clearDemo(); assert.strictEqual(r.ok, false); assert.ok(/[\u0600-\u06FF]/.test(r.error));
});
T('البيانات التجريبية: حفظ وقراءة وحذف يعمل، والقراءة تعيد نسخة صالحة', function () {
  var st = fake(), a = store(st), d = D.build(TODAY), r = a.saveDemo(d);
  assert.deepStrictEqual(r, { ok: true }); assert.deepStrictEqual(store(st).loadDemo(), { data: d });
  assert.deepStrictEqual(a.clearDemo(), { ok: true }); assert.deepStrictEqual(a.loadDemo(), { data: null }); assert.strictEqual(st.m['marsa.v1.demo'], undefined);
  assert.deepStrictEqual(a.clearDemo(), { ok: true });
});
T('عزل البيانات التجريبية: التحميل والحذف لا يغيّران أي مفتاح آخر بايتاً ببايت (mine وsaved وdraft وui والقديمة)', function () {
  var st = fake(seeded()), a = store(st), before = JSON.stringify(st.m), keysBefore = Object.keys(st.m).sort(), mid;
  a.savePrefs({ theme: 'dark', welcomed: true }); before = JSON.stringify(st.m); keysBefore = Object.keys(st.m).sort();
  assert.ok(a.saveDemo(D.build(TODAY)).ok); mid = JSON.parse(JSON.stringify(st.m));
  Object.keys(mid).forEach(function (k) { if (k !== 'marsa.v1.demo') assert.strictEqual(mid[k], JSON.parse(before)[k], 'تغيّر ' + k); });
  assert.deepStrictEqual(Object.keys(mid).sort(), keysBefore.concat(['marsa.v1.demo']).sort());
  assert.ok(a.clearDemo().ok); assert.strictEqual(JSON.stringify(st.m), before, 'بعد الحذف يجب أن يعود التخزين كما كان بالضبط');
  assert.strictEqual(st.m['marsa.v1.mine'], MINE); assert.strictEqual(st.m['marsa.v1.saved'], SAVED); Object.keys(LEGACY).forEach(function (k) { assert.strictEqual(st.m[k], LEGACY[k], k); });
});
T('قراءة البيانات التجريبية لا تكتب شيئاً (لا نسخ احتياطية ولا مفاتيح)', function () {
  var st = fake(seeded()), a = store(st), w = st.writes, snap = JSON.stringify(st.m);
  a.saveDemo(D.build(TODAY)); w = st.writes; snap = JSON.stringify(st.m);
  a.loadDemo(); a.loadDemo(); assert.strictEqual(st.writes, w); assert.strictEqual(JSON.stringify(st.m), snap);
});
T('بيانات تجريبية تالفة أو بإصدار غير مدعوم: لا انهيار، corrupt مع رسالة عربية، والحذف يزيلها دون المساس بغيرها', function () {
  var bads = ['{ملعوب', '[]', '{"schemaVersion":9,"synthetic":true}', JSON.stringify(Object.assign({}, D.build(TODAY), { synthetic: false })), JSON.stringify(Object.assign({}, D.build(TODAY), { exams: 'x' }))];
  bads.forEach(function (bad) {
    var init = seeded(); init['marsa.v1.demo'] = bad;
    var st = fake(init), a = store(st), r = a.loadDemo();
    assert.strictEqual(r.data, null); assert.strictEqual(r.corrupt, true); assert.ok(/[\u0600-\u06FF]/.test(r.error) && /تالفة/.test(r.error));
    assert.strictEqual(a.clearDemo().ok, true); assert.strictEqual(st.m['marsa.v1.demo'], undefined);
    assert.strictEqual(st.m['marsa.v1.mine'], MINE); assert.strictEqual(st.m['marsa.v1.saved'], SAVED);
    assert.deepStrictEqual(a.loadDemo(), { data: null });
  });
});
T('فشل حفظ البيانات التجريبية يبقي السابق كما هو وبرسالة عربية ولا يمسّ غيره', function () {
  var st = fake(seeded()), a = store(st), first = D.build(TODAY), r, snapBefore;
  assert.ok(a.saveDemo(first).ok); snapBefore = JSON.stringify(st.m);
  st.failSet = function (k) { return k === 'marsa.v1.demo'; };
  r = a.saveDemo(D.build('2026-11-10')); assert.strictEqual(r.ok, false); assert.ok(/[\u0600-\u06FF]/.test(r.error));
  assert.strictEqual(JSON.stringify(st.m), snapBefore); assert.deepStrictEqual(a.loadDemo().data, first);
  st.failSet = null; st.lie = once('marsa.v1.demo');
  r = a.saveDemo(D.build('2026-11-10')); assert.strictEqual(r.ok, false); assert.strictEqual(JSON.stringify(st.m), snapBefore);
});
T('فشل الحذف (التخزين يتجاهله) يُكتشف ويُبلَّغ عنه', function () {
  var st = fake(seeded()), a = store(st), r;
  a.saveDemo(D.build(TODAY)); st.removeItem = function () { /* يتجاهل */ };
  r = a.clearDemo(); assert.strictEqual(r.ok, false); assert.ok(/[\u0600-\u06FF]/.test(r.error)); assert.ok(a.loadDemo().data);
});
T('حفظ بيانات غير صالحة يُرفض دون أي كتابة', function () {
  var st = fake(), a = store(st), w = st.writes;
  [null, {}, { schemaVersion: 1 }, Object.assign({}, D.build(TODAY), { synthetic: false })].forEach(function (b) { var r = a.saveDemo(b); assert.strictEqual(r.ok, false); assert.ok(/[\u0600-\u06FF]/.test(r.error)); });
  assert.strictEqual(st.writes, w); assert.strictEqual(st.m['marsa.v1.demo'], undefined);
});
T('كل المفاتيح المكتوبة تحت marsa.v1.* (ui وdemo فقط في هذا المسار)', function () {
  var st = fake(), a = store(st);
  a.savePrefs({ theme: 'dark', welcomed: true }); a.saveUi({ mode: 'rep', appUrl: '' }); a.saveDemo(D.build(TODAY)); a.clearDemo(); a.saveDemo(D.build(TODAY));
  Object.keys(st.m).forEach(function (k) { assert.ok(/^marsa\.v1\.(ui|demo)$/.test(k), k); });
});
console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
