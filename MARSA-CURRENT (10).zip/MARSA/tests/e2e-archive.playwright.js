// اختبار واجهة المرحلة 03.9 (الأرشيف الدراسي المشتق مع البحث والفلاتر) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-archive.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة بساعة مزيّفة (الخميس 2026-10-22 09:00 بغداد). لقطات الشاشة تُحفظ في SHOTS_DIR إن عُرّف.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var SHOTS = process.env.SHOTS_DIR || '';
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z'; // 09:00 بغداد
var DEMO = 'cls_demo_001', TWOID = 'cls_two';
var K = { lesson: 'marsa.academic.dailyLessons.', prep: 'marsa.academic.preparations.', exam: 'marsa.academic.exams.' };
function classesJson(active) {
  return JSON.stringify({ schemaVersion: 1, activeClassId: active, classes: [
    { classId: DEMO, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null },
    { classId: TWOID, schoolName: '', stage: 'الثالث المتوسط', branch: '', section: 'ب', year: '', status: 'active', createdAt: null, archivedAt: null }] });
}
async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: opts.tz || 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(opts.clock || NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  if ((await page.$('.seg button[data-m="rep"]:not([hidden])')) === null) {
    await page.click('.nav button:has-text("الإعدادات")');
    await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
    await page.click('button:has-text("تفعيل")');
  }
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function nav(page, label) { await page.click('.nav button:has-text("' + label + '")'); await page.waitForSelector('#page-title'); }
async function seed(page, type, classId, records) { await page.evaluate(function (a) { localStorage.setItem(a.key, JSON.stringify({ schemaVersion: 1, classId: a.classId, records: a.records })); }, { key: K[type] + classId, classId: classId, records: records }); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function allStorage(page) { return page.evaluate(function () { var o = {}; for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('marsa.ui') !== 0) o[k] = localStorage.getItem(k); } return JSON.stringify(o); }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function pageText(page) { return page.textContent('#v-page'); }
async function cards(page) { return page.$$eval('#v-page .ak-card', function (l) { return l.map(function (x) { return x.getAttribute('data-kind') + ':' + x.getAttribute('data-record-id'); }); }); }
async function J(page) { return JSON.stringify(await cards(page)); }
async function resLine(page) { return page.textContent('.ak-res'); }
async function openPanel(page) { if (await page.$eval('#akf-panel', function (p) { return p.hidden; })) await page.click('.akf-toggle'); }
async function shot(page, name) { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); }
function rec(id, o, cls) { return Object.assign({ recordId: id, classId: cls || DEMO, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
function L(id, date, subject, title, extra, cls) { return rec(id, Object.assign({ subject: subject, title: title, date: date }, extra), cls); }
function P(id, date, subject, title, extra, cls) { return rec(id, Object.assign({ subject: subject, title: title, date: date, content: 'محتوى ' + title }, extra), cls); }
function X(id, date, status, subject, title, extra, cls) { return rec(id, Object.assign({ subject: subject, title: title, examDate: date, status: status }, extra), cls); }
// اليوم 2026-10-22. بيانات مخزَّنة بترتيب مخلوط عمداً.
async function seedMixed(page) {
  await seed(page, 'lesson', DEMO, [L('L3', '2026-09-01', 'العلوم', 'الذرة', { summary: 'ملخص الذرة', pages: 'ص 9', homework: 'واجب الذرة' }), L('L_fut', '2026-10-30', 'التاريخ', 'درس بتاريخ مستقبلي'), L('L1', '2026-10-21', 'الرياضيات', 'المعادلات'), L('L2', '2026-10-22', 'العربي', 'الإملاء')]);
  await seed(page, 'prep', DEMO, [P('P_old', '2026-08-15', 'الحاسوب', 'تحضير الشبكات'), P('P_tom', '2026-10-23', 'الفيزياء', 'تحضير باجر'), P('P_past', '2026-10-20', 'الرياضيات', 'تحضير الجبر', { pages: 'ص 3', homework: 'حل 5 مسائل' }), P('P_today', '2026-10-22', 'العربي', 'تحضير اليوم')]);
  await seed(page, 'exam', DEMO, [X('X_next', '2026-10-25', 'scheduled', 'الكيمياء', 'امتحان قادم'), X('X_cp', '2026-09-01', 'cancelled', 'الجغرافيا', 'امتحان ملغى سابق'), X('X_held', '2026-10-05', 'held', 'العلوم', 'شهري أول', { topics: 'الفصل 1\nالفصل 2', notes: 'تعليمات' }), X('X_cc', '2026-10-28', 'cancelled', 'الإنجليزي', 'ملغى مستقبلي'), X('X_over', '2026-10-10', 'scheduled', 'الحاسوب', 'امتحان فات موعده')]);
}
var EXPECT_ALL = '["lesson:L_fut","lesson:L2","lesson:L1","prep:P_past","exam:X_over","exam:X_held","lesson:L3","exam:X_cp","prep:P_old"]';

(async function main() {
  var browser = await pw.chromium.launch(), c, page, t, before, i;

  // ===== 1) لا سجلات أصلية: فراغ يشرح البدء، بلا بيانات وهمية ولا عناصر تصفية، بلا كتابة =====
  c = await open(browser, { label: 'empty' }); page = c.page;
  await nav(page, 'الأرشيف');
  t = await pageText(page);
  check('Title is «الأرشيف الدراسي» and read-only note present', /الأرشيف الدراسي/.test(await page.textContent('#page-title')) && /عرض للقراءة فقط/.test(t));
  check('No source records: explains how to start; not an error; no fake cards', /لا توجد سجلات دراسية لهذا الصف بعد/.test(t) && /ممثل الصف/.test(t) && (await page.$('.st-err')) === null && (await cards(page)).length === 0);
  check('No source records: no filter area, no clear-filters button (nothing to filter)', await page.evaluate(function () { var c = document.querySelector('.akf'); return !c || c.hidden || c.offsetParent === null; }) && (await page.$$eval('.akf-clear', function (l) { return l.every(function (b) { return b.offsetParent === null; }); })));
  check('No placeholders «يُفعّل في مرحلة لاحقة»; nothing written to storage', !/يُفعّل في مرحلة لاحقة|هذا القسم جاهز للربط/.test(t) && !Object.keys(JSON.parse(await allStorage(page))).some(function (k) { return k.indexOf('marsa.academic.') === 0; }));
  check('Empty 390px: no horizontal scroll', !(await overflow(page)));
  await c.ctx.close();

  // ===== 2) سجلات موجودة لكن كلها قادمة: «لا توجد سجلات سابقة» ≠ «لا سجلات أصلية» =====
  c = await open(browser, { label: 'upcoming-only' }); page = c.page;
  await seed(page, 'prep', DEMO, [P('p1', '2026-10-23', 'م', 'قادم')]); await seed(page, 'exam', DEMO, [X('x1', '2026-10-30', 'scheduled', 'م', 'قادم')]);
  await nav(page, 'الأرشيف'); t = await pageText(page);
  check('Only upcoming source records: «لا توجد سجلات سابقة بعد» (distinct from no records at all) and no clear-filters button', /لا توجد سجلات سابقة بعد/.test(t) && !/لا توجد سجلات دراسية لهذا الصف بعد/.test(t) && (await cards(page)).length === 0);
  await c.ctx.close();

  // ===== 3) القواعد والترتيب والتكرار والمصدر =====
  c = await open(browser, { label: 'mixed' }); page = c.page;
  await seedMixed(page);
  before = await allStorage(page);
  await nav(page, 'الأرشيف');
  check('Rules + order: newest first across kinds; undated rules; upcoming/today preps and upcoming/future-cancelled exams excluded', (await J(page)) === EXPECT_ALL, await J(page));
  check('No duplicates: one card per (kind, recordId)', (function (a) { return a.length === 9 && a.length === new Set(a).size; })(await cards(page)));
  check('Count line shows 9 archive records', /عدد سجلات الأرشيف: 9/.test(await pageText(page)));
  var kinds = await page.$$eval('#v-page .ak-card', function (l) { return l.map(function (x) { return x.getAttribute('data-kind') + '=' + x.querySelector('.ak-kind').textContent; }); });
  check('Each card is clearly typed: درس مشروح / تحضير / امتحان', kinds.every(function (k) { return { lesson: 'درس مشروح', prep: 'تحضير', exam: 'امتحان' }[k.split('=')[0]] === k.split('=')[1]; }) && kinds.length === 9, kinds.join(','));
  var tags = await page.$$eval('#v-page .ak-card', function (l) { var o = {}; l.forEach(function (li) { o[li.getAttribute('data-record-id')] = Array.prototype.map.call(li.querySelectorAll('.lc-meta .tag'), function (x) { return x.textContent; }).join('|'); }); return o; });
  check('Exam status shown: held «أُجري», cancelled «أُلغي», overdue scheduled stays «مجدول» with «مضى موعده»', /أُجري/.test(tags.X_held) && /أُلغي/.test(tags.X_cp) && /مجدول/.test(tags.X_over) && /مضى موعده/.test(tags.X_over) && !/مضى موعده/.test(tags.X_held), JSON.stringify(tags));
  check('Lesson tags: today lesson «اليوم», future-dated lesson flagged «تاريخه بعد اليوم» but not hidden', /اليوم/.test(tags.L2) && /تاريخه بعد اليوم/.test(tags.L_fut) && !/اليوم/.test(tags.L1.replace(/درس مشروح/, '')), JSON.stringify(tags));
  var txt = await page.$$eval('#v-page .ak-card', function (l) { var o = {}; l.forEach(function (li) { o[li.getAttribute('data-record-id')] = li.textContent; }); return o; });
  check('Details per kind: lesson summary/pages/homework; prep content/pages/homework; exam topics/instructions', /ملخص الذرة/.test(txt.L3) && /ص 9/.test(txt.L3) && /واجب الذرة/.test(txt.L3) && /محتوى تحضير الجبر/.test(txt.P_past) && /حل 5 مسائل/.test(txt.P_past) && /الفصل 1/.test(txt.X_held) && /تعليمات/.test(txt.X_held));
  check('Empty optional fields hidden; no null/undefined/NaN anywhere', !/الملخص|الواجب|null|undefined|NaN/.test(txt.L1) && !/\bnull\b|undefined|NaN/.test(await pageText(page)));
  check('Exam topics keep their line breaks', await page.$eval('[data-record-id="X_held"] .lc-t', function (p) { return p.textContent === 'الفصل 1\nالفصل 2' && getComputedStyle(p).whiteSpace === 'pre-wrap'; }));
  check('Browsing the archive writes nothing (storage byte-identical, no archive key created)', (await allStorage(page)) === before && !/archive/i.test(Object.keys(JSON.parse(before)).join(',')));
  check('Read-only: no forms/textarea/contenteditable/links/edit-delete buttons, no .acts', (await page.$$eval('#v-page form, #v-page textarea, #v-page [contenteditable], #v-page a[href], #v-page .acts', function (l) { return l.length; })) === 0 && !/تعديل|حذف|إضافة سجل/.test((await page.$$eval('#v-page button', function (l) { return l.map(function (b) { return b.textContent; }).join(' '); }))));
  check('Mixed 390px: no horizontal scroll', !(await overflow(page)));
  await shot(page, 'archive-all-390');

  // الظهور في المصدر الأصلي
  await toRep(page);
  await nav(page, 'ما أُخذ اليوم');
  var lessonSrc = await page.$$eval('#v-page li[data-record-id]', function (l) { return l.map(function (x) { return x.getAttribute('data-record-id'); }).sort(); });
  await nav(page, 'التحاضير');
  var prepSrc = await page.$$eval('#v-page li[data-record-id]', function (l) { return l.map(function (x) { return x.getAttribute('data-record-id'); }).sort(); });
  await nav(page, 'الامتحانات');
  var examSrc = await page.$$eval('#v-page li[data-record-id]', function (l) { return l.map(function (x) { return x.getAttribute('data-record-id'); }).sort(); });
  check('Every archived record still appears in its original rep screen (lessons)', ['L1', 'L2', 'L3', 'L_fut'].every(function (x) { return lessonSrc.indexOf(x) > -1; }), lessonSrc.join(','));
  check('Every archived record still appears in its original rep screen (preps, incl. past ones; upcoming ones remain there too)', ['P_old', 'P_past', 'P_today', 'P_tom'].every(function (x) { return prepSrc.indexOf(x) > -1; }), prepSrc.join(','));
  check('Every archived record still appears in its original rep screen (exams: held, cancelled, overdue and upcoming)', ['X_cc', 'X_cp', 'X_held', 'X_next', 'X_over'].every(function (x) { return examSrc.indexOf(x) > -1; }), examSrc.join(','));
  check('Opening rep screens did not change stored data', (await allStorage(page)) === before);
  await toStudent(page); await nav(page, 'الأرشيف');
  check('Back in student mode archive is unchanged', (await J(page)) === EXPECT_ALL);

  // ===== 4) البحث =====
  await page.fill('.st-search', 'الرياضيات');
  check('Search by subject (L1 + P_past)', (await J(page)) === '["lesson:L1","prep:P_past"]', await J(page));
  check('Result line shows «النتائج: 2 من 9»; search alone is not counted as a filter', /النتائج: 2 من 9/.test(await resLine(page)) && !/الفلاتر النشطة/.test(await resLine(page)) && (await page.textContent('.akf-toggle')) === 'تصفية');
  await page.fill('.st-search', 'تحضير');
  check('Search by title (P_past, P_old)', (await J(page)) === '["prep:P_past","prep:P_old"]', await J(page));
  await page.fill('.st-search', 'الذره'); // ة ↔ ه
  check('Search normalises taa marbuta/hamza (الذره finds الذرة)', (await J(page)) === '["lesson:L3"]', await J(page));
  await page.fill('.st-search', 'الفصل 2');
  check('Search does not look in exam topics (subject/title only)', (await cards(page)).length === 0);
  // لا نتائج بعد الفلترة ≠ لا سجلات أصلية
  await page.fill('.st-search', 'لا شيء مطابق');
  t = await pageText(page);
  check('Filtered-empty: «لا توجد نتائج مطابقة» + clear button; NOT the no-records message', /لا توجد نتائج مطابقة/.test(t) && !/لا توجد سجلات دراسية لهذا الصف بعد|لا توجد سجلات سابقة بعد/.test(t) && (await page.$$('.ak-none .akf-clear')).length === 1);
  check('Filtered-empty: count line still shows 9 source records', /عدد سجلات الأرشيف: 9/.test(t));
  await page.click('.ak-none .akf-clear');
  check('Clear from the no-results state restores all 9 and empties the search box', (await J(page)) === EXPECT_ALL && (await page.inputValue('.st-search')) === '');
  check('Searching never changed stored data', (await allStorage(page)) === before);

  // ===== 5) الفلاتر: نوع + فترة في منطقة واحدة =====
  check('Filter area is a single toggle button; panel is collapsed by default', (await page.getAttribute('.akf-toggle', 'aria-expanded')) === 'false' && (await page.$eval('#akf-panel', function (p) { return p.hidden; })));
  await page.click('.akf-toggle');
  check('Toggle opens the panel (aria-expanded=true) showing kind chips and period', (await page.getAttribute('.akf-toggle', 'aria-expanded')) === 'true' && (await page.$$('.akf-kind')).length === 4 && (await page.$('#akf-period')) !== null);
  var chipTxt = await page.$$eval('.akf-kind', function (l) { return l.map(function (b) { return b.textContent; }); });
  check('Kind chips show source counts: الكل (9) / الدروس (4) / التحاضير (2) / الامتحانات (3)', JSON.stringify(chipTxt) === JSON.stringify(['الكل (9)', 'الدروس (4)', 'التحاضير (2)', 'الامتحانات (3)']), JSON.stringify(chipTxt));
  await page.click('.akf-kind[data-kind="prep"]');
  check('Kind = تحضير → P_past, P_old; count «الفلاتر النشطة: 1»; toggle shows (1)', (await J(page)) === '["prep:P_past","prep:P_old"]' && /النتائج: 2 من 9 — الفلاتر النشطة: 1/.test(await resLine(page)) && (await page.textContent('.akf-toggle')) === 'تصفية (1)', await J(page) + ' / ' + await resLine(page));
  check('Active chip has aria-pressed=true; others false', (await page.$$eval('.akf-kind', function (l) { return l.map(function (b) { return b.getAttribute('aria-pressed'); }).join(','); })) === 'false,false,true,false');
  await page.click('.akf-kind[data-kind="exam"]');
  check('Kind = امتحان → the 3 archived exams (cancelled-future/upcoming remain out)', (await J(page)) === '["exam:X_over","exam:X_held","exam:X_cp"]', await J(page));
  await page.selectOption('#akf-period', '30');
  check('Kind exam + last 30 days → X_over, X_held; filters count 2', (await J(page)) === '["exam:X_over","exam:X_held"]' && /الفلاتر النشطة: 2/.test(await resLine(page)) && (await page.textContent('.akf-toggle')) === 'تصفية (2)', await J(page));
  await page.click('.akf-kind[data-kind="all"]');
  check('Last 30 days only → L2, L1, P_past, X_over, X_held (future lesson, 09-01 items excluded)', (await J(page)) === '["lesson:L2","lesson:L1","prep:P_past","exam:X_over","exam:X_held"]', await J(page));
  await page.selectOption('#akf-period', '7');
  check('Last 7 days → L2, L1, P_past', (await J(page)) === '["lesson:L2","lesson:L1","prep:P_past"]', await J(page));
  await page.selectOption('#akf-period', 'custom');
  check('Custom period reveals two date inputs (not before)', await page.$eval('.akf-dates', function (d) { return !d.hidden && d.querySelectorAll('input[type="date"]').length === 2; }));
  check('Custom with no dates = inactive filter (all 9, count 0)', (await J(page)) === EXPECT_ALL && (await page.textContent('.akf-toggle')) === 'تصفية');
  await page.fill('#akf-from', '2026-10-05'); await page.fill('#akf-to', '2026-10-10');
  check('Custom 10-05..10-10 inclusive → X_over, X_held; filter count 1', (await J(page)) === '["exam:X_over","exam:X_held"]' && (await page.textContent('.akf-toggle')) === 'تصفية (1)', await J(page));
  await page.fill('#akf-from', '2026-10-20'); await page.fill('#akf-to', '2026-10-05');
  t = await page.textContent('.akf-msg');
  check('Reversed range: explicit message, no silent swap, zero results with the filtered-empty state', /تاريخ البداية بعد تاريخ النهاية/.test(t) && (await cards(page)).length === 0 && /لا توجد نتائج مطابقة/.test(await pageText(page)), t);
  await page.fill('#akf-to', '');
  check('From only (10-20) → L_fut? no (future lesson allowed after from) → L_fut, L2, L1, P_past', (await J(page)) === '["lesson:L_fut","lesson:L2","lesson:L1","prep:P_past"]', await J(page));
  await page.fill('.st-search', 'الرياضيات'); await page.click('.akf-kind[data-kind="lesson"]');
  check('Search + kind + period combine as an intersection → L1', (await J(page)) === '["lesson:L1"]' && /الفلاتر النشطة: 2/.test(await resLine(page)), await J(page));
  check('A visible «مسح الفلاتر» button exists while filters are active', (await page.$$eval('.akf-clear', function (l) { return l.filter(function (b) { return b.offsetParent !== null; }).length; })) >= 1);
  await shot(page, 'archive-filters-390');
  await page.click('.akf-panel .akf-clear');
  check('Clear filters resets search, kind, period, dates and count; all 9 back', (await J(page)) === EXPECT_ALL && (await page.inputValue('.st-search')) === '' && (await page.inputValue('#akf-period')) === 'all' && (await page.textContent('.akf-toggle')) === 'تصفية' && (await page.$$eval('.akf-clear', function (l) { return l.every(function (b) { return b.offsetParent === null; }); })), (await J(page)) + '|' + (await page.inputValue('.st-search')) + '|' + (await page.inputValue('#akf-period')) + '|' + (await page.textContent('.akf-toggle')));
  check('Filters never changed the stored data (byte-identical after all interactions)', (await allStorage(page)) === before);
  // مسح الفلاتر مرئي خارج اللوحة أيضاً
  await page.click('.akf-toggle'); await page.fill('.st-search', 'العلوم');
  check('Outside-panel clear button shows while a search is active (panel collapsed)', await page.$eval('.ak-res + .akf-clear', function (b) { return b.offsetParent !== null; }));
  await page.click('.ak-res + .akf-clear');
  check('Outside-panel clear restores all', (await J(page)) === EXPECT_ALL);
  await c.ctx.close();

  // ===== 6) تحرير من المصدر ينعكس بلا تكرار، والحذف يزيل العنصر =====
  c = await open(browser, { label: 'edit' }); page = c.page;
  await seedMixed(page);
  await toRep(page); await nav(page, 'ما أُخذ اليوم');
  await page.click('.lcard:has-text("المعادلات") button:has-text("تعديل")');
  await page.fill('#lf-title', 'المعادلات المعدّلة'); await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lcard:has-text("المعادلات المعدّلة")');
  await toStudent(page); await nav(page, 'الأرشيف');
  check('Rep edit shows in archive with same recordId, no duplicate card', (await J(page)) === EXPECT_ALL && /المعادلات المعدّلة/.test(await page.textContent('[data-record-id="L1"]')));
  await toRep(page); await nav(page, 'ما أُخذ اليوم');
  await page.click('.lcard:has-text("المعادلات المعدّلة") button:has-text("حذف")'); await page.click('dialog[open] button:has-text("حذف")');
  await page.waitForFunction(function () { return !document.querySelector('.lcard[data-record-id="L1"]'); });
  await toStudent(page); await nav(page, 'الأرشيف');
  check('Deleting at the source removes it from the archive (derived view, no stale copy)', (await J(page)) === EXPECT_ALL.replace('"lesson:L1",', ''), await J(page));
  await c.ctx.close();

  // ===== 7) فصل الصفوف + تبديل الصف + تحديث حي =====
  c = await open(browser, { label: 'classes', init: 'try{if(!localStorage.getItem("marsa.classes"))localStorage.setItem("marsa.classes",' + JSON.stringify(classesJson(DEMO)) + ');}catch(e){}' }); page = c.page;
  await seed(page, 'lesson', DEMO, [L('a1', '2026-10-01', 'مادة الصف الأول', 'درس أ')]);
  await seed(page, 'lesson', TWOID, [L('b1', '2026-10-02', 'مادة الصف الثاني', 'درس ب', {}, TWOID)]);
  await seed(page, 'prep', TWOID, [P('b2', '2026-10-03', 'مادة الصف الثاني', 'تحضير ب', {}, TWOID)]);
  await seed(page, 'exam', TWOID, [X('b3', '2026-10-04', 'held', 'مادة الصف الثاني', 'امتحان ب', {}, TWOID)]);
  await nav(page, 'الأرشيف');
  check('Class 1 archive shows only class-1 items', (await J(page)) === '["lesson:a1"]' && !/مادة الصف الثاني/.test(await pageText(page)), await J(page));
  await page.evaluate(function (j) { localStorage.setItem('marsa.classes', j); window.dispatchEvent(new StorageEvent('storage', { key: 'marsa.classes' })); }, classesJson(TWOID));
  await page.waitForFunction(function () { return /مادة الصف الثاني/.test(document.getElementById('v-page').textContent); });
  check('Active class switch re-renders to class 2 only (3 kinds, no class-1 leakage)', (await J(page)) === '["exam:b3","prep:b2","lesson:b1"]' && !/مادة الصف الأول/.test(await pageText(page)), await J(page));
  await page.fill('.st-search', 'مادة');
  await seed(page, 'prep', TWOID, [P('b2', '2026-10-03', 'مادة الصف الثاني', 'تحضير ب', {}, TWOID), P('b4', '2026-10-12', 'مادة جديدة', 'تحضير وصل حياً', {}, TWOID)]);
  await page.evaluate(function (k) { window.dispatchEvent(new StorageEvent('storage', { key: k })); }, K.prep + TWOID);
  await page.waitForFunction(function () { return /وصل حياً/.test(document.getElementById('v-page').textContent); });
  check('Live storage event on preparations updates the open archive; the search text is kept', (await page.inputValue('.st-search')) === 'مادة' && (await cards(page)).indexOf('prep:b4') > -1, await J(page));
  await seed(page, 'exam', TWOID, [X('b3', '2026-10-04', 'held', 'مادة الصف الثاني', 'امتحان ب', {}, TWOID), X('b5', '2026-10-13', 'held', 'مادة حية', 'امتحان حي', {}, TWOID)]);
  await page.evaluate(function (k) { window.dispatchEvent(new StorageEvent('storage', { key: k })); }, K.exam + TWOID);
  await page.waitForFunction(function () { return /امتحان حي/.test(document.getElementById('v-page').textContent); });
  check('Live storage event on exams also updates the open archive', (await cards(page)).indexOf('exam:b5') > -1);
  await c.ctx.close();

  // ===== 8) منتصف الليل والصفحة مفتوحة: العنصر ينتقل بالعرض فقط، والفلاتر تبقى =====
  c = await open(browser, { label: 'midnight' }); page = c.page;
  await seed(page, 'lesson', DEMO, [L('m_l', '2026-10-01', 'م', 'درس قديم')]); await seed(page, 'prep', DEMO, [P('m_p', '2026-10-22', 'م', 'تحضير اليوم')]); await seed(page, 'exam', DEMO, [X('m_x', '2026-10-22', 'scheduled', 'م', 'امتحان اليوم')]);
  await nav(page, 'الأرشيف'); await page.fill('.st-search', 'م');
  var keysBefore = await raw(page, K.prep + DEMO) + await raw(page, K.exam + DEMO);
  check('Before midnight: today\'s prep and today\'s scheduled exam are not in the archive', (await J(page)) === '["lesson:m_l"]', await J(page));
  await page.clock.fastForward(16 * 3600 * 1000 + 60000 * 2);
  await page.waitForFunction(function () { return document.querySelectorAll('#v-page .ak-card').length === 3; }, null, { timeout: 5000 });
  check('After midnight (page left open): prep and the exam (still «مجدول», flagged «مضى موعده») appear; search kept', (await J(page)) === '["prep:m_p","exam:m_x","lesson:m_l"]' && (await page.inputValue('.st-search')) === 'م' && /مضى موعده/.test(await page.textContent('[data-record-id="m_x"]')) && /مجدول/.test(await page.textContent('[data-record-id="m_x"]')), await J(page));
  check('Passage of time never rewrote or moved a stored record', (await raw(page, K.prep + DEMO)) + (await raw(page, K.exam + DEMO)) === keysBefore && (await raw(page, 'marsa.academic.archive.' + DEMO)) === null);
  await c.ctx.close();

  // ===== 9) أخطاء القراءة: مصدر واحد تالف، وكل المصادر تالفة =====
  c = await open(browser, { label: 'corrupt-one' }); page = c.page;
  await seed(page, 'lesson', DEMO, [L('ok1', '2026-10-01', 'مادة سليمة', 'درس سليم')]);
  await page.evaluate(function (k) { localStorage.setItem(k, '{not json'); }, K.exam + DEMO);
  await nav(page, 'الأرشيف'); t = await pageText(page);
  check('One corrupt source: role=alert naming «الامتحانات», says completeness/emptiness cannot be asserted', (await page.$$eval('#v-page [role="alert"]', function (l) { return l.length; })) === 1 && /الامتحانات:/.test(t) && /لا يمكن الجزم/.test(t));
  check('One corrupt source: readable sources still shown; no empty-state', (await J(page)) === '["lesson:ok1"]' && !/لا توجد سجلات/.test(t));
  check('Corrupt raw preserved, backup saved, nothing overwritten by viewing', (await raw(page, K.exam + DEMO)) === '{not json' && (await raw(page, K.exam + DEMO + '.backup')) === '{not json');
  await c.ctx.close();
  var allBad = function () { ['dailyLessons', 'preparations', 'exams'].forEach(function (n) { localStorage.setItem('marsa.academic.' + n + '.cls_demo_001', JSON.stringify({ schemaVersion: 9, classId: 'cls_demo_001', records: [] })); }); };
  c = await open(browser, { label: 'corrupt-all' }); page = c.page;
  await page.evaluate(allBad); await nav(page, 'الأرشيف'); t = await pageText(page);
  check('All sources unreadable: alert only, never «لا توجد سجلات…», no filter area', (await page.$$eval('#v-page [role="alert"]', function (l) { return l.length; })) === 1 && !/لا توجد سجلات/.test(t) && (await cards(page)).length === 0 && /الدروس:/.test(t) && /التحاضير:/.test(t) && /الامتحانات:/.test(t));
  await shot(page, 'archive-error-390');
  check('Error view 390px: no horizontal scroll', !(await overflow(page)));
  await c.ctx.close();

  // ===== 10) تخزين غير متاح، ولا صف نشط، وXSS =====
  c = await open(browser, { label: 'nostorage', init: 'try{Object.defineProperty(window,"localStorage",{get:function(){throw new Error("blocked")}});}catch(e){}' }); page = c.page;
  await page.click('.nav button:has-text("الأرشيف")'); await page.waitForSelector('#page-title');
  check('Storage unavailable: archive renders (temporary-storage warning or empty-state), no crash', /مؤقت|لا توجد سجلات/.test(await pageText(page)));
  await c.ctx.close();
  c = await open(browser, { label: 'noclass', init: 'try{localStorage.setItem("marsa.classes",' + JSON.stringify(JSON.stringify({ schemaVersion: 1, activeClassId: null, classes: [{ classId: DEMO, schoolName: '', stage: 'س', branch: '', section: '', year: '', status: 'archived', createdAt: null, archivedAt: '2026-10-01T00:00:00.000Z' }] })) + ')}catch(e){}' }); page = c.page;
  await nav(page, 'الأرشيف'); t = await pageText(page);
  check('No active class: clear message, no cards, no filter controls', /لا يوجد صف نشط/.test(t) && (await cards(page)).length === 0 && (await page.$('.akf')) === null);
  await c.ctx.close();
  c = await open(browser, { label: 'xss' }); page = c.page;
  await seed(page, 'lesson', DEMO, [L('x1', '2026-10-01', '<img src=x onerror="window.__x=1">', '<script>window.__x=2</script>', { summary: '<b>عريض</b> [x](javascript:alert(1))' })]);
  await seed(page, 'exam', DEMO, [X('x2', '2026-10-02', 'held', '<svg onload="window.__x=3">', '<a href="javascript:window.__x=4">اضغط</a>', { topics: '<iframe src="javascript:1"></iframe>' })]);
  await nav(page, 'الأرشيف'); await page.fill('.st-search', '<img'); await page.fill('.st-search', '');
  check('Markup in subject/title/body stays text (no elements, no script run, no javascript: links)', await page.evaluate(function () { var v = document.getElementById('v-page'); return !window.__x && !v.querySelector('img,script,b,svg,iframe') && !Array.prototype.some.call(v.querySelectorAll('a'), function (a) { return /^javascript:/i.test(a.getAttribute('href') || ''); }) && /<img src=x/.test(v.textContent); }));
  await c.ctx.close();

  // ===== 11) الهاتف: عروض ضيقة + نص طويل + أهداف لمس + خطوط =====
  var long = 'ن'.repeat(300), url = 'https://example.com/' + 'a'.repeat(200), widths = [320, 360, 390, 430];
  for (i = 0; i < widths.length; i++) {
    c = await open(browser, { label: 'w' + widths[i], viewport: { width: widths[i], height: 760 } }); page = c.page;
    await seedMixed(page);
    await seed(page, 'lesson', DEMO, [L('long1', '2026-10-21', long.slice(0, 80), long.slice(0, 120), { summary: long + ' ' + url, pages: url, homework: long })]);
    await nav(page, 'الأرشيف');
    check('Width ' + widths[i] + ': long text wraps (no horizontal scroll)', !(await overflow(page)));
    await page.click('.akf-toggle'); await page.selectOption('#akf-period', 'custom'); await page.fill('#akf-from', '2026-10-01'); await page.fill('#akf-to', '2026-10-31');
    check('Width ' + widths[i] + ': open panel with custom dates (no horizontal scroll)', !(await overflow(page)));
    if (widths[i] === 390) {
      var sizes = await page.evaluate(function () {
        function box(sel) { return Array.prototype.map.call(document.querySelectorAll(sel), function (e) { var r = e.getBoundingClientRect(); return { sel: sel, w: r.width, h: r.height, fs: parseFloat(getComputedStyle(e).fontSize) }; }); }
        return [].concat(box('.akf-toggle'), box('.akf-kind'), box('#akf-period'), box('#akf-from'), box('#akf-to'), box('.st-search'), box('.akf-panel .akf-clear'));
      });
      check('Touch targets >= 44px high for toggle, chips, period, dates, search, clear', sizes.length >= 9 && sizes.every(function (s) { return s.h >= 43.5; }), JSON.stringify(sizes.filter(function (s) { return s.h < 43.5; })));
      check('Form fields use >= 16px font (no iOS zoom)', sizes.filter(function (s) { return /period|from|to|search/.test(s.sel); }).every(function (s) { return s.fs >= 16; }));
      check('Chips and fields stay inside the viewport (RTL, no clipping)', await page.evaluate(function () { return Array.prototype.every.call(document.querySelectorAll('.akf-panel *'), function (e) { var r = e.getBoundingClientRect(); return r.width === 0 || (r.left >= -0.5 && r.right <= window.innerWidth + 0.5); }); }));
      check('Page is RTL, Arabic', await page.evaluate(function () { return document.documentElement.dir === 'rtl' && document.documentElement.lang === 'ar'; }));
      await shot(page, 'archive-panel-390');
    }
    if (widths[i] === 320) await shot(page, 'archive-long-320');
    await c.ctx.close();
  }
  c = await open(browser, { label: 'dark' }); page = c.page;
  await page.emulateMedia({ colorScheme: 'dark' }); await seedMixed(page); await nav(page, 'الأرشيف'); await page.click('.akf-toggle'); await page.click('.akf-kind[data-kind="exam"]');
  check('Dark mode: panel and chips readable (chip text not same colour as its background) and no overflow', await page.evaluate(function () { function lum(c) { var m = c.match(/\d+(\.\d+)?/g).map(Number); return (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) / 255; } return Array.prototype.every.call(document.querySelectorAll('.akf-kind'), function (b) { var cs = getComputedStyle(b); return Math.abs(lum(cs.color) - lum(cs.backgroundColor.indexOf('rgba(0, 0, 0, 0)') === 0 ? getComputedStyle(document.querySelector('.akf-panel')).backgroundColor : cs.backgroundColor)) > 0.3; }); }) && !(await overflow(page)));
  await shot(page, 'archive-dark-390');
  await c.ctx.close();

  // ===== 12) المناطق الزمنية: نفس النتيجة =====
  var tzs = ['Asia/Baghdad', 'UTC', 'America/Los_Angeles', 'Pacific/Kiritimati'];
  for (i = 0; i < tzs.length; i++) {
    c = await open(browser, { label: 'tz' + i, tz: tzs[i], clock: '2026-10-22T09:00:00' }); page = c.page; // 09:00 بتوقيت كل منطقة
    await seedMixed(page); await nav(page, 'الأرشيف');
    check('Time zone ' + tzs[i] + ': identical archive', (await J(page)) === EXPECT_ALL, await J(page));
    await c.ctx.close();
  }

  await browser.close();
  var failed = results.filter(function (r) { return !r.ok; });
  check('No uncaught JS errors on any page', jsErrors.length === 0, jsErrors.join(' | '));
  console.log('\n' + results.filter(function (r) { return r.ok; }).length + ' passed, ' + (results.length - results.filter(function (r) { return r.ok; }).length) + ' failed');
  process.exit(results.some(function (r) { return !r.ok; }) ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
