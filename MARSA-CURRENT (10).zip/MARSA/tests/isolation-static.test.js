// تدقيق ثابت للمرحلة 03.11 (Node بلا متصفح): لا eval ولا innerHTML ولا بيانات/مواد مفروضة،
// وكل وصول للتخزين الأكاديمي يمرّ عبر classId. شغّله: node tests/isolation-static.test.js
var fs = require('fs'), path = require('path');
var root = path.resolve(__dirname, '..'), pass = 0, fail = 0;
function check(n, c, d) { if (c) { pass++; console.log('PASS ' + n); } else { fail++; console.log('FAIL ' + n + (d ? ' :: ' + d : '')); } }
function read(f) { return fs.readFileSync(path.join(root, f), 'utf8'); }
var jsFiles = fs.readdirSync(path.join(root, 'js')).filter(function (f) { return /\.js$/.test(f); });
var html = read('full.html');
// تُزال التعليقات لأن الشرح قد يذكر الأسماء الممنوعة
function code(src) { return src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"\\])\/\/.*$/gm, '$1'); }

jsFiles.forEach(function (f) {
  var c = code(read('js/' + f)), bad = [];
  if (/\beval\s*\(/.test(c)) bad.push('eval');
  if (/new\s+Function\s*\(/.test(c)) bad.push('new Function');
  if (/\.innerHTML\s*=|\.outerHTML\s*=|insertAdjacentHTML|document\.write\s*\(/.test(c)) bad.push('HTML sink');
  if (/\bsetTimeout\s*\(\s*['"`]|\bsetInterval\s*\(\s*['"`]/.test(c)) bad.push('string timer');
  check('js/' + f + ': لا eval ولا Function ولا innerHTML ولا مؤقت نصي', !bad.length, bad.join(','));
});
check('index.html: لا معالجات أحداث مضمّنة ولا javascript:', !/\son[a-z]+\s*=|javascript:/i.test(html));
check('index.html: لا مكتبات/سكربتات خارجية (خطوط Google CSS فقط)', !/<script[^>]+src=["']https?:/i.test(html));

// لا مواد ولا بيانات مفروضة في الكود (أسماء مواد شائعة)
var SUBJ = /رياضيات|فيزياء|كيمياء|أحياء|اللغة العربية|الإنكليزية|الانكليزية|التربية الإسلامية|حاسوب\s*\d|امتحان\s*الشهر|درجة\s*\d/;
jsFiles.forEach(function (f) { if (f === 'app.js') return; check('js/' + f + ': لا أسماء مواد مفروضة', !SUBJ.test(code(read('js/' + f)))); });
var app = code(read('js/app.js'));
check('app.js: لا أسماء مواد أو امتحانات مفروضة', !SUBJ.test(app), (SUBJ.exec(app) || [''])[0]);
check('index.html: لا نص صف تجريبي ثابت قبل التحميل', !/صيانة وتجميع الحاسوب/.test(html));

// كل وصول للتخزين الأكاديمي في app.js يستعمل cid/activeId (لا مفاتيح مبنية يدوياً)
var manual = app.match(/marsa\.academic\.[A-Za-z]+\.'?\s*\+/g) || [];
check('app.js: لا يبني مفاتيح marsa.academic يدوياً (الطبقة وحدها تبنيها)', manual.length === 0, manual.join('|'));
var calls = app.match(/store\.(readCollection|saveCollection|upsertRecord|deleteRecord|getRecord)\([^)]*\)/g) || [];
var wrong = calls.filter(function (c) { return !/,\s*(cid|id)\b/.test(c); });
check('app.js: كل استدعاء للتخزين الأكاديمي يمرّر cid', calls.length > 0 && !wrong.length, wrong.join(' | '));

// الروابط: href واحد فقط ويمرّ عبر safe-text
var hrefs = app.match(/\.href\s*=\s*[^;]+/g) || [];
check('app.js: href واحد فقط ويأتي من safe-text', hrefs.length === 1 && /sg\.href/.test(hrefs[0]), hrefs.join('|'));
console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
