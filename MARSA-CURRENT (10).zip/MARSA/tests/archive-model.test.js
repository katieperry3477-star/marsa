// تشغيل: node tests/archive-model.test.js  (لا يحتاج مكتبات)
// يختبر منطق الأرشيف المشتق (03.9): القواعد، الترتيب، البحث، الفلاتر، المناطق الزمنية، وأنه لا يكتب ولا يعدّل شيئاً.
var assert = require('assert'), cp = require('child_process'), path = require('path');
var M = require('../js/archive-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0, TODAY = '2026-10-22';
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake() { var d = {}; return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { d[k] = String(v); }, removeItem: function (k) { delete d[k]; } }; }
function R(id, o) { return Object.assign({ recordId: id, classId: 'c1', subject: 'مادة', title: id, createdAt: '2026-10-01T00:00:00.000Z' }, o); }
function keys(l) { return l.map(function (e) { return e.key; }).join('|'); }
function build(o) { return M.buildEntries(Object.assign({ classId: 'c1', today: TODAY }, o)); }

t('lessons: every lesson enters (past, today, future, undated); future is not hidden', function () {
  var e = build({ lessons: [R('a', { date: '2026-10-01' }), R('b', { date: TODAY }), R('c', { date: '2026-12-01' }), R('d', {})] });
  assert.strictEqual(e.length, 4); assert.ok(e.every(function (x) { return x.kind === 'lesson'; }));
});
t('preps: only valid date strictly before today (today/tomorrow/future/undated/invalid stay out)', function () {
  var e = build({ preps: [R('past', { date: '2026-10-21' }), R('today', { date: TODAY }), R('tom', { date: '2026-10-23' }), R('none', {}), R('bad', { date: '2026-13-40' }), R('old', { date: '2025-01-01' })] });
  assert.strictEqual(keys(e), 'prep:past|prep:old');
});
t('exams: held always; scheduled/cancelled only when date passed; upcoming and future-cancelled excluded', function () {
  var e = build({ exams: [
    R('held_past', { examDate: '2026-10-05', status: 'held' }), R('held_future', { examDate: '2026-11-05', status: 'held' }), R('held_nodate', { status: 'held' }),
    R('over', { examDate: '2026-10-10', status: 'scheduled' }), R('today', { examDate: TODAY, status: 'scheduled' }), R('next', { examDate: '2026-10-25', status: 'scheduled' }),
    R('c_past', { examDate: '2026-09-01', status: 'cancelled' }), R('c_future', { examDate: '2026-10-28', status: 'cancelled' }), R('nostatus_past', { examDate: '2026-09-02' }), R('weird_future', { examDate: '2026-11-02', status: 'zzz' })] });
  assert.strictEqual(keys(e).split('|').sort().join('|'), ['exam:held_past', 'exam:held_future', 'exam:held_nodate', 'exam:over', 'exam:c_past', 'exam:nostatus_past'].sort().join('|'));
  assert.strictEqual(e.filter(function (x) { return x.recordId === 'over'; })[0].status, 'scheduled');
});
t('derived view: entries reference the original record objects and inputs are not modified', function () {
  var l = [R('a', { date: '2026-10-01' })], p = [R('p', { date: '2026-10-01' })], ex = [R('e', { examDate: '2026-10-01', status: 'held' })], snap = JSON.stringify([l, p, ex]);
  var e = build({ lessons: l, preps: p, exams: ex });
  assert.strictEqual(e.length, 3); assert.strictEqual(e[0].record, l[0]);
  M.filterEntries(M.sortEntries(e), { q: 'a', kind: 'lesson', period: '7' }, TODAY);
  assert.strictEqual(JSON.stringify([l, p, ex]), snap);
});
t('no duplicates: same recordId in different types are distinct entries, one entry per source record', function () {
  var e = build({ lessons: [R('x', { date: '2026-10-01' })], preps: [R('x', { date: '2026-10-01' })], exams: [R('x', { examDate: '2026-10-01', status: 'held' })] });
  assert.strictEqual(keys(e), 'lesson:x|prep:x|exam:x');
  assert.strictEqual(build({ lessons: [R('x', { date: '2026-10-01' })] }).length, 1);
});
t('class isolation: records of another classId are ignored', function () {
  var e = build({ lessons: [R('mine', { date: '2026-10-01' }), R('other', { date: '2026-10-01', classId: 'c2' })] });
  assert.strictEqual(keys(e), 'lesson:mine');
});
t('bad inputs (non-arrays, null records, non-string fields) do not throw', function () {
  assert.strictEqual(build({ lessons: null, preps: 'x', exams: undefined }).length, 0);
  var e = build({ lessons: [null, 5, R('ok', { date: 7, subject: 9, title: null })] });
  assert.strictEqual(e.length, 1); assert.strictEqual(e[0].date, ''); assert.strictEqual(e[0].subject, '');
});
t('sort: newest date first across kinds; undated last; stable tie-break (createdAt desc, kind, id)', function () {
  var e = build({
    lessons: [R('l1', { date: '2026-10-10' }), R('l_nodate', {}), R('l_tie', { date: '2026-10-15', createdAt: '2026-10-02T00:00:00.000Z' })],
    preps: [R('p1', { date: '2026-10-15', createdAt: '2026-10-03T00:00:00.000Z' }), R('p_old', { date: '2026-09-30' })],
    exams: [R('e1', { examDate: '2026-10-20', status: 'held' }), R('e_tie', { examDate: '2026-10-15', status: 'held', createdAt: '2026-10-03T00:00:00.000Z' })] });
  var a = keys(M.sortEntries(e)), b = keys(M.sortEntries(e.slice().reverse()));
  assert.strictEqual(a, 'exam:e1|prep:p1|exam:e_tie|lesson:l_tie|lesson:l1|prep:p_old|lesson:l_nodate');
  assert.strictEqual(a, b); // لا يعتمد على ترتيب الإدخال
});
t('sort does not mutate its input', function () {
  var e = build({ lessons: [R('a', { date: '2026-10-01' }), R('b', { date: '2026-10-09' })] }), before = keys(e);
  M.sortEntries(e); assert.strictEqual(keys(e), before);
});
t('search: subject or title only, normalises hamza/taa marbuta/tashkeel; not content/topics', function () {
  var e = build({ lessons: [R('a', { date: '2026-10-01', subject: 'الرياضيات', title: 'المعادلات', summary: 'سر' }), R('m', { date: '2026-10-02', subject: 'اللغة العربية', title: 'إملاء' })], exams: [R('b', { examDate: '2026-10-01', status: 'held', subject: 'العلوم', title: 'شهري', topics: 'الذرة' })] });
  function q(s) { return keys(M.filterEntries(e, { q: s }, TODAY)); }
  assert.strictEqual(q('الرياضيات'), 'lesson:a'); assert.strictEqual(q('رياضيّات'), 'lesson:a'); 
  assert.strictEqual(q('معادلات'), 'lesson:a'); assert.strictEqual(q('شهري'), 'exam:b'); assert.strictEqual(q('الذرة'), ''); assert.strictEqual(q('سر'), '');
  assert.strictEqual(q('   '), 'lesson:a|lesson:m|exam:b'); assert.strictEqual(q('اللغه'), 'lesson:m'); assert.strictEqual(q('املاء'), 'lesson:m'); assert.strictEqual(q('اللُغَة'), 'lesson:m'); assert.strictEqual(q('زززز'), '');
});
t('kind filter', function () {
  var e = build({ lessons: [R('l', { date: '2026-10-01' })], preps: [R('p', { date: '2026-10-01' })], exams: [R('x', { examDate: '2026-10-01', status: 'held' })] });
  assert.strictEqual(keys(M.filterEntries(e, { kind: 'prep' }, TODAY)), 'prep:p'); assert.strictEqual(keys(M.filterEntries(e, { kind: 'exam' }, TODAY)), 'exam:x');
  assert.strictEqual(M.filterEntries(e, { kind: 'all' }, TODAY).length, 3); assert.strictEqual(M.filterEntries(e, { kind: 'bogus' }, TODAY).length, 3);
});
t('period: last 7 = today and 6 days before (inclusive); last 30 = 30 days inclusive; undated excluded; future lesson excluded', function () {
  var e = build({ lessons: [R('d0', { date: '2026-10-22' }), R('d6', { date: '2026-10-16' }), R('d7', { date: '2026-10-15' }), R('d29', { date: '2026-09-23' }), R('d30', { date: '2026-09-22' }), R('fut', { date: '2026-10-23' }), R('nod', {})] });
  assert.strictEqual(keys(M.filterEntries(e, { period: '7' }, TODAY)), 'lesson:d0|lesson:d6');
  assert.strictEqual(keys(M.filterEntries(e, { period: '30' }, TODAY)), 'lesson:d0|lesson:d6|lesson:d7|lesson:d29');
  assert.strictEqual(M.filterEntries(e, { period: 'all' }, TODAY).length, 7);
});
t('custom period: from only, to only, both inclusive, reversed range -> no results + message, empty custom = inactive', function () {
  var e = build({ lessons: [R('a', { date: '2026-10-01' }), R('b', { date: '2026-10-10' }), R('c', { date: '2026-10-20' })] });
  function k(f) { return keys(M.filterEntries(e, Object.assign({ period: 'custom' }, f), TODAY)); }
  assert.strictEqual(k({ from: '2026-10-10' }), 'lesson:b|lesson:c');
  assert.strictEqual(k({ to: '2026-10-10' }), 'lesson:a|lesson:b'); assert.strictEqual(k({ from: '2026-10-10', to: '2026-10-10' }), 'lesson:b');
  assert.strictEqual(k({ from: '2026-10-20', to: '2026-10-01' }), ''); assert.ok(M.periodRange({ period: 'custom', from: '2026-10-20', to: '2026-10-01' }, TODAY).message);
  assert.strictEqual(k({}), 'lesson:a|lesson:b|lesson:c'); assert.strictEqual(M.activeFilterCount({ period: 'custom' }, TODAY), 0);
  assert.strictEqual(k({ from: 'garbage' }), 'lesson:a|lesson:b|lesson:c');
});
t('active filter count: kind + period only (search separate); hasAnyFilter includes search; defaults are inactive', function () {
  assert.strictEqual(M.activeFilterCount(M.defaults(), TODAY), 0); assert.ok(!M.hasAnyFilter(M.defaults(), TODAY));
  assert.strictEqual(M.activeFilterCount({ kind: 'exam' }, TODAY), 1); assert.strictEqual(M.activeFilterCount({ kind: 'exam', period: '7' }, TODAY), 2);
  assert.strictEqual(M.activeFilterCount({ q: 'x' }, TODAY), 0); assert.ok(M.hasAnyFilter({ q: 'x' }, TODAY)); assert.ok(!M.hasAnyFilter({ q: '  ' }, TODAY));
});
t('combined filters are an intersection and filtering never changes the base list', function () {
  var e = build({ lessons: [R('l', { date: '2026-10-20', subject: 'عربي' })], preps: [R('p', { date: '2026-10-20', subject: 'عربي' })], exams: [R('x', { examDate: '2026-08-01', status: 'held', subject: 'عربي' })] }), len = e.length;
  assert.strictEqual(keys(M.filterEntries(e, { q: 'عربي', kind: 'all', period: '7' }, TODAY)), 'lesson:l|prep:p');
  assert.strictEqual(keys(M.filterEntries(e, { q: 'عربي', kind: 'prep', period: '7' }, TODAY)), 'prep:p');
  assert.strictEqual(e.length, len);
});
t('countByKind', function () {
  var e = build({ lessons: [R('l', { date: '2026-10-01' })], exams: [R('x', { examDate: '2026-10-01', status: 'held' }), R('y', { examDate: '2026-10-02', status: 'held' })] });
  assert.deepStrictEqual(M.countByKind(e), { all: 3, lesson: 1, prep: 0, exam: 2 });
});
t('time rollover: the same stored records move between views only by date (record untouched)', function () {
  var p = [R('p', { date: '2026-10-23' })];
  assert.strictEqual(M.buildEntries({ classId: 'c1', today: '2026-10-23', preps: p }).length, 0);
  assert.strictEqual(M.buildEntries({ classId: 'c1', today: '2026-10-24', preps: p }).length, 1);
  assert.strictEqual(p[0].date, '2026-10-23');
});
t('time zones: derived result is identical under Baghdad, UTC, Los Angeles and Kiritimati (dates are local strings)', function () {
  var code = "var M=require('" + path.resolve(__dirname, '../js/archive-model.js').replace(/\\/g, '/') + "');var S=require('" + path.resolve(__dirname, '../js/academic-store.js').replace(/\\/g, '/') + "');" +
    "var today=S.toLocalDate();var e=M.buildEntries({classId:'c',today:today,preps:[{recordId:'p',classId:'c',date:'2026-10-21'},{recordId:'q',classId:'c',date:'2026-10-22'}]});" +
    "console.log(M.addDays('2026-03-08',1)+'|'+M.periodRange({period:'7'},'2026-10-22').from+'|'+e.map(function(x){return x.key}).join(','));";
  ['Asia/Baghdad', 'UTC', 'America/Los_Angeles', 'Pacific/Kiritimati'].forEach(function (tz) {
    var out = cp.execFileSync(process.execPath, ['-e', code], { env: Object.assign({}, process.env, { TZ: tz, FAKE: '1' }) }).toString().trim().split('|');
    assert.strictEqual(out[0], '2026-03-09'); assert.strictEqual(out[1], '2026-10-16');
  });
});
t('integration with the real store: reading + deriving + filtering writes nothing and edits nothing', function () {
  var st = fake(), s = S.create({ storage: st });
  s.saveCollection('dailyLessons', 'c1', [R('l', { date: '2026-10-01' })]); s.saveCollection('preparations', 'c1', [R('p', { date: '2026-10-01' }), R('pf', { date: '2026-12-01' })]); s.saveCollection('exams', 'c1', [R('x', { examDate: '2026-10-01', status: 'held' })]);
  s.saveCollection('dailyLessons', 'c2', [R('z', { date: '2026-10-01', classId: 'c2' })]);
  var before = JSON.stringify(st.d);
  var e = M.sortEntries(build({ lessons: s.readCollection('dailyLessons', 'c1').records, preps: s.readCollection('preparations', 'c1').records, exams: s.readCollection('exams', 'c1').records }));
  M.filterEntries(e, { q: 'l', kind: 'lesson', period: '30' }, TODAY);
  assert.strictEqual(JSON.stringify(st.d), before); assert.strictEqual(e.length, 3); assert.ok(!Object.keys(st.d).some(function (k) { return /archive/i.test(k); }));
});
console.log(n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
