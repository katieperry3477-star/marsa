// اختبار واجهة 4.04: الدرجات والتقييمات (وضع ممثل الصف) + الخصوصية في وضع الطالب + الفصل عن «الامتحانات».
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-grades.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
async function skip(page) { await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
}
async function newClass(page, stage) {
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', stage); await page.click('#dlg-class button.primary');
  await page.waitForSelector('#dlg-class', { state: 'hidden' });
  var card = page.locator('li.cls', { hasText: stage }).filter({ has: page.locator('button:has-text("اختيار كصف نشط")') });
  if (await card.count()) await card.first().locator('button:has-text("اختيار كصف نشط")').click();
  return page.evaluate(function () { return JSON.parse(localStorage.getItem('marsa.classes')).activeClassId; });
}
async function addStudents(page, names) {
  await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")'); await page.fill('#add-names', names.join('\n'));
  await page.click('button:has-text("معاينة الأسماء")'); await page.click('button:has-text("تأكيد الإضافة")'); await page.waitForSelector('#dlg-add', { state: 'hidden' });
}
async function toGr(page) { await page.click('.nav button:text-is("الدرجات")'); await page.waitForSelector('#gr-score'); }
async function recs(page, cid, type) { return page.evaluate(function (a) { var raw = localStorage.getItem('marsa.academic.' + a.t + '.' + a.c); return raw ? JSON.parse(raw).records : []; }, { c: cid, t: type || 'grades' }); }
async function fillForm(page, o) {
  if (o.student !== undefined) await page.selectOption('#gr-studentId', { label: o.student });
  if (o.subject !== undefined) await page.fill('#gr-subject', o.subject);
  if (o.title !== undefined) await page.fill('#gr-title', o.title);
  if (o.date !== undefined) await page.fill('#gr-date', o.date);
  if (o.score !== undefined) await page.fill('#gr-score', o.score);
  if (o.max !== undefined) await page.fill('#gr-maxScore', o.max);
  if (o.note !== undefined) await page.fill('#gr-note', o.note);
}
async function save(page) { await page.click('.gr-form button.primary'); await page.waitForTimeout(120); }
async function clearStatus(page) { await page.evaluate(function () { document.getElementById('status').textContent = ''; }); }
async function status(page) { return page.textContent('#status'); }
async function cards(page) { return page.$$eval('.grow', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function localDay(page) { return page.evaluate(function () { return window.MarsaGradesModel.localDate(); }); }

(async function () {
  var browser = await pw.chromium.launch();
  var ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  var page = await ctx.newPage(); page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.addInitScript(function () {
    window.__reads = []; var g = Storage.prototype.getItem;
    Storage.prototype.getItem = function (k) { if (String(k).indexOf('marsa.academic.grades.') === 0) window.__reads.push(k); return g.apply(this, arguments); };
  });
  await page.goto(URL); await skip(page);

  // ===== 1) وضع الطالب: لا قراءة لنوع الدرجات ولا عرض فردي =====
  await page.evaluate(function () { localStorage.setItem('marsa.academic.grades.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', records: [{ recordId: 'grd_secret', classId: 'cls_demo_001', studentId: 'stu_secret', subject: 'سرّ-المادة', title: 'سرّ-العنوان', date: '2026-10-20', score: 3, maxScore: 10, note: 'سرّ-الدرجة' }] })); window.__reads.length = 0; });
  var navs = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  for (var i = 0; i < navs.length; i++) { await page.click('.nav button >> nth=' + i); await page.waitForTimeout(60); }
  await page.click('.nav button:has-text("درجاتي")');
  var stTxt = await page.textContent('#v-page');
  check('وضع الطالب: «درجاتي» تعرض تنبيه المصادقة', /يحتاج مصادقة/.test(stTxt) && /هوية طالب موثوقة/.test(stTxt), stTxt.slice(0, 200));
  check('وضع الطالب: لا نص «لا توجد درجات مسجلة» المضلّل', !/لا توجد درجات مسجلة/.test(stTxt));
  check('وضع الطالب: لا تظهر الدرجة المخزّنة ولا بيانات الطالب في أي مكان', !/سرّ-المادة|سرّ-العنوان|سرّ-الدرجة|stu_secret/.test(await page.evaluate(function () { return document.body.textContent; })));
  check('وضع الطالب: لم تُقرأ مفاتيح الدرجات من localStorage في كل الصفحات', (await page.evaluate(function () { return window.__reads; })).length === 0, JSON.stringify(await page.evaluate(function () { return window.__reads; })));
  check('وضع الطالب: لا زر ولا نموذج ولا قائمة طلاب في «درجاتي»', (await page.$$('#v-page button.btn, #v-page .grow, #v-page #gr-score')).length === 0);
  check('وضع الطالب: لا زر «الدرجات» الخاص بالممثل في الشريط', navs.indexOf('الدرجات') < 0 && navs.indexOf('درجاتي') > -1, navs.join('|'));
  await page.evaluate(function () { localStorage.removeItem('marsa.academic.grades.cls_demo_001'); });

  // ===== 2) وضع الممثل: الصف والطلاب =====
  await toRep(page);
  var cid = await newClass(page, 'صف-4.04');
  var repNav = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  check('شريط الممثل يحوي «الدرجات» مرة واحدة بجانب «الامتحانات» الأصلية', repNav.filter(function (x) { return x === 'الدرجات'; }).length === 1 && repNav.filter(function (x) { return x === 'الامتحانات'; }).length === 1, repNav.join('|'));
  await page.click('.nav button:has-text("اللوحة")');
  check('لوحة الممثل: بلاطة واحدة للدرجات وأخرى مستقلة للامتحانات', (await page.$$eval('.tile', function (l) { return l.filter(function (b) { return /الدرجات والتقييمات/.test(b.textContent); }).length; })) === 1 && (await page.$$eval('.tile', function (l) { return l.filter(function (b) { return /إدارة الامتحانات/.test(b.textContent); }).length; })) === 1);
  await toGr(page);
  var t0 = await page.textContent('#v-page');
  check('صف بلا طلاب: حالة فراغ صادقة، والنموذج معطّل، ولا متوسط وهمي', /لا يوجد طلاب فعّالون/.test(t0) && await page.isDisabled('#gr-score') && /لا توجد درجات مسجلة بعد/.test(t0) && !/%/.test(await page.textContent('.gr-sum')));
  check('لا زر معطّل «يُفعّل في مرحلة لاحقة» في الدرجات', !/يُفعّل في مرحلة لاحقة/.test(t0));
  check('فتح الصفحة لا يكتب مفتاح الدرجات', (await recs(page, cid)).length === 0 && (await page.evaluate(function (c) { return localStorage.getItem('marsa.academic.grades.' + c); }, cid)) === null);
  await addStudents(page, ['أحمد علي', 'بشرى كريم', 'جاسم محمد']);
  var roster = await page.evaluate(function (id) { var raw = localStorage.getItem(id === 'cls_demo_001' ? 'marsa.roster' : 'marsa.roster.' + id); return JSON.parse(raw).students.map(function (s) { return [s.name, s.studentId]; }); }, cid);
  var idOf = {}; roster.forEach(function (r) { idOf[r[0]] = r[1]; });
  await toGr(page);
  check('قائمة الطلاب في النموذج: الفعّالون فقط (3 + الخيار الفارغ)', (await page.$$eval('#gr-studentId option', function (l) { return l.length; })) === 4);
  check('تاريخ اليوم المحلي افتراضياً وmax = اليوم', (await page.inputValue('#gr-date')) === (await localDay(page)) && (await page.getAttribute('#gr-date', 'max')) === (await localDay(page)));

  // ===== 3) التحقق: لا يُحفظ شيء ورسائل بجوار الحقول =====
  await save(page);
  check('نموذج فارغ: أخطاء للطالب والمادة والعنوان والدرجة والقصوى، ولا سجل، ولا رسالة نجاح', (await page.$$eval('.gr-form .fg .err', function (l) { return l.filter(function (e) { return e.textContent; }).length; })) >= 5 && (await recs(page, cid)).length === 0 && !/تم حفظ/.test(await status(page)));
  check('التركيز ينتقل لأول حقل خاطئ وaria-invalid موضوع', (await page.evaluate(function () { return document.activeElement.id; })) === 'gr-studentId' && (await page.getAttribute('#gr-studentId', 'aria-invalid')) === 'true');
  await fillForm(page, { student: 'أحمد علي', subject: 'الرياضيات', title: 'اختبار قصير', score: '11', max: '10' }); await save(page);
  check('الدرجة أكبر من القصوى: خطأ قرب الحقل ولا حفظ', /أكبر من الدرجة القصوى/.test(await page.textContent('#gr-score-e')) && (await recs(page, cid)).length === 0);
  await fillForm(page, { score: '5', max: '0' }); await save(page);
  check('الدرجة القصوى صفر مرفوضة', /أكبر من صفر/.test(await page.textContent('#gr-maxScore-e')) && (await recs(page, cid)).length === 0);
  await fillForm(page, { max: '-10' }); await save(page);
  check('الدرجة القصوى سالبة مرفوضة', (await page.textContent('#gr-maxScore-e')).length > 0 && (await recs(page, cid)).length === 0);
  await fillForm(page, { max: '10', score: 'abc' }); await save(page);
  check('درجة غير رقمية مرفوضة ولا تُعدّ صفراً', /رقماً/.test(await page.textContent('#gr-score-e')) && (await recs(page, cid)).length === 0);
  await fillForm(page, { score: '-1' }); await save(page);
  check('درجة سالبة مرفوضة', (await page.textContent('#gr-score-e')).length > 0 && (await recs(page, cid)).length === 0);
  await fillForm(page, { score: '5', date: '2099-01-01' }); await save(page);
  check('تاريخ مستقبلي مرفوض', (await page.textContent('#gr-date-e')).length > 0 && (await recs(page, cid)).length === 0);
  await page.fill('#gr-score', '7'); await page.waitForTimeout(30);
  check('كتابة في حقل تمسح خطأه وتزيل aria-invalid', (await page.textContent('#gr-score-e')) === '' && (await page.getAttribute('#gr-score', 'aria-invalid')) === null);

  // ===== 4) الإدخال: أرقام عشرية وعربية وقيم دنيا وعليا =====
  var d = await localDay(page);
  await fillForm(page, { date: d, score: '7.5', max: '10', note: 'جيد' }); await save(page);
  var r1 = await recs(page, cid);
  check('حُفظ سجل واحد بحقول صحيحة: grd_ وclassId وstudentId الثابت وتاريخ محلي والأرقام أعداد', r1.length === 1 && /^grd_/.test(r1[0].recordId) && r1[0].classId === cid && r1[0].studentId === idOf['أحمد علي'] && r1[0].date === d && r1[0].score === 7.5 && r1[0].maxScore === 10 && r1[0].subject === 'الرياضيات' && r1[0].title === 'اختبار قصير' && r1[0].note === 'جيد', JSON.stringify(r1));
  check('لا حقول مشتقة مخزنة (نسبة/متوسط)', Object.keys(r1[0]).every(function (k) { return ['recordId', 'classId', 'studentId', 'subject', 'title', 'date', 'score', 'maxScore', 'note', 'createdAt', 'updatedAt'].indexOf(k) > -1; }), Object.keys(r1[0]).join());
  check('رسالة النجاح بعد الحفظ الفعلي، والبطاقة تعرض 7.5 / 10 و75%', /تم حفظ الدرجة/.test(await status(page)) && (await cards(page)).length === 1 && /7\.5 \/ 10/.test((await cards(page))[0]) && /75%/.test((await cards(page))[0]), (await cards(page)).join('|'));
  check('بعد الحفظ: تُمسح الدرجة والملاحظة وتبقى المادة والعنوان والقصوى للإدخال التالي', (await page.inputValue('#gr-score')) === '' && (await page.inputValue('#gr-note')) === '' && (await page.inputValue('#gr-subject')) === 'الرياضيات' && (await page.inputValue('#gr-maxScore')) === '10' && (await page.inputValue('#gr-studentId')) === '');
  await fillForm(page, { student: 'بشرى كريم', score: '٥٫٢٥', max: '١٠' }); await save(page);
  await fillForm(page, { student: 'جاسم محمد', score: '0' }); await save(page);
  await fillForm(page, { student: 'أحمد علي', title: 'امتحان نصفي', score: '40', max: '50', note: '' }); await save(page);
  var r2 = await recs(page, cid);
  check('4 سجلات: الأرقام العربية خُزّنت عدداً 5.25، والصفر صالح (0)، والقصوى 50', r2.length === 4 && r2.some(function (r) { return r.score === 5.25 && r.maxScore === 10; }) && r2.some(function (r) { return r.score === 0; }) && r2.some(function (r) { return r.maxScore === 50 && r.score === 40; }), JSON.stringify(r2.map(function (r) { return [r.score, r.maxScore]; })));
  check('الدرجة المساوية للقصوى مقبولة (حد أعلى)', await (async function () { await fillForm(page, { student: 'بشرى كريم', title: 'واجب', score: '10', max: '10' }); await save(page); return (await recs(page, cid)).length === 5; })());

  // ===== 5) الفصل عن «الامتحانات» =====
  check('لا سجل كُتب في نوع exams من صفحة الدرجات', (await recs(page, cid, 'exams')).length === 0);
  await page.click('.nav button:has-text("الامتحانات")'); await page.waitForTimeout(80);
  var exTxt = await page.textContent('#v-page');
  check('صفحة «الامتحانات» تبقى للمواعيد: لا درجات ولا نموذج درجات فيها', !(await page.$('#gr-score')) && !/\/ 10/.test(exTxt) && (await page.$$('.grow')).length === 0);
  await toGr(page);

  // ===== 6) منع التكرار وإعادة الامتحان =====
  var before = (await recs(page, cid)).length;
  await fillForm(page, { student: 'أحمد علي', subject: 'الرياضيات', title: 'اختبار قصير', date: d, score: '9', max: '10' }); await clearStatus(page); await save(page);
  check('تكرار (طالب+مادة+عنوان+تاريخ): رسالة صريحة ولا سجل جديد ولا نجاح', /يوجد تقييم بالبيانات نفسها/.test(await page.textContent('#gr-msg')) && (await recs(page, cid)).length === before && !/تم حفظ/.test(await status(page)));
  check('زر «فتح السجل الموجود للتعديل» يظهر', (await page.$$('button:has-text("فتح السجل الموجود للتعديل")')).length === 1);
  await page.fill('#gr-subject', ' الرياضيات  '); await page.fill('#gr-title', 'اختبار   قصير'); await save(page);
  check('التكرار يُكتشف بعد توحيد المسافات', (await recs(page, cid)).length === before);
  await page.click('button:has-text("فتح السجل الموجود للتعديل")'); await page.waitForTimeout(80);
  check('الزر يفتح السجل الموجود بقيمه المخزّنة في وضع التعديل وبلا نافذة تأكيد', /تعديل درجة/.test(await page.textContent('.gr-form h2')) && (await page.inputValue('#gr-score')) === '7.5' && !(await page.isVisible('#dlg-confirm')));
  await page.click('.gr-form button.link:has-text("إلغاء التعديل")'); await page.waitForTimeout(60);
  await fillForm(page, { student: 'أحمد علي', subject: 'الرياضيات', title: 'اختبار قصير - إعادة', date: d, score: '6', max: '10' }); await save(page);
  check('إعادة الامتحان بعنوان مختلف مسموحة (سجل جديد)', (await recs(page, cid)).length === before + 1);
  await fillForm(page, { student: 'أحمد علي', subject: 'الرياضيات', title: 'اختبار قصير', date: '2026-01-05', score: '6', max: '10' }); await save(page);
  check('نفس العنوان بتاريخ مختلف مسموح (تقييم آخر مماثل)', (await recs(page, cid)).length === before + 2);

  // ===== 7) التعديل يحفظ recordId =====
  var all = await recs(page, cid), target = all.filter(function (r) { return r.studentId === idOf['أحمد علي'] && r.title === 'اختبار قصير'; })[0];
  var card = page.locator('.grow', { hasText: 'اختبار قصير' }).filter({ hasText: 'أحمد علي' }).filter({ hasNotText: 'إعادة' }).first();
  await card.locator('button:has-text("تعديل")').click(); await page.waitForTimeout(80);
  check('وضع التعديل: العنوان يتغير، الطالب مقفل، زر الإلغاء ظاهر، والقيم معبّأة', /تعديل درجة/.test(await page.textContent('.gr-form h2')) && await page.isDisabled('#gr-studentId') && (await page.inputValue('#gr-score')) === '7.5' && (await page.$$('button:has-text("إلغاء التعديل"):not([hidden])')).length === 1);
  await page.fill('#gr-score', '8.25'); await page.fill('#gr-note', 'بعد المراجعة'); await save(page);
  var r3 = await recs(page, cid), edited = r3.filter(function (r) { return r.recordId === target.recordId; })[0];
  check('التعديل: العدد كما هو، recordId وclassId وstudentId وcreatedAt ثابتة، والدرجة 8.25', r3.length === all.length && edited && edited.score === 8.25 && edited.studentId === target.studentId && edited.classId === cid && edited.createdAt === target.createdAt && edited.note === 'بعد المراجعة', JSON.stringify(edited));
  check('بعد التعديل: النموذج يعود لوضع الإضافة ورسالة نجاح التعديل', /تسجيل درجة/.test(await page.textContent('.gr-form h2')) && /تم حفظ تعديل الدرجة/.test(await status(page)) && !(await page.isDisabled('#gr-studentId')));
  await card.locator('button:has-text("تعديل")').click(); await page.fill('#gr-title', 'اختبار شهري'); await page.fill('#gr-score', '12'); await save(page);
  check('تعديل بقيمة خاطئة يُرفض ولا يغيّر المخزّن', (await recs(page, cid)).filter(function (r) { return r.recordId === target.recordId; })[0].score === 8.25 && (await page.textContent('#gr-score-e')).length > 0);
  await page.click('.gr-form button.link:has-text("إلغاء التعديل")'); await page.waitForTimeout(60);
  if (await page.isVisible('#dlg-confirm')) await page.click('#dlg-confirm button:has-text("تجاهل")');
  check('إلغاء التعديل يعيد وضع الإضافة', /تسجيل درجة/.test(await page.textContent('.gr-form h2')));

  // ===== 8) المتوسط وأساسه =====
  var sum = await page.textContent('.gr-sum');
  var sc = (await recs(page, cid)), tot = sc.reduce(function (a, r) { return a + r.score; }, 0), mx = sc.reduce(function (a, r) { return a + r.maxScore; }, 0), pct = Math.round(tot / mx * 10000) / 100;
  check('المتوسط الكلي = المجموع ÷ مجموع القصوى مع ذكر الأساس والعدد', sum.indexOf(pct + '%') > -1 && /المجموع ÷ مجموع الدرجات القصوى/.test(sum) && new RegExp('على ' + sc.length + ' تقييم').test(sum), sum + ' | expected ' + pct);
  check('ملخص حسب المادة موجود (الرياضيات)', /حسب المادة/.test(sum) && /الرياضيات/.test(sum));
  await page.selectOption('#gr-v-never', 'x').catch(function () { });
  await page.selectOption('.gr-listsec select >> nth=0', { label: 'أحمد علي' }); await page.waitForTimeout(60);
  var sum2 = await page.textContent('.gr-sum'), a = sc.filter(function (r) { return r.studentId === idOf['أحمد علي']; }), p2 = Math.round(a.reduce(function (x, r) { return x + r.score; }, 0) / a.reduce(function (x, r) { return x + r.maxScore; }, 0) * 10000) / 100;
  check('فلتر الطالب يعيد حساب المتوسط له وحده ويعنونه باسمه', /متوسط أحمد علي/.test(sum2) && sum2.indexOf(p2 + '%') > -1, sum2);
  await page.selectOption('.gr-listsec select >> nth=0', 'all');

  // ===== 9) البحث والفرز =====
  await page.fill('.gr-listsec input[type=search]', 'بشرى'); await page.waitForTimeout(60);
  check('البحث بالاسم: كل البطاقات لبشرى', (await cards(page)).length > 0 && (await cards(page)).every(function (t) { return /بشرى كريم/.test(t); }));
  await page.fill('.gr-listsec input[type=search]', 'امتحان نصفي'); await page.waitForTimeout(60);
  check('البحث بالعنوان', (await cards(page)).length === 1 && /40 \/ 50/.test((await cards(page))[0]));
  var dd = d.split('-'); await page.fill('.gr-listsec input[type=search]', dd[2] + '/' + dd[1] + '/' + dd[0]); await page.waitForTimeout(60);
  check('البحث بالتاريخ بصيغة DD/MM/YYYY', (await cards(page)).length === (await recs(page, cid)).filter(function (r) { return r.date === d; }).length && (await cards(page)).length > 0);
  await page.fill('.gr-listsec input[type=search]', 'لا-شيء-مطابق'); await page.waitForTimeout(60);
  check('بحث بلا نتائج: رسالة صريحة بدل قائمة صامتة', (await cards(page)).length === 0 && /لا توجد درجات مطابقة/.test(await page.textContent('.gr-listsec')));
  await page.fill('.gr-listsec input[type=search]', ''); await page.waitForTimeout(60);
  await page.selectOption('.gr-listsec select >> nth=1', { label: 'الرياضيات' }); await page.waitForTimeout(60);
  check('فلتر المادة', (await cards(page)).length > 0 && (await cards(page)).every(function (t) { return /الرياضيات/.test(t); }));
  await page.selectOption('.gr-listsec select >> nth=1', 'all');
  var sortSel = page.locator('.gr-listsec select[aria-label="معيار الفرز"]'), dirSel = page.locator('.gr-listsec select[aria-label="اتجاه الفرز"]');
  await sortSel.selectOption('percent'); await dirSel.selectOption('desc'); await page.waitForTimeout(60);
  var pcs = await page.$$eval('.grow .gr-score .tag', function (l) { return l.map(function (x) { return parseFloat(x.textContent); }); });
  check('الفرز بالنسبة تنازلياً', pcs.length > 2 && pcs.every(function (v, i) { return i === 0 || pcs[i - 1] >= v; }), pcs.join(','));
  await dirSel.selectOption('asc'); await page.waitForTimeout(60);
  pcs = await page.$$eval('.grow .gr-score .tag', function (l) { return l.map(function (x) { return parseFloat(x.textContent); }); });
  check('الفرز بالنسبة تصاعدياً', pcs.every(function (v, i) { return i === 0 || pcs[i - 1] <= v; }), pcs.join(','));
  await sortSel.selectOption('student'); await dirSel.selectOption('asc'); await page.waitForTimeout(60);
  var names = await page.$$eval('.grow .ar-n', function (l) { return l.map(function (x) { return x.textContent; }); });
  check('الفرز بالطالب أبجدياً', names.length > 2 && names.every(function (v, i) { return i === 0 || names[i - 1].localeCompare(v, 'ar') <= 0; }), names.join(','));
  await sortSel.selectOption('date'); await dirSel.selectOption('desc');
  check('الفرز لا يغيّر المخزّن (نفس عدد السجلات والمعرّفات)', (await recs(page, cid)).length === sc.length);

  // ===== 10) الحذف بتأكيد =====
  var cnt = (await recs(page, cid)).length, vic = page.locator('.grow', { hasText: '40 / 50' });
  await vic.locator('button:has-text("حذف")').click(); await page.waitForTimeout(60);
  var ct = await page.textContent('#dlg-confirm');
  check('نافذة تأكيد الحذف تذكر الطالب والمادة والعنوان والتاريخ والدرجة', /أحمد علي/.test(ct) && /الرياضيات/.test(ct) && /امتحان نصفي/.test(ct) && /40 من 50/.test(ct), ct);
  await page.click('#dlg-confirm button:has-text("إلغاء")'); check('إلغاء الحذف يُبقي السجل', (await recs(page, cid)).length === cnt);
  await vic.locator('button:has-text("حذف")').click(); await page.click('#dlg-confirm button:has-text("حذف السجل")'); await page.waitForTimeout(100);
  check('الحذف الفعلي: ينقص سجل واحد ورسالة بعد النجاح فقط', (await recs(page, cid)).length === cnt - 1 && /تم حذف سجل الدرجة/.test(await status(page)));

  // ===== 11) الطالب المؤرشف: قراءة وحذف فقط =====
  await page.click('.nav button:has-text("الطلاب")'); await page.locator('li.stu', { hasText: 'جاسم محمد' }).locator('button:has-text("أرشفة الطالب")').click();
  await page.click('#dlg-confirm button:has-text("أرشفة الطالب")'); await page.waitForTimeout(100);
  await toGr(page);
  check('الطالب المؤرشف غير موجود في قائمة إدخال التقييمات الجديدة', (await page.$$eval('#gr-studentId option', function (l) { return l.map(function (o) { return o.textContent; }); })).indexOf('جاسم محمد') < 0);
  var jc = page.locator('.grow', { hasText: 'جاسم محمد' });
  check('سجله التاريخي ما زال ظاهراً بوسم «مؤرشف» وبلا زر تعديل وبدرجته الصفرية الحقيقية', (await jc.count()) === 1 && /مؤرشف/.test(await jc.first().textContent()) && (await jc.first().locator('button:has-text("تعديل")').count()) === 0 && (await jc.first().locator('button:has-text("حذف")').count()) === 1 && /0 \/ 10/.test(await jc.first().textContent()));
  check('سجل المؤرشف لم يُحذف من التخزين', (await recs(page, cid)).some(function (r) { return r.studentId === idOf['جاسم محمد']; }));
  check('فلتر الطالب يتيح اختيار المؤرشف للقراءة', (await page.$$eval('.gr-listsec select option', function (l) { return l.some(function (o) { return /جاسم محمد \(مؤرشف\)/.test(o.textContent); }); })));
  await page.evaluate(function (a) { var d = JSON.parse(localStorage.getItem('marsa.academic.grades.' + a.c)); d.records.push(Object.assign({}, d.records[0], { recordId: 'grd_orphan', studentId: 'stu_missing_zz', title: 'يتيم' })); localStorage.setItem('marsa.academic.grades.' + a.c, JSON.stringify(d)); }, { c: cid });
  await page.reload(); await skip(page); await toRep(page); await toGr(page);
  var orphan = page.locator('.grow', { hasText: 'يتيم' });
  check('سجل طالب غير موجود يُعرض بتسمية صريحة ووسم «غير معروف» دون تعديل', (await orphan.count()) === 1 && /غير معروف/.test(await orphan.first().textContent()) && /غير موجود في قائمة هذا الصف/.test(await orphan.first().textContent()) && (await orphan.first().locator('button:has-text("تعديل")').count()) === 0);

  // ===== 12) العزل بين الصفوف =====
  var cid2 = await newClass(page, 'صف-4.04-ب');
  await addStudents(page, ['سارة نور']); await toGr(page);
  check('صف ثانٍ: لا يرى درجات الصف الأول ولا متوسطها', (await page.$$('.grow')).length === 0 && /لا توجد درجات مسجلة بعد/.test(await page.textContent('.gr-listsec')) && !/%/.test(await page.textContent('.gr-sum')));
  await fillForm(page, { student: 'سارة نور', subject: 'الفيزياء', title: 'اختبار', score: '3', max: '4' }); await save(page);
  check('درجة الصف الثاني تُحفظ في مفتاحه فقط وبـ classId الصحيح', (await recs(page, cid2)).length === 1 && (await recs(page, cid2))[0].classId === cid2 && (await recs(page, cid)).every(function (r) { return r.classId === cid; }) && (await recs(page, cid)).length > 0);
  check('مفاتيح الصفوف والطلاب لم تتأثر بالدرجات', await page.evaluate(function (a) { return !!localStorage.getItem('marsa.classes') && !!localStorage.getItem('marsa.roster.' + a.c); }, { c: cid }));

  // ===== 13) فشل التخزين: لا نجاح كاذب والنموذج يبقى =====
  await fillForm(page, { student: 'سارة نور', subject: 'الفيزياء', title: 'اختبار ثانٍ', score: '2', max: '4' });
  await page.evaluate(function () { window.__origSet = Storage.prototype.setItem; Storage.prototype.setItem = function (k) { if (String(k).indexOf('marsa.academic.grades.') === 0) throw new Error('QuotaExceededError'); return window.__origSet.apply(this, arguments); }; });
  await clearStatus(page); await save(page);
  check('امتلاء التخزين: رسالة فشل صريحة، لا رسالة نجاح، النموذج ما زال معبّأ', /لم تُحفظ الدرجة/.test(await page.textContent('#gr-msg')) && !/تم حفظ/.test(await status(page)) && (await page.inputValue('#gr-score')) === '2' && (await page.inputValue('#gr-title')) === 'اختبار ثانٍ');
  check('لم يُضف سجل ولم تظهر بطاقة وهمية', (await recs(page, cid2)).length === 1 && (await page.$$('.grow')).length === 1);
  await page.evaluate(function () { Storage.prototype.setItem = window.__origSet; });
  await save(page);
  check('بعد زوال العطل ينجح الحفظ نفسه', (await recs(page, cid2)).length === 2 && /تم حفظ الدرجة/.test(await status(page)));

  // ===== 14) بيانات تالفة: لا قائمة فارغة ولا كتابة فوقها =====
  await page.evaluate(function (c) { localStorage.setItem('marsa.academic.grades.' + c, '{ملف تالف'); }, cid2);
  await page.reload(); await skip(page); await toRep(page); await page.click('.nav button:has-text("اللوحة")');
  await page.click('button:has-text("إدارة الصفوف")'); await page.locator('li.cls', { hasText: 'صف-4.04-ب' }).first().locator('button:has-text("اختيار كصف نشط")').click().catch(function () { });
  await toGr(page);
  check('مخزن معطوب: تنبيه واضح، لا بطاقات، لا «لا توجد درجات»، لا متوسط', (await page.$$('.notice.warnbox')).length > 0 && (await page.$$('.grow')).length === 0 && !/لا توجد درجات مسجلة بعد/.test(await page.textContent('.gr-listsec')) && !/%/.test(await page.textContent('.gr-sum')));
  check('النموذج معطّل والبيانات التالفة لم تُمسّ', await page.isDisabled('#gr-score') && (await page.evaluate(function (c) { return localStorage.getItem('marsa.academic.grades.' + c); }, cid2)) === '{ملف تالف');
  await page.evaluate(function (c) { localStorage.setItem('marsa.academic.grades.' + c, JSON.stringify({ schemaVersion: 1, classId: c, records: [{ recordId: 'grd_x', classId: c, studentId: 'stu_x', subject: 'م', title: 'ع', date: '2026-10-01', score: 50, maxScore: 10 }] })); }, cid2);
  await page.reload(); await skip(page); await toRep(page); await toGr(page);
  check('درجة تتجاوز القصوى في المخزن: تُحجب بتنبيه ولا تُعرض كأنها صالحة', (await page.$$('.grow')).length === 0 && (await page.$$('.notice.warnbox')).length > 0);
  await page.evaluate(function (c) { localStorage.removeItem('marsa.academic.grades.' + c); }, cid2);

  // ===== 15) مسودة غير محفوظة: لا تُفقد بصمت =====
  await page.reload(); await skip(page); await toRep(page); await toGr(page);
  await page.fill('#gr-title', 'مسودة'); await page.click('.nav button:has-text("اللوحة")'); await page.waitForTimeout(60);
  check('مغادرة الصفحة بمسودة: نافذة تأكيد تجاهل', await page.isVisible('#dlg-confirm') && /غير المحفوظة/.test(await page.textContent('#dlg-confirm')));
  await page.click('#dlg-confirm button:has-text("إلغاء")'); check('إلغاء التأكيد يُبقي المسودة والصفحة', (await page.inputValue('#gr-title')) === 'مسودة');
  await page.click('.nav button:has-text("اللوحة")'); await page.click('#dlg-confirm button:has-text("تجاهل")'); await page.waitForTimeout(60);
  check('تأكيد التجاهل يغادر الصفحة', (await page.$('#gr-title')) === null);

  // ===== 16) XSS =====
  await toGr(page);
  await fillForm(page, { student: 'سارة نور', subject: '<img src=x onerror="window.__xss=1">', title: '<script>window.__xss=2</script>', score: '1', max: '2', note: '<b onmouseover="window.__xss=3">ملاحظة</b>' }); await save(page);
  check('نص يحوي HTML يُعرض نصاً ولا يُنفَّذ ولا يُنشأ له عنصر', (await page.evaluate(function () { return window.__xss; })) === undefined && (await page.$$('.grow img, .grow script, .grow [onmouseover], .grow .lc-t b')).length === 0 && /<img src=x/.test((await cards(page)).join('')));

  // ===== 17) الجوال: تجاوز أفقي، أهداف اللمس، التسميات =====
  check('لا تمرير أفقي على 390px', !(await overflow(page)));
  var small = await page.$$eval('.gr-form button, .gr-form input.field, .gr-form select, .gr-listsec input.field, .gr-listsec select, .grow button', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + (e.textContent || e.getAttribute('aria-label') || e.type) + ':' + Math.round(e.getBoundingClientRect().height); }); });
  check('أهداف اللمس ≥ 44px', small.length === 0, small.join(' | '));
  var lab = await page.evaluate(function () {
    return Array.prototype.slice.call(document.querySelectorAll('.gr-form input, .gr-form select, .gr-listsec input, .gr-listsec select')).filter(function (i) { return !(i.getAttribute('aria-label') || (i.id && document.querySelector('label[for="' + i.id + '"]'))); }).length;
  });
  check('كل حقل له تسمية، وأزرار البطاقات لها aria-label مفصّلة', lab === 0 && (await page.$$eval('.grow button', function (l) { return l.length > 0 && l.every(function (b) { return /—/.test(b.getAttribute('aria-label') || ''); }); })));
  check('الأخطاء مربوطة بـ aria-describedby', await page.evaluate(function () { var e = document.getElementById('gr-score'); return /gr-score-e/.test(e.getAttribute('aria-describedby')) && !!document.getElementById('gr-score-e'); }));
  for (var w = 0; w < 2; w++) { await page.setViewportSize({ width: w ? 320 : 768, height: 780 }); check('لا تمرير أفقي على عرض ' + (w ? 320 : 768), !(await overflow(page))); }
  await page.setViewportSize({ width: 390, height: 780 });

  check('لا أخطاء JavaScript في الصفحة', jsErrors.length === 0, jsErrors.join(' | '));
  await browser.close();
  var pass = results.filter(function (r) { return r.ok; }).length, fail = results.length - pass;
  console.log('\n' + pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
})().catch(function (e) { console.log('FATAL', e && e.stack || e); process.exit(2); });
