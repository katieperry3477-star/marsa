// اختبارات js/safe-text.js (03.6): node tests/safe-text.test.js
var T = require('../js/safe-text.js'), pass = 0, fail = 0;
function check(n, c, d) { if (c) { pass++; } else { fail++; console.log('FAIL ' + n + (d ? ' :: ' + d : '')); } }
function j(x) { return JSON.stringify(x); }
function plain(segs) { return segs.map(function (s) { return s.text; }).join(''); }
function hrefs(segs) { return segs.filter(function (s) { return s.href; }).map(function (s) { return s.href; }); }

var s = T.segments('انظر https://example.com/a?b=1 ثم أكمل');
check('رابط https يُكتشف', hrefs(s).length === 1 && hrefs(s)[0] === 'https://example.com/a?b=1', j(s));
check('النص كاملاً يُحفظ', plain(s) === 'انظر https://example.com/a?b=1 ثم أكمل', plain(s));
check('http مسموح', hrefs(T.segments('http://example.org/x')).length === 1);
check('حالة الأحرف الكبيرة HTTPS', hrefs(T.segments('HTTPS://EXAMPLE.COM/')).length === 1);
['javascript:alert(1)', 'JaVaScRiPt:alert(1)', 'data:text/html,<script>alert(1)</script>', 'file:///etc/passwd', 'vbscript:msgbox(1)', 'mailto:a@b.com', 'ftp://x.com/a', 'blob:x'].forEach(function (u) {
  var sg = T.segments('اضغط ' + u + ' الآن');
  check('بروتوكول غير مسموح يبقى نصاً: ' + u.slice(0, 14), hrefs(sg).length === 0 && plain(sg) === 'اضغط ' + u + ' الآن', j(sg));
});
check('javascript داخل مسار https لا يغيّر البروتوكول', hrefs(T.segments('https://x.com/?u=javascript:alert(1)')).length === 1 && T.safeHref('https://x.com/?u=javascript:alert(1)').indexOf('https://') === 0);
check('رابط بدخول مضمّن (تضليل) مرفوض', hrefs(T.segments('https://google.com@evil.com/')).length === 0, j(T.segments('https://google.com@evil.com/')));
check('blob: لا يصبح رابطاً قابلاً للنقر لكن https بعده رابط عادي', hrefs(T.segments('blob:https://x.com/1')).join() === 'https://x.com/1');
check('رابط بلا مضيف مرفوض', hrefs(T.segments('https:///x')).length === 0 && hrefs(T.segments('https://')).length === 0);
check('علامات الترقيم الختامية تُستثنى', hrefs(T.segments('المصدر (https://example.com/page).'))[0] === 'https://example.com/page', j(T.segments('المصدر (https://example.com/page).')));
check('فاصلة عربية ختامية تُستثنى', hrefs(T.segments('https://example.com/a،'))[0] === 'https://example.com/a');
check('رابطان في نص واحد', hrefs(T.segments('https://a.com/1 و https://b.com/2')).length === 2);
check('رابط طويل جداً مرفوض', hrefs(T.segments('https://a.com/' + new Array(2100).join('x'))).length === 0);
check('وسوم HTML تبقى نصاً', plain(T.segments('<img src=x onerror=alert(1)> <b>x</b>')) === '<img src=x onerror=alert(1)> <b>x</b>' && hrefs(T.segments('<img src=x onerror=alert(1)>')).length === 0);
check('رابط داخل وسم لا يبتلع الوسم', hrefs(T.segments('<a href="https://x.com/y">z</a>'))[0] === 'https://x.com/y', j(T.segments('<a href="https://x.com/y">z</a>')));
check('مدخل غير نصي يعطي قائمة فارغة', T.segments(null).length === 0 && T.segments(undefined).length === 0 && T.segments(5).length === 0);
check('نص فارغ', T.segments('').length === 0);
check('نص بلا روابط قطعة واحدة', T.segments('درس عادي').length === 1);
check('محارف خفية توقف الرابط', hrefs(T.segments('https://a.com/x​evil'))[0] === 'https://a.com/x', j(T.segments('https://a.com/x​evil')));
check('safeHref يرفض غير النص', T.safeHref(null) === '' && T.safeHref({}) === '' && T.safeHref('') === '');
console.log(pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
