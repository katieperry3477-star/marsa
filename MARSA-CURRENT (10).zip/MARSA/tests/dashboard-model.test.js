// اختبارات js/dashboard-model.js (03.10): node tests/dashboard-model.test.js
var D = require('../js/dashboard-model.js'), pass = 0, fail = 0;
var M = { lessons: require('../js/lessons-model.js'), schedule: require('../js/schedule-model.js'), preps: require('../js/preps-model.js'), exams: require('../js/exams-model.js') };
function check(n, c, d) { if (c) pass++; else { fail++; console.log('FAIL ' + n + (d ? ' :: ' + d : '')); } }
var T = '2026-10-22';
function col(records) { return { ok: true, records: records }; }
function inp(o) { return { classId: 'c1', today: T, dayKey: 'thu', lessons: o.lessons || col([]), schedule: o.schedule || col([]), preps: o.preps || col([]), exams: o.exams || col([]) }; }
function keys(S) { return S.counters.map(function (c) { return c.key; }).join(','); }

var S = D.summarize(inp({}), M);
check('كل شيء فارغ: لا عدادات', S.counters.length === 0, JSON.stringify(S.counters));
check('فارغ: الحالة ok والمجاميع صفر', S.lessons.status === 'ok' && S.lessons.total === 0 && S.exams.next === null && S.preps.latest === null);

// دروس
var L1 = { recordId: 'a', classId: 'c1', subject: 'ر', title: 'اليوم 1', date: T, createdAt: '2026-10-22T05:00:00Z' };
var L2 = { recordId: 'b', classId: 'c1', subject: 'ع', title: 'أمس', date: '2026-10-21', createdAt: '2026-10-21T05:00:00Z' };
var L3 = { recordId: 'c', classId: 'c1', subject: 'ف', title: 'اليوم 2', date: T, createdAt: '2026-10-22T06:00:00Z' };
var L4 = { recordId: 'd', classId: 'c1', subject: 'ف', title: 'غداً', date: '2026-10-23', createdAt: '2026-10-22T07:00:00Z' };
S = D.summarize(inp({ lessons: col([L2, L4, L1, L3]) }), M);
check('دروس اليوم فقط', S.lessons.todayCount === 2 && S.lessons.todayList.every(function (r) { return r.date === T; }));
check('لا يُحسب درس الغد ولا الأمس', S.lessons.todayList.indexOf(L4) < 0 && S.lessons.todayList.indexOf(L2) < 0);
check('آخر درس قبل اليوم', S.lessons.lastBefore && S.lessons.lastBefore.recordId === 'b');
check('عدّاد الدروس', keys(S).indexOf('lessons') > -1 && S.counters[0].value === 2);
S = D.summarize(inp({ lessons: col([L2]) }), M);
check('درس سابق فقط: عدّاد صفر صادق (المجموعة فيها سجل)', S.lessons.todayCount === 0 && S.counters[0].key === 'lessons' && S.counters[0].value === 0);
var many = []; for (var i = 0; i < 5; i++) many.push({ recordId: 'm' + i, classId: 'c1', subject: 'x', title: 't' + i, date: T, createdAt: '2026-10-22T0' + i + ':00:00Z' });
S = D.summarize(inp({ lessons: col(many) }), M);
check('المعروض محدود والباقي يُعدّ', S.lessons.shown.length === 3 && S.lessons.more === 2 && S.lessons.todayCount === 5);

// جدول
function sch(id, day, period, start, subj) { return { recordId: id, classId: 'c1', day: day, period: period, startTime: start, endTime: '', subject: subj }; }
S = D.summarize(inp({ schedule: col([sch('s3', 'thu', 3, '', 'ج'), sch('s1', 'thu', 1, '08:00', 'أ'), sch('s9', 'sun', 1, '08:00', 'ب'), sch('s2', 'thu', 2, '', 'ث')]) }), M);
check('حصص الخميس فقط ومرتبة', S.schedule.todayCount === 3 && S.schedule.todayList.map(function (r) { return r.recordId; }).join() === 's1,s2,s3', S.schedule.todayList.map(function (r) { return r.recordId; }).join());
check('عدّاد الحصص', S.counters.some(function (c) { return c.key === 'periods' && c.value === 3; }));
S = D.summarize(inp({ schedule: col([sch('s9', 'sun', 1, '', 'ب')]) }), M);
check('يوم بلا حصص لكن الجدول غير فارغ: صفر صادق', S.schedule.total === 1 && S.schedule.todayCount === 0 && S.counters[0].value === 0);
var I = inp({ schedule: col([sch('s1', 'thu', 1, '', 'أ')]) }); I.dayKey = null;
check('بلا مفتاح يوم: لا حصص', D.summarize(I, M).schedule.todayCount === 0);
S = D.summarize(inp({ schedule: col([{ recordId: 'u', classId: 'c1', day: 'xyz', subject: 'غ' }]) }), M);
check('يوم مجهول لا يُحسب لليوم', S.schedule.todayCount === 0);

// تحاضير
function prep(id, date, created, title) { return { recordId: id, classId: 'c1', subject: 'م', title: title || id, date: date, createdAt: created }; }
S = D.summarize(inp({ preps: col([prep('p1', '2026-10-20', '2026-10-01T00:00:00Z'), prep('p2', T, '2026-10-02T00:00:00Z'), prep('p3', '2026-10-23', '2026-10-03T00:00:00Z'), prep('p4', '', '2026-10-04T00:00:00Z')]) }), M);
check('التحاضير القادمة: اليوم فما بعده فقط', S.preps.upcomingCount === 2, S.preps.upcomingCount);
check('آخر تحضير = الأحدث إضافة لا الأقرب موعداً', S.preps.latest.recordId === 'p4');
check('تاريخ الغد المحسوب', S.preps.tomorrow === '2026-10-23');
S = D.summarize(inp({ preps: col([{ recordId: 'x', classId: 'c1', subject: 's', title: 't', date: T }, { recordId: 'y', classId: 'c1', subject: 's', title: 't', date: T }]) }), M);
check('بلا createdAt: ترتيب ثابت بالمعرّف', S.preps.latest.recordId === 'y');

// امتحانات
function ex(id, date, st) { return { recordId: id, classId: 'c1', subject: 'ك', title: id, examDate: date, status: st || 'scheduled' }; }
S = D.summarize(inp({ exams: col([ex('e1', '2026-10-30'), ex('e2', '2026-10-25'), ex('e3', '2026-10-20'), ex('e4', '2026-10-24', 'cancelled'), ex('e5', T)]) }), M);
check('أقرب امتحان قادم (اليوم يُحسب)', S.exams.next.recordId === 'e5');
check('القادمة: لا الملغى ولا الماضي', S.exams.upcomingCount === 3, S.exams.upcomingCount);
S = D.summarize(inp({ exams: col([ex('e3', '2026-10-20'), ex('h', '2026-10-30', 'held')]) }), M);
check('لا امتحان قادم: next=null وعدّاد صفر صادق', S.exams.next === null && S.counters[0].key === 'exams' && S.counters[0].value === 0);

// أخطاء
S = D.summarize(inp({ exams: { ok: false, records: [], error: 'تالفة' }, preps: { ok: false } }), M);
check('مجموعة تالفة: status error وبلا عدّاد', S.exams.status === 'error' && S.exams.error === 'تالفة' && keys(S).indexOf('exams') < 0);
check('خطأ بلا رسالة: رسالة افتراضية', S.preps.status === 'error' && S.preps.error.length > 0 && keys(S).indexOf('preps') < 0);
check('تلف مجموعة لا يؤثر في غيرها', D.summarize(inp({ lessons: col([L1]), exams: { ok: false, records: [] } }), M).lessons.todayCount === 1);
check('ok=false مع records لا تُقرأ', D.summarize(inp({ exams: { ok: false, records: [ex('z', T)] } }), M).exams.total === 0);

// المدخلات لا تُعدَّل
var recs = [L2, L1], before = JSON.stringify(recs); D.summarize(inp({ lessons: col(recs) }), M);
check('لا تعديل للمدخلات', JSON.stringify(recs) === before);

// التوقيع
var a = D.signature(inp({ lessons: col([L1]) })), b = D.signature(inp({ lessons: col([L1]) })), c = D.signature(inp({ lessons: col([L1, L2]) }));
check('توقيع ثابت لنفس المدخلات', a === b);
check('التوقيع يتغير بتغيّر السجلات', a !== c);
var d1 = inp({}); d1.today = '2026-10-23';
check('التوقيع يتغير بتغيّر اليوم', D.signature(inp({})) !== D.signature(d1));
var d2 = inp({}); d2.classId = 'c2';
check('التوقيع يتغير بتغيّر الصف', D.signature(inp({})) !== D.signature(d2));
check('التوقيع يتغير بتغيّر حالة التلف', D.signature(inp({})) !== D.signature(inp({ exams: { ok: false, error: 'x' } })));


// ===== 4.06: summarizeRep (حضور/درجات/مدفوعات: أعداد سجلات فقط، لا بيانات فردية) =====
var RM = require('../js/lessons-model.js');
function rinp(o) { return { classId: 'c1', today: T, attendance: o.attendance || col([]), grades: o.grades || col([]), payments: o.payments || col([]) }; }
var R = D.summarizeRep(rinp({}), RM);
check('4.06 فارغ: كل مجموعة ok وصفر', ['attendance', 'grades', 'payments'].every(function (k) { return R[k].status === 'ok' && R[k].total === 0 && R[k].todayCount === 0; }));
var A = [{ recordId: 'a1', studentId: 's1', date: T, status: 'present' }, { recordId: 'a2', studentId: 's2', date: T, status: 'absent' }, { recordId: 'a3', studentId: 's3', date: T, status: 'late' }, { recordId: 'a4', studentId: 's1', date: '2026-10-21', status: 'absent' }, { recordId: 'a5', studentId: 's4', date: 'bad', status: 'absent' }];
R = D.summarizeRep(rinp({ attendance: col(A) }), RM);
check('4.06 الحضور: المجموع 5 واليوم 3 فقط', R.attendance.total === 5 && R.attendance.todayCount === 3, JSON.stringify(R.attendance));
check('4.06 الحضور: غياب اليوم 1 وتأخر اليوم 1 (غياب الأمس والتاريخ التالف لا يُحسبان)', R.attendance.absentToday === 1 && R.attendance.lateToday === 1);
var G = [{ recordId: 'g1', studentId: 's1', subject: 'ر', title: 'اختبار 1', date: T, score: '9' }, { recordId: 'g2', studentId: 's2', subject: 'ر', title: 'اختبار 1', date: T, score: '8' }, { recordId: 'g3', studentId: 's1', subject: 'ع', title: 'شفوي', date: '2026-10-20', score: '7' }];
R = D.summarizeRep(rinp({ grades: col(G) }), RM);
check('4.06 الدرجات: 3 سجلات في تقييمين مميّزين، سُجّل اليوم 2', R.grades.total === 3 && R.grades.assessmentCount === 2 && R.grades.todayCount === 2, JSON.stringify(R.grades));
R = D.summarizeRep(rinp({ payments: col([{ recordId: 'p1', studentId: 's1', date: T, amount: 5000 }, { recordId: 'p2', studentId: 's1', date: '2026-10-01', amount: 2000 }]) }), RM);
check('4.06 المدفوعات: عدد فقط (2 ، اليوم 1)', R.payments.total === 2 && R.payments.todayCount === 1);
var flat = JSON.stringify(R);
check('4.06 المخرجات بلا مبلغ ولا معرّف طالب ولا اسم', !/5000|2000|s1|amount|studentId/.test(flat), flat);
R = D.summarizeRep(rinp({ attendance: { ok: false, records: [], error: 'تالف' } }), RM);
check('4.06 مجموعة غير مقروءة: status=error ولا رقم', R.attendance.status === 'error' && R.attendance.total === 0 && R.attendance.error === 'تالف');
var sig1 = D.signatureRep(rinp({ attendance: col(A) })), sig2 = D.signatureRep(rinp({ attendance: col(A.slice(1)) }));
check('4.06 التوقيع يتغير مع تغيّر السجلات وثابت مع تساويها', sig1 !== sig2 && sig1 === D.signatureRep(rinp({ attendance: col(A) })));
check('4.06 لوحة اليوم العامة لا تنتج عدّاد حضور/درجات/مدفوعات', !/attendance|grades|payments/.test(D.summarize(inp({}), M).counters.map(function (c) { return c.key; }).join()));

console.log(pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
