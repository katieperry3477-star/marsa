// اختبار واجهة 4.05: المدفوعات وسجل المقبوضات (وضع ممثل الصف) + الخصوصية في وضع الطالب.
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-payments.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
async function skip(page) { await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
}
async function newClass(page, stage) {
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', stage); await page.click('#dlg-class button.primary');
  await page.waitForSelector('#dlg-class', { state: 'hidden' });
  var card = page.locator('li.cls', { hasText: stage }).filter({ has: page.locator('button:has-text("اختيار كصف نشط")') });
  if (await card.count()) await card.first().locator('button:has-text("اختيار كصف نشط")').click();
  return page.evaluate(function () { return JSON.parse(localStorage.getItem('marsa.classes')).activeClassId; });
}
async function addStudents(page, names) {
  await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")'); await page.fill('#add-names', names.join('\n'));
  await page.click('button:has-text("معاينة الأسماء")'); await page.click('button:has-text("تأكيد الإضافة")'); await page.waitForSelector('#dlg-add', { state: 'hidden' });
}
async function toPay(page) { await page.click('.nav button:text-is("المدفوعات")'); await page.waitForSelector('#pay-amount'); }
async function recs(page, cid) { return page.evaluate(function (c) { var raw = localStorage.getItem('marsa.academic.payments.' + c); return raw ? JSON.parse(raw).records : []; }, cid); }
async function fillForm(page, o) {
  if (o.student !== undefined) await page.selectOption('#pay-studentId', { label: o.student });
  if (o.amount !== undefined) await page.fill('#pay-amount', o.amount);
  if (o.purpose !== undefined) await page.fill('#pay-purpose', o.purpose);
  if (o.date !== undefined) await page.fill('#pay-date', o.date);
  if (o.receipt !== undefined) await page.fill('#pay-receiptNo', o.receipt);
  if (o.note !== undefined) await page.fill('#pay-note', o.note);
}
async function save(page) { await page.click('.pay-form .toolbar button.primary'); await page.waitForTimeout(120); }
async function clearStatus(page) { await page.evaluate(function () { document.getElementById('status').textContent = ''; }); }
async function status(page) { return page.textContent('#status'); }
async function cards(page) { return page.$$eval('.pay-list .grow', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function today(page) { return page.evaluate(function () { return window.MarsaPaymentsModel.localDate(); }); }

(async function () {
  var browser = await pw.chromium.launch();
  var ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  var page = await ctx.newPage(); page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.addInitScript(function () {
    window.__reads = []; var g = Storage.prototype.getItem;
    Storage.prototype.getItem = function (k) { if (String(k).indexOf('marsa.academic.payments.') === 0) window.__reads.push(k); return g.apply(this, arguments); };
  });
  await page.goto(URL); await skip(page);

  // ===== 1) وضع الطالب: لا قراءة لنوع المدفوعات ولا أي عرض فردي =====
  await page.evaluate(function () { localStorage.setItem('marsa.academic.payments.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', records: [{ recordId: 'pay_secret', classId: 'cls_demo_001', studentId: 'stu_secret', amount: 987654, purpose: 'سرّ-الغرض', date: '2026-10-20', receiptNo: 'سرّ-وصل', note: 'سرّ-الملاحظة' }] })); window.__reads.length = 0; });
  var navs = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  for (var i = 0; i < navs.length; i++) { await page.click('.nav button >> nth=' + i); await page.waitForTimeout(60); }
  check('وضع الطالب: لا توجد صفحة «المدفوعات» في التنقل', navs.indexOf('المدفوعات') < 0, JSON.stringify(navs));
  var bodyTxt = await page.evaluate(function () { return document.body.textContent; });
  check('وضع الطالب: لا يظهر مبلغ ولا غرض ولا وصل مخزّن في أي صفحة', !/987654|987,654|سرّ-الغرض|سرّ-وصل|سرّ-الملاحظة|stu_secret/.test(bodyTxt));
  check('وضع الطالب: لم يُستدعَ getItem لمفتاح payments إطلاقاً', (await page.evaluate(function () { return window.__reads.length; })) === 0, JSON.stringify(await page.evaluate(function () { return window.__reads; })));
  var hs = await page.evaluate(function () { return location.hash; });
  await page.evaluate(function () { try { window.__go && window.__go('payments'); } catch (e) {} });
  check('وضع الطالب: لا نموذج مدفوعات في DOM', (await page.$('#pay-amount')) === null);
  await page.evaluate(function () { localStorage.removeItem('marsa.academic.payments.cls_demo_001'); });

  // ===== 2) وضع الممثل: بلا صف نشط ولا كتابة =====
  await toRep(page);
  await page.evaluate(function () { var c = JSON.parse(localStorage.getItem('marsa.classes')); window.__classesBackup = JSON.stringify(c); });
  var cid = await newClass(page, 'صف مدفوعات أ'); check('صف جديد نشط', !!cid);
  await toPay(page);
  var pt = await page.textContent('#v-page');
  check('الصفحة تشرح أنها مبالغ مستلمة فعلاً بلا ديون أو رسوم مفترضة', /استُلمت فعلاً/.test(pt) && /ديوناً أو غرامات/.test(pt) && /الدينار العراقي/.test(pt));
  check('لا زر معطّل «إضافة سجل» القديم ولا «يُفعّل في مرحلة لاحقة»', !/يُفعّل في مرحلة لاحقة/.test(pt) && !(await page.$('.page-head .act')));
  check('حالة فارغة صادقة: لا توجد دفعات + لا إجمالي', /لا توجد دفعات مسجلة بعد/.test(pt) && /لا يوجد إجمالي/.test(pt));
  check('بلا طلاب: النموذج معطّل ورسالة صريحة وزر فتح الطلاب', (await page.isDisabled('#pay-amount')) && (await page.isDisabled('.pay-form .toolbar button.primary')) && /لا يوجد طلاب فعّالون/.test(pt));
  check('لا مبلغ افتراضي في الحقل', (await page.inputValue('#pay-amount')) === '');
  check('لم يُنشأ أي مفتاح payments من مجرد فتح الصفحة', (await page.evaluate(function (c) { return localStorage.getItem('marsa.academic.payments.' + c); }, cid)) === null);

  await addStudents(page, ['أحمد علي', 'بشرى حسن', 'جاسم كريم']); await toPay(page);
  var td = await today(page);
  var opts = await page.$$eval('#pay-studentId option', function (o) { return o.map(function (x) { return x.textContent; }); });
  check('قائمة الطلاب: فعّالون فقط + عنصر «اختر الطالب»', opts.length === 4 && opts[0] === 'اختر الطالب', JSON.stringify(opts));
  check('التاريخ الافتراضي اليوم المحلي وحده الأقصى اليوم', (await page.inputValue('#pay-date')) === td && (await page.getAttribute('#pay-date', 'max')) === td);
  check('حقل المبلغ نصي رقمي LTR مع تسمية «دينار عراقي»', (await page.getAttribute('#pay-amount', 'inputmode')) === 'numeric' && (await page.textContent('label[for="pay-amount"]')).indexOf('دينار عراقي') > -1);

  // ===== 3) التحقق من الإدخال =====
  await save(page);
  check('حفظ فارغ: رسائل خطأ قرب الحقول ولا سجل', (await page.textContent('#pay-studentId-e')) !== '' && (await page.textContent('#pay-amount-e')) !== '' && (await page.textContent('#pay-purpose-e')) !== '' && (await recs(page, cid)).length === 0);
  check('أول حقل خاطئ يأخذ التركيز + aria-invalid', (await page.evaluate(function () { return document.activeElement.id; })) === 'pay-studentId' && (await page.getAttribute('#pay-studentId', 'aria-invalid')) === 'true');
  var bad = [['0', /أكبر من صفر/], ['-500', /موجباً/], ['5000.5', /بلا كسور/], ['abc', /رقماً/], ['١٠٠٠٠٠٠٠٠٠٠٠٠٠', /كبير جداً/]];
  for (var b = 0; b < bad.length; b++) {
    await fillForm(page, { student: 'أحمد علي', amount: bad[b][0], purpose: 'غرض' }); await save(page);
    check('مبلغ «' + bad[b][0] + '» مرفوض برسالة مناسبة ولا يُحفظ', bad[b][1].test(await page.textContent('#pay-amount-e')) && (await recs(page, cid)).length === 0, await page.textContent('#pay-amount-e'));
  }
  await fillForm(page, { amount: '5000', purpose: '   ' }); await save(page);
  check('غرض مسافات فقط مرفوض', (await page.textContent('#pay-purpose-e')) !== '' && (await recs(page, cid)).length === 0);
  var tm = await page.evaluate(function () { var d = new Date(); d.setDate(d.getDate() + 1); return window.MarsaPaymentsModel.localDate(d); });
  await fillForm(page, { purpose: 'غرض', date: tm }); await save(page);
  check('تاريخ بعد اليوم المحلي مرفوض', /بعد اليوم/.test(await page.textContent('#pay-date-e')) && (await recs(page, cid)).length === 0);
  await fillForm(page, { date: '' }); await save(page);
  check('تاريخ فارغ مرفوض', (await page.textContent('#pay-date-e')) !== '' && (await recs(page, cid)).length === 0);
  check('بيانات النموذج لم تُمسح بعد فشل التحقق', (await page.inputValue('#pay-amount')) === '5000' && (await page.inputValue('#pay-purpose')) === 'غرض');

  // ===== 4) إضافة صحيحة =====
  await fillForm(page, { student: 'أحمد علي', amount: '٢٥٬٠٠٠', purpose: 'ملزمة الرياضيات', date: td, receipt: 'R-100', note: 'نقداً' }); await clearStatus(page); await save(page);
  var r1 = await recs(page, cid);
  check('الحفظ: سجل واحد بمبلغ 25000 عدداً صحيحاً (number)', r1.length === 1 && r1[0].amount === 25000 && typeof r1[0].amount === 'number', JSON.stringify(r1));
  check('السجل: recordId pay_ وclassId مطابق وstudentId ثابت وطوابع زمنية ولا حقول مشتقة', /^pay_/.test(r1[0].recordId) && r1[0].classId === cid && /^[A-Za-z0-9_-]{1,64}$/.test(r1[0].studentId) && !!r1[0].createdAt && !!r1[0].updatedAt && Object.keys(r1[0]).sort().join() === 'amount,classId,createdAt,date,note,purpose,receiptNo,recordId,studentId,updatedAt', Object.keys(r1[0]).join());
  check('رسالة نجاح بعد حفظ فعلي', /تم حفظ الدفعة/.test(await status(page)));
  check('النموذج بعد الحفظ: الطالب والمبلغ والوصل والملاحظة فُرِّغت والغرض والتاريخ بقيا', (await page.inputValue('#pay-amount')) === '' && (await page.inputValue('#pay-studentId')) === '' && (await page.inputValue('#pay-receiptNo')) === '' && (await page.inputValue('#pay-purpose')) === 'ملزمة الرياضيات');
  var c0 = (await cards(page))[0];
  check('البطاقة: الطالب والمبلغ بالدينار العراقي والغرض والتاريخ والوصل', /أحمد علي/.test(c0) && /25,000 دينار عراقي/.test(c0) && /ملزمة الرياضيات/.test(c0) && /R-100/.test(c0) && c0.indexOf(td.slice(8, 10) + '/' + td.slice(5, 7) + '/' + td.slice(0, 4)) > -1, c0);
  var sm = await page.textContent('.pay-sum');
  check('الإجمالي: «المستلم المسجَّل» 25,000 مع بيان الفترة وأنه ليس مطلوباً أو متبقياً', /المستلم المسجَّل/.test(sm) && /25,000 دينار عراقي/.test(sm) && /كل السجلات المسجَّلة/.test(sm) && /وليس مبلغاً مطلوباً أو متبقياً/.test(sm) && !/المطلوب:|المتبقي:|الدين:/.test(sm), sm);

  // دفعتان متطابقتان مسموحتان + تحذير وصل مكرر
  await fillForm(page, { student: 'أحمد علي', amount: '25000', purpose: 'ملزمة الرياضيات', receipt: 'r-100' });
  check('تلميح مباشر لرقم وصل مكرر (تحذير لا منع)', /مستخدم في 1 دفعة أخرى/.test(await page.textContent('#pay-receiptNo-w')));
  await clearStatus(page); await save(page);
  check('وصل مكرر + دفعة مطابقة: تُحفظ ويظهر تنبيه في الحالة', (await recs(page, cid)).length === 2 && /تنبيه: رقم الوصل مستخدم في 1 دفعة/.test(await status(page)), await status(page));
  check('لا فرض منع تكرار: السجلان بمعرّفين مختلفين', (await recs(page, cid)).map(function (r) { return r.recordId; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).length === 2);

  // ===== 5) تعديل يحافظ على recordId =====
  var rid = r1[0].recordId;
  await page.locator('.pay-list .grow[data-record-id="' + rid + '"] button:has-text("تعديل")').click();
  check('وضع التعديل: العنوان وزر الحفظ والإلغاء والطالب مقفل', (await page.textContent('.pay-form h2')) === 'تعديل دفعة' && (await page.textContent('.pay-form .toolbar button.primary')) === 'حفظ التعديل' && (await page.isDisabled('#pay-studentId')) && (await page.inputValue('#pay-amount')) === '25000');
  await page.fill('#pay-amount', '30000'); await page.fill('#pay-purpose', 'ملزمة الفيزياء'); await page.fill('#pay-receiptNo', ''); await clearStatus(page); await save(page);
  var r2 = await recs(page, cid), ed = r2.filter(function (r) { return r.recordId === rid; })[0];
  check('التعديل: نفس recordId ونفس createdAt وعدد السجلات 2 والمبلغ والغرض تغيّرا ورقم الوصل أُزيل', !!ed && r2.length === 2 && ed.amount === 30000 && ed.purpose === 'ملزمة الفيزياء' && !('receiptNo' in ed) && ed.createdAt === r1[0].createdAt && ed.studentId === r1[0].studentId && ed.updatedAt >= r1[0].updatedAt, JSON.stringify(ed));
  check('بعد التعديل: رجع النموذج لوضع الإضافة ورسالة تعديل', /تم حفظ تعديل الدفعة/.test(await status(page)) && (await page.textContent('.pay-form h2')) === 'تسجيل دفعة مستلمة');
  await page.locator('.pay-list .grow[data-record-id="' + rid + '"] button:has-text("تعديل")').click(); await clearStatus(page); await save(page);
  check('حفظ تعديل بلا تغيير: لا كتابة ورسالة «لا توجد تغييرات»', /لا توجد تغييرات/.test(await status(page)));
  await page.click('.pay-form button:has-text("إلغاء التعديل")');
  check('إلغاء التعديل (بلا تغيير): يعود لوضع الإضافة', (await page.textContent('.pay-form h2')) === 'تسجيل دفعة مستلمة');

  // ===== 6) إضافة دفعات أخرى بتواريخ مختلفة للإجماليات =====
  var d1 = '2026-09-10', d2 = '2026-10-01', d3 = '2026-10-15';
  async function addPay(st, amt, pur, date, rc) { await fillForm(page, { student: st, amount: amt, purpose: pur, date: date, receipt: rc || '' }); await save(page); }
  await addPay('بشرى حسن', '10000', 'رحلة', d1); await addPay('بشرى حسن', '5000', 'رحلة', d2, 'B-1'); await addPay('جاسم كريم', '2000', 'قرطاسية', d3);
  var all = await recs(page, cid);
  check('خمس دفعات محفوظة بمعرّفات فريدة', all.length === 5 && new Set(all.map(function (r) { return r.recordId; })).size === 5);
  var tot = all.reduce(function (s, r) { return s + r.amount; }, 0);
  var sumTxt = await page.textContent('.pay-sum');
  check('الإجمالي الكلي (بلا فترة) = مجموع السجلات المخزنة فعلاً', sumTxt.indexOf(new Intl.NumberFormat('en-US').format(tot) + ' دينار عراقي') > -1 && /5 دفعة/.test(sumTxt), sumTxt);
  var perTxt = await page.$$eval('.pay-per li', function (l) { return l.map(function (x) { return x.getAttribute('data-student-id') + '|' + x.textContent; }); });
  check('إجمالي كل طالب مشتق ومرتب (3 طلاب) ويذكر عدد الدفعات', perTxt.length === 3 && /أحمد علي/.test(perTxt.join()) && /بشرى حسن.*15,000 دينار عراقي \(2 دفعة\)/.test(perTxt.join()), perTxt.join('\n'));
  // فترة
  await page.fill('#pay-from', d2); await page.fill('#pay-to', d3); await page.dispatchEvent('#pay-to', 'change');
  var pt2 = await page.textContent('.pay-sum');
  var inRange = all.filter(function (r) { return r.date >= d2 && r.date <= d3; });
  var sumIn = inRange.reduce(function (s, r) { return s + r.amount; }, 0);
  check('مجموع الفترة [01/10 – 15/10] شامل الطرفين = ' + sumIn, pt2.indexOf(new Intl.NumberFormat('en-US').format(sumIn) + ' دينار عراقي') > -1 && /من 01\/10\/2026 إلى 15\/10\/2026/.test(pt2), pt2);
  check('الفترة لا تُخلط بالمجموع التاريخي: عنوان الفترة ظاهر ورقم التاريخي غائب', (await page.textContent('.pay-sum')).indexOf(new Intl.NumberFormat('en-US').format(tot) + ' دينار عراقي') < 0 || sumIn === tot);
  check('إجماليات الطلاب تتبع الفترة (بشرى 5,000 فقط)', /بشرى حسن.*5,000 دينار عراقي \(1 دفعة\)/.test((await page.$$eval('.pay-per li', function (l) { return l.map(function (x) { return x.textContent; }); })).join()));
  check('قائمة السجلات تتبع الفترة (عدد البطاقات)', (await cards(page)).length === inRange.length, String((await cards(page)).length));
  await page.fill('#pay-from', '2026-10-31'); await page.dispatchEvent('#pay-from', 'change');
  check('فترة معكوسة: رسالة خطأ ولا إجمالي ولا بطاقات', /بعد تاريخ النهاية/.test(await page.textContent('.pay-listsec')) && /صحّح الفترة/.test(await page.textContent('.pay-sum')) && (await cards(page)).length === 0);
  await page.fill('#pay-from', '2026-12-01'); await page.fill('#pay-to', '2026-12-31'); await page.dispatchEvent('#pay-to', 'change');
  check('فترة بلا دفعات: لا إجمالي مختلق (لا «0 دينار») ورسالة صادقة', /لا توجد دفعات مطابقة/.test(await page.textContent('.pay-sum')) && !/0 دينار عراقي/.test(await page.textContent('.pay-sum')));
  await page.click('button:has-text("مسح الفترة")');
  check('مسح الفترة يعيد كل السجلات', (await cards(page)).length === 5 && /كل السجلات المسجَّلة/.test(await page.textContent('.pay-sum')));
  await page.click('button:has-text("هذا الشهر")');
  var monthFrom = td.slice(0, 8) + '01';
  check('زر «هذا الشهر» يضبط من أول الشهر إلى اليوم', (await page.inputValue('#pay-from')) === monthFrom && (await page.inputValue('#pay-to')) === td);
  await page.click('button:has-text("مسح الفترة")');

  // ===== 7) البحث والفلتر والفرز =====
  await page.fill('input[type="search"]', 'قرطاسية');
  check('البحث بالغرض', (await cards(page)).length === 1 && /جاسم/.test((await cards(page))[0]));
  check('الإجمالي يذكر قيد البحث', /بحث: «قرطاسية»/.test(await page.textContent('.pay-sum')) && /2,000 دينار عراقي/.test(await page.textContent('.pay-sum')));
  await page.fill('input[type="search"]', 'B-1'); check('البحث برقم الوصل', (await cards(page)).length === 1 && /بشرى/.test((await cards(page))[0]));
  await page.fill('input[type="search"]', 'احمد'); check('البحث بالاسم مع توحيد الهمزة', (await cards(page)).length === 2);
  await page.fill('input[type="search"]', 'لا-يوجد'); check('بحث بلا نتيجة: رسالة صادقة', /لا توجد دفعات مطابقة/.test(await page.textContent('.pay-listsec')));
  await page.fill('input[type="search"]', '');
  await page.selectOption('.pay-listsec select[aria-label="فلتر الطالب"]', { label: 'بشرى حسن' });
  check('فلتر الطالب يقيّد القائمة والإجمالي (15,000) ويخفي تفصيل الطلاب', (await cards(page)).length === 2 && /15,000 دينار عراقي/.test(await page.textContent('.pay-sum')) && /الطالب: بشرى حسن/.test(await page.textContent('.pay-sum')) && (await page.$$('.pay-per li')).length === 0);
  await page.selectOption('.pay-listsec select[aria-label="فلتر الطالب"]', 'all');
  await page.selectOption('select[aria-label="معيار الفرز"]', 'amount'); await page.selectOption('select[aria-label="اتجاه الفرز"]', 'desc');
  var amts = (await recs(page, cid)).map(function (r) { return r.amount; }).sort(function (a, b) { return b - a; });
  var shown = (await page.$$eval('.pay-list .pay-amt', function (l) { return l.map(function (x) { return +x.textContent.replace(/[^\d]/g, ''); }); }));
  check('الفرز بالمبلغ تنازلياً', JSON.stringify(shown) === JSON.stringify(amts), JSON.stringify(shown));

  // ===== 8) الحذف بتأكيد =====
  var before = await recs(page, cid);
  await page.locator('.pay-list .grow[data-record-id="' + rid + '"] button:has-text("حذف")').click();
  var dlg = await page.textContent('#dlg-confirm');
  check('نافذة التأكيد تذكر الطالب والمبلغ والتاريخ والغرض', /أحمد علي/.test(dlg) && /30,000 دينار عراقي/.test(dlg) && /ملزمة الفيزياء/.test(dlg) && /لا يمكن التراجع/.test(dlg), dlg);
  check('لم يُحذف شيء قبل التأكيد', (await recs(page, cid)).length === before.length);
  await page.click('#dlg-confirm button:has-text("إلغاء")'); await page.waitForTimeout(80);
  check('إلغاء التأكيد: السجل باقٍ', (await recs(page, cid)).length === before.length);
  await page.locator('.pay-list .grow[data-record-id="' + rid + '"] button:has-text("حذف")').click(); await clearStatus(page);
  await page.click('#dlg-confirm button:has-text("حذف السجل")'); await page.waitForTimeout(100);
  var after = await recs(page, cid);
  check('الحذف بعد التأكيد: أُزيل السجل المقصود فقط وبقيت البقية', after.length === before.length - 1 && !after.some(function (r) { return r.recordId === rid; }) && /تم حذف سجل الدفعة/.test(await status(page)));
  check('الإجمالي تحدّث بعد الحذف', !(new RegExp(new Intl.NumberFormat('en-US').format(tot) + ' دينار')).test(await page.textContent('.pay-sum')));

  // ===== 9) أرشفة الطالب لا تمسح سجلاته =====
  var bashraId = (await recs(page, cid)).filter(function (r) { return r.purpose === 'رحلة'; })[0].studentId;
  await page.click('.nav button:has-text("الطلاب")'); await page.locator('li.stu', { hasText: 'بشرى حسن' }).locator('button:has-text("أرشفة الطالب")').click();
  await page.click('#dlg-confirm button:has-text("أرشفة الطالب")'); await page.waitForTimeout(120);
  await toPay(page);
  var archRecs = (await recs(page, cid)).filter(function (r) { return r.studentId === bashraId; });
  check('بعد أرشفة الطالب: سجلاته ما زالت في التخزين', archRecs.length === 2, String(archRecs.length));
  var archCards = (await cards(page)).filter(function (x) { return /بشرى حسن/.test(x); });
  check('سجلات المؤرشف تُعرض بوسم «مؤرشف» بلا زر تعديل وبزر حذف', archCards.length === 2 && archCards.every(function (x) { return /مؤرشف/.test(x) && /للقراءة والحذف فقط/.test(x); }) && (await page.$$('.pay-list .grow[data-student-id="' + bashraId + '"] button:has-text("تعديل")')).length === 0 && (await page.$$('.pay-list .grow[data-student-id="' + bashraId + '"] button:has-text("حذف")')).length === 2);
  check('المؤرشف غير موجود في قائمة النموذج ويُحتسب في الإجمالي', (await page.$$eval('#pay-studentId option', function (o) { return o.map(function (x) { return x.textContent; }); })).indexOf('بشرى حسن') < 0 && /بشرى حسن/.test(await page.textContent('.pay-sum')) && /مؤرشف/.test(await page.textContent('.pay-sum')));
  check('فلتر الطالب يتضمن المؤرشف بتسمية صريحة', (await page.$$eval('.pay-listsec select[aria-label="فلتر الطالب"] option', function (o) { return o.map(function (x) { return x.textContent; }); })).indexOf('بشرى حسن (مؤرشف)') > -1);

  // ===== 10) فشل التخزين =====
  await fillForm(page, { student: 'أحمد علي', amount: '777', purpose: 'اختبار الفشل' });
  var snapshot = await page.evaluate(function (c) { return localStorage.getItem('marsa.academic.payments.' + c); }, cid);
  await page.evaluate(function () { window.__origSet = Storage.prototype.setItem; Storage.prototype.setItem = function (k) { if (String(k).indexOf('marsa.academic.payments.') === 0) throw new DOMException('quota', 'QuotaExceededError'); return window.__origSet.apply(this, arguments); }; });
  await clearStatus(page); await save(page);
  check('فشل الكتابة: رسالة صريحة قرب النموذج ولا رسالة نجاح', /لم تُحفظ الدفعة/.test(await page.textContent('#pay-msg')) && !/تم حفظ الدفعة/.test(await status(page)));
  check('فشل الكتابة: بيانات النموذج باقية والتخزين لم يتغير والسجل غير مضاف', (await page.inputValue('#pay-amount')) === '777' && (await page.inputValue('#pay-purpose')) === 'اختبار الفشل' && (await page.evaluate(function (c) { return localStorage.getItem('marsa.academic.payments.' + c); }, cid)) === snapshot);
  check('فشل الكتابة: زر الحفظ عاد مفعّلاً (يمكن إعادة المحاولة)', !(await page.isDisabled('.pay-form .toolbar button.primary')));
  var aid = (await recs(page, cid))[0].recordId; var n0 = (await recs(page, cid)).length;
  await page.locator('.pay-list .grow[data-record-id="' + aid + '"] button:has-text("حذف")').click(); await clearStatus(page); await page.click('#dlg-confirm button:has-text("حذف السجل")'); await page.waitForTimeout(100);
  check('فشل الحذف: رسالة «لم يُحذف» والسجل باقٍ', /لم يُحذف السجل/.test(await status(page)) && (await recs(page, cid)).length === n0 && !/تم حذف/.test(await status(page)));
  await page.evaluate(function () { Storage.prototype.setItem = window.__origSet; });
  await save(page);
  check('بعد زوال العطل: إعادة المحاولة تنجح من الحالة نفسها', (await recs(page, cid)).some(function (r) { return r.amount === 777; }) && /تم حفظ الدفعة/.test(await status(page)));
  // حماية النقر المزدوج
  await fillForm(page, { student: 'أحمد علي', amount: '111', purpose: 'نقر مزدوج' });
  var cnt0 = (await recs(page, cid)).length;
  await page.evaluate(function () { document.activeElement.blur(); var b = document.querySelector('.pay-form .toolbar button.primary'); b.click(); b.click(); });
  await page.waitForTimeout(150);
  check('نقرتان متتاليتان على الحفظ لا تنتجان دفعتين (الحقول فُرِّغت بعد الأولى)', (await recs(page, cid)).length === cnt0 + 1);

  // ===== 11) بيانات تالفة =====
  await page.evaluate(function (c) { window.__good = localStorage.getItem('marsa.academic.payments.' + c); localStorage.setItem('marsa.academic.payments.' + c, '{broken'); }, cid);
  await page.click('.nav button:has-text("اللوحة")'); await toPay(page);
  await page.click('.nav button:has-text("اللوحة")'); await toPay(page);
  var corTxt = await page.textContent('#v-page');
  check('بيانات تالفة: تحذير صريح لا «لا توجد دفعات»', /تالفة/.test(corTxt) && !/لا توجد دفعات مسجلة بعد/.test(corTxt));
  check('بيانات تالفة: النموذج معطّل ولا إجمالي', (await page.isDisabled('#pay-amount')) && (await page.isDisabled('.pay-form .toolbar button.primary')) && !/دينار عراقي في/.test(await page.textContent('.pay-sum')));
  check('بيانات تالفة: القيمة الخام لم تُمسّ', (await page.evaluate(function (c) { return localStorage.getItem('marsa.academic.payments.' + c); }, cid)) === '{broken');
  check('بيانات تالفة: نسخة احتياطية خام أُنشئت', await page.evaluate(function (c) { return Object.keys(localStorage).some(function (k) { return k.indexOf('marsa.academic.payments.' + c + '.backup') === 0 && localStorage.getItem(k) === '{broken'; }); }, cid));
  await page.evaluate(function (c) { localStorage.setItem('marsa.academic.payments.' + c, window.__good); }, cid);
  await page.click('.nav button:has-text("اللوحة")'); await toPay(page);

  // ===== 12) عزل بين صفين =====
  var cidB = await newClass(page, 'صف مدفوعات ب'); await addStudents(page, ['زينب']); await toPay(page);
  check('الصف الثاني: لا سجلات من الصف الأول', (await cards(page)).length === 0 && /لا توجد دفعات مسجلة بعد/.test(await page.textContent('#v-page')));
  await fillForm(page, { student: 'زينب', amount: '999', purpose: 'صف ب' }); await save(page);
  check('الصف الثاني: السجل بمعرّف صفه فقط', (await recs(page, cidB)).length === 1 && (await recs(page, cidB))[0].classId === cidB && (await recs(page, cid)).every(function (r) { return r.classId === cid; }));
  check('الصف الثاني: لا يظهر إجمالي الصف الأول', /999 دينار عراقي/.test(await page.textContent('.pay-sum')) && !/صف أ/.test(await page.textContent('.pay-sum')));
  // تبديل الصف داخل الصفحة يعيد الرسم
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.locator('li.cls', { hasText: 'صف مدفوعات أ' }).locator('button:has-text("اختيار كصف نشط")').click();
  await toPay(page);
  check('بعد العودة للصف الأول: سجلاته فقط', (await cards(page)).length > 1 && !(await cards(page)).some(function (x) { return /زينب|999 دينار/.test(x); }));

  // ===== 13) حارس المسودة =====
  await fillForm(page, { amount: '123' });
  await page.click('.nav button:has-text("اللوحة")'); await page.waitForTimeout(100);
  check('مغادرة الصفحة بمسودة: نافذة تأكيد', /تجاهل بيانات الدفعة غير المحفوظة/.test(await page.textContent('#dlg-confirm')));
  await page.click('#dlg-confirm button:has-text("إلغاء")'); await page.waitForTimeout(80);
  check('إلغاء المغادرة: تبقى الصفحة والمسودة', (await page.inputValue('#pay-amount')) === '123');
  await page.click('.nav button:has-text("اللوحة")'); await page.click('#dlg-confirm button:has-text("تجاهل والمتابعة")'); await page.waitForTimeout(100);
  check('تجاهل المسودة يغادر الصفحة', (await page.$('#pay-amount')) === null);

  // ===== 14) النص الآمن (بلا innerHTML) =====
  await toPay(page);
  await fillForm(page, { student: 'أحمد علي', amount: '321', purpose: '<img src=x onerror=window.__xss=1>', note: '<b>غامق</b>', receipt: '<i>x</i>' }); await save(page);
  check('نص HTML في الغرض/الملاحظة/الوصل يُعرض نصاً ولا يُنفَّذ', (await page.evaluate(function () { return window.__xss; })) === undefined && (await page.$$('.pay-list img, .pay-list b b, .pay-list i')).length === 0 && /<img src=x/.test((await cards(page)).join()));

  // ===== 15) الجوال 320 وبدون تمرير أفقي، لوحة المفاتيح، لمس =====
  for (var w of [320, 390]) {
    await page.setViewportSize({ width: w, height: 700 }); await page.waitForTimeout(80);
    check('بلا تمرير أفقي عند عرض ' + w, !(await overflow(page)));
  }
  var smallBtns = await page.$$eval('.pay-form button, .pay-list button, .pay-period-bar button', function (l) { return l.filter(function (b) { var r = b.getBoundingClientRect(); return r.width && r.height && (r.height < 32); }).map(function (b) { return b.textContent; }); });
  check('أزرار الصفحة بحجم لمس لا يقل عن 32px ارتفاعاً', smallBtns.length === 0, smallBtns.join());
  var unl = await page.$$eval('.pay-form input, .pay-form select, .pay-listsec input, .pay-listsec select', function (l) { return l.filter(function (e) { return !e.labels.length && !e.getAttribute('aria-label') && !e.getAttribute('aria-labelledby'); }).map(function (e) { return e.id || e.type; }); });
  check('كل حقل له تسمية مرتبطة أو aria-label', unl.length === 0, unl.join());
  await page.focus('#pay-amount'); await page.keyboard.type('55'); await page.keyboard.press('Tab');
  check('لوحة المفاتيح: Tab ينقل للحقل التالي', (await page.evaluate(function () { return document.activeElement.id; })) === 'pay-purpose');
  await page.setViewportSize({ width: 390, height: 780 });

  // ===== 16) إخفاء الحركة والتباين: لا يوجد انتقال خاص بهذه الصفحة =====
  // ===== 17) تبديل للطالب: لا يبقى أي مبلغ في DOM =====
  await page.click('.seg button[data-m="student"]'); await page.waitForTimeout(700);
  // 4.08: النموذج يحوي مسودة من فحص لوحة المفاتيح أعلاه؛ تبديل الوضع صار يسأل قبل التجاهل (كان يُفقدها بصمت). نؤكد التجاهل ثم نتابع الفحص نفسه
  if (await page.evaluate(function () { var d = document.getElementById('dlg-confirm'); return !!d && d.open; })) { await page.locator('#dlg-confirm button.primary').last().click(); await page.waitForTimeout(900); }
  var t3 = await page.evaluate(function () { return document.body.textContent; });
  check('بعد التبديل لوضع الطالب: لا نموذج مدفوعات ولا مبالغ ولا غرض مخزّن', (await page.$('#pay-amount')) === null && !/دينار عراقي/.test(t3.replace(/الدينار العراقي/g, '')) && !/<img src=x/.test(t3), t3.slice(0, 120));

  check('لا أخطاء JavaScript أثناء الجلسة كلها', jsErrors.length === 0, jsErrors.join(' | '));
  await browser.close();
  var failed = results.filter(function (r) { return !r.ok; }).length;
  console.log('\n' + (results.length - failed) + ' passed, ' + failed + ' failed'); process.exit(failed ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
