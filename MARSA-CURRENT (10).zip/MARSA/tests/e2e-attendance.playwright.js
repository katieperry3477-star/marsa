// اختبار واجهة 4.03: الحضور والغياب (وضع ممثل الصف) + الخصوصية في وضع الطالب.
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-attendance.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
async function skip(page) { await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
}
async function newClass(page, stage) {
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', stage); await page.click('#dlg-class button.primary');
  await page.waitForSelector('#dlg-class', { state: 'hidden' });
  var card = page.locator('li.cls', { hasText: stage }).filter({ has: page.locator('button:has-text("اختيار كصف نشط")') });
  if (await card.count()) await card.first().locator('button:has-text("اختيار كصف نشط")').click();
  return page.evaluate(function () { var c = JSON.parse(localStorage.getItem('marsa.classes')); return c.activeClassId; });
}
async function addStudents(page, names) {
  await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")'); await page.fill('#add-names', names.join('\n'));
  await page.click('button:has-text("معاينة الأسماء")'); await page.click('button:has-text("تأكيد الإضافة")'); await page.waitForSelector('#dlg-add', { state: 'hidden' });
}
async function toAtt(page) { await page.click('.nav button:has-text("الحضور")'); await page.waitForSelector('#att-date'); }
async function keyOf(page, cid) { return page.evaluate(function (id) { return localStorage.getItem('marsa.academic.attendance.' + id); }, cid); }
async function recs(page, cid) { var raw = await keyOf(page, cid); return raw ? JSON.parse(raw).records : []; }
async function counts(page) { return page.$$eval('.att-counts li', function (l) { var o = {}; l.forEach(function (x) { o[x.className.replace('ac-', '')] = +x.querySelector('b').textContent; }); return o; }); }
async function rowOf(page, name) { return page.locator('.arow[data-student-id]', { has: page.locator('.ar-n', { hasText: name }) }); }
async function pick(page, name, st) { var r = await rowOf(page, name); await r.locator('label.st-' + st).click(); }
async function sid(page, name) { return (await rowOf(page, name)).getAttribute('data-student-id'); }
async function status(page) { return page.textContent('#status'); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function localDay(page, add) { return page.evaluate(function (n) { var m = window.MarsaAttendanceModel; return m.addDays(m.localDate(), n); }, add); }

(async function () {
  var browser = await pw.chromium.launch();
  var ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  var page = await ctx.newPage(); page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.addInitScript(function () {
    window.__reads = []; var g = Storage.prototype.getItem;
    Storage.prototype.getItem = function (k) { if (String(k).indexOf('marsa.academic.attendance.') === 0) window.__reads.push(k); return g.apply(this, arguments); };
  });
  await page.goto(URL); await skip(page);

  // ===== 1) وضع الطالب: لا قراءة لنوع الحضور ولا عرض فردي =====
  await page.evaluate(function () { localStorage.setItem('marsa.academic.attendance.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', records: [{ recordId: 'att_secret', classId: 'cls_demo_001', studentId: 'stu_secret', date: '2026-10-20', status: 'absent', note: 'سرّ-الغياب' }] })); window.__reads.length = 0; });
  var navs = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  for (var i = 0; i < navs.length; i++) { await page.click('.nav button >> nth=' + i); await page.waitForTimeout(60); }
  await page.click('.nav button:has-text("غيابي")');
  var stTxt = await page.textContent('#v-page');
  check('وضع الطالب: صفحة «غيابي» تعرض تنبيه المصادقة', /يحتاج مصادقة/.test(stTxt) && /هوية طالب موثوقة/.test(stTxt), stTxt.slice(0, 200));
  check('وضع الطالب: لا نص «لا يوجد غياب مسجل» المضلّل', !/لا يوجد غياب مسجل/.test(stTxt));
  check('وضع الطالب: لا يظهر سجل الحضور المخزَّن ولا ملاحظته', !/سرّ-الغياب|stu_secret/.test(await page.evaluate(function () { return document.body.textContent; })));
  check('وضع الطالب: لم تُقرأ مفاتيح الحضور من localStorage في كل الصفحات', (await page.evaluate(function () { return window.__reads; })).length === 0, JSON.stringify(await page.evaluate(function () { return window.__reads; })));
  check('وضع الطالب: لا زر ولا قائمة طلاب في صفحة غيابي', (await page.$$('#v-page button.btn, #v-page .arow')).length === 0);
  await page.evaluate(function () { localStorage.removeItem('marsa.academic.attendance.cls_demo_001'); });

  // ===== 2) وضع الممثل: صف جديد وطلاب =====
  await toRep(page);
  var cid = await newClass(page, 'صف-4.03');
  var navRep = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  await toAtt(page);
  check('صفحة الحضور بلا طلاب: حالة فراغ صادقة وزر لقسم الطلاب', /لا يوجد طلاب فعّالون/.test(await page.textContent('#v-page')) && (await page.$$('.arow')).length === 0);
  check('لا زر معطّل «يُفعّل في مرحلة لاحقة» في الحضور', !/يُفعّل في مرحلة لاحقة/.test(await page.textContent('#v-page')));
  await addStudents(page, ['أحمد علي', 'بشرى كريم', 'جاسم محمد', 'ديما سعد']);
  navRep = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  check('شريط التنقل واحد وعدد زر «الحضور» واحد', (await page.$$('.nav')).length === 1 && navRep.filter(function (x) { return x === 'الحضور'; }).length === 1, navRep.join('|'));
  await toAtt(page);
  var codes = await page.evaluate(function (id) { var raw = localStorage.getItem(id === 'cls_demo_001' ? 'marsa.roster' : 'marsa.roster.' + id); return JSON.parse(raw).students.map(function (s) { return [s.name, s.studentCode, s.studentId]; }); }, cid);

  // ===== 3) حالة البداية: لا شيء يتحول إلى حاضر =====
  check('4 صفوف طلاب فعّالين مرتبة أبجدياً ومرقّمة', (await page.$$('.arow[data-student-id]')).length === 4 && (await page.$$eval('.arow .num', function (l) { return l.map(function (x) { return x.textContent; }).join(''); })) === '1234');
  check('لا حالة مختارة عند الفتح (لا radio محدد)', (await page.$$('.arow input:checked')).length === 0);
  check('كل صف يعرض «لم يُسجَّل»', (await page.$$eval('.arow .tag', function (l) { return l.map(function (x) { return x.textContent; }); })).every(function (x) { return x === 'لم يُسجَّل'; }));
  var c0 = await counts(page); check('العدّادات: 4 غير مسجّل والباقي 0', c0.unrecorded === 4 && c0.present + c0.absent + c0.late + c0.excused === 0, JSON.stringify(c0));
  check('فتح الصفحة لا يكتب مفتاح الحضور', (await keyOf(page, cid)) === null);
  check('الحفظ معطّل بلا تغييرات', await page.isDisabled('button:has-text("حفظ الحضور")'));
  check('تاريخ اليوم المحلي افتراضياً وmax = اليوم', (await page.inputValue('#att-date')) === (await localDay(page, 0)) && (await page.getAttribute('#att-date', 'max')) === (await localDay(page, 0)));

  // ===== 4) تسجيل وحفظ =====
  await pick(page, 'أحمد علي', 'present'); await pick(page, 'بشرى كريم', 'absent'); await pick(page, 'جاسم محمد', 'late');
  await (await rowOf(page, 'بشرى كريم')).locator('input[type=text]').fill('سفر عائلي');
  check('قبل الحفظ: لا شيء مكتوب في التخزين ويظهر عدّاد غير المحفوظ', (await keyOf(page, cid)) === null && /تغييرات غير محفوظة: 3/.test(await page.textContent('.att-dirty')), await page.textContent('.att-dirty'));
  check('العدّادات تعتمد المحفوظ فقط (ما زالت 4 غير مسجّل)', (await counts(page)).unrecorded === 4);
  await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  var r1 = await recs(page, cid), ids = {}; r1.forEach(function (r) { ids[r.studentId] = r.recordId; });
  check('حُفظ 3 سجلات فقط (ديما بلا قرار = بلا سجل)', r1.length === 3 && !r1.some(function (r) { return r.studentId === codes[3][2]; }), JSON.stringify(r1.map(function (r) { return r.status; })));
  check('كل سجل: recordId بادئة att_ وclassId مطابق وstudentId ثابت وتاريخ محلي', r1.every(function (r) { return /^att_/.test(r.recordId) && r.classId === cid && /^[A-Za-z0-9_-]+$/.test(r.studentId) && r.date === r1[0].date; }));
  check('الملاحظة محفوظة والحالات صحيحة', r1.filter(function (r) { return r.status === 'absent'; })[0].note === 'سفر عائلي' && r1.map(function (r) { return r.status; }).sort().join() === 'absent,late,present');
  check('رسالة نجاح بعد الحفظ الفعلي', /تم حفظ الحضور/.test(await status(page)), await status(page));
  var c1 = await counts(page); check('العدّادات بعد الحفظ: حاضر1 غائب1 متأخر1 بعذر0 غير مسجّل1', c1.present === 1 && c1.absent === 1 && c1.late === 1 && c1.excused === 0 && c1.unrecorded === 1, JSON.stringify(c1));
  check('ديما ما زالت «لم يُسجَّل» (لم تتحول إلى حاضر)', /لم يُسجَّل/.test(await (await rowOf(page, 'ديما سعد')).locator('.tag').textContent()));
  check('زر الحفظ معطّل بعد الحفظ ولا نص غير محفوظ', await page.isDisabled('button:has-text("حفظ الحضور")') && (await page.textContent('.att-dirty')) === '');

  // ===== 5) التعديل يحفظ recordId ولا يكرّر =====
  await pick(page, 'أحمد علي', 'excused'); await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  var r2 = await recs(page, cid);
  check('التعديل: ما زالت 3 سجلات (بلا تكرار) وrecordId أحمد كما هو والحالة بعذر', r2.length === 3 && r2.filter(function (r) { return r.studentId === codes[0][2]; })[0].recordId === ids[codes[0][2]] && r2.filter(function (r) { return r.studentId === codes[0][2]; })[0].status === 'excused');
  check('createdAt ثابت وupdatedAt حُدّث', (function () { var a = r1.filter(function (r) { return r.studentId === codes[0][2]; })[0], b = r2.filter(function (r) { return r.studentId === codes[0][2]; })[0]; return a.createdAt === b.createdAt && b.updatedAt >= a.updatedAt; })());

  // ===== 6) إجراء جماعي صريح وقابل للتراجع =====
  await page.click('button:has-text("تحديد غير المسجّلين حاضرين")');
  var dChecked = await (await rowOf(page, 'ديما سعد')).locator('input[value=present]').isChecked();
  check('الإجراء الجماعي يحدّد غير المسجّلين فقط (ديما) ولا يغيّر المحفوظين', dChecked && await (await rowOf(page, 'بشرى كريم')).locator('input[value=absent]').isChecked() && await (await rowOf(page, 'أحمد علي')).locator('input[value=excused]').isChecked());
  check('الإجراء الجماعي لا يحفظ قبل الضغط على حفظ', (await recs(page, cid)).length === 3);
  await page.click('button:has-text("تراجع عن التحديد الجماعي")');
  check('التراجع يعيد ديما بلا حالة ويُخفي زر التراجع', !(await (await rowOf(page, 'ديما سعد')).locator('input[value=present]').isChecked()) && (await page.$$('button:has-text("تراجع عن التحديد الجماعي"):not([hidden])')).length === 0);
  await page.click('button:has-text("تحديد غير المسجّلين حاضرين")'); await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  check('بعد الحفظ الجماعي: 4 سجلات ولا تكرار ولا تغيير في الآخرين', (await recs(page, cid)).length === 4 && (await counts(page)).present === 1 + 0 && (await counts(page)).unrecorded === 0, JSON.stringify(await counts(page)));

  // ===== 7) تاريخ سابق + مستقبلي =====
  var yest = await localDay(page, -1), tom = await localDay(page, 1);
  await page.fill('#att-date', yest); await page.waitForTimeout(80);
  check('تاريخ سابق: الصفوف بلا سجلات (غير مسجّل 4) ولا تأثير على اليوم', (await counts(page)).unrecorded === 4 && (await page.inputValue('#att-date')) === yest);
  await pick(page, 'جاسم محمد', 'absent');
  await page.fill('#att-date', tom); await page.waitForTimeout(80);
  check('تاريخ مستقبلي مرفوض برسالة قرب الحقل ويبقى التاريخ ولا يضيع التحديد', /بعد اليوم/.test(await page.textContent('#att-date-e')) && (await page.inputValue('#att-date')) === yest && await (await rowOf(page, 'جاسم محمد')).locator('input[value=absent]').isChecked() && (await page.getAttribute('#att-date', 'aria-invalid')) === 'true');
  check('زر «اليوم التالي» معطّل عند اليوم لكنه يعمل من أمس', await page.isEnabled('button:has-text("اليوم التالي")'));
  await page.fill('#att-date', await localDay(page, 0)); await page.waitForTimeout(80);
  check('تغيير التاريخ مع مسودة: نافذة تأكيد تجاهل', await page.isVisible('#dlg-confirm') && /تجاهل التغييرات/.test(await page.textContent('#dlg-confirm')));
  await page.click('#dlg-confirm button:has-text("إلغاء")'); await page.waitForTimeout(60);
  check('الإلغاء: يبقى التاريخ السابق والمسودة', (await page.inputValue('#att-date')) === yest && await (await rowOf(page, 'جاسم محمد')).locator('input[value=absent]').isChecked());
  await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  var r3 = await recs(page, cid);
  check('حفظ سجل أمس: 5 سجلات، ويوم اليوم لم يتأثر', r3.length === 5 && r3.filter(function (r) { return r.date === yest; }).length === 1 && r3.filter(function (r) { return r.date !== yest; }).length === 4);
  await page.click('.att-date button:text-is("اليوم")'); await page.waitForTimeout(80);
  check('زر «اليوم» يعيد تاريخ اليوم بلا نافذة (لا مسودة)', (await page.inputValue('#att-date')) === await localDay(page, 0) && !(await page.isVisible('#dlg-confirm')));

  // ===== 8) سجل الأيام + البحث والفلاتر =====
  var hist = await page.$$eval('.att-days .adr', function (l) { return l.map(function (x) { return x.textContent; }); });
  check('سجل الأيام: يومان بالأحدث أولاً وعدّادات صحيحة', hist.length === 2 && /حاضر 1 · غائب 1 · متأخر 1 · بعذر 1/.test(hist[0]) && /غائب 1/.test(hist[1]) && hist[0].indexOf((await localDay(page, 0)).split('-').reverse().join('/')) > -1, JSON.stringify(hist));
  await page.selectOption('#ah-st', 'absent'); await page.waitForTimeout(60);
  check('فلتر الحالة في سجل الأيام: يومان فيهما غياب', (await page.$$('.att-days .adr')).length === 2);
  await page.selectOption('#ah-st', 'late'); await page.waitForTimeout(60);
  check('فلتر «متأخر»: يوم واحد (بلا تأخير في أمس)', (await page.$$('.att-days .adr')).length === 1);
  await page.selectOption('#ah-st', 'all'); await page.fill('#ah-from', await localDay(page, 0)); await page.waitForTimeout(60);
  check('فلتر من تاريخ: يوم واحد', (await page.$$('.att-days .adr')).length === 1);
  await page.fill('#ah-from', ''); await page.click('.att-days .adr:last-child button'); await page.waitForTimeout(80);
  check('«فتح هذا اليوم» ينقل إلى ذلك اليوم', (await page.inputValue('#att-date')) === yest);
  await page.click('.att-date button:text-is("اليوم")'); await page.waitForTimeout(80);
  await page.fill('.att-filters input[type=search]', 'بشرى'); await page.waitForTimeout(60);
  check('البحث بالاسم', (await page.$$('.arow[data-student-id]')).length === 1);
  await page.fill('.att-filters input[type=search]', codes[2][1].toLowerCase()); await page.waitForTimeout(60);
  check('البحث بالكود (غير حساس لحالة الأحرف)', (await page.$$eval('.arow .ar-n', function (l) { return l.map(function (x) { return x.textContent; }); })).join() === 'جاسم محمد');
  await page.fill('.att-filters input[type=search]', 'zzz-لا-أحد'); await page.waitForTimeout(60);
  check('بحث بلا نتائج: رسالة صريحة', /لا يوجد طلاب مطابقون/.test(await page.textContent('.att-sheet')));
  await page.fill('.att-filters input[type=search]', ''); await page.selectOption('.att-filters select', 'late'); await page.waitForTimeout(60);
  check('فلتر الحالة في اليوم: متأخر فقط', (await page.$$('.arow[data-student-id]')).length === 1);
  await page.selectOption('.att-filters select', 'all');

  // ===== 9) الحذف بتأكيد =====
  var row = await rowOf(page, 'بشرى كريم');
  await row.locator('button:has-text("حذف السجل")').click();
  var ct = await page.textContent('#dlg-confirm');
  check('نافذة الحذف تذكر الطالب والتاريخ والحالة', /بشرى كريم/.test(ct) && /غائب/.test(ct) && ct.indexOf((await localDay(page, 0)).split('-').reverse().join('/')) > -1, ct);
  await page.click('#dlg-confirm button:has-text("إلغاء")'); check('إلغاء الحذف يُبقي السجل', (await recs(page, cid)).length === 5);
  await row.locator('button:has-text("حذف السجل")').click(); await page.click('#dlg-confirm button:has-text("حذف السجل")'); await page.waitForTimeout(150);
  check('الحذف الفعلي: 4 سجلات وبشرى «لم يُسجَّل» ورسالة نجاح بعد الحذف', (await recs(page, cid)).length === 4 && /لم يُسجَّل/.test(await (await rowOf(page, 'بشرى كريم')).locator('.tag').textContent()) && /تم حذف/.test(await status(page)));

  // ===== 10) طالب مؤرشف =====
  await page.click('.nav button:has-text("الطلاب")'); await page.locator('li.stu', { hasText: 'جاسم محمد' }).locator('button:has-text("أرشفة الطالب")').click();
  await page.click('#dlg-confirm button:has-text("أرشفة الطالب")'); await page.waitForTimeout(100);
  await toAtt(page);
  check('المؤرشف لا يظهر بين الطلاب الفعّالين (3 صفوف) ولا يمكن تسجيله', (await page.$$('.arow[data-student-id]')).length === 3 && (await page.$$eval('.arow[data-student-id] .ar-n', function (l) { return l.map(function (x) { return x.textContent; }); })).indexOf('جاسم محمد') < 0);
  var leg = await page.textContent('.att-sheet');
  check('سجله القديم يُقرأ في قسم منفصل بتسمية «مؤرشف» بلا radio', /سجلات طلاب غير فعّالين/.test(leg) && /جاسم محمد/.test(await page.textContent('.att-legacy')) && /مؤرشف/.test(await page.textContent('.att-legacy')) && (await page.$$('.att-legacy input')).length === 0);
  var c2 = await counts(page); check('العدّادات لا تخلط المؤرشف: المجموع 3 (حاضر2 متأخر0 غير مسجّل1)', c2.present + c2.absent + c2.late + c2.excused + c2.unrecorded === 3 && c2.late === 0, JSON.stringify(c2));
  check('سجل المؤرشف لم يُحذف من التخزين', (await recs(page, cid)).some(function (r) { return r.studentId === codes[2][2]; }));

  // ===== 11) فشل التخزين =====
  await page.evaluate(function () { window.__sset = Storage.prototype.setItem; Storage.prototype.setItem = function (k) { if (String(k).indexOf('marsa.academic.attendance.') === 0) throw new Error('QuotaExceededError'); return window.__sset.apply(this, arguments); }; });
  var before = await keyOf(page, cid);
  await pick(page, 'بشرى كريم', 'present'); await (await rowOf(page, 'بشرى كريم')).locator('input[type=text]').fill('ملاحظة-لا-تضيع');
  await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  var errTxt = await page.textContent('.att-sheet .err[role=alert]');
  check('فشل التخزين: رسالة «لم يُحفظ» واضحة ولا رسالة نجاح', /لم يُحفظ/.test(errTxt) && !/تم حفظ الحضور/.test(await status(page)), errTxt);
  check('فشل التخزين: التخزين لم يتغيّر والنموذج لم يُفرَّغ (الاختيار والملاحظة باقيان)', (await keyOf(page, cid)) === before && await (await rowOf(page, 'بشرى كريم')).locator('input[value=present]').isChecked() && (await (await rowOf(page, 'بشرى كريم')).locator('input[type=text]').inputValue()) === 'ملاحظة-لا-تضيع');
  check('فشل التخزين: زر الحفظ يعود مفعّلاً للمحاولة', await page.isEnabled('button:has-text("حفظ الحضور")'));
  await page.evaluate(function () { Storage.prototype.setItem = window.__sset; });
  await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  check('بعد زوال العطل: الحفظ ينجح بنفس المسودة', /تم حفظ الحضور/.test(await status(page)) && (await recs(page, cid)).filter(function (r) { return r.studentId === codes[1][2] && r.note === 'ملاحظة-لا-تضيع'; }).length === 1);

  // ===== 12) حارس المغادرة =====
  await pick(page, 'ديما سعد', 'late');
  await page.click('.nav button:has-text("اللوحة")'); await page.waitForTimeout(80);
  check('مغادرة الصفحة بمسودة: نافذة تأكيد ولا انتقال قبل القرار', await page.isVisible('#dlg-confirm') && (await page.$$('#att-date')).length === 1);
  await page.click('#dlg-confirm button:has-text("إلغاء")'); check('الإلغاء يبقي المسودة', await (await rowOf(page, 'ديما سعد')).locator('input[value=late]').isChecked());
  await page.click('.nav button:has-text("اللوحة")'); await page.click('#dlg-confirm button:has-text("تجاهل والمتابعة")'); await page.waitForTimeout(80);
  check('التجاهل ينقل بلا حفظ', (await page.$$('#att-date')).length === 0 && !(await recs(page, cid)).some(function (r) { return r.studentId === codes[3][2] && r.status === 'late'; }));

  // ===== 13) عزل الصفوف =====
  var cid2 = await newClass(page, 'صف-4.03-ب');
  await addStudents(page, ['أحمد علي', 'زينب حسن']); await toAtt(page);
  check('صف جديد: بلا سجلات من الصف الأول (غير مسجّل = عدد طلابه)', (await counts(page)).unrecorded === 2 && (await counts(page)).present === 0);
  await pick(page, 'أحمد علي', 'present'); await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  var a1 = await recs(page, cid), a2 = await recs(page, cid2);
  check('مفتاحان منفصلان: الصف الثاني بسجل واحد والأول بقي 4 بلا تلوّث', a2.length === 1 && a2[0].classId === cid2 && a1.length === 5 && a1.every(function (r) { return r.classId === cid; }) && a2[0].studentId !== a1[0].studentId);

  // ===== 14) بيانات تالفة =====
  await page.evaluate(function (id) { localStorage.setItem('marsa.academic.attendance.' + id, '{bad json'); }, cid2);
  await page.click('.nav button:has-text("اللوحة")'); await toAtt(page);
  check('بيانات تالفة: رسالة تلف ولا قائمة طلاب فارغة مضلّلة ولا كتابة فوقها', /تالفة/.test(await page.textContent('.notice.warnbox')) && (await page.$$('.arow')).length === 0 && (await keyOf(page, cid2)) === '{bad json');
  check('بيانات تالفة: الحفظ والتحديد الجماعي معطّلان', await page.isDisabled('button:has-text("حفظ الحضور")') && await page.isDisabled('button:has-text("تحديد غير المسجّلين حاضرين")'));
  check('نسخة خام احتياطية أُنشئت', await page.evaluate(function (id) { return Object.keys(localStorage).some(function (k) { return k.indexOf('marsa.academic.attendance.' + id + '.backup') === 0; }); }, cid2));
  await page.evaluate(function (id) { localStorage.removeItem('marsa.academic.attendance.' + id); }, cid2);

  // ===== 15) تكرار مخزَّن قديماً =====
  var s0 = a1[0];
  await page.evaluate(function (a) { var d = { schemaVersion: 1, classId: a.cid, records: a.recs.concat([Object.assign({}, a.recs[0], { recordId: 'att_dupe_x', status: 'absent' })]) }; localStorage.setItem('marsa.academic.attendance.' + a.cid, JSON.stringify(d)); }, { cid: cid, recs: a1 });
  var dupRaw = await keyOf(page, cid);
  await page.evaluate(function (id) { var s = window.MarsaAcademicStore; }, cid);
  await page.click('.nav button:has-text("الطلاب")'); await page.evaluate(function (id) { var raw = localStorage.getItem('marsa.classes'); var c = JSON.parse(raw); c.activeClassId = id; localStorage.setItem('marsa.classes', raw); }, cid);
  await page.reload(); await skip(page); await toRep(page); await page.evaluate(function (id) { }, cid);
  var ac = await page.evaluate(function () { return JSON.parse(localStorage.getItem('marsa.classes')).activeClassId; });
  if (ac !== cid) { await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")'); await page.locator('.cls', { hasText: 'صف-4.03' }).first().locator('button:has-text("اختيار كصف نشط")').click().catch(function () { }); }
  await toAtt(page);
  check('تكرار قديم: يُحجب بوضوح (لا يُطمس ولا يُعرض فارغاً) ولم يتغيّر التخزين', /مكرر|تالفة|غير صالحة/.test(await page.textContent('.notice.warnbox')) && (await page.$$('.arow')).length === 0 && (await keyOf(page, cid)) === dupRaw, (await page.textContent('#v-page')).slice(0, 300));

  // ===== 16) تخطيط الهاتف والوصول =====
  await page.evaluate(function (a) { localStorage.setItem('marsa.academic.attendance.' + a.cid, JSON.stringify({ schemaVersion: 1, classId: a.cid, records: a.recs })); }, { cid: cid, recs: a1 });
  await page.reload(); await skip(page); await toRep(page); await toAtt(page);
  check('الصف النشط بعد إعادة التحميل ما زال صالحاً وبه صفوف', (await page.$$('.arow[data-student-id]')).length >= 1);
  for (var wv = 0; wv < 3; wv++) {
    var w = [320, 360, 412][wv]; await page.setViewportSize({ width: w, height: 780 }); await page.waitForTimeout(80);
    check('بلا تمرير أفقي عند ' + w + 'px', !(await overflow(page)));
  }
  await page.setViewportSize({ width: 390, height: 780 });
  var small = await page.$$eval('.ar-o, .att-sheet button, .att-sheet input.field, .att-sheet select', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + (e.textContent || e.getAttribute('aria-label') || e.type) + ':' + Math.round(e.getBoundingClientRect().height); }); });
  check('أهداف اللمس ≥ 44px', small.length === 0, small.join(' | '));
  var a11y = await page.evaluate(function () {
    var fs = Array.prototype.slice.call(document.querySelectorAll('.arow[data-student-id] fieldset')), bad = [];
    fs.forEach(function (f) { var lg = f.querySelector('legend'); var radios = f.querySelectorAll('input[type=radio]'); if (!lg || !lg.textContent.trim() || radios.length !== 4) bad.push('fieldset'); var nm = {}; radios.forEach(function (r) { nm[r.name] = 1; }); if (Object.keys(nm).length !== 1) bad.push('name'); });
    var unl = Array.prototype.slice.call(document.querySelectorAll('.att-sheet input:not([type=radio]), .att-sheet select, .att-hist input, .att-hist select')).filter(function (i) { return !(i.getAttribute('aria-label') || (i.id && document.querySelector('label[for="' + i.id + '"]'))); }).length;
    return { bad: bad, unlabeled: unl, n: fs.length };
  });
  check('كل صف: fieldset+legend وأربعة radio باسم واحد؛ وكل حقل له تسمية', a11y.bad.length === 0 && a11y.unlabeled === 0 && a11y.n > 0, JSON.stringify(a11y));
  var firstRadio = (await page.$$('.arow input[type=radio]'))[0]; await firstRadio.focus(); await page.keyboard.press('Space'); await page.keyboard.press('ArrowLeft');
  check('لوحة المفاتيح: radio قابل للتحديد (Space/أسهم)', (await page.$$('.arow input:checked')).length >= 1);
  check('حالة المختار لا تعتمد على اللون وحده (حرف ✓ عبر ::before)', await page.evaluate(function () { var el = document.querySelector('.ar-o:has(input:checked) span'); return !!el && getComputedStyle(el, '::before').content.indexOf('\u2713') > -1; }));

  // ===== 17) دلالات XSS: النص المدخل بـ textContent =====
  await page.evaluate(function (a) { var d = { schemaVersion: 1, classId: a.cid, records: a.recs.slice(0, 1).map(function (r) { return Object.assign({}, r, { note: '<img src=x onerror="window.__xss=1">' }); }) }; localStorage.setItem('marsa.academic.attendance.' + a.cid, JSON.stringify(d)); }, { cid: cid, recs: a1 });
  await page.reload(); await skip(page); await toRep(page); await toAtt(page); await page.waitForTimeout(100);
  check('ملاحظة تحوي HTML تُعرض نصاً ولا تُنفَّذ', (await page.evaluate(function () { return window.__xss; })) === undefined && (await page.$$('.att-sheet img')).length === 0);

  check('لا أخطاء JavaScript في الصفحة', jsErrors.length === 0, jsErrors.join(' | '));
  await browser.close();
  var pass = results.filter(function (r) { return r.ok; }).length, fail = results.length - pass;
  console.log('\n' + pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
})().catch(function (e) { console.log('FATAL', e && e.stack || e); process.exit(2); });
