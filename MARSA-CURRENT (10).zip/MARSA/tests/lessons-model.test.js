// تشغيل: node tests/lessons-model.test.js  (لا يحتاج مكتبات)
var assert = require('assert'), cp = require('child_process'), path = require('path');
var M = require('../js/lessons-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake() { var d = {}; return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { d[k] = String(v); }, removeItem: function (k) { delete d[k]; } }; }
var ok = { subject: 'مادة', title: 'درس', date: '2026-10-21' };
function v(o, today) { var x = {}, k; for (k in ok) x[k] = ok[k]; for (k in o) x[k] = o[k]; return M.validate(x, { today: today || '2026-10-22' }); }

t('required fields only: subject, title, date', function () {
  assert.ok(v({}).ok);
  assert.ok(v({ subject: '' }).errors.subject); assert.ok(v({ title: '' }).errors.title); assert.ok(v({ date: '' }).errors.date);
});
t('whitespace-only and invisible-only are empty', function () {
  assert.ok(v({ subject: '   \n\t ' }).errors.subject);
  assert.ok(v({ title: '\u200B\u200F\u202E ' }).errors.title);
});
t('one-line fields collapse spaces/newlines; multiline keeps newlines', function () {
  var r = v({ subject: '  رياضيات \n  ٢ ', summary: 'سطر1\r\n\r\n\r\n\r\nسطر2  ' });
  assert.strictEqual(r.values.subject, 'رياضيات ٢'); assert.strictEqual(r.values.summary, 'سطر1\n\nسطر2');
});
t('length limits are enforced per field', function () {
  var L = M.LIMITS, k;
  for (k in L) { var o = {}; o[k] = new Array(L[k] + 2).join('ا'); assert.ok(v(o).errors[k], k + ' too long accepted'); o[k] = new Array(L[k] + 1).join('ا'); assert.ok(!v(o).errors[k], k + ' at limit rejected'); }
});
t('date validation: format, real calendar day, range', function () {
  assert.ok(v({ date: '2026-02-30' }).errors.date); assert.ok(v({ date: '21-10-2026' }).errors.date); assert.ok(v({ date: '1999-12-31' }).errors.date); assert.ok(v({ date: '2101-01-01' }).errors.date);
  assert.ok(!v({ date: '2000-01-01' }).errors.date); assert.ok(!v({ date: '2100-12-31' }).errors.date); assert.ok(!v({ date: '2028-02-29' }).errors.date);
});
t('future date flagged (not an error), today/past are not', function () {
  assert.strictEqual(v({ date: '2026-10-23' }, '2026-10-22').future, true); assert.ok(v({ date: '2026-10-23' }, '2026-10-22').ok);
  assert.strictEqual(v({ date: '2026-10-22' }, '2026-10-22').future, false); assert.strictEqual(v({ date: '2026-10-01' }, '2026-10-22').future, false);
});
t('firstError follows field order', function () { var r = v({ subject: '', date: 'x' }); assert.strictEqual(r.firstError, 'subject'); });
t('markup stays plain text (no stripping/execution, kept verbatim)', function () {
  var r = v({ title: '<img src=x onerror=alert(1)>' }); assert.ok(r.ok); assert.strictEqual(r.values.title, '<img src=x onerror=alert(1)>');
});
t('buildRecord: optional empties removed, existing id/class/createdAt/extra kept, never creates recordId', function () {
  var base = M.validate(ok, { today: '2026-10-22' }).values, r = M.buildRecord(base, null);
  assert.ok(!('recordId' in r) && !('summary' in r) && !('pages' in r));
  var ex = { recordId: 'dl_1', classId: 'cls_a', createdAt: 'T0', summary: 'قديم', extra: 7, subject: 'x', title: 'y', date: '2026-01-01' };
  var vals = M.validate({ subject: 'م', title: 'ع', date: '2026-10-21', pages: 'ص5' }, { today: '2026-10-22' }).values, e = M.buildRecord(vals, ex);
  assert.strictEqual(e.recordId, 'dl_1'); assert.strictEqual(e.classId, 'cls_a'); assert.strictEqual(e.createdAt, 'T0'); assert.strictEqual(e.extra, 7);
  assert.ok(!('summary' in e)); assert.strictEqual(e.pages, 'ص5'); assert.strictEqual(ex.summary, 'قديم');
});
t('sort: newest date first, then newest created, stable on bad data', function () {
  var l = [{ recordId: 'a', date: '2026-10-01', createdAt: '1' }, { recordId: 'b', date: '2026-10-21', createdAt: '1' }, { recordId: 'c', date: '2026-10-21', createdAt: '2' }, { recordId: 'd' }, { recordId: 'e', date: 5 }];
  assert.deepStrictEqual(M.sortRecords(l).map(function (x) { return x.recordId; }), ['c', 'b', 'a', 'e', 'd']);
  assert.strictEqual(l[0].recordId, 'a');
});
t('search by title or subject, hamza/taa-marbuta/diacritics insensitive; not by other fields', function () {
  var l = [{ recordId: '1', subject: 'الحاسوب', title: 'الذاكرة العشوائية', summary: 'سرّي' }, { recordId: '2', subject: 'رياضيات', title: 'المعادلات' }];
  assert.strictEqual(M.filterRecords(l, 'ذاكره').length, 1); assert.strictEqual(M.filterRecords(l, 'رياضيّات').length, 1);
  assert.strictEqual(M.filterRecords(l, 'سري').length, 0); assert.strictEqual(M.filterRecords(l, '').length, 2); assert.strictEqual(M.filterRecords(l, '<b>').length, 0);
});
t('subjectsOf lists only what the user wrote (no fixed list)', function () {
  assert.deepStrictEqual(M.subjectsOf([]), []);
  assert.deepStrictEqual(M.subjectsOf([{ subject: 'علوم', date: '2026-01-01' }, { subject: 'علوم ', date: '2026-02-01' }, { subject: 'فيزياء', date: '2026-03-01' }]), ['فيزياء', 'علوم']);
});
t('formatDate never throws on bad input', function () {
  assert.strictEqual(M.formatDate(''), 'بلا تاريخ'); assert.strictEqual(M.formatDate(undefined), 'بلا تاريخ'); assert.strictEqual(M.formatDate('2026-02-30'), '2026-02-30');
});
t('integration with store: add → edit keeps recordId → delete; classes stay separate', function () {
  var s = S.create({ storage: fake() }), a, id, b;
  a = s.upsertRecord('dailyLessons', 'cls_a', M.buildRecord(M.validate(ok, { today: '2026-10-22' }).values, null));
  assert.ok(a.ok && a.created); id = a.record.recordId;
  b = s.upsertRecord('dailyLessons', 'cls_a', M.buildRecord(M.validate({ subject: 'م2', title: 'ع2', date: '2026-10-20' }, { today: '2026-10-22' }).values, s.getRecord('dailyLessons', 'cls_a', id).record));
  assert.ok(b.ok && !b.created && b.record.recordId === id && b.record.createdAt === a.record.createdAt);
  assert.strictEqual(s.readCollection('dailyLessons', 'cls_b').records.length, 0);
  s.upsertRecord('dailyLessons', 'cls_b', M.buildRecord(M.validate(ok, { today: '2026-10-22' }).values, null));
  assert.strictEqual(s.readCollection('dailyLessons', 'cls_a').records.length, 1); assert.strictEqual(s.readCollection('dailyLessons', 'cls_b').records.length, 1);
  assert.ok(s.deleteRecord('dailyLessons', 'cls_a', id).ok); assert.strictEqual(s.readCollection('dailyLessons', 'cls_b').records.length, 1);
});

// المنطقة الزمنية: التاريخ المحلي لا ينقلب يوماً بسبب UTC في أي منطقة (عملية فرعية لكل TZ)
['Asia/Baghdad', 'UTC', 'America/Los_Angeles', 'Pacific/Kiritimati', 'Pacific/Pago_Pago'].forEach(function (tz) {
  t('timezone ' + tz + ': toLocalDate and formatDate keep the local day', function () {
    var code = "var S=require('./js/academic-store.js'),M=require('./js/lessons-model.js'),r=[];" +
      "r.push(S.toLocalDate(new Date(2026,9,21,0,30)),S.toLocalDate(new Date(2026,9,21,23,59)),S.toLocalDate(new Date(2026,0,1,0,0)));" +
      "var s=M.formatDate('2026-10-21'),e=M.formatDate('2026-01-01');" +
      "r.push(/21/.test(s)?'d21':'bad:'+s, /\\b1\\b/.test(e)||/(?:^|\\D)1(?:\\D|$)/.test(e)?'d1':'bad:'+e);console.log(JSON.stringify(r));";
    var out = cp.execFileSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: Object.assign({}, process.env, { TZ: tz }) }).toString().trim();
    assert.strictEqual(out, JSON.stringify(['2026-10-21', '2026-10-21', '2026-01-01', 'd21', 'd1']), tz + ' -> ' + out);
  });
});
console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
