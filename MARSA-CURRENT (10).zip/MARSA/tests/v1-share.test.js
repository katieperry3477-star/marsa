// تشغيل: node tests/v1-share.test.js  (لا يحتاج مكتبات)
// يختبر كود المشاركة الذاتي المحتوى (js/v1-share.js): الترميز، فك الضغط المحلي، النقص والتلف والتزوير، ولصق رسالة واتساب.
var assert = require('assert'), zlib = require('zlib'), fs = require('fs'), path = require('path');
var S = require('../js/v1-share.js'), M = require('../js/preps-model.js');
var n = 0, f = 0;
function run(tasks) { // تسلسلي ليبقى ترتيب الطباعة ثابتاً
  var p = Promise.resolve();
  tasks.forEach(function (x) { p = p.then(x); });
  return p;
}
var tests = [];
function T(name, fn) { tests.push(function () { return Promise.resolve().then(fn).then(function () { n++; console.log('PASS', name); }, function (e) { f++; console.log('FAIL', name, '-', e && e.message); }); }); }

var UTF = new TextEncoder();
function base() { return { id: 'p4k2m9x7q1ab', subject: 'اللغة العربية', title: 'درس الحال', date: '2026-10-28', content: 'الحال وصف هيئة الفاعل أو المفعول.\nمثال: جاء الطالب مسرعاً.', updatedAt: 1780000000000 }; }
function mk(o) { var p = base(), k; for (k in o) p[k] = o[k]; return p; }
function enc(p, o) { return S.encode(p, o); }
// يبني كوداً يدوياً (طريقة 0) من كائن حمولة خام لاختبار التزوير
function forge(payload, opts) {
  opts = opts || {};
  var raw = UTF.encode(typeof payload === 'string' ? payload : JSON.stringify(payload)), crc = opts.crc !== undefined ? opts.crc : S.crc32(raw), head = [0, (raw.length >>> 16) & 255, (raw.length >>> 8) & 255, raw.length & 255, (crc >>> 24) & 255, (crc >>> 16) & 255, (crc >>> 8) & 255, crc & 255], all = new Uint8Array(8 + raw.length), i;
  for (i = 0; i < 8; i++) all[i] = head[i];
  all.set(raw, 8);
  return 'MARSA1-' + S.b64encode(all);
}
function good(extra) { var o = { v: 1, i: 'p4k2m9x7q1ab', s: 'مادة', t: 'عنوان', d: '2026-10-28', c: 'نص', u: 1780000000000 }, k; for (k in extra) { if (extra[k] === undefined) delete o[k]; else o[k] = extra[k]; } return o; }
// نص عربي شبه طبيعي حتمي (للأحجام الواقعية)
var WORDS = 'الحال الفاعل المفعول الجملة الاسمية الفعلية المبتدأ الخبر الدرس الطالب المعلم الكتاب الصفحة التمرين الواجب المثال القاعدة الإعراب منصوب مرفوع مجرور علامة الفتحة الضمة الكسرة جاء ذهب كتب قرأ سمع فهم حفظ راجع حل أجب اشرح استخرج اذكر وضح قارن علل بين ما هو الذي التي في من إلى على عن مع بعد قبل حيث كيف لماذا متى أين نوع حالة صفة موصوف نعت تابع عطف توكيد بدل مضاف إليه جار ومجرور'.split(' ');
function arabicText(len, seed) {
  var s = seed || 12345, out = '', w;
  function rnd() { s = (s * 1103515245 + 12345) & 0x7fffffff; return s; }
  while (out.length < len) { w = WORDS[rnd() % WORDS.length]; out += (out ? (rnd() % 13 === 0 ? '.\n' : ' ') : '') + w; }
  return out.slice(0, len).trim();
}

// ===== الأساسيات =====
T('round trip: عربي + رموز تعبيرية + أسطر + رابط ⇒ نفس الحقول حرفياً', function () {
  var p = mk({ title: 'درس الحال 😀', content: 'سطر ١ 🏃‍♂️ ✅\n\nسطر ٢ https://example.com/a?b=1&c=2\nمحتوى «بين علامتين» و "مزدوجة" و \'مفردة\' \\ / <b>x</b>', homework: 'حل ص ١٢ 📚', pages: 'ص 10-12', notes: 'ملاحظة', group: 'الخامس العلمي — ب' });
  return enc(p).then(function (r) {
    var d = S.decode(r.code), k;
    assert.ok(d.ok, d.message);
    for (k in p) assert.strictEqual(d.prep[k], p[k], k);
    assert.ok(/^MARSA1-[A-Za-z0-9+\/]+$/.test(r.code), 'أبجدية آمنة بلا _ * ~ `');
  });
});
T('رموز تعبيرية بسيطة ومركّبة (ZWJ وألوان البشرة والأعلام) تعود كما هي بالضبط', function () {
  var txt = 'أ 😀 😍 👍🏽 ✅ ❤️ 🇮🇶 📚 𝒜 😀😀😀 🏃‍♂️ 👨‍👩‍👧‍👦 ❤️‍🔥 🏳️‍🌈 🧑🏽‍💻';
  return enc(mk({ content: txt })).then(function (r) { var d = S.decode(r.code); assert.ok(d.ok); assert.strictEqual(d.prep.content, txt); });
});
T('الحقول الاختيارية الفارغة لا تدخل الكود ولا تعود', function () {
  return enc(base()).then(function (r) {
    var d = S.decode(r.code); assert.ok(d.ok);
    ['pages', 'homework', 'notes', 'group'].forEach(function (k) { assert.ok(!(k in d.prep), k); });
    assert.ok(S.toPayload(base()).indexOf('"p"') < 0 && S.toPayload(base()).indexOf('"g"') < 0);
  });
});
T('الترميز حتمي: نفس التحضير ⇒ نفس الكود حرفياً (يُعاد إرساله كما هو)', function () {
  return Promise.all([enc(mk({ homework: 'ح' })), enc(mk({ homework: 'ح' }))]).then(function (a) { assert.strictEqual(a[0].code, a[1].code); });
});
T('تعديل أي حقل أو updatedAt ⇒ كود مختلف', function () {
  return Promise.all([enc(base()), enc(mk({ title: 'عنوان آخر' })), enc(mk({ updatedAt: 1780000000001 }))]).then(function (a) { assert.notStrictEqual(a[0].code, a[1].code); assert.notStrictEqual(a[0].code, a[2].code); });
});
T('أقصى الحدود: كل حقل بطوله الأقصى (عربي) يمرّ ويعود سليماً', function () {
  var L = M.LIMITS, p = mk({ subject: arabicText(L.subject, 1).slice(0, L.subject), title: arabicText(L.title, 2).slice(0, L.title), content: arabicText(L.content, 3).slice(0, L.content), pages: arabicText(L.pages, 4).slice(0, L.pages), homework: arabicText(L.homework, 5).slice(0, L.homework), notes: arabicText(L.notes, 6).slice(0, L.notes), group: arabicText(60, 7).slice(0, 60) });
  return enc(p).then(function (r) {
    var d = S.decode(r.code); assert.ok(d.ok, d.message);
    assert.strictEqual(d.prep.content, M.validate({ subject: 'a', title: 'a', date: p.date, content: p.content }).values.content);
    console.log('   • أقصى تحضير (كل الحقول بحدودها): ' + r.rawBytes + ' بايت ← كود ' + r.codeLength + ' حرفاً (طريقة ' + r.method + ')');
    assert.ok(r.codeLength < 8000);
  });
});
T('الضغط يصغّر الكود فعلاً (عربي شبه طبيعي) ولا يُدّعى بلا دليل: نقارن بالنسخة غير المضغوطة', function () {
  var rows = [];
  return [200, 1000, 2000].reduce(function (pr, len) {
    return pr.then(function () {
      var p = mk({ content: arabicText(len, len) });
      return Promise.all([enc(p), enc(p, { deflate: function () { return null; } })]).then(function (a) {
        assert.strictEqual(a[0].method, 1); assert.strictEqual(a[1].method, 0);
        assert.ok(a[0].codeLength < a[1].codeLength, 'المضغوط أقصر');
        rows.push(len + ' حرفاً عربياً: مضغوط ' + a[0].codeLength + ' / بلا ضغط ' + a[1].codeLength + ' (' + Math.round(100 * a[0].codeLength / a[1].codeLength) + '%)');
        assert.ok(S.decode(a[0].code).ok && S.decode(a[1].code).ok);
      });
    });
  }, Promise.resolve()).then(function () { rows.forEach(function (r) { console.log('   • ' + r); }); });
});
T('بلا ضغط مدمج (CompressionStream غير موجود/يفشل) ⇒ يُنتج كوداً صالحاً بطريقة 0', function () {
  return enc(base(), { deflate: function () { return Promise.reject(new Error('x')); } }).then(function (r) { assert.strictEqual(r.method, 0); assert.ok(S.decode(r.code).ok); });
});
T('فك الضغط محلي: يعمل حتى لو حُذف DecompressionStream/CompressionStream من البيئة', function () {
  var saveD = globalThis.DecompressionStream, saveC = globalThis.CompressionStream;
  return enc(mk({ content: arabicText(1500, 9) })).then(function (r) {
    var out;
    assert.strictEqual(r.method, 1);
    delete globalThis.DecompressionStream; delete globalThis.CompressionStream;
    try { out = S.decode(r.code); } finally { globalThis.DecompressionStream = saveD; globalThis.CompressionStream = saveC; }
    assert.ok(out.ok, out.message);
    assert.ok(!/DecompressionStream/.test(fs.readFileSync(path.join(__dirname, '..', 'js', 'v1-share.js'), 'utf8')), 'لا اعتماد على DecompressionStream');
  });
});

// ===== فك الضغط المحلي مقابل zlib الحقيقي =====
T('inflateRaw يطابق zlib: مستويات 0–9 واستراتيجيات (ثابت/هوفمان فقط/RLE) وأحجام مختلفة', function () {
  var samples = [Buffer.alloc(0), Buffer.from('a'), Buffer.from('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'), UTF.encode(arabicText(3000, 5)), Buffer.from(Array.from({ length: 70000 }, function (_, i) { return (i * 2654435761 >>> 24) & 255; })), UTF.encode(JSON.stringify(good({ c: arabicText(1900, 8) }))), Buffer.alloc(100000, 7)], checked = 0;
  samples.forEach(function (buf) {
    [0, 1, 4, 6, 9].forEach(function (level) {
      [zlib.constants.Z_DEFAULT_STRATEGY, zlib.constants.Z_FIXED, zlib.constants.Z_HUFFMAN_ONLY, zlib.constants.Z_RLE].forEach(function (strategy) {
        var z = zlib.deflateRawSync(buf, { level: level, strategy: strategy }), out = S.inflateRaw(new Uint8Array(z), 1 << 20);
        assert.ok(Buffer.compare(Buffer.from(out), buf) === 0, 'level ' + level + ' strategy ' + strategy + ' size ' + buf.length);
        checked++;
      });
    });
  });
  assert.ok(checked >= 140, 'عدد الحالات ' + checked);
});
T('inflateRaw: دفق مقطوع أو تالف أو نوع كتلة 3 ⇒ خطأ code=inflate (لا تعليق ولا ذاكرة مفتوحة)', function () {
  var z = zlib.deflateRawSync(UTF.encode(arabicText(2000, 4))), cut = 0, bad = 0, i, thrown;
  for (i = 1; i < z.length; i += 7) { try { S.inflateRaw(new Uint8Array(z.subarray(0, i)), 1 << 20); } catch (e) { assert.ok(e.code === 'inflate' || e.code === 'toobig'); cut++; } }
  assert.ok(cut > 10);
  try { S.inflateRaw(new Uint8Array([0x07]), 1000); } catch (e) { thrown = e; }
  assert.ok(thrown && thrown.code === 'inflate', 'BTYPE=3');
  for (i = 0; i < 300; i++) { var junk = new Uint8Array(40); junk.forEach(function (_, k) { junk[k] = (i * 31 + k * 17 + (k * k)) & 255; }); try { S.inflateRaw(junk, 5000); } catch (e2) { assert.ok(e2.code === 'inflate' || e2.code === 'toobig', e2.message); bad++; } }
  assert.ok(bad > 50);
});
T('قنبلة الضغط: بيانات تتضخم إلى ميغابايتات تُرفض (toobig) ويرجع decode رسالة عربية', function () {
  var bomb = zlib.deflateRawSync(Buffer.alloc(8 * 1024 * 1024)), thrown, raw = new Uint8Array(8 + bomb.length), code;
  try { S.inflateRaw(new Uint8Array(bomb), 1000); } catch (e) { thrown = e; }
  assert.ok(thrown && thrown.code === 'toobig');
  raw[0] = 1; raw[1] = (bomb.length >>> 16) & 255; raw[2] = (bomb.length >>> 8) & 255; raw[3] = bomb.length & 255; raw.set(bomb, 8);
  code = 'MARSA1-' + S.b64encode(raw);
  var d = S.decode(code); assert.ok(!d.ok && /أكبر من المسموح|تالف/.test(d.message), d.message);
});
T('CRC32: المتجه القياسي ومطابقة zlib', function () {
  assert.strictEqual(S.crc32(UTF.encode('123456789')), 0xCBF43926);
  if (zlib.crc32) { var b = UTF.encode(arabicText(500, 3)); assert.strictEqual(S.crc32(b), zlib.crc32(Buffer.from(b))); }
});
T('base64: ذهاب وإياب لكل الأطوال 0–70، يتسامح مع المسافات والأسطر، ويرفض الأحرف الغريبة', function () {
  var i, k, b, s;
  for (i = 0; i <= 70; i++) { b = new Uint8Array(i); for (k = 0; k < i; k++) b[k] = (k * 37 + i * 11) & 255; s = S.b64encode(b); assert.deepStrictEqual(Array.from(S.b64decode(s)), Array.from(b), 'len ' + i); assert.deepStrictEqual(Array.from(S.b64decode(s.replace(/(.{7})/g, '$1\n '))), Array.from(b)); }
  assert.strictEqual(S.b64decode('ab$d'), null); assert.strictEqual(S.b64decode('abcde'), null); assert.strictEqual(S.b64decode('ab_-'), null);
});

// ===== اللصق من واتساب =====
T('لصق رسالة واتساب كاملة (مع علامات ```) يلتقط الكود', function () {
  return enc(mk({ group: 'ب', content: arabicText(800, 2) })).then(function (r) {
    var msg = S.buildMessage(mk({ group: 'ب' }), r.code, 'https://example.com/marsa/'), d = S.decode(msg);
    assert.ok(d.ok, d.message); assert.strictEqual(d.prep.id, 'p4k2m9x7q1ab');
    assert.ok(msg.indexOf('الصف: ب') > -1 && msg.indexOf('https://example.com/marsa/') > -1 && msg.indexOf(r.code) > -1);
    assert.strictEqual((msg.match(/```/g) || []).length, 2, 'كتلة كود واحدة تمنع تنسيق واتساب (_ * ~)');
    assert.ok(msg.indexOf('اللغة العربية') > -1 && msg.indexOf('درس الحال') > -1 && msg.indexOf('أكتوبر 2026') > -1);
  });
});
T('الكود يصمد أمام ما تفعله التطبيقات: كسر أسطر، مسافات، علامات اتجاه RTL، حروف صغيرة للبادئة، شرطة مطوّلة', function () {
  return enc(mk({ content: arabicText(900, 6) })).then(function (r) {
    var c = r.code, body = c.slice(7), variants = [
      c.replace(/(.{60})/g, '$1\n'), c.replace(/(.{25})/g, '$1 '), c.replace(/(.{10})/g, '$1\u200F'), c.replace(/(.{33})/g, '$1\u202B\u202C'),
      'marsa1-' + body, 'MARSA1\u2013' + body, 'MARSA 1 - ' + body, '\u200Fالكود:\n' + c + '\n\nشكراً', '   ' + c + '   ', 'انسخ هذا ' + c + ' ثم الصقه', c + '\nThanks a lot', c + ' Thanks', c + '```\nنهاية'
    ];
    variants.forEach(function (v, i) { var d = S.decode(v); assert.ok(d.ok, 'variant ' + i + ': ' + d.message); assert.strictEqual(d.prep.id, 'p4k2m9x7q1ab'); });
  });
});
T('أكثر من كود في النص: يُقرأ الأول فقط', function () {
  return Promise.all([enc(base()), enc(mk({ id: 'zzzzzz99aa', title: 'آخر' }))]).then(function (a) { var d = S.decode(a[0].code + '\n' + a[1].code); assert.ok(d.ok); assert.strictEqual(d.prep.id, 'p4k2m9x7q1ab'); });
});

// ===== أخطاء واضحة =====
T('كود فارغ ⇒ empty، نص عادي ⇒ noprefix، إصدار أحدث ⇒ version، إصدار قديم ⇒ version', function () {
  assert.strictEqual(S.decode('').reason, 'empty'); assert.strictEqual(S.decode(' \n\t ').reason, 'empty'); assert.strictEqual(S.decode(null).reason, 'empty'); assert.strictEqual(S.decode(undefined).reason, 'empty');
  var a = S.decode('مرحباً هذا نص عادي'); assert.strictEqual(a.reason, 'noprefix'); assert.ok(/ليس كود مَرسى/.test(a.message));
  assert.strictEqual(S.decode('MARSA').reason, 'noprefix'); assert.strictEqual(S.decode('MARSA1').reason, 'noprefix'); assert.strictEqual(S.decode('https://example.com').reason, 'noprefix');
  var v2 = S.decode('MARSA2-AQAAAAAAAAAAAAAAAA'); assert.strictEqual(v2.reason, 'version'); assert.ok(/أحدث/.test(v2.message) && /حدّث التطبيق/.test(v2.message));
  var v0 = S.decode('MARSA0-AQAAAAAAAAAAAAAAAA'); assert.strictEqual(v0.reason, 'version');
  assert.strictEqual(S.decode('MARSA1-').reason, 'truncated'); assert.strictEqual(S.decode('MARSA1-AQAA').reason, 'truncated');
});
T('كود ناقص: كل نقطة قطع ممكنة ⇒ truncated (أو corrupt) ولا يُقبل أبداً', function () {
  return enc(mk({ content: arabicText(600, 11) })).then(function (r) {
    var cut, d, truncated = 0;
    for (cut = 7; cut < r.code.length; cut++) {
      d = S.decode(r.code.slice(0, cut));
      assert.ok(!d.ok, 'قُبل كود مقطوع عند ' + cut);
      assert.ok(d.reason === 'truncated' || d.reason === 'corrupt', d.reason + '@' + cut);
      if (d.reason === 'truncated') { truncated++; assert.ok(/ناقص/.test(d.message)); }
    }
    assert.ok(truncated > r.code.length * 0.9);
  });
});
T('كود تالف: تغيير أي حرف لا يُنتج تحضيراً مختلفاً أبداً (إما خطأ أو نفس البيانات تماماً)', function () {
  return enc(mk({ content: arabicText(500, 13), homework: 'واجب 📚' })).then(function (r) {
    var orig = S.decode(r.code), pos, ch, alt, d, errors = 0, same = 0, ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    assert.ok(orig.ok);
    for (pos = 7; pos < r.code.length; pos++) {
      ch = r.code.charAt(pos); alt = ALPHA.charAt((ALPHA.indexOf(ch) + 1 + (pos % 7)) % 64); if (alt === ch) alt = ALPHA.charAt((ALPHA.indexOf(ch) + 2) % 64);
      d = S.decode(r.code.slice(0, pos) + alt + r.code.slice(pos + 1));
      if (d.ok) { assert.deepStrictEqual(d.prep, orig.prep, 'تحضير مختلف عند ' + pos); same++; } else { assert.ok(d.reason === 'corrupt' || d.reason === 'truncated' || d.reason === 'toobig', d.reason); errors++; }
    }
    assert.ok(errors > (r.code.length - 7) * 0.95, 'errors ' + errors + ' same ' + same);
    assert.ok(same <= 3, 'حروف الحشو الأخير فقط قد لا تغيّر البيانات: ' + same);
    assert.ok(/تالف/.test(S.decode(r.code.slice(0, 40) + (r.code.charAt(40) === 'A' ? 'B' : 'A') + r.code.slice(41)).message));
  });
});
T('حرف خارج الأبجدية في وسط الكود (مثل علامة عربية) ⇒ يُقطع هناك فيظهر ناقصاً لا تحضيراً خاطئاً', function () {
  return enc(mk({ content: arabicText(300, 1) })).then(function (r) { var d = S.decode(r.code.slice(0, 50) + 'ـ' + r.code.slice(50)); assert.ok(!d.ok); });
});

// ===== حمولة مزوّرة (بـ CRC صحيح) تُرفض بالتحقق =====
T('حمولة مزوّرة صحيحة الـ CRC لكن مخالفة للمخطط ⇒ invalid برسالة عربية (لا استثناء)', function () {
  var cases = [
    [good({ x: 1 }), 'مفتاح غير معروف'], [good({ t: undefined }), 'بلا عنوان'], [good({ s: 5 }), 'نوع خاطئ'], [good({ d: '2026-02-30' }), 'تاريخ غير موجود'], [good({ d: '1999-01-01' }), 'سنة خارج النطاق'],
    [good({ i: '../x' }), 'معرّف غير صالح'], [good({ i: 'abc' }), 'معرّف قصير'], [good({ i: 'a'.repeat(65) }), 'معرّف طويل'], [good({ c: 'ا'.repeat(2001) }), 'محتوى فوق الحد'], [good({ u: -1 }), 'u سالب'], [good({ u: 1.5 }), 'u كسري'], [good({ u: '5' }), 'u نص'], [good({ u: 1e15 }), 'u ضخم'],
    [good({ g: 'ا'.repeat(61) }), 'مجموعة طويلة'], [good({ c: '   ' }), 'محتوى فارغ'], [good({ s: '\u200B\u200F' }), 'مادة غير مرئية'], [good({ p: ['x'] }), 'صفحات مصفوفة'],
    [[], 'مصفوفة'], ['"x"', 'نص'], ['null', 'null'], ['123', 'رقم'], ['{"v":1', 'JSON ناقص'], ['{"v":1,"v":2}', 'مفتاح مكرر'], [good({ v: 2 }), 'v=2'], [good({ v: '1' }), 'v نص']
  ];
  cases.forEach(function (c) { var d = S.decode(forge(c[0])); assert.ok(!d.ok, 'قُبلت حمولة: ' + c[1]); assert.ok(typeof d.message === 'string' && /[\u0600-\u06FF]/.test(d.message), c[1] + ' ⇒ ' + d.message); });
});
T('__proto__ و constructor داخل الحمولة لا يلوّثان الكائنات ولا يُقبلان', function () {
  var d = S.decode(forge('{"v":1,"i":"p4k2m9x7q1ab","s":"م","t":"ع","d":"2026-10-28","c":"ن","u":1,"__proto__":{"polluted":true}}'));
  assert.ok(!d.ok); assert.strictEqual({}.polluted, undefined);
  var d2 = S.decode(forge('{"v":1,"i":"p4k2m9x7q1ab","s":"م","t":"ع","d":"2026-10-28","c":"ن","u":1,"constructor":{"x":1}}')); assert.ok(!d2.ok);
});
T('CRC خاطئ بحمولة سليمة ⇒ corrupt؛ طول مُعلن أكبر من الفعلي ⇒ truncated؛ طريقة غير معروفة ⇒ corrupt', function () {
  var good1 = forge(good(), { crc: 123 }); assert.strictEqual(S.decode(good1).reason, 'corrupt');
  var ok = forge(good()), bytes = S.b64decode(ok.slice(7)); bytes[3] += 40; assert.strictEqual(S.decode('MARSA1-' + S.b64encode(bytes)).reason, 'truncated');
  bytes = S.b64decode(ok.slice(7)); bytes[0] = 9; assert.strictEqual(S.decode('MARSA1-' + S.b64encode(bytes)).reason, 'corrupt');
  bytes = S.b64decode(ok.slice(7)); bytes[1] = 255; assert.ok(!S.decode('MARSA1-' + S.b64encode(bytes)).ok);
});
T('نص HTML/سكربت داخل التحضير يبقى نصاً حرفياً (العرض يتم بـ textContent)', function () {
  var evil = '<img src=x onerror=alert(1)><script>alert(2)</script> javascript:alert(3)';
  return enc(mk({ title: evil.slice(0, 100), content: evil })).then(function (r) { var d = S.decode(r.code); assert.ok(d.ok); assert.strictEqual(d.prep.content, evil); });
});
T('encode يرفض معرّفاً غير صالحاً وحمولة أكبر من الحد', function () {
  return enc(mk({ id: '../etc' })).then(function () { assert.fail('لم يُرفض'); }, function (e) { assert.ok(/معرّف/.test(e.message)); }).then(function () {
    return enc(mk({ content: 'ا'.repeat(250000) }));
  }).then(function () { assert.fail('لم يُرفض'); }, function (e) { assert.ok(/كبير/.test(e.message)); });
});
T('buildMessage: بلا رابط ⇒ «افتح تطبيق مَرسى»؛ رابط ⇒ يظهر؛ مجموعة ⇒ سطر الصف؛ التاريخ بصيغة عربية', function () {
  var code = 'MARSA1-AAAA', a = S.buildMessage(base(), code, ''), b = S.buildMessage(mk({ group: 'الشعبة ج' }), code, ' https://x.example/m/ ');
  assert.ok(a.indexOf('افتح تطبيق مَرسى') > -1 && a.indexOf('الصف:') < 0 && a.indexOf('http') < 0);
  assert.ok(b.indexOf('افتح مَرسى: https://x.example/m/') > -1 && b.indexOf('الصف: الشعبة ج') > -1);
  assert.ok(/التاريخ: .*2026/.test(a));
});
T('الكود لا يحوي بيانات شخصية غير مطلوبة: الحمولة مفاتيحها محصورة بحقول التحضير فقط', function () {
  var keys = Object.keys(JSON.parse(S.toPayload(mk({ pages: 'p', homework: 'h', notes: 'n', group: 'g' })))).sort().join('');
  assert.strictEqual(keys, 'cdghinpstuv'.split('').sort().join(''));
});

run(tests).then(function () {
  console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
});
