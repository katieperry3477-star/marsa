// اختبار واجهة المرحلة 03.2 بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-lessons.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة، ويحقن بيانات الاختبار في تخزين السياق المؤقت فقط.
var pw = require('playwright'), path = require('path'), fs = require('fs');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }

async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: opts.tz || 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: !!opts.touch, isMobile: !!opts.touch });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  if (opts.clock) await page.clock.install({ time: new Date(opts.clock) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")');
  await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
  await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toLessons(page) { await page.click('.nav button:has-text("ما أُخذ اليوم")'); await page.waitForSelector('#page-title'); }
async function fill(page, o) {
  if (o.subject !== undefined) await page.fill('#lf-subject', o.subject);
  if (o.title !== undefined) await page.fill('#lf-title', o.title);
  if (o.date !== undefined) await page.fill('#lf-date', o.date);
  var opt = ['summary', 'pages', 'homework', 'notes'].filter(function (k) { return o[k] !== undefined; });
  if (opt.length) {
    if (!(await page.$eval('details.opt', function (d) { return d.open; }))) await page.click('details.opt summary');
    for (var i = 0; i < opt.length; i++) await page.fill('#lf-' + opt[i], o[opt[i]]);
  }
}
async function store(page, key) { return page.evaluate(function (k) { var r = localStorage.getItem(k); return r === null ? null : JSON.parse(r); }, key); }
async function keys(page) { return page.evaluate(function () { var o = []; for (var i = 0; i < localStorage.length; i++) o.push(localStorage.key(i)); return o.sort(); }); }
async function cards(page) { return page.$$eval('.lcard', function (l) { return l.map(function (x) { return x.querySelector('h3').textContent; }); }); }
async function toast(page) { return page.$eval('#status', function (s) { return s.textContent; }); }
var KEY = 'marsa.academic.dailyLessons.cls_demo_001';

(async function main() {
  var browser = await pw.chromium.launch();
  var c, page, r, k, rec, rec2;

  // ===== 1) بداية نظيفة + التنقل + عدم تكرار الدخول =====
  c = await open(browser, { label: 'fresh' }); page = c.page;
  await toRep(page);
  var navTexts = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent; }); });
  check('Nav (rep mode) has exactly one «ما أُخذ اليوم» tab', navTexts.filter(function (x) { return x === 'ما أُخذ اليوم'; }).length === 1, navTexts.join('|'));
  await page.click('.nav button:has-text("اللوحة")');
  var tiles = await page.$$eval('.tile', function (l) { return l.map(function (b) { return b.textContent; }); });
  check('Dashboard has exactly one lessons tile', tiles.filter(function (x) { return x.indexOf('ما أُخذ اليوم') > -1; }).length === 1, tiles.join('|'));
  check('No other entry buttons to lessons elsewhere on dashboard', (await page.$$eval('main button', function (l) { return l.filter(function (b) { return b.textContent.indexOf('سجل الدروس') > -1 || b.textContent.indexOf('ما أُخذ اليوم') > -1; }).length; })) === 1);
  await page.click('.tile:has-text("ما أُخذ اليوم")');
  await page.waitForSelector('.lform', { state: 'hidden' });
  check('Route opens lessons page (data-view=r-lessons)', (await page.getAttribute('html', 'data-view')) === 'r-lessons');
  check('Fresh start: no fake lessons (empty state with guidance)', (await cards(page)).length === 0 && /لم تُسجَّل أي دروس/.test(await page.textContent('#v-page .empty')) && /إضافة سجل درس/.test(await page.textContent('#v-page .empty')));
  check('Fresh start: opening lessons page writes NO academic key', (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0; }).length === 0, (await keys(page)).join(','));
  check('Fresh start: search box hidden while empty', await page.$eval('input[type=search]', function (e) { return e.hidden || getComputedStyle(e).display === 'none'; }));
  check('Fresh start: shows count 0 and active class bar', /عدد السجلات: 0/.test(await page.textContent('.count')) && (await page.$('.classbar')) !== null);

  // ===== 2) إضافة: تحقق من الحقول =====
  await page.click('button:has-text("إضافة سجل درس")');
  check('Form opens; required fields marked, optional ones collapsed', (await page.$eval('details.opt', function (d) { return !d.open; })) && /مطلوب/.test(await page.textContent('label[for=lf-subject]')) && /اختياري/.test(await page.textContent('label[for=lf-summary]')));
  var todayLocal = await page.evaluate(function () { var d = new Date(), p = function (n) { return (n < 10 ? '0' : '') + n; }; return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); });
  check('Default date = local today', (await page.inputValue('#lf-date')) === todayLocal, await page.inputValue('#lf-date'));
  await page.click('button:has-text("حفظ السجل")');
  check('Empty required fields: errors shown, focus on first, nothing saved', /المادة|اسم المادة/.test(await page.textContent('#lf-subject-e')) && /عنوان/.test(await page.textContent('#lf-title-e')) && (await page.evaluate(function () { return document.activeElement.id; })) === 'lf-subject' && (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0; }).length === 0);
  await fill(page, { subject: '   ', title: '   ' });
  await page.click('button:has-text("حفظ السجل")');
  check('Whitespace-only rejected', /اسم المادة/.test(await page.textContent('#lf-subject-e')));
  check('maxlength attributes present for limits', (await page.$eval('#lf-subject', function (e) { return e.maxLength; })) === 80 && (await page.$eval('#lf-title', function (e) { return e.maxLength; })) === 120 && (await page.$eval('#lf-summary', function (e) { return e.maxLength; })) === 1000);
  await fill(page, { subject: 'مادة أ', title: 'درس الأول', date: '' });
  await page.click('button:has-text("حفظ السجل")');
  check('Cleared date rejected (required)', /اختر تاريخ/.test(await page.textContent('#lf-date-e')) && (await page.evaluate(function () { return document.activeElement.id; })) === 'lf-date');
  check('Browser date input cannot even hold an impossible date', (await page.$eval('#lf-date', function (e) { e.value = '2026-02-30'; return e.value; })) === '');

  // ===== 3) إضافة ناجحة، ظهور بالقائمة، سجل ثابت =====
  await fill(page, { date: '2026-10-20', summary: 'ملخص\nسطر ثان', pages: 'ص 10-12', homework: 'حل التمرين 3', notes: 'ملاحظة' });
  await page.click('button:has-text("حفظ السجل")');
  await page.waitForSelector('.lcard');
  check('Add: record appears in list and form closes', (await cards(page)).join() === 'درس الأول' && (await page.$('.lform:not([hidden])')) === null);
  check('Add: success toast shown (persistent storage)', /تم حفظ سجل الدرس/.test(await toast(page)));
  var col = await store(page, KEY);
  rec = col.records[0];
  check('Stored: schemaVersion 1, classId cls_demo_001, one record', col.schemaVersion === 1 && col.classId === 'cls_demo_001' && col.records.length === 1);
  check('Stored record: recordId, classId, local date string, fields', /^dl_/.test(rec.recordId) && rec.classId === 'cls_demo_001' && rec.date === '2026-10-20' && rec.subject === 'مادة أ' && rec.title === 'درس الأول' && rec.summary === 'ملخص\nسطر ثان' && rec.pages === 'ص 10-12' && rec.homework === 'حل التمرين 3' && rec.notes === 'ملاحظة');
  check('Card shows optional fields with multi-line summary', /ملخص/.test(await page.textContent('.lcard')) && /حل التمرين 3/.test(await page.textContent('.lcard')) && (await page.$eval('.lc-t', function (e) { return getComputedStyle(e).whiteSpace; })) === 'pre-wrap');
  var keysAfter = await keys(page);
  check('Only the lessons collection key was added to storage', keysAfter.filter(function (x) { return x.indexOf('marsa.academic') === 0; }).join() === KEY, keysAfter.join(','));

  // ===== 4) بحث وترتيب الأحدث أولاً =====
  await page.click('button:has-text("إضافة سجل درس")');
  await fill(page, { subject: 'مادة ب', title: 'درس أحدث', date: '2026-10-21' });
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard:nth-child(2)');
  await page.click('button:has-text("إضافة سجل درس")');
  await fill(page, { subject: 'مادة أ', title: 'درس أقدم', date: '2026-09-01' });
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard:nth-child(3)');
  check('List order: newest date first', (await cards(page)).join('|') === 'درس أحدث|درس الأول|درس أقدم', (await cards(page)).join('|'));
  await page.fill('input[type=search]', 'مادة ب');
  check('Search by subject', (await cards(page)).join('|') === 'درس أحدث');
  await page.fill('input[type=search]', 'اقدم');
  check('Search by title (hamza-insensitive)', (await cards(page)).join('|') === 'درس أقدم');
  await page.fill('input[type=search]', 'غير موجود');
  check('Search no match message + count', (await cards(page)).length === 0 && /لا توجد سجلات مطابقة/.test(await page.textContent('main')) && /النتائج: 0 من 3/.test(await page.textContent('.resc')));
  await page.fill('input[type=search]', '');
  await page.click('button:has-text("إضافة سجل درس")');
  var sugg = await page.$$eval('#lf-subjects option', function (l) { return l.map(function (o) { return o.value; }).sort(); });
  check('datalist has only user-entered subjects (مادة أ, مادة ب)', sugg.join('|') === ['مادة أ', 'مادة ب'].sort().join('|'), sugg.join('|'));
  await page.click('.lform button:has-text("إلغاء")');
  check('Cancel on untouched form closes it without confirm', (await page.$('.lform:not([hidden])')) === null);

  // ===== 5) تعديل: المعرّف ثابت =====
  var before = (await store(page, KEY)).records.filter(function (x) { return x.title === 'درس الأول'; })[0];
  await page.click('.lcard:has-text("درس الأول") button:has-text("تعديل")');
  check('Edit form prefilled; optional details auto-open', (await page.inputValue('#lf-title')) === 'درس الأول' && (await page.inputValue('#lf-date')) === '2026-10-20' && (await page.inputValue('#lf-summary')) === 'ملخص\nسطر ثان' && (await page.$eval('details.opt', function (d) { return d.open; })));
  await page.fill('#lf-title', 'درس الأول (معدّل)'); await page.fill('#lf-homework', '');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lcard:has-text("معدّل")');
  var after = (await store(page, KEY)).records.filter(function (x) { return x.title === 'درس الأول (معدّل)'; })[0];
  check('Edit: same recordId, classId and createdAt (no new record)', after && after.recordId === before.recordId && after.classId === before.classId && after.createdAt === before.createdAt && (await store(page, KEY)).records.length === 3);
  check('Edit: updatedAt set, emptied optional field removed, others kept', after.updatedAt && !('homework' in after) && after.pages === 'ص 10-12');
  check('Edit: toast confirms', /تم حفظ التعديل/.test(await toast(page)));

  // ===== 6) نموذج متسخ: حماية من الفقد =====
  await page.click('.lcard:has-text("درس أحدث") button:has-text("تعديل")');
  await page.fill('#lf-title', 'تغيير غير محفوظ');
  await page.click('.lcard:has-text("درس أقدم") button:has-text("تعديل")');
  check('Dirty form: switching asks for confirmation', (await page.$eval('#dlg-confirm', function (d) { return d.open; })) && /تجاهل/.test(await page.textContent('#dlg-confirm-body')));
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  check('Dirty form: cancel keeps typed text', (await page.inputValue('#lf-title')) === 'تغيير غير محفوظ');
  await page.click('.lform button:has-text("إلغاء")');
  await page.click('#dlg-confirm-body button:has-text("تجاهل والمتابعة")');
  check('Dirty form: confirm discards and closes, record unchanged', (await page.$('.lform:not([hidden])')) === null && (await cards(page)).indexOf('درس أحدث') > -1);

  // ===== 7) حذف بتأكيد =====
  await page.click('.lcard:has-text("درس أقدم") button:has-text("حذف")');
  check('Delete shows clear confirmation naming the record', (await page.$eval('#dlg-confirm', function (d) { return d.open; })) && /درس أقدم/.test(await page.textContent('#dlg-confirm-body')) && /لا يمكن التراجع/.test(await page.textContent('#dlg-confirm-body')));
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  check('Delete cancelled: record still there', (await cards(page)).length === 3 && (await store(page, KEY)).records.length === 3);
  await page.click('.lcard:has-text("درس أقدم") button:has-text("حذف")');
  await page.click('#dlg-confirm-body button:has-text("حذف السجل")');
  check('Delete confirmed: removed from list and storage', (await cards(page)).indexOf('درس أقدم') === -1 && (await store(page, KEY)).records.length === 2);
  check('Delete: toast shown', /تم حذف سجل الدرس/.test(await toast(page)));

  // ===== 8) إعادة التحميل: استمرار البيانات =====
  await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  var uiPrefs = await store(page, 'marsa.ui');
  check('Reload: back to student mode, rep never stored', uiPrefs.mode === 'student' && (await page.getAttribute('html', 'data-mode')) === 'student');
  await toRep(page); await toLessons(page);
  check('Reload: lessons persisted and same order', (await cards(page)).join('|') === 'درس أحدث|درس الأول (معدّل)', (await cards(page)).join('|'));
  var snap = await page.evaluate(function () { return localStorage.getItem('marsa.academic.dailyLessons.cls_demo_001'); });
  await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  await toRep(page); await toLessons(page);
  check('Viewing lessons does not rewrite stored bytes', (await page.evaluate(function () { return localStorage.getItem('marsa.academic.dailyLessons.cls_demo_001'); })) === snap);

  // ===== 9) فصل الصفوف =====
  await page.click('.nav button:has-text("اللوحة")'); await page.click('.tile:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")');
  await page.fill('#cf-stage', 'الثالث المتوسط'); await page.fill('#cf-section', 'ب');
  await page.check('.cform .chk input'); await page.click('button:has-text("إضافة الصف")');
  await page.waitForFunction(function () { return !document.getElementById('dlg-class').open; });
  await toLessons(page);
  check('Second class starts with EMPTY lessons (demo lessons not shown)', (await cards(page)).length === 0 && /لم تُسجَّل أي دروس/.test(await page.textContent('#v-page .empty')));
  var otherId = await page.getAttribute('main', 'data-class-id');
  await page.click('button:has-text("إضافة سجل درس")'); await fill(page, { subject: 'مادة ج', title: 'درس الصف الآخر', date: '2026-10-19' });
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  var colB = await store(page, 'marsa.academic.dailyLessons.' + otherId);
  check('Second class saved under its own key with its own classId', colB && colB.classId === otherId && otherId !== 'cls_demo_001' && colB.records.length === 1 && colB.records[0].classId === otherId);
  check('Demo class collection untouched by second-class add', (await store(page, KEY)).records.length === 2);
  await page.selectOption('#cb-sel', 'cls_demo_001'); await page.waitForSelector('.lcard:has-text("درس أحدث")');
  check('Switch back to demo: only demo lessons (no mixing)', (await cards(page)).join('|') === 'درس أحدث|درس الأول (معدّل)', (await cards(page)).join('|'));
  await page.selectOption('#cb-sel', otherId); await page.waitForSelector('.lcard:has-text("الصف الآخر")');
  check('Switch to other class again: only its lesson', (await cards(page)).join('|') === 'درس الصف الآخر');
  // حذف الصف الذي فيه دروس ممنوع
  await page.click('.classbar button:has-text("إدارة الصفوف")');
  await page.click('.cls:has-text("الثالث المتوسط") button:has-text("حذف نهائي")');
  check('Class with lessons cannot be permanently deleted (explained)', /السجلات الدراسية/.test(await page.textContent('#dlg-confirm-body')) && (await store(page, 'marsa.academic.dailyLessons.' + otherId)) !== null);
  await page.click('#dlg-confirm-body button:has-text("حسناً")');
  check('Existing class/roster keys not touched by lessons (marsa.classes intact, demo class kept)', (await store(page, 'marsa.classes')).classes.some(function (x) { return x.classId === 'cls_demo_001'; }));
  await c.ctx.close();

  // ===== 10) فشل الحفظ: النموذج يبقى ولا نجاح =====
  c = await open(browser, { label: 'fail' }); page = c.page; await toRep(page); await toLessons(page);
  await page.click('button:has-text("إضافة سجل درس")');
  await fill(page, { subject: 'مادة', title: 'لن يُحفظ الآن', date: '2026-10-21', summary: 'نص طويل أدخله المستخدم' });
  await page.evaluate(function () { window.__orig = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (String(k).indexOf('marsa.academic') === 0) throw new Error('QuotaExceededError'); return window.__orig.call(this, k, v); }; });
  await page.click('button:has-text("حفظ السجل")');
  check('Failed save: error message shown inside form', /لم يُحفظ السجل/.test(await page.textContent('#lf-msg')) && /أعد المحاولة/.test(await page.textContent('#lf-msg')), await page.textContent('#lf-msg'));
  check('Failed save: form still open with ALL typed data', (await page.inputValue('#lf-title')) === 'لن يُحفظ الآن' && (await page.inputValue('#lf-subject')) === 'مادة' && (await page.inputValue('#lf-summary')) === 'نص طويل أدخله المستخدم' && (await page.inputValue('#lf-date')) === '2026-10-21');
  check('Failed save: NO success toast and no card', !/تم حفظ/.test(await toast(page)) && (await cards(page)).length === 0);
  check('Failed save: nothing written to storage', (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0; }).length === 0);
  check('Failed save: submit button usable again (not stuck disabled)', !(await page.$eval('button:has-text("حفظ السجل")', function (b) { return b.disabled; })));
  await page.evaluate(function () { Storage.prototype.setItem = window.__orig; });
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  check('Retry after storage recovers: saved once with success toast', (await cards(page)).join() === 'لن يُحفظ الآن' && /تم حفظ سجل الدرس/.test(await toast(page)) && (await store(page, KEY)).records.length === 1);
  // تعديل يُحذف من مكان آخر: لا إحياء
  await page.click('.lcard button:has-text("تعديل")');
  await page.evaluate(function (k) { localStorage.setItem(k, JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', records: [] })); }, KEY);
  await page.fill('#lf-title', 'عنوان جديد'); await page.click('button:has-text("حفظ التعديل")');
  check('Edit of a record deleted elsewhere: refused, no resurrection, form kept', /لم يعد موجوداً/.test(await page.textContent('#lf-msg')) && (await store(page, KEY)).records.length === 0 && (await page.inputValue('#lf-title')) === 'عنوان جديد');
  // تاريخ مستقبلي: ضغطتان
  await page.click('.lform button:has-text("إلغاء")'); await page.click('#dlg-confirm-body button:has-text("تجاهل والمتابعة")');
  await page.click('button:has-text("إضافة سجل درس")');
  await fill(page, { subject: 'م', title: 'مستقبلي', date: '2099-01-01' });
  await page.click('button:has-text("حفظ السجل")');
  check('Future date: first press warns and saves nothing', /بعد اليوم/.test(await page.textContent('#lf-msg')) && (await store(page, KEY)).records.length === 0);
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  check('Future date: second press confirms and saves', (await store(page, KEY)).records.length === 1 && (await store(page, KEY)).records[0].date === '2099-01-01');
  await c.ctx.close();

  // ===== 11) تخزين مؤقت فقط =====
  c = await open(browser, { label: 'temp', init: function () { try { Object.defineProperty(window, 'localStorage', { get: function () { throw new Error('blocked'); } }); } catch (e) { } } });
  page = c.page; await toRep(page); await toLessons(page);
  check('Blocked storage: persistent banner shown on lessons page', /مؤقتة/.test(await page.textContent('#v-page .warnbox')), await page.textContent('main'));
  await page.click('button:has-text("إضافة سجل درس")'); await fill(page, { subject: 'م', title: 'مؤقت', date: '2026-10-21' });
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  check('Blocked storage: toast says temporary, NOT a plain success', /ليس بشكل دائم|في ذاكرة هذه الصفحة فقط/.test(await toast(page)) && !/^تم حفظ سجل الدرس\.?$/.test((await toast(page)).trim()), await toast(page));
  check('Blocked storage: record visible in session', (await cards(page)).join() === 'مؤقت');
  await c.ctx.close();

  // ===== 12) بيانات تالفة =====
  c = await open(browser, { label: 'corrupt', init: function () { try { if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); localStorage.setItem('marsa.academic.dailyLessons.cls_demo_001', '{broken'); } } catch (e) { } } });
  page = c.page; await toRep(page); await toLessons(page);
  check('Corrupt collection: warning shown, bytes untouched, backup kept', /تالفة/.test(await page.textContent('#v-page .warnbox')) && (await page.evaluate(function () { return localStorage.getItem('marsa.academic.dailyLessons.cls_demo_001'); })) === '{broken' && (await page.evaluate(function () { return localStorage.getItem('marsa.academic.dailyLessons.cls_demo_001.backup'); })) === '{broken');
  check('Corrupt collection: add button disabled (no overwrite) and no fake empty-state claim', (await page.$eval('button:has-text("إضافة سجل درس")', function (b) { return b.disabled; })) && (await page.$('#v-page .empty')) === null);
  await c.ctx.close();

  // ===== 13) النص كنص (XSS) =====
  c = await open(browser, { label: 'xss' }); page = c.page; await toRep(page); await toLessons(page);
  var evil = '<img src=x onerror="window.__x=1"><script>window.__x=2<\/script>';
  await page.click('button:has-text("إضافة سجل درس")'); await fill(page, { subject: evil, title: evil, date: '2026-10-21', summary: evil, pages: evil, homework: evil, notes: evil });
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  check('Markup in all fields rendered as text only (no img/script injected, no execution)', (await page.$$('.lcard img, .lcard script')).length === 0 && (await page.evaluate(function () { return window.__x; })) === undefined && (await page.textContent('.lcard h3')) === evil);
  await page.fill('input[type=search]', '<img');
  check('Search with markup is inert', (await page.$$('main img')).length === 0);
  await page.click('.lcard button:has-text("حذف")');
  check('Confirm dialog shows markup as text', (await page.$$('#dlg-confirm-body img')).length === 0 && (await page.textContent('#dlg-confirm-body')).indexOf('<img') > -1);
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  await c.ctx.close();

  // ===== 14) التاريخ المحلي عبر المناطق الزمنية (ساعة مزيفة) =====
  var zones = [['Pacific/Kiritimati', '2026-10-21T23:30:00Z', '2026-10-22'], ['America/Los_Angeles', '2026-10-22T06:30:00Z', '2026-10-21'], ['Asia/Baghdad', '2026-10-21T21:30:00Z', '2026-10-22'], ['Asia/Baghdad', '2026-10-21T20:30:00Z', '2026-10-21']];
  for (var z = 0; z < zones.length; z++) {
    c = await open(browser, { label: 'tz', tz: zones[z][0], clock: zones[z][1] }); page = c.page; await toRep(page); await toLessons(page);
    await page.click('button:has-text("إضافة سجل درس")');
    var dv = await page.inputValue('#lf-date');
    await fill(page, { subject: 'م', title: 'ت' });
    await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
    var saved = (await store(page, KEY)).records[0].date, shownTag = await page.$$eval('.lcard .tag.on', function (l) { return l.length; });
    check('TZ ' + zones[z][0] + ' @ ' + zones[z][1] + ': default+stored date = local day ' + zones[z][2] + ' (not UTC day)', dv === zones[z][2] && saved === zones[z][2] && shownTag === 1, dv + ' / ' + saved);
    var day = await page.$eval('.lc-date', function (e) { return e.textContent; });
    check('TZ ' + zones[z][0] + ': displayed date contains local day number ' + +zones[z][2].slice(8), day.indexOf(String(+zones[z][2].slice(8))) > -1, day);
    await c.ctx.close();
  }

  // ===== 15) موبايل: عدم تمرير أفقي، لمس 44px، خط 16px، حالات =====
  var widths = [320, 360, 375, 390, 412];
  var longTxt = 'ااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااا';
  for (var w = 0; w < widths.length; w++) {
    c = await open(browser, { label: 'mob' + widths[w], viewport: { width: widths[w], height: 700 }, touch: true }); page = c.page; await toRep(page); await toLessons(page);
    var ov0 = await page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; });
    await page.click('button:has-text("إضافة سجل درس")');
    await fill(page, { subject: longTxt.slice(0, 80), title: longTxt, date: '2026-10-21', summary: longTxt + '\n' + longTxt, pages: longTxt.slice(0, 80), homework: longTxt, notes: longTxt });
    var ovForm = await page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; });
    var small = await page.$$eval('.lform button, .lform input, .lform textarea, .lform select, .lform summary, .toolbar button', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + Math.round(e.getBoundingClientRect().height); }); });
    var fonts = await page.$$eval('.lform input, .lform textarea, input[type=search]', function (l) { return l.filter(function (e) { return e.offsetParent && parseFloat(getComputedStyle(e).fontSize) < 16; }).length; });
    await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
    var ovList = await page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; });
    var smallList = await page.$$eval('.lcard button, input[type=search], .toolbar button', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + Math.round(e.getBoundingClientRect().height); }); });
    await page.click('.lcard button:has-text("حذف")');
    var dlgOverflow = await page.evaluate(function () { var d = document.getElementById('dlg-confirm'), r = d.getBoundingClientRect(); return r.left < 0 || r.right > window.innerWidth + 1 || document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; });
    await page.click('#dlg-confirm-body button:has-text("إلغاء")');
    check('Mobile ' + widths[w] + 'px: no horizontal scroll (empty page / open form with long text / list with long text / delete dialog)', !ov0 && !ovForm && !ovList && !dlgOverflow, [ov0, ovForm, ovList, dlgOverflow].join(','));
    check('Mobile ' + widths[w] + 'px: all form/list controls >= 44px tall', small.length === 0 && smallList.length === 0, small.concat(smallList).join(','));
    check('Mobile ' + widths[w] + 'px: inputs font-size >= 16px (no iOS zoom)', fonts === 0);
    await c.ctx.close();
  }
  // الوضع الأفقي القصير: نموذج مفتوح لا يقصّ الأزرار
  c = await open(browser, { label: 'land', viewport: { width: 568, height: 320 }, touch: true }); page = c.page; await toRep(page); await toLessons(page);
  await page.click('button:has-text("إضافة سجل درس")');
  var reach = await page.evaluate(function () { var b = Array.from(document.querySelectorAll('.lform button')).filter(function (x) { return x.textContent === 'حفظ السجل'; })[0]; b.scrollIntoView({ block: 'center' }); var r = b.getBoundingClientRect(); return r.top >= 0 && r.bottom <= window.innerHeight; });
  check('Mobile 568x320 landscape: save button reachable and no horizontal scroll', reach && !(await page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; })));
  await c.ctx.close();


  // ===== 17) انحدار: الطلاب والصفوف ما زالت تعمل، وحذف صف فارغ ينظّف مفاتيحه الأكاديمية الفارغة =====
  c = await open(browser, { label: 'regress' }); page = c.page; await toRep(page);
  await page.click('.nav button:has-text("الطلاب")');
  await page.click('button:has-text("إضافة طلاب")');
  await page.fill('#dlg-add-body textarea', 'علي حسن\nأحمد كريم');
  await page.click('button:has-text("معاينة الأسماء")'); await page.click('button:has-text("تأكيد الإضافة")');
  await page.waitForSelector('.stu');
  var ros = await store(page, 'marsa.roster');
  check('Regression: bulk add students still works (schema 2, classId, codes, 2 students)', ros.schemaVersion === 2 && ros.classId === 'cls_demo_001' && ros.students.length === 2 && ros.students.every(function (x) { return /^MR-/.test(x.studentCode) && x.studentId; }));
  var firstName = await page.$eval('.stu .stu-name', function (e) { return e.textContent; });
  check('Regression: Arabic sort (أحمد before علي)', firstName === 'أحمد كريم', firstName);
  await page.click('.stu:has-text("علي حسن") button:has-text("أرشفة الطالب")'); await page.click('#dlg-confirm-body button:has-text("أرشفة الطالب")');
  check('Regression: archive student still works', (await store(page, 'marsa.roster')).students.filter(function (x) { return x.status === 'archived'; }).length === 1);
  await toLessons(page); await page.click('button:has-text("إضافة سجل درس")'); await fill(page, { subject: 'م', title: 'ت' }); await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  check('Lessons do not touch the roster (still 2 students, same bytes shape)', (await store(page, 'marsa.roster')).students.length === 2);
  await page.click('.nav button:has-text("اللوحة")'); await page.click('.tile:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', 'صف فارغ للحذف'); await page.check('.cform .chk input'); await page.click('button:has-text("إضافة الصف")');
  await page.waitForFunction(function () { return !document.getElementById('dlg-class').open; });
  await toLessons(page); await page.click('button:has-text("إضافة سجل درس")'); await fill(page, { subject: 'م', title: 'سيُحذف' }); await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  var emptyId = await page.getAttribute('main', 'data-class-id');
  await page.click('.lcard button:has-text("حذف")'); await page.click('#dlg-confirm-body button:has-text("حذف السجل")');
  await page.click('.nav button:has-text("اللوحة")'); await page.click('.tile:has-text("إدارة الصفوف")');
  await page.click('.cls:has-text("صف فارغ للحذف") button:has-text("حذف نهائي")');
  check('Class whose lessons were all deleted can be permanently deleted (confirmation shown)', /الحذف النهائي لا يمكن التراجع/.test(await page.textContent('#dlg-confirm-body')));
  await page.click('#dlg-confirm-body button:has-text("حذف نهائي")');
  await page.waitForFunction(function () { return !document.getElementById('dlg-confirm').open; });
  check('Deleting the empty class removed its (empty) academic key; other class data intact', (await store(page, 'marsa.academic.dailyLessons.' + emptyId)) === null && (await store(page, KEY)).records.length === 1 && (await store(page, 'marsa.classes')).classes.every(function (x) { return x.classId !== emptyId; }));
  await c.ctx.close();

  // ===== 16) تدقيق ثابت =====
  var src = ['js/app.js', 'js/lessons-model.js', 'js/academic-store.js'].map(function (f) { return fs.readFileSync(path.resolve(__dirname, '..', f), 'utf8'); }).join('\n');
  check('Static: no eval / new Function / innerHTML / outerHTML / insertAdjacentHTML / document.write', !/\beval\s*\(|new\s+Function|\.innerHTML|\.outerHTML|insertAdjacentHTML|document\.write/.test(src));
  check('Static: no string timers', !/set(Timeout|Interval)\s*\(\s*['"`]/.test(src));
  var css = fs.readFileSync(path.resolve(__dirname, '..', 'css/styles.css'), 'utf8').replace(/@media \(hover:hover\)\{[^{}]*\{[^{}]*\}\}/g, '');
  check('Static: no :hover rule outside @media (hover:hover)', !/:hover/.test(css));
  check('No uncaught JS errors across all runs', jsErrors.length === 0, jsErrors.join(' || '));

  await browser.close();
  var failed = results.filter(function (x) { return !x.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed (of ' + results.length + ')');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('RUNNER ERROR', e); process.exit(2); });
