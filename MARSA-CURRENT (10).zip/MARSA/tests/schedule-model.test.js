// تشغيل: node tests/schedule-model.test.js  (لا يحتاج مكتبات)
var assert = require('assert');
var M = require('../js/schedule-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake() { var d = {}; return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { d[k] = String(v); }, removeItem: function (k) { delete d[k]; } }; }
var ok = { day: 'sun', subject: 'مادة' };
function v(o) { var x = {}, k; for (k in ok) x[k] = ok[k]; for (k in o) x[k] = o[k]; return M.validate(x); }
function rec(o) { var r = { recordId: 'sch_' + (rec.i = (rec.i || 0) + 1), classId: 'c1', createdAt: '2026-01-01T00:00:0' + (rec.i % 10) + 'Z' }, k; for (k in o) r[k] = o[k]; return r; }
function ids(l) { return l.map(function (x) { return x.recordId; }); }

t('required: day + subject only; period/time/notes optional', function () {
  assert.ok(v({}).ok);
  assert.ok(v({ day: '' }).errors.day); assert.ok(v({ day: 'xyz' }).errors.day); assert.ok(v({ day: '__proto__' }).errors.day);
  assert.ok(v({ subject: ' \u200B ' }).errors.subject);
  var r = v({ period: '', startTime: '', endTime: '', notes: '' }); assert.ok(r.ok); assert.strictEqual(r.values.period, null);
});
t('subject/notes length limits (80 / 300)', function () {
  assert.ok(v({ subject: new Array(82).join('م') }).errors.subject);
  assert.ok(v({ subject: new Array(81).join('م') }).ok);
  assert.ok(v({ notes: new Array(302).join('ن') }).errors.notes);
  assert.ok(v({ notes: new Array(301).join('ن') }).ok);
});
t('period: integer 1..30, Arabic-Indic digits accepted, junk rejected', function () {
  assert.strictEqual(v({ period: '3' }).values.period, 3);
  assert.strictEqual(v({ period: '٤' }).values.period, 4);
  assert.strictEqual(v({ period: '۵' }).values.period, 5);
  ['0', '31', '-1', '1.5', 'a', '1e1', '١٢٣٤'].forEach(function (p) { assert.ok(v({ period: p }).errors.period, p); });
  assert.ok(v({ period: '30' }).ok);
});
t('time format: HH:MM, H:MM, Arabic digits; invalid rejected', function () {
  assert.strictEqual(v({ startTime: '8:05' }).values.startTime, '08:05');
  assert.strictEqual(v({ startTime: '٠٨:٣٠' }).values.startTime, '08:30');
  assert.strictEqual(v({ startTime: '23:59' }).values.startTime, '23:59');
  ['24:00', '12:60', '8', '8:5', 'abc', '25:00', '12:345'].forEach(function (x) { assert.ok(v({ startTime: x }).errors.startTime, x); });
});
t('end must be after start; equal and earlier rejected; end without start rejected; start alone ok', function () {
  assert.ok(v({ startTime: '08:00', endTime: '08:45' }).ok);
  assert.ok(v({ startTime: '08:00', endTime: '08:00' }).errors.endTime);
  assert.ok(v({ startTime: '09:00', endTime: '08:00' }).errors.endTime);
  assert.ok(v({ endTime: '08:45' }).errors.startTime);
  assert.ok(v({ startTime: '08:00' }).ok);
  assert.ok(v({ startTime: '23:00', endTime: '00:30' }).errors.endTime); // لا حصة تعبر منتصف الليل
});
t('formatTime / timeRange (12h, Latin digits, ص/م)', function () {
  assert.strictEqual(M.formatTime('08:05'), '8:05 ص'); assert.strictEqual(M.formatTime('00:10'), '12:10 ص');
  assert.strictEqual(M.formatTime('12:00'), '12:00 م'); assert.strictEqual(M.formatTime('13:30'), '1:30 م'); assert.strictEqual(M.formatTime('bad'), '');
  assert.strictEqual(M.timeRange({ startTime: '08:00', endTime: '08:45' }), '8:00 ص – 8:45 ص');
  assert.strictEqual(M.timeRange({ startTime: '08:00' }), 'من 8:00 ص'); assert.strictEqual(M.timeRange({}), '');
});
t('buildRecord: keeps recordId/classId/createdAt on edit, drops empty optionals, never invents an id', function () {
  var ex = { recordId: 'sch_a', classId: 'c1', createdAt: 'x', day: 'sun', subject: 'قديم', period: 2, startTime: '08:00', endTime: '08:45', notes: 'ن', extra: 1 };
  var r = M.buildRecord(v({ day: 'mon', subject: 'جديد' }).values, ex);
  assert.strictEqual(r.recordId, 'sch_a'); assert.strictEqual(r.classId, 'c1'); assert.strictEqual(r.createdAt, 'x'); assert.strictEqual(r.extra, 1);
  assert.strictEqual(r.day, 'mon'); assert.ok(!('period' in r) && !('startTime' in r) && !('endTime' in r) && !('notes' in r));
  assert.ok(!('recordId' in M.buildRecord(v({}).values, null)));
});
t('sorting: period asc, then start time, then createdAt/id; unnumbered/untimed last; stable regardless of input order', function () {
  var a = rec({ subject: 'a', period: 2 }), b = rec({ subject: 'b', period: 1 }), c = rec({ subject: 'c' }), d = rec({ subject: 'd', startTime: '07:00' }), e = rec({ subject: 'e', period: 2, startTime: '07:30' });
  // a (period 2, no time) vs e (period 2, 07:30): الوقت قبل «بلا وقت»
  assert.deepStrictEqual(M.sortDay([a, b, c, d, e]).map(function (x) { return x.subject; }), ['b', 'e', 'a', 'd', 'c']);
  assert.deepStrictEqual(M.sortDay([e, d, c, b, a]).map(function (x) { return x.subject; }), ['b', 'e', 'a', 'd', 'c']);
  var p10 = rec({ subject: 'p10', period: 10 }), p9 = rec({ subject: 'p9', period: 9 });
  assert.deepStrictEqual(M.sortDay([p10, p9]).map(function (x) { return x.subject; }), ['p9', 'p10']); // رقمي لا نصي
});
t('groupByDay: valid days grouped; invalid/missing day goes to unknown (never hidden)', function () {
  var g = M.groupByDay([rec({ subject: 'x', day: 'sun' }), rec({ subject: 'y', day: 'zzz' }), rec({ subject: 'z' }), rec({ subject: 'w', day: 'constructor' })]);
  assert.strictEqual(g.byDay.sun.length, 1); assert.strictEqual(g.unknown.length, 3); assert.strictEqual(g.byDay.mon.length, 0);
});
t('days: fixed keys, Saturday-first order, JS getDay mapping', function () {
  assert.deepStrictEqual(M.DAYS.map(function (d) { return d.key; }), ['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri']);
  assert.strictEqual(M.dayLabel('wed'), 'الأربعاء'); assert.strictEqual(M.dayKeyOfDate(new Date(2026, 9, 22)), 'thu'); // 2026-10-22 خميس
  assert.strictEqual(M.dayKeyOfDate(new Date(2026, 9, 24)), 'sat'); assert.strictEqual(M.dayKeyOfDate(new Date(2026, 9, 25)), 'sun');
});
t('visibleDays: enabled + any day with records, in week order', function () {
  var g = M.groupByDay([rec({ subject: 'x', day: 'fri' })]);
  assert.deepStrictEqual(M.visibleDays(['mon', 'sun'], g), ['sun', 'mon', 'fri']);
  assert.deepStrictEqual(M.visibleDays(['bad'], M.groupByDay([])), []);
});
t('days setting: none → default, ok, corrupt/newer/mismatched class → default with status, never throws', function () {
  assert.deepStrictEqual(M.parseDaysSetting(null, 'c1'), { status: 'none', days: M.DEFAULT_DAYS });
  var raw = M.serializeDaysSetting(['thu', 'sat', 'sat', 'bad'], 'c1');
  assert.deepStrictEqual(M.parseDaysSetting(raw, 'c1'), { status: 'ok', days: ['sat', 'thu'] });
  assert.strictEqual(M.parseDaysSetting(raw, 'c2').status, 'corrupt');
  assert.strictEqual(M.parseDaysSetting('{bad', 'c1').status, 'corrupt');
  assert.strictEqual(M.parseDaysSetting('[]', 'c1').status, 'corrupt');
  assert.strictEqual(M.parseDaysSetting('{"schemaVersion":1,"classId":"c1","days":[]}', 'c1').status, 'corrupt');
  assert.strictEqual(M.parseDaysSetting('{"schemaVersion":9,"classId":"c1","days":["sun"]}', 'c1').status, 'newer');
});
t('conflicts: duplicate period same day', function () {
  var l = [rec({ day: 'sun', subject: 'أ', period: 2 })];
  var c = M.findConflicts(l, { day: 'sun', period: 2 }, null);
  assert.strictEqual(c.length, 1); assert.strictEqual(c[0].type, 'period'); assert.ok(/الحصة رقم 2/.test(c[0].message) && /الأحد/.test(c[0].message) && /أ/.test(c[0].message));
  assert.strictEqual(M.findConflicts(l, { day: 'mon', period: 2 }, null).length, 0);
  assert.strictEqual(M.findConflicts(l, { day: 'sun', period: 3 }, null).length, 0);
  assert.strictEqual(M.findConflicts(l, { day: 'sun', period: null }, null).length, 0);
});
t('conflicts: time overlap (touching edges are not overlap), start-only equal start, start inside range', function () {
  var l = [rec({ day: 'sun', subject: 'أ', startTime: '08:00', endTime: '08:45' })];
  function c(s, e) { return M.findConflicts(l, { day: 'sun', startTime: s, endTime: e }, null); }
  assert.strictEqual(c('08:30', '09:15')[0].type, 'overlap');
  assert.strictEqual(c('07:30', '08:10')[0].type, 'overlap');
  assert.strictEqual(c('08:10', '08:20')[0].type, 'overlap'); // داخلها
  assert.strictEqual(c('07:00', '09:00')[0].type, 'overlap'); // تحتويها
  assert.strictEqual(c('08:45', '09:30').length, 0); assert.strictEqual(c('07:15', '08:00').length, 0);
  assert.strictEqual(c('08:00', null)[0].type, 'start'); // بداية فقط تساوي بداية حصة قائمة
  assert.strictEqual(c('08:01', null)[0].type, 'overlap'); // بداية فقط داخل الفترة
  assert.strictEqual(c('08:20', '')[0].type, 'overlap');
  assert.strictEqual(c('09:00', '').length, 0); assert.strictEqual(c('', '').length, 0);
  var l2 = [rec({ day: 'sun', subject: 'ب', startTime: '10:00' })];
  assert.strictEqual(M.findConflicts(l2, { day: 'sun', startTime: '10:00' }, null)[0].type, 'start');
  assert.strictEqual(M.findConflicts(l2, { day: 'sun', startTime: '10:05' }, null).length, 0);
  assert.strictEqual(M.findConflicts(l, { day: 'mon', startTime: '08:00', endTime: '08:45' }, null).length, 0);
});
t('conflicts: editing excludes itself; does not mutate or delete anything; messages are readable Arabic', function () {
  var a = rec({ day: 'sun', subject: 'أ', period: 1, startTime: '08:00', endTime: '08:45' }), b = rec({ day: 'sun', subject: 'ب', period: 2, startTime: '08:45', endTime: '09:30' });
  var l = [a, b], snap = JSON.stringify(l);
  assert.strictEqual(M.findConflicts(l, { day: 'sun', period: 1, startTime: '08:00', endTime: '08:45' }, a.recordId).length, 0);
  var c = M.findConflicts(l, { day: 'sun', period: 2, startTime: '08:30', endTime: '09:00' }, a.recordId);
  assert.deepStrictEqual(c.map(function (x) { return x.type; }), ['period']); // نفس الحصة تُبلَّغ مرة واحدة
  assert.strictEqual(JSON.stringify(l), snap);
  var d = M.findConflicts(l, { day: 'sun', period: 5, startTime: '08:30', endTime: '09:00' }, null);
  assert.strictEqual(d.length, 2); d.forEach(function (x) { assert.ok(/[\u0600-\u06FF]/.test(x.message) && /\d:\d\d [صم]/.test(x.message)); });
});
t('conflictSignature: same conflicts → same signature; changed times → different', function () {
  var a = rec({ day: 'sun', subject: 'أ', period: 1 }), vals = { day: 'sun', period: 1, startTime: '', endTime: '' }, c = M.findConflicts([a], vals, null);
  assert.strictEqual(M.conflictSignature(c, vals), M.conflictSignature(M.findConflicts([a], vals, null), vals));
  var v2 = { day: 'sun', period: 1, startTime: '08:00', endTime: '' };
  assert.notStrictEqual(M.conflictSignature(c, vals), M.conflictSignature(M.findConflicts([a], v2, null), v2));
});
t('subjectsOf: only the user\'s own subjects, deduped Arabic-insensitively, no built-ins', function () {
  assert.deepStrictEqual(M.subjectsOf([]), []);
  var s = M.subjectsOf([rec({ subject: 'الرياضيات', updatedAt: '2026-01-01' }), rec({ subject: 'الرياضيات ', updatedAt: '2026-01-02' }), rec({ subject: 'علوم', updatedAt: '2026-01-03' })]);
  assert.strictEqual(s.length, 2);
});
t('integration with MarsaAcademicStore: add → edit by same id → delete; no mixing across classes or other types; no auto data', function () {
  var st = S.create({ storage: fake() });
  assert.deepStrictEqual(st.readCollection('schedule', 'c1').records, []);
  var a = st.upsertRecord('schedule', 'c1', M.buildRecord(v({ subject: 'أ', period: 1, startTime: '08:00', endTime: '08:45' }).values, null));
  assert.ok(a.ok && a.created && /^sch_/.test(a.record.recordId) && a.record.classId === 'c1');
  var id = a.record.recordId, ca = a.record.createdAt;
  var g = st.getRecord('schedule', 'c1', id).record;
  var e = st.upsertRecord('schedule', 'c1', M.buildRecord(v({ day: 'mon', subject: 'ب', period: 3 }).values, g));
  assert.ok(e.ok && !e.created && e.record.recordId === id && e.record.createdAt === ca && e.record.classId === 'c1' && e.record.day === 'mon' && e.record.subject === 'ب');
  assert.strictEqual(st.readCollection('schedule', 'c1').records.length, 1);
  assert.strictEqual(st.readCollection('schedule', 'c2').records.length, 0);
  assert.strictEqual(st.readCollection('dailyLessons', 'c1').records.length, 0); assert.strictEqual(st.readCollection('preparations', 'c1').records.length, 0);
  assert.ok(!st.upsertRecord('schedule', 'c1', { recordId: 'sch_x', classId: 'c2', day: 'sun', subject: 's' }).ok);
  assert.ok(!st.upsertRecord('schedule', 'c1', { day: 'sun', subject: 's', startTime: '25:00' }).ok); // الطبقة ترفض وقتاً غير صالح
  assert.ok(st.deleteRecord('schedule', 'c1', id).ok); assert.strictEqual(st.readCollection('schedule', 'c1').records.length, 0);
});
t('write failure → no false success, nothing saved', function () {
  var be = fake(), st = S.create({ storage: be });
  st.upsertRecord('schedule', 'c1', M.buildRecord(v({ subject: 'أ' }).values, null));
  be.setItem = function () { throw new Error('quota'); };
  var r = st.upsertRecord('schedule', 'c1', M.buildRecord(v({ subject: 'ب' }).values, null));
  assert.ok(!r.ok && r.status === 'write-failed'); assert.strictEqual(st.readCollection('schedule', 'c1').records.length, 1);
});
t('model is DOM-free and has no eval/Function/innerHTML', function () {
  var src = require('fs').readFileSync(require('path').join(__dirname, '..', 'js', 'schedule-model.js'), 'utf8');
  assert.ok(!/\beval\s*\(|new Function|innerHTML|document\.|window\./.test(src));
});
console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
