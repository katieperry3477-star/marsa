// 02.01 — عزل V2 عن V1 (R-097، R-099، R-100، ADR-301، ADR-317). ساكن: لا متصفح ولا شبكة.
// التشغيل: node tests/v2/v2-isolation.test.js
'use strict';
var fs = require('fs'), path = require('path'), cp = require('child_process'), crypto = require('crypto');
var ROOT = path.join(__dirname, '..', '..'), V2 = path.join(ROOT, 'v2');
var pass = 0, fail = 0;
function t(name, ok, extra) { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra === undefined ? '' : extra); } }
function walk(d, acc) { fs.readdirSync(d).forEach(function (n) { var p = path.join(d, n); if (fs.statSync(p).isDirectory()) walk(p, acc); else acc.push(p); }); return acc; }
function rel(p) { return path.relative(ROOT, p).split(path.sep).join('/'); }
var files = walk(V2, []);
var code = files.filter(function (f) { return /\.(html|js|css|json)$/.test(f); });
var text = {}; code.forEach(function (f) { text[f] = fs.readFileSync(f, 'utf8'); });
// الوحدات المنسوخة حرفياً من V1 قد تحمل في تعليقاتها أسماء V1؛ تُفحص بقواعد منفصلة (بصمة) لا بقواعد الإشارات
var isLegacy = function (f) { return rel(f).indexOf('v2/legacy/') === 0 && /\.js$/.test(f); };
var own = code.filter(function (f) { return !isLegacy(f); });

t('v2/ موجود وفيه نقطة دخول ونصوص وثوابت', ['index.html', 'js/main.js', 'js/core/constants.js', 'js/core/storage.js', 'js/i18n/ar.js', '_headers', 'version.json', 'legacy/MANIFEST.json'].every(function (f) { return fs.existsSync(path.join(V2, f)); }));

// ===== لا إشارة إلى V1/full.html/مفاتيحهما =====
var BAD = [
  ['marsa.v1.', /marsa\.v1\./], ['marsa.academic.', /marsa\.academic\./], ['full.html', /full\.html/], ['js/app.js', /js\/app\.js/], ['css/styles.css', /css\/styles\.css/],
  ['v1-*.js', /v1-(app|boot|demo|share|store|text)/], ['v1.css', /css\/v1\.css/], ['MARSA1', /MARSA1/], ['خروج من المجلد ../..', /\.\.\/\.\.\/(?!legacy\/)/]
];
BAD.forEach(function (b) {
  var hits = own.filter(function (f) { return b[1].test(text[f]) && rel(f) !== 'v2/js/core/constants.js' && rel(f) !== 'v2/legacy/MANIFEST.json' && rel(f) !== 'v2/README.md'; }).map(rel);
  t('كود V2 لا يشير إلى ' + b[0], hits.length === 0, hits.join());
});
// الاستثناء الوحيد المسموح: constants.js يسرد البادئات المحظورة كنص للتوثيق
var cn = text[path.join(V2, 'js/core/constants.js')];
t('constants.js يحصر STORAGE_PREFIX في marsa.v2. وIDB_NAME في marsa-v2', /STORAGE_PREFIX = 'marsa\.v2\.'/.test(cn) && /IDB_NAME = 'marsa-v2'/.test(cn));
// أي استعمال لـlocalStorage/sessionStorage/indexedDB مباشرة خارج حارس التخزين ممنوع
var direct = own.filter(function (f) { return /\.js$/.test(f) && rel(f) !== 'v2/js/core/storage.js' && /\b(localStorage|sessionStorage|indexedDB)\b/.test(text[f]); }).map(rel);
t('لا وصول مباشر إلى localStorage/sessionStorage/indexedDB إلا عبر core/storage.js', direct.length === 0, direct.join());
t('كل مسارات import نسبية داخل v2 (بلا http ولا ../ تخرج منه)', own.filter(function (f) { return /\.js$/.test(f); }).every(function (f) {
  var re = /(?:import\s[^'"]*from\s*|import\s*\(\s*|import\s+)['"]([^'"]+)['"]/g, m;
  while ((m = re.exec(text[f]))) { if (!/^\.{1,2}\//.test(m[1])) return false; if (path.relative(V2, path.resolve(path.dirname(f), m[1])).indexOf('..') === 0) return false; }
  return true;
}));

// ===== CSP: لا سكربت/نمط/معالج مضمّن ولا موارد خارجية =====
var htmls = own.filter(function (f) { return /\.html$/.test(f); });
t('HTML بلا <script> مضمّن (كل سكربت بـsrc)', htmls.every(function (f) { var m = text[f].match(/<script\b[^>]*>/gi) || []; return m.every(function (s) { return /\bsrc=/.test(s); }) && !/<script\b[^>]*>\s*\S/.test(text[f].replace(/<script\b[^>]*\bsrc=[^>]*>\s*<\/script>/gi, '')); }));
t('HTML بلا <style> مضمّن ولا style="" ولا معالجات on*=', htmls.every(function (f) { return !/<style\b/i.test(text[f]) && !/\sstyle\s*=/i.test(text[f]) && !/\son[a-z]+\s*=/i.test(text[f]); }));
t('HTML بلا javascript: ولا eval/new Function في كود V2', own.every(function (f) { return !/javascript:/i.test(text[f]) && !(/\.js$/.test(f) && /\b(eval\s*\(|new Function\s*\()/.test(text[f])); }));
t('بلا innerHTML/outerHTML/insertAdjacentHTML/document.write في كود V2 (textContent فقط)', own.filter(function (f) { return /\.js$/.test(f); }).every(function (f) { return !/\.(innerHTML|outerHTML)\s*=|insertAdjacentHTML|document\.write/.test(text[f]); }));
t('لا روابط/موارد خارجية (http/https/CDN) في HTML وCSS وJS لـV2', own.every(function (f) { return /\.json$/.test(f) || !/(?:src|href)=["']https?:|url\(\s*["']?https?:|@import|from\s+['"]https?:|import\(\s*['"]https?:/i.test(text[f]); }));
var hd = fs.readFileSync(path.join(V2, '_headers'), 'utf8');
t('_headers: CSP صارمة (default-src none، script-src/style-src self، object/base/frame مقفلة)', /default-src 'none'/.test(hd) && /script-src 'self'/.test(hd) && /style-src 'self'/.test(hd) && /object-src 'none'/.test(hd) && /base-uri 'none'/.test(hd) && /frame-ancestors 'none'/.test(hd));
var hdv = hd.split('\n').filter(function (l) { return l.trim().charAt(0) !== '#'; }).join('\n');
t('_headers: بلا unsafe-inline ولا unsafe-eval ولا wildcard لـconnect-src (خارج التعليقات)', !/unsafe-inline|unsafe-eval/.test(hdv) && !/connect-src[^;\n]*\*/.test(hdv));
t('_headers: nosniff وReferrer-Policy وPermissions-Policy وno-cache لـversion.json', /nosniff/.test(hd) && /Referrer-Policy: no-referrer/.test(hd) && /Permissions-Policy/.test(hd) && /\/version\.json\s*\n\s*Cache-Control: no-cache/.test(hd));

// ===== أسرار =====
var SECRET = /(service[_-]?role|SUPABASE_[A-Z_]*KEY|sb_secret_|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}|-----BEGIN [A-Z ]*PRIVATE|AKIA[0-9A-Z]{16}|api[_-]?key\s*[:=]\s*['"][^'"]{8,})/i;
t('لا أسرار/مفاتيح في أي ملف داخل v2/', files.every(function (f) { return !/\.(html|js|css|json|md)$/.test(f) || !SECRET.test(fs.readFileSync(f, 'utf8')); }));
t('لا .env ولا مفاتيح ولا نسخ احتياطية ولا ZIP داخل v2/', files.every(function (f) { return !/(^|\/)\.env|\.(pem|key|zip|bak|sql)$/.test(f); }));
t('لا ملفات ثنائية/صور بيانات طلاب داخل v2/ (الأنواع المسموحة نصية فقط الآن)', files.every(function (f) { return /\.(html|js|css|json|md)$|_headers$/.test(f); }), files.filter(function (f) { return !/\.(html|js|css|json|md)$|_headers$/.test(f); }).map(rel).join());

// ===== V1/full.html لم يُمسّا (R-097) =====
var sums = fs.readFileSync(path.join(ROOT, 'docs/execution-v2/v1-parity.sha256'), 'utf8').trim().split('\n');
var bad = [];
sums.forEach(function (l) { var m = /^([0-9a-f]{64})  (.+)$/.exec(l); if (!m) { bad.push('تنسيق: ' + l); return; } var h = crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, m[2]))).digest('hex'); if (h !== m[1]) bad.push(m[2]); });
t('بصمات V1 وfull.html و css و js/* (' + sums.length + ' ملفاً) مطابقة لما قبل 02.01', bad.length === 0, bad.join());
var must = ['index.html', 'full.html', 'css/v1.css', 'css/styles.css', 'js/v1-app.js', 'js/v1-store.js', 'js/app.js'];
t('قائمة البصمات تشمل index.html وfull.html وv1.css وكل ملفات js/ الحالية', must.every(function (m) { return sums.some(function (l) { return l.slice(66) === m; }); }) && fs.readdirSync(path.join(ROOT, 'js')).filter(function (n) { return /\.js$/.test(n); }).every(function (n) { return sums.some(function (l) { return l.slice(66) === 'js/' + n; }); }));
var old = cp.spawnSync('sha256sum', ['-c', path.join(ROOT, 'docs/architecture/code-baseline.sha256')], { cwd: ROOT, encoding: 'utf8' });
t('بصمات الأساس القديمة 14/14 (docs/architecture/code-baseline.sha256)', old.status === 0 && (old.stdout.match(/: OK/g) || []).length === 14, old.stdout + old.stderr);
t('archive/MARSA-stage5-original.zip بصمته 24e02ba0… (R-099)', crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, 'archive/MARSA-stage5-original.zip'))).digest('hex') === '24e02ba00f252191bcac18e0a3fd36dc18a00621b7ce9f43a9bf7fb1da2b03cf');

// ===== V1 لا يعرف V2 =====
var v1files = ['index.html', 'full.html', 'css/v1.css', 'css/styles.css'].concat(fs.readdirSync(path.join(ROOT, 'js')).map(function (n) { return 'js/' + n; }));
t('لا ملف من V1/full.html يشير إلى v2/ أو marsa.v2 أو marsa-v2', v1files.every(function (f) { var s = fs.readFileSync(path.join(ROOT, f), 'utf8'); return !/(^|[^a-z0-9])v2\//i.test(s) && !/marsa\.v2|marsa-v2/.test(s); }));
t('index.html (V1) لا يحمّل شيئاً من v2/ ولا من legacy/', !/v2\/|legacy\//.test(fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8')));

// ===== حارس مفاتيح التخزين في وقت التشغيل =====
(async function () {
  var S = await import(path.join(V2, 'js/core/storage.js')), C = await import(path.join(V2, 'js/core/constants.js'));
  var mem = {}, be = { length: 0, key: function (i) { return Object.keys(mem)[i] || null; }, getItem: function (k) { return k in mem ? mem[k] : null; }, setItem: function (k, v) { mem[k] = String(v); this.length = Object.keys(mem).length; }, removeItem: function (k) { delete mem[k]; this.length = Object.keys(mem).length; } };
  mem['marsa.v1.mine'] = '[1]'; mem['marsa.academic.lessons.c1'] = '{}'; be.length = 2;
  var st = S.createStorage(be);
  t('الحارس: كتابة marsa.v2.ui تنجح وتُقرأ', st.setJSON('marsa.v2.ui', { theme: 'dark' }) === true && st.getJSON('marsa.v2.ui', null).theme === 'dark');
  ['marsa.v1.mine', 'marsa.academic.lessons.c1', 'marsa.v1.ui', 'marsa.x', 'other', '', 'marsa.v2.', null, undefined, 5].forEach(function (k) {
    var threw = 0;
    [function () { st.getJSON(k, null); }, function () { st.setJSON(k, 1); }, function () { st.remove(k); }].forEach(function (fn) { try { fn(); } catch (e) { threw++; } });
    t('الحارس يرفض (قراءة/كتابة/حذف) المفتاح ' + JSON.stringify(k), threw === 3);
  });
  t('الحارس: مفاتيح V1 لم تتغير بعد المحاولات المرفوضة', mem['marsa.v1.mine'] === '[1]' && mem['marsa.academic.lessons.c1'] === '{}');
  t('الحارس: keys() لا يعرض إلا marsa.v2.*', st.keys().every(function (k) { return k.indexOf('marsa.v2.') === 0; }) && st.keys().length === 1);
  t('الحارس: backend يرمي استثناءً (وضع خاص/حصة) لا ينهار: القراءة تُرجع القيمة الافتراضية والكتابة false', (function () { var bad = { getItem: function () { throw new Error('x'); }, setItem: function () { throw new Error('q'); }, removeItem: function () { throw new Error('x'); }, length: 0, key: function () { throw new Error('x'); } }; var s = S.createStorage(bad); return s.getJSON('marsa.v2.a', 7) === 7 && s.setJSON('marsa.v2.a', 1) === false && s.available() === false && s.keys().length === 0; })());
  t('الحارس: JSON تالف يُرجع الافتراضي ولا يرمي', (function () { mem['marsa.v2.bad'] = '{x'; return st.getJSON('marsa.v2.bad', 'dflt') === 'dflt'; })());
  t('الحارس: بلا backend (null) يعمل بلا استثناء', (function () { var s = S.createStorage(null); return s.available() === false && s.getJSON('marsa.v2.z', 1) === 1 && s.setJSON('marsa.v2.z', 1) === false; })());
  t('constants: FORBIDDEN_PREFIXES مجمّدة وتشمل marsa.v1. وmarsa.academic.', Object.isFrozen(C.FORBIDDEN_PREFIXES) && C.FORBIDDEN_PREFIXES.indexOf('marsa.v1.') > -1 && C.FORBIDDEN_PREFIXES.indexOf('marsa.academic.') > -1);

  // ===== النصوص =====
  var I = await import(path.join(V2, 'js/core/i18n.js')), keys = I.allKeys();
  var used = new Set(); [text[path.join(V2, 'index.html')], text[path.join(V2, 'js/main.js')]].forEach(function (s) { (s.match(/data-t="([^"]+)"|t\('([^']+)'\)/g) || []).forEach(function (m) { used.add(m.replace(/.*?["'(]'?([a-z0-9._]+)['")]*$/i, '$1')); }); });
  t('كل مفتاح نص مستعمل في index.html/main.js معرَّف في ar.js', Array.from(used).every(function (k) { return keys.indexOf(k) > -1; }), Array.from(used).filter(function (k) { return keys.indexOf(k) < 0; }).join());
  t('t() لمفتاح غائب يُرجع المفتاح ويُسجَّله', I.t('no.such') === 'no.such' && I.missingKeys().indexOf('no.such') > -1);
  t('نصوص data-t الافتراضية في HTML مطابقة لـar.js (لا انجراف)', (function () { var h = text[path.join(V2, 'index.html')], re = /data-t="([^"]+)"[^>]*>([^<]*)</g, m, ok = true; var ar = {}; keys.forEach(function (k) { ar[k] = I.t(k); }); while ((m = re.exec(h))) { if (ar[m[1]] !== undefined && ar[m[1]] !== m[2]) ok = false; } return ok; })());

  // ===== محمّل الوحدات القديمة: قائمة بيضاء =====
  var L = await import(path.join(V2, 'js/core/legacy-loader.js'));
  var man = JSON.parse(text[path.join(V2, 'legacy/MANIFEST.json')]);
  t('legacy-loader: الأسماء المسموحة = ملفات MANIFEST بالضبط', JSON.stringify(L.legacyNames().sort()) === JSON.stringify(man.files.map(function (f) { return f.file.replace(/\.js$/, ''); }).sort()));
  var rejected = 0; for (var bad of ['preps-model', 'v1-store', 'academic-store', '../js/app', 'app', '']) { try { await L.loadLegacy(bad, {}, {}); } catch (e) { rejected++; } }
  t('legacy-loader يرفض أي وحدة خارج القائمة (preps-model وv1-store وacademic-store ومسارات)', rejected === 6);
  console.log('\n' + pass + ' pass, ' + fail + ' fail'); process.exit(fail ? 1 : 0);
})().catch(function (e) { console.log('FAIL استثناء', e && e.stack || e); process.exit(1); });
