// 02.01 — تكافؤ الوحدات المنسوخة في v2/legacy مع أصولها في js/ (R-097، R-098، ADR-301).
// 1) البصمة والبايتات مطابقة للأصل وللـMANIFEST؛ 2) السلوك مطابق على مجموعة مدخلات ثابتة (نسخة مقابل أصل)؛ 3) تعمل كـUMD في سياق متصفح بلا module
// فتضع الاسم العام المسجَّل؛ 4) المولِّد --check؛ 5) الاختبار نفسه يكشف أي انجراف (طفرة على نسخة مؤقتة).
// التشغيل: node tests/v2/legacy-parity.test.js
'use strict';
var fs = require('fs'), path = require('path'), vm = require('vm'), os = require('os'), cp = require('child_process'), crypto = require('crypto');
var ROOT = path.join(__dirname, '..', '..'), SRC = path.join(ROOT, 'js'), DST = path.join(ROOT, 'v2', 'legacy');
var pass = 0, fail = 0;
function t(name, ok, extra) { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra === undefined ? '' : extra); } }
var sha = function (b) { return crypto.createHash('sha256').update(b).digest('hex'); };
var man = JSON.parse(fs.readFileSync(path.join(DST, 'MANIFEST.json'), 'utf8'));

t('MANIFEST: 6 وحدات منسوخة وقائمة استبعاد موثقة بسبب لكل ملف', man.files.length === 6 && man.excluded.length >= 8 && man.excluded.every(function (e) { return e.source && e.reason.length > 15; }));
t('MANIFEST: لكل وحدة اسم عام وبرومبت مالك ووصف وأجزاء معاد استعمالها وفجوات (قد تكون فارغة لـsafe-text فقط)', man.files.every(function (f) { return /^Marsa[A-Za-z]+$/.test(f.global) && /^\d\d\.\d\d/.test(f.owner_prompt) && f.purpose && f.reusable_parts && Array.isArray(f.adaptation_gaps) && (f.adaptation_gaps.length > 0 || f.file === 'safe-text.js'); }));
t('لا ملف .js في v2/legacy خارج MANIFEST ولا العكس', JSON.stringify(fs.readdirSync(DST).filter(function (n) { return /\.js$/.test(n); }).sort()) === JSON.stringify(man.files.map(function (f) { return f.file; }).sort()));
var excludedNames = ['preps-model', 'academic-store', 'v1-store', 'v1-share', 'v1-demo', 'v1-text', 'v1-app', 'v1-boot', 'app'];
t('لا وحدة مستبعدة (preps/academic-store/v1-*/app) موجودة في v2/legacy', excludedNames.every(function (n) { return !fs.existsSync(path.join(DST, n + '.js')); }));

// الأجزاء المعاد استعمالها المذكورة في MANIFEST موجودة فعلاً كتصديرات (حتى لا يوصف شيء غير موجود)
function ctxLoad(file) {
  var sb = { self: {} }; sb.self = sb; // سياق بلا module وبلا require: يُحاكي <script> عادياً
  vm.createContext(sb); vm.runInContext(fs.readFileSync(file, 'utf8'), sb, { filename: file }); return sb;
}
var SAMPLES = ['', ' ', 'x', '  مادة  الرياضيات ', '٣٠٠٠', '3000', '1,5', '12.5', '2026-11-12', '2026-02-30', 'https://example.com/a?b=1،', 'javascript:alert(1)', 'أإآ ة ى', null, undefined, 0, 7, -3, 1e12, true, [], {}, { subject: 'رياضيات', title: 'اختبار', date: '2026-11-10', studentId: 's1', score: '8', maxScore: '10', amount: '3000', purpose: 'ملزمة', status: 'present', day: 'sun', examDate: '2026-11-20' }, [{ recordId: 'a', studentId: 's1', date: '2026-11-10', status: 'absent', subject: 'رياضيات', day: 'sun', startTime: '08:00', endTime: '08:45', score: 5, maxScore: 10, amount: 1000 }, { recordId: 'b', studentId: 's2', date: '2026-11-10', status: 'present', subject: 'علوم', day: 'mon', score: 9, maxScore: 10, amount: 500 }]];
function safeCall(fn, args) { try { var r = fn.apply(null, args); return JSON.stringify(r === undefined ? '__undef__' : r); } catch (e) { return 'THROW:' + (e && e.message); } }
function battery(api) {
  var out = {}; Object.keys(api).sort().forEach(function (k) {
    var v = api[k];
    if (typeof v !== 'function') { out[k] = JSON.stringify(v); return; }
    var rs = [];
    SAMPLES.forEach(function (a) { rs.push(safeCall(v, [a])); SAMPLES.slice(0, 8).forEach(function (b) { rs.push(safeCall(v, [a, b])); }); });
    rs.push(safeCall(v, [SAMPLES[SAMPLES.length - 1], '2026-11-12', 's1'])); rs.push(safeCall(v, [SAMPLES[SAMPLES.length - 2], SAMPLES[SAMPLES.length - 1]]));
    out[k] = rs.join('\u0001');
  }); return out;
}

man.files.forEach(function (f) {
  var a = fs.readFileSync(path.join(SRC, f.file)), b = fs.readFileSync(path.join(DST, f.file));
  t(f.file + ': النسخة مطابقة بايتاً ببايت للأصل في js/', a.equals(b));
  t(f.file + ': SHA-256 يطابق MANIFEST', sha(b) === f.sha256);
  var orig = require(path.join(SRC, f.file)), copy = require(path.join(DST, f.file));
  t(f.file + ': التصديرات متطابقة الأسماء', JSON.stringify(Object.keys(orig).sort()) === JSON.stringify(Object.keys(copy).sort()));
  var bo = battery(orig), bc = battery(copy), diff = Object.keys(bo).filter(function (k) { return bo[k] !== bc[k]; });
  t(f.file + ': السلوك مطابق على ' + Object.keys(bo).length + ' تصديراً × ' + (SAMPLES.length * 9 + 2) + ' استدعاء', diff.length === 0, diff.join());
  var sb = ctxLoad(path.join(DST, f.file));
  t(f.file + ': في سياق متصفح (بلا module) يعرّف ' + f.global + ' بالتصديرات نفسها', sb[f.global] && JSON.stringify(Object.keys(sb[f.global]).sort()) === JSON.stringify(Object.keys(copy).sort()));
  var names = f.reusable_parts.match(/[A-Za-z][A-Za-z0-9_]{3,}/g) || [];
  var exp = Object.keys(copy), claimed = names.filter(function (n) { return /^[a-z]/.test(n) || /^[A-Z_]+$/.test(n); }), absent = claimed.filter(function (n) { return exp.indexOf(n) < 0; });
  t(f.file + ': كل اسم مذكور في reusable_parts تصدير فعلي', absent.length === 0, absent.join());
});

// ===== سلوك مرجعي مباشر (يثبت الفرضيات التي تبني عليها طبقات التكييف لاحقاً) =====
var P = require(path.join(DST, 'payments-model.js')), G = require(path.join(DST, 'grades-model.js')), A = require(path.join(DST, 'attendance-model.js')), S = require(path.join(DST, 'safe-text.js')), E = require(path.join(DST, 'exams-model.js')), SC = require(path.join(DST, 'schedule-model.js'));
t('payments: «٣٠٠٠» → 3000 دينار صحيح؛ كسر وسالب وصفر مرفوضة', P.parseAmount('٣٠٠٠').value === 3000 && !P.parseAmount('12.5').ok && !P.parseAmount('-5').ok && !P.parseAmount('0').ok);
t('grades: parseNumber يرفض فاصلة الآلاف العربية ويقبل الفاصلة العشرية', G.parseNumber('7,5').value === 7.5 && !G.parseNumber('١٬٠٠٠').ok);
t('attendance: الحالات الأربع للنموذج (يفتقر إلى exceptional في المخطط → فجوة موثقة)', JSON.stringify(A.STATUSES) === JSON.stringify(['present', 'absent', 'late', 'excused']) && man.files.find(function (f) { return f.file === 'attendance-model.js'; }).adaptation_gaps.some(function (g) { return /exceptional/.test(g); }));
t('safe-text: javascript: لا يصير رابطاً؛ https يصير', S.safeHref('javascript:alert(1)') === '' && S.safeHref('https://example.com/x') === 'https://example.com/x');
t('exams: title إلزامي في النموذج (فجوة موثقة مع exams V2 بلا title)', E.validate({ subject: 'رياضيات', examDate: '2026-11-20', status: 'scheduled' }, { today: '2026-11-12' }).ok === false && man.files.find(function (f) { return f.file === 'exams-model.js'; }).adaptation_gaps.some(function (g) { return /title/.test(g); }));
t('schedule: الأيام تبدأ بالأحد وتنتهي بالخميس افتراضياً', Array.isArray(SC.DEFAULT_DAYS) && SC.DEFAULT_DAYS.length === 5 && SC.DEFAULT_DAYS[0] === 'sun');

// ===== المولِّد =====
var gen = cp.spawnSync(process.execPath, [path.join(ROOT, 'scripts', 'v2-sync.js'), '--check'], { encoding: 'utf8' });
t('scripts/v2-sync.js --check ينجح (النسخ وMANIFEST وtokens.css مطابقة)', gen.status === 0, gen.stdout + gen.stderr);
var tok = fs.readFileSync(path.join(ROOT, 'v2', 'css', 'tokens.css'), 'utf8'), U = require(path.join(ROOT, 'tests', 'ui', 'ui-map-v2.js'));
t('tokens.css: كل رمز في TOKENS (فاتح وداكن) حاضر بقيمته', Object.keys(U.TOKENS.light).every(function (k) { return tok.indexOf('--' + k + ': ' + U.TOKENS.light[k] + ';') > -1; }) && Object.keys(U.TOKENS.dark).every(function (k) { return tok.indexOf('--' + k + ': ' + U.TOKENS.dark[k] + ';') > -1; }));
t('tokens.css: ثلاثة أوضاع (تلقائي بالجهاز، data-theme=light، data-theme=dark) بلا لون صلب خارج الرموز', /prefers-color-scheme:dark/.test(tok) && /\[data-theme="light"\]/.test(tok) && /:root\[data-theme="dark"\]/.test(tok));
var base = fs.readFileSync(path.join(ROOT, 'v2', 'css', 'base.css'), 'utf8');
t('base.css: لا ألوان صلبة (#rrggbb/rgb) كل لون من متغيّر', !/#[0-9a-fA-F]{3,8}\b|rgba?\(/.test(base));
t('base.css: يحترم prefers-reduced-motion', /prefers-reduced-motion:reduce/.test(base));
// 02.02: متغيّرات غير الألوان (خط، زوايا، مدد حركة…) تُعرَّف في :root داخل base.css نفسه؛ الشرط الباقي صارم: لا var() غير معرَّف في tokens.css أو base.css
var vars = (base.match(/var\(--([a-z0-9-]+)\)/g) || []).map(function (x) { return x.slice(6, -1); });
function defined(v) { return tok.indexOf('--' + v + ':') > -1 || base.indexOf('--' + v + ':') > -1; }
t('base.css: كل var(--x) معرَّف في tokens.css أو في base.css نفسه', vars.every(defined), vars.filter(function (v) { return !defined(v); }).join());
['shell.css', 'components.css'].forEach(function (f) {
  var css = fs.readFileSync(path.join(ROOT, 'v2', 'css', f), 'utf8');
  var vs = (css.match(/var\(--([a-z0-9-]+)[,)]/g) || []).map(function (x) { return x.slice(6, -1); });
  t(f + ': كل var(--x) معرَّف في tokens.css أو base.css', vs.every(defined), vs.filter(function (v) { return !defined(v); }).join());
  t(f + ': لا ألوان صلبة (#rrggbb/rgb/rgba) كل لون من متغيّر', !/#[0-9a-fA-F]{3,8}\b|rgba?\(/.test(css));
});

// ===== يكشف الانجراف (طفرة على نسخة مؤقتة) =====
var tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'marsa-parity-')), mutated = false, caught = false;
try {
  var tf = path.join(tmp, 'payments-model.js'), src = fs.readFileSync(path.join(DST, 'payments-model.js'), 'utf8');
  var mut = src.replace('MAX_AMOUNT = 999999999999', 'MAX_AMOUNT = 100000000'); mutated = mut !== src; fs.writeFileSync(tf, mut);
  var bo2 = battery(require(path.join(SRC, 'payments-model.js'))), bm = battery(require(tf));
  caught = sha(Buffer.from(mut)) !== man.files.find(function (f) { return f.file === 'payments-model.js'; }).sha256 && Object.keys(bo2).some(function (k) { return bo2[k] !== bm[k]; });
} finally { fs.rmSync(tmp, { recursive: true, force: true }); }
t('طفرة: تعديل سقف المبلغ في نسخة مؤقتة تكشفه البصمة والسلوك معاً', mutated && caught);
console.log('\n' + pass + ' pass, ' + fail + ' fail'); process.exit(fail ? 1 : 0);
