// 02.01 — اختبار متصفح لهيكل V2: يعمل تحت CSP الحقيقية من v2/_headers، لا يمسّ تخزين V1، وV1 يعمل بعد حذف v2/ (خطة الرجوع).
// تشغيل: NODE_PATH=$(npm root -g) node tests/v2/e2e-v2-foundation.playwright.js
// خادم محلي مؤقت فقط؛ بلا شبكة خارجية؛ بيانات اصطناعية. Chromium فقط (لم تُجرَّب Safari/Firefox/هاتف حقيقي).
var pw = require('playwright'), path = require('path'), http = require('http'), fs = require('fs'), os = require('os');
var ROOT = path.resolve(__dirname, '..', '..');
var pass = 0, fail = 0;
function check(name, ok, detail) { if (ok) { pass++; console.log('PASS ' + name); } else { fail++; console.log('FAIL ' + name + ' :: ' + (detail || '')); } }
var TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.md': 'text/markdown; charset=utf-8' };

// يقرأ v2/_headers (صيغة Cloudflare: مسار ثم أسطر مزاحة) ويطبّقها على /v2/*؛ هكذا تُفحص CSP الحقيقية لا نسخة مكتوبة يدوياً في الاختبار
function parseHeaders(file) {
  var rules = [], cur = null;
  fs.readFileSync(file, 'utf8').split('\n').forEach(function (l) {
    if (!l.trim() || l.trim()[0] === '#') return;
    if (/^\S/.test(l)) { cur = { pattern: l.trim(), h: {} }; rules.push(cur); }
    else if (cur) { var i = l.indexOf(':'); cur.h[l.slice(0, i).trim()] = l.slice(i + 1).trim(); }
  });
  return rules;
}
function matches(pat, p) { if (pat === '/*') return true; return pat === p; }
function serve(root, opts) {
  opts = opts || {};
  var rules = opts.headers ? parseHeaders(opts.headers) : [], log = [];
  var srv = http.createServer(function (req, res) {
    var p = decodeURIComponent(req.url.split('?')[0]); log.push(p);
    if (p === '/') p = '/index.html';
    var file = path.join(root, p), h = { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' };
    if (file.indexOf(root) !== 0 || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
    if (opts.headersPrefix && p.indexOf(opts.headersPrefix) === 0) { var rp = p.slice(opts.headersPrefix.length - 1); rules.forEach(function (r) { if (matches(r.pattern, rp)) Object.assign(h, r.h); }); }
    res.writeHead(200, h); fs.createReadStream(file).pipe(res);
  });
  return new Promise(function (ok) { srv.listen(0, '127.0.0.1', function () { ok({ srv: srv, base: 'http://localhost:' + srv.address().port, log: log }); }); });
}
var V1_SEED = { 'marsa.v1.mine': '{"schemaVersion":1,"records":[{"id":"seed00001","subject":"رياضيات","title":"تحضير اصطناعي","date":"2026-11-10","content":"محتوى اصطناعي"}]}', 'marsa.v1.ui': '{"role":"rep"}', 'marsa.academic.lessons.cls_demo': '{"schemaVersion":1,"records":[]}' };

async function newCtx(browser, o) {
  o = o || {};
  var ctx = await browser.newContext({ viewport: o.viewport || { width: 390, height: 844 }, locale: 'ar-IQ', timezoneId: 'Asia/Baghdad', colorScheme: o.scheme || 'dark', reducedMotion: 'reduce' });
  await ctx.addInitScript(function (seed) { try { if (!sessionStorage.getItem('seeded')) { Object.keys(seed).forEach(function (k) { localStorage.setItem(k, seed[k]); }); sessionStorage.setItem('seeded', '1'); } } catch (e) { /* لا شيء */ } window.__csp = []; document.addEventListener('securitypolicyviolation', function (e) { window.__csp.push(e.violatedDirective + ' ' + e.blockedURI); }); }, o.seed === false ? {} : V1_SEED);
  return ctx;
}
function watch(page, bag) {
  page.on('pageerror', function (e) { bag.errors.push('pageerror: ' + e.message); });
  page.on('console', function (m) { if (m.type() === 'error' || /Content Security Policy|Refused to/i.test(m.text())) bag.errors.push(m.type() + ': ' + m.text()); });
  page.on('requestfailed', function (r) { bag.errors.push('requestfailed: ' + r.url()); });
  page.on('request', function (r) { bag.urls.push(r.url()); });
}
async function snap(page) { return page.evaluate(function () { var o = {}; Object.keys(localStorage).sort().forEach(function (k) { o[k] = localStorage.getItem(k); }); return o; }); }
function stable(o) { var r = {}; Object.keys(o).sort().forEach(function (k) { r[k] = o[k]; }); return JSON.stringify(r); }
// full.html (قديم، لا يُعدَّل) يطلب خط Google الخارجي؛ هذا الاعتماد سابق وموثّق ولا يخص V2، فيُتجاهل فشله هنا فقط
function nonFont(a) { return a.filter(function (e) { return !/fonts\.(googleapis|gstatic)\.com|ERR_TUNNEL_CONNECTION_FAILED|ERR_INTERNET_DISCONNECTED|ERR_NAME_NOT_RESOLVED/.test(e); }); }

(async function () {
  var browser = await pw.chromium.launch();
  var S = await serve(ROOT, { headers: path.join(ROOT, 'v2', '_headers'), headersPrefix: '/v2/' });

  // ===== 1) تحميل V2 تحت CSP، فوق تخزين V1 مزروع =====
  var ctx = await newCtx(browser), page = await ctx.newPage(), bag = { errors: [], urls: [] };
  watch(page, bag);
  var resp = await page.goto(S.base + '/v2/index.html');
  await page.waitForSelector('html[data-v2="ready"]', { timeout: 8000 });
  var csp = resp.headers()['content-security-policy'] || '';
  check('V2: الاستجابة تحمل CSP الصارمة من v2/_headers (script-src self، بلا unsafe-inline)', /script-src 'self'/.test(csp) && !/unsafe-inline/.test(csp), csp);
  check('V2: لا أخطاء صفحة ولا انتهاكات CSP ولا طلبات فاشلة', bag.errors.length === 0 && (await page.evaluate(function () { return window.__csp.length; })) === 0, bag.errors.join(' | '));
  check('V2: lang=ar وdir=rtl وعنوان الصفحة من ملف النصوص', await page.evaluate(function () { return document.documentElement.lang === 'ar' && document.documentElement.dir === 'rtl' && document.title === 'اختر دوراً للعرض التجريبي — مَرسى'; })); // 02.02: الصفحة الأولى صارت منتقي الدور التجريبي بدل هيكل 02.01
  // 02.02: الهيكل الأولي استُبدل بالقشرة؛ نص «قيد التطوير» ورقم البناء صارا على الرئيسية والإعدادات (فحوص أشدّ في e2e-v2-shell)
  check('V2: المنتقي التجريبي ظاهر: h1 «اختر دوراً للعرض التجريبي» وملاحظة البيانات الوهمية', (await page.locator('h1').innerText()) === 'اختر دوراً للعرض التجريبي' && /بيانات وهمية/.test(await page.locator('.note-box').innerText()));
  var pz = await ctx.newPage(); watch(pz, bag);
  await pz.goto(S.base + '/v2/index.html?mock=student#/home'); await pz.waitForSelector('html[data-v2="ready"]');
  check('V2: النص والملاحظة «قيد التطوير وليس النسخة النهائية» ظاهران على الرئيسية', (await pz.locator('h1').innerText()) === 'الرئيسية' && /قيد التطوير وليس النسخة النهائية/.test(await pz.locator('#dev-note').innerText()));
  await pz.evaluate(function () { location.hash = '#/settings'; }); await pz.waitForSelector('#build-version');
  await pz.waitForFunction(function () { return /shell/.test(document.getElementById('build-version').textContent); }, null, { timeout: 4000 });
  check('V2: يقرأ version.json ويعرضه (في الإعدادات)', (await pz.locator('#build-version').innerText()) === '2.0.0-shell.1');
  await pz.close();
  check('V2: كل الطلبات من الأصل نفسه وتحت /v2/ فقط (لا V1 ولا full.html ولا خارجي)', bag.urls.every(function (u) { return u.indexOf(S.base + '/v2/') === 0; }), bag.urls.filter(function (u) { return u.indexOf(S.base + '/v2/') !== 0; }).join());
  var after = await snap(page);
  check('V2: لم يُغيّر ولم يُضف ولم يحذف أي مفتاح localStorage (مفاتيح V1 والأكاديمي سليمة بايتاً)', stable(after) === stable(V1_SEED), JSON.stringify(Object.keys(after)));
  var dbs = await page.evaluate(async function () { return indexedDB.databases ? (await indexedDB.databases()).map(function (d) { return d.name; }) : []; });
  check('V2: لم يُنشأ أي قاعدة IndexedDB في 02.01 (marsa-v2 تُنشأ في 03.04)', dbs.length === 0, dbs.join());
  check('V2: لا تمرير أفقي (390px)', await page.evaluate(function () { return document.documentElement.scrollWidth <= window.innerWidth; }));
  check('V2: رابط التخطّي أول عنصر قابل للتركيز', await (async function () { await page.keyboard.press('Tab'); return page.evaluate(function () { return document.activeElement && document.activeElement.classList.contains('skip'); }); })());

  // ===== 2) المظهر: تلقائي (فاتح/داكن بالجهاز) وdata-theme =====
  var themes = [];
  for (var sc of ['dark', 'light']) {
    var c2 = await newCtx(browser, { scheme: sc, seed: false }), p2 = await c2.newPage(); await p2.goto(S.base + '/v2/index.html'); await p2.waitForSelector('html[data-v2="ready"]');
    themes.push([sc, await p2.evaluate(function () { return getComputedStyle(document.body).backgroundColor; })]);
    if (sc === 'light') { await p2.evaluate(function () { document.documentElement.setAttribute('data-theme', 'dark'); }); themes.push(['light+data-theme=dark', await p2.evaluate(function () { return getComputedStyle(document.body).backgroundColor; })]); }
    if (sc === 'dark') { await p2.evaluate(function () { document.documentElement.setAttribute('data-theme', 'light'); }); themes.push(['dark+data-theme=light', await p2.evaluate(function () { return getComputedStyle(document.body).backgroundColor; })]); }
    await c2.close();
  }
  var tm = {}; themes.forEach(function (x) { tm[x[0]] = x[1]; });
  check('المظهر: داكن بالجهاز = #0B1324، فاتح = #F4F7FB', tm.dark === 'rgb(11, 19, 36)' && tm.light === 'rgb(244, 247, 251)', JSON.stringify(tm));
  check('المظهر: data-theme يغلب تفضيل الجهاز في الاتجاهين', tm['light+data-theme=dark'] === 'rgb(11, 19, 36)' && tm['dark+data-theme=light'] === 'rgb(244, 247, 251)', JSON.stringify(tm));

  // ===== 3) سطح الحاسبة =====
  var c3 = await newCtx(browser, { viewport: { width: 1280, height: 800 }, seed: false }), p3 = await c3.newPage(), b3 = { errors: [], urls: [] }; watch(p3, b3);
  await p3.goto(S.base + '/v2/index.html'); await p3.waitForSelector('html[data-v2="ready"]');
  check('الحاسبة 1280px: بلا تمرير أفقي وبلا أخطاء وعمود المنتقي ≤ 640px', b3.errors.length === 0 && await p3.evaluate(function () { return document.documentElement.scrollWidth <= window.innerWidth && document.querySelector('.page-inner').getBoundingClientRect().width <= 640; }), b3.errors.join()); // 02.02: المنتقي ≤640 (أعمدة الشاشات الأخرى ≤960 تُفحص في e2e-v2-shell)
  await c3.close();
  var c3b = await newCtx(browser, { viewport: { width: 320, height: 640 }, seed: false }), p3b = await c3b.newPage(); await p3b.goto(S.base + '/v2/index.html'); await p3b.waitForSelector('html[data-v2="ready"]');
  check('أدنى عرض 320px: بلا تمرير أفقي', await p3b.evaluate(function () { return document.documentElement.scrollWidth <= window.innerWidth; })); await c3b.close();

  // ===== 4) محمّل الوحدات القديمة وحارس التخزين داخل المتصفح تحت CSP =====
  var r = await page.evaluate(async function () {
    var L = await import('/v2/js/core/legacy-loader.js'), out = {};
    var P = await L.loadLegacy('payments-model'); out.amount = P.parseAmount('٣٠٠٠').value;
    out.again = (await L.loadLegacy('payments-model')) === P;
    out.safe = (await L.loadLegacy('safe-text')).safeHref('javascript:alert(1)');
    out.srcs = Array.prototype.map.call(document.querySelectorAll('script[src]'), function (s) { return new URL(s.src).pathname; });
    out.rejected = []; for (var n of ['preps-model', 'v1-store', 'academic-store', '../js/app']) { try { await L.loadLegacy(n); out.rejected.push(false); } catch (e) { out.rejected.push(true); } }
    var St = await import('/v2/js/core/storage.js'), st = St.browserStorage();
    out.avail = st.available(); out.write = st.setJSON('marsa.v2.ui', { theme: 'dark' }); out.read = st.getJSON('marsa.v2.ui', null);
    out.guard = []; ['marsa.v1.mine', 'marsa.academic.lessons.cls_demo', 'marsa.v1.ui'].forEach(function (k) { try { st.getJSON(k, null); out.guard.push(false); } catch (e) { out.guard.push(true); } });
    out.keys = st.keys(); out.csp = window.__csp.length; return out;
  });
  check('المتصفح: loadLegacy يحمّل payments-model تحت CSP ويعمل (٣٠٠٠ → 3000) وبلا تحميل مكرر', r.amount === 3000 && r.again === true);
  check('المتصفح: safe-text المحمَّل يرفض javascript:', r.safe === '');
  check('المتصفح: سكربتات legacy المحمَّلة من /v2/legacy/ فقط', r.srcs.every(function (s) { return /^\/v2\/(js\/main\.js|legacy\/[a-z-]+\.js)$/.test(s); }), r.srcs.join());
  check('المتصفح: الوحدات خارج القائمة مرفوضة (preps-model، v1-store، academic-store، مسار نسبي)', r.rejected.length === 4 && r.rejected.every(Boolean));
  check('المتصفح: حارس التخزين يكتب marsa.v2.ui ويقرؤه ويرفض مفاتيح V1/الأكاديمي', r.avail === true && r.write === true && r.read && r.read.theme === 'dark' && r.guard.every(Boolean));
  check('المتصفح: keys() = marsa.v2.ui فقط وV1 سليم بعد كل ذلك ولا انتهاك CSP', JSON.stringify(r.keys) === JSON.stringify(['marsa.v2.ui']) && r.csp === 0);
  var fin = await snap(page); delete fin['marsa.v2.ui'];
  check('V1 المزروع ما زال سليماً بايتاً بعد استعمال V2', stable(fin) === stable(V1_SEED));

  // ===== 5) V1 يعمل ولا يعرف V2 (نفس الأصل، نفس التخزين) =====
  var bv = { errors: [], urls: [] }; var pv = await ctx.newPage(); watch(pv, bv);
  await pv.goto(S.base + '/index.html'); await pv.waitForSelector('#app *', { timeout: 8000 });
  check('V1 (index.html) يفتح بلا أخطاء بعد زيارة V2 على الأصل نفسه', bv.errors.length === 0, bv.errors.join(' | '));
  check('V1 لا يطلب أي ملف من v2/ ولا يقرأ مفتاح marsa.v2.*', bv.urls.every(function (u) { return u.indexOf('/v2/') < 0; }) && !(await pv.evaluate(function () { return document.body.innerText.indexOf('marsa.v2') > -1; })));
  check('V1: بياناته المزروعة (mine/ui/academic) سليمة بعد فتحه', await (async function () { var s = await snap(pv); return s['marsa.v1.mine'] === V1_SEED['marsa.v1.mine'] && s['marsa.academic.lessons.cls_demo'] === V1_SEED['marsa.academic.lessons.cls_demo']; })());
  var pf = await ctx.newPage(), bf = { errors: [], urls: [] }; watch(pf, bf); await pf.goto(S.base + '/full.html'); await pf.waitForTimeout(800);
  check('full.html يفتح بلا أخطاء (عدا خط Google الخارجي السابق) ولا يطلب v2/', nonFont(bf.errors).length === 0 && bf.urls.every(function (u) { return u.indexOf('/v2/') < 0; }), bf.errors.join(' | '));
  await ctx.close();

  // ===== 6) خطة الرجوع: حذف v2/ كاملاً لا يؤثر في V1 وfull.html =====
  var tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'marsa-rollback-'));
  try {
    ['index.html', 'full.html'].forEach(function (f) { fs.copyFileSync(path.join(ROOT, f), path.join(tmp, f)); });
    ['css', 'js'].forEach(function (d) { fs.mkdirSync(path.join(tmp, d)); fs.readdirSync(path.join(ROOT, d)).forEach(function (f) { fs.copyFileSync(path.join(ROOT, d, f), path.join(tmp, d, f)); }); });
    check('الرجوع: النسخة المؤقتة بلا مجلد v2/ إطلاقاً', !fs.existsSync(path.join(tmp, 'v2')));
    var S2 = await serve(tmp), c6 = await newCtx(browser, { seed: false }), p6 = await c6.newPage(), b6 = { errors: [], urls: [] }; watch(p6, b6);
    await p6.goto(S2.base + '/index.html'); await p6.waitForSelector('#app *', { timeout: 8000 });
    check('الرجوع: V1 يعمل بلا v2/ وبلا أي 404', b6.errors.length === 0 && S2.log.every(function (u) { return u.indexOf('/v2/') < 0; }), b6.errors.join(' | '));
    var p7 = await c6.newPage(), b7 = { errors: [], urls: [] }; watch(p7, b7); await p7.goto(S2.base + '/full.html'); await p7.waitForTimeout(800);
    check('الرجوع: full.html يعمل بلا v2/', nonFont(b7.errors).length === 0, b7.errors.join(' | '));
    await c6.close(); S2.srv.close();
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }

  await browser.close(); S.srv.close();
  console.log('\n' + pass + ' pass, ' + fail + ' fail'); process.exit(fail ? 1 : 0);
})().catch(function (e) { console.log('FAIL استثناء', e && e.stack || e); process.exit(1); });
