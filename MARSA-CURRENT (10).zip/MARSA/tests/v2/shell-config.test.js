// 02.02 — اختبار ساكن ووحدات لقشرة V2: لا متصفح ولا شبكة. التشغيل: node tests/v2/shell-config.test.js
// يغطي: تطابق إعدادات التنقل المولَّدة مع خريطة الواجهات، الموجّه والحارس، تمييز التبويب الأب، الزمن العربي، المظهر وحارس التخزين،
// تغطية النصوص (ADR-320)، نظافة CSS/JS (RTL منطقي، حركة transform/opacity فقط، لا style مضمّن)، وطفرات تُثبت أن الفحوص تكشف الخلل.
'use strict';
var fs = require('fs'), path = require('path'), cp = require('child_process'), url = require('url');
var ROOT = path.join(__dirname, '..', '..'), V2 = path.join(ROOT, 'v2');
var U = require(path.join(ROOT, 'tests', 'ui', 'ui-map-v2.js'));
var pass = 0, fail = 0;
function t(name, ok, extra) { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra === undefined ? '' : extra); } }
function imp(rel) { return import(url.pathToFileURL(path.join(V2, rel)).href); }
function read(rel) { return fs.readFileSync(path.join(V2, rel), 'utf8'); }
function walk(d, acc) { fs.readdirSync(d).forEach(function (n) { var p = path.join(d, n); if (fs.statSync(p).isDirectory()) walk(p, acc); else acc.push(p); }); return acc; }
function stripJsComments(s) { return s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"\\])\/\/.*$/gm, '$1'); }

// ───────────── فاحص تطابق التنقل مع الخريطة (يُستعمل أيضاً على نسخ مطفَّرة) ─────────────
function navProblems(cfg, txt) {
  var p = [], RK = { s: 'student', r: 'rep', d: 'dev' };
  ['s', 'r', 'd'].forEach(function (k) {
    var role = RK[k], mt = U.TABBARS[k].tabs, ct = cfg.TABBARS[role] || [];
    if (ct.length !== 3 || mt.length !== 3) p.push(role + ': عدد التبويبات ليس 3');
    mt.forEach(function (tab, i) {
      var c = ct[i]; if (!c) { p.push(role + ': تبويب ناقص ' + i); return; }
      if (txt[c.label] !== tab[0]) p.push(role + ': نص التبويب ' + i);
      if (c.screen !== tab[1]) p.push(role + ': شاشة التبويب ' + i);
      if (c.icon !== tab[2]) p.push(role + ': أيقونة التبويب ' + i);
    });
    var mg = U.SIDEBARS[k], cg = cfg.SIDEBARS[role] || [];
    if (mg.length !== cg.length) p.push(role + ': عدد مجموعات القائمة');
    mg.forEach(function (g, gi) {
      var c = cg[gi]; if (!c) return;
      if (g.title ? txt[c.title] !== g.title : c.title !== null) p.push(role + ': عنوان المجموعة ' + gi);
      if (!!g.footer !== !!c.footer) p.push(role + ': تذييل المجموعة ' + gi);
      if (!!c.collapsible !== (g.title === 'ملفي')) p.push(role + ': قابلية الطي ' + gi);
      if (g.items.length !== c.items.length) { p.push(role + ': عدد بنود المجموعة ' + gi); return; }
      g.items.forEach(function (it, ii) {
        var ci = c.items[ii];
        if (it.future) { if (ci.type !== 'future' || ci.key !== it.future) p.push(role + ': بند قريباً ' + gi + '.' + ii); }
        else if (it.action) { if (ci.type !== 'action' || ci.action !== it.action || txt[ci.label] !== it.ar) p.push(role + ': إجراء ' + gi + '.' + ii); }
        else if (ci.type !== 'link' || ci.screen !== it.screen || txt[ci.label] !== it.ar) p.push(role + ': رابط ' + gi + '.' + ii);
      });
    });
  });
  U.FUTURE.forEach(function (f) {
    var c = cfg.FUTURE[f.key]; if (!c) { p.push('قريباً ناقص ' + f.key); return; }
    if (txt[c.name] !== f.ar || txt[c.note] !== f.note) p.push('نص قريباً ' + f.key);
    var want = ['student', 'rep', 'dev'].filter(function (r) { return f.roles.indexOf({ student: 's', rep: 'r', dev: 'd' }[r]) > -1; });
    if (JSON.stringify(c.roles) !== JSON.stringify(want)) p.push('أدوار قريباً ' + f.key);
  });
  if (Object.keys(cfg.FUTURE).length !== U.FUTURE.length) p.push('عدد بنود قريباً');
  U.SCREENS.forEach(function (s) {
    var c = cfg.SCREENS[s.id]; if (!c) { p.push('شاشة ناقصة ' + s.id); return; }
    var routes = s.route.split(' · ').filter(function (r) { return r.indexOf('#/') === 0; }).map(function (r) { return r.slice(1); });
    var roles = ['student', 'rep', 'dev'].filter(function (r) { return s.roles.indexOf({ student: 's', rep: 'r', dev: 'd' }[r]) > -1; });
    if (JSON.stringify(c.routes) !== JSON.stringify(routes)) p.push('مسارات ' + s.id);
    if (JSON.stringify(c.roles) !== JSON.stringify(roles)) p.push('أدوار ' + s.id);
    if (c.kind !== s.kind || c.states !== s.states || c.prompt !== s.prompt) p.push('بيانات ' + s.id);
  });
  if (cfg.HOME_CAPS.cards !== U.HOME.maxCards || cfg.HOME_CAPS.quick !== U.HOME.maxQuick) p.push('سقف الرئيسية');
  return p;
}

// ───────────── فاحص CSS ─────────────
function braceBlocks(css, atRe) {
  var out = [], m, re = new RegExp(atRe, 'g');
  while ((m = re.exec(css))) {
    var i = css.indexOf('{', m.index), d = 0, j = i;
    for (; j < css.length; j++) { if (css[j] === '{') d++; else if (css[j] === '}') { d--; if (d === 0) break; } }
    out.push(css.slice(i + 1, j));
  }
  return out;
}
var TRANS_OK = ['transform', 'opacity', 'background-color', 'color', 'border-color', 'visibility', 'grid-template-rows'];
function cssProblems(name, css0) {
  var css = css0.replace(/\/\*[\s\S]*?\*\//g, ''), p = [];
  if (/(^|[\s;{])(margin|padding)-(left|right)\s*:/.test(css)) p.push(name + ': margin/padding-left|right');
  if (/(^|[\s;{])(left|right)\s*:/.test(css)) p.push(name + ': left|right');
  if (/(^|[\s;{])border-(left|right)(-[a-z]+)?\s*:/.test(css)) p.push(name + ': border-left|right');
  if (/text-align\s*:\s*(left|right)/.test(css)) p.push(name + ': text-align left|right');
  if (/(^|[\s;{])float\s*:/.test(css)) p.push(name + ': float');
  css.replace(/transition\s*:\s*([^;}]+)/g, function (_, v) {
    v.split(/,(?![^(]*\))/).forEach(function (part) { var prop = part.trim().split(/\s+/)[0]; if (prop && prop !== 'none' && TRANS_OK.indexOf(prop) < 0) p.push(name + ': transition على ' + prop); });
    return '';
  });
  braceBlocks(css, '@keyframes\\s+[\\w-]+\\s*').forEach(function (body) {
    body.replace(/([a-z-]+)\s*:/g, function (_, prop) { if (['opacity', 'transform'].indexOf(prop) < 0) p.push(name + ': keyframes تحرّك ' + prop); return ''; });
  });
  css.replace(/font-size\s*:\s*([0-9.]+)(rem|px)/g, function (_, v, u) { var px = u === 'rem' ? parseFloat(v) * 16 : parseFloat(v); if (px < 12) p.push(name + ': خط أصغر من 12px (' + v + u + ')'); return ''; });
  css.split('}').forEach(function (rule) {
    if (/outline\s*:\s*(none|0)\b/.test(rule) && !/main/.test(rule.split('{')[0])) p.push(name + ': outline:none خارج main');
    if (/!important/.test(rule) && !/\[hidden\]|\*,\*::before|animation:none|transition:none/.test(rule)) p.push(name + ': !important غير مبرَّر');
  });
  return p;
}

(async function () {
  var C = await imp('js/ui/nav-config.js'), N = await imp('js/ui/nav.js'), R = await imp('js/ui/router.js'), T = await imp('js/ui/time.js');
  var TH = await imp('js/ui/theme.js'), ST = await imp('js/ui/store.js'), I = await imp('js/core/i18n.js'), S = await imp('js/core/storage.js');
  var A = await imp('js/i18n/ar.js'), AN = await imp('js/i18n/ar-nav.js'), M = await imp('js/data/mock.js');
  var txt = AN.arNav;

  // ===== 1) المولِّد ومصدر الحقيقة =====
  var gen = cp.spawnSync('node', [path.join(ROOT, 'scripts', 'v2-nav-sync.js'), '--check'], { encoding: 'utf8' });
  t('v2-nav-sync --check: nav-config.js وar-nav.js مطابقان للمولِّد (لا تعديل يدوي)', gen.status === 0, gen.stdout);
  t('كل شاشات الخريطة (' + U.SCREENS.length + ') موجودة في SCREENS ومطابقة مساراً ودوراً وحالات ووقت تنفيذ', navProblems(C, txt).length === 0, navProblems(C, txt).join(' | '));
  t('الأشرطة السفلية 3 عناصر لكل دور بنص وأيقونة الخريطة', ['student', 'rep', 'dev'].every(function (r) { return C.TABBARS[r].length === 3; }));
  t('كل تبويب وكل رابط قائمة يشير إلى شاشة موجودة لها مسار ويسمح بدور صاحبها', ['student', 'rep', 'dev'].every(function (r) {
    var ids = C.TABBARS[r].map(function (x) { return x.screen; });
    C.SIDEBARS[r].forEach(function (g) { g.items.forEach(function (it) { if (it.type === 'link') ids.push(it.screen); }); });
    return ids.every(function (id) { var s = C.SCREENS[id]; return s && s.routes.length > 0 && s.roles.indexOf(r) > -1; });
  }));
  t('«ملفي» هي المجموعة الوحيدة القابلة للطي (للطالب)', Object.keys(C.SIDEBARS).every(function (r) { return C.SIDEBARS[r].every(function (g) { return !g.collapsible || (r === 'student' && txt[g.title] === 'ملفي'); }); }) && C.SIDEBARS.student.some(function (g) { return g.collapsible; }));
  t('بنود «قيد التطوير» لكل دور ≡ الخريطة (الطالب 3، الممثل 4، المطوّر 4 حسب الأدوار)', ['student', 'rep', 'dev'].every(function (r) {
    var inSide = []; C.SIDEBARS[r].forEach(function (g) { g.items.forEach(function (it) { if (it.type === 'future') inSide.push(it.key); }); });
    var want = U.FUTURE.filter(function (f) { return f.roles.indexOf({ student: 's', rep: 'r', dev: 'd' }[r]) > -1; }).map(function (f) { return f.key; });
    return inSide.length === want.length && inSide.every(function (k) { return want.indexOf(k) > -1; });
  }));
  t('nav-config.js بلا حروف عربية (مفاتيح فقط) خارج التعليقات (الفاصلة العربية في «04.02، 04.03» ليست نصاً)', !/[\u0621-\u064A]/.test(stripJsComments(read('js/ui/nav-config.js'))));

  // ===== 2) الموجّه والحارس =====
  var P = R.parseHash('#/preps/today?state=error&x=%D8%A7');
  t('parseHash: المسار والاستعلام (مع فكّ الترميز)', P.path === '/preps/today' && P.query.state === 'error' && P.query.x === 'ا');
  t('parseHash: الشرطة الأخيرة تُهمل والفارغ جذر', R.parseHash('#/home/').path === '/home' && R.parseHash('').path === '/' && R.parseHash('#').path === '/');
  t('isRouteHash: #/… وفارغ مسارات؛ #main رابط داخلي لا يعالجه الموجّه', R.isRouteHash('#/home') && R.isRouteHash('') && R.isRouteHash('#') && !R.isRouteHash('#main') && !R.isRouteHash('#x'));
  function res(role, h) { return R.resolve(C.SCREENS, role, h); }
  t('#/home: الطالب SC-HOME-S والممثل SC-HOME-R والمطوّر محجوب', res('student', '#/home').screen.id === 'SC-HOME-S' && res('rep', '#/home').screen.id === 'SC-HOME-R' && res('dev', '#/home').type === 'forbidden');
  t('المسار الثابت يسبق :id (#/preps/new): الممثل نموذج التحضير والطالب محجوب لا «تفاصيل تحضير»', res('rep', '#/preps/new').screen.id === 'SC-PREP-FORM' && res('student', '#/preps/new').type === 'forbidden');
  t('#/preps/:id للجميع بمعامل id؛ #/preps/:id/edit للممثل والمطوّر فقط', res('student', '#/preps/p1').screen.id === 'SC-PREP-VIEW' && res('student', '#/preps/p1').params.id === 'p1' && res('rep', '#/preps/p1/edit').screen.id === 'SC-PREP-FORM' && res('student', '#/preps/p1/edit').type === 'forbidden');
  t('#/class/students: import ثابت يسبق :id؛ :id ملف طالب؛ :id/edit نموذج', res('rep', '#/class/students/import').screen.id === 'SC-STUDENT-IMPORT' && res('rep', '#/class/students/9').screen.id === 'SC-STUDENT-PROFILE' && res('rep', '#/class/students/9/edit').screen.id === 'SC-STUDENT-FORM' && res('rep', '#/class/students/new').screen.id === 'SC-STUDENT-FORM');
  t('الطالب على أي مسار /class أو /dev: محجوب (forbidden) بلا مطابقة شاشة', ['#/class', '#/class/students', '#/class/costs', '#/dev', '#/dev/reps', '#/dev/audit'].every(function (h) { var r = res('student', h); return r.type === 'forbidden' && r.screen === null; }));
  t('الممثل على /dev/*: محجوب؛ المطوّر على /class/*: مسموح (عرض الصف)', ['#/dev', '#/dev/support', '#/dev/backup'].every(function (h) { return res('rep', h).type === 'forbidden'; }) && res('dev', '#/class/students').type === 'ok');
  t('مسار مجهول أو بعدد مقاطع مختلف ◄ notfound؛ ترميز تالف ◄ notfound', ['#/nope', '#/preps', '#/preps/a/b/c', '#/class/unknown', '#/preps/%E0%A4%A'].every(function (h) { return res('rep', h).type === 'notfound'; }));
  t('الجذر #/ والفارغ ◄ root (يُحوَّل للرئيسية)', res('student', '#/').type === 'root' && res('student', '').type === 'root');
  t('بلا دور: لا شاشة تُعتبر مسموحة (كلها forbidden)', Object.keys(C.SCREENS).filter(function (id) { return C.SCREENS[id].routes.length; }).every(function (id) { var rt = C.SCREENS[id].routes[0].replace(/:[a-z]+/g, 'x1'); return R.resolve(C.SCREENS, null, '#' + rt).type === 'forbidden'; }));
  // خاصية شاملة: كل شاشة ومسار ودور مسموح ◄ يُحلّ إلى الشاشة نفسها؛ ودور غير مسموح ◄ forbidden
  var propBad = [];
  Object.keys(C.SCREENS).forEach(function (id) {
    var s = C.SCREENS[id];
    s.routes.forEach(function (pat) {
      var concrete = '#' + pat.replace(/:[a-z]+/g, 'x1');
      C.ROLES.forEach(function (r) {
        var out = R.resolve(C.SCREENS, r, concrete), allowed = s.roles.indexOf(r) > -1;
        if (allowed && !(out.type === 'ok' && out.screen.id === id)) propBad.push(r + ' ' + concrete + ' ◄ ' + out.type + (out.screen ? ' ' + out.screen.id : ''));
        if (!allowed && out.type === 'ok' && out.screen.id === id) propBad.push(r + ' ' + concrete + ' مسموح خطأً');
      });
    });
  });
  t('خاصية شاملة: كل (شاشة × مسار × دور) يُحلّ إلى نفسه إن سُمح وإلا لا يعرض تلك الشاشة', propBad.length === 0, propBad.slice(0, 5).join(' | '));

  // ===== 3) مساعدات التنقل =====
  var PT = {
    student: { 'SC-HOME-S': 'SC-HOME-S', 'SC-PREPS-TODAY': 'SC-PREPS-TODAY', 'SC-PREPS-TOMORROW': 'SC-PREPS-TODAY', 'SC-EXAM': 'SC-PREPS-TODAY', 'SC-PREPS-ARCHIVE': 'SC-PREPS-TODAY', 'SC-PREP-VIEW': 'SC-PREPS-TODAY', 'SC-HOMEWORK': 'SC-PREPS-TODAY', 'SC-EXAMS': 'SC-PREPS-TODAY', 'SC-PROFILE': 'SC-PROFILE', 'SC-ABSENCES-MINE': 'SC-PROFILE', 'SC-GRADES-MINE': 'SC-PROFILE', 'SC-PAYMENTS-MINE': 'SC-PROFILE', 'SC-ANNOUNCE': 'SC-HOME-S', 'SC-NOTIFS': 'SC-HOME-S', 'SC-SCHEDULE': 'SC-HOME-S', 'SC-SETTINGS': 'SC-HOME-S', 'SC-ABOUT': 'SC-HOME-S', 'SC-UPCOMING': 'SC-HOME-S', 'SC-FORBIDDEN': 'SC-HOME-S' },
    rep: { 'SC-HOME-R': 'SC-HOME-R', 'SC-CLASS-MGMT': 'SC-CLASS-MGMT', 'SC-STUDENTS': 'SC-CLASS-MGMT', 'SC-ATTENDANCE': 'SC-CLASS-MGMT', 'SC-GRADES': 'SC-CLASS-MGMT', 'SC-COSTS': 'SC-CLASS-MGMT', 'SC-EXAMS': 'SC-CLASS-MGMT', 'SC-EXAM-FORM': 'SC-CLASS-MGMT', 'SC-SCHEDULE': 'SC-CLASS-MGMT', 'SC-ANNOUNCE': 'SC-CLASS-MGMT', 'SC-ANNOUNCE-FORM': 'SC-CLASS-MGMT', 'SC-PREPS-TODAY': 'SC-PREPS-TODAY', 'SC-PREPS-TOMORROW': 'SC-PREPS-TODAY', 'SC-EXAM': 'SC-PREPS-TODAY', 'SC-PREP-VIEW': 'SC-PREPS-TODAY', 'SC-PREP-FORM': 'SC-PREPS-TODAY', 'SC-HOMEWORK': 'SC-PREPS-TODAY', 'SC-NOTIFS': 'SC-HOME-R', 'SC-PROFILE': 'SC-HOME-R', 'SC-SETTINGS': 'SC-HOME-R', 'SC-ABOUT': 'SC-HOME-R' },
    dev: { 'SC-DEV-HOME': 'SC-DEV-HOME', 'SC-REPS': 'SC-REPS', 'SC-SUPPORT': 'SC-REPS', 'SC-SYSTEM': 'SC-SYSTEM', 'SC-BACKUP': 'SC-SYSTEM', 'SC-AUDIT': 'SC-SYSTEM', 'SC-SETTINGS': 'SC-DEV-HOME', 'SC-NOTIFS': 'SC-DEV-HOME' }
  };
  var ptBad = [];
  Object.keys(PT).forEach(function (r) { Object.keys(PT[r]).forEach(function (id) { var got = N.parentTab(r, id, ''); if (got !== PT[r][id]) ptBad.push(r + '/' + id + ' ◄ ' + got + ' (المتوقع ' + PT[r][id] + ')'); }); });
  t('parentTab: التبويب الأب لكل شاشة وكل دور حسب UI-MAP §2 (' + Object.keys(PT).reduce(function (a, r) { return a + Object.keys(PT[r]).length; }, 0) + ' حالة)', ptBad.length === 0, ptBad.join(' | '));
  t('parentTab: الممثل على أي مسار /class/* ◄ إدارة الصف حتى لو لم تُذكر الشاشة', N.parentTab('rep', 'SC-X', '/class/whatever') === 'SC-CLASS-MGMT');
  t('isTabRoot: جذور التبويبات فقط تحمل سطر «قيد التطوير»', C.TABBARS.student.every(function (x) { return N.isTabRoot('student', x.screen); }) && !N.isTabRoot('student', 'SC-SETTINGS') && !N.isTabRoot('rep', 'SC-PREPS-TOMORROW'));
  t('isDeep: الجذور وصفحات التبويب بلا رجوع؛ الصفحات الأعمق بزر رجوع', !N.isDeep('student', 'SC-HOME-S') && !N.isDeep('student', 'SC-PREPS-TOMORROW') && !N.isDeep('student', 'SC-EXAM') && N.isDeep('student', 'SC-SETTINGS') && N.isDeep('rep', 'SC-STUDENTS') && N.isDeep('student', 'SC-FORBIDDEN'));
  t('titleKey: تسمية الدور تغلب عنوان الشاشة («حسابي» للممثل، «ملفي» للطالب)', txt[N.titleKey('rep', 'SC-PROFILE')] === 'حسابي' && txt[N.titleKey('student', 'SC-PROFILE')] === 'ملفي' && txt[N.titleKey('rep', 'SC-EXAMS')] === 'الامتحانات' && txt[N.titleKey('student', 'SC-EXAMS')] === 'كل الامتحانات');
  t('homeRoute: #/home للطالب والممثل و#/dev للمطوّر', N.homeRoute('student') === '/home' && N.homeRoute('rep') === '/home' && N.homeRoute('dev') === '/dev');

  // ===== 4) الزمن العربي =====
  var tf = I.tf, MIN = 60000, HR = 3600000, DAY = 86400000;
  t('pluralForm العربية: 1 مفرد، 2 مثنى، 3–10 قلة، 11+ كثرة', T.pluralForm(1) === 'one' && T.pluralForm(2) === 'two' && T.pluralForm(3) === 'few' && T.pluralForm(10) === 'few' && T.pluralForm(11) === 'many' && T.pluralForm(25) === 'many');
  var ago = function (ms) { return T.agoLabel(ms, tf); };
  t('agoLabel: الآن/دقيقة/دقيقتين/3 دقائق/11 دقيقة', ago(30000) === 'الآن' && ago(MIN) === 'قبل دقيقة' && ago(2 * MIN) === 'قبل دقيقتين' && ago(3 * MIN) === 'قبل 3 دقائق' && ago(11 * MIN) === 'قبل 11 دقيقة');
  t('agoLabel: ساعة/ساعتين/5 ساعات/23 ساعة وحد الساعة 59→60 دقيقة', ago(59 * MIN) === 'قبل 59 دقيقة' && ago(60 * MIN) === 'قبل ساعة' && ago(2 * HR) === 'قبل ساعتين' && ago(5 * HR) === 'قبل 5 ساعات' && ago(23 * HR) === 'قبل 23 ساعة');
  t('agoLabel: يوم/يومين/4 أيام/11 يوماً وحد اليوم', ago(24 * HR) === 'قبل يوم' && ago(48 * HR) === 'قبل يومين' && ago(4 * DAY) === 'قبل 4 أيام' && ago(11 * DAY) === 'قبل 11 يوماً' && ago(-5000) === 'الآن');
  t('isStale: أكثر من 24 ساعة فقط (24 ساعة بالضبط ليست قديمة)', !T.isStale(24 * HR) && T.isStale(24 * HR + 1) && !T.isStale(3 * HR));
  t('inDaysLabel: اليوم/باچر/بعد يومين/بعد 3 أيام/بعد 10 أيام/بعد 11 يوماً', [0, 1, 2, 3, 10, 11].map(function (n) { return T.inDaysLabel(n, tf); }).join('|') === 'اليوم|باچر|بعد يومين|بعد 3 أيام|بعد 10 أيام|بعد 11 يوماً');

  // ===== 5) المظهر وحارس التخزين =====
  t('normalizeTheme: القيم المجهولة والتالفة ◄ auto', ['auto', 'light', 'dark'].every(function (v) { return TH.normalizeTheme(v) === v; }) && [undefined, null, '', 'blue', 5, {}, 'DARK'].every(function (v) { return TH.normalizeTheme(v) === 'auto'; }));
  function fakeBackend(initial) { var m = Object.assign({}, initial), log = []; return { m: m, log: log, getItem: function (k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem: function (k, v) { log.push(['set', k]); m[k] = String(v); }, removeItem: function (k) { log.push(['rm', k]); delete m[k]; }, key: function (i) { return Object.keys(m)[i]; }, get length() { return Object.keys(m).length; } }; }
  var be = fakeBackend({ 'marsa.v1.ui': '{"role":"rep"}', 'marsa.v2.ui': '{"theme":"dark","other":1}' }), st = S.createStorage(be);
  t('loadPrefs يقرأ المظهر المحفوظ ولا يكتب شيئاً (لا كتابة عند الفتح)', TH.loadPrefs(st).theme === 'dark' && be.log.length === 0);
  t('loadPrefs: JSON تالف أو قيمة غريبة ◄ auto بلا استثناء', TH.loadPrefs(S.createStorage(fakeBackend({ 'marsa.v2.ui': '{oops' }))).theme === 'auto' && TH.loadPrefs(S.createStorage(fakeBackend({ 'marsa.v2.ui': '{"theme":"neon"}' }))).theme === 'auto' && TH.loadPrefs(S.createStorage(fakeBackend({}))).theme === 'auto');
  t('savePrefs يدمج ولا يمحو حقولاً أخرى ويكتب marsa.v2.ui فقط', TH.savePrefs({ theme: 'light' }, st) === true && JSON.parse(be.m['marsa.v2.ui']).theme === 'light' && JSON.parse(be.m['marsa.v2.ui']).other === 1 && be.m['marsa.v1.ui'] === '{"role":"rep"}' && be.log.every(function (e) { return e[1] === 'marsa.v2.ui'; }));
  t('UI_KEY = marsa.v2.ui (داخل بادئة V2 المسموحة)', TH.UI_KEY === 'marsa.v2.ui');
  var rootFake = { attrs: {}, setAttribute: function (k, v) { this.attrs[k] = v; }, removeAttribute: function (k) { delete this.attrs[k]; } };
  t('applyTheme: dark/light يضبط data-theme؛ auto يزيله؛ قيمة سيئة ◄ auto', TH.applyTheme('dark', rootFake) === 'dark' && rootFake.attrs['data-theme'] === 'dark' && TH.applyTheme('light', rootFake) === 'light' && rootFake.attrs['data-theme'] === 'light' && TH.applyTheme('auto', rootFake) === 'auto' && !('data-theme' in rootFake.attrs) && TH.applyTheme('zzz', rootFake) === 'auto');
  ST.set({ role: 'dev' });
  t('store.effectiveRole: وضع الدعم يغلب الدور ويعود عند إنهائه', ST.effectiveRole() === 'dev' && (ST.set({ support: { role: 'student', name: 'x', minutes: 30 } }), ST.effectiveRole() === 'student') && (ST.set({ support: null }), ST.effectiveRole() === 'dev'));
  var calls = 0, unsub = ST.subscribe(function () { calls++; }); ST.set({ online: false }); ST.set({ online: false }); unsub(); ST.set({ online: true });
  t('store.set يُخطر المشتركين عند التغيّر الفعلي فقط ويتوقف بعد الإلغاء', calls === 1);

  // ===== 6) النصوص (ADR-320) =====
  var all = Object.assign({}, A.ar, txt), allKeys = I.allKeys();
  t('i18n يدمج ar.js وar-nav.js بلا تعارض مفاتيح', Object.keys(A.ar).every(function (k) { return !(k in txt); }) && allKeys.length === Object.keys(all).length);
  var jsFiles = walk(path.join(V2, 'js'), []).filter(function (f) { return /\.js$/.test(f) && f.indexOf(path.sep + 'legacy' + path.sep) < 0 && !/i18n[\\/]ar(-nav)?\.js$/.test(f); });
  var KEY_RE = /^(app|intro|header|nav|tabbar|sidebar|role|user|future|action|offline|stamp|ago|in|write|state|toast|forbidden|notfound|mock|scaffold|support|home|quick|preps|prep|exam|notifs|settings|upcoming|about|subject|foundation|screen|tab|sb|grp)\.[a-z0-9._-]*[a-z0-9]$/i;
  var litMissing = [];
  jsFiles.forEach(function (f) { stripJsComments(fs.readFileSync(f, 'utf8')).replace(/'([^'\\\n]+)'/g, function (_, s) { if (KEY_RE.test(s) && !(s in all)) litMissing.push(path.basename(f) + ':' + s); return ''; }); });
  t('كل مفتاح نص حرفي في كود V2 معرَّف في ar.js/ar-nav.js', litMissing.length === 0, litMissing.join(','));
  var prefixes = {}; jsFiles.forEach(function (f) { stripJsComments(fs.readFileSync(f, 'utf8')).replace(/'((?:app|header|nav|role|user|future|ago|in|state|scaffold|support|home|quick|preps|prep|exam|notifs|settings|subject|screen|tab|sb|grp|action)\.[a-z0-9._-]*\.)'\s*\+/gi, function (_, s) { prefixes[s] = 1; return ''; }); });
  var dyn = [];
  Object.keys(prefixes).forEach(function (pre) {
    var expect = { 'subject.': Object.keys(M.buildData('SC-PREPS-TODAY')).length ? ['math', 'physics', 'chemistry', 'biology', 'arabic', 'english'] : [], 'role.': ['student', 'rep', 'dev'], 'user.': ['student', 'rep', 'dev'], 'settings.theme.': ['auto', 'light', 'dark'], 'support.start.': ['student', 'rep'], 'screen.': Object.keys(C.SCREENS) }[pre];
    if (expect) expect.forEach(function (k) { if (!((pre + k) in all)) dyn.push(pre + k); });
    else if (!/^(ago\.|in\.|tab\.|sb\.|grp\.|future\.|action\.)/.test(pre)) dyn.push('بادئة غير مغطاة: ' + pre);
  });
  t('المفاتيح الديناميكية (بادئة + قيمة) كلها معرَّفة (مواد، أدوار، ثيمات، شاشات، دعم)', dyn.length === 0, dyn.join(','));
  t('مفاتيح الزمن ago.*/in.* مكتملة (4 صيغ لكل وحدة)', ['minute', 'hour', 'day'].every(function (u) { return ['one', 'two', 'few', 'many'].every(function (f) { return ('ago.' + u + '.' + f) in all; }); }) && ['today', 'tomorrow', 'two', 'few', 'many'].every(function (k) { return ('in.' + k) in all; }));
  t('كل مفتاح اسم مادة في بيانات الوهم معرَّف subject.*', (function () {
    var subs = []; ['SC-PREPS-TODAY', 'SC-PREPS-TOMORROW', 'SC-EXAM'].forEach(function (id) { JSON.stringify(M.buildData(id), function (k, v) { if (k === 'subject') subs.push(v); return v; }); });
    return subs.length > 5 && subs.every(function (s) { return ('subject.' + s) in all; });
  })());
  var arabicInLogic = [];
  jsFiles.filter(function (f) { return !/data[\\/]mock\.js$/.test(f); }).forEach(function (f) {
    // رسائل أخطاء المطوّر (new Error('…')) ليست نصوصاً تُعرض للمستخدم فلا تدخل في الفحص
    var code = stripJsComments(fs.readFileSync(f, 'utf8')).replace(/new Error\((?:[^()]|\([^()]*\))*\)/g, 'new Error()');
    if (/(["'`])(?:(?!\1)[^\\\n]|\\.)*[\u0621-\u064A](?:(?!\1)[^\\\n]|\\.)*\1/.test(code)) arabicInLogic.push(path.relative(V2, f));
  });
  t('لا نص عربي حرفي داخل منطق الواجهة (ui/core/main) — النصوص كلها مفاتيح', arabicInLogic.length === 0, arabicInLogic.join(','));

  // ===== 7) نظافة JS =====
  var uiCode = jsFiles.map(function (f) { return [path.relative(V2, f), stripJsComments(fs.readFileSync(f, 'utf8'))]; });
  t('لا console.* ولا alert/confirm/prompt ولا window.open في كود V2', uiCode.every(function (c) { return !/\bconsole\.|\b(alert|confirm|prompt)\s*\(|window\.open/.test(c[1]); }));
  t('لا style مضمّن: لا setAttribute(\'style\') ولا cssText ولا style= في كود V2؛ والوحيد المسموح style.setProperty لمتغيّر --support-h في shell.js', uiCode.every(function (c) {
    if (/setAttribute\(\s*['"]style|cssText|\.style\s*=/.test(c[1])) return false;
    var uses = c[1].match(/\.style\b/g) || [];
    return c[0] === 'js/ui/shell.js' ? (uses.length === 1 && /style\.setProperty\('--support-h'/.test(c[1])) : uses.length === 0;
  }));
  t('dom.h ترفض style مضمّناً صراحة (حماية CSP)', /k === 'style'\) throw/.test(read('js/ui/dom.js')));
  t('fetch فقط في main.js (version.json)؛ لا XHR/WebSocket/EventSource/sendBeacon', uiCode.every(function (c) { return !/XMLHttpRequest|WebSocket|EventSource|sendBeacon|importScripts/.test(c[1]) && (c[0] === 'js/main.js' || !/\bfetch\s*\(/.test(c[1])); }) && /fetch\(VERSION_URL/.test(read('js/main.js')));
  t('setInterval وحيد في shell.js (مؤقت جلسة الدعم) ويُمسح عند الإنهاء والخروج', uiCode.filter(function (c) { return /setInterval/.test(c[1]); }).map(function (c) { return c[0]; }).join() === 'js/ui/shell.js' && (read('js/ui/shell.js').match(/clearInterval\(supportTimer\)/g) || []).length >= 3);
  t('الشعار من الرمز #marsa-mark المعرَّف في index.html', /#marsa-mark/.test(read('js/ui/dom.js')) && /<symbol id="marsa-mark"/.test(read('index.html')));
  t('index.html: هياكل الشاشة (قائمة، شريط تبويب، ترويسة، main، شريط الدعم) والرابط الأول skip', (function () {
    var h = read('index.html');
    return ['id="sidebar"', 'id="tabbar"', 'id="top"', 'id="main"', 'id="support-bar"', 'id="offline-bar"', 'id="toasts"', 'id="intro"', 'id="scrim"'].every(function (s) { return h.indexOf(s) > -1; }) && h.indexOf('class="skip"') < h.indexOf('id="support-bar"') && /<html lang="ar" dir="rtl">/.test(h) && /viewport-fit=cover/.test(h);
  })());

  // ===== 8) نظافة CSS =====
  var cssFiles = ['base.css', 'shell.css', 'components.css'], allProblems = [];
  cssFiles.forEach(function (f) { allProblems = allProblems.concat(cssProblems(f, read('css/' + f))); });
  t('CSS: خصائص منطقية فقط (لا left/right/float)، الانتقالات transform/opacity/ألوان/grid-rows، keyframes opacity+transform، خط ≥12px، لا outline:none ولا !important غير مبرَّر', allProblems.length === 0, allProblems.join(' | '));
  t('CSS: prefers-reduced-motion يوقف animation وtransition', /@media \(prefers-reduced-motion:reduce\)\{[^}]*animation:none !important;transition:none !important/.test(read('css/base.css').replace(/\s+/g, ' ').replace(/\{ /g, '{').replace(/ \}/g, '}')) || /prefers-reduced-motion:reduce[\s\S]*animation:none !important[\s\S]*transition:none !important/.test(read('css/base.css')));
  t('CSS: القائمة الجانبية تنزلق بـtransform وتُخفي بـvisibility (لا display) فلا تُركَّز وهي مغلقة', /\.sidebar\{[^}]*transform:translateX\(100%\)[^}]*visibility:hidden/.test(read('css/shell.css')) && /\.sidebar\[data-open="true"\]\{[^}]*transform:translateX\(0\)[^}]*visibility:visible/.test(read('css/shell.css')));
  t('CSS: مدد الحركة 100/200/180/320/240ms كما في الخريطة وسلس الحركة cubic-bezier(.2,.8,.2,1)', /--dur-fast:100ms/.test(read('css/base.css')) && /--dur-base:200ms/.test(read('css/base.css')) && /--dur-route:180ms/.test(read('css/base.css')) && /--dur-slide:320ms/.test(read('css/base.css')) && /--dur-slide-out:240ms/.test(read('css/base.css')) && /cubic-bezier\(\.2,\.8,\.2,1\)/.test(read('css/base.css')) && U.EASE !== undefined);
  t('CSS: نقطة الحاسوب 1024px تثبّت القائمة بعرض 280 وتُخفي الشريط السفلي', /@media \(min-width:1024px\)\{[^}]*\.sidebar\{width:280px/.test(read('css/shell.css')) && /\.tabbar,\.menu-btn,\.sb-close\{display:none\}/.test(read('css/shell.css')));
  t('CSS: حلقة التركيز لكل :focus-visible وعلى الخلفيات الداكنة بالذهب وعلى شريط الدعم بحبره', /:focus-visible\{outline:3px solid var\(--focus\)/.test(read('css/base.css')) && /\.top :focus-visible[^{]*\{outline-color:var\(--gold\)/.test(read('css/base.css')) && /\.support-bar :focus-visible\{outline-color:var\(--support-ink\)/.test(read('css/base.css')));

  // ===== 9) بيانات وهمية فقط =====
  var mockText = read('js/data/mock.js');
  // السلاسل النصية فقط (الأرقام الخام مدد زمنية بالميلي ثانية لا هويات)
  var mockStrings = [];
  ['SC-HOME-S', 'SC-HOME-R', 'SC-DEV-HOME', 'SC-PREPS-TODAY', 'SC-PREPS-TOMORROW', 'SC-EXAM', 'SC-NOTIFS', 'SC-STUDENTS'].forEach(function (id) { JSON.stringify(M.buildData(id, 'rep'), function (k, v) { if (typeof v === 'string') mockStrings.push(v); return v; }); });
  JSON.stringify(M.SUPPORT_TARGETS, function (k, v) { if (typeof v === 'string') mockStrings.push(v); return v; });
  var allMock = mockStrings.join(' ');
  t('بيانات الوهم: بلا روابط ولا بريد ولا أرقام هاتف/هوية طويلة؛ أسماء الدعم بعلامة «تجريبي»', !/https?:|@[a-z]/i.test(mockText) && !/https?:|@[a-z0-9]|\d{7,}/i.test(allMock) && Object.keys(M.SUPPORT_TARGETS).every(function (k) { return /تجريبي/.test(M.SUPPORT_TARGETS[k].name); }));
  t('mock.loadScreenData: لا شبكة (لا fetch()/XHR) ويسجّل الاستدعاءات للاختبار', !/\bfetch\s*\(|XMLHttpRequest/.test(stripJsComments(mockText)) && /callLog/.test(mockText));
  var cards = ['SC-HOME-S', 'SC-HOME-R', 'SC-DEV-HOME'].map(function (id) { return M.buildData(id); });
  t('بيانات الرئيسية ضمن السقف: ≤4 بطاقات (طالب ≤3، ممثل ≤3، مطوّر 4)', cards.length === 3 && !!cards[0].today && !!cards[1].alerts && cards[2].audit.length === 5 && C.HOME_CAPS.cards === 4 && C.HOME_CAPS.quick === 3);

  // ===== 10) طفرات: الفحوص تكشف الخلل =====
  var cfg2 = JSON.parse(JSON.stringify(C)), txt2 = Object.assign({}, txt);
  cfg2.TABBARS.student[1].screen = 'SC-HOME-S';
  t('طفرة: تغيير شاشة تبويب في نسخة مؤقتة يكشفه فاحص التنقل', navProblems(cfg2, txt).length > 0);
  txt2[C.TABBARS.rep[0].label] = 'غلط';
  t('طفرة: تغيير نص تبويب يكشفه الفاحص', navProblems(C, txt2).length > 0);
  var cfg3 = JSON.parse(JSON.stringify(C)); cfg3.SCREENS['SC-STUDENTS'].roles.push('student');
  t('طفرة: منح الطالب شاشة «الطلاب» يكشفه الفاحص (حارس الدور)', navProblems(cfg3, txt).length > 0 && R.resolve(cfg3.SCREENS, 'student', '#/class/students').type === 'ok');
  var cfg4 = JSON.parse(JSON.stringify(C)); cfg4.SIDEBARS.student[3].collapsible = false;
  t('طفرة: إلغاء قابلية طي «ملفي» يكشفه الفاحص', navProblems(cfg4, txt).length > 0);
  t('طفرة: CSS بـmargin-left وtransition:width وtransform خاطئ وخط 10px وoutline:none تكشفها فاحص CSS', cssProblems('x', '.a{margin-left:4px}').length === 1 && cssProblems('x', '.a{transition:width 1s}').length === 1 && cssProblems('x', '@keyframes k{from{width:0}to{opacity:1}}').length === 1 && cssProblems('x', '.a{font-size:.6rem}').length === 1 && cssProblems('x', '.a{outline:none}').length === 1 && cssProblems('x', '.a{color:red !important}').length === 1);
  t('طفرة: CSS سليم (خصائص منطقية وtransform/opacity) لا يُنتج مشاكل', cssProblems('x', '.a{margin-inline-start:4px;transition:transform 1s,opacity 1s}@keyframes k{from{opacity:0}to{opacity:1;transform:none}}').length === 0);

  console.log('\n' + pass + ' pass, ' + fail + ' fail');
  process.exit(fail ? 1 : 0);
})().catch(function (e) { console.error(e); process.exit(2); });
