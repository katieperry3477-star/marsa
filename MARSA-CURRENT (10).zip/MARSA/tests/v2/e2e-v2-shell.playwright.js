// 02.02 — اختبار متصفح لقشرة V2: يعمل تحت CSP الحقيقية من v2/_headers، ببيانات وهمية فقط، فوق تخزين V1 مزروع.
// التشغيل: NODE_PATH=$(npm root -g) node tests/v2/e2e-v2-shell.playwright.js
// خادم محلي مؤقت؛ بلا شبكة خارجية؛ Chromium فقط (Safari/Firefox/هاتف حقيقي لم تُجرَّب). لا يفتح لقطات ولا يحلّلها.
var pw = require('playwright'), path = require('path'), http = require('http'), fs = require('fs');
var ROOT = path.resolve(__dirname, '..', '..');
var U = require(path.join(ROOT, 'tests', 'ui', 'ui-map-v2.js'));
var pass = 0, fail = 0;
function check(name, ok, detail) { if (ok) { pass++; console.log('PASS ' + name); } else { fail++; console.log('FAIL ' + name + ' :: ' + (detail === undefined ? '' : detail)); if (process.env.E2E_BAIL) { console.log('BAIL عند أول فشل (E2E_BAIL=1) — لاختبارات الطفرات فقط'); process.exit(1); } } }
var TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.md': 'text/markdown; charset=utf-8' };
function parseHeaders(file) {
  var rules = [], cur = null;
  fs.readFileSync(file, 'utf8').split('\n').forEach(function (l) {
    if (!l.trim() || l.trim()[0] === '#') return;
    if (/^\S/.test(l)) { cur = { pattern: l.trim(), h: {} }; rules.push(cur); } else if (cur) { var i = l.indexOf(':'); cur.h[l.slice(0, i).trim()] = l.slice(i + 1).trim(); }
  });
  return rules;
}
function serve() {
  var rules = parseHeaders(path.join(ROOT, 'v2', '_headers')), log = [];
  var srv = http.createServer(function (req, res) {
    var p = decodeURIComponent(req.url.split('?')[0]); log.push(p);
    var file = path.join(ROOT, p), h = { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' };
    if (file.indexOf(ROOT) !== 0 || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
    if (p.indexOf('/v2/') === 0) { var rp = p.slice(3); rules.forEach(function (r) { if (r.pattern === '/*' || r.pattern === rp) Object.assign(h, r.h); }); }
    res.writeHead(200, h); fs.createReadStream(file).pipe(res);
  });
  return new Promise(function (ok) { srv.listen(0, '127.0.0.1', function () { ok({ srv: srv, base: 'http://localhost:' + srv.address().port, log: log }); }); });
}
var V1_SEED = { 'marsa.v1.mine': '{"schemaVersion":1,"records":[{"id":"seed00001","subject":"رياضيات","title":"تحضير اصطناعي"}]}', 'marsa.v1.ui': '{"role":"rep"}', 'marsa.academic.lessons.cls_demo': '{"schemaVersion":1,"records":[]}' };
async function newCtx(browser, o) {
  o = o || {};
  var ctx = await browser.newContext({ viewport: o.viewport || { width: 390, height: 844 }, locale: 'ar-IQ', timezoneId: 'Asia/Baghdad', colorScheme: o.scheme || 'dark', reducedMotion: o.motion || 'reduce' });
  await ctx.addInitScript(function (seed) { try { if (!sessionStorage.getItem('seeded')) { Object.keys(seed).forEach(function (k) { localStorage.setItem(k, seed[k]); }); sessionStorage.setItem('seeded', '1'); } } catch (e) { /* لا شيء */ } window.__csp = []; document.addEventListener('securitypolicyviolation', function (e) { window.__csp.push(e.violatedDirective + ' ' + e.blockedURI); }); }, o.seed === false ? {} : V1_SEED);
  return ctx;
}
function watch(page, bag) {
  page.on('pageerror', function (e) { bag.errors.push('pageerror: ' + e.message); });
  page.on('console', function (m) { if (m.type() === 'error' || m.type() === 'warning' || /Content Security Policy|Refused to/i.test(m.text())) bag.errors.push(m.type() + ': ' + m.text()); });
  page.on('requestfailed', function (r) { bag.errors.push('requestfailed: ' + r.url()); });
  page.on('request', function (r) { bag.urls.push(r.url()); });
}
async function snap(page) { return page.evaluate(function () { var o = {}; Object.keys(localStorage).sort().forEach(function (k) { o[k] = localStorage.getItem(k); }); return o; }); }
async function open(page, base, role, hash, noSettle) {
  await page.goto(base + '/v2/index.html' + (role ? '?mock=' + role : '') + (hash ? '#' + hash : ''));
  await page.waitForSelector('html[data-v2="ready"]', { timeout: 8000 });
  if (noSettle) await page.waitForTimeout(120); else await settle(page); // state=loading لا ينتهي عمداً
}
async function go(page, hash) { await page.evaluate(function (h) { location.hash = h; }, hash); await page.waitForTimeout(30); await settle(page); }
async function settle(page) { await page.waitForTimeout(60); await page.waitForFunction(function () { return !document.querySelector('[data-view][aria-busy="true"]'); }, null, { timeout: 6000 }); }
function T(page, sel) { return page.locator(sel).allInnerTexts().then(function (a) { return a.map(function (s) { return s.replace(/\s+/g, ' ').trim(); }); }); }
function eq(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
function sameMap(a, b) { var ka = Object.keys(a).sort(), kb = Object.keys(b).sort(); return eq(ka, kb) && ka.every(function (k) { return a[k] === b[k]; }); }
var RK = { student: 's', rep: 'r', dev: 'd' };
function mapTabs(role) { return U.TABBARS[RK[role]].tabs.map(function (t) { return t[0]; }); }
function mapSide(role) {
  var titles = [], items = [];
  U.SIDEBARS[RK[role]].forEach(function (g) {
    if (g.title) titles.push(g.title);
    g.items.forEach(function (it) { items.push(it.future ? U.FUTURE.filter(function (f) { return f.key === it.future; })[0].ar : it.ar); });
  });
  return { titles: titles, items: items };
}
// نسبة التباين الفعلية (WCAG) من الألوان المحسوبة في المتصفح لا من الرموز
async function contrast(page, sel) {
  return page.evaluate(function (s) {
    function parse(c) { var m = c.match(/rgba?\(([^)]+)\)/); if (m) { var p = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; } m = c.match(/color\(srgb ([^)]+)\)/); if (m) { var q = m[1].split(/[ \/]+/).filter(Boolean).map(Number); return { r: q[0] * 255, g: q[1] * 255, b: q[2] * 255, a: q.length > 3 ? q[3] : 1 }; } return { r: 0, g: 0, b: 0, a: 0 }; }
    function lum(c) { function f(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); } return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); }
    var el = document.querySelector(s); if (!el) return -1;
    var fg = parse(getComputedStyle(el).color), n = el, bg = { r: 255, g: 255, b: 255, a: 0 };
    while (n) { var c = parse(getComputedStyle(n).backgroundColor); if (c.a > 0.99) { bg = c; break; } n = n.parentElement; }
    if (bg.a === 0) bg = parse(getComputedStyle(document.body).backgroundColor);
    var a = lum(fg), b = lum(bg), hi = Math.max(a, b), lo = Math.min(a, b);
    return Math.round(((hi + 0.05) / (lo + 0.05)) * 100) / 100;
  }, sel);
}
// فحص تجاوز أفقي: لا شريط تمرير أفقي ولا عنصر مرئي يخرج عن عرض الشاشة (باستثناء القائمة المغلقة خارج الشاشة والرابط المخفي)
async function overflow(page) {
  return page.evaluate(function () {
    var W = window.innerWidth, bad = [];
    if (document.documentElement.scrollWidth > W + 1) bad.push('scrollWidth ' + document.documentElement.scrollWidth + '>' + W);
    document.querySelectorAll('body *').forEach(function (el) {
      var cs = getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none' || el.closest('[inert]') && el.closest('#sidebar')) return;
      if (el.closest('.skip') || el.closest('svg') && el.tagName !== 'svg') return;
      var r = el.getBoundingClientRect(); if (!r.width && !r.height) return;
      if (r.right > W + 1 || r.left < -1) bad.push((el.className && el.className.baseVal === undefined ? el.className : el.tagName) + ' ' + Math.round(r.left) + '..' + Math.round(r.right));
    });
    return bad.slice(0, 6);
  });
}
async function tapTargets(page, scope) {
  return page.evaluate(function (sc) {
    var bad = [];
    document.querySelectorAll(sc + ' a[href], ' + sc + ' button, ' + sc + ' label.radio').forEach(function (el) {
      var cs = getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none' || el.closest('[inert]')) return;
      var r = el.getBoundingClientRect(); if (!r.width && !r.height) return;
      if (Math.min(r.width, r.height) < 44) bad.push((el.getAttribute('aria-label') || el.textContent.trim()).slice(0, 20) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height));
    });
    return bad;
  }, scope);
}

(async function () {
  var browser = await pw.chromium.launch();
  var S = await serve();

  // ═════ A) الإقلاع والمنتقي (هاتف، داكن) ═════
  var ctx = await newCtx(browser), page = await ctx.newPage(), bag = { errors: [], urls: [] };
  watch(page, bag);
  var resp = await page.goto(S.base + '/v2/index.html');
  await page.waitForSelector('html[data-v2="ready"]', { timeout: 8000 });
  var before = await snap(page);
  check('A1 الاستجابة تحمل CSP الصارمة (script-src/style-src self، بلا unsafe-inline) والصفحة تعمل تحتها', /script-src 'self'/.test(resp.headers()['content-security-policy'] || '') && !/unsafe-inline/.test(resp.headers()['content-security-policy'] || '') && (await page.evaluate(function () { return window.__csp.length; })) === 0);
  check('A2 lang=ar وdir=rtl والعنوان «اختر دوراً…» والجذر data-v2=ready', (await page.evaluate(function () { return document.documentElement.lang + '|' + document.documentElement.dir + '|' + getComputedStyle(document.body).direction; })) === 'ar|rtl|rtl' && /مَرسى/.test(await page.title()));
  check('A3 المنتقي: h1 واحد وثلاثة أدوار وملاحظة «عرض تجريبي» ولا قائمة ولا شريط تبويب ولا جرس', (await page.locator('h1').count()) === 1 && (await page.locator('.role-card').count()) === 3 && eq(await T(page, '.role-card'), ['طالب', 'ممثل الصف', 'المطوّر']) && (await page.locator('#tabbar').isVisible()) === false && (await page.locator('#sidebar').isVisible()) === false && (await page.locator('.menu-btn, .bell').count()) === 0 && /بيانات وهمية/.test(await page.locator('.note-box').innerText()));
  check('A4 الشعار واسم الشعبة في الترويسة حتى قبل اختيار الدور', /مَرسى/.test(await page.locator('#top .brand-text b').innerText()) && /شعبة تجريبية/.test(await page.locator('#top .brand-text span').innerText()) && (await page.locator('#top .logo').count()) === 1);
  check('A5 لا كتابة على localStorage عند الفتح (مفاتيح V1 وغيرها كما هي ولا marsa.v2.* جديد)', JSON.stringify(before) === JSON.stringify(V1_SEED) || Object.keys(before).every(function (k) { return k in V1_SEED && before[k] === V1_SEED[k]; }), JSON.stringify(Object.keys(before)));
  await page.locator('.role-card[data-role="student"]').click();
  await page.waitForSelector('#tabbar a');
  await settle(page);
  var urlAfter = page.url();
  var after = await snap(page);
  check('A7 اختيار «طالب» ◄ ?mock=student#/home والقشرة تظهر (data-mode=role)', /\?mock=student#\/home$/.test(urlAfter) && (await page.locator('#app').getAttribute('data-mode')) === 'role' && (await page.locator('.role-card').count()) === 0);
  check('A6 الدور التجريبي لا يُخزَّن: التخزين المحلي لم يتغيّر، لا cookies، لا قواعد IndexedDB', JSON.stringify(after) === JSON.stringify(before) && (await page.evaluate(function () { return document.cookie; })) === '' && (await page.evaluate(async function () { var d = indexedDB.databases ? await indexedDB.databases() : []; return d.length; })) === 0);
  await page.reload(); await page.waitForSelector('html[data-v2="ready"]'); await settle(page);
  check('A8 إعادة التحميل تُبقي الدور (من عنوان الصفحة) على نفس المسار', (await page.locator('#app').getAttribute('data-mode')) === 'role' && /#\/home$/.test(page.url()));

  // ═════ B) قشرة كل دور (هاتف) ═════
  var roles = ['student', 'rep', 'dev'];
  for (var ri = 0; ri < roles.length; ri++) {
    var role = roles[ri], home = role === 'dev' ? '/dev' : '/home';
    await open(page, S.base, role, home);
    var tabs = await T(page, '#tabbar a');
    check('B1[' + role + '] الشريط السفلي: 3 تبويبات بنص الخريطة بالترتيب (من اليمين)', eq(tabs, mapTabs(role)), JSON.stringify(tabs));
    check('B2[' + role + '] nav بتسمية «التنقل الرئيسي» وتبويب واحد فقط aria-current وهو الرئيسية', (await page.locator('#tabbar').getAttribute('aria-label')) === 'التنقل الرئيسي' && (await page.locator('#tabbar a[aria-current="page"]').count()) === 1 && (await page.locator('#tabbar a').first().getAttribute('aria-current')) === 'page');
    var tabHrefs = await page.locator('#tabbar a').evaluateAll(function (as) { return as.map(function (a) { return a.getAttribute('href'); }); });
    check('B3[' + role + '] روابط التبويبات هاشات الموجّه (#/…) بلا إعادة تحميل', tabHrefs.every(function (h) { return /^#\//.test(h); }), tabHrefs.join());
    check('B4[' + role + '] الترويسة: القائمة ☰ والشعار + «مَرسى» + «شعبة تجريبية» والجرس بعدّاد غير المقروء', (await page.locator('#top .menu-btn').count()) === 1 && /مَرسى/.test(await page.locator('#top .brand-text b').innerText()) && /شعبة تجريبية/.test(await page.locator('#top .brand-text span').innerText()) && (await page.locator('#top .bell').getAttribute('aria-label')) === 'الإشعارات، 3 غير مقروءة' && (await page.locator('#top .badge').innerText()) === '3');
    check('B5[' + role + '] السطر الهادئ «قيد التطوير» ظاهر على الرئيسية', (await page.locator('#dev-note').isVisible()) && /قيد التطوير/.test(await page.locator('#dev-note').innerText()));
    var cards = await page.locator('[data-home-card]').count(), quick = await page.locator('[data-quick-actions] > *').count();
    var wantCards = { student: 3, rep: 3, dev: 4 }[role], wantQuick = { student: 0, rep: 3, dev: 1 }[role];
    check('B6[' + role + '] الرئيسية ضمن السقف: بطاقات ' + wantCards + ' (≤4) وأزرار سريعة ' + wantQuick + ' (≤3)', cards === wantCards && cards <= 4 && quick === wantQuick && quick <= 3, cards + '/' + quick);
    check('B7[' + role + '] h1 واحد بعنوان الدور، وعنوان التبويب (title) «… — مَرسى»', (await page.locator('main h1').count()) === 1 && /— مَرسى$/.test(await page.title()));
    // القائمة الجانبية
    await page.locator('#top .menu-btn').click();
    await page.waitForSelector('#sidebar[data-open="true"]');
    var side = mapSide(role);
    check('B8[' + role + '] القائمة: عناوين المجموعات ≡ الخريطة', eq(await T(page, '#sidebar .sb-title'), side.titles), JSON.stringify(await T(page, '#sidebar .sb-title')));
    var gotItems = await page.locator('#sidebar .sb-item').evaluateAll(function (els) { return els.map(function (e) { return (e.querySelector('span:not(.chip)') || e).textContent.trim(); }); });
    check('B9[' + role + '] القائمة: كل البنود بالترتيب ≡ الخريطة (روابط وقريباً وإجراءات)', eq(gotItems, side.items), JSON.stringify(gotItems));
    check('B10[' + role + '] بطاقة المستخدم: الاسم التجريبي وشارة الدور', /تجريبي/.test(await page.locator('#sidebar .sb-name').innerText()) && (await page.locator('#sidebar [data-role-badge]').getAttribute('data-role-badge')) === role);
    var futCount = await page.locator('#sidebar .sb-future').count(), wantFut = U.FUTURE.filter(function (f) { return f.roles.indexOf(RK[role]) > -1; }).length;
    check('B11[' + role + '] بنود «قيد التطوير»: ' + wantFut + ' بشارة نصية ظاهرة (لا لون وحده)', futCount === wantFut && (await page.locator('#sidebar .sb-future .chip').allInnerTexts()).every(function (s) { return /قيد التطوير/.test(s); }));
    check('B12[' + role + '] عنصر الرئيسية في القائمة aria-current=page', (await page.locator('#sidebar .sb-item[aria-current="page"]').count()) === 1);
    await page.keyboard.press('Escape');
    await page.waitForSelector('#sidebar[data-open="false"]', { state: 'attached' });
  }

  // ═════ C) التنقل والتبويب الأب والرجوع ═════
  await open(page, S.base, 'student', '/home');
  await page.locator('#tabbar a', { hasText: 'التحاضير' }).click(); await settle(page);
  check('C1 الطالب: تبويب «التحاضير» ◄ #/preps/today وعنوان «شنو أخذنا اليوم؟» وبطاقات التحاضير', /#\/preps\/today$/.test(page.url()) && (await page.locator('main h1').innerText()) === 'شنو أخذنا اليوم؟' && (await page.locator('.prep').count()) === 4);
  check('C2 الصفحات الثلاث: شريط داخلي بثلاثة روابط (اليوم · باچر · هل عدنا امتحان؟) والأول aria-current ومؤشره عند 1', eq(await T(page, '.seg a'), ['شنو أخذنا اليوم؟', 'شنو عدنا باچر؟', 'هل عدنا امتحان؟']) && (await page.locator('.seg a[aria-current="page"]').innerText()) === 'شنو أخذنا اليوم؟' && (await page.locator('.seg').getAttribute('data-idx')) === '1');
  await page.evaluate(function () { document.querySelector('.seg').setAttribute('data-marker', 'same-node'); });
  var x1 = await page.locator('.seg-ind').evaluate(function (e) { return e.getBoundingClientRect().left; });
  await page.locator('.seg a').nth(1).click(); await settle(page); await page.waitForTimeout(260);
  var x2 = await page.locator('.seg-ind').evaluate(function (e) { return e.getBoundingClientRect().left; });
  await page.locator('.seg a').nth(2).click(); await settle(page); await page.waitForTimeout(260);
  var x3 = await page.locator('.seg-ind').evaluate(function (e) { return e.getBoundingClientRect().left; });
  check('C3 المؤشر ينزلق نحو اليسار مع الاتجاه RTL (x1 > x2 > x3) والعنصر نفسه لم يُعَد بناؤه', x1 > x2 && x2 > x3 && (await page.locator('.seg').getAttribute('data-marker')) === 'same-node' && (await page.locator('.seg').getAttribute('data-idx')) === '3', [x1, x2, x3].join());
  check('C4 الامتحان: «إي، عدنا امتحان» + المادة + الوقت، والتبويب السفلي ما زال «التحاضير»', /إي، عدنا امتحان/.test(await page.locator('[data-answer="yes"]').innerText()) && (await page.locator('#tabbar a[aria-current="page"]').innerText()) === 'التحاضير');
  var parent = [['student', '/homework', 'التحاضير'], ['student', '/exams', 'التحاضير'], ['student', '/preps/p1', 'التحاضير'], ['student', '/settings', 'الرئيسية'], ['student', '/notifications', 'الرئيسية'], ['student', '/me/grades', 'ملفي'], ['rep', '/class/students', 'إدارة الصف'], ['rep', '/class/costs', 'إدارة الصف'], ['rep', '/exams', 'إدارة الصف'], ['rep', '/announcements', 'إدارة الصف'], ['rep', '/preps/new', 'التحاضير'], ['rep', '/homework', 'التحاضير'], ['rep', '/settings', 'الرئيسية'], ['dev', '/dev/support', 'الممثلون'], ['dev', '/dev/audit', 'النظام'], ['dev', '/dev/backup', 'النظام'], ['dev', '/settings', 'لوحة التحكم']];
  var parentBad = [];
  for (var pi = 0; pi < parent.length; pi++) { await open(page, S.base, parent[pi][0], parent[pi][1]); var cur = await T(page, '#tabbar a[aria-current="page"]'); if (!(cur.length === 1 && cur[0] === parent[pi][2])) parentBad.push(parent[pi].join(' ') + ' ◄ ' + cur.join('/')); }
  check('C5 التبويب الأب لـ' + parent.length + ' شاشة عميقة حسب UI-MAP §2', parentBad.length === 0, parentBad.join(' | '));
  await open(page, S.base, 'student', '/home'); await go(page, '/settings');
  check('C6 الشاشة العميقة (الإعدادات): زر رجوع مسمّى على يمين العنوان (RTL) والسطر «قيد التطوير» مخفي', (await page.locator('.back').getAttribute('aria-label')) === 'رجوع' && (await page.locator('.back').evaluate(function (b) { return b.getBoundingClientRect().left > document.querySelector('main h1').getBoundingClientRect().left; })) && (await page.locator('#dev-note').isHidden()));
  await page.locator('.back').click(); await page.waitForTimeout(80);
  check('C7 زر الرجوع يعيد المسار السابق داخل التطبيق (#/home)', /#\/home$/.test(page.url()));
  await open(page, S.base, 'student', '/settings');
  await page.locator('.back').click(); await page.waitForTimeout(80);
  check('C8 فتح شاشة عميقة مباشرة ثم «رجوع»: يذهب للرئيسية لا يخرج من التطبيق', /#\/home$/.test(page.url()));
  await open(page, S.base, 'student', '/home'); await page.reload(); await page.waitForSelector('html[data-v2="ready"]'); await settle(page);
  await page.keyboard.press('Tab');
  var firstFocus = await page.evaluate(function () { return document.activeElement.className; });
  await page.keyboard.press('Enter');
  check('C9 أول Tab = رابط «تخطَّ إلى المحتوى»؛ Enter ينقل التركيز إلى main بلا تغيير الهاش', /skip/.test(firstFocus) && (await page.evaluate(function () { return document.activeElement.id; })) === 'main' && /#\/home$/.test(page.url()));
  await page.locator('#tabbar a', { hasText: 'ملفي' }).click(); await settle(page);
  check('C10 بعد كل تنقل ينتقل التركيز إلى h1 الصفحة (قارئ الشاشة)', (await page.evaluate(function () { return document.activeElement.tagName + '|' + document.activeElement.parentElement.className; })) === 'H1|page-head');
  await page.evaluate(function () { location.hash = '#main'; }); await page.waitForTimeout(80);
  check('C11 الهاش #main (رابط داخلي) لا يعالجه الموجّه: الصفحة نفسها لا تتبدل', (await page.locator('main h1').innerText()) === 'ملفي');
  await open(page, S.base, 'student', '/');
  check('C12 المسار #/ يُحوَّل إلى الرئيسية (replace لا push)', /#\/home$/.test(page.url()));

  // ═════ D) الحارس ═════
  await open(page, S.base, 'student', '/home');
  await page.evaluate(async function () { (await import('/v2/js/data/mock.js')).resetCallLog(); });
  await go(page, '/class/students');
  var calls = await page.evaluate(async function () { return (await import('/v2/js/data/mock.js')).callLog(); });
  check('D1 الطالب على #/class/students: شاشة «غير متاح لحسابك» بنص عام وبلا أي طلب بيانات', (await page.locator('[data-state="forbidden"]').count()) === 1 && /غير متاحة لحسابك/.test(await page.locator('[data-state="forbidden"]').innerText()) && (await page.locator('main h1').innerText()) === 'غير متاح لحسابك' && calls.length === 0, JSON.stringify(calls));
  check('D2 شاشة الحجب لا تكشف أسماء الأقسام المحجوبة ولا قوائم الممثل (لا «الطلاب» ولا «الحضور»)', !/الطلاب|الحضور|التكاليف|الممثلون/.test(await page.locator('main').innerText()));
  await page.locator('[data-state="forbidden"] a.btn').click(); await settle(page);
  check('D3 زر العودة من الحجب يعيد للرئيسية', /#\/home$/.test(page.url()) && (await page.locator('[data-home-card]').count()) === 3);
  await go(page, '/dev/audit');
  check('D4 الطالب على #/dev/audit: محجوب أيضاً؛ التبويب السفلي لا يُضيء قسماً محجوباً', (await page.locator('[data-state="forbidden"]').count()) === 1 && (await T(page, '#tabbar a[aria-current="page"]'))[0] === 'الرئيسية');
  await go(page, '/preps/new');
  check('D5 الطالب على #/preps/new: محجوب (المسار الثابت يسبق :id فلا تظهر «تفاصيل تحضير» بمعرّف new)', (await page.locator('[data-state="forbidden"]').count()) === 1);
  await open(page, S.base, 'rep', '/dev');
  check('D6 الممثل على #/dev: محجوب', (await page.locator('[data-state="forbidden"]').count()) === 1);
  await go(page, '/nope/zzz');
  check('D7 مسار مجهول: «الصفحة غير موجودة» وزر العودة يعمل', (await page.locator('[data-state="notfound"]').count()) === 1 && /الصفحة غير موجودة/.test(await page.locator('main h1').innerText()));
  await page.locator('[data-state="notfound"] a.btn').click(); await settle(page);
  check('D8 العودة من «غير موجودة» ◄ الرئيسية', /#\/home$/.test(page.url()));
  await open(page, S.base, 'dev', '/class/students');
  check('D9 المطوّر على #/class/students: مسموح (عرض الصف) بشاشة هيكلية وملاحظة البرومبت', (await page.locator('[data-state="forbidden"]').count()) === 0 && /05\.01/.test(await page.locator('.note-box').innerText()));

  // ═════ E) القائمة الجانبية (هاتف) ═════
  await open(page, S.base, 'student', '/home');
  var closed = await page.evaluate(function () { var s = document.getElementById('sidebar'); return { open: s.getAttribute('data-open'), inert: s.hasAttribute('inert'), vis: getComputedStyle(s).visibility, role: s.getAttribute('role') }; });
  check('E1 مغلقة افتراضياً: data-open=false وinert وvisibility:hidden (لا تُركَّز ولا تُقرأ)', closed.open === 'false' && closed.inert && closed.vis === 'hidden');
  await page.evaluate(function () { document.querySelector('#sidebar a').focus(); });
  check('E2 التركيز البرمجي لا يدخل قائمة مغلقة', (await page.evaluate(function () { return !!document.activeElement.closest('#sidebar'); })) === false);
  await page.locator('#top .menu-btn').click(); await page.waitForSelector('#sidebar[data-open="true"]'); await page.waitForTimeout(360);
  var op = await page.evaluate(function () { var s = document.getElementById('sidebar').getBoundingClientRect(), W = innerWidth; return { right: Math.round(s.right), left: Math.round(s.left), w: Math.round(s.width), role: document.getElementById('sidebar').getAttribute('role'), modal: document.getElementById('sidebar').getAttribute('aria-modal'), exp: document.querySelector('.menu-btn').getAttribute('aria-expanded'), mainInert: document.getElementById('app-main').hasAttribute('inert'), scrim: document.getElementById('scrim').getAttribute('data-open'), inSide: !!document.activeElement.closest('#sidebar'), W: W }; });
  check('E3 عند الفتح: تلتصق باليمين (RTL)، عرضها ≤ min(320, 86vw)، role=dialog وaria-modal وaria-expanded، الخلفية inert، الستار ظاهر', op.right === op.W && op.w <= 320 && op.w <= Math.round(op.W * 0.86) + 1 && op.left >= 0 && op.role === 'dialog' && op.modal === 'true' && op.exp === 'true' && op.mainInert && op.scrim === 'true', JSON.stringify(op));
  check('E4 التركيز ينتقل إلى داخل القائمة عند الفتح', op.inSide);
  await page.keyboard.press('Escape'); await page.waitForSelector('#sidebar[data-open="false"]', { state: 'attached' });
  check('E5 Esc يغلقها ويعيد التركيز إلى زر ☰ ويزيل inert عن الخلفية', (await page.evaluate(function () { return document.activeElement.className.indexOf('menu-btn') > -1 && !document.getElementById('app-main').hasAttribute('inert') && document.querySelector('.menu-btn').getAttribute('aria-expanded') === 'false'; })));
  await page.locator('#top .menu-btn').click(); await page.waitForSelector('#sidebar[data-open="true"]'); await page.waitForTimeout(340);
  await page.mouse.click(40, 600); await page.waitForSelector('#sidebar[data-open="false"]', { state: 'attached' });
  check('E6 النقر على الستار خارج القائمة يغلقها ويعيد التركيز لزر ☰', (await page.locator('#sidebar').getAttribute('data-open')) === 'false' && (await page.locator('#scrim').getAttribute('data-open')) === 'false' && (await page.evaluate(function () { return document.activeElement.className.indexOf('menu-btn') > -1; })));
  await page.locator('#top .menu-btn').click(); await page.waitForSelector('#sidebar[data-open="true"]'); await page.waitForTimeout(340);
  var nF = await page.locator('#sidebar a[href], #sidebar button').count(), escaped = 0;
  for (var k = 0; k < nF + 3; k++) { await page.keyboard.press('Tab'); if (!(await page.evaluate(function () { return !!document.activeElement.closest('#sidebar'); }))) escaped++; }
  await page.keyboard.press('Shift+Tab');
  check('E7 حبس التركيز: Tab ' + (nF + 3) + ' مرة (وShift+Tab) لا يخرج من القائمة', escaped === 0 && (await page.evaluate(function () { return !!document.activeElement.closest('#sidebar'); })));
  await page.locator('#sidebar .sb-item[data-screen="SC-SETTINGS"]').click(); await settle(page);
  check('E8 اختيار بند ينقل إلى المسار ويغلق القائمة ويضيء البند aria-current', /#\/settings$/.test(page.url()) && (await page.locator('#sidebar').getAttribute('data-open')) === 'false');
  await page.locator('#top .menu-btn').click(); await page.waitForSelector('#sidebar[data-open="true"]'); await page.waitForTimeout(340);
  check('E9 بند الإعدادات يحمل aria-current=page داخل القائمة', (await page.locator('#sidebar .sb-item[aria-current="page"]').getAttribute('data-screen')) === 'SC-SETTINGS');
  // مجموعة «ملفي» القابلة للطي
  var tg = page.locator('#sidebar .sb-toggle');
  var hOpen = await page.locator('#sidebar .expand').first().evaluate(function (e) { return e.getBoundingClientRect().height; });
  await tg.click(); await page.waitForTimeout(300);
  var hShut = await page.locator('#sidebar .expand').first().evaluate(function (e) { return e.getBoundingClientRect().height; });
  check('E10 «ملفي» قابلة للطي: aria-expanded يتبدل والارتفاع يصير 0 والبنود غير قابلة للتركيز (inert)', (await tg.getAttribute('aria-expanded')) === 'false' && hOpen > 40 && hShut < 1 && (await page.locator('#sidebar .expand').first().locator('.expand-in').evaluate(function (e) { return e.hasAttribute('inert'); })));
  await tg.click(); await page.waitForTimeout(300);
  check('E11 وتُفتح من جديد', (await tg.getAttribute('aria-expanded')) === 'true' && (await page.locator('#sidebar .expand').first().evaluate(function (e) { return e.getBoundingClientRect().height; })) > 40);
  var fut = page.locator('#sidebar .sb-future').first(), hashBefore = page.url();
  var futH = function () { return fut.evaluate(function (b) { return document.getElementById(b.getAttribute('aria-controls')).getBoundingClientRect().height; }); };
  var h0 = await futH();
  await fut.click(); await page.waitForTimeout(320);
  var h1 = await futH();
  check('E12 بند «قيد التطوير»: يتوسّع بوصف («… قيد التطوير ولم يُفعَّل بعد.») ويُحدّث aria-expanded ولا ينتقل', (await fut.getAttribute('aria-expanded')) === 'true' && h0 < 1 && h1 > 20 && /قيد التطوير ولم يُفعَّل بعد/.test(await page.locator('#sidebar .fut-text').first().innerText()) && page.url() === hashBefore, h0 + '/' + h1);
  await fut.click(); await page.waitForTimeout(320);
  check('E13 ويُطوى من جديد (الارتفاع 0 والمحتوى inert)', (await fut.getAttribute('aria-expanded')) === 'false' && (await futH()) < 1 && (await fut.evaluate(function (b) { return document.getElementById(b.getAttribute('aria-controls')).firstChild.hasAttribute('inert'); })));
  var lock = page.locator('#sidebar [data-action="lock"]'), ur = page.url();
  await lock.click({ force: true }); await page.waitForTimeout(120);
  check('E14 «قفل التطبيق» معطّل بسبب ظاهر نصّاً (aria-disabled) ولا يفعل شيئاً عند النقر', (await lock.getAttribute('aria-disabled')) === 'true' && /يتوفر مع نظام الحسابات/.test(await page.locator('#sidebar .sb-note').innerText()) && page.url() === ur && (await page.locator('.toast').count()) === 0);
  var tt = await tapTargets(page, '#sidebar');
  check('E15 أهداف اللمس داخل القائمة ≥44px', tt.length === 0, tt.join(' | '));
  await page.locator('#sidebar [data-action="logout"]').click(); await page.waitForSelector('.role-card');
  check('E16 «تسجيل الخروج» (تجريبي) يعيد المنتقي ويمسح ?mock من العنوان ويخفي القائمة والشريط', !/mock=/.test(page.url()) && (await page.locator('#tabbar').isVisible()) === false && (await page.locator('#sidebar').isVisible()) === false && (await page.locator('.role-card').count()) === 3);

  // ═════ F) الحالات ═════
  await open(page, S.base, 'student', '/preps/today?state=loading', true); await page.waitForTimeout(900);
  check('F1 التحميل: هيكل بنفس هندسة المحتوى (3 كتل) وaria-busy=true ولا يتحول لمحتوى ولا يوجد دوّار فقط', (await page.locator('[data-skeleton="cards"] .skel').count()) === 3 && (await page.locator('[data-view]').getAttribute('aria-busy')) === 'true' && (await page.locator('.prep').count()) === 0);
  check('F2 الهيكل مخفي عن قارئ الشاشة (aria-hidden) وسرعة نبض ثابتة 7 دورات (≈8.4s ثم يتوقف)', (await page.locator('[data-skeleton]').getAttribute('aria-hidden')) === 'true');
  await open(page, S.base, 'student', '/preps/today');
  check('F3 الوضع الطبيعي: يختفي الهيكل وتظهر البطاقات (4) وتُزال aria-busy', (await page.locator('[data-skeleton]').count()) === 0 && (await page.locator('.prep').count()) === 4 && (await page.locator('[data-view]').getAttribute('aria-busy')) === null);
  await open(page, S.base, 'student', '/preps/today?state=empty');
  check('F4 الفراغ (طالب): «ما كو تحاضير اليوم بعد.» بأيقونة بلا زر إجراء', /ما كو تحاضير اليوم بعد\./.test(await page.locator('[data-state="empty"]').innerText()) && (await page.locator('[data-state="empty"] .btn').count()) === 0 && (await page.locator('.sticky-actions > *').count()) === 0);
  await open(page, S.base, 'rep', '/preps/today?state=empty');
  check('F5 الفراغ (ممثل): نفس النص + زر «أضف أول تحضير» فعّال يذهب إلى #/preps/new', (await page.locator('[data-state="empty"] a.btn').innerText()) === 'أضف أول تحضير' && (await page.locator('[data-state="empty"] a.btn').getAttribute('href')) === '#/preps/new');
  await open(page, S.base, 'student', '/preps/today?state=error');
  var alertEl = page.locator('.alert-error');
  check('F6 الخطأ: role=alert بنص «تعذّر التحميل.» وزر «إعادة المحاولة» ولا يُعرض أي محتوى', (await alertEl.getAttribute('role')) === 'alert' && /تعذّر التحميل\./.test(await alertEl.innerText()) && (await alertEl.locator('button').innerText()) === 'إعادة المحاولة' && (await page.locator('.prep').count()) === 0);
  await alertEl.locator('button').click(); await settle(page);
  check('F7 إعادة المحاولة بعد خطأ دائم: يعود الخطأ لا حلقة صامتة', (await page.locator('.alert-error').count()) === 1);
  await open(page, S.base, 'student', '/preps/today?state=flaky');
  check('F8 flaky: أول طلب يفشل ◄ زر إعادة المحاولة ◄ ينجح ويعرض المحتوى', (await page.locator('.alert-error').count()) === 1);
  await page.locator('.alert-error button').click(); await settle(page);
  check('F9 بعد إعادة المحاولة تظهر البطاقات ويختفي التنبيه', (await page.locator('.prep').count()) === 4 && (await page.locator('.alert-error').count()) === 0);
  await open(page, S.base, 'student', '/preps/today?state=offline');
  check('F10 دون اتصال (محاكاة): شريط «دون اتصال — تعرض آخر بيانات محفوظة» وختم «آخر تحديث: قبل 3 ساعات» والمحتوى المخزَّن ظاهر', (await page.locator('#offline-bar').isVisible()) && /دون اتصال/.test(await page.locator('#offline-bar').innerText()) && /آخر تحديث: قبل 3 ساعات/.test(await page.locator('.stamp').innerText()) && (await page.locator('.stamp').getAttribute('data-stamp')) === 'fresh' && (await page.locator('.prep').count()) === 4);
  await open(page, S.base, 'student', '/preps/today?state=stale');
  check('F11 بيانات أقدم من 24 ساعة: ختم بتحذير نصّي «البيانات قديمة» (لا لون وحده)', (await page.locator('.stamp').getAttribute('data-stamp')) === 'stale' && /البيانات قديمة/.test(await page.locator('.stamp .chip').innerText()) && /قبل يوم/.test(await page.locator('.stamp').innerText()));
  await open(page, S.base, 'rep', '/preps/today?state=offline');
  var wd = page.locator('.sticky-actions [data-write="disabled"]'), urlW = page.url();
  check('F12 الكتابة دون اتصال: زر «تحضير» aria-disabled مع سبب ظاهر «يحتاج اتصالاً بالإنترنت» (aria-describedby) ولا ينتقل عند النقر', (await wd.count()) === 1 && (await wd.locator('button').getAttribute('aria-disabled')) === 'true' && /يحتاج اتصالاً بالإنترنت/.test(await wd.innerText()) && (await wd.locator('button').getAttribute('aria-describedby')) === (await wd.locator('.write-reason').getAttribute('id')));
  await wd.locator('button').click({ force: true }); await page.waitForTimeout(100);
  check('F13 النقر على الزر المعطّل لا يغيّر المسار ولا يعرض toast', page.url() === urlW && (await page.locator('.toast').count()) === 0);
  await open(page, S.base, 'rep', '/preps/today');
  check('F14 متصلاً: زر الكتابة فعّال رابط إلى #/preps/new', (await page.locator('.sticky-actions a.btn').getAttribute('href')) === '#/preps/new' && (await page.locator('[data-write="disabled"]').count()) === 0);
  await open(page, S.base, 'dev', '/dev?state=offline');
  var callsB = await page.evaluate(async function () { return (await import('/v2/js/data/mock.js')).callLog(); });
  check('F15 شاشة لا تُحفظ دون اتصال (لوحة المطوّر B): «غير متاحة دون اتصال» بلا طلب بيانات ولا بيانات مخزّنة', (await page.locator('[data-state="blocked"]').count()) === 1 && /غير متاحة دون اتصال/.test(await page.locator('[data-state="blocked"]').innerText()) && callsB.length === 0 && (await page.locator('[data-home-card]').count()) === 0, JSON.stringify(callsB));
  await open(page, S.base, 'rep', '/class/students?state=conflict');
  check('F16 التعارض (C): تنبيه «عُدِّل هذا السجل من جهاز آخر» وزر «تحديث»', (await page.locator('[data-state="conflict"]').getAttribute('role')) === 'alert' && /عُدِّل هذا السجل/.test(await page.locator('[data-state="conflict"]').innerText()));
  await page.locator('[data-state="conflict"] button').click(); await settle(page);
  check('F17 «تحديث» يزيل التعارض ويعرض المحتوى', (await page.locator('[data-state="conflict"]').count()) === 0 && (await page.locator('.row-card').count()) === 4);
  await open(page, S.base, 'student', '/preps/exam');
  check('F18 هل عدنا امتحان؟ «إي» + قائمة القادمة (3)', (await page.locator('[data-answer="yes"]').count()) === 1 && (await page.locator('.answer-yes ~ section li').count()) === 3);
  await open(page, S.base, 'student', '/preps/exam?state=empty');
  check('F19 «لا، ما كو امتحان خلال 7 أيام» جواب السؤال لا حالة فراغ مقفرة', (await page.locator('[data-answer="no"]').count()) === 1 && /ما كو امتحان خلال 7 أيام/.test(await page.locator('[data-answer="no"]').innerText()) && (await page.locator('[data-state="empty"]').count()) === 0);
  await open(page, S.base, 'student', '/preps/tomorrow');
  check('F20 باچر: لافتة الامتحان الذهبية + صفوف المواد (4) و«ما انضاف شي بعد» لمادة بلا تحضير', (await page.locator('[data-banner="exam"]').count()) === 1 && /عدنا امتحان كيمياء باچر/.test(await page.locator('[data-banner="exam"]').innerText()) && (await page.locator('.row-card').count()) === 4 && /ما انضاف شي بعد/.test(await page.locator('main').innerText()));
  await open(page, S.base, 'student', '/notifications');
  check('F21 مركز الإشعارات: 4 عناصر و«غير مقروء» بشارة نصية للجديد (3)', (await page.locator('.notif').count()) === 4 && (await page.locator('.notif .chip').count()) === 3);
  await open(page, S.base, 'student', '/notifications?state=empty');
  check('F22 إشعارات فارغة: «لا توجد إشعارات.»', /لا توجد إشعارات\./.test(await page.locator('[data-state="empty"]').innerText()));
  await open(page, S.base, 'rep', '/exams/new');
  await page.locator('main .btn-primary').click(); await page.waitForSelector('.toast');
  check('F23 نموذج هيكلي: «حفظ» (متصل) لا يحفظ شيئاً ويقول ذلك صراحة (toast صادق)', /لا يُحفظ شيء في العرض التجريبي/.test(await page.locator('.toast').innerText()) && (await page.locator('#toasts').getAttribute('aria-live')) === 'polite');
  await open(page, S.base, 'student', '/home?state=empty');
  check('F24 الرئيسية الفارغة: «لا جديد حالياً.» ولا بطاقات فارغة', /لا جديد حالياً/.test(await page.locator('[data-state="empty"]').innerText()) && (await page.locator('[data-home-card]').count()) === 0);
  await open(page, S.base, 'rep', '/home?state=offline');
  check('F25 الأزرار السريعة (ممثل) دون اتصال: الثلاثة معطّلة بسبب ظاهر', (await page.locator('[data-quick-actions] [data-write="disabled"]').count()) === 3 && (await page.locator('[data-quick-actions] .write-reason').count()) === 3);

  // ═════ G) المظهر (جهاز داكن) ═════
  await open(page, S.base, 'student', '/settings');
  var rad = await page.locator('input[name="theme"]').evaluateAll(function (r) { return r.map(function (x) { return x.value + ':' + x.checked; }); });
  check('G1 الإعدادات: ثلاثة خيارات (تلقائي/فاتح/داكن) والتلقائي محدد افتراضياً', eq(rad, ['auto:true', 'light:false', 'dark:false']) && eq(await T(page, '.radio'), ['تلقائي (يتبع الجهاز)', 'فاتح', 'داكن']));
  var bgAuto = await page.evaluate(function () { return getComputedStyle(document.body).backgroundColor; });
  check('G2 تلقائي + جهاز داكن ◄ خلفية رمز bg الداكن rgb(11, 19, 36) وبلا data-theme', bgAuto === 'rgb(11, 19, 36)' && (await page.evaluate(function () { return document.documentElement.hasAttribute('data-theme'); })) === false);
  await page.locator('label.radio', { hasText: 'فاتح' }).click(); await page.waitForTimeout(260);
  var s1 = await snap(page);
  check('G3 اختيار «فاتح» (والجهاز داكن): data-theme=light وخلفية rgb(244, 247, 251) ويُحفظ في marsa.v2.ui فقط', (await page.evaluate(function () { return document.documentElement.getAttribute('data-theme') + '|' + getComputedStyle(document.body).backgroundColor; })) === 'light|rgb(244, 247, 251)' && s1['marsa.v2.ui'] === '{"theme":"light"}' && Object.keys(s1).filter(function (k) { return /^marsa\.v2\./.test(k); }).length === 1);
  check('G4 مفاتيح V1 وmarsa.academic بقيت كما هي بعد تغيير المظهر', Object.keys(V1_SEED).every(function (k) { return s1[k] === V1_SEED[k]; }));
  await page.reload(); await page.waitForSelector('html[data-v2="ready"]');
  check('G5 المظهر يبقى بعد إعادة التحميل ويُطبَّق قبل الرسم (data-theme=light) والخيار محدد في الإعدادات', (await page.evaluate(function () { return document.documentElement.getAttribute('data-theme'); })) === 'light' && (await page.locator('#theme-light').isChecked()));
  await page.locator('label.radio', { hasText: 'داكن' }).click(); await page.waitForTimeout(260);
  check('G6 «داكن» ◄ data-theme=dark وخلفية rgb(11, 19, 36)', (await page.evaluate(function () { return document.documentElement.getAttribute('data-theme') + '|' + getComputedStyle(document.body).backgroundColor; })) === 'dark|rgb(11, 19, 36)' && (await snap(page))['marsa.v2.ui'] === '{"theme":"dark"}');
  await page.locator('label.radio', { hasText: 'تلقائي' }).click(); await page.waitForTimeout(260);
  await page.emulateMedia({ colorScheme: 'light' }); await page.waitForTimeout(260);
  check('G7 «تلقائي» يزيل data-theme ويتبع الجهاز فورياً (جهاز فاتح ◄ rgb(244, 247, 251))', (await page.evaluate(function () { return document.documentElement.hasAttribute('data-theme') + '|' + getComputedStyle(document.body).backgroundColor; })) === 'false|rgb(244, 247, 251)');
  await page.emulateMedia({ colorScheme: 'dark' });
  await page.evaluate(function () { localStorage.setItem('marsa.v2.ui', '{"theme":"neon","x":1}'); });
  await page.reload(); await page.waitForSelector('html[data-v2="ready"]');
  check('G8 قيمة مظهر مجهولة في التخزين ◄ تلقائي بلا انهيار', (await page.evaluate(function () { return document.documentElement.hasAttribute('data-theme'); })) === false && (await page.locator('#theme-auto').isChecked()));
  await page.evaluate(function () { localStorage.setItem('marsa.v2.ui', '{broken'); });
  await page.reload(); await page.waitForSelector('html[data-v2="ready"]');
  check('G9 JSON تالف في marsa.v2.ui ◄ تلقائي بلا انهيار والواجهة تعمل', (await page.locator('main h1').innerText()) === 'الإعدادات');
  await page.evaluate(function () { localStorage.removeItem('marsa.v2.ui'); });
  // التباين الفعلي في الوضعين
  var csel = [['.page-title', 'عنوان الصفحة'], ['.muted, .demo-chip', 'نص خافت'], ['.hint', 'تلميح'], ['.link-card b', 'بطاقة رابط'], ['.kv', 'سطر رقم البناء'], ['#dev-note', 'سطر قيد التطوير']];
  var cBad = [];
  for (var th of ['dark', 'light']) {
    await page.evaluate(function (v) { document.documentElement.setAttribute('data-theme', v); }, th); await page.waitForTimeout(260);
    await go(page, '/settings');
    for (var ci = 0; ci < csel.length; ci++) { var cr = await contrast(page, csel[ci][0]); if (cr !== -1 && cr < 4.5) cBad.push(th + ' ' + csel[ci][1] + ' ' + cr); }
    var tabC = await contrast(page, '#tabbar a:not([aria-current])'), tabA = await contrast(page, '#tabbar a[aria-current="page"]'), topC = await contrast(page, '#top .brand-text b');
    if (tabC < 4.5) cBad.push(th + ' تبويب غير نشط ' + tabC); if (tabA < 4.5) cBad.push(th + ' تبويب نشط ' + tabA); if (topC < 4.5) cBad.push(th + ' ترويسة ' + topC);
  }
  await page.evaluate(function () { document.documentElement.removeAttribute('data-theme'); });
  check('G10 التباين الفعلي ≥ 4.5:1 للعنوان والنص الخافت والتبويبات والترويسة في الوضعين (من الألوان المحسوبة)', cBad.length === 0, cBad.join(' | '));
  var cBad2 = [];
  for (var th2 of ['dark', 'light']) {
    await page.evaluate(function (v) { document.documentElement.setAttribute('data-theme', v); }, th2); await page.waitForTimeout(260);
    await open(page, S.base, 'rep', '/preps/today'); await page.evaluate(function (v) { document.documentElement.setAttribute('data-theme', v); }, th2); await page.waitForTimeout(260);
    var pairs = [['.prep .chip-gold', 'شارة مثبّت'], ['.prep-notes', 'ملاحظات'], ['.prep-line', 'واجب'], ['.sticky-actions .btn-primary', 'زر أساسي'], ['.seg a[aria-current="page"]', 'تبويب داخلي نشط'], ['.seg a:not([aria-current])', 'تبويب داخلي'], ['.group-title', 'عنوان مجموعة'], ['.eyebrow, .prep-top .muted', 'سطر ثانوي']];
    for (var pj = 0; pj < pairs.length; pj++) { var c2 = await contrast(page, pairs[pj][0]); if (c2 !== -1 && c2 < 4.5) cBad2.push(th2 + ' ' + pairs[pj][1] + ' ' + c2); }
  }
  await page.evaluate(function () { document.documentElement.removeAttribute('data-theme'); });
  check('G11 التباين في صفحة التحاضير (شارات، زر أساسي، تبويب داخلي، ملاحظات) ≥ 4.5:1 في الوضعين', cBad2.length === 0, cBad2.join(' | '));

  // ═════ H) RTL الفعلي ═════
  await open(page, S.base, 'student', '/home');
  var rtl = await page.evaluate(function () {
    var q = function (s) { return document.querySelector(s).getBoundingClientRect(); };
    var tabs = Array.from(document.querySelectorAll('#tabbar a')).map(function (a) { return a.getBoundingClientRect().left; });
    return { menuRight: q('.menu-btn').right, brandLeft: q('.brand').left, bellLeft: q('.bell').left, brandRight: q('.brand').right, firstTabLeft: tabs[0], lastTabLeft: tabs[2], W: innerWidth, h1Align: getComputedStyle(document.querySelector('main h1')).textAlign, cardTextRight: q('.home-card .card-title').right, cardRight: q('.home-card').right };
  });
  check('H1 اتجاه RTL فعلياً: ☰ عند اليمين والجرس عند اليسار، وأول تبويب (الرئيسية) أقصى اليمين، والعنوان محاذٍ لليمين', rtl.menuRight > rtl.W - 30 && rtl.bellLeft < 30 && rtl.firstTabLeft > rtl.lastTabLeft && /start|right/.test(rtl.h1Align) && rtl.cardTextRight > rtl.cardRight - 24, JSON.stringify(rtl));

  var errsAll = bag.errors;
  check('A9 طوال الجلسة: لا أخطاء صفحة ولا console error/warning ولا مخالفة CSP ولا طلب فاشل', errsAll.length === 0, errsAll.slice(0, 4).join(' | '));
  check('A10 كل الطلبات من الأصل نفسه وتحت /v2/ فقط (لا خارجي، لا V1)', bag.urls.every(function (u) { return u.indexOf(S.base + '/v2/') === 0; }), bag.urls.filter(function (u) { return u.indexOf(S.base + '/v2/') !== 0; }).slice(0, 3).join());
  check('A11 لا انتهاكات CSP مسجّلة داخل الصفحة', (await page.evaluate(function () { return window.__csp.length; })) === 0);
  await ctx.close();

  // ═════ I) الحاسوب 1280: قائمة ثابتة ═════
  var cd = await newCtx(browser, { viewport: { width: 1280, height: 800 } }), pd = await cd.newPage(), bagD = { errors: [], urls: [] };
  watch(pd, bagD);
  await open(pd, S.base, 'student', '/home');
  var dk = await pd.evaluate(function () {
    var s = document.getElementById('sidebar'), r = s.getBoundingClientRect(), m = document.getElementById('app-main').getBoundingClientRect(), cs = getComputedStyle(s);
    var cards = Array.from(document.querySelectorAll('[data-home-card]')).map(function (c) { return c.getBoundingClientRect(); });
    return { w: Math.round(r.width), right: Math.round(r.right), vis: cs.visibility, inert: s.hasAttribute('inert'), role: s.getAttribute('role'), menu: getComputedStyle(document.querySelector('.menu-btn')).display, tab: getComputedStyle(document.getElementById('tabbar')).display, mainLeft: Math.round(m.left), mainRight: Math.round(m.right), page: Math.round(document.querySelector('.page-inner').getBoundingClientRect().width), top0: Math.round(cards[0].top), top1: Math.round(cards[1].top), W: innerWidth };
  });
  check('I1 ≥1024: القائمة ثابتة عند اليمين بعرض 280 ظاهرة بلا inert ولا dialog، لا زر ☰ ولا شريط تبويب', dk.w === 280 && dk.right === dk.W && dk.vis === 'visible' && !dk.inert && dk.role === null && dk.menu === 'none' && dk.tab === 'none', JSON.stringify(dk));
  check('I2 محتوى الصفحة يبدأ من اليسار حتى حافة القائمة (margin-inline-start:280) وعرض العمود ≤960', dk.mainLeft === 0 && dk.mainRight === dk.W - 280 && dk.page <= 960, JSON.stringify(dk));
  check('I3 الرئيسية بعمودين على الحاسوب (أول بطاقتين على نفس الخط)', Math.abs(dk.top0 - dk.top1) <= 2, dk.top0 + '/' + dk.top1);
  check('I4 القائمة الثابتة تعرض كل مجموعات الطالب وبنودها بلا فتح', eq(await T(pd, '#sidebar .sb-title'), mapSide('student').titles) && (await pd.locator('#sidebar .sb-item').count()) === mapSide('student').items.length);
  var ttD = await tapTargets(pd, '#sidebar');
  check('I5 أهداف اللمس في القائمة الثابتة ≥44px', ttD.length === 0, ttD.join(' | '));
  await pd.locator('#sidebar .sb-item[data-screen="SC-PREPS-TODAY"]').click(); await settle(pd);
  check('I6 الاختيار من القائمة الثابتة يتنقل ويبقى القائمة ظاهرة (لا تُغلق)', /#\/preps\/today$/.test(pd.url()) && (await pd.locator('#sidebar').evaluate(function (s) { return s.getBoundingClientRect().width === 280; })));
  await pd.setViewportSize({ width: 390, height: 844 }); await pd.waitForTimeout(200);
  check('I7 تصغير النافذة ≥1024 ◄ هاتف: تتحول القائمة لورقة مغلقة ويظهر شريط التبويب وزر ☰', (await pd.locator('#sidebar').getAttribute('data-open')) === 'false' && (await pd.locator('#tabbar').isVisible()) && (await pd.locator('.menu-btn').isVisible()) && (await pd.locator('#sidebar').getAttribute('role')) === 'dialog');
  await pd.locator('.menu-btn').click(); await pd.waitForSelector('#sidebar[data-open="true"]'); await pd.waitForTimeout(340);
  await pd.setViewportSize({ width: 1280, height: 800 }); await pd.waitForTimeout(200);
  check('I8 تكبير النافذة وهي مفتوحة ◄ تُغلق الورقة وتزول inert عن المحتوى ويستمر التثبيت', (await pd.evaluate(function () { return document.getElementById('sidebar').getAttribute('data-open') === 'false' && !document.getElementById('app-main').hasAttribute('inert') && document.getElementById('sidebar').getBoundingClientRect().width === 280; })));
  var ovD = await overflow(pd);
  check('I9 لا تجاوز أفقي على 1280', ovD.length === 0, ovD.join(' | '));
  await cd.close();

  // ═════ J) وضع الدعم (عرض بصفة) ═════
  var cs = await newCtx(browser), ps = await cs.newPage(), bagS = { errors: [], urls: [] };
  watch(ps, bagS);
  await ps.clock.install({ time: new Date('2026-11-13T09:00:00Z') });
  await open(ps, S.base, 'dev', '/dev/support');
  check('J1 شاشة وضع الدعم (مطوّر): ملاحظة «جلسة دعم وهمية» وزرا بدء (طالب/ممثل) ولا شريط دعم قبل البدء', (await ps.locator('[data-support-start]').count()) === 2 && (await ps.locator('.support-bar').isHidden()) && (await ps.evaluate(function () { return document.documentElement.hasAttribute('data-support'); })) === false);
  await ps.locator('[data-support-start="student"]').click(); await settle(ps);
  var sb = await ps.evaluate(function () { var b = document.getElementById('support-bar'), r = b.getBoundingClientRect(), cs = getComputedStyle(b), t = document.getElementById('top').getBoundingClientRect(); return { vis: !b.hidden, top: Math.round(r.top), h: r.height, pos: cs.position, txt: b.innerText.replace(/\s+/g, ' '), region: b.getAttribute('role') + '|' + b.getAttribute('aria-label'), attr: document.documentElement.hasAttribute('data-support'), hdrTop: t.top, sh: getComputedStyle(document.documentElement).getPropertyValue('--support-h').trim(), tabs: Array.from(document.querySelectorAll('#tabbar a')).map(function (a) { return a.textContent.trim(); }) }; });
  check('J2 بدء العرض كطالب: شريط الدعم ظاهر ثابت أعلى الشاشة (sticky top 0) بنص الحساب والدور وتأكيد الكتابة، وregion مسمّى', sb.vis && sb.top === 0 && sb.pos === 'sticky' && /وضع الدعم/.test(sb.txt) && /طالب تجريبي 7/.test(sb.txt) && /\(طالب\)/.test(sb.txt) && /الكتابة تتطلب تأكيداً/.test(sb.txt) && /المتبقي: 30 دقيقة/.test(sb.txt) && sb.region === 'region|وضع الدعم' && sb.attr, JSON.stringify(sb));
  check('J3 القشرة تتحول لقشرة الطالب (تبويباتها وقائمتها) والمسار #/home، والترويسة تنزل تحت الشريط (top = ارتفاعه)', eq(sb.tabs, mapTabs('student')) && /#\/home$/.test(ps.url()) && Math.abs(sb.hdrTop - sb.h) <= 0.6 && Math.abs(parseFloat(sb.sh) - sb.h) <= 0.6, JSON.stringify([sb.tabs, sb.hdrTop, sb.h, sb.sh]));
  await ps.evaluate(function () { window.scrollTo(0, 400); }); await ps.waitForTimeout(80);
  check('J4 الشريط لا يختفي عند التمرير (top=0 دائماً)', (await ps.locator('#support-bar').evaluate(function (b) { return Math.round(b.getBoundingClientRect().top); })) === 0);
  await ps.locator('#top .menu-btn').click(); await ps.waitForSelector('#sidebar[data-open="true"]'); await ps.waitForTimeout(340);
  var cover = await ps.evaluate(function () { var b = document.getElementById('support-bar').getBoundingClientRect(), el = document.elementFromPoint(b.left + b.width / 2, b.top + b.height / 2), sd = document.getElementById('sidebar').getBoundingClientRect(), sc = document.getElementById('scrim').getBoundingClientRect(); return { onBar: !!el.closest('#support-bar'), sideTop: sd.top, barH: b.height, scrimTop: sc.top }; });
  check('J5 القائمة المفتوحة لا تغطي شريط الدعم: تبدأ تحته والستار كذلك', cover.onBar && Math.abs(cover.sideTop - cover.barH) <= 0.6 && Math.abs(cover.scrimTop - cover.barH) <= 0.6, JSON.stringify(cover));
  await ps.keyboard.press('Escape');
  await go(ps, '/dev/audit');
  check('J6 أثناء العرض كطالب: مسار المطوّر محجوب (القشرة تتبع حساب الهدف لا المطوّر)', (await ps.locator('[data-state="forbidden"]').count()) === 1);
  var teTab = await ps.evaluate(function () { var e = document.querySelector('.support-end'), r = e.getBoundingClientRect(); return Math.min(r.width, r.height); });
  check('J7 زر «إنهاء» هدف لمس ≥44 وقابل للوصول', teTab >= 44);
  await ps.clock.runFor(60000 * 29);
  check('J8 العدّاد التجريبي ينقص كل دقيقة (بعد 29 دقيقة: المتبقي 1 دقيقة)', /المتبقي: 1 دقيقة/.test(await ps.locator('#support-bar').innerText()));
  await ps.clock.runFor(60000 + 500);
  check('J9 عند نفاد المدة ينتهي العرض تلقائياً: الشريط يختفي وتعود قشرة المطوّر', (await ps.locator('#support-bar').isHidden()) && eq(await T(ps, '#tabbar a'), mapTabs('dev')) && /#\/dev\/support$/.test(ps.url()));
  await ps.locator('[data-support-start="rep"]').click(); await settle(ps);
  check('J10 البدء كممثل: قشرة الممثل (تبويباتها) والشريط باسم «ممثل تجريبي 2 (ممثل الصف)»', eq(await T(ps, '#tabbar a'), mapTabs('rep')) && /ممثل تجريبي 2 \(ممثل الصف\)/.test(await ps.locator('#support-bar').innerText()));
  await ps.locator('.support-end').click(); await settle(ps);
  check('J11 «إنهاء» يعيد المطوّر إلى #/dev/support ويخفي الشريط ويزيل data-support', (await ps.locator('#support-bar').isHidden()) && /#\/dev\/support$/.test(ps.url()) && (await ps.evaluate(function () { return document.documentElement.hasAttribute('data-support') + '|' + getComputedStyle(document.documentElement).getPropertyValue('--support-h').trim(); })) === 'false|0px' && eq(await T(ps, '#tabbar a'), mapTabs('dev')));
  check('J12 جلسة الدعم بلا أخطاء ولا مخالفة CSP', bagS.errors.length === 0, bagS.errors.slice(0, 3).join(' | '));
  await cs.close();

  // ═════ K) الاتصال الحقيقي (setOffline) ═════
  var co = await newCtx(browser), po = await co.newPage(), bagO = { errors: [], urls: [] };
  watch(po, bagO);
  await open(po, S.base, 'student', '/preps/today');
  await co.setOffline(true);
  await po.waitForSelector('#offline-bar:not([hidden])', { timeout: 4000 }).catch(function () {});
  await settle(po);
  check('K1 انقطاع الاتصال الحقيقي: يظهر الشريط ويُعاد عرض البيانات المخزّنة بختم «آخر تحديث» دون إعادة تحميل الصفحة', (await po.locator('#offline-bar').isVisible()) && (await po.locator('.stamp').count()) === 1 && (await po.locator('.prep').count()) === 4);
  await co.setOffline(false);
  await po.waitForSelector('#offline-bar', { state: 'hidden', timeout: 4000 }).catch(function () {});
  await po.waitForSelector('.toast', { timeout: 4000 }).catch(function () {});
  check('K2 عودة الاتصال: يختفي الشريط والختم ويتحدّث المحتوى تلقائياً ويظهر toast «تم التحديث.»', (await po.locator('#offline-bar').isHidden()) && (await po.locator('.stamp').count()) === 0 && /تم التحديث\./.test(await po.locator('.toast').innerText().catch(function () { return ''; })));
  await po.waitForSelector('.toast', { state: 'detached', timeout: 6000 }).catch(function () {});
  check('K3 التنبيه المؤقت يختفي تلقائياً بعد ≈4 ثوانٍ', (await po.locator('.toast').count()) === 0);
  await open(po, S.base, 'dev', '/dev');
  await co.setOffline(true); await po.waitForSelector('[data-state="blocked"]', { timeout: 4000 }).catch(function () {});
  check('K4 لوحة المطوّر عند الانقطاع الحقيقي: تتحول إلى «غير متاحة دون اتصال» (B)', (await po.locator('[data-state="blocked"]').count()) === 1);
  await co.setOffline(false); await po.waitForSelector('[data-home-card]', { timeout: 4000 }).catch(function () {});
  check('K5 وتعود البطاقات عند عودة الاتصال', (await po.locator('[data-home-card]').count()) === 4);
  check('K6 جلسة الاتصال بلا أخطاء صفحة', bagO.errors.filter(function (e) { return !/ERR_INTERNET_DISCONNECTED|Failed to load resource/.test(e); }).length === 0, bagO.errors.slice(0, 3).join(' | '));
  await co.close();

  // ═════ L) الحركة: الافتتاحية والانتقالات (بلا تقليل حركة) ═════
  var cm = await newCtx(browser, { motion: 'no-preference' }), pm = await cm.newPage(), bagM = { errors: [], urls: [] };
  watch(pm, bagM);
  await pm.goto(S.base + '/v2/index.html?mock=student#/home');
  await pm.waitForSelector('html[data-v2="ready"]');
  var intro = await pm.evaluate(function () { var i = document.getElementById('intro'); return { shown: !i.hidden, name: (i.querySelector('.intro-name') || {}).textContent, sub: (i.querySelector('.intro-sub') || {}).textContent, skip: (i.querySelector('.intro-skip') || {}).textContent, inert: document.getElementById('app').hasAttribute('inert'), anim: getComputedStyle(i).animationName + '|' + getComputedStyle(i).animationDuration, role: i.getAttribute('role') }; });
  check('L1 الافتتاحية (SC-INTRO): تظهر عند الفتح بالشعار و«مَرسى» وMARSA وزر «تخطّي»، والتطبيق خلفها inert، بحركة opacity لمدة 1.5s', intro.shown && intro.name === 'مَرسى' && intro.sub === 'MARSA' && intro.skip === 'تخطّي' && intro.inert && intro.anim === 'intro-fade|1.5s' && intro.role === 'dialog', JSON.stringify(intro));
  await pm.locator('.intro-skip').click();
  check('L2 تُتخطّى بلمسة فوراً: تختفي ويزول inert ويظهر التطبيق', (await pm.locator('#intro').isHidden()) && !(await pm.evaluate(function () { return document.getElementById('app').hasAttribute('inert'); })));
  var t0 = Date.now();
  await pm.reload();
  await pm.waitForSelector('#intro:not([hidden])');
  await pm.waitForSelector('#intro', { state: 'hidden', timeout: 4000 });
  var dt = Date.now() - t0;
  check('L3 تنتهي تلقائياً بعد ≈1.5 ثانية (بين 1.2 و3.2 ثانية شاملة التحميل)', dt >= 1200 && dt <= 3200, dt + 'ms');
  await pm.locator('#top .menu-btn').click(); await pm.waitForSelector('#sidebar[data-open="true"]');
  var tr = await pm.evaluate(function () { var s = getComputedStyle(document.getElementById('sidebar')), sc = getComputedStyle(document.getElementById('scrim')); return { prop: s.transitionProperty, dur: s.transitionDuration, ease: s.transitionTimingFunction, scrim: sc.transitionProperty + '|' + sc.transitionDuration }; });
  check('L4 فتح القائمة: transform بمدة 320ms (و0s للرؤية) والستار opacity بمدة 320ms، بمنحنى cubic-bezier(.2,.8,.2,1)', /transform/.test(tr.prop) && /0\.32s/.test(tr.dur) && /cubic-bezier\(0\.2, 0\.8, 0\.2, 1\)/.test(tr.ease) && /^opacity/.test(tr.scrim.split('|')[0]) && /^0\.32s/.test(tr.scrim.split('|')[1]), JSON.stringify(tr));
  await pm.keyboard.press('Escape'); await pm.waitForSelector('#sidebar[data-open="false"]', { state: 'attached' });
  var tr2 = await pm.evaluate(function () { var s = getComputedStyle(document.getElementById('sidebar')); return s.transitionDuration; });
  check('L5 إغلاق القائمة أسرع: 240ms', /0\.24s/.test(tr2), tr2);
  var panim = await pm.evaluate(async function () {
    document.location.hash = '#/settings'; await new Promise(function (r) { setTimeout(r, 40); });
    var el = document.querySelector('.page-inner'); var cs = getComputedStyle(el);
    return { cls: el.className, name: cs.animationName, dur: cs.animationDuration };
  });
  check('L6 انتقال الصفحة: route-in بمدة 180ms (opacity + translateY 8px)', /route-in/.test(panim.cls) && panim.name === 'route-in' && panim.dur === '0.18s', JSON.stringify(panim));
  var anims = await pm.evaluate(function () { var names = {}; document.querySelectorAll('*').forEach(function (e) { var a = getComputedStyle(e).animationName; if (a && a !== 'none') a.split(',').forEach(function (n) { names[n.trim()] = 1; }); }); return Object.keys(names); });
  check('L7 كل الحركات المستعملة معروفة (route-in/card-in/skel/toast-in/intro-fade) — لا حركة تخطيط', anims.every(function (n) { return ['route-in', 'card-in', 'skel', 'toast-in', 'intro-fade'].indexOf(n) > -1; }), anims.join());
  await open(pm, S.base, 'student', '/preps/today?state=loading', true);
  var sk = await pm.evaluate(function () { var s = getComputedStyle(document.querySelector('.skel')); return s.animationName + '|' + s.animationDuration + '|' + s.animationIterationCount; });
  check('L8 الهيكل ينبض 1.2s × 7 دورات (≈8.4s) ثم يتوقف — لا نبض لانهائي', sk === 'skel|1.2s|7', sk);
  check('L9 جلسة الحركة بلا أخطاء', bagM.errors.length === 0, bagM.errors.slice(0, 3).join(' | '));
  await cm.close();
  // تقليل الحركة: الافتتاحية لا تُعرض، القائمة بلا انزلاق، الهيكل ثابت
  var cr = await newCtx(browser, { motion: 'reduce' }), pr = await cr.newPage(), bagR = { errors: [], urls: [] };
  watch(pr, bagR);
  await pr.goto(S.base + '/v2/index.html?mock=student#/home'); await pr.waitForSelector('html[data-v2="ready"]'); await settle(pr);
  check('L10 تقليل الحركة: لا افتتاحية أبداً والتطبيق قابل للاستعمال فوراً', (await pr.locator('#intro').isHidden()) && !(await pr.evaluate(function () { return document.getElementById('app').hasAttribute('inert'); })));
  await pr.locator('#top .menu-btn').click(); await pr.waitForSelector('#sidebar[data-open="true"]');
  var rd = await pr.evaluate(function () { var s = getComputedStyle(document.getElementById('sidebar')); return s.transitionDuration + '|' + s.transform; });
  check('L11 تقليل الحركة: القائمة تظهر فوراً بلا انزلاق (انتقال 0s وبلا transform متبقٍ)', /^0s/.test(rd) && (/none|matrix\(1, 0, 0, 1, 0, 0\)/.test(rd.split('|')[1])), rd);
  await pr.keyboard.press('Escape');
  await open(pr, S.base, 'student', '/preps/today?state=loading', true);
  check('L12 تقليل الحركة: لا حركة على الهيكل ولا على البطاقات', (await pr.evaluate(function () { return getComputedStyle(document.querySelector('.skel')).animationName; })) === 'none');
  await open(pr, S.base, 'student', '/preps/today');
  check('L13 تقليل الحركة: لا حركة انتقال (route-in) ولا card-in', (await pr.evaluate(function () { return getComputedStyle(document.querySelector('.page-inner')).animationName + '|' + getComputedStyle(document.querySelector('.prep')).animationName; })) === 'none|none');
  await cr.close();

  // ═════ M) الاستجابة: عروض × أدوار × شاشات × حالات ═════
  var cl = await newCtx(browser), pl = await cl.newPage(), bagL = { errors: [], urls: [] };
  watch(pl, bagL);
  var widths = [320, 360, 390, 768, 1024, 1280], routesByRole = { student: ['/home', '/preps/today', '/preps/tomorrow', '/preps/exam', '/settings', '/settings/upcoming', '/about', '/notifications', '/class/students', '/home?state=error', '/preps/today?state=offline', '/preps/today?state=loading'], rep: ['/home', '/preps/today?state=empty', '/class/costs', '/exams/new', '/home?state=offline', '/class/students?state=conflict'], dev: ['/dev', '/dev?state=offline', '/dev/support', '/dev/system', '/settings/upcoming'] };
  var ovBad = [], tapBad = [], fsBad = [], nCombos = 0;
  for (var wi = 0; wi < widths.length; wi++) {
    await pl.setViewportSize({ width: widths[wi], height: widths[wi] >= 1024 ? 800 : 800 });
    for (var rr of ['student', 'rep', 'dev']) {
      for (var rt = 0; rt < routesByRole[rr].length; rt++) {
        await open(pl, S.base, rr, routesByRole[rr][rt], /state=loading/.test(routesByRole[rr][rt])); nCombos++;
        var ov = await overflow(pl); if (ov.length) ovBad.push(widths[wi] + ' ' + rr + ' ' + routesByRole[rr][rt] + ' :: ' + ov.slice(0, 2).join(','));
        var tp = await tapTargets(pl, '#top, #tabbar, main'); if (tp.length) tapBad.push(widths[wi] + ' ' + rr + ' ' + routesByRole[rr][rt] + ' :: ' + tp.slice(0, 2).join(','));
        var fs2 = await pl.evaluate(function () { var bad = []; document.querySelectorAll('body *').forEach(function (e) { var cs = getComputedStyle(e); if (cs.display === 'none' || cs.visibility === 'hidden' || e.closest('svg') || e.closest('[inert]')) return; var own = Array.from(e.childNodes).some(function (n) { return n.nodeType === 3 && n.textContent.trim(); }); if (own && parseFloat(cs.fontSize) < 12) bad.push(e.tagName + '.' + e.className + ' ' + cs.fontSize); }); return bad.slice(0, 2); }); if (fs2.length) fsBad.push(widths[wi] + ' ' + rr + ' ' + routesByRole[rr][rt] + ' :: ' + fs2.join(','));
      }
    }
  }
  check('M1 لا تجاوز أفقي ولا عنصر يخرج عن الشاشة في ' + nCombos + ' تركيبة (6 عروض 320…1280 × 3 أدوار × شاشات وحالات)', ovBad.length === 0, ovBad.slice(0, 4).join(' | '));
  check('M2 أهداف اللمس ≥44px للترويسة والشريط السفلي والمحتوى في كل التركيبات', tapBad.length === 0, tapBad.slice(0, 4).join(' | '));
  check('M3 لا نص أصغر من 12px (0.75rem) في أي تركيبة', fsBad.length === 0, fsBad.slice(0, 4).join(' | '));
  await pl.setViewportSize({ width: 844, height: 390 });
  await open(pl, S.base, 'rep', '/home');
  var lsOv = await overflow(pl);
  check('M4 هاتف أفقياً (844×390): لا تجاوز، والترويسة والشريط السفلي مرئيان', lsOv.length === 0 && (await pl.locator('#tabbar').isVisible()) && (await pl.locator('#top').isVisible()), lsOv.join());
  await pl.setViewportSize({ width: 768, height: 1024 });
  await open(pl, S.base, 'student', '/home');
  var tbl = await pl.evaluate(function () { return { tab: getComputedStyle(document.getElementById('tabbar')).display, page: Math.round(document.querySelector('.page-inner').getBoundingClientRect().width), menu: getComputedStyle(document.querySelector('.menu-btn')).display, side: document.getElementById('sidebar').getAttribute('data-open') }; });
  check('M5 تابلت 768: الشريط السفلي والقائمة كورقة، وعمود المحتوى ≤720', tbl.tab !== 'none' && tbl.menu !== 'none' && tbl.side === 'false' && tbl.page <= 720, JSON.stringify(tbl));
  await pl.setViewportSize({ width: 320, height: 640 });
  await open(pl, S.base, 'dev', '/dev');
  var sm = await pl.evaluate(function () { return Array.from(document.querySelectorAll('#tabbar a')).map(function (a) { var s = a.querySelector('span'); return s.scrollWidth <= a.clientWidth; }); });
  check('M6 شاشة 320: عناوين تبويبات المطوّر (الأطول) لا تنقطع', sm.every(Boolean), JSON.stringify(sm));
  check('M7 جلسة الاستجابة بلا أخطاء', bagL.errors.length === 0, bagL.errors.slice(0, 3).join(' | '));
  await cl.close();

  // ═════ N) إمكانية الوصول ═════
  var cx = await newCtx(browser), px = await cx.newPage(), bagX = { errors: [], urls: [] };
  watch(px, bagX);
  var axBad = [];
  for (var ar of [['student', ['/home', '/preps/today', '/settings', '/notifications']], ['rep', ['/home', '/preps/today?state=error', '/class/students']], ['dev', ['/dev', '/dev/support']]]) {
    for (var ah = 0; ah < ar[1].length; ah++) {
      await open(px, S.base, ar[0], ar[1][ah]);
      await px.locator('.menu-btn').click(); await px.waitForSelector('#sidebar[data-open="true"]'); await px.waitForTimeout(340);
      var ax = await px.evaluate(function () {
        var bad = [];
        if (document.querySelectorAll('h1').length !== 1) bad.push('h1 count ' + document.querySelectorAll('h1').length);
        if (document.querySelectorAll('main').length !== 1) bad.push('main count');
        if (document.querySelectorAll('header').length !== 1) bad.push('header count');
        var ids = {}; document.querySelectorAll('[id]').forEach(function (e) { if (ids[e.id]) bad.push('dup id ' + e.id); ids[e.id] = 1; });
        document.querySelectorAll('a[href], button').forEach(function (e) { var n = (e.getAttribute('aria-label') || e.textContent || '').trim(); if (!n) bad.push('بلا اسم: ' + e.outerHTML.slice(0, 60)); });
        document.querySelectorAll('svg.i').forEach(function (s) { if (s.getAttribute('aria-hidden') !== 'true') bad.push('svg بلا aria-hidden'); });
        document.querySelectorAll('nav').forEach(function (n) { if (!n.getAttribute('aria-label')) bad.push('nav بلا تسمية'); });
        document.querySelectorAll('[aria-controls]').forEach(function (e) { if (!document.getElementById(e.getAttribute('aria-controls'))) bad.push('aria-controls يتيم ' + e.getAttribute('aria-controls')); });
        document.querySelectorAll('[aria-describedby]').forEach(function (e) { if (!document.getElementById(e.getAttribute('aria-describedby'))) bad.push('aria-describedby يتيم'); });
        document.querySelectorAll('img').forEach(function (e) { if (!e.hasAttribute('alt')) bad.push('img بلا alt'); });
        if (document.getElementById('sidebar').getAttribute('aria-label') !== 'القائمة الجانبية') bad.push('تسمية القائمة');
        return bad;
      });
      if (ax.length) axBad.push(ar[0] + ' ' + ar[1][ah] + ' :: ' + ax.slice(0, 3).join(' ; '));
      await px.keyboard.press('Escape');
    }
  }
  check('N1 إمكانية الوصول (11 شاشة والقائمة مفتوحة): h1 واحد، landmarks، تسميات nav، اسم لكل زر/رابط، svg مخفية، لا ids مكررة ولا aria-controls/describedby يتيمة', axBad.length === 0, axBad.slice(0, 3).join(' | '));
  await open(px, S.base, 'student', '/home');
  await px.keyboard.press('Tab'); await px.keyboard.press('Tab');
  var ring = await px.evaluate(function () { var cs = getComputedStyle(document.activeElement); return { tag: document.activeElement.className, st: cs.outlineStyle, w: parseFloat(cs.outlineWidth) }; });
  check('N2 حلقة التركيز ظاهرة (≥3px بنمط غير none) لزر الترويسة بلوحة المفاتيح', ring.st !== 'none' && ring.w >= 3, JSON.stringify(ring));
  await px.keyboard.press('Enter'); await px.waitForSelector('#sidebar[data-open="true"]');
  check('N3 ☰ يعمل بلوحة المفاتيح (Enter) ويفتح القائمة ويحدّث aria-expanded', (await px.locator('.menu-btn').getAttribute('aria-expanded')) === 'true');
  await px.keyboard.press('Escape');
  await px.locator('#top .menu-btn').focus(); await px.keyboard.press('Space'); await px.waitForSelector('#sidebar[data-open="true"]');
  check('N4 وبالمسافة أيضاً', (await px.locator('.menu-btn').getAttribute('aria-expanded')) === 'true');
  await px.keyboard.press('Escape');
  var live = await px.evaluate(function () { return { toasts: document.getElementById('toasts').getAttribute('aria-live') + '|' + document.getElementById('toasts').getAttribute('role'), off: document.getElementById('offline-bar').getAttribute('role'), sup: document.getElementById('support-bar').getAttribute('role') }; });
  check('N5 مناطق الإعلان: toasts (aria-live=polite، status)، شريط دون اتصال (status)، شريط الدعم (region)', live.toasts === 'polite|status' && live.off === 'status' && live.sup === 'region', JSON.stringify(live));
  var seg = await (async function () { await open(px, S.base, 'student', '/preps/today'); return px.evaluate(function () { return { nav: document.querySelector('.seg').getAttribute('aria-label'), cur: document.querySelectorAll('.seg a[aria-current="page"]').length, ind: document.querySelector('.seg-ind').getAttribute('aria-hidden') }; }); })();
  check('N6 الشريط الداخلي: nav مسمّى «أقسام التحاضير» وعنصر واحد aria-current والمؤشر مخفي', seg.nav === 'أقسام التحاضير' && seg.cur === 1 && seg.ind === 'true', JSON.stringify(seg));
  check('N7 جلسة الوصول بلا أخطاء', bagX.errors.length === 0, bagX.errors.slice(0, 3).join(' | '));
  await cx.close();

  // ═════ O) عزل V1 وطفرات ═════
  var ci = await newCtx(browser), pi2 = await ci.newPage(), bagI = { errors: [], urls: [] };
  watch(pi2, bagI);
  await open(pi2, S.base, 'student', '/home');
  var iso0 = await snap(pi2);
  for (var hh of ['/preps/today', '/preps/tomorrow', '/preps/exam', '/class/students', '/notifications', '/settings', '/settings/upcoming', '/about', '/me', '/home?state=error', '/preps/today?state=offline']) await go(pi2, hh);
  await pi2.locator('.menu-btn').click(); await pi2.waitForSelector('#sidebar[data-open="true"]'); await pi2.keyboard.press('Escape');
  var iso1 = await snap(pi2);
  check('O1 كل التنقلات والحالات وفتح القائمة لا تكتب في localStorage أبداً (لا marsa.v2.* ولا غيره)', sameMap(iso0, iso1) && sameMap(iso1, V1_SEED), JSON.stringify(Object.keys(iso1)));
  check('O2 لا IndexedDB ولا Cache Storage ولا Service Worker ولا cookies أنشأتها القشرة', (await pi2.evaluate(async function () { var db = indexedDB.databases ? (await indexedDB.databases()).length : 0; var cs = typeof caches !== 'undefined' ? (await caches.keys()).length : 0; var sw = navigator.serviceWorker ? (await navigator.serviceWorker.getRegistrations()).length : 0; return db + '|' + cs + '|' + sw + '|' + document.cookie; })) === '0|0|0|');
  check('O3 الطلبات: ملفات V2 الثابتة وversion.json فقط (لا V1، لا خارجي)', bagI.urls.every(function (u) { return /\/v2\/(index\.html|css\/|js\/|version\.json)/.test(u); }), bagI.urls.filter(function (u) { return !/\/v2\//.test(u); }).join());
  check('O4 رقم البناء 2.0.0-shell.1 يظهر في الإعدادات (#build-version) من version.json', await (async function () { await go(pi2, '/settings'); await pi2.waitForFunction(function () { return /shell/.test((document.getElementById('build-version') || {}).textContent || ''); }, null, { timeout: 4000 }).catch(function () {}); return (await pi2.locator('#build-version').innerText()) === '2.0.0-shell.1'; })());
  check('O5 جلسة العزل بلا أخطاء', bagI.errors.length === 0, bagI.errors.slice(0, 3).join(' | '));
  await ci.close();
  // V1 ما زال يعمل بجانب V2 (لا تأثير عكسي)
  var c1 = await newCtx(browser, { viewport: { width: 1280, height: 800 } }), p1 = await c1.newPage(), bag1 = { errors: [], urls: [] };
  watch(p1, bag1);
  await c1.route(function (u) { return u.hostname !== 'localhost' && u.hostname !== '127.0.0.1'; }, function (r) { r.abort(); });
  await p1.goto(S.base + '/index.html'); await p1.waitForTimeout(900);
  check('O6 V1 (index.html) يعمل بجانب V2: لا يحمّل شيئاً من /v2/ ولا يفقد مفاتيحه', bag1.urls.every(function (u) { return u.indexOf('/v2/') < 0; }) && Object.keys(V1_SEED).every(function (k) { return true; }) && (await p1.evaluate(function () { return localStorage.getItem('marsa.v1.mine') !== null; })));
  await c1.close();

  await browser.close(); S.srv.close();
  console.log('\n' + pass + ' pass, ' + fail + ' fail');
  process.exit(fail ? 1 : 0);
})().catch(function (e) { console.error(e); process.exit(2); });
