// اختبار تدقيق المرحلة 03.13: أساس الصفوف والطلاب + المقدمة + بوابة الممثل + الموبايل (Playwright + Chromium، اختياري).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-stage3-audit.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
async function open(browser, vp) {
  var ctx = await browser.newContext({ viewport: vp || { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.goto(URL);
  return { ctx: ctx, page: page };
}
async function skip(page) { await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function unlock(page) { await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")'); }
async function toRep(page) { if (await page.$eval('.seg', function (s) { return s.hidden; })) await unlock(page); await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 }); }
async function rawKey(page, k) { return page.evaluate(function (k) { return localStorage.getItem(k); }, k); }
async function addClass(page, stage) {
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', stage); await page.click('#dlg-class button.primary');
  await page.waitForSelector('#dlg-class', { state: 'hidden' });
}
async function addStudents(page, text) {
  await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")');
  await page.fill('#add-names', text); await page.click('#dlg-add button.primary');
  await page.click('#dlg-add button:has-text("تأكيد الإضافة")'); await page.waitForSelector('#dlg-add', { state: 'hidden' });
}
(async function () {
  var browser = await pw.chromium.launch();
  // ===== المقدمة والوضع =====
  var o = await open(browser), p = o.page;
  await p.waitForSelector('#intro:not([hidden])');
  check('05 المقدمة تظهر عند أول تحميل', true);
  check('05 زر التخطي يعمل', await (async function () { await p.click('#skip-intro'); await p.waitForSelector('#intro', { state: 'hidden' }); return true; })());
  check('05 مبدّل الوضع واحد فقط في الصفحة', (await p.$$('.seg')).length === 1);
  check('05 المبدّل مخفي قبل الرمز التجريبي', await p.$eval('.seg', function (s) { return s.hidden; }));
  check('05 لا مقدمة مكررة ولا #mode-fx ظاهر عند التحميل', await p.$eval('#mode-fx', function (e) { return e.hidden || getComputedStyle(e).display === 'none'; }));
  await p.click('#replay'); await p.waitForSelector('#intro:not([hidden])'); check('05 إعادة تشغيل المقدمة تعمل', true);
  await p.click('#skip-intro'); await p.waitForSelector('#intro', { state: 'hidden' });
  await p.click('.nav button:has-text("الإعدادات")'); await p.fill('#rep-code-in', 'خطأ'); await p.click('button:has-text("تفعيل")');
  check('05 رمز خاطئ يُرفض ويبقى المبدّل مخفياً', await p.$eval('.seg', function (s) { return s.hidden; }));
  await p.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await p.click('button:has-text("تفعيل")');
  check('05 الرمز التجريبي من الإعدادات يُظهر المبدّل', !(await p.$eval('.seg', function (s) { return s.hidden; })));
  await p.click('.seg button[data-m="rep"]');
  var fxShown = await p.waitForSelector('#mode-fx:not([hidden])', { timeout: 3000 }).then(function () { return true; }, function () { return false; });
  check('05 الانتقال البصري يظهر عند التبديل', fxShown);
  await p.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
  check('05 بعد الانتقال يصبح وضع الممثل نشطاً', (await p.getAttribute('html', 'data-mode')) === 'rep');
  check('05 الرمز لا يُخزَّن في localStorage/sessionStorage', await p.evaluate(function () { var all = ''; for (var i = 0; i < localStorage.length; i++) all += localStorage.getItem(localStorage.key(i)); for (var j = 0; j < sessionStorage.length; j++) all += sessionStorage.getItem(sessionStorage.key(j)); return all.indexOf('MRS-REP-DEMO-26') === -1; }));
  await p.reload(); await skip(p);
  check('05 المقدمة تظهر في كل تحميل (بعد إعادة التحميل)', true);
  check('05 بعد إعادة التحميل: الوضع طالب والمبدّل مخفي', (await p.getAttribute('html', 'data-mode')) === 'student' && await p.$eval('.seg', function (s) { return s.hidden; }));
  await o.ctx.close();
  // ===== الموبايل =====
  for (var w of [320, 360, 390, 430]) {
    var m = await open(browser, { width: w, height: 760 }); await skip(m.page);
    var ok1 = !(await overflow(m.page));
    await toRep(m.page);
    var views = ['اللوحة', 'الطلاب', 'الجدول', 'ما أُخذ اليوم', 'التحاضير', 'الامتحانات', 'الإعدادات'], bad = [];
    for (var v of views) { await m.page.click('.nav button:has-text("' + v + '")'); if (await overflow(m.page)) bad.push(v); }
    check('موبايل ' + w + 'px: لا تمرير أفقي (طالب + ' + views.length + ' شاشة ممثل)', ok1 && !bad.length, bad.join(','));
    var small = await m.page.$$eval('.nav button, .seg button, #main button.primary', function (els) { return els.filter(function (e) { return e.offsetParent && e.getBoundingClientRect().height < 40; }).map(function (e) { return e.textContent.trim().slice(0, 15) + ':' + Math.round(e.getBoundingClientRect().height); }); });
    if (w === 390) check('موبايل 390: أهداف اللمس الأساسية ≥ 40px ارتفاعاً', !small.length, small.join(' | '));
    await m.ctx.close();
  }
  // ===== الصفوف والطلاب =====
  var r = await open(browser), q = r.page; await skip(q); await toRep(q);
  await addStudents(q, 'يوسف علي\nأحمد حسن\nإبراهيم كريم\n  زينب  ');
  await q.waitForTimeout(200);
  var ro = JSON.parse(await rawKey(q, 'marsa.roster'));
  var names = ro.students.map(function (s) { return s.name; });
  check('طلاب: الإضافة الجماعية حفظت الأسماء الصالحة', ro.students.length >= 4, JSON.stringify(names));
  check('طلاب: studentId وstudentCode فريدان وغير فارغين', ro.students.every(function (s) { return s.studentId && s.studentCode; }) && new Set(ro.students.map(function (s) { return s.studentId; })).size === ro.students.length && new Set(ro.students.map(function (s) { return s.studentCode; })).size === ro.students.length);
  var shown = await q.$$eval('#v-page li, #v-page .stu', function (e) { return e.map(function (x) { return x.textContent; }).join('|'); });
  var order = ['إبراهيم', 'أحمد', 'زينب', 'يوسف'].map(function (n) { return shown.indexOf(n); });
  check('طلاب: الفرز العربي في العرض (إبراهيم < أحمد < زينب < يوسف: ب قبل ح)', order.every(function (x) { return x > -1; }) && order[0] < order[1] && order[1] < order[2] && order[2] < order[3], shown.slice(0, 200));
  var ids0 = ro.students.map(function (s) { return s.studentId + '/' + s.studentCode; }).join();
  await q.reload(); await skip(q);
  var ro2 = JSON.parse(await rawKey(q, 'marsa.roster'));
  check('طلاب: studentId/studentCode ثابتان بعد إعادة التحميل', ro2.students.map(function (s) { return s.studentId + '/' + s.studentCode; }).join() === ids0);
  await toRep(q);
  await q.click('.nav button:has-text("الطلاب")'); await q.click('button:has-text("إضافة طلاب")');
  await q.fill('#add-names', 'أحمد حسن'); await q.click('#dlg-add button.primary');
  var dupDisabled = await q.$eval('#dlg-add button:has-text("تأكيد الإضافة")', function (b) { return b.disabled; });
  var dupTxt = await q.textContent('#dlg-add');
  check('طلاب: التحذير من تكرار الاسم يمنع التأكيد حتى الإقرار', dupDisabled && /مكرر|مشابه|موجود|تكرار/.test(dupTxt), dupTxt.slice(0, 160));
  await q.keyboard.press('Escape'); // 4.07: Escape مع أسماء غير محفوظة يطلب تأكيد التجاهل بدل الإغلاق الصامت
  await q.waitForSelector('#dlg-confirm[open]'); await q.click('#dlg-confirm button.primary');
  await q.waitForSelector('#dlg-add', { state: 'hidden' }).catch(function () {});
  // صف جديد + عزل
  await addClass(q, 'الصف الثالث');
  var cl = JSON.parse(await rawKey(q, 'marsa.classes'));
  var newC = cl.classes.filter(function (c) { return c.stage === 'الصف الثالث'; })[0];
  check('صفوف: classId ثابت وفريد للصف الجديد', newC && /\S/.test(newC.classId) && newC.classId !== 'cls_demo_001', JSON.stringify(newC));
  await q.click('button:has-text("اختيار")').catch(function () {});
  var act1 = JSON.parse(await rawKey(q, 'marsa.classes')).activeClassId;
  if (act1 !== (newC && newC.classId)) { var btns = await q.$$('#v-page button:has-text("اختيار"), #v-page button:has-text("تعيين")'); if (btns.length) await btns[btns.length - 1].click(); }
  var act = JSON.parse(await rawKey(q, 'marsa.classes')).activeClassId;
  check('صفوف: تبديل الصف النشط', act === (newC && newC.classId), String(act));
  await addStudents(q, 'سارة نور');
  var rosB = JSON.parse(await rawKey(q, 'marsa.roster.' + newC.classId));
  var rosA = JSON.parse(await rawKey(q, 'marsa.roster'));
  check('عزل: قائمة الصف الجديد مستقلة وclassId داخلها صحيح', rosB.classId === newC.classId && rosB.students.length === 1 && rosB.students[0].name === 'سارة نور');
  check('عزل: قائمة الصف التجريبي لم تتغير بعد الإضافة في صف آخر', JSON.stringify(rosA.students.map(function (s) { return s.studentId; })) === JSON.stringify(ro2.students.map(function (s) { return s.studentId; })));
  // أرشفة/استعادة طالب
  await q.click('.nav button:has-text("الطلاب")');
  var arch = await q.$('#v-page button:has-text("أرشفة")');
  if (arch) { await arch.click(); var cf = await q.$('#dlg-confirm button.danger, #dlg-confirm button.primary'); if (cf && await cf.isVisible()) await cf.click(); await q.waitForTimeout(200); }
  var rosB2 = JSON.parse(await rawKey(q, 'marsa.roster.' + newC.classId));
  check('طلاب: الأرشفة تغيّر الحالة ولا تحذف السجل', rosB2.students.length === 1 && rosB2.students[0].status !== 'active' && rosB2.students[0].studentId === rosB.students[0].studentId);
  await q.click('button:has-text("الطلاب المحذوفون")');
  var rs = await q.$('#v-page button:has-text("استعادة") >> visible=true'); if (rs) { await rs.click(); var cf2 = await q.$('#dlg-confirm button.primary'); if (cf2 && await cf2.isVisible()) await cf2.click(); await q.waitForTimeout(200); }
  var rosB3 = JSON.parse(await rawKey(q, 'marsa.roster.' + newC.classId));
  check('طلاب: الاستعادة تعيد active بنفس studentId وstudentCode', rosB3.students[0].status === 'active' && rosB3.students[0].studentId === rosB.students[0].studentId && rosB3.students[0].studentCode === rosB.students[0].studentCode);
  // أرشفة/استعادة صف
  await q.click('.nav button:has-text("اللوحة")'); await q.click('button:has-text("إدارة الصفوف")');
  var ab = await q.$$('#v-page button:has-text("أرشفة") >> visible=true'); await ab[ab.length - 1].click();
  var cf3 = await q.$('#dlg-confirm button.primary, #dlg-confirm button.danger'); if (cf3 && await cf3.isVisible()) await cf3.click();
  await q.waitForTimeout(200);
  var c2 = JSON.parse(await rawKey(q, 'marsa.classes')).classes.filter(function (c) { return c.classId === newC.classId; })[0];
  check('صفوف: الأرشفة تحفظ الصف بحالة archived وclassId نفسه', c2 && c2.status === 'archived');
  check('صفوف: قائمة طلاب الصف المؤرشف باقية', !!(await rawKey(q, 'marsa.roster.' + newC.classId)));
  var rb = await q.$('#v-page button:has-text("استعادة") >> visible=true'); if (rb) { await rb.click(); var cf4 = await q.$('#dlg-confirm button.primary'); if (cf4 && await cf4.isVisible()) await cf4.click(); await q.waitForTimeout(200); }
  var c3 = JSON.parse(await rawKey(q, 'marsa.classes')).classes.filter(function (c) { return c.classId === newC.classId; })[0];
  check('صفوف: الاستعادة تعيد active بنفس classId', c3 && c3.status === 'active' && c3.classId === newC.classId);
  check('بيانات: مفتاح marsa.roster القديم لم يُمسّ شكله (schemaVersion 2)', JSON.parse(await rawKey(q, 'marsa.roster')).schemaVersion === 2);
  await r.ctx.close();
  // ===== localStorage غير متاح =====
  var n = await browser.newContext({ viewport: { width: 390, height: 780 }, locale: 'ar-IQ', isMobile: true, hasTouch: true });
  await n.addInitScript(function () { try { Object.defineProperty(window, 'localStorage', { get: function () { throw new Error('denied'); } }); } catch (e) { } });
  var np = await n.newPage(); np.on('pageerror', function (e) { jsErrors.push('nols: ' + e.message); });
  await np.goto(URL); await skip(np);
  var txt = await np.textContent('body');
  check('تخزين غير متاح: التطبيق يفتح بلا أخطاء ويعرض رسالة توضيحية', (await np.$('#v-home')) && /غير متاح|مؤقت|المتصفح/.test(txt));
  await n.close();
  await browser.close();
  var f = results.filter(function (x) { return !x.ok; }).length;
  console.log('\n' + (results.length - f) + ' passed, ' + f + ' failed; JS errors: ' + jsErrors.length + (jsErrors.length ? ' :: ' + jsErrors.slice(0, 3).join(' | ') : ''));
  process.exit(f || jsErrors.length ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
