// اختبار واجهة المرحلة 4.06 (ربط الحضور والدرجات والمدفوعات بلوحة الممثل والأرشيف وعزل الصفوف) بـ Playwright + Chromium.
// تشغيل: PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers NODE_PATH=$(npm root -g) node tests/e2e-stage4-integration.playwright.js
// ساعة مزيّفة: الخميس 2026-10-22 09:00 بغداد. كل البيانات المزروعة تُنشأ داخل الاختبار نفسه (لا بيانات في التطبيق).
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z', TODAY = '2026-10-22';
var DEMO = 'cls_demo_001', TWO = 'cls_two';
function classesJson(active) {
  return JSON.stringify({ schemaVersion: 1, activeClassId: active, classes: [
    { classId: DEMO, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة', section: '', year: '', status: 'active', createdAt: null, archivedAt: null },
    { classId: TWO, schoolName: '', stage: 'الثالث المتوسط', branch: '', section: 'ب', year: '', status: 'active', createdAt: null, archivedAt: null }] });
}
async function open(browser) {
  var ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.clock.install({ time: new Date(NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  if ((await page.$('.seg button[data-m="rep"]:not([hidden])')) === null) {
    await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
  }
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function setStore(page, type, cid, records) {
  await page.evaluate(function (a) { localStorage.setItem('marsa.academic.' + a.type + '.' + a.cid, JSON.stringify({ schemaVersion: 1, classId: a.cid, records: a.records })); }, { type: type, cid: cid, records: records });
}
async function setClasses(page, active) { await page.evaluate(function (j) { localStorage.setItem('marsa.classes', j); }, classesJson(active)); }
function base(id, cid, o) { return Object.assign({ recordId: id, classId: cid, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
function att(id, cid, sid, date, status) { return base(id, cid, { studentId: sid, date: date, status: status, note: 'سرّ-الغياب' }); }
function grd(id, cid, sid, title, date, score) { return base(id, cid, { studentId: sid, subject: 'سرّ-المادة', title: title, date: date, score: score, maxScore: 10, note: 'سرّ-الدرجة' }); }
function pay(id, cid, sid, date, amount) { return base(id, cid, { studentId: sid, amount: amount, purpose: 'سرّ-الغرض', date: date, receiptNo: 'سرّ-وصل', note: 'سرّ-الملاحظة' }); }
async function reload(page) { await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function repRow(page, name) { var r = await page.$('.sumlist li[data-sum="' + name + '"]'); return r ? ((await r.textContent()) || '') : null; }
async function backToDash(page) { await page.click('.nav button:has-text("اللوحة")'); await page.waitForSelector('.sumlist'); }
async function gotoNav(page, label) { await page.click('.nav button:has-text("' + label + '")'); await page.waitForTimeout(150); }

(async function main() {
  var browser = await pw.chromium.launch(), c, page, t, r;

  // ===== 1) بلا بيانات: صفوف الملخص تشرح البدء ولا أرقام مختلقة =====
  c = await open(browser); page = c.page;
  await setClasses(page, DEMO); await reload(page); await toRep(page);
  r = await repRow(page, 'الحضور');
  check('فارغ: صف الحضور يشرح البدء ولا رقم', r !== null && /لم يُسجَّل حضور بعد/.test(r) && !/\d/.test(r), r);
  check('فارغ: صفا الدرجات والمدفوعات يشرحان البدء', /لا درجات بعد/.test(await repRow(page, 'الدرجات')) && /لا وصولات بعد/.test(await repRow(page, 'المدفوعات')));
  t = (await page.textContent('.sumlist')) || '';
  check('فارغ: الملخص فيه التذكير بأن وضع الممثل تجريبي', /ليس حماية أمنية حقيقية/.test((await page.textContent('main')) || ''));

  // ===== 2) بيانات حقيقية: العدّادات من السجلات (الصف النشط وحده) =====
  await setStore(page, 'attendance', DEMO, [att('a1', DEMO, 's1', TODAY, 'present'), att('a2', DEMO, 's2', TODAY, 'absent'), att('a3', DEMO, 's1', '2026-10-21', 'absent')]);
  await setStore(page, 'grades', DEMO, [grd('g1', DEMO, 's1', 'اختبار 1', TODAY, 8), grd('g2', DEMO, 's2', 'اختبار 1', TODAY, 6), grd('g3', DEMO, 's1', 'شفوي', '2026-10-20', 9)]);
  await setStore(page, 'payments', DEMO, [pay('p1', DEMO, 's1', TODAY, 25000), pay('p2', DEMO, 's2', '2026-10-01', 5000)]);
  // بيانات صف آخر لا يجوز أن تتسرب
  await setStore(page, 'attendance', TWO, [att('b1', TWO, 'x1', TODAY, 'absent'), att('b2', TWO, 'x2', TODAY, 'absent'), att('b3', TWO, 'x3', TODAY, 'absent'), att('b4', TWO, 'x4', TODAY, 'absent')]);
  await setStore(page, 'payments', TWO, [pay('q1', TWO, 'x1', TODAY, 777000)]);
  await gotoNav(page, 'الحضور'); await backToDash(page);
  r = await repRow(page, 'الحضور');
  check('الحضور: 3 سجلات، اليوم 2، غياب اليوم 1', /3 سجل/.test(r) && /اليوم: 2/.test(r) && /غياب: 1/.test(r), r);
  r = await repRow(page, 'الدرجات');
  check('الدرجات: 3 درجات في تقييمين، سُجّل اليوم 2', /3 درجة في 2 تقييم/.test(r) && /سُجّل اليوم: 2/.test(r), r);
  r = await repRow(page, 'المدفوعات');
  check('المدفوعات: وصلان واليوم 1 (عدد فقط)', /2 وصل/.test(r) && /اليوم: 1/.test(r), r);
  t = (await page.textContent('.sumlist')) || '';
  check('الملخص بلا مبلغ ولا اسم ولا ملاحظة', !/25000|25,000|5000|777000|سرّ/.test(t), t);
  check('لا تسرب من الصف الآخر (غياب 4 سجلات لا يظهر هنا)', !/4 سجل/.test(await repRow(page, 'الحضور')) && !/3 وصل/.test(await repRow(page, 'المدفوعات')));

  // ===== 3) إضافة/تعديل/حذف ينعكس بعد العودة =====
  await setStore(page, 'attendance', DEMO, [att('a1', DEMO, 's1', TODAY, 'present'), att('a2', DEMO, 's2', TODAY, 'absent'), att('a3', DEMO, 's1', '2026-10-21', 'absent'), att('a4', DEMO, 's3', TODAY, 'absent')]);
  await gotoNav(page, 'الحضور'); await backToDash(page);
  check('إضافة سجل: الحضور يصير 4 واليوم 3 وغياب 2', /4 سجل/.test(await repRow(page, 'الحضور')) && /غياب: 2/.test(await repRow(page, 'الحضور')), await repRow(page, 'الحضور'));
  await setStore(page, 'attendance', DEMO, [att('a1', DEMO, 's1', TODAY, 'present'), att('a2', DEMO, 's2', TODAY, 'present'), att('a3', DEMO, 's1', '2026-10-21', 'absent'), att('a4', DEMO, 's3', TODAY, 'absent')]);
  await gotoNav(page, 'الحضور'); await backToDash(page);
  check('تعديل سجل (غائب→حاضر): الغياب يصير 1', /غياب: 1/.test(await repRow(page, 'الحضور')), await repRow(page, 'الحضور'));
  await setStore(page, 'payments', DEMO, []);
  await gotoNav(page, 'المدفوعات'); await backToDash(page);
  check('حذف كل الوصولات: يعود صف المدفوعات لحالة الفراغ بلا رقم', /لا وصولات بعد/.test(await repRow(page, 'المدفوعات')) && !/\d/.test(await repRow(page, 'المدفوعات')));

  // ===== 4) تبديل الصف النشط =====
  await setClasses(page, TWO); await reload(page); await toRep(page);
  r = await repRow(page, 'الحضور');
  check('الصف الثاني: الحضور 4 سجلات كلها غياب اليوم', /4 سجل/.test(r) && /غياب: 4/.test(r), r);
  check('الصف الثاني: لا درجات (لا تسرب من الأول)', /لا درجات بعد/.test(await repRow(page, 'الدرجات')));
  check('الصف الثاني: وصل واحد فقط', /1 وصل/.test(await repRow(page, 'المدفوعات')), await repRow(page, 'المدفوعات'));

  // ===== 5) تلف البيانات: خطأ صريح لا صفر =====
  await page.evaluate(function (cid) { localStorage.setItem('marsa.academic.grades.' + cid, '{bad json'); }, TWO);
  await gotoNav(page, 'الدرجات'); await backToDash(page);
  r = await repRow(page, 'الدرجات');
  check('بيانات درجات تالفة: «تعذّرت قراءتها» لا صفر ولا فراغ', /تعذّرت قراءتها/.test(r), r);
  check('البيانات التالفة لم تُكتب فوقها', await page.evaluate(function (cid) { return localStorage.getItem('marsa.academic.grades.' + cid) === '{bad json'; }, TWO));
  await page.evaluate(function (cid) { localStorage.removeItem('marsa.academic.grades.' + cid); }, TWO);

  // ===== 6) منع الحذف النهائي لصف فيه حضور/درجات/مدفوعات فقط =====
  await setClasses(page, DEMO); await reload(page); await toRep(page);
  await page.click('button:has-text("إدارة الصفوف")').catch(function () {});
  await page.waitForSelector('.cls', { timeout: 4000 }).catch(function () {});
  var cards = await page.$$('.cls');
  check('صفحة الصفوف تعرض الصفين', cards.length === 2, String(cards.length));
  async function tryDelete() {
    var btn = await page.$('button[aria-label*="حذف نهائي"][aria-label*="الثالث المتوسط"]');
    if (!btn) return null;
    await btn.click(); await page.waitForSelector('#dlg-conf-t, dialog[open] h2, [role=dialog] h2', { timeout: 3000 }).catch(function () {});
    var txt = (await page.textContent('body')) || '';
    var closeBtn = await page.$('button:has-text("حسناً")'); if (closeBtn) await closeBtn.click();
    else { var cancel = await page.$('button:has-text("إلغاء")'); if (cancel) await cancel.click(); }
    await page.waitForTimeout(100);
    return txt;
  }
  var d1 = await tryDelete();
  check('صف فيه حضور ومدفوعات فقط: الحذف النهائي ممنوع برسالة السجلات الدراسية', d1 !== null && /لا يمكن حذف هذا الصف نهائياً/.test(d1) && /السجلات الدراسية/.test(d1), d1 && d1.slice(0, 120));
  check('السجلات باقية بعد محاولة الحذف', await page.evaluate(function (cid) { return JSON.parse(localStorage.getItem('marsa.academic.attendance.' + cid)).records.length === 4 && JSON.parse(localStorage.getItem('marsa.academic.payments.' + cid)).records.length === 1; }, TWO));
  // أرشفة الصف تُبقي سجلاته
  var arch = await page.$('button[aria-label*="أرشفة"][aria-label*="الثالث المتوسط"]');
  if (arch) { await arch.click(); await page.click('button:has-text("أرشفة الصف")'); await page.waitForTimeout(200); }
  check('أرشفة الصف تُبقي حضوره ومدفوعاته', await page.evaluate(function (cid) { return JSON.parse(localStorage.getItem('marsa.academic.attendance.' + cid)).records.length === 4 && JSON.parse(localStorage.getItem('marsa.academic.payments.' + cid)).records.length === 1; }, TWO));
  var d2 = await tryDelete();
  check('الصف المؤرشف ذو السجلات ما زال لا يُحذف نهائياً', d2 !== null && /لا يمكن حذف هذا الصف نهائياً/.test(d2), d2 && d2.slice(0, 120));
  await c.ctx.close();

  // ===== 7) وضع الطالب والأرشيف: لا بيانات فردية ولا ملخصات مالية =====
  c = await open(browser); page = c.page;
  await setClasses(page, DEMO);
  await setStore(page, 'attendance', DEMO, [att('a1', DEMO, 's1', '2026-10-20', 'absent')]);
  await setStore(page, 'grades', DEMO, [grd('g1', DEMO, 's1', 'اختبار 1', '2026-10-20', 3)]);
  await setStore(page, 'payments', DEMO, [pay('p1', DEMO, 's1', '2026-10-20', 987654)]);
  await setStore(page, 'dailyLessons', DEMO, [base('l1', DEMO, { subject: 'الشبكات', title: 'درس عام', date: '2026-10-20' })]);
  await reload(page);
  var body = (await page.textContent('body')) || '';
  check('الرئيسية (طالب): لا عدّادات حضور/درجات/مدفوعات ولا ملخص الممثل', !(await page.$('.sumlist')) && !/987654|سرّ/.test(body));
  async function studentPages() {
    var labels = ['الجدول', 'التحاضير', 'الأرشيف', 'الامتحانات', 'الإعلانات', 'المواد والملازم', 'درجاتي', 'غيابي', 'الإعدادات'], leaks = [], i, tx;
    for (i = 0; i < labels.length; i++) {
      await page.click('.nav button:has-text("' + labels[i] + '")'); await page.waitForTimeout(120);
      tx = (await page.textContent('body')) || '';
      if (/987654|سرّ-|stu_|s1\b/.test(tx)) leaks.push(labels[i]);
    }
    return leaks;
  }
  var leaks = await studentPages();
  check('كل صفحات الطالب بلا درجة ولا غياب ولا مبلغ فردي', leaks.length === 0, leaks.join(','));
  await page.click('.nav button:has-text("درجاتي")');
  check('«درجاتي» تشرح أن العرض الفردي يحتاج مصادقة', /المصادقة|مصادقة/.test((await page.textContent('main')) || ''), ((await page.textContent('main')) || '').slice(0, 160));
  await page.click('.nav button:has-text("الأرشيف")'); await page.waitForTimeout(150);
  t = (await page.textContent('main')) || '';
  check('الأرشيف مشتق: يعرض الدرس العام ولا يعرض سجل حضور/درجة/دفعة', /درس عام/.test(t) && !/غياب|987654|اختبار 1|سرّ/.test(t), t.slice(0, 200));
  var before = await page.evaluate(function () { return Object.keys(localStorage).sort().join('|'); });
  await toRep(page); await toStudent(page);
  var after = await page.evaluate(function () { return Object.keys(localStorage).sort().join('|'); });
  check('الأرشيف لم ينشئ مجموعة تخزين جديدة (مشتق فقط): لا مفتاح يحوي archive ومجموعة المفاتيح لم تتغير', !/archive/i.test(after) && before === after, before + ' => ' + after);
  check('بعد العودة لوضع الطالب: لا DOM مخفي لملخص الممثل', !(await page.$('.sumlist')) && !/987654|سرّ-/.test((await page.textContent('body')) || ''));
  await c.ctx.close();

  await browser.close();
  var failed = results.filter(function (x) { return !x.ok; }).length;
  check('لا أخطاء JavaScript أثناء الاختبار', jsErrors.length === 0, jsErrors.join(' | '));
  failed += jsErrors.length ? 1 : 0;
  console.log('\n' + (results.length) + ' checks, ' + failed + ' failed');
  process.exit(failed ? 1 : 0);
})().catch(function (e) { console.log('CRASH ' + e.stack); process.exit(2); });
