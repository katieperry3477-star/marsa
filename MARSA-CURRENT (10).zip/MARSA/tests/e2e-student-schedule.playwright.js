// اختبار واجهة المرحلة 03.7 (الجدول الدراسي للطالب، قراءة فقط) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-student-schedule.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة بساعة مزيّفة (الخميس 2026-10-22 09:00 بغداد). لقطات الشاشة تُحفظ في SHOTS_DIR إن عُرّف.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var SHOTS = process.env.SHOTS_DIR || '';
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z';
var DEMO = 'cls_demo_001', TWOID = 'cls_two', KEY = 'marsa.academic.schedule.' + DEMO, KEY2 = 'marsa.academic.schedule.' + TWOID, DKEY = 'marsa.scheduleDays.' + DEMO;
function classesJson(active) {
  return JSON.stringify({ schemaVersion: 1, activeClassId: active, classes: [
    { classId: DEMO, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null },
    { classId: TWOID, schoolName: '', stage: 'الثالث المتوسط', branch: '', section: 'ب', year: '', status: 'active', createdAt: null, archivedAt: null }] });
}
async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: opts.tz || 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(opts.clock || NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  if ((await page.$('.seg button[data-m="rep"]:not([hidden])')) === null) {
    await page.click('.nav button:has-text("الإعدادات")');
    await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
    await page.click('button:has-text("تفعيل")');
  }
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function nav(page, label) { await page.click('.nav button:has-text("' + label + '")'); await page.waitForSelector('#page-title'); }
async function seed(page, key, classId, records) { await page.evaluate(function (a) { localStorage.setItem(a.key, JSON.stringify({ schemaVersion: 1, classId: a.classId, records: a.records })); }, { key: key, classId: classId, records: records }); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function allStorage(page) { return page.evaluate(function () { var o = {}; for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('marsa.ui') !== 0) o[k] = localStorage.getItem(k); } return JSON.stringify(o); }); }
async function keys(page) { return page.evaluate(function () { var o = []; for (var i = 0; i < localStorage.length; i++) o.push(localStorage.key(i)); return o.sort(); }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function pageText(page) { return page.textContent('#v-page'); }
async function rowTitles(page) { return page.$$eval('#v-page .st-prow h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function dayRows(page, day) { return page.$$eval('#v-page [data-day="' + day + '"].pgroup .st-prow', function (l) { return l.map(function (li) { return li.querySelector('h3').textContent + '|' + (li.querySelector('.pr-t') ? li.querySelector('.pr-t').textContent : '') + '|' + li.querySelector('.pnum').textContent; }); }); }
async function dayTab(page, name) { await page.click('.dtab:has-text("' + name + '")'); }
async function shot(page, name) { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); }
function rec(id, o, cls) { return Object.assign({ recordId: id, classId: cls || DEMO, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
// بيانات مخزَّنة عمداً بترتيب مخلوط (الترتيب الظاهر لا يعتمد على موضع السجل)
function mixed() {
  return [
    rec('sch_5', { day: 'thu', subject: 'مادة بلا رقم ولا وقت' }),
    rec('sch_3', { day: 'thu', subject: 'الحصة الثالثة', period: 3, startTime: '10:15', endTime: '11:00' }),
    rec('sch_1', { day: 'thu', subject: 'الحصة الأولى', period: 1, startTime: '08:00', endTime: '08:45' }),
    rec('sch_4', { day: 'thu', subject: 'بلا رقم مع وقت', startTime: '07:30' }),
    rec('sch_2', { day: 'thu', subject: 'الحصة الثانية بلا وقت', period: 2 }),
    rec('sch_s', { day: 'sun', subject: 'حصة الأحد', period: 1, startTime: '00:05', endTime: '23:59' }),
    rec('sch_n', { day: 'mon', subject: 'حصة الاثنين', period: 2, startTime: '13:30', endTime: '14:15', notes: 'سطر أول\nانظر https://example.com/x لاحقاً' })
  ];
}

(async function main() {
  var browser = await pw.chromium.launch();
  var c, page, t, before, after, i;

  // ===== 1) الفراغ: رسالة مفيدة، لا بيانات وهمية، لا كتابة، لا أزرار تعديل =====
  c = await open(browser, { label: 'empty' }); page = c.page;
  await nav(page, 'الجدول');
  t = await pageText(page);
  check('Empty: helpful message explains how it fills (rep builds it)', /لم يُضف ممثل الصف جدول الحصص بعد/.test(t) && /وضعه/.test(t));
  check('Empty: no placeholder «لم يُضف جدول الحصص بعد.» static part and no «يُفعّل في مرحلة لاحقة»', !/يُفعّل في مرحلة لاحقة|هذا القسم جاهز للربط/.test(t) && (await page.$('.page-head .act')) === null);
  check('Empty: no invented lessons/periods/times (no .st-prow, no day tabs, no mode toggle)', (await page.$$('.st-prow')).length === 0 && (await page.$$('.dtab')).length === 0 && (await page.$('.sctrl:not([hidden]) button')) === null);
  check('Empty: count shows 0', /عدد الحصص: 0/.test(t));
  check('Empty: nothing written to storage by opening the page', (await keys(page)).filter(function (k) { return /schedule|scheduleDays/.test(k); }).length === 0, JSON.stringify(await keys(page)));
  check('Empty: no horizontal page scroll at 390', !(await overflow(page)));
  await shot(page, 'sched-empty-390');
  await c.ctx.close();

  // ===== 2) ترتيب وعرض الحصص من بيانات مخزَّنة بترتيب مخلوط =====
  c = await open(browser, { label: 'order' }); page = c.page;
  await seed(page, KEY, DEMO, mixed());
  await nav(page, 'الجدول');
  check('Default day is today (Thursday) with pressed tab and «اليوم» tag', (await page.$eval('.dtab[aria-pressed="true"] .dn', function (e) { return e.textContent; })) === 'الخميس' && /اليوم/.test(await page.textContent('.pgroup .tag.on')));
  check('Thursday order: period asc, then by start time, unnumbered last (no-time last)', JSON.stringify(await rowTitles(page)) === JSON.stringify(['الحصة الأولى', 'الحصة الثانية بلا وقت', 'الحصة الثالثة', 'بلا رقم مع وقت', 'مادة بلا رقم ولا وقت']), JSON.stringify(await rowTitles(page)));
  var thu = await dayRows(page, 'thu');
  check('Time shown only when entered: 8:00 ص – 8:45 ص; none for no-time rows', thu[0] === 'الحصة الأولى|8:00 ص – 8:45 ص|1' && thu[1] === 'الحصة الثانية بلا وقت||2' && thu[4] === 'مادة بلا رقم ولا وقت||—', JSON.stringify(thu));
  check('Start-only time shows «من 7:30 ص»; unnumbered shows — and «بلا رقم» (no invented number)', thu[3] === 'بلا رقم مع وقت|من 7:30 ص|—' && /بلا رقم/.test(await page.textContent('.st-prow:nth-child(5) .pr-n')));
  check('Day count in tab labels (Thursday 5)', /5/.test(await page.$eval('.dtab[data-day="thu"] .dc', function (e) { return e.textContent; })));
  await dayTab(page, 'الأحد');
  check('Sunday: 00:05 – 23:59 shown as 12:05 ص – 11:59 م (no timezone/day flip)', (await dayRows(page, 'sun'))[0] === 'حصة الأحد|12:05 ص – 11:59 م|1', JSON.stringify(await dayRows(page, 'sun')));
  await dayTab(page, 'الاثنين');
  check('Monday: 13:30 – 14:15 shown as 1:30 م – 2:15 م; note multi-line kept, safe link only', (await dayRows(page, 'mon'))[0] === 'حصة الاثنين|1:30 م – 2:15 م|2' && (await page.$eval('.pr-note', function (e) { return e.textContent.indexOf('سطر أول') === 0; })) && (await page.$$eval('.pr-note a', function (l) { return l.length === 1 && l[0].href === 'https://example.com/x' && /noopener/.test(l[0].rel); })));
  check('Days without records but enabled show a gentle empty line (Tuesday)', (await (async function () { await dayTab(page, 'الثلاثاء'); return /لا توجد حصص مضافة ليوم الثلاثاء/.test(await page.textContent('#v-page .pgroup')); })()));
  await c.ctx.close();

  // ===== 3) التنقل بين الأيام: السابق/التالي، التبويبات، الأسبوع كله =====
  c = await open(browser, { label: 'nav' }); page = c.page;
  await seed(page, KEY, DEMO, mixed());
  await nav(page, 'الجدول');
  var steps = await page.$$eval('.dnav .dstep', function (l) { return l.map(function (b) { return { t: b.textContent, d: b.disabled, h: b.getBoundingClientRect().height, w: b.getBoundingClientRect().width }; }); });
  check('Prev/next buttons exist with next/prev day names; Thursday is last visible day so «next» disabled', steps.length === 2 && /الأربعاء/.test(steps[0].t) && steps[1].d === true, JSON.stringify(steps));
  check('Prev/next and day tabs are ≥44px tall touch targets', steps.every(function (s) { return s.h >= 43.5; }) && (await page.$$eval('.dtab', function (l) { return l.every(function (b) { return b.getBoundingClientRect().height >= 43.5; }); })));
  await page.click('.dnav .dstep >> nth=0');
  check('Prev goes to Wednesday (empty day message, no Thursday rows)', (await page.$eval('.dtab[aria-pressed="true"] .dn', function (e) { return e.textContent; })) === 'الأربعاء' && (await rowTitles(page)).length === 0);
  for (i = 0; i < 3; i++) await page.click('.dnav .dstep >> nth=0');
  check('Three more prevs reach Sunday (first visible), «prev» disabled', (await page.$eval('.dtab[aria-pressed="true"] .dn', function (e) { return e.textContent; })) === 'الأحد' && (await page.$eval('.dnav .dstep >> nth=0', function (b) { return b.disabled; })) && (await rowTitles(page)).join('|') === 'حصة الأحد');
  await page.click('.sv button:has-text("الأسبوع كله")');
  var cards = await page.$$eval('#v-page .daycard[data-day]', function (l) { return l.map(function (x) { return x.getAttribute('data-day'); }); });
  check('Week view: all 5 visible days as cards in week order, tabs/nav hidden', JSON.stringify(cards) === JSON.stringify(['sun', 'mon', 'tue', 'wed', 'thu']) && (await page.$eval('.dtabs', function (e) { return e.hidden; })) && (await page.$eval('.dnav', function (e) { return e.hidden; })), JSON.stringify(cards));
  check('Week view data identical to day view data (Thursday rows)', (await dayRows(page, 'thu')).length === 5 && !(await overflow(page)));
  await shot(page, 'sched-week-390');
  await page.click('.sv button:has-text("يوم واحد")');
  check('Back to single-day mode keeps tabs visible', !(await page.$eval('.dtabs', function (e) { return e.hidden; })));
  await c.ctx.close();

  // ===== 4) مطابقة شاشة الممثل: نفس البيانات ونفس الترتيب =====
  c = await open(browser, { label: 'parity' }); page = c.page;
  await seed(page, KEY, DEMO, mixed());
  await toRep(page); await nav(page, 'الجدول');
  await page.click('.sv button:has-text("الأسبوع كله")');
  var repDump = await page.$$eval('#v-page .daycard[data-day]', function (cs) { return cs.map(function (cd) { return cd.getAttribute('data-day') + '=' + Array.prototype.map.call(cd.querySelectorAll('.prow'), function (li) { return li.querySelector('h3').textContent + '|' + (li.querySelector('.pr-t') ? li.querySelector('.pr-t').textContent : '') + '|' + li.querySelector('.pnum').textContent; }).join(';'); }).join('#'); });
  await toStudent(page); await nav(page, 'الجدول');
  await page.click('.sv button:has-text("الأسبوع كله")');
  var stDump = await page.$$eval('#v-page .daycard[data-day]', function (cs) { return cs.map(function (cd) { return cd.getAttribute('data-day') + '=' + Array.prototype.map.call(cd.querySelectorAll('.st-prow'), function (li) { return li.querySelector('h3').textContent + '|' + (li.querySelector('.pr-t') ? li.querySelector('.pr-t').textContent : '') + '|' + li.querySelector('.pnum').textContent; }).join(';'); }).join('#'); });
  check('Student week view equals rep week view (days, subjects, times, period numbers, order)', repDump === stDump && repDump.length > 40, repDump + '\n' + stDump);
  await c.ctx.close();

  // ===== 5) قراءة فقط: لا أزرار/حقول تعديل، ولا كتابة في التخزين =====
  c = await open(browser, { label: 'readonly' }); page = c.page;
  await seed(page, KEY, DEMO, mixed());
  before = await allStorage(page);
  await nav(page, 'الجدول');
  await page.click('.sv button:has-text("الأسبوع كله")'); await page.click('.sv button:has-text("يوم واحد")'); await dayTab(page, 'الاثنين'); await page.click('.dnav .dstep >> nth=1');
  var btns = await page.$$eval('#v-page button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  check('No edit/delete/add buttons in student schedule', !btns.some(function (x) { return /تعديل|حذف|إضافة|حفظ|إلغاء/.test(x); }), JSON.stringify(btns));
  check('No form controls at all (input/textarea/select/form/contenteditable)', (await page.$$('#v-page input, #v-page textarea, #v-page select, #v-page form, #v-page [contenteditable]')).length === 0);
  check('No dialog/rep-only controls leaked: no «ضبط أيام الأسبوع» details', (await page.$('#v-page details')) === null && !/ضبط أيام الأسبوع/.test(await pageText(page)));
  check('Storage bytes identical after browsing (no writes, no backups, no new keys)', (await allStorage(page)) === before);
  // محاولة تعديل بالنقر على الصف لا تفعل شيئاً
  await page.click('.st-prow h3 >> nth=0', { trial: false }).catch(function () {});
  check('Clicking a row opens nothing (no dialog, no form)', (await page.$('dialog[open]')) === null && (await page.$('#v-page form')) === null);
  await c.ctx.close();

  // ===== 6) رجوع من الممثل إلى الطالب: يظهر ما أضافه الممثل فعلاً عبر واجهته =====
  c = await open(browser, { label: 'return' }); page = c.page;
  await toRep(page); await nav(page, 'الجدول');
  await page.click('button:has-text("إضافة حصة") >> nth=0');
  await page.selectOption('#sf-day', 'thu'); await page.fill('#sf-subject', 'مادة أضافها الممثل'); await page.fill('#sf-period', '1'); await page.fill('#sf-startTime', '08:00'); await page.fill('#sf-endTime', '08:45');
  await page.click('button[type=submit]'); await page.waitForSelector('.lform', { state: 'hidden' });
  await toStudent(page); await nav(page, 'الجدول');
  check('Rep-added lesson appears in student view after returning', (await dayRows(page, 'thu')).join() === 'مادة أضافها الممثل|8:00 ص – 8:45 ص|1', JSON.stringify(await dayRows(page, 'thu')));
  await toRep(page); await nav(page, 'الجدول');
  await page.click('.prow:has-text("مادة أضافها الممثل") button:has-text("تعديل")');
  await page.fill('#sf-subject', 'مادة معدّلة'); await page.click('button[type=submit]'); await page.waitForSelector('.lform', { state: 'hidden' });
  await toStudent(page); await nav(page, 'الجدول');
  check('Rep edit is reflected in student view', (await rowTitles(page)).join() === 'مادة معدّلة', JSON.stringify(await rowTitles(page)));
  await c.ctx.close();

  // ===== 7) فصل الصفوف وتبديل الصف النشط =====
  c = await open(browser, { label: 'classes', init: 'try{if(!localStorage.getItem("marsa.classes"))localStorage.setItem("marsa.classes",' + JSON.stringify(classesJson(DEMO)) + ')}catch(e){}' }); page = c.page;
  var CKEY = await page.evaluate(function () { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (/class/i.test(k) && k.indexOf('academic') < 0 && k.indexOf('roster') < 0) return k; } return null; });
  check('Classes storage key found for two-class setup', !!CKEY, String(CKEY));
  if (CKEY) {
    await page.evaluate(function (a) { localStorage.setItem(a.k, a.v); }, { k: CKEY, v: classesJson(DEMO) });
    await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
    await seed(page, KEY, DEMO, [rec('a1', { day: 'thu', subject: 'مادة الصف الأول', period: 1 })]);
    await seed(page, KEY2, TWOID, [rec('b1', { day: 'thu', subject: 'مادة الصف الثاني', period: 1 }, TWOID), rec('b2', { day: 'thu', subject: 'ثانية الصف الثاني', period: 2 }, TWOID)]);
    await nav(page, 'الجدول');
    check('Class 1 student view shows only class 1 lesson', (await rowTitles(page)).join() === 'مادة الصف الأول');
    // تبديل الصف النشط من وضع الممثل ثم العودة
    await toRep(page); await nav(page, 'الجدول');
    await page.selectOption('#cb-sel', TWOID);
    await toStudent(page); await nav(page, 'الجدول');
    check('After switching active class to class 2: only class 2 lessons, none of class 1', (await rowTitles(page)).join('|') === 'مادة الصف الثاني|ثانية الصف الثاني' && !/مادة الصف الأول/.test(await pageText(page)), JSON.stringify(await rowTitles(page)));
    // تبديل الصف أثناء بقاء صفحة الطالب مفتوحة (حدث storage من تبويب آخر): لا يبقى جدول الصف السابق
    await page.evaluate(function (a) { localStorage.setItem(a.k, a.v); window.dispatchEvent(new StorageEvent('storage', { key: a.k })); }, { k: CKEY, v: classesJson(DEMO) });
    await page.waitForTimeout(150);
    check('Open student page re-renders on active-class change: shows class 1 only (no stale class 2)', (await rowTitles(page)).join() === 'مادة الصف الأول' && !/مادة الصف الثاني/.test(await pageText(page)), JSON.stringify(await rowTitles(page)));
    // الاختيار اليومي لا ينتقل بين الصفوف
    await page.evaluate(function (a) { localStorage.setItem(a.k, a.v); window.dispatchEvent(new StorageEvent('storage', { key: a.k })); }, { k: CKEY, v: classesJson(TWOID) });
    await page.waitForTimeout(150);
    check('And back to class 2 on change again', (await rowTitles(page)).join('|') === 'مادة الصف الثاني|ثانية الصف الثاني');
    // حصص صف آخر داخل مفتاح هذا الصف (classId غير مطابق) لا تُعرض
    await seed(page, KEY2, DEMO, [rec('x1', { day: 'thu', subject: 'سجل صف آخر' }, DEMO)]);
    await page.evaluate(function (k) { window.dispatchEvent(new StorageEvent('storage', { key: k })); }, KEY2);
    await page.waitForTimeout(150);
    check('Collection whose classId mismatches its key is blocked with alert (no foreign class data shown)', (await page.$('.st-err[role="alert"]')) !== null && !/سجل صف آخر/.test(await pageText(page)));
  }
  await c.ctx.close();

  // ===== 8) تحديث الصفحة المفتوحة عند تغيّر التخزين (حدث storage) =====
  c = await open(browser, { label: 'live' }); page = c.page;
  await seed(page, KEY, DEMO, [rec('l1', { day: 'thu', subject: 'قبل', period: 1 })]);
  await nav(page, 'الجدول');
  await seed(page, KEY, DEMO, [rec('l1', { day: 'thu', subject: 'قبل', period: 1 }), rec('l2', { day: 'thu', subject: 'بعد', period: 2 })]);
  await page.evaluate(function (k) { window.dispatchEvent(new StorageEvent('storage', { key: k })); }, KEY);
  await page.waitForTimeout(150);
  check('Open page picks up a storage event', (await rowTitles(page)).join('|') === 'قبل|بعد');
  await seed(page, KEY, DEMO, [rec('l3', { day: 'sat', subject: 'يوم مخفي عادة', period: 1 })]);
  await page.evaluate(function (k) { window.dispatchEvent(new StorageEvent('storage', { key: k })); }, KEY);
  await page.waitForTimeout(150);
  check('A day with lessons becomes visible even if not in weekdays setting (Saturday tab appears)', (await page.$('.dtab[data-day="sat"]')) !== null);
  await c.ctx.close();

  // ===== 9) إعداد أيام الأسبوع: يُقرأ فقط ولا يُكتب =====
  c = await open(browser, { label: 'days' }); page = c.page;
  await seed(page, KEY, DEMO, [rec('d1', { day: 'sun', subject: 'أحد', period: 1 })]);
  await page.evaluate(function (a) { localStorage.setItem(a.k, a.v); }, { k: DKEY, v: JSON.stringify({ schemaVersion: 1, classId: DEMO, days: ['sat', 'sun', 'mon'] }) });
  await nav(page, 'الجدول');
  check('Saved days setting respected (Sat, Sun, Mon only)', JSON.stringify(await page.$$eval('.dtab .dn', function (l) { return l.map(function (x) { return x.textContent; }); })) === JSON.stringify(['السبت', 'الأحد', 'الاثنين']));
  check('Today (Thu) not enabled → defaults to first visible day (Saturday), not a hidden day', (await page.$eval('.dtab[aria-pressed="true"] .dn', function (e) { return e.textContent; })) === 'السبت');
  await page.evaluate(function (k) { localStorage.setItem(k, '{bad json'); }, DKEY);
  await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  before = await allStorage(page);
  await nav(page, 'الجدول');
  check('Corrupt days setting: falls back to default days (Sun–Thu), lesson still shown, nothing written/backed up from student mode', JSON.stringify(await page.$$eval('.dtab .dn', function (l) { return l.map(function (x) { return x.textContent; }); })) === JSON.stringify(['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس']) && (await allStorage(page)) === before);
  await c.ctx.close();

  // ===== 10) بيانات تالفة: تنبيه واضح لا رسالة فراغ =====
  var bads = [
    ['JSON تالف', '{not json'],
    ['نسخة أحدث', JSON.stringify({ schemaVersion: 99, classId: DEMO, records: [] })],
    ['classId لا يطابق', JSON.stringify({ schemaVersion: 1, classId: 'other', records: [rec('z', { day: 'thu', subject: 'غريب' })] })],
    ['سجل غير صالح', JSON.stringify({ schemaVersion: 1, classId: DEMO, records: [{ recordId: 'bad', classId: DEMO, day: 'thu' }, 5] })]
  ];
  for (i = 0; i < bads.length; i++) {
    c = await open(browser, { label: 'bad' + i }); page = c.page;
    await page.evaluate(function (a) { localStorage.setItem(a.k, a.v); }, { k: KEY, v: bads[i][1] });
    await nav(page, 'الجدول'); t = await pageText(page);
    check('Bad data [' + bads[i][0] + ']: alert shown, says emptiness cannot be asserted, no empty-state, no tabs, no stranger data', (await page.$('.st-err[role="alert"]')) !== null && /لا يمكن الجزم/.test(t) && !/لم يُضف ممثل الصف جدول الحصص بعد/.test(t) && (await page.$$('.dtab, .st-prow')).length === 0 && !/غريب/.test(t), t.slice(0, 200));
    check('Bad data [' + bads[i][0] + ']: no horizontal scroll', !(await overflow(page)));
    if (i === 0) await shot(page, 'sched-error-390');
    await c.ctx.close();
  }

  // ===== 11) التخزين غير متاح =====
  c = await open(browser, { label: 'nostore', init: 'try{Object.defineProperty(window,"localStorage",{get:function(){throw new Error("denied")}})}catch(e){}' }); page = c.page;
  await nav(page, 'الجدول'); t = await pageText(page);
  check('Storage unavailable: clear temporary-storage warning shown, page still renders without crashing', /التخزين الدائم غير متاح/.test(t) && (await page.$('#page-title')) !== null, t.slice(0, 200));
  await c.ctx.close();

  // ===== 12) لا صف نشط =====
  c = await open(browser, { label: 'noclass', init: 'try{localStorage.setItem("marsa.classes",' + JSON.stringify(JSON.stringify({ schemaVersion: 1, activeClassId: null, classes: [{ classId: DEMO, schoolName: '', stage: 'س', branch: '', section: '', year: '', status: 'archived', createdAt: null, archivedAt: '2026-10-01T00:00:00.000Z' }] })) + ')}catch(e){}' }); page = c.page;
  await nav(page, 'الجدول'); t = await pageText(page);
  check('No active class: clear message, no lessons, no buttons to edit', /لا يوجد صف نشط/.test(t) && (await page.$$('.st-prow, .dtab')).length === 0 && !(await page.$$eval('#v-page button', function (l) { return l.some(function (b) { return /تعديل|حذف|إضافة/.test(b.textContent); }); })), t.slice(0, 200));
  await c.ctx.close();

  // ===== 13) المنطقة الزمنية: نفس النص بأي منطقة =====
  var tzs = ['Asia/Baghdad', 'Pacific/Kiritimati', 'Pacific/Pago_Pago', 'America/Los_Angeles', 'UTC'], outs = [];
  for (i = 0; i < tzs.length; i++) {
    c = await open(browser, { label: 'tz' + i, tz: tzs[i], clock: '2026-10-22T12:00:00Z' }); page = c.page;
    await seed(page, KEY, DEMO, mixed());
    await nav(page, 'الجدول'); await page.click('.sv button:has-text("الأسبوع كله")');
    outs.push(await page.$$eval('#v-page .daycard[data-day]', function (cs) { return cs.map(function (cd) { return cd.getAttribute('data-day') + '=' + Array.prototype.map.call(cd.querySelectorAll('.st-prow'), function (li) { return li.querySelector('h3').textContent + '|' + (li.querySelector('.pr-t') ? li.querySelector('.pr-t').textContent : ''); }).join(';'); }).join('#'); }));
    await c.ctx.close();
  }
  check('Times/lessons identical in 5 time zones (Baghdad, +14, −11, LA, UTC): no shift or day flip', outs.every(function (x) { return x === outs[0]; }) && /8:00 ص – 8:45 ص/.test(outs[0]) && /12:05 ص – 11:59 م/.test(outs[0]), outs.join('\n'));

  // ===== 14) منتصف الليل: تمييز «اليوم» يتحدّث والصفحة مفتوحة =====
  c = await open(browser, { label: 'midnight', clock: '2026-10-21T20:59:00Z' }); page = c.page; // الأربعاء 23:59 بغداد
  await seed(page, KEY, DEMO, [rec('m1', { day: 'wed', subject: 'أربعاء', period: 1 }), rec('m2', { day: 'thu', subject: 'خميس', period: 1 })]);
  await nav(page, 'الجدول');
  check('Before midnight Wednesday is today', (await page.$eval('.dtab.is-today .dn', function (e) { return e.textContent; })) === 'الأربعاء');
  await page.clock.fastForward(120000); await page.waitForTimeout(100);
  check('After midnight (page open) Thursday is marked today', (await page.$eval('.dtab.is-today .dn', function (e) { return e.textContent; })) === 'الخميس');
  await c.ctx.close();

  // ===== 15) XSS وأمان النص =====
  c = await open(browser, { label: 'xss' }); page = c.page;
  await page.evaluate(function () { window.__x = 0; });
  await seed(page, KEY, DEMO, [rec('x1', { day: 'thu', subject: '<img src=x onerror="window.__x=1">مادة', period: 1, notes: '<script>window.__x=2</script> javascript:alert(1) https://ok.example/p' })]);
  await nav(page, 'الجدول'); await page.waitForTimeout(100);
  check('HTML in subject/notes is shown as text, nothing executes, no injected elements', (await page.evaluate(function () { return window.__x; })) === 0 && (await page.$('#v-page img, #v-page script')) === null && /<img src=x/.test(await pageText(page)));
  check('Only http(s) link becomes anchor; javascript: stays text', (await page.$$eval('.pr-note a', function (l) { return l.length === 1 && l[0].href === 'https://ok.example/p'; })));
  await c.ctx.close();

  // ===== 16) عرض الهاتف: عدم التمرير الأفقي بعروض مختلفة ومحتوى طويل وكل الأيام =====
  var long = 'مادة_طويلة_جداً_بلا_مسافات_'.repeat(8), ALL = ['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri'], big = [];
  ALL.forEach(function (d, k) { for (var n = 1; n <= 3; n++) big.push(rec('big_' + d + n, { day: d, subject: n === 1 ? long : 'مادة ' + d + n, period: n, startTime: ('0' + (7 + n)).slice(-2) + ':00', endTime: ('0' + (7 + n)).slice(-2) + ':45', notes: n === 2 ? long + ' https://example.com/' + 'a'.repeat(120) : undefined })); });
  var widths = [320, 360, 390, 430];
  for (i = 0; i < widths.length; i++) {
    c = await open(browser, { label: 'w' + widths[i], viewport: { width: widths[i], height: 740 } }); page = c.page;
    await seed(page, KEY, DEMO, big);
    await page.evaluate(function (k) { localStorage.setItem(k, JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', days: ['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri'] })); }, DKEY);
    await nav(page, 'الجدول');
    var o1 = await overflow(page);
    await page.click('.sv button:has-text("الأسبوع كله")');
    var o2 = await overflow(page);
    await page.click('.sv button:has-text("يوم واحد")');
    check('No horizontal page scroll at ' + widths[i] + 'px (7 days, long unbroken text, long URL) in day and week views', !o1 && !o2);
    check('All 7 day tabs fit inside viewport at ' + widths[i] + 'px', await page.$$eval('.dtab', function (l) { return l.length === 7 && l.every(function (b) { var r = b.getBoundingClientRect(); return r.left >= -1 && r.right <= document.documentElement.clientWidth + 1; }); }));
    if (widths[i] === 360) { await shot(page, 'sched-day-360'); }
    await c.ctx.close();
  }

  // ===== 17) مظهر داكن + RTL =====
  c = await open(browser, { label: 'dark' }); page = c.page;
  await page.emulateMedia({ colorScheme: 'dark' });
  await seed(page, KEY, DEMO, mixed());
  await nav(page, 'الجدول');
  check('RTL direction on student schedule rows', await page.evaluate(function () { return document.documentElement.dir === 'rtl' && getComputedStyle(document.querySelector('.st-prow')).direction === 'rtl'; }));
  await shot(page, 'sched-dark-390');
  await c.ctx.close();

  // ===== 18) لا تأثير على صفحات الطالب الأخرى والرئيسية =====
  c = await open(browser, { label: 'others' }); page = c.page;
  await nav(page, 'التحاضير'); check('Student prep page still renders', /عرض للقراءة فقط/.test(await pageText(page)));
  await nav(page, 'الأرشيف'); check('Student archive page still renders', /عرض للقراءة فقط/.test(await pageText(page)));
  await nav(page, 'الجدول'); check('Navigating away and back re-renders schedule without error', (await page.$('#page-title')) !== null);
  await page.click('.nav button:has-text("الرئيسية")'); await page.waitForSelector('#welcome');
  await page.click('.link[data-go="schedule"]');
  check('Home «فتح الجدول الدراسي» opens student schedule', (await page.evaluate(function () { return document.documentElement.getAttribute('data-view'); })) === 'schedule');
  check('Home schedule panel no longer claims «لم يُضف جدول» / «يُفعّل في مرحلة لاحقة»', !/لم يُضف جدول الحصص الأسبوعي بعد|يُفعّل في مرحلة لاحقة/.test(await page.evaluate(function () { return document.querySelector('#v-home section[aria-labelledby="t-sched"]').textContent; })));
  await c.ctx.close();

  await browser.close();
  check('No uncaught JavaScript errors in any scenario', jsErrors.length === 0, jsErrors.join(' ;; '));
  var failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('RUNNER ERROR', e); process.exit(2); });
