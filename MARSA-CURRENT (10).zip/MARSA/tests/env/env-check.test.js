// تشغيل: node tests/env/env-check.test.js  (لا يحتاج مكتبات ولا شبكة)
// 03.01: فاحص إعدادات البيئة — الحالات السليمة وحالات الرفض (مفقود، مختلط، سر في الواجهة، dev/prod، prod محجوب، لا طباعة قيم) + نقاء الملفات النموذجية.
var assert = require('assert'), fs = require('fs'), path = require('path'), cp = require('child_process'), os = require('os');
var root = path.resolve(__dirname, '..', '..');
var C = require(path.join(root, 'scripts', 'check-env.js'));
var n = 0, f = 0;
function T(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '::', e && e.message); } }

// قيم اصطناعية بالكامل (لا تطابق أي مفتاح حقيقي)
var REF_DEV = 'devdevdevdev1', REF_PROD = 'prodprodprod2';
var PUB = 'sb_publishable_' + 'A1b2C3d4E5f6G7h8I9j0';
var PUB2 = 'sb_publishable_' + 'Z9y8X7w6V5u4T3s2R1q0';
var SEC = 'sb_secret_' + 'Q1w2E3r4T5y6U7i8O9p0';
function b64(o) { return Buffer.from(JSON.stringify(o)).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_'); }
function jwt(role) { return b64({ alg: 'HS256', typ: 'JWT' }) + '.' + b64({ iss: 'supabase-demo', role: role }) + '.' + 'c2lnbmF0dXJlLXN5bnRoZXRpYw'; }

function mem(files, frontend) {
  var all = Object.assign({}, frontend || { 'index.html': '<!doctype html><title>x</title>', 'css/v1.css': 'a{}', 'js/v1-app.js': 'var a=1;' }, files);
  return {
    read: function (p) { return Object.prototype.hasOwnProperty.call(all, p) ? all[p] : null; },
    list: function (d) { return Object.keys(all).filter(function (k) { var i = k.lastIndexOf('/'); return (i < 0 ? '' : k.slice(0, i)) === d; }).map(function (k) { return k.slice(k.lastIndexOf('/') + 1); }); }
  };
}
function run(target, files, frontend) { return C.checkEnv({ target: target, io: mem(files, frontend) }); }
function st(r, id) { var x = r.results.filter(function (q) { return q.id === id; }); return x.length ? x[x.length - 1].status : null; }
function envText(o) { return Object.keys(o).map(function (k) { return k + '=' + o[k]; }).join('\n'); }
var LOCAL_OK = { MARSA_ENV: 'local', MARSA_MODE: 'local' };
var SHARED_LOCAL = { MARSA_ENV: 'local', MARSA_MODE: 'shared', SUPABASE_URL: 'http://127.0.0.1:54321', SUPABASE_PUBLISHABLE_KEY: PUB };
var DEV_OK = { MARSA_ENV: 'dev', MARSA_MODE: 'shared', SUPABASE_URL: 'https://' + REF_DEV + '.supabase.co', SUPABASE_PUBLISHABLE_KEY: PUB };

// ---------- سليم ----------
T('local بوضع local: سليم بلا عنوان ولا مفاتيح', function () { var r = run('local', { '.env.local': envText(LOCAL_OK) }); assert.ok(r.ok, JSON.stringify(r.results)); });
T('local بوضع shared نحو 127.0.0.1 ومفتاح عام: سليم', function () { var r = run('local', { '.env.local': envText(SHARED_LOCAL) }); assert.ok(r.ok, JSON.stringify(r.results)); });
T('dev بعنوان https سحابي ومفتاح عام: سليم', function () { var r = run('dev', { '.env.dev': envText(DEV_OK) }); assert.ok(r.ok, JSON.stringify(r.results)); });
T('مفتاح anon القديم (JWT بدور anon): مقبول مع تحذير', function () { var e = Object.assign({}, SHARED_LOCAL, { SUPABASE_PUBLISHABLE_KEY: jwt('anon') }); var r = run('local', { '.env.local': envText(e) }); assert.ok(r.ok); assert.strictEqual(st(r, 'K1'), 'warn'); });
T('تعليق بعد القيمة وعلامات اقتباس وexport تُحلَّل صحيحاً', function () { var p = C.parseDotenv('export MARSA_ENV="local" # c\nMARSA_MODE=local   # c2\n# تعليق\n'); assert.strictEqual(p.MARSA_ENV, 'local'); assert.strictEqual(p.MARSA_MODE, 'local'); });

// ---------- مفقود (فشل آمن) ----------
T('غياب .env.local: تحذير فقط ويبقى local بلا اتصال (لا فشل ولا افتراض shared)', function () { var r = run('local', {}); assert.ok(r.ok); assert.strictEqual(st(r, 'F1'), 'warn'); });
T('غياب .env.dev: فشل (لا إعداد بديل)', function () { var r = run('dev', {}); assert.ok(!r.ok); assert.strictEqual(st(r, 'F1'), 'fail'); });
T('MARSA_ENV أو MARSA_MODE مفقود: فشل', function () { assert.strictEqual(st(run('local', { '.env.local': 'MARSA_MODE=local' }), 'E1'), 'fail'); assert.strictEqual(st(run('local', { '.env.local': 'MARSA_ENV=local' }), 'M1'), 'fail'); });
T('MARSA_MODE بقيمة غريبة: فشل', function () { assert.strictEqual(st(run('local', { '.env.local': 'MARSA_ENV=local\nMARSA_MODE=remote' }), 'M1'), 'fail'); });
T('shared بلا عنوان أو بلا مفتاح: فشل لكل منهما', function () {
  var a = Object.assign({}, SHARED_LOCAL); delete a.SUPABASE_URL; assert.strictEqual(st(run('local', { '.env.local': envText(a) }), 'U1'), 'fail');
  var b = Object.assign({}, SHARED_LOCAL); delete b.SUPABASE_PUBLISHABLE_KEY; assert.strictEqual(st(run('local', { '.env.local': envText(b) }), 'K1'), 'fail');
});
T('قيم وهمية (EXAMPLE/your-project) في وضع shared: فشل', function () {
  var a = Object.assign({}, SHARED_LOCAL, { SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_' + 'EXAMPLE_NOT_A_REAL_KEY' }); assert.strictEqual(st(run('local', { '.env.local': envText(a) }), 'K1'), 'fail');
  var b = Object.assign({}, DEV_OK, { SUPABASE_URL: 'https://your-project.supabase.co' }); assert.strictEqual(st(run('dev', { '.env.dev': envText(b) }), 'U1'), 'fail');
});

// ---------- خلط بيئات ----------
T('ملف prod يُفحص كـdev (MARSA_ENV لا يطابق): فشل', function () { var e = Object.assign({}, DEV_OK, { MARSA_ENV: 'prod' }); assert.strictEqual(st(run('dev', { '.env.dev': envText(e) }), 'E1'), 'fail'); });
T('local يشير إلى خدمة بعيدة: فشل', function () { var e = Object.assign({}, SHARED_LOCAL, { SUPABASE_URL: 'https://' + REF_DEV + '.supabase.co' }); assert.strictEqual(st(run('local', { '.env.local': envText(e) }), 'U1'), 'fail'); });
T('dev بعنوان http أو نطاق غير supabase أو مسار/مستخدم: فشل', function () {
  ['http://' + REF_DEV + '.supabase.co', 'https://evil.example.org', 'https://' + REF_DEV + '.supabase.co/rest/v1', 'https://user:pw@' + REF_DEV + '.supabase.co'].forEach(function (u) {
    var e = Object.assign({}, DEV_OK, { SUPABASE_URL: u }); assert.strictEqual(st(run('dev', { '.env.dev': envText(e) }), 'U1'), 'fail', u);
  });
});
T('dev وprod على المشروع نفسه أو المفتاح نفسه: فشل', function () {
  var prod = { MARSA_ENV: 'prod', MARSA_MODE: 'shared', SUPABASE_URL: DEV_OK.SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY: PUB2 };
  assert.strictEqual(st(run('dev', { '.env.dev': envText(DEV_OK), '.env.prod': envText(prod) }), 'X1'), 'fail');
  var prod2 = { MARSA_ENV: 'prod', MARSA_MODE: 'shared', SUPABASE_URL: 'https://' + REF_PROD + '.supabase.co', SUPABASE_PUBLISHABLE_KEY: PUB };
  assert.strictEqual(st(run('dev', { '.env.dev': envText(DEV_OK), '.env.prod': envText(prod2) }), 'X1'), 'fail');
});
T('dev وprod منفصلان تماماً: X1 سليم', function () {
  var prod = { MARSA_ENV: 'prod', MARSA_MODE: 'shared', SUPABASE_URL: 'https://' + REF_PROD + '.supabase.co', SUPABASE_PUBLISHABLE_KEY: PUB2 };
  assert.strictEqual(st(run('dev', { '.env.dev': envText(DEV_OK), '.env.prod': envText(prod) }), 'X1'), 'ok');
});
T('prod محجوب دائماً (G-D) حتى لو الإعداد سليم الشكل', function () {
  var prod = { MARSA_ENV: 'prod', MARSA_MODE: 'shared', SUPABASE_URL: 'https://' + REF_PROD + '.supabase.co', SUPABASE_PUBLISHABLE_KEY: PUB2 };
  var r = run('prod', { '.env.prod': envText(prod) }); assert.ok(!r.ok); assert.strictEqual(st(r, 'G1'), 'fail'); assert.strictEqual(st(r, 'U1'), 'ok');
});
T('prod بلا ملف: فشل أيضاً', function () { var r = run('prod', {}); assert.ok(!r.ok); assert.strictEqual(st(r, 'F1'), 'fail'); });
T('هدف غير معروف: فشل', function () { assert.ok(!run('staging', {}).ok); });

// ---------- أسرار ----------
function msg(r, id) { return r.results.filter(function (q) { return q.id === id; }).map(function (q) { return q.msg; }).join('|'); }
T('مفتاح سري في خانة publishable (sb_secret_): فشل بسبب «سري» تحديداً', function () { var e = Object.assign({}, SHARED_LOCAL, { SUPABASE_PUBLISHABLE_KEY: SEC }); var r = run('local', { '.env.local': envText(e) }); assert.strictEqual(st(r, 'K1'), 'fail'); assert.ok(/سري/.test(msg(r, 'K1')), msg(r, 'K1')); });
T('JWT بدور service_role في خانة publishable: فشل بسبب «سري» تحديداً', function () { var e = Object.assign({}, SHARED_LOCAL, { SUPABASE_PUBLISHABLE_KEY: jwt('service_role') }); var r = run('local', { '.env.local': envText(e) }); assert.strictEqual(st(r, 'K1'), 'fail'); assert.ok(/سري/.test(msg(r, 'K1')), msg(r, 'K1')); });
T('متغير بادئته عامة واسمه سر (NEXT_PUBLIC_…SECRET): فشل', function () { var r = run('local', { '.env.local': envText(LOCAL_OK) + '\nNEXT_PUBLIC_SUPABASE_SECRET_KEY=x' }); assert.strictEqual(st(r, 'S1'), 'fail'); });
T('مفتاح سري داخل ملف prod: فشل', function () { var e = { MARSA_ENV: 'prod', MARSA_MODE: 'local', SUPABASE_SECRET_KEY: SEC }; assert.strictEqual(st(run('prod', { '.env.prod': envText(e) }), 'S2'), 'fail'); });
T('أسماء قديمة (ANON/SERVICE_ROLE) ومتغير مجهول: تحذير لا يُخفى', function () { var r = run('local', { '.env.local': envText(LOCAL_OK) + '\nSUPABASE_SERVICE_ROLE_KEY=a\nTYPO_VAR=1' }); assert.strictEqual(r.results.filter(function (x) { return x.id === 'N1'; }).length, 1); assert.strictEqual(r.results.filter(function (x) { return x.id === 'N2'; }).length, 1); });
T('سر في ملف واجهة (6 أنماط): كلها تُكتشف', function () {
  var bad = ['var k="' + SEC + '";', 'var r="service_role";', 'var t="' + jwt('service_role') + '";', 'var x=process.env.A;', 'var u="postgresql://postgres:hunter2@db.example:5432/postgres";', 'var h="MARSA_INVITE_HMAC_SECRET";'];
  bad.forEach(function (code) { var r = run('local', { '.env.local': envText(LOCAL_OK) }, { 'index.html': 'x', 'js/v1-app.js': code }); assert.strictEqual(st(r, 'W1'), 'fail', code); });
});
T('قيمة السر الفعلية من ملف البيئة لو ظهرت في الواجهة: تُكتشف حتى بلا نمط', function () {
  var e = Object.assign({}, LOCAL_OK, { MARSA_INVITE_HMAC_SECRET: 'plainsecretvalue-1234' });
  var r = run('local', { '.env.local': envText(e) }, { 'index.html': 'x', 'js/v1-app.js': 'var z="plainsecretvalue-1234";' }); assert.strictEqual(st(r, 'W1'), 'fail');
});
T('الواجهة النظيفة تمرّ؛ وملفات خارج قائمة الواجهة (full.html/app.js) لا تُفحص', function () {
  var r = run('local', { '.env.local': envText(LOCAL_OK), 'full.html': 'service_role', 'js/app.js': 'service_role' }); assert.strictEqual(st(r, 'W1'), 'ok');
});

// ---------- js/marsa-config.js ----------
T('marsa-config.js بالحقول العامة الثلاثة ويطابق البيئة: سليم', function () {
  var cfg = 'window.MARSA_CONFIG=Object.freeze({mode:"shared",supabaseUrl:"' + SHARED_LOCAL.SUPABASE_URL + '",supabasePublishableKey:"' + PUB + '"});';
  assert.strictEqual(st(run('local', { '.env.local': envText(SHARED_LOCAL), 'js/marsa-config.js': cfg }), 'C1'), 'ok');
});
T('marsa-config.js بحقل زائد (مثل secret) أو غير مطابق أو لا يُنفَّذ: فشل', function () {
  var extra = 'window.MARSA_CONFIG={mode:"local",supabaseUrl:"",supabasePublishableKey:"",secret:"x"};';
  assert.strictEqual(st(run('local', { '.env.local': envText(LOCAL_OK), 'js/marsa-config.js': extra }), 'C1'), 'fail');
  var mism = 'window.MARSA_CONFIG={mode:"shared",supabaseUrl:"http://127.0.0.1:1",supabasePublishableKey:"' + PUB + '"};';
  assert.strictEqual(st(run('local', { '.env.local': envText(SHARED_LOCAL), 'js/marsa-config.js': mism }), 'C1'), 'fail');
  assert.strictEqual(st(run('local', { '.env.local': envText(LOCAL_OK), 'js/marsa-config.js': 'while(true){}' }), 'C1'), 'fail');
  assert.strictEqual(st(run('local', { '.env.local': envText(LOCAL_OK), 'js/marsa-config.js': 'require("fs")' }), 'C1'), 'fail');
});

// ---------- الواجهة الحقيقية والملفات النموذجية ----------
T('واجهة المشروع الحقيقية نظيفة (فحص ساكن على الشجرة الفعلية)', function () {
  var r = C.checkEnv({ target: 'local', io: { read: function (p) { try { return fs.readFileSync(path.join(root, p), 'utf8'); } catch (e) { return null; } }, list: function (d) { try { return fs.readdirSync(path.join(root, d)); } catch (e) { return []; } } } });
  assert.strictEqual(st(r, 'W1'), 'ok', JSON.stringify(r.results));
});
T('.env.example: قيم وهمية فقط (لا JWT ولا مفتاح سري ولا عنوان سحابي ولا كلمة سر)', function () {
  var raw = fs.readFileSync(path.join(root, '.env.example'), 'utf8'), t = raw.split(/\r?\n/).filter(function (l) { return !/^\s*#/.test(l); }).join('\n'), p = C.parseDotenv(raw);
  assert.ok(!/eyJ[A-Za-z0-9_-]{10,}\./.test(t)); assert.ok(!/sb_secret_[A-Za-z0-9]/.test(t)); assert.ok(!/supabase\.co/.test(t)); assert.ok(!/postgres(ql)?:\/\//i.test(t));
  assert.strictEqual(p.SUPABASE_SECRET_KEY, ''); assert.strictEqual(p.MARSA_INVITE_HMAC_SECRET, ''); assert.ok(/EXAMPLE/.test(p.SUPABASE_PUBLISHABLE_KEY)); assert.strictEqual(p.MARSA_MODE, 'local');
  assert.deepStrictEqual(Object.keys(p).sort(), ['MARSA_ENV', 'MARSA_INVITE_HMAC_SECRET', 'MARSA_MODE', 'SUPABASE_PUBLISHABLE_KEY', 'SUPABASE_SECRET_KEY', 'SUPABASE_URL']);
});
T('.gitignore يستثني .env.* ويستثني النموذج فقط، وlocal marsa-config', function () {
  var g = fs.readFileSync(path.join(root, '.gitignore'), 'utf8').split(/\r?\n/);
  ['.env', '.env.*', '!.env.example', 'js/marsa-config.js'].forEach(function (l) { assert.ok(g.indexOf(l) >= 0, l); });
});
T('لا ملف .env حقيقي ولا js/marsa-config.js داخل شجرة المشروع (يُمنع في الـZIP)', function () {
  var left = fs.readdirSync(root).filter(function (x) { return /^\.env/.test(x) && x !== '.env.example'; });
  assert.deepStrictEqual(left, []); assert.ok(!fs.existsSync(path.join(root, 'js', 'marsa-config.js')));
});
T('قالب config/marsa-config.example.js: ثلاثة حقول عامة فقط، وضع local، مجمَّد، وغير محمَّل من index.html', function () {
  var code = fs.readFileSync(path.join(root, 'config', 'marsa-config.example.js'), 'utf8'), box = {}; box.window = box; require('vm').runInNewContext(code, box);
  assert.deepStrictEqual(Object.keys(box.MARSA_CONFIG).sort(), ['mode', 'supabasePublishableKey', 'supabaseUrl']); assert.strictEqual(box.MARSA_CONFIG.mode, 'local'); assert.ok(Object.isFrozen(box.MARSA_CONFIG));
  assert.ok(!/marsa-config/.test(fs.readFileSync(path.join(root, 'index.html'), 'utf8')));
  assert.ok(!/sb_secret_|service_role/i.test(code.replace(/^\s*\/\/.*$/gm, '')));
});

// ---------- الأداة كعملية: رموز الخروج وعدم طباعة القيم ----------
function cli(args, files) {
  var dir = fs.mkdtempSync(path.join(os.tmpdir(), 'marsa-env-')); fs.mkdirSync(path.join(dir, 'css')); fs.mkdirSync(path.join(dir, 'js'));
  fs.writeFileSync(path.join(dir, 'index.html'), '<title>x</title>');
  Object.keys(files || {}).forEach(function (k) { fs.writeFileSync(path.join(dir, k), files[k]); });
  var r = cp.spawnSync(process.execPath, [path.join(root, 'scripts', 'check-env.js'), '--root', dir].concat(args), { encoding: 'utf8' });
  fs.rmSync(dir, { recursive: true, force: true }); return r;
}
T('CLI: بلا ملف على local = خروج 0؛ على dev = 1؛ على prod = 1؛ هدف خاطئ = 2؛ وسيط مجهول = 2', function () {
  assert.strictEqual(cli([]).status, 0); assert.strictEqual(cli(['--target', 'dev']).status, 1); assert.strictEqual(cli(['--target', 'prod']).status, 1);
  assert.strictEqual(cli(['--target', 'x']).status, 2); assert.strictEqual(cli(['--zzz']).status, 2);
});
T('CLI: لا يطبع أي قيمة سرية أو مفتاحاً أو عنواناً حتى عند الفشل', function () {
  var e = Object.assign({}, SHARED_LOCAL, { SUPABASE_PUBLISHABLE_KEY: SEC, SUPABASE_SECRET_KEY: SEC, MARSA_INVITE_HMAC_SECRET: 'hmac-super-secret-value' });
  var r = cli([], { '.env.local': envText(e) }), out = r.stdout + r.stderr;
  assert.strictEqual(r.status, 1); assert.ok(out.indexOf(SEC) < 0); assert.ok(out.indexOf('Q1w2E3r4') < 0); assert.ok(out.indexOf('hmac-super-secret-value') < 0); assert.ok(out.indexOf('127.0.0.1:54321') < 0);
});

console.log('\nالنتيجة: ' + n + ' نجح / ' + f + ' فشل');
process.exit(f ? 1 : 0);
