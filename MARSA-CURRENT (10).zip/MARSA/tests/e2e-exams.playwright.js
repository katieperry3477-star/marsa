// اختبار واجهة المرحلة 03.5 (الامتحانات) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-exams.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة، بساعة مزيّفة ثابتة البداية، ويحقن بيانات الاختبار في تخزين السياق المؤقت فقط.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
// 2026-10-22 09:00 بتوقيت بغداد (UTC+3)
var NOW = '2026-10-22T06:00:00Z';
async function open(browser, opts) {
  opts = opts || {};
  var ctx = opts.ctx || await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: opts.tz || 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: !!opts.touch, isMobile: !!opts.touch });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(opts.clock || NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")');
  await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
  await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toExams(page) { await page.click('.nav button:has-text("الامتحانات")'); await page.waitForSelector('#page-title'); }
async function fill(page, o) {
  if (o.subject !== undefined) await page.fill('#ef-subject', o.subject);
  if (o.title !== undefined) await page.fill('#ef-title', o.title);
  if (o.examDate !== undefined) await page.fill('#ef-examDate', o.examDate);
  if (o.status !== undefined) await page.selectOption('#ef-status', o.status);
  if (o.topics !== undefined) await page.fill('#ef-topics', o.topics);
  if (o.notes !== undefined) await page.fill('#ef-notes', o.notes);
}
async function addExam(page, o) {
  await page.click('button:has-text("إضافة امتحان")');
  await fill(page, o);
  await page.click('button:has-text("حفظ الامتحان")');
  await page.waitForSelector('.lform', { state: 'hidden' });
}
async function store(page, key) { return page.evaluate(function (k) { var r = localStorage.getItem(k); return r === null ? null : JSON.parse(r); }, key); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function keys(page) { return page.evaluate(function () { var o = []; for (var i = 0; i < localStorage.length; i++) o.push(localStorage.key(i)); return o.sort(); }); }
async function acKeys(page) { return (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0 && x.indexOf('.backup') < 0; }); }
async function group(page, g) { return page.$$eval('.pgroup[data-group="' + g + '"] .ecard h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function allCards(page) { return page.$$eval('.ecard h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function toast(page) { return page.$eval('#status', function (s) { return s.textContent; }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function failOn(page) { await page.evaluate(function () { window.__orig = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (String(k).indexOf('marsa.academic') === 0) throw new Error('QuotaExceededError'); return window.__orig.call(this, k, v); }; }); }
async function failOff(page) { await page.evaluate(function () { Storage.prototype.setItem = window.__orig; }); }
var KEY = 'marsa.academic.exams.cls_demo_001';

(async function main() {
  var browser = await pw.chromium.launch();
  var c, page, col, rec, before, after;

  // ===== 1) بداية نظيفة =====
  c = await open(browser, { label: 'fresh' }); page = c.page;
  await toRep(page);
  var navTexts = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent; }); });
  check('Nav (rep): exactly one «الامتحانات» tab', navTexts.filter(function (x) { return x === 'الامتحانات'; }).length === 1, navTexts.join('|'));
  await toExams(page);
  check('Route opens r-exams page', (await page.getAttribute('html', 'data-view')) === 'r-exams');
  check('Old placeholder gone (disabled «إضافة امتحان» head button, «يُفعّل في مرحلة لاحقة», old empty parts)', (await page.$('.page-head .act')) === null && !/يُفعّل في مرحلة لاحقة|لم تُحدد مواضيع بعد|لا توجد امتحانات مضافة/.test(await page.textContent('#v-page')));
  check('Fresh start: no fake exams; empty state explains how to start', (await allCards(page)).length === 0 && /لم تُضف أي امتحانات/.test(await page.textContent('#v-page .empty')) && /إضافة امتحان/.test(await page.textContent('#v-page .empty')));
  check('Fresh start: opening page writes NO academic key', (await acKeys(page)).length === 0, (await keys(page)).join(','));
  check('Fresh start: count 0, class bar shown, enabled add button', /عدد الامتحانات: 0/.test(await page.textContent('.count')) && (await page.$('.classbar')) !== null && !(await page.$eval('.toolbar button.primary', function (b) { return b.disabled; })));
  check('Note: no grades/questions in this stage', /لا درجات ولا أسئلة/.test(await page.textContent('.sepnote')));

  // ===== 2) النموذج والتحقق =====
  await page.click('button:has-text("إضافة امتحان")');
  check('Form: required marked, optionals marked', /مطلوب/.test(await page.textContent('label[for=ef-subject]')) && /مطلوب/.test(await page.textContent('label[for=ef-title]')) && /مطلوب/.test(await page.textContent('label[for=ef-examDate]')) && /مطلوب/.test(await page.textContent('label[for=ef-status]')) && /اختياري/.test(await page.textContent('label[for=ef-topics]')) && /اختياري/.test(await page.textContent('label[for=ef-notes]')));
  check('Form: status select has مجدول/أُجري/أُلغي and defaults to مجدول; date empty (no assumed date)', (await page.$$eval('#ef-status option', function (l) { return l.map(function (o) { return o.textContent; }); })).join('|') === 'مجدول|أُجري|أُلغي' && (await page.inputValue('#ef-status')) === 'scheduled' && (await page.inputValue('#ef-examDate')) === '');
  check('Form: no subject presets (datalist absent on empty class), no score/questions field', (await page.$('#ef-subjects')) === null && (await page.$$('#v-page .lform input, #v-page .lform select, #v-page .lform textarea')).length === 6);
  await page.click('button:has-text("حفظ الامتحان")');
  check('Empty required: errors on subject/title/date, focus first, nothing saved', /المادة/.test(await page.textContent('#ef-subject-e')) && /عنوان/.test(await page.textContent('#ef-title-e')) && /اختر تاريخ/.test(await page.textContent('#ef-examDate-e')) && (await page.evaluate(function () { return document.activeElement.id; })) === 'ef-subject' && (await acKeys(page)).length === 0);
  await fill(page, { subject: '  ', title: '  ' });
  await page.click('button:has-text("حفظ الامتحان")');
  check('Whitespace-only rejected', /اسم المادة/.test(await page.textContent('#ef-subject-e')) && /عنوان/.test(await page.textContent('#ef-title-e')));
  check('maxlength attributes from limits', (await page.$eval('#ef-subject', function (e) { return e.maxLength; })) === 80 && (await page.$eval('#ef-title', function (e) { return e.maxLength; })) === 120 && (await page.$eval('#ef-topics', function (e) { return e.maxLength; })) === 1500 && (await page.$eval('#ef-notes', function (e) { return e.maxLength; })) === 1000);
  await fill(page, { subject: 'مادة أ', title: 'امتحان شهري', examDate: '' });
  await page.click('button:has-text("حفظ الامتحان")');
  check('Missing date rejected with focus on date', /اختر تاريخ/.test(await page.textContent('#ef-examDate-e')) && (await page.evaluate(function () { return document.activeElement.id; })) === 'ef-examDate' && (await page.getAttribute('#ef-examDate', 'aria-invalid')) === 'true');
  // حقل التاريخ: محاولة إدخال تاريخ خارج النطاق عبر الـDOM
  await page.evaluate(function () { var d = document.getElementById('ef-examDate'); d.min = ''; d.max = ''; });
  await page.fill('#ef-examDate', '1999-01-01'); await page.click('button:has-text("حفظ الامتحان")');
  check('Out-of-range year rejected', /خارج النطاق/.test(await page.textContent('#ef-examDate-e')) && (await acKeys(page)).length === 0, await page.textContent('#ef-examDate-e'));

  // ===== 3) إضافة وظهور في القادمة =====
  await fill(page, { examDate: '2026-11-05', topics: 'الفصل 1\nالفصل 2', notes: 'أحضر القلم' });
  await page.click('button:has-text("حفظ الامتحان")');
  await page.waitForSelector('.ecard');
  check('Add: success toast, form closed, card in «القادمة»', /تم حفظ الامتحان/.test(await toast(page)) && (await page.$('.lform:not([hidden])')) === null && (await group(page, 'upcoming')).join() === 'امتحان شهري' && (await group(page, 'finished')).length === 0);
  col = await store(page, KEY); rec = col.records[0];
  check('Stored: schemaVersion 1, classId, only the exams key', col.schemaVersion === 1 && col.classId === 'cls_demo_001' && col.records.length === 1 && (await acKeys(page)).join() === KEY);
  check('Stored record: exam_ id, examDate local, status scheduled, topics with newline, no score/questions/date', /^exam_/.test(rec.recordId) && rec.classId === 'cls_demo_001' && rec.examDate === '2026-11-05' && rec.status === 'scheduled' && rec.topics === 'الفصل 1\nالفصل 2' && rec.notes === 'أحضر القلم' && rec.subject === 'مادة أ' && !('score' in rec) && !('grade' in rec) && !('questions' in rec) && !('date' in rec) && rec.createdAt && rec.updatedAt, JSON.stringify(rec));
  await addExam(page, { subject: 'مادة ب', title: 'اليوم', examDate: '2026-10-22' });
  await addExam(page, { subject: 'مادة أ', title: 'باجر', examDate: '2026-10-23' });
  await addExam(page, { subject: 'مادة ج', title: 'بعيد', examDate: '2026-12-20' });
  await addExam(page, { subject: 'مادة ب', title: 'ماضٍ مجدول', examDate: '2026-10-10' });
  await addExam(page, { subject: 'مادة ب', title: 'ماضٍ أُجري', examDate: '2026-10-12', status: 'held' });
  await addExam(page, { subject: 'مادة ج', title: 'ملغى مستقبلي', examDate: '2026-11-30', status: 'cancelled' });
  check('Upcoming: nearest first (today, tomorrow, 5 Nov, 20 Dec); cancelled-future NOT included', (await group(page, 'upcoming')).join('|') === 'اليوم|باجر|امتحان شهري|بعيد', (await group(page, 'upcoming')).join('|'));
  check('Finished: newest date first (cancelled 30 Nov, held 12 Oct, past-scheduled 10 Oct)', (await group(page, 'finished')).join('|') === 'ملغى مستقبلي|ماضٍ أُجري|ماضٍ مجدول', (await group(page, 'finished')).join('|'));
  check('Group order on page and counts in headings', (await page.$$eval('.pgroup h2', function (l) { return l.map(function (h) { return h.textContent; }); })).join('|') === 'الامتحانات القادمة (4)|الامتحانات السابقة والمنتهية (3)');
  check('Past-scheduled exam is NOT auto-cancelled: status stays مجدول, tagged «مضى موعده», and stored status is scheduled', /مجدول/.test(await page.textContent('.ecard:has-text("ماضٍ مجدول") .tag.st-scheduled')) && /مضى موعده/.test(await page.textContent('.ecard:has-text("ماضٍ مجدول")')) && !/أُلغي/.test(await page.textContent('.ecard:has-text("ماضٍ مجدول")')) && (await store(page, KEY)).records.filter(function (x) { return x.title === 'ماضٍ مجدول'; })[0].status === 'scheduled');
  check('Held/cancelled tags shown; cancelled card marked', /أُجري/.test(await page.textContent('.ecard:has-text("ماضٍ أُجري") .tag.st-held')) && /أُلغي/.test(await page.textContent('.ecard:has-text("ملغى مستقبلي") .tag.st-cancelled')) && (await page.getAttribute('.ecard:has-text("ملغى مستقبلي")', 'data-status')) === 'cancelled');
  check('Relative labels: اليوم / باجر / بعد 14 يوماً', /اليوم/.test(await page.textContent('.ecard:has-text("اليوم") .tag.rel')) && /باجر/.test(await page.textContent('.ecard:has-text("باجر") .tag.rel')) && /بعد 14 يوماً/.test(await page.textContent('.ecard:has-text("امتحان شهري") .tag.rel')), await page.textContent('.ecard:has-text("امتحان شهري")'));
  check('Card shows multi-line topics with pre-wrap + notes', (await page.$eval('.ecard:has-text("امتحان شهري") .lc-t', function (e) { return getComputedStyle(e).whiteSpace; })) === 'pre-wrap' && /الفصل 2/.test(await page.textContent('.ecard:has-text("امتحان شهري")')) && /أحضر القلم/.test(await page.textContent('.ecard:has-text("امتحان شهري")')));
  check('Count shows 7', /عدد الامتحانات: 7/.test(await page.textContent('.count')));
  await page.click('button:has-text("إضافة امتحان")');
  var sugg = await page.$$eval('#ef-subjects option', function (l) { return l.map(function (o) { return o.value; }).sort(); });
  check('datalist has only user-entered subjects', sugg.join('|') === ['مادة أ', 'مادة ب', 'مادة ج'].sort().join('|'), sugg.join('|'));
  await page.click('.lform button:has-text("إلغاء")');
  check('Cancel on untouched form closes it without confirm', (await page.$('.lform:not([hidden])')) === null);

  // ===== 4) تعديل: recordId ثابت والامتحان ينتقل بالتاريخ والحالة =====
  before = (await store(page, KEY)).records.filter(function (x) { return x.title === 'بعيد'; })[0];
  await page.click('.ecard:has-text("بعيد") button:has-text("تعديل")');
  check('Edit prefilled incl. status/date', (await page.inputValue('#ef-title')) === 'بعيد' && (await page.inputValue('#ef-examDate')) === '2026-12-20' && (await page.inputValue('#ef-status')) === 'scheduled' && (await page.inputValue('#ef-subject')) === 'مادة ج');
  await page.fill('#ef-examDate', '2026-10-24'); await page.fill('#ef-title', 'بعيد (قُرّب)');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.ecard:has-text("قُرّب")');
  after = (await store(page, KEY)).records.filter(function (x) { return x.title === 'بعيد (قُرّب)'; })[0];
  check('Edit: same recordId/classId/createdAt, no new record, updatedAt set', after && after.recordId === before.recordId && after.classId === before.classId && after.createdAt === before.createdAt && (await store(page, KEY)).records.length === 7 && after.updatedAt >= before.updatedAt);
  check('Edit date: moved earlier in upcoming (after باجر, before امتحان شهري)', (await group(page, 'upcoming')).join('|') === 'اليوم|باجر|بعيد (قُرّب)|امتحان شهري', (await group(page, 'upcoming')).join('|'));
  await page.click('.ecard:has-text("قُرّب") button:has-text("تعديل")'); await page.selectOption('#ef-status', 'held');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  check('Edit status → أُجري: leaves upcoming, enters finished (date still future)', (await group(page, 'upcoming')).indexOf('بعيد (قُرّب)') === -1 && (await group(page, 'finished')).indexOf('بعيد (قُرّب)') > -1 && /تم حفظ التعديل/.test(await toast(page)));
  await page.click('.ecard:has-text("قُرّب") button:has-text("تعديل")'); await page.selectOption('#ef-status', 'cancelled');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  check('Edit status → أُلغي: shown as cancelled in finished', (await page.getAttribute('.pgroup[data-group=finished] .ecard:has-text("قُرّب")', 'data-status')) === 'cancelled');
  await page.click('.ecard:has-text("قُرّب") button:has-text("تعديل")'); await page.selectOption('#ef-status', 'scheduled');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  check('Edit status back → مجدول with future date: returns to upcoming; same recordId throughout', (await group(page, 'upcoming')).indexOf('بعيد (قُرّب)') > -1 && (await store(page, KEY)).records.filter(function (x) { return x.title === 'بعيد (قُرّب)'; })[0].recordId === before.recordId);
  await page.click('.ecard:has-text("ماضٍ مجدول") button:has-text("تعديل")'); await page.fill('#ef-examDate', '2026-11-20');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  check('Edit date of overdue scheduled exam to future: moves to upcoming and loses «مضى موعده»', (await group(page, 'upcoming')).indexOf('ماضٍ مجدول') > -1 && !/مضى موعده/.test(await page.textContent('.ecard:has-text("ماضٍ مجدول")')));
  await page.click('.ecard:has-text("امتحان شهري") button:has-text("تعديل")'); await page.fill('#ef-topics', ''); await page.fill('#ef-notes', '');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  rec = (await store(page, KEY)).records.filter(function (x) { return x.title === 'امتحان شهري'; })[0];
  check('Edit: emptied optionals removed from record', !('topics' in rec) && !('notes' in rec) && rec.status === 'scheduled' && rec.examDate === '2026-11-05');

  // ===== 5) حماية النموذج المتسخ =====
  await page.click('.ecard:has-text("اليوم") button:has-text("تعديل")');
  await page.fill('#ef-title', 'تغيير غير محفوظ');
  await page.click('.ecard:has-text("باجر") button:has-text("تعديل")');
  check('Dirty form: switching asks to confirm', (await page.$eval('#dlg-confirm', function (d) { return d.open; })) && /تجاهل/.test(await page.textContent('#dlg-confirm-body')));
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  check('Dirty form: cancel keeps typed text', (await page.inputValue('#ef-title')) === 'تغيير غير محفوظ');
  await page.click('.lform button:has-text("إلغاء")');
  await page.click('#dlg-confirm-body button:has-text("تجاهل والمتابعة")');
  check('Dirty form: confirm discards; record unchanged', (await page.$('.lform:not([hidden])')) === null && (await group(page, 'upcoming'))[0] === 'اليوم');
  // تغيير الحالة وحده يُعدّ تغييراً غير محفوظ
  await page.click('.ecard:has-text("اليوم") button:has-text("تعديل")'); await page.selectOption('#ef-status', 'held');
  await page.click('.lform button:has-text("إلغاء")');
  check('Dirty form: status-only change also asks to confirm', (await page.$eval('#dlg-confirm', function (d) { return d.open; })));
  await page.click('#dlg-confirm-body button:has-text("تجاهل والمتابعة")');

  // ===== 6) حذف بتأكيد =====
  var n0 = (await store(page, KEY)).records.length;
  await page.click('.ecard:has-text("ملغى مستقبلي") button:has-text("حذف")');
  check('Delete: confirmation names the record, subject, warns irreversible', (await page.$eval('#dlg-confirm', function (d) { return d.open; })) && /ملغى مستقبلي/.test(await page.textContent('#dlg-confirm-body')) && /مادة ج/.test(await page.textContent('#dlg-confirm-body')) && /لا يمكن التراجع/.test(await page.textContent('#dlg-confirm-body')));
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  check('Delete cancelled: still there', (await store(page, KEY)).records.length === n0 && (await allCards(page)).indexOf('ملغى مستقبلي') > -1);
  await page.click('.ecard:has-text("ملغى مستقبلي") button:has-text("حذف")');
  await page.click('#dlg-confirm-body button:has-text("حذف الامتحان")');
  check('Delete confirmed: removed from list and storage + toast', (await allCards(page)).indexOf('ملغى مستقبلي') === -1 && (await store(page, KEY)).records.length === n0 - 1 && /تم حذف الامتحان/.test(await toast(page)));

  // ===== 7) إعادة التحميل =====
  var snapshot = await raw(page, KEY);
  await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  check('Reload: stored data survives byte-for-byte', (await raw(page, KEY)) === snapshot);
  await c.ctx.close();

  // ===== 8) منع الإرسال المكرر =====
  c = await open(browser, { label: 'dup' }); page = c.page; await toRep(page); await toExams(page);
  await page.click('button:has-text("إضافة امتحان")');
  await fill(page, { subject: 'م', title: 'نقر مزدوج', examDate: '2026-11-01' });
  await page.dblclick('button:has-text("حفظ الامتحان")').catch(function () { });
  await page.waitForTimeout(200);
  check('Double-click on save: exactly ONE record stored and ONE card', ((await store(page, KEY)) || { records: [] }).records.length === 1 && (await allCards(page)).length === 1, JSON.stringify(((await store(page, KEY)) || { records: [] }).records.length));
  await page.click('button:has-text("إضافة امتحان")');
  await fill(page, { subject: 'م', title: 'حدث مكرر', examDate: '2026-11-02' });
  var submits = await page.evaluate(function () {
    var f = document.querySelector('.lform form'); f.requestSubmit(); f.requestSubmit(); f.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
    return ((JSON.parse(localStorage.getItem('marsa.academic.exams.cls_demo_001')) || { records: [] }).records).filter(function (r) { return r.title === 'حدث مكرر'; }).length;
  });
  check('Repeated submit events (3 in same tick): exactly ONE record', submits === 1 && ((await store(page, KEY)).records.filter(function (r) { return r.title === 'حدث مكرر'; }).length === 1), String(submits));
  await page.click('button:has-text("إضافة امتحان")');
  await fill(page, { subject: 'م', title: 'Enter مكرر', examDate: '2026-11-03' });
  await page.press('#ef-title', 'Enter'); await page.press('#ef-title', 'Enter').catch(function () { });
  await page.waitForTimeout(150);
  check('Enter pressed twice: still ONE record for that exam', (await store(page, KEY)).records.filter(function (r) { return r.title === 'Enter مكرر'; }).length === 1);
  // تعديل مزدوج: لا سجل ثانٍ
  var cnt = (await store(page, KEY)).records.length;
  await page.click('.ecard:has-text("نقر مزدوج") button:has-text("تعديل")'); await page.fill('#ef-title', 'نقر مزدوج معدّل');
  await page.dblclick('button:has-text("حفظ التعديل")').catch(function () { });
  await page.waitForTimeout(150);
  check('Double-click on edit save: same count, edited once', (await store(page, KEY)).records.length === cnt && (await store(page, KEY)).records.filter(function (r) { return r.title === 'نقر مزدوج معدّل'; }).length === 1);
  await c.ctx.close();

  // ===== 9) فصل عن الصفوف الأخرى وعن بقية أنواع التخزين =====
  c = await open(browser, { label: 'sep' }); page = c.page; await toRep(page); await toExams(page);
  await addExam(page, { subject: 'م', title: 'امتحان الصف التجريبي', examDate: '2026-11-01' });
  check('Adding an exam writes ONLY the exams key (no preparations/lessons/schedule keys, no grades)', (await acKeys(page)).join() === KEY && (await keys(page)).every(function (k) { return !/grade|score|marks/i.test(k); }));
  var demoRaw = await raw(page, KEY);
  await page.click('.nav button:has-text("اللوحة")'); await page.click('.tile:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")');
  await page.fill('#cf-stage', 'الثالث المتوسط'); await page.fill('#cf-section', 'ب');
  await page.check('.cform .chk input'); await page.click('button:has-text("إضافة الصف")');
  await page.waitForFunction(function () { return !document.getElementById('dlg-class').open; });
  await toExams(page);
  var otherId = await page.getAttribute('main', 'data-class-id');
  check('Second class starts with EMPTY exams (no mixing)', (await allCards(page)).length === 0 && /لم تُضف أي امتحانات/.test(await page.textContent('#v-page .empty')));
  await addExam(page, { subject: 'ج', title: 'امتحان الصف الآخر', examDate: '2026-11-03' });
  var colB = await store(page, 'marsa.academic.exams.' + otherId);
  check('Other class saved under its own key/classId', colB && colB.classId === otherId && otherId !== 'cls_demo_001' && colB.records.length === 1 && colB.records[0].classId === otherId);
  check('Demo class collection bytes untouched by other-class add', (await raw(page, KEY)) === demoRaw);
  await page.selectOption('#cb-sel', 'cls_demo_001'); await page.waitForSelector('.ecard:has-text("الصف التجريبي")');
  check('Switch back: only demo exams', (await allCards(page)).join('|') === 'امتحان الصف التجريبي', (await allCards(page)).join('|'));
  await page.selectOption('#cb-sel', otherId); await page.waitForSelector('.ecard:has-text("الصف الآخر")');
  check('Switch to other: only its exam', (await allCards(page)).join('|') === 'امتحان الصف الآخر');
  await page.click('.classbar button:has-text("إدارة الصفوف")');
  await page.click('.cls:has-text("الثالث المتوسط") button:has-text("حذف نهائي")');
  check('Class with exams cannot be permanently deleted (explained)', /السجلات الدراسية/.test(await page.textContent('#dlg-confirm-body')) && (await store(page, 'marsa.academic.exams.' + otherId)) !== null);
  await page.click('#dlg-confirm-body button:has-text("حسناً")');
  await c.ctx.close();

  // ===== 10) فشل الحفظ =====
  c = await open(browser, { label: 'fail' }); page = c.page; await toRep(page); await toExams(page);
  await page.click('button:has-text("إضافة امتحان")');
  await fill(page, { subject: 'مادة', title: 'لن يُحفظ الآن', examDate: '2026-11-05', topics: 'نص طويل أدخله المستخدم', notes: 'ملاحظة', status: 'scheduled' });
  await failOn(page);
  await page.click('button:has-text("حفظ الامتحان")');
  check('Failed add: error inside form (not saved, retry hint)', /لم يُحفظ الامتحان/.test(await page.textContent('#ef-msg')) && /أعد المحاولة/.test(await page.textContent('#ef-msg')), await page.textContent('#ef-msg'));
  check('Failed add: ALL typed data kept', (await page.inputValue('#ef-title')) === 'لن يُحفظ الآن' && (await page.inputValue('#ef-subject')) === 'مادة' && (await page.inputValue('#ef-topics')) === 'نص طويل أدخله المستخدم' && (await page.inputValue('#ef-notes')) === 'ملاحظة' && (await page.inputValue('#ef-examDate')) === '2026-11-05');
  check('Failed add: NO success toast, no card, nothing in storage', !/تم حفظ/.test(await toast(page)) && (await allCards(page)).length === 0 && (await acKeys(page)).length === 0);
  check('Failed add: submit usable again', !(await page.$eval('button:has-text("حفظ الامتحان")', function (b) { return b.disabled; })));
  await failOff(page);
  await page.click('button:has-text("حفظ الامتحان")'); await page.waitForSelector('.ecard');
  check('Retry after recovery: saved once with success toast', (await allCards(page)).join() === 'لن يُحفظ الآن' && /تم حفظ الامتحان/.test(await toast(page)) && (await store(page, KEY)).records.length === 1);
  await page.click('.ecard button:has-text("تعديل")'); await page.fill('#ef-title', 'عنوان جديد لن يُحفظ');
  await failOn(page);
  await page.click('button:has-text("حفظ التعديل")');
  check('Failed edit: error + form kept + storage unchanged + no success toast', /لم يُحفظ الامتحان/.test(await page.textContent('#ef-msg')) && (await page.inputValue('#ef-title')) === 'عنوان جديد لن يُحفظ' && (await store(page, KEY)).records[0].title === 'لن يُحفظ الآن' && !/تم حفظ التعديل/.test(await toast(page)));
  await page.click('.lform button:has-text("إلغاء")'); await page.click('#dlg-confirm-body button:has-text("تجاهل والمتابعة")');
  await page.click('.ecard button:has-text("حذف")'); await page.click('#dlg-confirm-body button:has-text("حذف الامتحان")');
  check('Failed delete: still listed and stored; no «تم حذف» toast, explicit failure toast', (await allCards(page)).length === 1 && (await store(page, KEY)).records.length === 1 && !/تم حذف/.test(await toast(page)) && /لم يُحذف/.test(await toast(page)), await toast(page));
  await failOff(page);
  await c.ctx.close();

  // ===== 11) تخزين مؤقت فقط =====
  c = await open(browser, { label: 'temp', init: function () { try { Object.defineProperty(window, 'localStorage', { get: function () { throw new Error('blocked'); } }); } catch (e) { } } }); page = c.page;
  await toRep(page); await toExams(page);
  check('Blocked storage: «مؤقتة» banner on exams page', /مؤقتة/.test(await page.textContent('#v-page .warnbox')), await page.textContent('main'));
  await addExam(page, { subject: 'م', title: 'مؤقت', examDate: '2026-11-05' });
  check('Blocked storage: record visible in session and toast says NOT permanent', (await allCards(page)).join() === 'مؤقت' && /ليس بشكل دائم/.test(await toast(page)), await toast(page));
  await c.ctx.close();

  // ===== 12) بيانات تالفة =====
  c = await open(browser, { label: 'corrupt', init: function () { try { if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); localStorage.setItem('marsa.academic.exams.cls_demo_001', '{broken'); } } catch (e) { } } }); page = c.page;
  await toRep(page); await toExams(page);
  check('Corrupt collection: warning shown, add disabled, bytes unchanged, backup made, no fake success', /تالفة/.test(await page.textContent('#v-page .warnbox')) && (await page.$eval('button:has-text("إضافة امتحان")', function (b) { return b.disabled; })) && (await raw(page, KEY)) === '{broken' && (await keys(page)).some(function (k) { return k.indexOf('marsa.academic.exams.cls_demo_001.backup') === 0; }) && (await allCards(page)).length === 0);
  await c.ctx.close();

  // ===== 13) النص كنص (XSS) =====
  c = await open(browser, { label: 'xss' }); page = c.page; await toRep(page); await toExams(page);
  var X = '<img src=x onerror="window.__xss=1"><script>window.__xss=2</script>';
  await addExam(page, { subject: X, title: X, examDate: '2026-10-22', topics: X, notes: X });
  check('XSS: markup shown as text everywhere, nothing executed, no injected elements', (await page.$$('.ecard img, .ecard script, #v-page img[src="x"]')).length === 0 && (await page.evaluate(function () { return window.__xss; })) === undefined && (await page.textContent('.ecard h3')) === X && (await page.$$eval('.ecard .lc-t', function (l) { return l.length === 2 && l.every(function (e) { return e.textContent === '<img src=x onerror="window.__xss=1"><script>window.__xss=2</script>'; }); })));
  await page.click('.ecard button:has-text("تعديل")');
  check('XSS: edit form holds the raw text verbatim', (await page.inputValue('#ef-topics')) === X);
  await page.click('.lform button:has-text("إلغاء")');
  await page.click('.ecard button:has-text("حذف")');
  check('XSS: delete dialog shows markup as text', (await page.$$('#dlg-confirm-body img, #dlg-confirm-body script')).length === 0 && (await page.evaluate(function () { return window.__xss; })) === undefined);
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  await c.ctx.close();

  // ===== 14) التاريخ المحلي ونقطة منتصف الليل =====
  var zones = [['Pacific/Kiritimati', '2026-10-21T10:30:00Z', '2026-10-22', '2026-10-21'], ['America/Los_Angeles', '2026-10-22T06:30:00Z', '2026-10-21', '2026-10-20'], ['Asia/Baghdad', '2026-10-21T21:30:00Z', '2026-10-22', '2026-10-21'], ['Pacific/Pago_Pago', '2026-10-22T10:30:00Z', '2026-10-21', '2026-10-20']];
  for (var z = 0; z < zones.length; z++) {
    c = await open(browser, { label: 'tz' + z, tz: zones[z][0], clock: zones[z][1] }); page = c.page; await toRep(page); await toExams(page);
    await addExam(page, { subject: 'م', title: 'امتحان اليوم المحلي', examDate: zones[z][2] });
    await addExam(page, { subject: 'م', title: 'امتحان أمس المحلي', examDate: zones[z][3] });
    check(zones[z][0] + ': local today is upcoming (labelled اليوم), local yesterday is finished (not UTC)', (await group(page, 'upcoming')).join() === 'امتحان اليوم المحلي' && (await group(page, 'finished')).join() === 'امتحان أمس المحلي' && /اليوم/.test(await page.textContent('.ecard:has-text("اليوم المحلي") .tag.rel')), (await group(page, 'upcoming')).join() + '/' + (await group(page, 'finished')).join());
    await c.ctx.close();
  }
  c = await open(browser, { label: 'midnight', clock: '2026-10-22T20:59:00Z' }); page = c.page; await toRep(page); await toExams(page);
  await addExam(page, { subject: 'م', title: 'ينتهي موعده', examDate: '2026-10-22' });
  check('Before midnight (23:59 Baghdad): exam of today is upcoming', (await group(page, 'upcoming')).join() === 'ينتهي موعده');
  await page.clock.fastForward(3 * 60 * 1000);
  await page.waitForFunction(function () { var g = document.querySelector('.pgroup[data-group="finished"]'); return g && /ينتهي موعده/.test(g.textContent); }, null, { timeout: 5000 }).catch(function () { });
  check('After midnight with page open: moved to finished, still مجدول (not cancelled), tagged «مضى موعده» (no reload)', (await group(page, 'finished')).join() === 'ينتهي موعده' && (await group(page, 'upcoming')).length === 0 && (await page.getAttribute('.ecard', 'data-status')) === 'scheduled' && /مضى موعده/.test(await page.textContent('.ecard')));
  await c.ctx.close();

  // ===== 15) لا صف نشط =====
  c = await open(browser, { label: 'noclass' }); page = c.page; await toRep(page);
  await page.click('.nav button:has-text("اللوحة")'); await page.click('.tile:has-text("إدارة الصفوف")');
  var arch = await page.$('.cls:has-text("الثاني المهني") button:has-text("أرشفة")');
  if (arch) { await arch.click(); var conf = await page.$('#dlg-confirm[open] #dlg-confirm-body button.primary, #dlg-confirm[open] #dlg-confirm-body button:has-text("أرشفة")'); if (conf) await conf.click(); }
  await page.waitForTimeout(200);
  await toExams(page);
  check('No active class: clear alert, no form/add button, nothing written', /لا يوجد صف نشط/.test(await page.textContent('#v-page .empty')) && (await page.$('button:has-text("إضافة امتحان")')) === null && (await acKeys(page)).length === 0, (await page.textContent('#v-page')).slice(0, 200));
  await c.ctx.close();

  // ===== 16) تبويبان: حدث storage =====
  c = await open(browser, { label: 'tabA' }); page = c.page; await toRep(page); await toExams(page);
  var p2 = (await open(browser, { ctx: c.ctx, label: 'tabB' })).page; await toRep(p2); await toExams(p2);
  await addExam(p2, { subject: 'م', title: 'من تبويب آخر', examDate: '2026-11-05' });
  await page.waitForFunction(function () { return /من تبويب آخر/.test(document.getElementById('v-page').textContent); }, null, { timeout: 4000 }).catch(function () { });
  check('Two tabs: exam added in tab B appears in tab A (storage event)', (await allCards(page)).join() === 'من تبويب آخر', (await allCards(page)).join());
  await c.ctx.close();

  // ===== 17) وضع الطالب لم يتغير، والتحاضير والجدول و«ما أُخذ» ما زالت تعمل =====
  c = await open(browser, { label: 'student' }); page = c.page;
  await page.click('.nav button:has-text("الامتحانات")');
  check('Student mode «الامتحانات» (03.8): read-only view, empty-state explains how to start, no add button, nothing written to storage', (await page.$('button:has-text("إضافة امتحان")')) === null && /لا توجد امتحانات مضافة لهذا الصف بعد/.test(await page.textContent('#v-page')) && (await acKeys(page)).length === 0);
  await toRep(page);
  await page.click('.nav button:has-text("التحاضير")'); await page.waitForSelector('#page-title');
  await page.click('button:has-text("إضافة تحضير")'); await page.fill('#pf-subject', 'م'); await page.fill('#pf-title', 'ت'); await page.fill('#pf-date', '2026-10-23'); await page.fill('#pf-content', 'ج'); await page.click('button:has-text("حفظ التحضير")'); await page.waitForSelector('.pcard');
  check('Regression: preparations page still works and writes only its own key', (await acKeys(page)).join() === 'marsa.academic.preparations.cls_demo_001');
  await toExams(page);
  check('Exams page does not show preparations (independent types)', (await allCards(page)).length === 0);
  await page.click('.nav button:has-text("الجدول")'); await page.waitForSelector('#page-title');
  await page.click('.nav button:has-text("ما أُخذ اليوم")'); await page.waitForSelector('#page-title');
  check('Regression: schedule and lessons pages open without JS errors', true);
  await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")');
  await page.fill('#dlg-add-body textarea', 'زيد\nأحمد\nباسم'); await page.click('button:has-text("معاينة الأسماء")');
  await page.click('#dlg-add-body button.primary'); await page.waitForTimeout(300);
  var roster = await store(page, 'marsa.roster');
  check('Regression: bulk add students + ids/codes still work', roster && roster.students && roster.students.length === 3 && roster.students.every(function (s) { return s.studentId && s.studentCode; }));
  var names = await page.$$eval('.stu .stu-name', function (l) { return l.map(function (b) { return b.textContent; }); });
  check('Regression: Arabic sort of students (أحمد, باسم, زيد)', names.join('|') === 'أحمد|باسم|زيد', names.join('|'));
  await toExams(page);
  await addExam(page, { subject: 'م', title: 'ت', examDate: '2026-10-25' });
  check('Regression: adding an exam does not touch the roster', JSON.stringify(await store(page, 'marsa.roster')) === JSON.stringify(roster));
  await page.click('.nav button:has-text("اللوحة")');
  check('Dashboard: exactly one exams tile with the new description', (await page.$$eval('.tile', function (l) { return l.filter(function (b) { return /^الامتحانات/.test(b.textContent) || /إدارة الامتحانات/.test(b.textContent); }).length; })) === 1);
  await c.ctx.close();

  // ===== 18) موبايل =====
  var widths = [320, 360, 375, 390, 412];
  var longTxt = 'ااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااا';
  for (var w = 0; w < widths.length; w++) {
    c = await open(browser, { label: 'mob' + widths[w], viewport: { width: widths[w], height: 700 }, touch: true }); page = c.page; await toRep(page); await toExams(page);
    var ov0 = await overflow(page);
    await page.click('button:has-text("إضافة امتحان")');
    await fill(page, { subject: longTxt.slice(0, 80), title: longTxt.slice(0, 120), examDate: '2026-10-22', topics: longTxt + '\n' + longTxt, notes: longTxt });
    var ovForm = await overflow(page);
    var small = await page.$$eval('.lform button, .lform input, .lform select, .lform textarea, .toolbar button', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + Math.round(e.getBoundingClientRect().height); }); });
    var fonts = await page.$$eval('.lform input, .lform select, .lform textarea', function (l) { return l.filter(function (e) { return e.offsetParent && parseFloat(getComputedStyle(e).fontSize) < 16; }).length; });
    await page.click('button:has-text("حفظ الامتحان")'); await page.waitForSelector('.ecard');
    await addExam(page, { subject: 'م', title: 'ثانٍ', examDate: '2026-10-23', status: 'held' });
    await addExam(page, { subject: 'م', title: 'ثالث', examDate: '2026-10-01', status: 'cancelled' });
    await addExam(page, { subject: 'م', title: 'رابع', examDate: '2026-11-15' });
    var ovList = await overflow(page);
    var smallList = await page.$$eval('.ecard button', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + Math.round(e.getBoundingClientRect().height); }); });
    await page.click('.ecard button:has-text("حذف")');
    var dlgOverflow = await page.evaluate(function () { var d = document.getElementById('dlg-confirm'), r = d.getBoundingClientRect(); return r.left < 0 || r.right > window.innerWidth + 1 || document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; });
    await page.click('#dlg-confirm-body button:has-text("إلغاء")');
    check('Mobile ' + widths[w] + 'px: no horizontal scroll (empty / open form w/ long text / grouped list with all statuses / delete dialog)', !ov0 && !ovForm && !ovList && !dlgOverflow, [ov0, ovForm, ovList, dlgOverflow].join(','));
    check('Mobile ' + widths[w] + 'px: form/list controls >= 44px tall', small.length === 0 && smallList.length === 0, small.concat(smallList).join(','));
    check('Mobile ' + widths[w] + 'px: inputs/select font-size >= 16px', fonts === 0);
    await c.ctx.close();
  }
  c = await open(browser, { label: 'land', viewport: { width: 568, height: 320 }, touch: true }); page = c.page; await toRep(page); await toExams(page);
  await page.click('button:has-text("إضافة امتحان")');
  var reach = await page.evaluate(function () { var b = Array.from(document.querySelectorAll('.lform button')).filter(function (x) { return x.textContent === 'حفظ الامتحان'; })[0]; b.scrollIntoView({ block: 'center' }); var r = b.getBoundingClientRect(); return r.top >= 0 && r.bottom <= window.innerHeight; });
  check('Mobile 568x320 landscape: save reachable, no horizontal scroll', reach && !(await overflow(page)));
  await c.ctx.close();

  check('No uncaught JS errors in any session', jsErrors.length === 0, jsErrors.join(' | '));
  await browser.close();
  var failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('RUNNER ERROR', e); process.exit(2); });
