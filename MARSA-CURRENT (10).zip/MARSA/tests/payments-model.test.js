// اختبارات منطق المدفوعات (4.05) — بعيداً عن DOM. تشغيل: node tests/payments-model.test.js (لا يحتاج مكتبات)
var assert = require('assert');
var M = require('../js/payments-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake(opts) { var d = {}; opts = opts || {}; return { d: d, sets: 0, removes: 0, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { if (opts.failWrite) throw new Error('QuotaExceededError'); this.sets++; d[k] = String(v); }, removeItem: function (k) { this.removes++; delete d[k]; } }; }
var CID = 'cls_t1', TODAY = '2026-10-22', ACT = ['stu_a', 'stu_b'];
var STUDENTS = [{ studentId: 'stu_a', name: 'أحمد', status: 'active' }, { studentId: 'stu_b', name: 'بشرى', status: 'active' }, { studentId: 'stu_c', name: 'جاسم', status: 'archived' }];
var CTX = { today: TODAY, activeIds: ACT };
function ok(over) { var b = { studentId: 'stu_a', amount: '5000', purpose: 'ملزمة الرياضيات', date: '2026-10-20', receiptNo: '', note: '' }; for (var k in (over || {})) b[k] = over[k]; return b; }
function rec(id, sid, amount, date, extra) { var r = { recordId: id, classId: CID, studentId: sid, amount: amount, purpose: 'غرض', date: date }; for (var k in (extra || {})) r[k] = extra[k]; return r; }

// ---- المبلغ: صفر / سالب / غير رقمي / كسور ----
t('parseAmount: مبلغ صحيح بأرقام لاتينية وعربية وفارسية وفواصل آلاف', function () {
  assert.strictEqual(M.parseAmount('5000').value, 5000); assert.strictEqual(M.parseAmount('25,000').value, 25000); assert.strictEqual(M.parseAmount('٢٥٬٠٠٠').value, 25000);
  assert.strictEqual(M.parseAmount('۱۲۰۰۰').value, 12000); assert.strictEqual(M.parseAmount(' 1 500 ').value, 1500); assert.strictEqual(M.parseAmount(7500).value, 7500); assert.strictEqual(M.parseAmount('1').value, 1);
});
t('parseAmount: الصفر مرفوض بسببه', function () { ['0', '٠', '000', 0].forEach(function (x) { var r = M.parseAmount(x); assert.strictEqual(r.ok, false, String(x)); assert.strictEqual(r.reason, 'zero'); }); });
t('parseAmount: السالب مرفوض بسببه', function () { ['-5', '-5000', '−100', '–3', -7].forEach(function (x) { var r = M.parseAmount(x); assert.strictEqual(r.ok, false, String(x)); assert.strictEqual(r.reason, 'negative'); }); });
t('parseAmount: الكسور مرفوضة (نقطة أو فاصلة عشرية عربية) ولا تُقرَّب', function () { ['5000.5', '10.0', '٥٫٥', '.5', 5.5].forEach(function (x) { var r = M.parseAmount(x); assert.strictEqual(r.ok, false, String(x)); assert.strictEqual(r.reason, 'fraction'); }); });
t('parseAmount: غير الرقمي مرفوض (لا parseInt متساهل)', function () {
  ['abc', '12abc', '1e3', '+5', '5 د.ع', '0x10', 'Infinity', 'NaN', '5-5', '--5'].forEach(function (x) { assert.strictEqual(M.parseAmount(x).ok, false, x); });
  assert.strictEqual(M.parseAmount('').reason, 'empty'); assert.strictEqual(M.parseAmount('   ').reason, 'empty'); assert.strictEqual(M.parseAmount(null).reason, 'empty'); assert.strictEqual(M.parseAmount(undefined).reason, 'empty');
  assert.strictEqual(M.parseAmount(NaN).ok, false); assert.strictEqual(M.parseAmount(Infinity).ok, false);
});
t('parseAmount: الحد الأعلى — الحد نفسه مقبول وما فوقه مرفوض', function () {
  assert.strictEqual(M.parseAmount(String(M.MAX_AMOUNT)).ok, true); var r = M.parseAmount(String(M.MAX_AMOUNT + 1)); assert.strictEqual(r.ok, false); assert.strictEqual(r.reason, 'toolarge');
  assert.strictEqual(M.parseAmount('99999999999999999999999').reason, 'toolarge');
});
t('formatAmount: فواصل آلاف ووحدة الدينار العراقي', function () {
  assert.strictEqual(M.formatAmount(1250000, true), '1,250,000 دينار عراقي'); assert.strictEqual(M.formatAmount(500), '500 د.ع'); assert.strictEqual(M.formatAmount(NaN), '—'); assert.strictEqual(M.formatAmount('5'), '—');
});

// ---- validateEntry ----
t('validateEntry: إدخال صحيح كامل يمرّ ويُنظَّف', function () {
  var r = M.validateEntry(ok({ amount: '٥٬٠٠٠', purpose: '  ملزمة   الرياضيات ', receiptNo: ' R-1 ', note: ' ملاحظة ' }), CTX);
  assert.strictEqual(r.ok, true); assert.strictEqual(r.values.amount, 5000); assert.strictEqual(r.values.purpose, 'ملزمة الرياضيات'); assert.strictEqual(r.values.receiptNo, 'R-1'); assert.strictEqual(r.values.note, 'ملاحظة');
});
t('validateEntry: الغرض مطلوب (فارغ/مسافات/رموز خفية) وحده 80 حرفاً', function () {
  ['', '   ', '\u200B\u200F'].forEach(function (p) { assert.ok(M.validateEntry(ok({ purpose: p }), CTX).errors.purpose, JSON.stringify(p)); });
  assert.ok(!M.validateEntry(ok({ purpose: 'ا'.repeat(80) }), CTX).errors.purpose); assert.ok(M.validateEntry(ok({ purpose: 'ا'.repeat(81) }), CTX).errors.purpose);
});
t('validateEntry: رقم الوصل اختياري (فارغ مقبول) وحده 40 حرفاً والملاحظة 200', function () {
  assert.strictEqual(M.validateEntry(ok({ receiptNo: '' }), CTX).ok, true); assert.strictEqual(M.validateEntry(ok({ receiptNo: undefined, note: undefined }), CTX).ok, true);
  assert.ok(!M.validateEntry(ok({ receiptNo: 'x'.repeat(40) }), CTX).errors.receiptNo); assert.ok(M.validateEntry(ok({ receiptNo: 'x'.repeat(41) }), CTX).errors.receiptNo);
  assert.ok(!M.validateEntry(ok({ note: 'ن'.repeat(200) }), CTX).errors.note); assert.ok(M.validateEntry(ok({ note: 'ن'.repeat(201) }), CTX).errors.note);
});
t('validateEntry: أخطاء المبلغ تظهر برسائل عربية مختلفة حسب السبب', function () {
  var msgs = ['', '0', '-5', '5.5', 'abc'].map(function (a) { var e = M.validateEntry(ok({ amount: a }), CTX).errors.amount; assert.ok(e, a); return e; });
  assert.strictEqual(new Set(msgs).size, 5); assert.ok(msgs.every(function (m) { return /[\u0600-\u06FF]/.test(m); }));
});

// ---- التواريخ ----
t('التاريخ: مطلوب وصالح وفي النطاق ولا يتجاوز اليوم المحلي', function () {
  assert.ok(M.validateEntry(ok({ date: '' }), CTX).errors.date); assert.ok(M.validateEntry(ok({ date: '2026-02-30' }), CTX).errors.date); assert.ok(M.validateEntry(ok({ date: '22/10/2026' }), CTX).errors.date);
  assert.ok(M.validateEntry(ok({ date: '1999-12-31' }), CTX).errors.date); assert.ok(M.validateEntry(ok({ date: '2101-01-01' }), CTX).errors.date);
  assert.ok(M.validateEntry(ok({ date: '2026-10-23' }), CTX).errors.date, 'بعد اليوم'); assert.ok(!M.validateEntry(ok({ date: TODAY }), CTX).errors.date, 'اليوم نفسه مقبول'); assert.ok(!M.validateEntry(ok({ date: '2000-01-01' }), CTX).errors.date);
});
t('localDate: يستعمل أجزاء Date المحلية لا UTC', function () {
  assert.strictEqual(M.localDate(new Date(2026, 0, 1, 0, 30)), '2026-01-01'); assert.strictEqual(M.localDate(new Date(2026, 11, 31, 23, 59)), '2026-12-31');
});
['Asia/Baghdad', 'UTC', 'Pacific/Pago_Pago'].forEach(function (tz) {
  t('localDate بلا انزياح UTC (' + tz + ')', function () {
    var cp = require('child_process'), out = cp.execFileSync(process.execPath, ['-e', "var M=require('./js/payments-model.js');console.log(M.localDate(new Date(2026,5,15,0,5))+'|'+M.localDate(new Date(2026,5,15,23,55)))"], { cwd: require('path').resolve(__dirname, '..'), env: Object.assign({}, process.env, { TZ: tz }) }).toString().trim();
    assert.strictEqual(out, '2026-06-15|2026-06-15');
  });
});
t('formatDate: DD/MM/YYYY وتاريخ غير صالح يُعرض كما هو', function () { assert.strictEqual(M.formatDate('2026-10-05'), '05/10/2026'); assert.strictEqual(M.formatDate('xx'), 'xx'); assert.strictEqual(M.formatDate(''), '(بلا تاريخ)'); });

// ---- ربط الطالب والصف ----
t('studentId: يجب أن يكون ضمن الفعّالين (مؤرشف أو غريب أو فارغ مرفوض)', function () {
  assert.ok(M.validateEntry(ok({ studentId: 'stu_c' }), CTX).errors.studentId); assert.ok(M.validateEntry(ok({ studentId: 'stu_zzz' }), CTX).errors.studentId);
  assert.ok(M.validateEntry(ok({ studentId: '' }), CTX).errors.studentId); assert.ok(M.validateEntry(ok({ studentId: 'bad id!' }), CTX).errors.studentId); assert.ok(!M.validateEntry(ok({ studentId: 'stu_b' }), CTX).errors.studentId);
});
t('studentKind: فعّال/مؤرشف/مجهول', function () { assert.strictEqual(M.studentKind('stu_a', STUDENTS), 'active'); assert.strictEqual(M.studentKind('stu_c', STUDENTS), 'archived'); assert.strictEqual(M.studentKind('nope', STUDENTS), 'unknown'); assert.strictEqual(M.studentKind('a', null), 'unknown'); });

// ---- planSave: إنشاء/تعديل/ثبات ----
t('planSave إنشاء: لا recordId ولا classId ولا createdAt ولا حقول مشتقة', function () {
  var p = M.planSave(ok(), [], CTX, null);
  assert.strictEqual(p.ok, true); assert.strictEqual(p.mode, 'create');
  assert.ok(!('recordId' in p.record) && !('classId' in p.record) && !('createdAt' in p.record));
  assert.deepStrictEqual(Object.keys(p.record).sort(), ['amount', 'date', 'purpose', 'studentId']);
  assert.strictEqual(p.record.amount, 5000); assert.strictEqual(typeof p.record.amount, 'number');
});
t('planSave: الحقول الاختيارية الفارغة لا تُخزَّن ومعبّأة تُخزَّن', function () {
  var a = M.planSave(ok(), [], CTX, null).record; assert.ok(!('receiptNo' in a) && !('note' in a));
  var b = M.planSave(ok({ receiptNo: 'R9', note: 'ن' }), [], CTX, null).record; assert.strictEqual(b.receiptNo, 'R9'); assert.strictEqual(b.note, 'ن');
});
t('planSave تعديل: يحافظ على recordId وclassId وcreatedAt وstudentId حتى لو أُرسل طالب آخر', function () {
  var ex = rec('pay_1', 'stu_a', 5000, '2026-10-20', { createdAt: '2026-10-20T08:00:00.000Z', updatedAt: '2026-10-20T08:00:00.000Z' });
  var p = M.planSave(ok({ studentId: 'stu_b', amount: '7000' }), [ex], CTX, ex);
  assert.strictEqual(p.ok, true); assert.strictEqual(p.mode, 'update'); assert.strictEqual(p.record.recordId, 'pay_1'); assert.strictEqual(p.record.classId, CID); assert.strictEqual(p.record.createdAt, '2026-10-20T08:00:00.000Z'); assert.strictEqual(p.record.studentId, 'stu_a'); assert.strictEqual(p.record.amount, 7000);
  assert.strictEqual(ex.amount, 5000, 'لا يُعدَّل الأصل');
});
t('planSave: إزالة رقم الوصل والملاحظة عند تفريغهما في التعديل', function () {
  var ex = rec('pay_1', 'stu_a', 5000, '2026-10-20', { receiptNo: 'R1', note: 'ن' });
  var p = M.planSave(ok({ receiptNo: '', note: '' }), [ex], CTX, ex); assert.strictEqual(p.mode, 'update'); assert.ok(!('receiptNo' in p.record) && !('note' in p.record));
});
t('planSave: بلا تغيير → unchanged؛ والسجل المحذوف أثناء التعديل → not-found', function () {
  var ex = rec('pay_1', 'stu_a', 5000, '2026-10-20', { purpose: 'ملزمة الرياضيات' });
  assert.strictEqual(M.planSave(ok(), [ex], CTX, ex).mode, 'unchanged');
  var g = M.planSave(ok(), [], CTX, ex); assert.strictEqual(g.ok, false); assert.strictEqual(g.status, 'not-found');
});
t('planSave: لا منع تكرار — دفعتان متطابقتان مسموحتان', function () {
  var ex = rec('pay_1', 'stu_a', 5000, '2026-10-20', { purpose: 'ملزمة الرياضيات' });
  var p = M.planSave(ok(), [ex], CTX, null); assert.strictEqual(p.ok, true); assert.strictEqual(p.mode, 'create');
});
t('رقم الوصل المكرر: تحذير وليس منعاً (مع توحيد النص ويستثني السجل نفسه)', function () {
  var list = [rec('pay_1', 'stu_a', 1000, '2026-10-01', { receiptNo: 'AB-12' }), rec('pay_2', 'stu_b', 1000, '2026-10-02', { receiptNo: 'ab-12 ' })];
  var p = M.planSave(ok({ receiptNo: ' Ab-12 ' }), list, CTX, null);
  assert.strictEqual(p.ok, true); assert.strictEqual(p.warnings.receiptMatches.length, 2);
  var e = M.planSave(ok({ receiptNo: 'AB-12', amount: '2000' }), list, CTX, list[0]); assert.strictEqual(e.ok, true); assert.strictEqual(e.warnings.receiptMatches.length, 1, 'لا يعدّ نفسه');
  assert.strictEqual(M.planSave(ok({ receiptNo: '' }), list, CTX, null).warnings.receiptMatches.length, 0, 'الفارغ لا يُطابق');
  assert.strictEqual(M.findReceiptMatches(list, '', null).length, 0);
});

// ---- الإجماليات والفترات ----
var BIG = [rec('p1', 'stu_a', 1000, '2026-09-30'), rec('p2', 'stu_a', 2000, '2026-10-01'), rec('p3', 'stu_b', 3000, '2026-10-10'), rec('p4', 'stu_b', 500, '2026-10-31'), rec('p5', 'stu_c', 250, '2026-10-15')];
t('sumRecords: مجموع صحيح وعدد، والفارغ = صفر صادق', function () {
  var s = M.sumRecords(BIG); assert.strictEqual(s.total, 6750); assert.strictEqual(s.count, 5); assert.strictEqual(s.invalid, 0);
  var e = M.sumRecords([]); assert.strictEqual(e.total, 0); assert.strictEqual(e.count, 0); assert.strictEqual(M.sumRecords(null).total, 0);
});
t('sumRecords: السجلات ذات المبلغ التالف تُستثنى وتُعدّ ولا تُعامل صفراً أو نصاً', function () {
  var s = M.sumRecords([rec('a', 'x', 1000, '2026-10-01'), rec('b', 'x', '500', '2026-10-01'), rec('c', 'x', -5, '2026-10-01'), rec('d', 'x', 2.5, '2026-10-01'), rec('e', 'x', null, '2026-10-01')]);
  assert.strictEqual(s.total, 1000); assert.strictEqual(s.count, 1); assert.strictEqual(s.invalid, 4);
});
t('sumRecords: تجاوز الحد الآمن يُعلَن overflow ولا يُنتج رقماً خاطئاً', function () {
  var s = M.sumRecords([rec('a', 'x', Number.MAX_SAFE_INTEGER, '2026-10-01'), rec('b', 'x', 10, '2026-10-01')]); assert.strictEqual(s.overflow, true); assert.strictEqual(s.total, Number.MAX_SAFE_INTEGER); assert.ok(Number.isSafeInteger(s.total));
});
t('totalInPeriod: الحدّان شاملان (حدود اليوم الأول والأخير)', function () {
  assert.strictEqual(M.totalInPeriod(BIG, '2026-10-01', '2026-10-31').total, 5750); // p2+p3+p4+p5
  assert.strictEqual(M.totalInPeriod(BIG, '2026-10-01', '2026-10-31').count, 4);
  assert.strictEqual(M.totalInPeriod(BIG, '2026-10-01', '2026-10-01').total, 2000); assert.strictEqual(M.totalInPeriod(BIG, '2026-10-31', '2026-10-31').total, 500);
  assert.strictEqual(M.totalInPeriod(BIG, '2026-10-02', '2026-10-09').total, 0, 'فترة بلا سجلات = صفر وليس null');
});
t('totalInPeriod: حد واحد أو بلا حدود = كل السجلات؛ ومجموع الفترة ≠ المجموع التاريخي', function () {
  var all = M.totalInPeriod(BIG, '', ''); assert.strictEqual(all.total, 6750); assert.strictEqual(all.bounded, false);
  assert.strictEqual(M.totalInPeriod(BIG, '2026-10-10', '').total, 3000 + 500 + 250); assert.strictEqual(M.totalInPeriod(BIG, '', '2026-09-30').total, 1000);
  assert.notStrictEqual(M.totalInPeriod(BIG, '2026-10-01', '2026-10-31').total, all.total); assert.strictEqual(M.totalInPeriod(BIG, '2026-10-01', '2026-10-31').bounded, true);
});
t('totalInPeriod: لا تعدّل المدخلات', function () { var c = JSON.stringify(BIG); M.totalInPeriod(BIG, '2026-10-01', '2026-10-31'); M.totalsByStudent(BIG); assert.strictEqual(JSON.stringify(BIG), c); });
t('totalsByStudent: لكل studentId لا بالاسم، مرتب بالأكبر ثم الاسم', function () {
  var names = { stu_a: 'أحمد', stu_b: 'بشرى', stu_c: 'جاسم' };
  var r = M.totalsByStudent(BIG, function (id) { return names[id]; });
  assert.deepStrictEqual(r.map(function (x) { return x.studentId + ':' + x.total; }), ['stu_b:3500', 'stu_a:3000', 'stu_c:250']);
  assert.strictEqual(M.totalsByStudent([], null).length, 0);
  var tie = M.totalsByStudent([rec('a', 'stu_b', 100, '2026-10-01'), rec('b', 'stu_a', 100, '2026-10-01')], function (id) { return names[id]; }); assert.deepStrictEqual(tie.map(function (x) { return x.studentId; }), ['stu_a', 'stu_b']);
});
t('totalsByStudent: طالبان بالاسم نفسه يبقيان منفصلين (المفتاح studentId)', function () {
  var r = M.totalsByStudent([rec('a', 's1', 100, '2026-10-01'), rec('b', 's2', 200, '2026-10-01')], function () { return 'محمد'; }); assert.strictEqual(r.length, 2);
});
t('periodLabel/validatePeriod: يعلن ما يغطيه الإجمالي ويكشف الفترة المعكوسة', function () {
  assert.ok(/كل السجلات/.test(M.periodLabel('', ''))); assert.strictEqual(M.periodLabel('2026-10-01', '2026-10-31'), 'من 01/10/2026 إلى 31/10/2026'); assert.strictEqual(M.periodLabel('2026-10-05', '2026-10-05'), 'يوم 05/10/2026');
  assert.ok(/من 01\/10\/2026/.test(M.periodLabel('2026-10-01', ''))); assert.ok(/حتى 31\/10\/2026/.test(M.periodLabel('', '2026-10-31')));
  assert.strictEqual(M.validatePeriod('', ''), null); assert.strictEqual(M.validatePeriod('2026-10-01', '2026-10-31'), null); assert.ok(M.validatePeriod('2026-11-01', '2026-10-01')); assert.ok(M.validatePeriod('bad', ''));
});

// ---- البحث والفرز ----
var NAMES = { stu_a: 'أحمد', stu_b: 'بشرى', stu_c: 'جاسم' };
function nameOf(id) { return NAMES[id] || ''; }
t('filterRecords: بالطالب/الغرض/رقم الوصل/التاريخ/المبلغ/الملاحظة مع توحيد الهمزات والتشكيل', function () {
  var L = [rec('a', 'stu_a', 5000, '2026-10-05', { purpose: 'أجور الرحلة', receiptNo: 'R-77', note: 'دفعة أولى' }), rec('b', 'stu_b', 12000, '2026-10-06', { purpose: 'ملزمة' })];
  function q(x) { return M.filterRecords(L, { query: x, nameOf: nameOf }).map(function (r) { return r.recordId; }).join(); }
  assert.strictEqual(q('احمد'), 'a'); assert.strictEqual(q('اجور'), 'a'); assert.strictEqual(q('r-77'), 'a'); assert.strictEqual(q('2026-10-06'), 'b'); assert.strictEqual(q('06/10/2026'), 'b'); assert.strictEqual(q('12000'), 'b'); assert.strictEqual(q('اولى'), 'a'); assert.strictEqual(q('بشرى'), 'b'); assert.strictEqual(q('غيرموجود'), '');
});
t('filterRecords: طالب وفترة معاً', function () {
  assert.strictEqual(M.filterRecords(BIG, { studentId: 'stu_b', from: '2026-10-01', to: '2026-10-20' }).length, 1);
  assert.strictEqual(M.filterRecords(BIG, { studentId: 'all' }).length, 5); assert.strictEqual(M.filterRecords(BIG, null).length, 5);
});
t('sortRecords: بالتاريخ والمبلغ والاسم والغرض، ثابت وحتمي ولا يعدّل الأصل', function () {
  var c = JSON.stringify(BIG);
  assert.deepStrictEqual(M.sortRecords(BIG, 'date', 'desc').map(function (r) { return r.recordId; }), ['p4', 'p5', 'p3', 'p2', 'p1']);
  assert.deepStrictEqual(M.sortRecords(BIG, 'amount', 'desc').map(function (r) { return r.recordId; }), ['p3', 'p2', 'p1', 'p4', 'p5']);
  assert.deepStrictEqual(M.sortRecords(BIG, 'amount', 'asc').map(function (r) { return r.recordId; }), ['p5', 'p4', 'p1', 'p2', 'p3']);
  assert.strictEqual(M.sortRecords(BIG, 'student', 'asc', nameOf)[0].studentId, 'stu_a'); assert.strictEqual(M.sortRecords(BIG, 'bogus', 'desc')[0].recordId, 'p4');
  assert.strictEqual(JSON.stringify(BIG), c);
});

// ---- التكامل مع المتجر: حذف، فشل التخزين، أرشفة، عزل الصف ----
function mk() { var st = fake(), s = S.create({ storage: st }); return { st: st, s: s }; }
function add(s, cid, over) { var p = M.planSave(ok(over), [], CTX, null); assert.ok(p.ok, JSON.stringify(p.errors)); return s.upsertRecord('payments', cid, p.record); }
t('تكامل: الإضافة ثم التعديل تُبقي recordId ولا تضاعف السجلات', function () {
  var x = mk(), a = add(x.s, CID), id = a.record.recordId;
  assert.ok(a.ok && /^pay_/.test(id) && a.record.classId === CID && a.record.createdAt);
  for (var i = 1; i <= 4; i++) {
    var cur = x.s.readCollection('payments', CID).records, ex = cur[0];
    var p = M.planSave(ok({ amount: String(5000 + i * 100) }), cur, CTX, ex); assert.strictEqual(p.mode, 'update');
    var u = x.s.upsertRecord('payments', CID, p.record); assert.ok(u.ok); assert.strictEqual(u.record.recordId, id); assert.strictEqual(u.created, false);
  }
  var f2 = x.s.readCollection('payments', CID).records; assert.strictEqual(f2.length, 1); assert.strictEqual(f2[0].amount, 5400); assert.strictEqual(f2[0].createdAt, a.record.createdAt);
});
t('تكامل: الحذف يزيل السجل المقصود فقط، وحذف غير موجود لا ينجح كذباً', function () {
  var x = mk(), a = add(x.s, CID), b = add(x.s, CID, { amount: '700' });
  var d = x.s.deleteRecord('payments', CID, a.record.recordId); assert.ok(d.ok); var left = x.s.readCollection('payments', CID).records; assert.strictEqual(left.length, 1); assert.strictEqual(left[0].recordId, b.record.recordId);
  var again = x.s.deleteRecord('payments', CID, a.record.recordId); assert.strictEqual(again.ok, false); assert.strictEqual(again.status, 'not-found');
});
t('تكامل: دفعتان متطابقتان تُحفظان كلتاهما (لا duplicate في المتجر)', function () {
  var x = mk(), a = add(x.s, CID), b = add(x.s, CID); assert.ok(a.ok && b.ok); assert.notStrictEqual(a.record.recordId, b.record.recordId); assert.strictEqual(x.s.readCollection('payments', CID).records.length, 2);
});
t('تكامل: العزل بين صفين، ولا لمس لمفاتيح الطلاب والصفوف ونوع الدرجات', function () {
  var x = mk(); x.st.setItem('marsa.roster', 'R'); x.st.setItem('marsa.classes', 'C'); x.st.removes = 0;
  var a = add(x.s, 'cls_a'), b = add(x.s, 'cls_b', { amount: '900' });
  assert.strictEqual(x.s.readCollection('payments', 'cls_a').records.length, 1); assert.strictEqual(x.s.readCollection('payments', 'cls_b').records[0].amount, 900);
  x.s.deleteRecord('payments', 'cls_a', a.record.recordId); assert.strictEqual(x.s.readCollection('payments', 'cls_a').records.length, 0); assert.strictEqual(x.s.readCollection('payments', 'cls_b').records.length, 1);
  assert.strictEqual(x.st.getItem('marsa.roster'), 'R'); assert.strictEqual(x.st.getItem('marsa.classes'), 'C'); assert.strictEqual(x.s.readCollection('grades', 'cls_a').records.length, 0); assert.strictEqual(x.st.removes, 0);
});
t('تكامل: سجل دفع صف آخر لا يُقبل (classId مختلف)', function () {
  var x = mk(), r = x.s.upsertRecord('payments', 'cls_a', { classId: 'cls_b', studentId: 'stu_a', amount: 100, purpose: 'غ', date: '2026-10-01' }); assert.strictEqual(r.ok, false); assert.strictEqual(r.status, 'class-mismatch');
});
t('أرشفة الطالب: سجله القديم يبقى مقروءاً ويُعرض مؤرشفاً ويدخل الإجمالي ولا يُنشأ له جديد', function () {
  var x = mk(), a = add(x.s, CID, { studentId: 'stu_a', amount: '4000' });
  var after = [{ studentId: 'stu_a', name: 'أحمد', status: 'archived' }];
  var recs = x.s.readCollection('payments', CID).records; assert.strictEqual(recs.length, 1);
  assert.strictEqual(M.studentKind('stu_a', after), 'archived'); assert.strictEqual(M.sumRecords(recs).total, 4000);
  assert.strictEqual(M.totalsByStudent(recs)[0].studentId, 'stu_a');
  var p = M.planSave(ok({ studentId: 'stu_a' }), recs, { today: TODAY, activeIds: [] }, null); assert.strictEqual(p.ok, false); assert.ok(p.errors.studentId);
  assert.strictEqual(x.s.readCollection('payments', CID).records[0].recordId, a.record.recordId);
});
t('فشل التخزين: الحفظ لا ينجح كذباً والسجلات السابقة سليمة', function () {
  var good = mk(); add(good.s, CID);
  var st = fake(), s = S.create({ storage: st }); add(s, CID); var before = st.d['marsa.academic.payments.' + CID];
  var bad = { d: st.d, getItem: st.getItem, removeItem: st.removeItem, key: st.key, get length() { return st.length; }, setItem: function () { throw new Error('QuotaExceededError'); } };
  var s2 = S.create({ storage: bad }); var p = M.planSave(ok({ amount: '999' }), s2.readCollection('payments', CID).records, CTX, null);
  var r = s2.upsertRecord('payments', CID, p.record); assert.strictEqual(r.ok, false); assert.strictEqual(r.status, 'write-failed'); assert.ok(r.error); assert.strictEqual(st.d['marsa.academic.payments.' + CID], before);
  var del = s2.deleteRecord('payments', CID, s2.readCollection('payments', CID).records[0].recordId); assert.strictEqual(del.ok, false); assert.strictEqual(st.d['marsa.academic.payments.' + CID], before);
});
t('بيانات تالفة: لا تُعرض فارغة ولا تُكتب فوقها', function () {
  var st = fake(), s = S.create({ storage: st }); st.d['marsa.academic.payments.' + CID] = '{broken';
  var r = s.readCollection('payments', CID); assert.strictEqual(r.ok, false); assert.strictEqual(r.blocked, true); assert.strictEqual(r.status, 'corrupt');
  var w = s.upsertRecord('payments', CID, M.planSave(ok(), [], CTX, null).record); assert.strictEqual(w.ok, false); assert.strictEqual(st.d['marsa.academic.payments.' + CID], '{broken');
});
t('المتجر يرفض دفعة بمبلغ غير صحيح حتى لو تجاوزت الواجهة (خط الدفاع)', function () {
  var x = mk();
  [0, -1, 5.5, '500', NaN, null, Infinity].forEach(function (a) { var r = x.s.upsertRecord('payments', CID, { studentId: 'stu_a', amount: a, purpose: 'غ', date: '2026-10-01' }); assert.strictEqual(r.ok, false, String(a)); });
  assert.strictEqual(x.s.readCollection('payments', CID).records.length, 0);
});
t('المتجر يرفض الحقول المشتقة أو المالية الممنوعة (متبقٍ/دين/رصيد/غرامة)', function () {
  var x = mk();
  ['remaining', 'balance', 'debt', 'due', 'fine', 'currency'].forEach(function (k) { var o = { studentId: 'stu_a', amount: 100, purpose: 'غ', date: '2026-10-01' }; o[k] = 1; assert.strictEqual(x.s.upsertRecord('payments', CID, o).ok, false, k); });
});
t('لا مبالغ افتراضية: النموذج بلا أي ثابت مبلغ/رسوم/دين، ولا استيراد لنماذج أخرى', function () {
  var src = require('fs').readFileSync(require('path').resolve(__dirname, '..', 'js', 'payments-model.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//, '');
  assert.ok(!/DEFAULT_AMOUNT|defaultAmount|FEE|tuition|debt|owed|remaining/i.test(src.replace(/MAX_AMOUNT/g, '')));
  assert.ok(!/require\(|grades-model|attendance-model|MarsaGradesModel|eval\(|new Function|innerHTML|insertAdjacentHTML/.test(src));
});

console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
