// اختبار واجهة المرحلة 03.11 (عزل بيانات الصفوف ومعالجة الأخطاء) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-isolation.playwright.js   (أو بعد تثبيت playwright محلياً)
// كل سياق متصفح معزول؛ تُحقن البيانات في تخزين السياق المؤقت فقط، ولا يُلمس أي تخزين حقيقي.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var DEMO = 'cls_demo_001', B = 'cls_b_0002', NOW = '2026-10-22T06:00:00Z', TODAY = '2026-10-22';
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }

function cls(id, stage, status) { return { classId: id, schoolName: '', stage: stage, branch: '', section: '', year: '', status: status || 'active', createdAt: null, archivedAt: status === 'archived' ? '2026-10-01T00:00:00.000Z' : null }; }
function classesJson(active, list) { return JSON.stringify({ schemaVersion: 1, activeClassId: active, classes: list || [cls(DEMO, 'صف ألف'), cls(B, 'صف باء')] }); }
function base(id, c) { return { recordId: id, classId: c, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }; }
function data(c, tag) {
  return {
    dailyLessons: [Object.assign(base('dl_' + tag, c), { subject: 'مادة-' + tag, title: 'درس-' + tag, date: '2026-10-21' })],
    preparations: [Object.assign(base('prep_' + tag, c), { subject: 'مادة-' + tag, title: 'تحضير-' + tag, date: TODAY })],
    schedule: [Object.assign(base('sch_' + tag, c), { day: 'thu', subject: 'حصة-' + tag, period: 1, startTime: '08:00', endTime: '08:45' })],
    exams: [Object.assign(base('exam_' + tag, c), { subject: 'مادة-' + tag, title: 'امتحان-' + tag, examDate: '2026-10-25' })]
  };
}
function col(c, recs) { return JSON.stringify({ schemaVersion: 1, classId: c, records: recs }); }
// يبني سكربت الحقن: يكتب المفتاح فقط إن لم يكن موجوداً (حتى لا تُمحى التغييرات عند إعادة التحميل)
function seedScript(map) { return 'try{var m=' + JSON.stringify(map) + ';for(var k in m){if(localStorage.getItem(k)===null)localStorage.setItem(k,m[k]);}}catch(e){}'; }
function fullSeed(extra) {
  var map = { 'marsa.classes': classesJson(DEMO) }, a = data(DEMO, 'AAA'), b = data(B, 'BBB');
  ['dailyLessons', 'preparations', 'schedule', 'exams'].forEach(function (t) { map['marsa.academic.' + t + '.' + DEMO] = col(DEMO, a[t]); map['marsa.academic.' + t + '.' + B] = col(B, b[t]); });
  map['marsa.roster'] = JSON.stringify({ schemaVersion: 2, classId: DEMO, students: [{ studentId: 'stu_a1', studentCode: 'MRS-AAAA-0001', name: 'طالب ألف', status: 'active' }] });
  map['marsa.roster.' + B] = JSON.stringify({ schemaVersion: 2, classId: B, students: [{ studentId: 'stu_b1', studentCode: 'MRS-BBBB-0001', name: 'طالب باء', status: 'active' }] });
  for (var k in extra) map[k] = extra[k];
  return map;
}
async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  if (await page.$eval('.seg', function (s) { return s.hidden; })) {
    await page.click('.nav button:has-text("الإعدادات")');
    await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
    await page.click('button:has-text("تفعيل")');
  }
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function nav(page, label) { await page.click('.nav button:has-text("' + label + '")'); if (label === 'الرئيسية') await page.waitForSelector('#v-home:not([hidden])'); else await page.waitForSelector('#page-title'); }
async function pageText(page) { return page.textContent('#v-page'); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function keys(page) { return page.evaluate(function () { var o = []; for (var i = 0; i < localStorage.length; i++) o.push(localStorage.key(i)); return o.sort(); }); }
async function toast(page) { return page.$eval('#status', function (s) { return s.textContent; }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function recCount(page, type, c) { return page.evaluate(function (a) { var r = localStorage.getItem('marsa.academic.' + a.t + '.' + a.c); return r === null ? -1 : JSON.parse(r).records.length; }, { t: type, c: c }); }
async function switchTo(page, id) { await page.selectOption('#cb-sel', id); await page.waitForTimeout(150); }

var REP = [['r-lessons', 'ما أُخذ اليوم', 'dailyLessons', 'درس-'], ['r-prep', 'التحاضير', 'preparations', 'تحضير-'], ['r-schedule', 'الجدول', 'schedule', 'حصة-'], ['r-exams', 'الامتحانات', 'exams', 'امتحان-']];
var STU = [['الجدول', 'حصة-'], ['التحاضير', 'تحضير-'], ['الأرشيف', 'درس-'], ['الامتحانات', 'امتحان-']];

(async function () {
  var browser = await pw.chromium.launch(), c, page, i, j, t;

  // ===== 1) التبديل بين صفين في صفحات الممثل: لا يظهر سجل صف داخل صف آخر
  c = await open(browser, { label: 'switch', init: seedScript(fullSeed()) }); page = c.page;
  var snapshot = {}; (await keys(page)).forEach(function () { }); // لقطة الأساس تؤخذ بعد أول تحميل (يضيف الترحيل أكواداً إن لزم)
  var rosterA0 = await raw(page, 'marsa.roster'), rosterB0 = await raw(page, 'marsa.roster.' + B);
  var acad0 = {}; (await keys(page)).filter(function (k) { return k.indexOf('marsa.academic') === 0; }).forEach(function (k) { acad0[k] = 1; });
  for (var k0 in acad0) acad0[k0] = await raw(page, k0);
  await toRep(page);
  for (i = 0; i < REP.length; i++) {
    await nav(page, REP[i][1]);
    t = await pageText(page);
    check('rep ' + REP[i][0] + ': الصف A يعرض سجلاته فقط', t.indexOf(REP[i][3] + 'AAA') > -1 && t.indexOf('BBB') < 0, t.slice(0, 200));
    await switchTo(page, B);
    t = await pageText(page);
    check('rep ' + REP[i][0] + ': بعد التبديل إلى B تظهر سجلات B فقط', t.indexOf(REP[i][3] + 'BBB') > -1 && t.indexOf('AAA') < 0, t.slice(0, 200));
    check('rep ' + REP[i][0] + ': لا تمرير أفقي', !(await overflow(page)));
    await switchTo(page, DEMO);
  }
  // صفحات الطالب والرئيسية
  await switchTo(page, DEMO); await toStudent(page);
  for (i = 0; i < STU.length; i++) {
    await nav(page, STU[i][0]); t = await pageText(page);
    check('student ' + STU[i][0] + ': A فقط', t.indexOf('AAA') > -1 && t.indexOf('BBB') < 0, t.slice(0, 160));
  }
  var home = await page.textContent('#v-home');
  check('الرئيسية: لا تظهر سجلات B وأنا في A', home.indexOf('BBB') < 0);
  await toRep(page); await nav(page, 'ما أُخذ اليوم'); await switchTo(page, B); await toStudent(page);
  for (i = 0; i < STU.length; i++) {
    await nav(page, STU[i][0]); t = await pageText(page);
    check('student ' + STU[i][0] + ': بعد التبديل B فقط', t.indexOf('BBB') > -1 && t.indexOf('AAA') < 0, t.slice(0, 160));
  }
  await nav(page, 'الرئيسية'); home = await page.textContent('#v-home');
  check('الرئيسية: لا تظهر سجلات A وأنا في B', home.indexOf('AAA') < 0 && /BBB/.test(home), home.slice(0, 300));
  check('التبديل لم يغيّر أي مجموعة أكاديمية ولا قائمة طلاب', (await raw(page, 'marsa.roster')) === rosterA0 && (await raw(page, 'marsa.roster.' + B)) === rosterB0 && (await (async function () { for (var k in acad0) if ((await raw(page, k)) !== acad0[k]) return false; return true; })()));
  await c.ctx.close();

  // ===== 2) أرشفة صف واستعادته وعدم وجود صف نشط
  c = await open(browser, { label: 'archive', init: seedScript(fullSeed()) }); page = c.page;
  rosterA0 = await raw(page, 'marsa.roster'); rosterB0 = await raw(page, 'marsa.roster.' + B);
  acad0 = {}; var ks = (await keys(page)).filter(function (k) { return k.indexOf('marsa.academic') === 0; });
  for (i = 0; i < ks.length; i++) acad0[ks[i]] = await raw(page, ks[i]);
  await toRep(page); await nav(page, 'ما أُخذ اليوم');
  await page.click('button:has-text("إدارة الصفوف")');
  await page.waitForSelector('#page-title');
  // أرشفة الصف النشط (A)
  await page.click('.clist li:has-text("صف ألف") button:has-text("أرشفة")');
  await page.click('dialog button:has-text("أرشفة الصف"), [role=dialog] button:has-text("أرشفة الصف")');
  await page.waitForTimeout(150);
  t = await pageText(page);
  check('بعد أرشفة الصف النشط: حالة «لا يوجد صف نشط»', t.indexOf('لا يوجد صف نشط') > -1);
  for (i = 0; i < REP.length; i++) { await nav(page, REP[i][1]); t = await pageText(page); check('بلا صف نشط ' + REP[i][0] + ': لا سجلات وزر فتح إدارة الصفوف', t.indexOf('لا يوجد صف نشط') > -1 && t.indexOf('AAA') < 0 && t.indexOf('BBB') < 0, t.slice(0, 120)); }
  check('الأرشفة لم تُغيّر قائمتي الطلاب', (await raw(page, 'marsa.roster')) === rosterA0 && (await raw(page, 'marsa.roster.' + B)) === rosterB0);
  var same = true; for (var k1 in acad0) if ((await raw(page, k1)) !== acad0[k1]) same = false;
  check('الأرشفة لم تُغيّر أي مجموعة أكاديمية', same);
  await toStudent(page);
  for (i = 0; i < STU.length; i++) { await nav(page, STU[i][0]); t = await pageText(page); check('طالب بلا صف نشط ' + STU[i][0] + ': لا سجلات', t.indexOf('AAA') < 0 && t.indexOf('BBB') < 0 && t.indexOf('لا يوجد صف نشط') > -1, t.slice(0, 120)); }
  await toRep(page); await page.click('.nav button:has-text("إدارة الصفوف")').catch(function () { });
  await c.ctx.close();

  // ===== 3) عدم تطابق classId: بيانات A تحت مفتاح B (وبالعكس على مستوى السجل)
  for (i = 0; i < REP.length; i++) {
    var type = REP[i][2], a = data(DEMO, 'AAA'), extra = {}, badKey = 'marsa.academic.' + type + '.' + B;
    extra[badKey] = col(DEMO, a[type]); // المجموعة نفسها بـ classId A لكن تحت مفتاح B
    var map = fullSeed(extra), badRaw = extra[badKey];
    c = await open(browser, { label: 'mismatch-' + type, init: seedScript(map) }); page = c.page;
    await toRep(page); await nav(page, REP[i][1]); await switchTo(page, B);
    t = await pageText(page);
    check('mismatch ' + type + ': لا يظهر سجل A داخل B', t.indexOf('AAA') < 0, t.slice(0, 200));
    check('mismatch ' + type + ': يظهر خطأ واضح', /لا يطابق|تالف|غير صالحة/.test(t) && /notice|warn/.test(await page.innerHTML('#v-page')), t.slice(0, 200));
    check('mismatch ' + type + ': المفتاح الخام لم يُستبدل', (await raw(page, badKey)) === badRaw);
    check('mismatch ' + type + ': نسخة خام احتياطية محفوظة', (await keys(page)).some(function (k) { return k.indexOf(badKey + '.backup') === 0 && true; }));
    var addDisabled = await page.$$eval('#v-page button', function (bs) { return bs.filter(function (b) { return /^إضافة/.test(b.textContent.trim()); }).every(function (b) { return b.disabled; }); });
    check('mismatch ' + type + ': أزرار الإضافة معطّلة', addDisabled);
    await switchTo(page, DEMO); t = await pageText(page);
    check('mismatch ' + type + ': صف A سليم لم يتأثر', t.indexOf(REP[i][3] + 'AAA') > -1);
    await toStudent(page);
    var stuLabel = { dailyLessons: 'الأرشيف', preparations: 'التحاضير', schedule: 'الجدول', exams: 'الامتحانات' }[type];
    await toRep(page); await nav(page, REP[i][1]); await switchTo(page, B); await toStudent(page); await nav(page, stuLabel);
    t = await pageText(page);
    check('mismatch ' + type + ': عرض الطالب لصف B لا يعرض A ويُظهر خطأ', t.indexOf('AAA') < 0 && /لا يطابق|تالف|غير صالحة|تعذّرت/.test(t), t.slice(0, 200));
    await c.ctx.close();
  }

  // ===== 4) أخطاء التخزين: ممتلئ، غير متاح، تالف، schemaVersion أحدث، نقر مزدوج
  var FORMS = {
    dailyLessons: { nav: 'ما أُخذ اليوم', add: 'إضافة سجل درس', save: 'حفظ السجل', fill: async function (p) { await p.fill('#lf-subject', 'م-جديدة'); await p.fill('#lf-title', 'عنوان-جديد'); await p.fill('#lf-date', TODAY); } },
    preparations: { nav: 'التحاضير', add: 'إضافة تحضير', save: 'حفظ التحضير', fill: async function (p) { await p.fill('#pf-subject', 'م-جديدة'); await p.fill('#pf-title', 'عنوان-جديد'); await p.fill('#pf-date', TODAY); await p.fill('#pf-content', 'محتوى'); } },
    schedule: { nav: 'الجدول', add: 'إضافة حصة', save: 'button[type=submit]', fill: async function (p) { await p.selectOption('#sf-day', 'thu'); await p.fill('#sf-subject', 'م-جديدة'); await p.fill('#sf-period', '2'); await p.fill('#sf-startTime', '09:00'); await p.fill('#sf-endTime', '09:45'); } },
    exams: { nav: 'الامتحانات', add: 'إضافة امتحان', save: 'حفظ الامتحان', fill: async function (p) { await p.fill('#ef-subject', 'م-جديدة'); await p.fill('#ef-title', 'عنوان-جديد'); await p.fill('#ef-examDate', '2026-10-30'); } }
  };
  var EMPTY = { 'marsa.classes': classesJson(DEMO, [cls(DEMO, 'صف ألف')]) };
  async function openForm(page, f) { await nav(page, f.nav); await page.click('button:has-text("' + f.add + '") >> nth=0'); await f.fill(page); }
  function saveSel(f) { return f.save.indexOf('button') === 0 ? f.save : 'button:has-text("' + f.save + '")'; }
  var TYPES4 = Object.keys(FORMS), ty;

  for (j = 0; j < TYPES4.length; j++) {
    ty = TYPES4[j]; var f = FORMS[ty];
    // 4a) نقر مزدوج: سجل واحد فقط
    c = await open(browser, { label: 'dbl-' + ty, init: seedScript(EMPTY) }); page = c.page;
    await toRep(page); await openForm(page, f);
    await page.dblclick(saveSel(f)).catch(function () { });
    await page.waitForTimeout(300);
    check('نقر مزدوج ' + ty + ': سجل واحد فقط', (await recCount(page, ty, DEMO)) === 1, 'count=' + (await recCount(page, ty, DEMO)));
    await c.ctx.close();
    // 4a2) إرسالان متتاليان فعليان للنموذج نفسه (Enter مكرر / لمس سريع)
    c = await open(browser, { label: 'dbl2-' + ty, init: seedScript(EMPTY) }); page = c.page;
    await toRep(page); await openForm(page, f);
    await page.evaluate(function () { var fm = document.querySelector('form.lf, form'); fm.requestSubmit(); fm.requestSubmit(); });
    await page.waitForTimeout(300);
    check('إرسالان متتاليان ' + ty + ': سجل واحد فقط', (await recCount(page, ty, DEMO)) === 1, 'count=' + (await recCount(page, ty, DEMO)));
    await c.ctx.close();

    // 4b) تخزين ممتلئ: لا رسالة نجاح، النموذج يبقى، لا شيء يُكتب
    c = await open(browser, { label: 'quota-' + ty, init: seedScript(EMPTY) }); page = c.page;
    await toRep(page); await openForm(page, f);
    await page.evaluate(function () { var o = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (String(k).indexOf('marsa.academic') === 0) throw new DOMException('quota', 'QuotaExceededError'); return o.apply(this, arguments); }; });
    await page.click(saveSel(f)); await page.waitForTimeout(250);
    var st = await toast(page), body = await pageText(page);
    check('تخزين ممتلئ ' + ty + ': لا إعلان نجاح', !/^تم حفظ|تم الحفظ|تم حفظ/.test(st) && /لم يُحفظ/.test(body), 'toast=' + st + ' body=' + body.slice(0, 200));
    check('تخزين ممتلئ ' + ty + ': النموذج مفتوح ببياناتي', (await page.$$('.lform:not([hidden]) form, form.lf, form')).length > 0 && (await recCount(page, ty, DEMO)) <= 0);
    await c.ctx.close();

    // 4c) localStorage غير متاح كلياً: يعمل في الذاكرة مع تحذير صريح، بلا ادعاء حفظ دائم
    c = await open(browser, { label: 'nols-' + ty, init: 'Object.defineProperty(window,"localStorage",{get:function(){throw new DOMException("denied","SecurityError");}});' }); page = c.page;
    check('localStorage غير متاح ' + ty + ': الصفحة تُحمَّل', await page.$('#main') !== null);
    await c.ctx.close();
    c = await open(browser, { label: 'nols2-' + ty, init: 'try{var _g=Storage.prototype.getItem,_s=Storage.prototype.setItem,_r=Storage.prototype.removeItem;Storage.prototype.getItem=Storage.prototype.setItem=Storage.prototype.removeItem=function(){throw new DOMException("denied","SecurityError");};}catch(e){}' }); page = c.page;
    await toRep(page).catch(function () { });
    var nav1 = await page.$('.nav button:has-text("' + f.nav + '")');
    if (nav1) {
      await openForm(page, f).catch(function () { });
      await page.click(saveSel(f)).catch(function () { }); await page.waitForTimeout(250);
      st = await toast(page); body = await pageText(page);
      check('تخزين غير متاح ' + ty + ': لا ادّعاء حفظ دائم (رسالة ذاكرة الصفحة أو تحذير)', /ذاكرة|مؤقت|غير متاح|لم يُحفظ/.test(st + ' ' + body), 'toast=' + st + ' body=' + body.slice(0, 160));
    } else check('تخزين غير متاح ' + ty + ': واجهة الممثل متاحة', false, 'nav missing');
    await c.ctx.close();

    // 4d) تالف / schemaVersion أحدث / 0: قراءة وكتابة محجوبتان والخام سليم والنسخة الاحتياطية موجودة
    var BAD = { 'JSON تالف': '{bad json', 'schemaVersion أحدث': JSON.stringify({ schemaVersion: 7, classId: DEMO, records: [] }), 'بنية غير صالحة': JSON.stringify([1, 2]) };
    for (var label in BAD) {
      var key = 'marsa.academic.' + ty + '.' + DEMO, ex = {}; ex[key] = BAD[label];
      c = await open(browser, { label: 'bad-' + ty, init: seedScript(Object.assign({}, EMPTY, ex)) }); page = c.page;
      await toRep(page); await nav(page, f.nav);
      body = await pageText(page);
      var dis = await page.$$eval('#v-page button', function (bs) { return bs.filter(function (b) { return /^إضافة/.test(b.textContent.trim()); }).every(function (b) { return b.disabled; }); });
      check(label + ' ' + ty + ': رسالة خطأ واضحة وأزرار الإضافة معطّلة', /تالفة|أحدث|غير صالح|غير مدعوم/.test(body) && dis, body.slice(0, 160));
      check(label + ' ' + ty + ': الخام لم يُستبدل ولم يُحذف', (await raw(page, key)) === BAD[label]);
      check(label + ' ' + ty + ': نسخة خام احتياطية موجودة', (await keys(page)).some(function (k) { return k.indexOf(key + '.backup') === 0; }));
      await toStudent(page);
      var sl = { dailyLessons: 'الأرشيف', preparations: 'التحاضير', schedule: 'الجدول', exams: 'الامتحانات' }[ty];
      await nav(page, sl); body = await pageText(page);
      check(label + ' ' + ty + ': عرض الطالب يُظهر الخطأ ولا يدّعي أن الصف فارغ', /تعذّرت|تالفة|أحدث|غير صالح|غير مدعوم|لا يمكن/.test(body), body.slice(0, 200));
      await c.ctx.close();
    }
  }

  // ===== 5) إدخال HTML/JavaScript يُعرض نصاً فقط في صفحات الممثل والطالب
  var XSS = '<img src=x onerror="window.__xss=1"><script>window.__xss=1</script>', xmap = fullSeed(), xd = data(DEMO, 'AAA');
  xd.dailyLessons[0].title = XSS + 'درس-AAA'; xd.preparations[0].title = XSS + 'تحضير-AAA'; xd.schedule[0].subject = XSS + 'حصة-AAA'; xd.exams[0].title = XSS + 'امتحان-AAA';
  xd.exams[0].topics = XSS;
  ['dailyLessons', 'preparations', 'schedule', 'exams'].forEach(function (t2) { xmap['marsa.academic.' + t2 + '.' + DEMO] = col(DEMO, xd[t2]); });
  c = await open(browser, { label: 'xss', init: seedScript(xmap) }); page = c.page;
  await toRep(page);
  for (i = 0; i < REP.length; i++) {
    await nav(page, REP[i][1]);
    check('XSS rep ' + REP[i][0] + ': لا عناصر img/script أُنشئت ويُعرض النص حرفياً', (await page.$$('#v-page img, #v-page script')).length === 0 && (await pageText(page)).indexOf('<img') > -1);
  }
  await toStudent(page);
  for (i = 0; i < STU.length; i++) {
    await nav(page, STU[i][0]);
    check('XSS student ' + STU[i][0] + ': لا عناصر img/script', (await page.$$('#v-page img, #v-page script')).length === 0);
  }
  await nav(page, 'الرئيسية');
  check('XSS الرئيسية: لا عناصر img/script', (await page.$$('#v-home img, #v-home script')).length === 0);
  check('XSS: لم يُنفَّذ أي سكربت', (await page.evaluate(function () { return window.__xss; })) === undefined);
  await c.ctx.close();

  await browser.close();
  var failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed; JS errors: ' + jsErrors.length);
  jsErrors.forEach(function (e) { console.log('JSERR ' + e); });
  process.exit(failed.length || jsErrors.length ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
