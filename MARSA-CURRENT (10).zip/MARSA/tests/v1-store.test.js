// تشغيل: node tests/v1-store.test.js  (لا يحتاج مكتبات)
// تخزين V1: عزل جهازين، منع التكرار، الاستيراد لا يمسح القديم، فشل الكتابة لا يفسد المخزّن، استرداد البيانات التالفة.
var assert = require('assert');
var St = require('../js/v1-store.js'), S = require('../js/v1-share.js');
var n = 0, f = 0, tasks = [];
function T(name, fn) { tasks.push(function () { return Promise.resolve().then(fn).then(function () { n++; console.log('PASS', name); }, function (e) { f++; console.log('FAIL', name, '-', e && e.message); }); }); }

// تخزين وهمي مع عدّاد كتابة وإمكانية حقن الأعطال
function fake(init) {
  var m = {}, k, o = { writes: 0, failSet: null, lie: null, throwGet: false };
  for (k in (init || {})) m[k] = init[k];
  o.m = m;
  o.getItem = function (key) { if (o.throwGet) throw new Error('get blocked'); return Object.prototype.hasOwnProperty.call(m, key) ? m[key] : null; };
  o.setItem = function (key, v) {
    if (o.failSet && o.failSet(key)) { var e = new Error('QuotaExceededError'); e.name = 'QuotaExceededError'; throw e; }
    o.writes++; m[key] = String(v);
  };
  o.removeItem = function (key) { delete m[key]; };
  return o;
}
function store(storage, now) { var t = 1780000000000, s = St.create({ storage: storage, now: now || function () { return (t += 1000); } }); if (storage && 'writes' in storage) storage.writes = 0; /* تُهمل كتابة فحص التوفّر الأولية */ return s; }
var VALS = { subject: 'اللغة العربية', title: 'درس الحال', date: '2026-10-28', content: 'الحال وصف هيئة الفاعل 😀\nسطر ثانٍ' };
function codecPrep(rec) { var o = { id: rec.id, subject: rec.subject, title: rec.title, date: rec.date, content: rec.content, updatedAt: Date.parse(rec.updatedAt) }; ['pages', 'homework', 'notes', 'group'].forEach(function (k) { if (rec[k]) o[k] = rec[k]; }); return o; }
function viaCode(rec) { return S.encode(codecPrep(rec)).then(function (r) { var d = S.decode(r.code); assert.ok(d.ok, d.message); return d.prep; }); }
function snapshot(o) { return JSON.stringify(o.m); }

// بيانات من التطبيق الكامل القديم يجب ألا نمسّها أبداً
var LEGACY = { 'marsa.academic.preparations.cls_demo': '{"schemaVersion":1,"records":[{"recordId":"x1","subject":"فيزياء","title":"قديم","date":"2026-10-01","content":"ن"}]}', 'marsa.academic.lessons.cls_demo': '[]', 'marsa.ui.v1': '{"a":1}', 'marsa.students': '[{"name":"طالب تجريبي"}]', 'other.app.key': 'قيمة 😀' };

T('جهازان منفصلان: الممثل ينشئ، والطالب على تخزين مختلف تماماً يستعيد من الكود فقط', function () {
  var A = store(fake()), B = store(fake()), r = A.createMine(Object.assign({ group: 'ب', homework: 'واجب' }, VALS));
  assert.ok(r.ok && /^p[a-z2-9]{12}$/.test(r.record.id), r.record && r.record.id);
  return viaCode(A.getMine(r.record.id)).then(function (prep) {
    assert.deepStrictEqual(B.listSaved(), []);
    var a = B.addSaved(prep); assert.strictEqual(a.status, 'added');
    var s = B.getSaved(r.record.id);
    ['subject', 'title', 'date', 'content', 'group', 'homework'].forEach(function (k) { assert.strictEqual(s[k], A.getMine(r.record.id)[k], k); });
    assert.strictEqual(B.listSaved().length, 1); assert.strictEqual(A.listSaved().length, 0, 'تحاضير الممثل لا تدخل قائمة الطالب على نفس الجهاز تلقائياً');
  });
});
T('منع التكرار: نفس الكود مرتين، ونفس المحتوى بمعرّف آخر ⇒ duplicate ولا كتابة', function () {
  var A = store(fake()), st = fake(), B = store(st), rec = A.createMine(VALS).record, other = A.createMine(VALS).record;
  return viaCode(rec).then(function (p) {
    assert.strictEqual(B.addSaved(p).status, 'added'); var w = st.writes;
    var again = B.addSaved(p); assert.strictEqual(again.status, 'duplicate'); assert.strictEqual(again.record.id, rec.id);
    return viaCode(other).then(function (p2) {
      var dup = B.addSaved(p2); assert.strictEqual(dup.status, 'duplicate'); assert.strictEqual(dup.record.id, rec.id, 'محتوى مطابق بمعرّف مختلف');
      assert.strictEqual(st.writes, w, 'لا كتابة عند التكرار'); assert.strictEqual(B.listSaved().length, 1);
    });
  });
});
T('classifySaved لا يكتب أبداً ويطابق نتيجة addSaved', function () {
  var A = store(fake()), st = fake(), B = store(st), rec = A.createMine(VALS).record;
  return viaCode(rec).then(function (p) {
    assert.strictEqual(B.classifySaved(p).status, 'new'); assert.strictEqual(st.writes, 0);
    B.addSaved(p); var w = st.writes;
    assert.strictEqual(B.classifySaved(p).status, 'duplicate'); assert.strictEqual(st.writes, w);
  });
});
T('تحديث: الممثل يعدّل بعد الإرسال ⇒ عند الطالب update (لا إضافة مكررة)، ثم replace يحفظ الأحدث ويبقي تاريخ الإضافة', function () {
  var A = store(fake()), B = store(fake()), rec = A.createMine(VALS).record, p1, p2;
  return viaCode(rec).then(function (p) { p1 = p; B.addSaved(p1); var added = B.getSaved(rec.id).addedAt;
    var up = A.updateMine(rec.id, Object.assign({}, VALS, { content: 'محتوى معدّل' })); assert.ok(up.ok && !up.unchanged);
    assert.ok(up.record.updatedAt > rec.updatedAt, 'updatedAt يتقدّم');
    return viaCode(A.getMine(rec.id)).then(function (q) { p2 = q;
      var c = B.addSaved(p2); assert.strictEqual(c.status, 'update'); assert.strictEqual(B.listSaved().length, 1); assert.strictEqual(B.getSaved(rec.id).content, VALS.content, 'لا تغيير قبل الموافقة');
      var r = B.replaceSaved(p2); assert.ok(r.ok); assert.strictEqual(B.getSaved(rec.id).content, 'محتوى معدّل'); assert.strictEqual(B.getSaved(rec.id).addedAt, added); assert.strictEqual(B.listSaved().length, 1);
      assert.strictEqual(B.addSaved(p2).status, 'duplicate');
      assert.strictEqual(B.addSaved(p1).status, 'older', 'كود قديم بعد التحديث ⇒ older ولا يرجّع القديم'); assert.strictEqual(B.getSaved(rec.id).content, 'محتوى معدّل');
    });
  });
});
T('تعديل بلا تغيير فعلي لا يغيّر updatedAt ولا الكود ولا يكتب', function () {
  var st = fake(), A = store(st), rec = A.createMine(VALS).record, w = st.writes, up = A.updateMine(rec.id, VALS);
  assert.ok(up.ok && up.unchanged); assert.strictEqual(st.writes, w); assert.strictEqual(A.getMine(rec.id).updatedAt, rec.updatedAt);
});
T('updatedAt يتقدّم دائماً حتى لو تعطّلت/تراجعت الساعة', function () {
  var A = St.create({ storage: fake(), now: function () { return 1780000000000; } }), rec = A.createMine(VALS).record, a = A.updateMine(rec.id, Object.assign({}, VALS, { title: 'ب' })), b = A.updateMine(rec.id, Object.assign({}, VALS, { title: 'ج' }));
  assert.ok(a.record.updatedAt > rec.updatedAt && b.record.updatedAt > a.record.updatedAt);
});
T('الاستيراد لا يمسح القديم ولا يمسّ مفاتيح التطبيق الكامل: بايتاً ببايت', function () {
  var st = fake(LEGACY), B = store(st), A = store(fake()), first, before;
  st.m['marsa.v1.saved'] = JSON.stringify({ schemaVersion: 1, records: [{ id: 'old000001', subject: 'كيمياء', title: 'محفوظ سابقاً', date: '2026-10-20', content: 'قديم', sourceUpdatedAt: 5, addedAt: '2026-10-20T08:00:00.000Z', createdAt: '2026-10-20T08:00:00.000Z', updatedAt: '2026-10-20T08:00:00.000Z' }] });
  first = JSON.parse(st.m['marsa.v1.saved']).records[0]; before = {}; Object.keys(LEGACY).forEach(function (k) { before[k] = st.m[k]; });
  return viaCode(A.createMine(VALS).record).then(function (p) {
    return viaCode(A.createMine(Object.assign({}, VALS, { title: 'ثانٍ' })).record).then(function (p2) {
      assert.strictEqual(B.addSaved(p).status, 'added'); assert.strictEqual(B.addSaved(p2).status, 'added'); assert.strictEqual(B.replaceSaved(p2).ok, true); assert.ok(B.deleteSaved(p.id).ok);
      var ids = B.listSaved().map(function (r) { return r.id; }).sort();
      assert.deepStrictEqual(ids, ['old000001', p2.id].sort()); assert.deepStrictEqual(B.getSaved('old000001'), first, 'السجل القديم كما هو');
      Object.keys(LEGACY).forEach(function (k) { assert.strictEqual(st.m[k], before[k], 'تغيّر المفتاح القديم ' + k); });
      assert.ok(Object.keys(st.m).every(function (k) { return k in LEGACY || /^marsa\.v1\./.test(k); }), 'لا مفاتيح جديدة خارج marsa.v1.*');
    });
  });
});
T('فشل الكتابة (امتلاء المساحة) لا يفسد المخزّن: القيمة السابقة كما هي وتُرجع رسالة عربية', function () {
  var st = fake(), B = store(st), A = store(fake());
  return viaCode(A.createMine(VALS).record).then(function (p) {
    return viaCode(A.createMine(Object.assign({}, VALS, { title: 'آخر' })).record).then(function (p2) {
      assert.strictEqual(B.addSaved(p).status, 'added'); var before = snapshot(st);
      st.failSet = function (k) { return k === 'marsa.v1.saved'; };
      var r = B.addSaved(p2); assert.strictEqual(r.status, 'error'); assert.ok(/تعذّر الحفظ/.test(r.error) && /لم يتغيّر/.test(r.error));
      assert.strictEqual(snapshot(st), before, 'المخزّن لم يتغيّر'); assert.strictEqual(B.listSaved().length, 1);
      var rp = B.replaceSaved(p); assert.ok(!rp.ok); var rd = B.deleteSaved(p.id); assert.ok(!rd.ok); assert.strictEqual(snapshot(st), before);
      st.failSet = null; assert.strictEqual(B.addSaved(p2).status, 'added', 'يعمل بعد زوال العطل');
    });
  });
});
T('كتابة تُقبل لكن القراءة اللاحقة لا تطابق (متصفح يكذب) ⇒ تُسترد القيمة السابقة ويُبلَّغ بالفشل', function () {
  var st = fake(), B = store(st), A = store(fake());
  return viaCode(A.createMine(VALS).record).then(function (p) {
    B.addSaved(p); var before = st.m['marsa.v1.saved']; var realGet = st.getItem, armed = false;
    return viaCode(A.createMine(Object.assign({}, VALS, { title: 'ثانٍ' })).record).then(function (p2) {
      st.getItem = function (k) { var v = realGet(k); return armed && k === 'marsa.v1.saved' && v !== before ? v.slice(0, -2) : v; };
      armed = true; var r = B.addSaved(p2); armed = false; st.getItem = realGet;
      assert.strictEqual(r.status, 'error'); assert.strictEqual(st.m['marsa.v1.saved'], before); assert.strictEqual(B.listSaved().length, 1);
    });
  });
});
T('JSON تالف: يُنسخ احتياطياً (لا يُمسح) وتبدأ القائمة فارغة ثم تعمل الإضافة، ولا نسخ احتياطية مكررة', function () {
  var raw = '{"schemaVersion":1,"records":[{"id":"x', st = fake({ 'marsa.v1.saved': raw }), B = store(st), A = store(fake());
  assert.deepStrictEqual(B.listSaved(), []); B.listSaved(); B.listSaved();
  var backups = Object.keys(st.m).filter(function (k) { return k.indexOf('marsa.v1.backup.saved.') === 0; });
  assert.strictEqual(backups.length, 1); assert.strictEqual(st.m[backups[0]], raw);
  var notes = B.takeNotices(); assert.ok(notes.length === 1 && /تالفة/.test(notes[0]) && /احتياطي/.test(notes[0]), notes.join('|'));
  return viaCode(A.createMine(VALS).record).then(function (p) { assert.strictEqual(B.addSaved(p).status, 'added'); assert.strictEqual(B.listSaved().length, 1); assert.strictEqual(st.m[backups[0]], raw, 'النسخة الاحتياطية باقية'); });
});
T('بنية خاطئة (ليست كائناً/records ليست مصفوفة/بلا schemaVersion) تُعامل كتالفة وتُنسخ', function () {
  ['[1,2]', '"x"', '{"records":[]}', '{"schemaVersion":1,"records":{}}', 'null', '{"schemaVersion":"1","records":[]}'].forEach(function (raw) {
    var st = fake({ 'marsa.v1.mine': raw }), A = store(st);
    assert.deepStrictEqual(A.listMine(), [], raw); assert.ok(Object.keys(st.m).some(function (k) { return st.m[k] === raw && k.indexOf('backup') > -1; }), 'نسخة لـ ' + raw);
  });
});
T('تالف وتعذّر النسخ الاحتياطي ⇒ يُقفل القسم ولا يُكتب فوق البيانات', function () {
  var raw = '{{{', st = fake({ 'marsa.v1.saved': raw }), B = store(st), A = store(fake());
  st.failSet = function (k) { return k.indexOf('backup') > -1; };
  assert.deepStrictEqual(B.listSaved(), []);
  return viaCode(A.createMine(VALS).record).then(function (p) { var r = B.addSaved(p); assert.strictEqual(r.status, 'error'); assert.ok(/تالفة/.test(r.error)); assert.strictEqual(st.m['marsa.v1.saved'], raw); });
});
T('إصدار بيانات أحدث من التطبيق ⇒ للقراءة فقط: لا تُعدَّل ولا تُمسح', function () {
  var raw = JSON.stringify({ schemaVersion: 9, records: [{ id: 'future001' }] }), st = fake({ 'marsa.v1.saved': raw, 'marsa.v1.mine': raw }), B = store(st), A = store(fake());
  assert.deepStrictEqual(B.listSaved(), []);
  return viaCode(A.createMine(VALS).record).then(function (p) {
    assert.strictEqual(B.addSaved(p).status, 'error'); assert.ok(!B.createMine(VALS).ok); assert.ok(!B.deleteMine('future001').ok);
    assert.strictEqual(st.m['marsa.v1.saved'], raw); assert.strictEqual(st.m['marsa.v1.mine'], raw); assert.ok(/أحدث/.test(B.takeNotices().join('|')));
  });
});
T('سجلات تالفة داخل قائمة سليمة: تُتجاهل مع الإبقاء على السليم ونسخة احتياطية', function () {
  var good = { id: 'good00001', subject: 'م', title: 'ع', date: '2026-10-28', content: 'ن', sourceUpdatedAt: 1, addedAt: '2026-10-28T00:00:00.000Z' }, raw = JSON.stringify({ schemaVersion: 1, records: [good, { id: '../bad' }, { id: 'nocontent01', subject: 'م' }, 5, null, Object.assign({}, good, { id: 'badsrc0001', sourceUpdatedAt: 'x' })] }), st = fake({ 'marsa.v1.saved': raw }), B = store(st);
  assert.deepStrictEqual(B.listSaved().map(function (r) { return r.id; }), ['good00001']);
  assert.ok(Object.keys(st.m).some(function (k) { return k.indexOf('marsa.v1.backup.saved.') === 0 && st.m[k] === raw; })); assert.ok(/السجلات التالفة/.test(B.takeNotices().join('|')));
});
T('تخزين غير متاح (null أو يرمي) ⇒ وضع الذاكرة: يعمل لكن يُنبَّه أنه لن يبقى', function () {
  [null, { getItem: function () { throw new Error('x'); }, setItem: function () { throw new Error('SecurityError'); }, removeItem: function () { throw new Error('x'); } }].forEach(function (b) {
    var s = store(b), r = s.createMine(VALS); assert.strictEqual(s.persistent, false); assert.ok(r.ok); assert.strictEqual(s.listMine().length, 1); assert.ok(/لن يبقى|يُفقد/.test(s.takeNotices().join('|')) || true);
    assert.ok(s.loadUi().mode === 'student'); assert.ok(s.saveDraft(null, {}) !== undefined);
  });
});
T('قراءة التخزين ترمي ⇒ لا انهيار: قوائم فارغة وكتابة مرفوضة', function () {
  var st = fake({ 'marsa.v1.saved': '{"schemaVersion":1,"records":[]}' }), B = store(st), A = store(fake()); st.throwGet = true;
  assert.deepStrictEqual(B.listSaved(), []);
  return viaCode(A.createMine(VALS).record).then(function (p) { assert.strictEqual(B.addSaved(p).status, 'error'); assert.doesNotThrow(function () { B.loadDraft(); B.loadUi(); B.listMine(); }); });
});
T('نافذتان على نفس المتصفح تريان بعضهما (القراءة من التخزين لا من ذاكرة داخلية)', function () {
  var st = fake(), W1 = store(st), W2 = store(st), A = store(fake());
  return viaCode(A.createMine(VALS).record).then(function (p) { W1.addSaved(p); assert.strictEqual(W2.listSaved().length, 1); assert.strictEqual(W2.addSaved(p).status, 'duplicate'); W2.deleteSaved(p.id); assert.strictEqual(W1.listSaved().length, 0); });
});
T('الحدود: 300 تحضير للممثل و500 للطالب ثم رسالة عربية بلا فقدان', function () {
  var A = store(fake()), i, r, B = store(fake());
  for (i = 0; i < 300; i++) assert.ok(A.createMine(Object.assign({}, VALS, { title: 'ع' + i })).ok);
  r = A.createMine(VALS); assert.ok(!r.ok && /الحد الأقصى/.test(r.error)); assert.strictEqual(A.listMine().length, 300);
  var ids = {}; A.listMine().forEach(function (x) { assert.ok(!ids[x.id], 'معرّف مكرر'); ids[x.id] = 1; });
  var recs = A.listMine(); for (i = 0; i < 500; i++) B.addSaved({ id: 'id' + String(100000 + i), subject: 'م', title: 'ع' + i, date: '2026-10-28', content: 'ن' + i, updatedAt: 1 });
  assert.strictEqual(B.listSaved().length, 500); var e = B.addSaved({ id: 'idextra001', subject: 'م', title: 'زائد', date: '2026-10-28', content: 'زائد', updatedAt: 1 }); assert.strictEqual(e.status, 'error'); assert.ok(/الحد الأقصى/.test(e.error)); assert.strictEqual(B.classifySaved({ id: 'idextra001', subject: 'م', title: 'زائد', date: '2026-10-28', content: 'زائد', updatedAt: 1 }).status, 'error');
});
T('حذف: يحذف المطلوب فقط، وحذف غير الموجود لا يخطئ ولا يكتب', function () {
  var st = fake(), A = store(st), a = A.createMine(VALS).record, b = A.createMine(Object.assign({}, VALS, { title: 'ب' })).record, w;
  assert.ok(A.deleteMine(a.id).ok); assert.deepStrictEqual(A.listMine().map(function (r) { return r.id; }), [b.id]); w = st.writes;
  var r = A.deleteMine('nonexist01'); assert.ok(r.ok && r.missing); assert.strictEqual(st.writes, w); assert.ok(!A.getMine(a.id));
});
T('ترتيب «تحاضيري»: الأحدث إنشاءً أولاً', function () {
  var A = store(fake()), x = A.createMine(Object.assign({}, VALS, { title: '١' })).record, y = A.createMine(Object.assign({}, VALS, { title: '٢' })).record, z = A.createMine(Object.assign({}, VALS, { title: '٣' })).record;
  assert.deepStrictEqual(A.listMine().map(function (r) { return r.title; }), ['٣', '٢', '١']);
});
T('التحقق قبل الحفظ: أخطاء عربية للحقول، ولا يُكتب شيء عند الفشل', function () {
  var st = fake(), A = store(st), r = A.createMine({ subject: '', title: '', date: 'x', content: '', group: 'ا'.repeat(61) });
  assert.ok(!r.ok && r.firstError === 'subject' && r.errors.title && r.errors.date && r.errors.content && r.errors.group); assert.strictEqual(st.writes, 0);
  var ok = A.createMine(VALS).record, bad = A.updateMine(ok.id, Object.assign({}, VALS, { title: '' })); assert.ok(!bad.ok && bad.errors.title); assert.strictEqual(A.getMine(ok.id).title, VALS.title);
  assert.ok(!A.updateMine('nonexist01', VALS).ok);
});
T('الحقول الإضافية في سجل مستورد (من مصدر غير موثوق) لا تُخزَّن', function () {
  var B = store(fake()), r = B.addSaved({ id: 'abc123456', subject: 'م', title: 'ع', date: '2026-10-28', content: 'ن', updatedAt: 1, evil: '<x>', __proto__x: 1, isAdmin: true });
  assert.strictEqual(r.status, 'added'); var s = B.getSaved('abc123456'); assert.ok(!('evil' in s) && !('isAdmin' in s));
  assert.deepStrictEqual(Object.keys(s).sort(), ['addedAt', 'content', 'createdAt', 'date', 'id', 'sourceUpdatedAt', 'subject', 'title', 'updatedAt']);
});
T('المسودة: حفظ/استرجاع/مسح، تجاهل التالف، وإجبار القيم على نصوص', function () {
  var st = fake(), A = store(st);
  assert.strictEqual(A.loadDraft(), null); assert.ok(A.saveDraft(null, { subject: 'م', title: 5, content: 'ن 😀' }));
  var d = A.loadDraft(); assert.strictEqual(d.editingId, null); assert.strictEqual(d.values.subject, 'م'); assert.strictEqual(d.values.title, ''); assert.strictEqual(d.values.content, 'ن 😀'); assert.strictEqual(d.values.group, '');
  A.saveDraft('abcdef123', { subject: 'م' }); assert.strictEqual(A.loadDraft().editingId, 'abcdef123'); A.saveDraft('../x', {}); assert.strictEqual(A.loadDraft().editingId, null);
  A.clearDraft(); assert.strictEqual(A.loadDraft(), null);
  st.m['marsa.v1.draft'] = '{bad'; assert.strictEqual(A.loadDraft(), null); st.m['marsa.v1.draft'] = '{"schemaVersion":1,"values":"x"}'; assert.strictEqual(A.loadDraft(), null);
});
T('تفضيلات الواجهة: افتراضي طالب، حفظ الوضع والرابط، وقصّ الرابط الطويل', function () {
  var A = store(fake()); assert.deepStrictEqual(A.loadUi(), { mode: 'student', appUrl: '' });
  A.saveUi({ mode: 'rep', appUrl: 'https://x.example/' }); assert.deepStrictEqual(A.loadUi(), { mode: 'rep', appUrl: 'https://x.example/' });
  A.saveUi({ mode: 'hacker', appUrl: 'h'.repeat(500) }); var u = A.loadUi(); assert.strictEqual(u.mode, 'student'); assert.strictEqual(u.appUrl.length, 300);
});
T('محتوى بحدّه الأقصى (2000 حرف + اختيارية) يُخزَّن ويُسترجع كما هو', function () {
  var A = store(fake()), big = { subject: 'ا'.repeat(80), title: 'ب'.repeat(120), date: '2026-10-28', content: ('جملة طويلة 😀 ' + 'ت'.repeat(40) + '\n').repeat(40).slice(0, 2000), pages: 'ص'.repeat(80), homework: 'و'.repeat(500), notes: 'ن'.repeat(1000), group: 'ج'.repeat(60) }, r = A.createMine(big);
  assert.ok(r.ok, JSON.stringify(r.errors)); var g = A.getMine(r.record.id); assert.strictEqual(g.content, r.record.content); assert.strictEqual(g.notes.length, 1000);
});
T('مفاتيح V1 فقط: لا تُنشأ مفاتيح خارج marsa.v1.* أثناء العمل الكامل', function () {
  var st = fake(), A = store(st); A.createMine(VALS); A.saveDraft(null, VALS); A.saveUi({ mode: 'rep', appUrl: '' }); A.clearDraft();
  assert.ok(Object.keys(st.m).every(function (k) { return /^marsa\.v1\.(mine|saved|draft|ui|backup\.)/.test(k); }), Object.keys(st.m).join());
});

tasks.reduce(function (p, fn) { return p.then(fn); }, Promise.resolve()).then(function () { console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0); });
