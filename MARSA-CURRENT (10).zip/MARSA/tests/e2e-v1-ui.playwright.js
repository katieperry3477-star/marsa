// اختبار واجهة 01.03 بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-v1-ui.playwright.js
// لقطات الشاشة (اختيارية): MARSA_SHOTS=1 (بعد الفحوص) أو MARSA_SHOTS_ONLY=1 (اللقطات وحدها) NODE_PATH=$(npm root -g) node tests/e2e-v1-ui.playwright.js  ← تُكتب في docs/phase1/01.03-shots/
// يغطي معايير 01.03: الانترو، الترحيب، الرئيسية، اليوم/باچر، الامتحان، المظهر الثلاثي، وسم الدور، عزل البيانات التجريبية،
// RTL والتجاوب وأهداف اللمس والتباين والتركيز، غياب الشبكة وإدراج HTML، وحقن أعطال التخزين. بيانات اصطناعية فقط ولا اتصال خارجي.
var pw = require('playwright'), path = require('path'), http = require('http'), fs = require('fs');
var ROOT = path.resolve(__dirname, '..'), D = require('../js/v1-demo.js');
var results = [], jsErrors = [], allRequests = [], BASE = '', server, innerTotal = 0, pagesOpened = 0;
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z'; // الخميس 2026-10-22 الساعة 09:00 بتوقيت بغداد (يوم دراسة)
var TODAY = '2026-10-22', TOMORROW = '2026-10-23'; // باچر = الجمعة (لا دروس)
var ROLE_WARN = 'تبديل الدور تجريبي وغير آمن للإنتاج';

// ===== بيانات اصطناعية =====
function uiSeed(o) { return JSON.stringify(Object.assign({ schemaVersion: 1, mode: 'student', appUrl: '', welcomed: true }, o || {})); }
var DEMO = D.build(TODAY), DEMO_JSON = JSON.stringify(DEMO);
var SAVED_SEED = JSON.stringify({ schemaVersion: 1, records: [
  { id: 'sav000001', subject: 'الكيمياء', title: 'تحضير اليوم المحفوظ', date: TODAY, content: 'محتوى تحضير اليوم المحفوظ', homework: 'حل التمرين ٥ ص ٢٠', sourceUpdatedAt: 5, addedAt: '2026-10-21T08:00:00.000Z', createdAt: '2026-10-21T08:00:00.000Z', updatedAt: '2026-10-21T08:00:00.000Z' },
  { id: 'sav000002', subject: 'الفيزياء', title: 'تحضير باچر المحفوظ', date: TOMORROW, content: 'محتوى تحضير باچر', sourceUpdatedAt: 6, addedAt: '2026-10-21T08:00:00.000Z', createdAt: '2026-10-21T08:00:00.000Z', updatedAt: '2026-10-21T08:00:00.000Z' }] });
var MINE_SEED = JSON.stringify({ schemaVersion: 1, records: [
  { id: 'min000001', subject: 'الأحياء', title: 'تحضير الممثل اليوم', date: TODAY, content: 'محتوى تحضير الممثل', homework: 'واجب الأحياء', createdAt: '2026-10-21T09:00:00.000Z', updatedAt: '2026-10-21T09:00:00.000Z' }] });
var LEGACY = { 'marsa.academic.preparations.cls_demo': '{"schemaVersion":1,"records":[{"recordId":"x1","subject":"فيزياء","title":"تحضير قديم","date":"2026-10-01","content":"ن"}]}', 'marsa.students': '[{"name":"طالب تجريبي"}]', 'marsa.ui.v1': '{"a":1}', 'other.app.key': 'قيمة 😀' };
function fullSeed(extra) { var s = Object.assign({}, LEGACY, { 'marsa.v1.ui': uiSeed(), 'marsa.v1.saved': SAVED_SEED, 'marsa.v1.mine': MINE_SEED }); return Object.assign(s, extra || {}); }

// ===== أدوات =====
function serve() {
  var types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.md': 'text/markdown; charset=utf-8' };
  return new Promise(function (resolve) {
    server = http.createServer(function (req, res) {
      var p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
      var file = path.join(ROOT, p);
      if (file.indexOf(ROOT) !== 0 || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
      res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' }); fs.createReadStream(file).pipe(res);
    }).listen(0, '127.0.0.1', function () { BASE = 'http://localhost:' + server.address().port; resolve(); });
  });
}
// مجسّات تُحقن قبل أي سكربت: مراقب الانترو (توقيت data-intro) وعدّاد innerHTML (يجب أن يبقى صفراً) ودوال التباين
function probes() {
  window.__intro = { on: null, off: null }; window.__inner = 0;
  new MutationObserver(function () {
    var v = document.documentElement.getAttribute('data-intro');
    if (v === 'on' && window.__intro.on === null) window.__intro.on = performance.now();
    if (v === null && window.__intro.on !== null && window.__intro.off === null) window.__intro.off = performance.now();
  }).observe(document, { subtree: true, attributes: true, attributeFilter: ['data-intro'] });
  try {
    var d = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
    Object.defineProperty(Element.prototype, 'innerHTML', { configurable: true, get: d.get, set: function (v) { window.__inner++; return d.set.call(this, v); } });
  } catch (e) { /* لا شيء */ }
  window.__cx = (function () {
    function parse(s) { var m = /rgba?\(([^)]+)\)/.exec(s || ''), p; if (!m) return null; p = m[1].split(/[,\s\/]+/).filter(Boolean).map(parseFloat); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; }
    function over(f, b) { var a = f.a; return { r: f.r * a + b.r * (1 - a), g: f.g * a + b.g * (1 - a), b: f.b * a + b.b * (1 - a), a: 1 }; }
    function lum(c) { function ch(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); } return 0.2126 * ch(c.r) + 0.7152 * ch(c.g) + 0.0722 * ch(c.b); }
    function ratio(a, b) { var x = lum(a), y = lum(b), t; if (x < y) { t = x; x = y; y = t; } return (x + 0.05) / (y + 0.05); }
    function bgOf(el) { var chain = [], n = el, base = { r: 255, g: 255, b: 255, a: 1 }, i, c; while (n && n.nodeType === 1) { chain.push(n); n = n.parentElement; } for (i = chain.length - 1; i >= 0; i--) { c = parse(getComputedStyle(chain[i]).backgroundColor); if (c && c.a > 0) base = c.a >= 1 ? c : over(c, base); } return base; }
    function visible(el) { var r = el.getClientRects(); return r.length > 0 && r[0].width > 0 && r[0].height > 0 && getComputedStyle(el).visibility !== 'hidden'; }
    return {
      text: function (sels, min) {
        var bad = [], seen = 0;
        sels.forEach(function (sel) { Array.prototype.forEach.call(document.querySelectorAll(sel), function (el) {
          var fg, bg, r; if (!visible(el) || !el.textContent.trim()) return;
          bg = bgOf(el); fg = parse(getComputedStyle(el).color); if (!fg) return; if (fg.a < 1) fg = over(fg, bg);
          r = ratio(fg, bg); seen++; if (r < min) bad.push(sel + ' «' + el.textContent.trim().slice(0, 24) + '» ' + r.toFixed(2));
        }); });
        return { seen: seen, bad: bad };
      },
      border: function (sels, min) {
        var bad = [], seen = 0;
        sels.forEach(function (sel) { Array.prototype.forEach.call(document.querySelectorAll(sel), function (el) {
          var cs, bc, par, own, r1, r2; if (!visible(el)) return;
          cs = getComputedStyle(el); bc = parse(cs.borderTopColor); if (!bc || parseFloat(cs.borderTopWidth) < 1) { bad.push(sel + ' بلا حدّ'); return; }
          par = bgOf(el.parentElement); own = bgOf(el); r1 = ratio(bc, par); r2 = ratio(bc, own); seen++;
          if (Math.min(r1, r2) < min) bad.push(sel + ' ' + Math.min(r1, r2).toFixed(2));
        }); });
        return { seen: seen, bad: bad };
      },
      outline: function (el, min) {
        var cs = getComputedStyle(el), oc = parse(cs.outlineColor), bg = bgOf(el.parentElement || el);
        return { style: cs.outlineStyle, width: parseFloat(cs.outlineWidth), ratio: oc ? ratio(oc, bg) : 0, min: min };
      }
    };
  })();
}
async function open(browser, o) {
  o = o || {};
  var ctx = await browser.newContext({ viewport: o.viewport || { width: 390, height: 800 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', colorScheme: o.scheme || 'light', reducedMotion: o.reduced ? 'reduce' : 'no-preference', permissions: [] });
  await ctx.addInitScript(probes);
  if (o.seed) await ctx.addInitScript(function (seed) { try { if (!sessionStorage.getItem('seeded')) { Object.keys(seed).forEach(function (k) { localStorage.setItem(k, seed[k]); }); sessionStorage.setItem('seeded', '1'); } } catch (e) { /* لا شيء */ } }, o.seed);
  if (o.init) await ctx.addInitScript(o.init);
  var page = await ctx.newPage(), label = o.label || 'dev';
  pagesOpened++;
  page.on('pageerror', function (e) { jsErrors.push(label + ': ' + e.message); });
  if (!o.ignoreConsole) page.on('console', function (m) { if (m.type() === 'error') jsErrors.push(label + ' console: ' + m.text()); });
  page.on('request', function (r) { allRequests.push(label + ' ' + r.url()); });
  page.on('dialog', function (d) { jsErrors.push(label + ' unexpected dialog: ' + d.message()); d.dismiss(); });
  if (o.clock !== false) await page.clock.install({ time: new Date(o.clock || NOW) });
  if (o.route) await page.route(o.route.pattern, o.route.handler);
  await page.goto(o.url || (BASE + '/index.html' + (o.hash || '')));
  if (!o.keepIntro) { await page.waitForSelector('#app h1'); await skipIntro(page); }
  return { ctx: ctx, page: page };
}
async function skipIntro(page) {
  try { if (await page.$('#intro')) await page.click('#intro-skip', { timeout: 3000 }); } catch (e) { /* قد يكون زال وحده */ }
  await page.waitForSelector('#intro', { state: 'detached', timeout: 8000 });
}
async function done(c) { try { innerTotal += await c.page.evaluate(function () { return window.__inner || 0; }); } catch (e) { /* الصفحة أُغلقت */ } await c.ctx.close(); }
async function dump(page) { return page.evaluate(function () { var o = {}, i, k; for (i = 0; i < localStorage.length; i++) { k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; }); }
async function go(page, hash) { await page.goto(BASE + '/index.html' + hash); await page.waitForSelector('#app h1'); await page.evaluate(function () { return new Promise(function (r) { requestAnimationFrame(function () { setTimeout(r, 0); }); }); }); }
async function waitRoute(page, hashVal, h1Text) { await page.waitForFunction(function (a) { var h = document.querySelector('#app h1'); return location.hash === a.hash && h && (!a.h || h.textContent.trim() === a.h); }, { hash: hashVal, h: h1Text || '' }, { timeout: 8000 }); }
async function waitStatus(page) { await page.waitForFunction(function () { return document.getElementById('status').textContent.length > 0; }, null, { timeout: 5000 }); }
async function texts(page, sel) { return page.$$eval(sel, function (l) { return l.map(function (x) { return x.textContent.replace(/\s+/g, ' ').trim(); }); }); }
async function h1(page) { return (await page.textContent('#app h1')).trim(); }
async function hash(page) { return page.evaluate(function () { return location.hash; }); }
function sameDump(a, b, except) { var ks = Object.keys(a).filter(function (k) { return k !== except; }), i; for (i = 0; i < ks.length; i++) if (a[ks[i]] !== b[ks[i]]) return ks[i]; return ''; }
async function press(page, sel, key) { await page.focus(sel); await page.keyboard.press(key); }

// ================= الانترو (S00) =================
async function scenarioIntro(browser) {
  var c = await open(browser, { label: 'intro', clock: false, keepIntro: true, seed: { 'marsa.v1.ui': uiSeed() } }), p = c.page, st, info;
  await p.waitForSelector('html[data-intro="on"]');
  info = await p.evaluate(function () { var i = document.getElementById('intro'), b = document.getElementById('intro-skip'); return { role: i.getAttribute('role'), modal: i.getAttribute('aria-modal'), label: i.getAttribute('aria-label'), skip: b.textContent.trim(), focus: document.activeElement && document.activeElement.id, inert: ['.top', '#shell', '.foot'].map(function (s) { return document.querySelector(s).hasAttribute('inert'); }), logo: !!i.querySelector('.intro-logo use') }; });
  check('انترو: يظهر عند الفتح كحوار باسم «مَرسى» وفيه الشعار وزر «تخطّي» وعليه التركيز', info.role === 'dialog' && info.modal === 'true' && info.label === 'مَرسى' && info.skip === 'تخطّي' && info.focus === 'intro-skip' && info.logo, JSON.stringify(info));
  check('انترو: بقية الصفحة معطّلة (inert) أثناء ظهوره كي لا يصلها التركيز بلوحة المفاتيح', info.inert.every(Boolean), JSON.stringify(info.inert));
  check('انترو: لا يحوي نصاً غير الشعار والاسم وزر التخطّي (شعار فقط)', (await p.$$eval('#intro > *', function (l) { return l.map(function (x) { return x.className && x.className.baseVal !== undefined ? x.className.baseVal : x.className; }); })).join(',') === 'intro-logo,intro-name,intro-sub,intro-dots,intro-skip');
  var anims = await p.evaluate(function () { return document.getAnimations().filter(function (a) { return a.effect && a.effect.target && a.effect.target.closest && a.effect.target.closest('#intro'); }).length; });
  check('انترو: الحركة تعمل في الوضع العادي (شرط يجعل اختبار «بلا حركة» ذا معنى)', anims > 0, 'عدد الحركات ' + anims);
  await p.waitForSelector('#intro', { state: 'detached', timeout: 8000 });
  var t = await p.evaluate(function () { return window.__intro; }), dur = t.off - t.on;
  check('انترو: يزول وحده بعد ≈1.5 ثانية (ليس فورياً ولا عالقاً)', dur >= 1300 && dur <= 3500, 'المدة ' + Math.round(dur) + 'ms');
  st = await p.evaluate(function () { return { inert: ['.top', '#shell', '.foot'].map(function (s) { return document.querySelector(s).hasAttribute('inert') || document.querySelector(s).hasAttribute('aria-hidden'); }), attr: document.documentElement.hasAttribute('data-intro'), focus: document.activeElement && document.activeElement.tagName, el: !!document.getElementById('intro') }; });
  check('انترو: بعد زواله يُزال التعطيل وعلامة data-intro ويعود التركيز إلى عنوان الصفحة', !st.inert.some(Boolean) && !st.attr && st.focus === 'H1' && !st.el, JSON.stringify(st));
  // فتحان متتاليان: يظهر عند كل فتح، ويُتخطّى بالزر وباللمس وبـEscape
  var results3 = [];
  for (var how of ['button', 'overlay', 'escape']) {
    await p.reload(); await p.waitForSelector('html[data-intro="on"]');
    var seen = !!(await p.$('#intro')), t0 = Date.now();
    if (how === 'button') await p.click('#intro-skip'); else if (how === 'overlay') await p.mouse.click(195, 300); else await p.keyboard.press('Escape');
    await p.waitForSelector('#intro', { state: 'detached', timeout: 3000 });
    results3.push(how + ':' + seen + ':' + (Date.now() - t0 < 1200));
  }
  check('انترو: يظهر عند كل فتح (إعادة التحميل ثلاث مرات) ويُتخطّى بزر «تخطّي» وبلمس الشاشة وبمفتاح Escape قبل انتهاء المدة', results3.join('|') === 'button:true:true|overlay:true:true|escape:true:true', results3.join('|'));
  await p.goto(BASE + '/index.html#/settings'); await p.waitForSelector('#btn-demo');
  check('انترو: لا يعود عند التنقل داخل الصفحة (hashchange)، فقط عند فتحها', !(await p.$('#intro')) && !(await p.evaluate(function () { return document.documentElement.hasAttribute('data-intro'); })));
  await done(c);

  // بلا حركة مع prefers-reduced-motion
  var r = await open(browser, { label: 'intro-rm', clock: false, keepIntro: true, reduced: true, seed: { 'marsa.v1.ui': uiSeed() } }), q = r.page;
  await q.waitForSelector('html[data-intro="on"]');
  var rm = await q.evaluate(function () {
    var names = ['.intro-logo', '.intro-name', '.intro-dots i'].map(function (s) { return getComputedStyle(document.querySelector(s)).animationName; });
    var running = document.getAnimations().filter(function (a) { return a.effect && a.effect.target && a.effect.target.closest && a.effect.target.closest('#intro'); }).length;
    return { names: names, trans: getComputedStyle(document.getElementById('intro')).transitionDuration, running: running, matches: matchMedia('(prefers-reduced-motion: reduce)').matches };
  });
  check('انترو مع prefers-reduced-motion: لا حركة (animation-name هو none، ولا حركات جارية، والانتقال صفر)', rm.matches && rm.names.every(function (n) { return n === 'none'; }) && rm.running === 0 && /^0s$/.test(rm.trans), JSON.stringify(rm));
  var tr0 = Date.now(); await q.click('#intro-skip'); await q.waitForSelector('#intro', { state: 'detached', timeout: 3000 });
  var fadeSeen = await q.evaluate(function () { return !!document.querySelector('.intro.leave'); });
  check('انترو مع تقليل الحركة: التخطّي يزيله فوراً بلا تلاشٍ، ويبقى قابلاً للتخطي', Date.now() - tr0 < 700 && !fadeSeen, 'الزمن ' + (Date.now() - tr0));
  await q.reload(); await q.waitForSelector('html[data-intro="on"]'); await q.waitForSelector('#intro', { state: 'detached', timeout: 8000 });
  var tt = await q.evaluate(function () { return window.__intro; });
  check('انترو مع تقليل الحركة: يظهر ساكناً ≈1.5 ثانية ثم يزول وحده', tt.off - tt.on >= 1300 && tt.off - tt.on <= 3500, 'المدة ' + Math.round(tt.off - tt.on));
  await done(r);

  // الانترو مستقل عن بقية الملفات: لو فشل تحميل v1-app.js لا يبقى عالقاً
  var f = await open(browser, { label: 'intro-noapp', clock: false, keepIntro: true, ignoreConsole: true, route: { pattern: '**/js/v1-app.js', handler: function (rt) { rt.abort(); } } });
  await f.page.waitForSelector('#intro', { state: 'detached', timeout: 8000 }).then(function () { check('انترو: مستقل، لو تعطّل ملف التطبيق v1-app.js يزول ولا يحجب الصفحة', true); }, function () { check('انترو: مستقل، لو تعطّل ملف التطبيق v1-app.js يزول ولا يحجب الصفحة', false, 'بقي عالقاً'); });
  await done(f);
}

// ================= الترحيب (S01) واختيار الدور (S02) =================
async function scenarioWelcome(browser) {
  var c = await open(browser, { label: 'welcome' }), p = c.page, s, ui;
  check('ترحيب: أول فتح يحوّل إلى #/welcome ويعرض الشريحة 1 «ما هو مَرسى؟»', (await hash(p)) === '#/welcome' && (await h1(p)) === 'ما هو مَرسى؟' && /الشريحة 1 من 3/.test(await p.textContent('.step')));
  check('ترحيب: لا شريط تنقل ولا مبدّل دور ظاهر أثناء الترحيب', !(await p.isVisible('#nav')) && !(await p.isVisible('.seg')));
  await p.click('a.btn.primary'); await waitRoute(p, '#/welcome/2', 'التحضير بالكود عبر واتساب');
  check('ترحيب: «التالي» يعرض الشريحة 2 «التحضير بالكود عبر واتساب» ويظهر «السابق»', (await h1(p)) === 'التحضير بالكود عبر واتساب' && (await p.isVisible('a.btn:has-text("السابق")')));
  await p.click('a.btn:has-text("السابق")'); await waitRoute(p, '#/welcome', 'ما هو مَرسى؟');
  check('ترحيب: «السابق» يرجع إلى الشريحة 1', (await h1(p)) === 'ما هو مَرسى؟');
  await p.click('a.btn.primary'); await waitRoute(p, '#/welcome/2', 'التحضير بالكود عبر واتساب');
  await p.click('a.btn.primary'); await waitRoute(p, '#/welcome/3', 'بياناتك على جهازك');
  var body3 = await p.textContent('.w-body');
  check('ترحيب: الشريحة 3 «بياناتك على جهازك» تذكر أن الكود غير مشفّر ولا يُلغى ولا حسابات ولا مزامنة', (await h1(p)) === 'بياناتك على جهازك' && /غير مشفّر ولا يُلغى/.test(body3) && /لا حسابات ولا مزامنة ولا خادم/.test(body3), body3);
  check('ترحيب: الشريحة 3 تحوي زر «اختيار دوري» في آخرها بدل «التالي»', (await p.isVisible('a.btn.primary:has-text("اختيار دوري")')));
  await p.click('a.btn.primary:has-text("اختيار دوري")'); await waitRoute(p, '#/welcome/role', 'من أنت؟');
  var roleTxt = (await texts(p, '.rolebtn b')).join('|'), warn = await p.textContent('.welcome .note');
  check('ترحيب: اختيار الدور في الآخر بزرين «أنا طالب» و«أنا ممثل الصف» ووسم «تجريبي وغير آمن للإنتاج»', (await h1(p)) === 'من أنت؟' && roleTxt === 'أنا طالب|أنا ممثل الصف' && warn.indexOf(ROLE_WARN) > -1, roleTxt + ' / ' + warn);
  ui = JSON.parse((await dump(p))['marsa.v1.ui'] || '{}');
  check('ترحيب: لا يُسجَّل «تمّ الترحيب» قبل اختيار الدور', ui.welcomed !== true, JSON.stringify(ui));
  await p.goto(BASE + '/index.html#/welcome'); await p.waitForSelector('#app h1');
  await p.click('.w-top a.linkbtn'); await waitRoute(p, '#/welcome/role', 'من أنت؟');
  check('ترحيب: «تخطّي» من الشريحة يقفز إلى اختيار الدور (الدور لا يُتخطّى)', (await h1(p)) === 'من أنت؟');
  await p.click('button[data-role="rep"]'); await p.waitForSelector('.cards3');
  ui = JSON.parse((await dump(p))['marsa.v1.ui']);
  s = await p.evaluate(function () { return { mode: document.documentElement.getAttribute('data-mode'), hash: location.hash, status: document.getElementById('status').textContent }; });
  check('ترحيب: اختيار «ممثل الصف» يحفظ الدور وعلم «تمّ الترحيب» في marsa.v1.ui وينقل إلى الرئيسية بأدوات الممثل', ui.mode === 'rep' && ui.welcomed === true && s.mode === 'rep' && (await texts(p, 'a.tile b')).join('|') === 'إنشاء تحضير|تحاضير أنشأتها', JSON.stringify(ui) + JSON.stringify(s));
  check('ترحيب: الانتقال إلى الرئيسية يستبدل مدخل التاريخ (لا يعود زر الرجوع إلى اختيار الدور)', s.hash === '#/' || s.hash === '');
  // فتحان متتاليان: لا يعود الترحيب
  await p.reload(); await skipIntro(p); await p.waitForSelector('#app h1');
  var second = { h: await h1(p), welcome: !!(await p.$('.welcome')), mode: await p.getAttribute('html', 'data-mode') };
  var p2 = await c.ctx.newPage(); await p2.goto(BASE + '/index.html'); await p2.waitForSelector('#app h1'); await skipIntro(p2);
  var third = { h: await h1(p2), welcome: !!(await p2.$('.welcome')) };
  check('ترحيب: يظهر أول مرة فقط؛ الفتح الثاني والثالث (إعادة تحميل وتبويب جديد) يذهبان إلى الرئيسية مباشرة بالدور المحفوظ', second.h === 'أهلاً بك في مَرسى' && !second.welcome && second.mode === 'rep' && third.h === 'أهلاً بك في مَرسى' && !third.welcome, JSON.stringify([second, third]));
  await p2.close();
  // يعود من «إعادة الترحيب» في الإعدادات ثم يُختار الدور من جديد
  await go(p, '#/settings'); await p.click('#btn-welcome'); await waitRoute(p, '#/welcome', 'ما هو مَرسى؟');
  check('ترحيب: «إعادة الترحيب» في الإعدادات تعيده من الشريحة 1', (await h1(p)) === 'ما هو مَرسى؟');
  await p.click('.w-top a.linkbtn'); await p.click('button[data-role="student"]'); await p.waitForSelector('.cards3');
  check('ترحيب: بعد الإعادة يُختار الدور من جديد (طالب) وتعود الرئيسية', (await p.getAttribute('html', 'data-mode')) === 'student' && (await texts(p, 'a.tile b')).join('|') === 'إضافة تحضير|تحضيراتي');
  // الوصول بلوحة المفاتيح
  await p.goto(BASE + '/index.html#/welcome/role'); await p.waitForSelector('button[data-role="rep"]');
  await press(p, 'button[data-role="rep"]', 'Enter'); await p.waitForSelector('.cards3');
  check('ترحيب: اختيار الدور يعمل بلوحة المفاتيح (Enter)', (await p.getAttribute('html', 'data-mode')) === 'rep');
  await done(c);
  // رابط عميق في أول فتح يمرّ بالترحيب، وجهاز آخر يرى الترحيب (لا مشاركة)
  var d = await open(browser, { label: 'welcome-deep', hash: '#/saved' });
  check('ترحيب: رابط عميق (#/saved) في أول فتح يمرّ بالترحيب أولاً ثم الرئيسية بعد اختيار الدور', (await hash(d.page)) === '#/welcome');
  await d.page.goto(BASE + '/index.html#/welcome/role'); await d.page.click('button[data-role="student"]'); await d.page.waitForSelector('.cards3');
  check('ترحيب: بعد اختيار الدور يظهر الرئيسية لا الرابط العميق', (await h1(d.page)) === 'أهلاً بك في مَرسى');
  await done(d);
  var e = await open(browser, { label: 'welcome-other-device' });
  check('ترحيب: جهاز آخر (سياق معزول) يرى الترحيب من جديد', (await hash(e.page)) === '#/welcome');
  await done(e);
}

// ================= الرئيسية (S10) =================
async function scenarioHome(browser) {
  var c = await open(browser, { label: 'home-empty', seed: { 'marsa.v1.ui': uiSeed() } }), p = c.page, cards, tiles;
  cards = await texts(p, 'a.scard');
  check('رئيسية الطالب: ثلاث بطاقات ملخّصة (اليوم، باچر، أقرب امتحان) بحالاتها الفارغة', cards.length === 3 && /^اليوم/.test(cards[0]) && /لا شيء اليوم/.test(cards[0]) && /^باچر/.test(cards[1]) && /لا شيء باچر/.test(cards[1]) && /^أقرب امتحان/.test(cards[2]) && /لا امتحانات قادمة/.test(cards[2]), JSON.stringify(cards));
  check('رئيسية الطالب: روابط البطاقات تفتح اليوم وباچر والامتحان', (await p.$$eval('a.scard', function (l) { return l.map(function (a) { return a.getAttribute('href'); }); })).join('|') === '#/day|#/day/tomorrow|#/exam');
  tiles = await texts(p, 'a.tile b');
  check('رئيسية الطالب: «إضافة تحضير» و«تحضيراتي» فقط (والأخيرة بعدّاد 0)', tiles.join('|') === 'إضافة تحضير|تحضيراتي' && (await texts(p, 'a.tile .count')).join('') === '0', tiles.join('|'));
  check('رئيسية الطالب: بلا جداول كاملة ولا مخططات ولا بطاقات قوائم ولا إحصائيات', (await p.$$eval('#app table, #app canvas, #app .card, #app .stat', function (l) { return l.length; })) === 0);
  check('رئيسية الطالب: سطر ترحيب بالتاريخ (صباح الخير · الخميس 22 أكتوبر) وعنوان «أهلاً بك في مَرسى»', (await h1(p)) === 'أهلاً بك في مَرسى' && /^صباح الخير · الخميس 22 أكتوبر$/.test((await p.textContent('.lead')).trim()), await p.textContent('.lead'));
  check('رئيسية بلا بيانات: توجيه واضح لتجربة البيانات التجريبية من الإعدادات بدل جدول فارغ', /لا جدول ولا امتحانات بعد/.test(await p.textContent('#app')) && (await p.isVisible('#app a.linkbtn[href="#/settings"]')));
  await done(c);
  var ev = await open(browser, { label: 'home-evening', clock: '2026-10-22T16:00:00Z', seed: { 'marsa.v1.ui': uiSeed() } });
  check('رئيسية: التحية «مساء الخير» بعد الظهر', /^مساء الخير · /.test((await ev.page.textContent('.lead')).trim()));
  await done(ev);
  // بيانات تجريبية + تحاضير محفوظة: الأعداد تجمع الدروس والتحاضير والواجب
  var g = D.examGroups(DEMO, TODAY).nearest, expEx = g.subject + ' · ' + D.daysLabel(D.daysBetween(TODAY, g.date));
  var s = await open(browser, { label: 'home-student', seed: fullSeed({ 'marsa.v1.demo': DEMO_JSON }) }); p = s.page;
  cards = await texts(p, 'a.scard');
  check('رئيسية الطالب بالبيانات التجريبية: اليوم «5 دروس · تحضير واحد · واجب واحد» وباچر (الجمعة) «تحضير واحد» والأقرب بتسميته', /5 دروس · تحضير واحد · واجب واحد/.test(cards[0]) && /تحضير واحد/.test(cards[1]) && !/دروس/.test(cards[1]) && cards[2].indexOf(expEx) > -1, JSON.stringify(cards) + ' / ' + expEx);
  check('رئيسية بالبيانات التجريبية: وسم «تجريبي» على البطاقات الثلاث وتنبيه أنها اصطناعية', (await p.$$eval('a.scard .demo-tag', function (l) { return l.length; })) === 3 && /بيانات تجريبية اصطناعية، وليست جدولك الحقيقي/.test(await p.textContent('.hint')));
  check('رئيسية الطالب: عدّاد تحضيراتي يعكس المحفوظ (2) ولا يتأثر بالبيانات التجريبية', (await texts(p, 'a.tile .count')).join('') === '2');
  await done(s);
  var r = await open(browser, { label: 'home-rep', seed: fullSeed({ 'marsa.v1.demo': DEMO_JSON, 'marsa.v1.ui': uiSeed({ mode: 'rep' }) }) }); p = r.page;
  cards = await texts(p, 'a.scard'); tiles = await texts(p, 'a.tile b');
  check('رئيسية الممثل: البطاقات الثلاث تقرأ من «تحاضير أنشأتها» (اليوم: 5 دروس · تحضير واحد · واجب واحد، وباچر بلا شيء)', /5 دروس · تحضير واحد · واجب واحد/.test(cards[0]) && /لا شيء باچر/.test(cards[1]), JSON.stringify(cards));
  check('رئيسية الممثل: «إنشاء تحضير» (الرئيسي) و«تحاضير أنشأتها» بعدّاد، ولا «إضافة تحضير»', tiles.join('|') === 'إنشاء تحضير|تحاضير أنشأتها' && (await p.$$eval('a.tile.primary', function (l) { return l.length; })) === 1);
  await done(r);
}

// ================= اليوم/باچر (S11) والامتحان القريب (S12/S13) =================
async function scenarioDayExam(browser) {
  var c = await open(browser, { label: 'day-empty', seed: { 'marsa.v1.ui': uiSeed() } }), p = c.page, rows, tabs;
  await go(p, '#/day');
  tabs = await p.$$eval('.tabs a', function (l) { return l.map(function (a) { return a.textContent + ':' + a.getAttribute('aria-current'); }); });
  check('اليوم: تبويبان «اليوم» و«باچر» والأول نشط', (await h1(p)) === 'اليوم' && tabs.join('|') === 'اليوم:page|باچر:null', tabs.join('|'));
  check('اليوم (بلا بيانات): حالات فارغة «لا جدول بعد» و«لا تحاضير لليوم» و«لا واجب مسجّل» مع شرح وروابط', /لا جدول بعد/.test(await p.textContent('#app')) && /لا تحاضير لليوم/.test(await p.textContent('#app')) && /لا واجب مسجّل/.test(await p.textContent('#app')) && (await p.isVisible('a.btn:has-text("إضافة تحضير")')) && (await p.isVisible('a.btn:has-text("فتح الإعدادات")')));
  await p.click('.tabs a:has-text("باچر")'); await waitRoute(p, '#/day/tomorrow', 'باچر');
  tabs = await p.$$eval('.tabs a', function (l) { return l.map(function (a) { return a.textContent + ':' + a.getAttribute('aria-current'); }); });
  check('باچر: التبويب الثاني ينشط ويتغيّر العنوان والحالات الفارغة (لا تحاضير ليوم باچر)', (await h1(p)) === 'باچر' && tabs.join('|') === 'اليوم:null|باچر:page' && /لا تحاضير ليوم باچر/.test(await p.textContent('#app')), tabs.join('|'));
  await go(p, '#/exam');
  check('الامتحان القريب (بلا بيانات): «لا امتحانات قادمة» مع شرح ورابط الإعدادات، ولا قوائم', (await h1(p)) === 'الامتحان القريب' && /لا امتحانات قادمة/.test(await p.textContent('.empty')) && (await p.isVisible('.empty a.btn[href="#/settings"]')) && !(await p.$('.nearest')) && !(await p.$('details.more')));
  await go(p, '#/exam/demo-exam-1');
  check('امتحان غير موجود (معرّف صالح الشكل): «غير موجود» برجوع إلى الامتحان القريب، بلا انهيار', (await h1(p)) === 'غير موجود' && /لم يعد هذا الامتحان موجوداً/.test(await p.textContent('.note')) && (await p.getAttribute('a.back', 'href')) === '#/exam');
  await go(p, '#/exam/%00bad');
  check('امتحان بمعرّف سيئ الشكل يعود للرئيسية بلا أخطاء (كباقي المسارات)', (await h1(p)) === 'أهلاً بك في مَرسى');
  await done(c);

  var s = await open(browser, { label: 'day-demo', seed: fullSeed({ 'marsa.v1.demo': DEMO_JSON }) }); p = s.page;
  await go(p, '#/day');
  rows = await texts(p, '.slist .lrow');
  var times = await texts(p, '.lrow .time'), sorted = times.slice().sort();
  check('اليوم (الخميس) بالبيانات التجريبية: خمسة دروس مرتّبة بالوقت (08:00–08:45 أولاً) ووسم «بيانات تجريبية»', rows.length === 5 && times[0] === '08:00–08:45' && times.join() === sorted.join() && /بيانات تجريبية/.test(await p.textContent('.note')), rows.join(' | '));
  var prep = await p.$$eval('.list a.card', function (l) { return l.map(function (a) { return a.getAttribute('href') + '|' + a.textContent.replace(/\s+/g, ' ').trim(); }); });
  check('اليوم: التحاضير المحفوظة لهذا اليوم تظهر ببطاقة تفتح القراءة (#/saved/المعرّف) ويظهر واجبها في قسم «الواجب»', prep.length === 2 && prep[0].indexOf('#/saved/sav000001|') === 0 && /تحضير اليوم المحفوظ/.test(prep[0]) && /حل التمرين/.test(prep[1]) && prep[1].indexOf('#/saved/sav000001|') === 0, JSON.stringify(prep));
  await p.click('.list a.card >> nth=0'); await p.waitForSelector('article.prep');
  check('اليوم: بطاقة التحضير تفتح شاشة القراءة بمحتواه', /محتوى تحضير اليوم المحفوظ/.test(await p.textContent('article.prep')));
  await go(p, '#/day/tomorrow');
  check('باچر (الجمعة): لا دروس لكن الجدول موجود («لا دروس باچر»)، ويظهر تحضير باچر المحفوظ', /لا دروس باچر/.test(await p.textContent('#app')) && !/لا جدول بعد/.test(await p.textContent('#app')) && (await texts(p, '.list a.card h3')).join('|') === 'تحضير باچر المحفوظ');
  await go(p, '#/exam');
  var gr = D.examGroups(DEMO, TODAY), nearestTxt = await p.textContent('a.nearest');
  check('الامتحان القريب: «الأقرب» أولاً بمادته وموعده (بعد N أيام) ثم «القادمة» (2) ثم «المنتهية (2)» مطويّة', nearestTxt.indexOf(gr.nearest.subject) > -1 && nearestTxt.indexOf(D.daysLabel(D.daysBetween(TODAY, gr.nearest.date))) > -1 && (await p.$$eval('section.block a.xcard', function (l) { return l.length; })) === 2 && (await p.textContent('details.more > summary')).trim() === 'المنتهية (2)' && !(await p.$eval('details.more', function (d) { return d.open; })), nearestTxt);
  var order = await p.$$eval('section.block a.xcard small', function (l) { return l.map(function (x) { return x.textContent; }); });
  check('الامتحان القريب: القادمة مرتّبة بالتاريخ، وبعد التاريخ «بعد N أيام/يوماً»', order.length === 2 && /بعد \d+ (أيام|يوماً)/.test(order[0]) && /بعد \d+ (أيام|يوماً)/.test(order[1]), order.join(' | '));
  await p.click('details.more > summary'); var fin = await p.$$eval('details.more a.xcard small', function (l) { return l.map(function (x) { return x.textContent; }); });
  check('الامتحان القريب: المنتهية تُفتح بالنقر وتعرض «قبل N أيام»', fin.length === 2 && fin.every(function (t) { return /قبل \d+ (أيام|يوماً)/.test(t); }), fin.join(' | '));
  await p.click('a.nearest'); await p.waitForFunction(function () { var h = document.querySelector('#app h1'); return /^#\/exam\/demo-exam-/.test(location.hash) && h && /^امتحان /.test(h.textContent); });
  var kv = await texts(p, 'dl.kv dt');
  check('تفاصيل الامتحان: عنوان «امتحان <المادة>» وحقول التاريخ والوقت والموعد والمواضيع والملاحظات ورجوع إلى الامتحان القريب', /^امتحان /.test(await h1(p)) && kv.join('|') === 'التاريخ|الوقت|الموعد|المواضيع|ملاحظات' && (await p.getAttribute('a.back', 'href')) === '#/exam', kv.join('|'));
  await done(s);
  // كل الامتحانات انتهت (بعد أشهر): حالة «لا امتحانات قادمة» مع المنتهية
  var l = await open(browser, { label: 'exam-all-finished', clock: '2027-06-01T06:00:00Z', seed: fullSeed({ 'marsa.v1.demo': DEMO_JSON }) });
  await go(l.page, '#/exam');
  check('الامتحان القريب: إن انتهت كلها يظهر «لا امتحانات قادمة» مع «المنتهية (5)»', /لا يوجد امتحان قادم/.test(await l.page.textContent('.empty')) && (await l.page.textContent('details.more > summary')).trim() === 'المنتهية (5)');
  await done(l);
  // النص نصٌّ فقط: لا HTML يُنفَّذ من حقول البيانات (ولو كانت مخزّنة بيد خبيثة)
  var evil = JSON.parse(DEMO_JSON); evil.exams[0].topics = '<img src=x onerror="window.__pwn=1">نص'; evil.exams[0].notes = '<script>window.__pwn=2<\/script>'; evil.timetable[4][0].subject = '<b>مادة</b>';
  var h = await open(browser, { label: 'exam-evil', seed: fullSeed({ 'marsa.v1.demo': JSON.stringify(evil) }) });
  await go(h.page, '#/exam/demo-exam-1');
  var evilState = await h.page.evaluate(function () { return { pwn: window.__pwn || 0, imgs: document.querySelectorAll('dd img, dd script, dd b').length, text: document.querySelector('dl.kv').textContent }; });
  await go(h.page, '#/day');
  var evilDay = await h.page.evaluate(function () { return { pwn: window.__pwn || 0, bold: document.querySelectorAll('.lrow b b').length, text: document.querySelector('.slist').textContent }; });
  check('نصوص البيانات التجريبية تُعرض نصاً فقط (textContent): لا وسوم ولا سكربتات تُنفَّذ', evilState.pwn === 0 && evilState.imgs === 0 && evilState.text.indexOf('<img') > -1 && evilDay.pwn === 0 && evilDay.bold === 0, JSON.stringify([evilState, evilDay]));
  await done(h);
}

// ================= المظهر الثلاثي (تلقائي/فاتح/داكن) =================
var BG = { light: 'rgb(244, 247, 251)', dark: 'rgb(11, 19, 36)' };
async function bodyBg(p) { return p.evaluate(function () { return getComputedStyle(document.body).backgroundColor; }); }
async function themeState(p) { return p.evaluate(function () { return { attr: document.documentElement.getAttribute('data-theme'), cs: getComputedStyle(document.documentElement).colorScheme, bg: getComputedStyle(document.body).backgroundColor, checked: (document.querySelector('input[name=theme]:checked') || {}).value || null }; }); }
async function scenarioTheme(browser) {
  var c = await open(browser, { label: 'theme', scheme: 'light', seed: { 'marsa.v1.ui': uiSeed(), 'marsa.v1.saved': SAVED_SEED } }), p = c.page, s, before;
  await go(p, '#/settings');
  var labels = await texts(p, '.choice span');
  check('إعدادات: المظهر ثلاثة خيارات (تلقائي/فاتح/داكن) والافتراضي «تلقائي» محدّد', labels.join('|') === 'تلقائي|فاتح|داكن' && (await themeState(p)).checked === 'auto' && (await themeState(p)).attr === null, labels.join('|'));
  s = await themeState(p);
  check('تلقائي على جهاز فاتح: الخلفية فاتحة بلا data-theme', s.bg === BG.light && s.attr === null, JSON.stringify(s));
  await p.emulateMedia({ colorScheme: 'dark' }); s = await themeState(p);
  check('تلقائي يتبع الجهاز فوراً: تحويل الجهاز إلى الداكن يغيّر الصفحة دون إعادة تحميل', s.bg === BG.dark && s.attr === null, JSON.stringify(s));
  await p.emulateMedia({ colorScheme: 'light' });
  before = await dump(p);
  await p.click('label.choice:has-text("داكن")'); s = await themeState(p);
  check('اختيار «داكن» على جهاز فاتح يُطبَّق فوراً (data-theme=dark، خلفية داكنة، color-scheme داكن)', s.attr === 'dark' && s.bg === BG.dark && s.cs === 'dark' && s.checked === 'dark', JSON.stringify(s));
  var ui = JSON.parse((await dump(p))['marsa.v1.ui']);
  check('المظهر يُحفظ محلياً في marsa.v1.ui مع بقاء الدور والإصدار والترحيب', ui.theme === 'dark' && ui.mode === 'student' && ui.welcomed === true && ui.schemaVersion === 1, JSON.stringify(ui));
  check('تغيير المظهر لا يمسّ تحضيراتي المحفوظة ولا غيرها', (await dump(p))['marsa.v1.saved'] === before['marsa.v1.saved'] && sameDump(before, await dump(p), 'marsa.v1.ui') === '');
  await p.reload(); await p.waitForSelector('#app h1'); s = await themeState(p); await skipIntro(p);
  check('المظهر المختار يبقى بعد التحديث (داكن على جهاز فاتح)', s.attr === 'dark' && s.bg === BG.dark && s.checked === 'dark', JSON.stringify(s));
  await p.emulateMedia({ colorScheme: 'dark' }); await p.click('label.choice:has-text("فاتح")'); s = await themeState(p);
  check('اختيار «فاتح» على جهاز داكن يتغلّب على الجهاز (خلفية فاتحة وcolor-scheme فاتح)', s.attr === 'light' && s.bg === BG.light && s.cs === 'light', JSON.stringify(s));
  await p.reload(); await p.waitForSelector('#app h1'); s = await themeState(p); await skipIntro(p);
  check('«فاتح» على جهاز داكن يبقى بعد التحديث', s.attr === 'light' && s.bg === BG.light, JSON.stringify(s));
  await p.click('label.choice:has-text("تلقائي")'); s = await themeState(p);
  check('العودة إلى «تلقائي» تزيل data-theme وتتبع الجهاز (داكن هنا)', s.attr === null && s.bg === BG.dark && s.checked === 'auto', JSON.stringify(s));
  ui = JSON.parse((await dump(p))['marsa.v1.ui']);
  check('«تلقائي» يُحفظ كقيمة auto ويبقى بعد التحديث', ui.theme === 'auto' && (await (async function () { await p.reload(); await p.waitForSelector('#app h1'); return (await themeState(p)).checked; })()) === 'auto');
  await skipIntro(p);
  await p.focus('input[value="light"]'); await p.keyboard.press('Space'); s = await themeState(p);
  check('المظهر يعمل بلوحة المفاتيح (تركيز الخيار ثم Space) وبحلقة تركيز ظاهرة على الخيار', s.attr === 'light' && s.checked === 'light');
  check('المظهر ينسحب على كل الشاشات: الرئيسية واليوم والامتحان بالمظهر المختار (فاتح)', await (async function () { var ok = true, r; for (r of ['#/', '#/day', '#/exam', '#/settings']) { await go(p, r); ok = ok && (await bodyBg(p)) === BG.light; } return ok; })());
  await done(c);
  var dk = await open(browser, { label: 'theme-dark-device', scheme: 'dark', seed: { 'marsa.v1.ui': uiSeed() } });
  s = await themeState(dk.page);
  check('الافتراضي تلقائي على جهاز داكن: يبدأ داكناً من أول عرض بلا اختيار', s.bg === BG.dark && s.attr === null && s.cs.indexOf('dark') > -1, JSON.stringify(s));
  await done(dk);
}

// ================= وسم الدور «تجريبي وغير آمن للإنتاج» =================
async function scenarioRole(browser) {
  var c = await open(browser, { label: 'role', seed: { 'marsa.v1.ui': uiSeed() } }), p = c.page, st, txt;
  await go(p, '#/settings');
  txt = await p.textContent('section.set:has(#btn-role)');
  check('إعدادات: قسم «الحساب والدور» موسوم صراحةً «تبديل الدور تجريبي وغير آمن للإنتاج» وبلا حسابات ولا كلمة مرور', txt.indexOf(ROLE_WARN) > -1 && /لا حسابات ولا كلمة مرور/.test(txt) && /أنت الآن: طالب/.test(txt), txt);
  await p.click('#btn-role'); await waitStatus(p);
  st = await p.evaluate(function () { return { mode: document.documentElement.getAttribute('data-mode'), status: document.getElementById('status').textContent, focus: document.activeElement.id, btn: document.getElementById('btn-role').textContent.trim(), who: document.querySelector('.who').textContent }; });
  check('عند التبديل من الإعدادات: رسالة حالة تذكر الدور الجديد والوسم، والزر يتبدّل، والتركيز يبقى على الزر', st.mode === 'rep' && st.status.indexOf(ROLE_WARN) > -1 && st.status.indexOf('ممثل الصف') > -1 && st.btn === 'التبديل إلى وضع الطالب' && /ممثل الصف/.test(st.who) && st.focus === 'btn-role', JSON.stringify(st));
  check('الدور المبدّل يُحفظ في marsa.v1.ui', JSON.parse((await dump(p))['marsa.v1.ui']).mode === 'rep');
  await p.click('.seg button[data-m="student"]'); await p.waitForSelector('html[data-mode="student"]'); await waitStatus(p);
  st = await p.evaluate(function () { return document.getElementById('status').textContent; });
  check('عند التبديل من المبدّل العلوي: رسالة الحالة تحمل الوسم نفسه «تجريبي وغير آمن للإنتاج»', st.indexOf(ROLE_WARN) > -1 && /طالب/.test(st), st);
  var d = await p.evaluate(function () { var g = document.querySelector('.seg'), n = document.getElementById(g.getAttribute('aria-describedby')); return n ? n.textContent : ''; });
  check('المبدّل العلوي موصوف لقارئ الشاشة بنفس الوسم (aria-describedby)', d.indexOf(ROLE_WARN) > -1, d);
  await go(p, '#/about');
  check('«عن مَرسى وحدوده» تذكر الحدود: لا حسابات ولا مزامنة ولا خادم، الكود غير مشفّر ولا يُلغى، الدور تجريبي وغير آمن للإنتاج', (await p.textContent('.facts')).indexOf('لا حسابات ولا مزامنة ولا خادم') > -1 && /غير مشفّر ولا يُلغى/.test(await p.textContent('.facts')) && /تجريبي وغير آمن للإنتاج/.test(await p.textContent('.facts')));
  await done(c);
}

// ================= البيانات التجريبية: عزل بايتاً ببايت =================
async function scenarioDemoIsolation(browser) {
  var c = await open(browser, { label: 'demo-iso', seed: fullSeed({ 'marsa.v1.draft': '{"schemaVersion":1,"values":{"subject":"مسودة"}}' }) }), p = c.page, b0, b1, b2, b3, k;
  b0 = await dump(p); await go(p, '#/settings');
  check('بيانات تجريبية: قبل التحميل لا مفتاح marsa.v1.demo، وزر «تجربة ببيانات تجريبية» يعرض حالة غير محمّلة', !('marsa.v1.demo' in b0) && (await p.textContent('#btn-demo')).trim() === 'تجربة ببيانات تجريبية');
  await p.click('#btn-demo'); await p.waitForSelector('#btn-demo.danger'); b1 = await dump(p);
  k = sameDump(b0, b1, 'marsa.v1.demo');
  check('تحميل البيانات التجريبية يضيف marsa.v1.demo وحده؛ mine وsaved وdraft وui والمفاتيح القديمة بلا تغيير بايتاً ببايت', k === '' && Object.keys(b1).length === Object.keys(b0).length + 1 && 'marsa.v1.demo' in b1, 'تغيّر: ' + k);
  check('البيانات المحمّلة صالحة وبعلامة اصطناعية، والزر صار «حذف البيانات التجريبية» والحالة «محمَّلة»', JSON.parse(b1['marsa.v1.demo']).synthetic === true && D.validate(JSON.parse(b1['marsa.v1.demo'])) && (await p.textContent('#btn-demo')).trim() === 'حذف البيانات التجريبية' && /محمَّلة/.test(await p.textContent('section.set:has(#btn-demo)')));
  for (var r of ['#/', '#/day', '#/day/tomorrow', '#/exam', '#/exam/demo-exam-1', '#/saved', '#/about']) await go(p, r);
  b2 = await dump(p);
  check('تصفّح شاشات اليوم/باچر/الامتحان لا يكتب شيئاً في التخزين (قراءة فقط)', JSON.stringify(b2) === JSON.stringify(b1));
  await go(p, '#/settings'); await p.reload(); await p.waitForSelector('#btn-demo'); await skipIntro(p);
  check('البيانات التجريبية تبقى بعد التحديث', (await p.textContent('#btn-demo')).trim() === 'حذف البيانات التجريبية');
  await p.click('#btn-demo'); await p.waitForSelector('#dlg[open]');
  check('الحذف يطلب تأكيداً بعنوان واضح ويحصر الحذف في البيانات التجريبية', (await p.textContent('#dlg-t')).trim() === 'حذف البيانات التجريبية؟' && /ولن يُمسّ أي تحضير محفوظ/.test(await p.textContent('#dlg-body')));
  await p.click('#dlg-body .btn:has-text("إلغاء")'); await p.waitForSelector('#dlg:not([open])', { state: 'attached' });
  check('إلغاء التأكيد لا يحذف شيئاً', JSON.stringify(await dump(p)) === JSON.stringify(b1));
  await p.click('#btn-demo'); await p.click('#dlg-body .btn.danger'); await p.waitForSelector('#btn-demo.primary'); b3 = await dump(p);
  check('بعد حذف البيانات التجريبية يعود التخزين كما كان قبل التحميل بالضبط (بايتاً ببايت لكل المفاتيح)', JSON.stringify(b3) === JSON.stringify(b0) && !('marsa.v1.demo' in b3), sameDump(b0, b3, '') );
  check('بعد الحذف تختفي الدروس والامتحانات والوسم «تجريبي» وتبقى تحاضيري (2) وبطاقات اليوم من التحاضير المحفوظة', await (async function () { await go(p, '#/'); var cs = await texts(p, 'a.scard'); return !/دروس/.test(cs[0]) && !/دروس/.test(cs[1]) && /تحضير واحد/.test(cs[0]) && /لا امتحانات قادمة/.test(cs[2]) && !(await p.$('.demo-tag')) && (await texts(p, 'a.tile .count')).join('') === '2'; })());
  await go(p, '#/exam/demo-exam-1');
  check('بعد الحذف: رابط امتحان محفوظ سابقاً يعطي «غير موجود» لا انهياراً', (await h1(p)) === 'غير موجود');
  // الدورة نفسها بدور الممثل
  await go(p, '#/settings'); await p.click('#btn-role'); await p.click('#btn-demo'); await p.waitForSelector('#btn-demo.danger');
  b1 = await dump(p); await p.click('#btn-demo'); await p.click('#dlg-body .btn.danger'); await p.waitForSelector('#btn-demo.primary'); b2 = await dump(p);
  check('بدور الممثل: التحميل والحذف لا يمسّان mine ولا saved ولا القديمة (يتغيّر الدور في marsa.v1.ui فقط)', sameDump(b0, b2, 'marsa.v1.ui') === '' && b2['marsa.v1.mine'] === b0['marsa.v1.mine'] && b2['marsa.v1.saved'] === b0['marsa.v1.saved'] && Object.keys(LEGACY).every(function (x) { return b2[x] === LEGACY[x]; }));
  await done(c);
}

// ================= RTL والتجاوب والتباين والتركيز وأهداف اللمس =================
var WIDTHS = [320, 390, 768, 1024, 1280];
var ROUTES_STUDENT = ['#/', '#/day', '#/day/tomorrow', '#/exam', '#/exam/demo-exam-1', '#/settings', '#/about', '#/welcome', '#/welcome/2', '#/welcome/3', '#/welcome/role', '#/saved', '#/saved/sav000001', '#/add'];
var ROUTES_REP = ['#/mine', '#/new', '#/share/min000001'];
var TOP_ROUTES = ['#/', '#/day', '#/day/tomorrow', '#/exam', '#/settings', '#/saved'];
var DEEP_ROUTES = ['#/add', '#/saved/sav000001', '#/exam/demo-exam-1', '#/about'];
async function overflowOf(p) { return p.evaluate(function () { return Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) - window.innerWidth; }); }
async function scenarioLayout(browser) {
  var seed = fullSeed({ 'marsa.v1.demo': DEMO_JSON });
  var c = await open(browser, { label: 'layout', seed: seed, viewport: { width: 320, height: 700 } }), p = c.page, w, r, bad, o;
  check('RTL: الصفحة dir=rtl وlang=ar، والعناوين اتجاهها rtl ومحاذاتها للبداية (اليمين)', await p.evaluate(function () { var h = document.querySelector('h1'); return document.documentElement.dir === 'rtl' && document.documentElement.lang === 'ar' && getComputedStyle(h).direction === 'rtl' && getComputedStyle(h).textAlign === 'start'; }));
  // لا تمرير أفقي
  bad = [];
  for (w of WIDTHS) { await p.setViewportSize({ width: w, height: 800 }); for (r of ROUTES_STUDENT) { await go(p, r); await p.waitForTimeout(40); o = await overflowOf(p); if (o > 1) bad.push(w + ' ' + r + ' +' + o); } }
  check('لا تمرير أفقي عند 320/390/768/1024/1280 في كل الشاشات الجديدة والقديمة (الوضع الفاتح، ' + ROUTES_STUDENT.length + ' شاشة × 5 عروض)', bad.length === 0, bad.slice(0, 6).join(' | '));
  await p.emulateMedia({ colorScheme: 'dark' }); bad = [];
  for (w of [320, 1280]) { await p.setViewportSize({ width: w, height: 800 }); for (r of ROUTES_STUDENT) { await go(p, r); await p.waitForTimeout(40); o = await overflowOf(p); if (o > 1) bad.push(w + ' ' + r + ' +' + o); } }
  check('لا تمرير أفقي في الوضع الداكن عند 320 و1280 في كل الشاشات', bad.length === 0, bad.slice(0, 6).join(' | '));
  await p.emulateMedia({ colorScheme: 'light' });
  // شريط التنقل
  await p.setViewportSize({ width: 390, height: 800 });
  var navInfo = [];
  for (r of TOP_ROUTES.concat(DEEP_ROUTES)) { await go(p, r); navInfo.push(r + ':' + (await p.isVisible('#nav'))); }
  var navOk = navInfo.filter(function (x) { return /:true$/.test(x); }).map(function (x) { return x.split(':')[0]; });
  check('تنقل الهاتف (390): الشريط السفلي يظهر في الشاشات العليا فقط ويختفي في التفاصيل والنماذج', JSON.stringify(navOk) === JSON.stringify(TOP_ROUTES), navInfo.join(' '));
  await go(p, '#/');
  var nb = await p.evaluate(function () { var n = document.getElementById('nav'), r = n.getBoundingClientRect(), items = Array.prototype.map.call(n.querySelectorAll('a'), function (a) { var b = a.getBoundingClientRect(); return { h: b.height, w: b.width, t: a.textContent.trim() }; }); return { bottom: r.bottom, vh: window.innerHeight, pos: getComputedStyle(n).position, items: items }; });
  check('تنقل الهاتف: أربعة عناصر (الرئيسية، اليوم، التحاضير، الإعدادات) كلٌّ ≥ 52px، والشريط مثبّت أسفل الشاشة', nb.items.map(function (i) { return i.t; }).join('|') === 'الرئيسية|اليوم|التحاضير|الإعدادات' && nb.items.every(function (i) { return i.h >= 52 && i.w >= 44; }) && nb.pos === 'fixed' && Math.abs(nb.bottom - nb.vh) < 2, JSON.stringify(nb));
  var active = [];
  for (r of ['#/', '#/day', '#/day/tomorrow', '#/saved', '#/settings', '#/exam']) { await go(p, r); active.push(r + '=' + (await p.$$eval('#nav a[aria-current="page"]', function (l) { return l.map(function (a) { return a.getAttribute('data-nav'); }).join(','); }))); }
  check('تنقل: العنصر النشط بـaria-current حسب الشاشة (الرئيسية/اليوم/باچر→اليوم/تحضيراتي→التحاضير/الإعدادات/الامتحان→الرئيسية)', active.join(' ') === '#/=home #/day=day #/day/tomorrow=day #/saved=preps #/settings=settings #/exam=home', active.join(' '));
  await go(p, '#/settings'); await p.evaluate(function () { window.scrollTo(0, document.body.scrollHeight); }); await p.waitForTimeout(60);
  var cover = await p.evaluate(function () { var n = document.getElementById('nav').getBoundingClientRect(), h = document.getElementById('how').getBoundingClientRect(); return { how: h.bottom, nav: n.top }; });
  check('الشريط السفلي لا يغطّي آخر المحتوى: زر الفوتر يظهر كاملاً فوقه عند نهاية الصفحة', cover.how <= cover.nav + 1, JSON.stringify(cover));
  // الشريط الجانبي من 1024
  var side = [];
  for (w of [768, 1024, 1280]) {
    await p.setViewportSize({ width: w, height: 800 });
    for (r of ['#/', '#/add', '#/saved/sav000001']) {
      await go(p, r);
      var g = await p.evaluate(function () { var n = document.getElementById('nav'), m = document.getElementById('main'), nr = n.getBoundingClientRect(), mrr = m.getBoundingClientRect(), vis = nr.width > 0 && getComputedStyle(n).display !== 'none'; return { vis: vis, nl: nr.left, nr: nr.right, ml: mrr.left, mr: mrr.right, vw: window.innerWidth, pos: getComputedStyle(n).position, h: Array.prototype.map.call(n.querySelectorAll('a'), function (a) { return a.getBoundingClientRect().height; }) }; });
      side.push(w + r + ':' + (w >= 1024 ? (g.vis && g.nl >= g.mr - 1 && g.nr <= g.vw + 1 && g.h.every(function (x) { return x >= 52; })) : (r === '#/' ? g.vis && g.pos === 'fixed' : !g.vis)));
    }
  }
  check('تنقل الحاسوب: من 1024 شريط جانبي يميناً (يمين المحتوى) في كل الشاشات بعناصر ≥ 52px، وعلى 768 يبقى سفلياً (للشاشات العليا فقط)', side.every(function (x) { return /:true$/.test(x); }), side.join(' '));
  await p.setViewportSize({ width: 1280, height: 800 }); await go(p, '#/');
  var cards1 = await p.evaluate(function () { return Array.prototype.map.call(document.querySelectorAll('a.scard'), function (a) { var r = a.getBoundingClientRect(); return Math.round(r.top); }); });
  check('رئيسية الحاسوب (1280): البطاقات الثلاث في صف واحد', cards1.length === 3 && cards1[0] === cards1[1] && cards1[1] === cards1[2], cards1.join(','));
  await go(p, '#/welcome');
  check('الترحيب على الحاسوب بلا شريط جانبي ولا مبدّل دور', !(await p.isVisible('#nav')) && !(await p.isVisible('.seg')));
  // أهداف اللمس ≥ 44
  await p.setViewportSize({ width: 390, height: 800 });
  var touchSel = '.btn, .tile, .scard, .nav a, .tabs a, .xcard, .nearest, a.card, .rolebtn, .choice, .linkbtn, .back, .seg button, summary, #how, #brand';
  bad = []; var touchSeen = 0;
  for (r of ROUTES_STUDENT.concat([])) {
    await go(p, r);
    var tl = await p.evaluate(function (sel) { var out = []; Array.prototype.forEach.call(document.querySelectorAll(sel), function (e) { var b = e.getBoundingClientRect(); if (b.width === 0 || b.height === 0) return; out.push({ c: e.className && e.className.baseVal !== undefined ? '' : e.className, t: (e.textContent || '').trim().slice(0, 18), w: Math.round(b.width), h: Math.round(b.height) }); }); return out; }, touchSel);
    touchSeen += tl.length; tl.forEach(function (x) { if (x.h < 43.5 || x.w < 43.5) bad.push(r + ' ' + x.c + ' «' + x.t + '» ' + x.w + 'x' + x.h); });
  }
  check('أهداف اللمس ≥ 44px لكل الأزرار والروابط والبطاقات والتبويبات والخيارات (' + touchSeen + ' عنصراً في ' + ROUTES_STUDENT.length + ' شاشة)', bad.length === 0 && touchSeen > 60, bad.slice(0, 6).join(' | ') + ' seen=' + touchSeen);
  // الأسهم تنعكس والأيقونات الرمزية لا
  var arrows = [];
  for (r of ['#/', '#/exam', '#/welcome']) { await go(p, r); arrows.push(await p.evaluate(function () { var dir = Array.prototype.map.call(document.querySelectorAll('svg.dir'), function (s) { return getComputedStyle(s).transform; }), other = Array.prototype.filter.call(document.querySelectorAll('svg:not(.dir)'), function (s) { return s.closest('#app, #nav, .top') && getComputedStyle(s).transform !== 'none' && !s.closest('.w-art'); }).length; return { dir: dir, n: dir.length, other: other }; })); }
  check('الأسهم (←/→ للتقدّم والرجوع) تنعكس في RTL بـscaleX(-1) في الرئيسية والامتحان والترحيب، والأيقونات الرمزية (تقويم، ساعة، زائد، صح…) لا تنعكس', arrows.every(function (a) { return a.n >= 1 && a.dir.every(function (t) { return t === 'matrix(-1, 0, 0, 1, 0, 0)'; }) && a.other === 0; }), JSON.stringify(arrows));
  await go(p, '#/');
  var paths = await p.evaluate(function () { return { go: document.querySelector('.scard .go path').getAttribute('d'), cal: document.querySelector('.scard .ic path').getAttribute('d') }; });
  check('سهم البطاقة مؤلَّف بصيغة LTR (›) فينقلب إلى (‹) في RTL ليشير إلى جهة التقدّم، ورمز التقويم بلا قلب', paths.go === 'M9 6l6 6-6 6' && /^M5 5h14v15/.test(paths.cal));
  await done(c);

  // التباين والتركيز والحدود في الوضعين
  for (var scheme of ['light', 'dark']) {
    var t = await open(browser, { label: 'contrast-' + scheme, scheme: scheme, seed: seed }), q = t.page;
    var TEXT_SELS = ['h1', '.lead', '.sec-t', '.scard b', '.scard small', '.demo-tag', '.nav a', '.tabs a', '.lrow b', '.lrow .time', '.nearest .kick', '.nearest h2', '.nearest .when', '.xcard b', '.xcard small', '.set-t', '.hint', '.choice span', '.who', '.note strong', '.note p', '.btn', '.step', '.w-body', '.rolebtn b', '.rolebtn small', '.linkbtn', '.kv dt', '.kv dd', '.empty', '.empty strong', '.foot p', '.tile b', '.tile small', '.card h3', '.card .snip', '.badge', '.facts li', 'summary'];
    var seenAll = 0, badText = [];
    for (r of ROUTES_STUDENT) {
      await go(q, r); await q.waitForTimeout(30);
      var tc = await q.evaluate(function (a) { return window.__cx.text(a.s, a.m); }, { s: TEXT_SELS, m: 4.5 }); seenAll += tc.seen; tc.bad.forEach(function (x) { badText.push(r + ' ' + x); });
    }
    await go(q, '#/exam'); await q.click('details.more > summary');
    var tc2 = await q.evaluate(function (a) { return window.__cx.text(a.s, a.m); }, { s: TEXT_SELS, m: 4.5 }); seenAll += tc2.seen; tc2.bad.forEach(function (x) { badText.push('exam-open ' + x); });
    check('تباين النص ≥ 4.5:1 في الوضع ' + (scheme === 'light' ? 'الفاتح' : 'الداكن') + ' على كل الشاشات (' + seenAll + ' عنصراً)', badText.length === 0 && seenAll > 150, badText.slice(0, 6).join(' | ') + ' seen=' + seenAll);
    var seenB = 0, badB = [];
    for (r of ['#/settings', '#/welcome/role', '#/welcome/2', '#/add', '#/saved']) {
      await go(q, r);
      var bc = await q.evaluate(function (a) { return window.__cx.border(a.s, a.m); }, { s: ['.choice span', '.rolebtn', '.dots li:not(.on)', '.field'], m: 3 }); seenB += bc.seen; bc.bad.forEach(function (x) { badB.push(r + ' ' + x); });
    }
    await q.goto(BASE + '/index.html#/new'); await q.waitForSelector('.field'); // مسار الممثل: حقول النموذج
    var bc2 = await q.evaluate(function (a) { return window.__cx.border(a.s, a.m); }, { s: ['.field'], m: 3 }); seenB += bc2.seen; bc2.bad.forEach(function (x) { badB.push('#/new ' + x); });
    check('تباين حدود الحقول والخيارات (--field) ≥ 3:1 فعلياً في الوضع ' + (scheme === 'light' ? 'الفاتح' : 'الداكن') + ' (' + seenB + ' عنصراً)', badB.length === 0 && seenB >= 12, badB.slice(0, 6).join(' | ') + ' seen=' + seenB);
    // حلقة التركيز ظاهرة بتباين ≥ 3 على لوحة المفاتيح
    var focusBad = [], focusSeen = 0, targets = [['#/', '.nav a[data-nav="day"]'], ['#/', 'a.scard'], ['#/', 'a.tile'], ['#/', '.seg button'], ['#/day', '.tabs a:nth-child(2)'], ['#/exam', 'a.nearest'], ['#/exam', 'details.more > summary'], ['#/settings', '#btn-demo'], ['#/settings', 'input[value="dark"]'], ['#/welcome/role', 'button.rolebtn'], ['#/welcome', 'a.btn.primary'], ['#/add', '#code-in'], ['#/saved', 'a.card']];
    for (var tg of targets) {
      await go(q, tg[0]); await q.keyboard.press('Tab');
      var fo = await q.evaluate(function (sel) { var el = document.querySelector(sel); if (!el) return null; el.focus(); var host = el.tagName === 'INPUT' && el.type === 'radio' ? el.nextElementSibling : el; return Object.assign({ matches: el.matches(':focus-visible') }, window.__cx.outline(host, 3)); }, tg[1]);
      focusSeen++; if (!fo || !fo.matches || fo.style === 'none' || fo.width < 2 || fo.ratio < 3) focusBad.push(tg.join(' ') + ' ' + JSON.stringify(fo));
    }
    check('حلقة التركيز ظاهرة (≥ 2px وتباين ≥ 3:1) على العناصر التفاعلية الجديدة بلوحة المفاتيح في الوضع ' + (scheme === 'light' ? 'الفاتح' : 'الداكن'), focusBad.length === 0 && focusSeen === targets.length, focusBad.slice(0, 4).join(' | '));
    await done(t);
  }
  // مسارات الممثل: بلا تمرير أفقي ولا أهداف لمس صغيرة
  var rp = await open(browser, { label: 'layout-rep', seed: fullSeed({ 'marsa.v1.demo': DEMO_JSON, 'marsa.v1.ui': uiSeed({ mode: 'rep' }) }), viewport: { width: 320, height: 700 } }); bad = [];
  for (w of [320, 1280]) { await rp.page.setViewportSize({ width: w, height: 800 }); for (r of ['#/'].concat(ROUTES_REP)) { await go(rp.page, r); await rp.page.waitForTimeout(40); o = await overflowOf(rp.page); if (o > 1) bad.push(w + ' ' + r + ' +' + o); } }
  check('مسارات الممثل (الرئيسية، تحاضير أنشأتها، إنشاء، كود المشاركة) بلا تمرير أفقي عند 320 و1280', bad.length === 0, bad.join(' | '));
  await rp.page.setViewportSize({ width: 390, height: 800 }); bad = [];
  for (r of ['#/', '#/mine']) { await go(rp.page, r); var vis = await rp.page.isVisible('#nav'); if (!vis) bad.push(r + ' nav'); }
  await go(rp.page, '#/new'); if (await rp.page.isVisible('#nav')) bad.push('new nav visible');
  check('تنقل الممثل: الشريط يظهر في الرئيسية وتحاضير أنشأتها (والعنصر الثالث يقود إليها) ويختفي في النموذج', bad.length === 0 && (await (async function () { await go(rp.page, '#/'); return rp.page.getAttribute('#nav a[data-nav="preps"]', 'href'); })()) === '#/mine', bad.join(' '));
  await done(rp);
}

// ================= حقن أعطال التخزين: الانترو والإعدادات لا يكسران التطبيق وتظهر رسالة عربية =================
function noLocalStorage() { Object.defineProperty(window, 'localStorage', { configurable: true, get: function () { throw new DOMException('denied', 'SecurityError'); } }); }
function quotaOnWrite() { var orig = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (k === 'marsa.v1.probe') return orig.call(this, k, v); var e = new Error('QuotaExceededError'); e.name = 'QuotaExceededError'; throw e; }; }
function readsThrow() { Storage.prototype.getItem = function () { throw new DOMException('blocked', 'SecurityError'); }; }
async function scenarioFailures(browser) {
  var a = await open(browser, { label: 'fail-no-storage', keepIntro: true, init: noLocalStorage }), p = a.page, s;
  await p.waitForSelector('#intro', { state: 'detached', timeout: 8000 });
  check('تخزين غير متاح (وصول مرفوض): الانترو يزول ولا ينكسر التطبيق ويظهر الترحيب برسالة عربية عن عدم الحفظ', (await hash(p)) === '#/welcome' && /تعذّر الوصول إلى تخزين المتصفح/.test(await p.textContent('.note.warn')) && /ما تضيفه سيُفقد عند إغلاقها/.test(await p.textContent('.note.warn')), await p.textContent('#app'));
  await p.goto(BASE + '/index.html#/welcome/role'); await p.click('button[data-role="student"]'); await p.waitForSelector('.cards3');
  check('تخزين غير متاح: يُكمل اختيار الدور ويصل إلى الرئيسية (لا حلقة ترحيب)، والتذييل يحذّر بالعربية', (await h1(p)) === 'أهلاً بك في مَرسى' && /تعذّر استخدام تخزين المتصفح/.test(await p.textContent('.foot p')));
  await go(p, '#/settings');
  check('تخزين غير متاح: شاشة الإعدادات تعمل وتعرض «التخزين غير متاح» بالعربية', /التخزين غير متاح/.test(await p.textContent('.note.warn')) && (await p.isVisible('#btn-demo')));
  await p.click('label.choice:has-text("داكن")'); s = await themeState(p);
  check('تخزين غير متاح: المظهر يعمل داخل الجلسة بلا أخطاء (ولا يُحفظ)', s.attr === 'dark' && s.bg === BG.dark);
  await p.click('#btn-demo'); await p.waitForSelector('#btn-demo.danger'); await go(p, '#/');
  check('تخزين غير متاح: البيانات التجريبية تعمل داخل الجلسة فقط', /5 دروس|دروس/.test((await texts(p, 'a.scard'))[0]));
  await p.reload(); await p.waitForSelector('#app h1'); await skipIntro(p);
  check('تخزين غير متاح: بعد التحديث يعود الترحيب (لا شيء مُحفوظ) بلا انهيار', (await hash(p)) === '#/welcome');
  await done(a);

  var b = await open(browser, { label: 'fail-quota-first-run', keepIntro: true, init: quotaOnWrite }); p = b.page;
  await skipIntro(p); await p.goto(BASE + '/index.html#/welcome/role'); await p.click('button[data-role="rep"]'); await p.waitForSelector('.cards3');
  s = await p.evaluate(function () { return { status: document.getElementById('status').textContent, mode: document.documentElement.getAttribute('data-mode'), len: localStorage.length, h: location.hash }; });
  check('امتلاء المساحة عند اختيار الدور: رسالة عربية «تعذّر حفظ اختيارك»، والتطبيق يكمل بالدور المختار داخل الجلسة بلا حلقة ترحيب', /تعذّر حفظ اختيارك/.test(s.status) && s.mode === 'rep' && s.len === 0, JSON.stringify(s));
  await go(p, '#/day'); await go(p, '#/exam');
  check('امتلاء المساحة: التنقل بين الشاشات سليم ولا يعود الترحيب خلال الجلسة', (await h1(p)) === 'الامتحان القريب');
  await p.reload(); await p.waitForSelector('#app h1'); await skipIntro(p);
  check('امتلاء المساحة: لم يُحفظ شيء فيعود الترحيب بعد التحديث (كما هو موصوف)', (await hash(p)) === '#/welcome');
  await done(b);

  var q = await open(browser, { label: 'fail-quota-settings', seed: { 'marsa.v1.ui': uiSeed(), 'marsa.v1.saved': SAVED_SEED }, init: quotaOnWrite }); p = q.page;
  await go(p, '#/settings'); var before = await dump(p);
  await p.click('label.choice:has-text("داكن")'); await p.waitForSelector('.set .note.err');
  s = await themeState(p);
  check('فشل حفظ المظهر: يرجع المظهر والاختيار السابقان وتظهر رسالة عربية في الإعدادات (role=alert)', s.attr === null && s.checked === 'auto' && s.bg === BG.light && /تعذّر حفظ المظهر على هذا الجهاز/.test(await p.textContent('.set .note.err')) && (await p.getAttribute('.set .note.err', 'role')) === 'alert', JSON.stringify(s));
  check('فشل حفظ المظهر لا يغيّر شيئاً في التخزين', JSON.stringify(await dump(p)) === JSON.stringify(before));
  await p.click('#btn-demo'); await p.waitForSelector('section.set .note.err >> nth=0');
  var dm = await p.textContent('section.set:has(#btn-demo)');
  check('فشل حفظ البيانات التجريبية: رسالة عربية في قسمها، والزر يبقى «تجربة ببيانات تجريبية»، ولا مفتاح demo ولا مساس بتحضيراتي', /تعذّر حفظ البيانات التجريبية/.test(dm) && (await p.textContent('#btn-demo')).trim() === 'تجربة ببيانات تجريبية' && !('marsa.v1.demo' in (await dump(p))) && (await dump(p))['marsa.v1.saved'] === SAVED_SEED, dm);
  await go(p, '#/'); await done(q);

  var cu = await open(browser, { label: 'fail-corrupt-ui', seed: { 'marsa.v1.ui': '{ملعوب', 'marsa.v1.saved': SAVED_SEED } }); p = cu.page;
  check('تفضيلات تالفة: التطبيق يعمل بالافتراضات ويظهر الترحيب برسالة عربية «تالفة»', (await hash(p)) === '#/welcome' && /تفضيلات الواجهة.*تالفة/.test(await p.textContent('.note.warn')), await p.textContent('#app'));
  await p.goto(BASE + '/index.html#/welcome/role'); await p.click('button[data-role="student"]'); await p.waitForSelector('.cards3');
  var fixed = (await dump(p))['marsa.v1.ui'], okJson = true, pj; try { pj = JSON.parse(fixed); } catch (e) { okJson = false; }
  check('تفضيلات تالفة: اختيار الدور يستبدلها بقيمة سليمة، وتحضيراتي المحفوظة بلا مساس', okJson && pj.welcomed === true && pj.mode === 'student' && (await dump(p))['marsa.v1.saved'] === SAVED_SEED, fixed);
  await p.reload(); await p.waitForSelector('#app h1'); await skipIntro(p);
  check('تفضيلات مُصلَحة: بعد التحديث لا ترحيب ولا رسالة تلف', (await h1(p)) === 'أهلاً بك في مَرسى' && !/تالفة/.test(await p.textContent('#app')));
  await done(cu);

  for (var bad of [{ n: 'JSON غير صالح', v: '{ملعوب' }, { n: 'إصدار غير مدعوم', v: JSON.stringify(Object.assign({}, DEMO, { schemaVersion: 9 })) }, { n: 'ليست اصطناعية', v: JSON.stringify(Object.assign({}, DEMO, { synthetic: false })) }]) {
    var cd = await open(browser, { label: 'fail-corrupt-demo', seed: fullSeed({ 'marsa.v1.demo': bad.v }) }); p = cd.page;
    var noteHome = await p.textContent('.note.warn');
    await go(p, '#/day'); var noteDay = await p.textContent('.note.err'); var roleDay = await p.getAttribute('.note.err', 'role');
    await go(p, '#/exam'); var noteEx = await p.textContent('.note.err');
    await go(p, '#/settings'); var sec = await p.textContent('section.set:has(#btn-demo)');
    var okAll = /تالفة/.test(noteHome) && /تالفة/.test(noteDay) && roleDay === 'alert' && /تالفة/.test(noteEx) && /الحالة: البيانات التجريبية تالفة/.test(sec) && (await p.textContent('#btn-demo')).trim() === 'حذف البيانات التجريبية';
    var snapShot = await dump(p); await p.click('#btn-demo'); await p.click('#dlg-body .btn.danger'); await p.waitForSelector('#btn-demo.primary'); var after = await dump(p);
    check('بيانات تجريبية تالفة (' + bad.n + '): رسائل عربية في الرئيسية واليوم والامتحان والإعدادات، والحذف يزيلها دون المساس بـmine/saved/القديمة', okAll && !('marsa.v1.demo' in after) && sameDump(snapShot, after, 'marsa.v1.demo') === '', noteHome + ' | ' + noteDay + ' | ' + sec);
    await done(cd);
  }

  var rd = await open(browser, { label: 'fail-reads-throw', keepIntro: true, init: readsThrow }); p = rd.page;
  await p.waitForSelector('#intro', { state: 'detached', timeout: 8000 });
  check('قراءة التخزين تفشل (getItem يرمي): الانترو يزول والترحيب يظهر ولا انهيار', (await hash(p)) === '#/welcome' && (await h1(p)) === 'ما هو مَرسى؟');
  await p.goto(BASE + '/index.html#/welcome/role'); await p.click('button[data-role="student"]'); await p.waitForSelector('.cards3'); await go(p, '#/settings'); await go(p, '#/exam'); await go(p, '#/day');
  check('قراءة التخزين تفشل: الرئيسية والإعدادات واليوم والامتحان تعمل بحالاتها الفارغة بلا أخطاء', (await h1(p)) === 'اليوم' && /لا جدول بعد/.test(await p.textContent('#app')));
  await done(rd);
}

// ================= file:// =================
async function scenarioFile(browser) {
  var url = 'file://' + path.join(ROOT, 'index.html'), c = await open(browser, { label: 'file', url: url, keepIntro: true, clock: NOW }), p = c.page, s;
  await p.waitForSelector('#intro', { state: 'detached', timeout: 8000 });
  check('file://: الانترو ثم الترحيب في أول فتح بلا خادم', (await h1(p)) === 'ما هو مَرسى؟');
  await p.goto(url + '#/welcome/role'); await p.click('button[data-role="student"]'); await p.waitForSelector('.cards3');
  await p.goto(url + '#/settings'); await p.waitForSelector('#btn-demo'); await p.click('label.choice:has-text("داكن")'); await p.click('#btn-demo'); await p.waitForSelector('#btn-demo.danger');
  await p.goto(url + '#/day'); await p.waitForSelector('.tabs'); var n = (await p.$$('.lrow')).length;
  s = await themeState(p);
  check('file://: المظهر الداكن والبيانات التجريبية واليوم تعمل وتُحفظ محلياً', s.attr === 'dark' && n === 5);
  await p.reload(); await p.waitForSelector('#app h1'); await skipIntro(p); s = await themeState(p);
  check('file://: بعد التحديث يبقى المظهر الداكن ولا يعود الترحيب', s.attr === 'dark' && (await h1(p)) === 'اليوم' && !(await p.$('.welcome')));
  await done(c);
}

// ================= لقطات الشاشة (اختيارية) =================
async function shots(browser) {
  var dir = path.join(ROOT, 'docs', 'phase1', '01.03-shots'), devs = [{ n: 'phone', vp: { width: 390, height: 844 } }, { n: 'desktop', vp: { width: 1280, height: 800 } }], sc, dv, c, p, steps, st;
  fs.mkdirSync(dir, { recursive: true });
  steps = [['02-welcome', '#/welcome'], ['03-role', '#/welcome/role'], ['04-home', '#/'], ['05-day', '#/day'], ['06-exam', '#/exam'], ['07-settings', '#/settings']];
  for (dv of devs) for (sc of ['light', 'dark']) {
    c = await open(browser, { label: 'shot', scheme: sc, viewport: dv.vp, reduced: true, keepIntro: true, seed: fullSeed({ 'marsa.v1.demo': DEMO_JSON }) }); p = c.page;
    await p.waitForSelector('html[data-intro="on"]'); await p.screenshot({ path: path.join(dir, dv.n + '-' + sc + '-01-intro.png') });
    await skipIntro(p);
    for (st of steps) { await go(p, st[1]); await p.waitForTimeout(120); await p.screenshot({ path: path.join(dir, dv.n + '-' + sc + '-' + st[0] + '.png') }); }
    await done(c);
  }
  console.log('لقطات الشاشة كُتبت في ' + dir);
}

// ================= التشغيل =================
(async function main() {
  await serve();
  var browser = await pw.chromium.launch();
  try {
    if (!process.env.MARSA_SHOTS_ONLY) {
      await scenarioIntro(browser);
      await scenarioWelcome(browser);
      await scenarioHome(browser);
      await scenarioDayExam(browser);
      await scenarioTheme(browser);
      await scenarioRole(browser);
      await scenarioDemoIsolation(browser);
      await scenarioLayout(browser);
      await scenarioFailures(browser);
      await scenarioFile(browser);
    }
    if (process.env.MARSA_SHOTS || process.env.MARSA_SHOTS_ONLY) await shots(browser);
  } catch (e) { check('الاختبار لم ينهَر في منتصفه', false, String((e && e.stack) || e).split('\n').slice(0, 4).join(' | ')); }
  var ext = allRequests.filter(function (u) { return !/^\S+ (http:\/\/localhost:\d+\/|file:\/\/|data:|blob:|about:)/.test(u); });
  check('لا طلبات شبكة خارجية في كل السيناريوهات (' + allRequests.length + ' طلباً، كلها من المصدر المحلي أو file://)', ext.length === 0 && (process.env.MARSA_SHOTS_ONLY || allRequests.length > 100), ext.slice(0, 5).join(' | ') + ' total=' + allRequests.length);
  check('لا استعمال لـinnerHTML وقت التشغيل في أي صفحة (مجسّ على Element.prototype يبقى صفراً عبر ' + pagesOpened + ' صفحة)', innerTotal === 0 && (process.env.MARSA_SHOTS_ONLY || pagesOpened > 20), 'innerHTML=' + innerTotal + ' pages=' + pagesOpened);
  check('لا أخطاء JS ولا أخطاء console في كل السيناريوهات', jsErrors.length === 0, jsErrors.slice(0, 6).join(' | '));
  await browser.close(); server.close();
  var failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed (of ' + results.length + ')');
  process.exit(failed.length ? 1 : 0);
})();
