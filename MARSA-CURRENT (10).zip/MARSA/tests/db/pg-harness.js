// 01.02 — مشغّل PostgreSQL محلي مؤقت لاختبارات المخطط. لا شبكة خارجية ولا حساب ولا بيانات حقيقية.
// يبني عنقوداً مؤقتاً (initdb) على 127.0.0.1 بمنفذ عشوائي، ويحمّل stubs-supabase.sql ثم schema-v2.sql، ويُغلقه ويحذفه عند الانتهاء.
// إن لم يتوفر PostgreSQL على الجهاز: available() = false ولا يُدّعى نجاح أي اختبار (انظر schema-v2.test.js).
'use strict';
const fs = require('fs'), os = require('os'), path = require('path'), cp = require('child_process');

const ROOT = path.join(__dirname, '..', '..');
const DB_DIR = path.join(ROOT, 'docs', 'execution-v2', 'db');

function findBin() {
  const bases = ['/usr/lib/postgresql', '/opt/homebrew/opt/postgresql@16/bin', '/usr/local/opt/postgresql@16/bin'];
  const cands = [];
  for (const b of bases) {
    if (!fs.existsSync(b)) continue;
    if (fs.existsSync(path.join(b, 'initdb'))) cands.push(b);
    else for (const v of fs.readdirSync(b).sort().reverse()) if (fs.existsSync(path.join(b, v, 'bin', 'initdb'))) cands.push(path.join(b, v, 'bin'));
  }
  return cands[0] || null;
}

const isRoot = typeof process.getuid === 'function' && process.getuid() === 0;
function run(bin, args, opts) {
  const o = Object.assign({ encoding: 'utf8' }, opts || {});
  if (isRoot) return cp.spawnSync('runuser', ['-u', 'postgres', '--', bin].concat(args), o);
  return cp.spawnSync(bin, args, o);
}

function available() {
  const bin = findBin();
  if (!bin) return { ok: false, why: 'لا توجد ثنائيات PostgreSQL (initdb) على هذا الجهاز' };
  const psql = cp.spawnSync('psql', ['--version'], { encoding: 'utf8' });
  if (psql.status !== 0) return { ok: false, why: 'لا يوجد عميل psql' };
  return { ok: true, bin, version: (cp.spawnSync(path.join(bin, 'postgres'), ['--version'], { encoding: 'utf8' }).stdout || '').trim() };
}

function startPg() {
  const av = available();
  if (!av.ok) throw new Error(av.why);
  const dir = fs.mkdtempSync(path.join(process.env.MARSA_PG_TMP || os.tmpdir(), 'marsa-pg-'));
  if (isRoot) cp.spawnSync('chown', ['-R', 'postgres:postgres', dir]);
  fs.chmodSync(dir, 0o700);
  const data = path.join(dir, 'data');
  const port = 40000 + Math.floor(Math.random() * 20000);
  let r = run(path.join(av.bin, 'initdb'), ['-D', data, '-E', 'UTF8', '--locale=C.UTF-8', '--auth=trust', '-U', 'postgres']);
  if (r.status !== 0) { cleanup(dir); throw new Error('initdb failed: ' + r.stderr); }
  r = run(path.join(av.bin, 'pg_ctl'), ['-D', data, '-w', '-l', path.join(dir, 'log.txt'), '-o',
    `-p ${port} -c listen_addresses=127.0.0.1 -c unix_socket_directories= -c fsync=off -c synchronous_commit=off -c full_page_writes=off`, 'start']);
  if (r.status !== 0) { const lg = fs.existsSync(path.join(dir, 'log.txt')) ? fs.readFileSync(path.join(dir, 'log.txt'), 'utf8') : ''; cleanup(dir); throw new Error('pg_ctl start failed: ' + r.stderr + lg); }
  const base = ['-X', '-q', '-h', '127.0.0.1', '-p', String(port), '-U', 'postgres'];
  function psql(sql, o) {
    o = o || {};
    const args = base.concat(['-d', o.db || 'postgres', '-v', 'ON_ERROR_STOP=1', '-A', '-t', '-F', '|']);
    const res = cp.spawnSync('psql', args, { input: sql, encoding: 'utf8', env: Object.assign({}, process.env, { PGCLIENTENCODING: 'UTF8' }) });
    return { code: res.status, out: (res.stdout || '').replace(/\n+$/, ''), err: (res.stderr || '').trim() };
  }
  function psqlAsync(sql, o) {
    o = o || {};
    const args = base.concat(['-d', o.db || 'postgres', '-v', 'ON_ERROR_STOP=1', '-A', '-t', '-F', '|']);
    const child = cp.spawn('psql', args, { env: Object.assign({}, process.env, { PGCLIENTENCODING: 'UTF8' }) });
    let out = '', err = '';
    child.stdout.on('data', (d) => { out += d; }); child.stderr.on('data', (d) => { err += d; });
    child.stdin.write(sql); child.stdin.end();
    return new Promise((res) => child.on('close', (code) => res({ code, out: out.replace(/\n+$/, ''), err: err.trim() })));
  }
  function stop() {
    run(path.join(av.bin, 'pg_ctl'), ['-D', data, '-m', 'immediate', '-w', 'stop']);
    cleanup(dir);
  }
  return { port, dir, version: av.version, psql, psqlAsync, stop };
}

function cleanup(dir) { try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* أفضل جهد */ } }

// قاعدة جديدة بالمخطط الكامل (للاختبارات التي تحتاج بيئة نظيفة).
function loadSchema(h, db, opts) {
  opts = opts || {};
  let r = h.psql('create database ' + db + ' encoding \'UTF8\' template template0 lc_collate \'C.UTF-8\' lc_ctype \'C.UTF-8\';');
  if (r.code !== 0) throw new Error('create database: ' + r.err);
  const stubs = fs.readFileSync(path.join(DB_DIR, 'stubs-supabase.sql'), 'utf8');
  const schema = opts.schemaText || fs.readFileSync(path.join(DB_DIR, 'schema-v2.sql'), 'utf8');
  r = h.psql(stubs, { db });
  if (r.code !== 0) throw new Error('stubs: ' + r.err);
  r = h.psql('begin;\n' + schema + '\ncommit;', { db });
  if (r.code !== 0) throw new Error('schema: ' + r.err);
  return r;
}

module.exports = { available, startPg, loadSchema, DB_DIR, ROOT };
