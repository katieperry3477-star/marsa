// 01.02 — اختبارات مخطط قاعدة بيانات V2 على PostgreSQL محلي فعلي (عنقود مؤقت).
// التشغيل: node tests/db/schema-v2.test.js        (متغير اختياري MARSA_PG_TMP لمجلد مؤقت يستطيع مستخدم postgres عبوره)
// إن لم يتوفر PostgreSQL: يطبع SKIP صريحاً ولا يحسب أي نجاح، ويخرج بالرمز 0.
// ما يختبره: المخطط والقيود والمشغّلات والتفرّد والإلحاق فقط والمجاميع والتزامن والأحجام. ما لا يختبره: سياسات RLS الحقيقية (03.03)،
// Supabase Auth/Storage/Realtime/Edge (المحاكاة stubs-supabase.sql تحاكي الأدوار وauth.uid() فقط).
'use strict';
const fs = require('fs'), path = require('path');
const H = require('./pg-harness.js');
const M = require('../security/access-matrix-v2.js').M;

const av = H.available();
if (!av.ok) { console.log('SKIP schema-v2 (لم يُختبر شيء): ' + av.why); process.exit(0); }

let pass = 0, fail = 0;
function t(name, ok, extra) { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra === undefined ? '' : String(extra).slice(0, 400)); } }

const pg = H.startPg();
process.on('exit', () => { try { pg.stop(); } catch (e) { /* مغلق */ } });
H.loadSchema(pg, 'm');
const DB = { db: 'm' };
const q = (sql) => { const r = pg.psql(sql, DB); if (r.code !== 0) throw new Error(r.err + '\nSQL: ' + sql.slice(0, 300)); return r.out; };
const G_ = (sql) => sql.replace(/select set_config\(([^;]*?)\);/g, (m, a) => 'select set_config(' + a + ') as _sc\n\\gset\n');
const _psql = pg.psql;
pg.psql = (sql, o) => _psql(G_(sql), o);
const tx = (sql) => pg.psql('begin;\n' + sql + '\nrollback;', DB);                 // ينفَّذ ويُتراجع عنه
const okTail = (name, sql, exp) => { const r = tx(sql); const n = String(exp).split('\n').length; t(name, r.code === 0 && r.out.split('\n').slice(-n).join('\n') === String(exp), r.code === 0 ? 'out=' + r.out : r.err); };
const okTx = (name, sql, expectOut) => { const r = tx(sql); t(name, r.code === 0 && (expectOut === undefined || r.out === String(expectOut)), r.code === 0 ? 'out=' + r.out : r.err); return r; };
const failTx = (name, sql, re) => { const r = tx(sql); t(name, r.code !== 0 && (!re || re.test(r.err)), r.code === 0 ? 'لم يفشل؛ out=' + r.out : r.err); return r; };

// ───────── بيانات اصطناعية ثابتة (لا بيانات حقيقية) ─────────
const ID = { dev: 'd0000000-0000-4000-8000-000000000001', rep1: 'd0000000-0000-4000-8000-000000000002', rep2: 'd0000000-0000-4000-8000-000000000003',
  s1: 'd0000000-0000-4000-8000-000000000011', s2: 'd0000000-0000-4000-8000-000000000012', s3: 'd0000000-0000-4000-8000-000000000013' };
const M_ = { dev: 'e0000000-0000-4000-8000-000000000001', rep1: 'e0000000-0000-4000-8000-000000000002', rep2: 'e0000000-0000-4000-8000-000000000003',
  s1: 'e0000000-0000-4000-8000-000000000011', s2: 'e0000000-0000-4000-8000-000000000012', s3: 'e0000000-0000-4000-8000-000000000013' };
const ST = { s1: 'f0000000-0000-4000-8000-000000000011', s2: 'f0000000-0000-4000-8000-000000000012', s3: 'f0000000-0000-4000-8000-000000000013' };
const A = q("select id from public.classes where name = 'الشعبة الأولى'");
q("insert into public.classes (id, name) values ('c0000000-0000-4000-8000-0000000000b2', 'الشعبة الثانية')");
const B = 'c0000000-0000-4000-8000-0000000000b2';
q(`insert into auth.users (id, email) values ${Object.values(ID).map((u) => `('${u}', '${u}@members.invalid')`).join(',')};
insert into public.students (id, class_id, full_name, phone) values
 ('${ST.s1}', '${A}', 'أحمد علي حسن', '07701110001'), ('${ST.s2}', '${A}', 'سارة محمد كريم', '07701110002'), ('${ST.s3}', '${B}', 'عمر خالد يوسف', '07701110003');
insert into public.members (id, user_id, role, display_name, status, activated_at) values ('${M_.dev}', '${ID.dev}', 'developer', 'المطوّر', 'active', now());
insert into public.members (id, user_id, role, class_id, display_name, status, activated_at) values
 ('${M_.rep1}', '${ID.rep1}', 'rep', '${A}', 'ممثل أ', 'active', now()), ('${M_.rep2}', '${ID.rep2}', 'rep', '${B}', 'ممثل ب', 'active', now());
insert into public.members (id, user_id, role, class_id, student_id, status, activated_at) values
 ('${M_.s1}', '${ID.s1}', 'student', '${A}', '${ST.s1}', 'active', now()), ('${M_.s2}', '${ID.s2}', 'student', '${A}', '${ST.s2}', 'active', now()),
 ('${M_.s3}', '${ID.s3}', 'student', '${B}', '${ST.s3}', 'active', now());`);
const asUser = (u, body, grants) => 'begin;\n' + (grants || []).map((g) => g + ';').join('\n') +
  `\nset local role authenticated;\nselect set_config('request.jwt.claim.sub', '${ID[u]}', true);\n` + body + '\nrollback;';
const HELP = `create function public.t_mem(sid uuid) returns uuid language sql security definer set search_path = '' as $f$ select id from public.members where student_id = sid $f$; grant execute on function public.t_mem(uuid) to authenticated; create function public.t_prep_live(pid uuid) returns boolean language sql security definer set search_path = '' as $f$ select exists (select 1 from public.preps where id = pid and archived_at is null) $f$; grant execute on function public.t_prep_live(uuid) to authenticated;`;
const HELP2 = `create function public.t_sheet_ok(sid uuid) returns boolean language sql security definer set search_path = '' as $f$ select exists (select 1 from public.attendance_sheets where id = sid and status = 'approved') $f$; grant execute on function public.t_sheet_ok(uuid) to authenticated;`;
const PRIV = ['select', 'insert', 'update'];
const uuid = (n) => '90000000-0000-4000-8000-' + String(n).padStart(12, '0');

// ═════════ 1) اتساق المخطط مع مصفوفة 01.01 ═════════
const ents = M.entities;
const TABLE_ENT = ents.filter((e) => !['storage_objects', 'storage_usage', 'roster_export', 'backup_export', 'backup_restore', 'cost_stats', 'record_history'].includes(e.id));
const schemaOf = (id) => (['activation_codes', 'activation_attempts'].includes(id) ? 'private' : 'public');
const rels = q("select n.nspname || '.' || c.relname || '|' || c.relkind::text from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and c.relkind in ('r','v')").split('\n');
const relSet = new Set(rels.map((r) => r.split('|')[0] + '|' + r.split('|')[1]));
t('DB-01 كل كيان جدولي في المصفوفة له جدول في المخطط (26)', TABLE_ENT.length === 26 && TABLE_ENT.every((e) => relSet.has(schemaOf(e.id) + '.' + e.id + '|r')), TABLE_ENT.filter((e) => !relSet.has(schemaOf(e.id) + '.' + e.id + '|r')).map((e) => e.id));
t('DB-02 view المصفوفة موجودان (cost_stats, record_history)', relSet.has('public.cost_stats|v') && relSet.has('public.record_history|v'));
t('DB-03 الكيانات غير الجدولية بلا جدول (storage/export/backup)', ['storage_objects', 'storage_usage', 'roster_export', 'backup_export', 'backup_restore'].every((id) => !relSet.has('public.' + id + '|r') && !relSet.has('private.' + id + '|r')));
const allTables = rels.filter((r) => r.endsWith('|r')).map((r) => r.split('|')[0]);
const expected = new Set(TABLE_ENT.map((e) => schemaOf(e.id) + '.' + e.id).concat(['private.record_revisions', 'private.audit_event_types']));
t('DB-04 لا جدول زائد ولا ناقص عن المصفوفة + جدولين داخليين فقط', allTables.length === expected.size && allTables.every((x) => expected.has(x)), allTables.filter((x) => !expected.has(x)));
const comments = Object.fromEntries(q("select n.nspname || '.' || c.relname || '|' || coalesce(obj_description(c.oid, 'pg_class'), '') from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and c.relkind in ('r','v')").split('\n').map((l) => l.split('|')).map((a) => [a[0], a.slice(1).join('|')]));
t('DB-05 صنف الحساسية في التوصيف يطابق المصفوفة لكل كيان', ents.filter((e) => comments[schemaOf(e.id) + '.' + e.id] !== undefined).every((e) => comments[schemaOf(e.id) + '.' + e.id].startsWith(e.cls + '|')),
  ents.filter((e) => comments[schemaOf(e.id) + '.' + e.id] !== undefined && !comments[schemaOf(e.id) + '.' + e.id].startsWith(e.cls + '|')).map((e) => e.id));
const cols = {}; q("select table_schema || '.' || table_name, column_name, data_type, is_nullable from information_schema.columns where table_schema in ('public','private')").split('\n').forEach((l) => { const [tb, c, ty, nl] = l.split('|'); (cols[tb] = cols[tb] || {})[c] = { ty, nullable: nl === 'YES' }; });
t('DB-06 عمود version موجود إذا وفقط إذا وسم version في المصفوفة', TABLE_ENT.every((e) => !!cols[schemaOf(e.id) + '.' + e.id].version === !!e.version), TABLE_ENT.filter((e) => !!cols[schemaOf(e.id) + '.' + e.id].version !== !!e.version).map((e) => e.id));
const hasA = (e) => Object.values(e.perms).some((p) => p.A && p.A !== 'none');
t('DB-07 كل كيان يملك عملية أرشفة في المصفوفة له archived_at أو revoked_at', TABLE_ENT.filter(hasA).every((e) => { const c = cols[schemaOf(e.id) + '.' + e.id]; return c.archived_at || c.revoked_at; }), TABLE_ENT.filter(hasA).filter((e) => { const c = cols[schemaOf(e.id) + '.' + e.id]; return !(c.archived_at || c.revoked_at); }).map((e) => e.id));
const NO_CLASS = ['classes', 'app_meta', 'system_settings', 'push_subscriptions', 'support_sessions', 'activation_attempts', 'audit_event_types'];
t('DB-08 class_id في كل جدول عدا الاستثناءات الموثقة', allTables.every((x) => cols[x].class_id || NO_CLASS.includes(x.split('.')[1]) || x === 'public.class_settings'), allTables.filter((x) => !cols[x].class_id && !NO_CLASS.includes(x.split('.')[1])));
t('DB-09 class_id إلزامي (NOT NULL) إلا في members وaudit_log', allTables.filter((x) => cols[x].class_id && !cols[x].class_id.nullable).length === allTables.filter((x) => cols[x].class_id).length - 2 && cols['public.members'].class_id.nullable && cols['public.audit_log'].class_id.nullable);
const fks = q(`select conrelid::regclass::text, confrelid::regclass::text, (select string_agg(attname, ',' order by ord) from unnest(conkey) with ordinality k(n, ord) join pg_attribute a on a.attrelid = conrelid and a.attnum = k.n)
  from pg_constraint where contype = 'f' and connamespace in ('public'::regnamespace, 'private'::regnamespace)`).split('\n').map((l) => l.split('|'));
const CLASS_SCOPED = ['students', 'attendance_sheets', 'preps', 'homework', 'exams', 'cost_items', 'cost_assignments', 'notifications'];
const refs = fks.filter((f) => CLASS_SCOPED.includes(f[1].replace('public.', '')));
t('DB-10 كل مفتاح أجنبي إلى جدول صفّي يتضمن class_id (لا ارتباط عابر للشعب)', refs.length >= 12 && refs.every((f) => f[2].split(',').includes('class_id')), refs.filter((f) => !f[2].split(',').includes('class_id')));
const ACTOR = ['created_by', 'updated_by', 'archived_by', 'approved_by', 'issued_by', 'revoked_by', 'status_changed_by', 'actor_member_id', 'support_target_member_id', 'developer_member_id', 'target_member_id', 'member_id'];
const idx = q(`select i.indrelid::regclass::text, (select string_agg(a.attname, ',' order by x.ord) from unnest(i.indkey) with ordinality x(n, ord) join pg_attribute a on a.attrelid = i.indrelid and a.attnum = x.n) from pg_index i where indrelid::regclass::text ~ '^(public|private)\\.|^[a-z_]+$'`).split('\n').map((l) => l.split('|'));
const noIdx = fks.filter((f) => !ACTOR.includes(f[2]) && f[0] !== 'audit_log' && !f[2].includes('class_id,')).filter((f) => f[2] !== 'class_id').filter((f) => !idx.some((i) => i[0] === f[0] && (i[1] + ',').startsWith(f[2].split(',')[0] + ',')));
t('DB-11 كل مفتاح أجنبي (عدا التوقيع/الفاعل وclass_id) مغطى بفهرس يبدأ بأعمدته', noIdx.length === 0, noIdx.map((f) => f[0] + '(' + f[2] + ')'));
const allCols = []; Object.entries(cols).forEach(([tb, cs]) => Object.keys(cs).forEach((c) => allCols.push(tb + '.' + c)));
t('DB-12 لا عمود رقم مدرسي ولا عملة ولا عنوان/موضوع/اسم مدرّس (R-037, R-054, R-066)', !allCols.some((c) => /(student_code|school_?(no|number)|student_number|currency|lesson|topic|teacher|\.title$)/.test(c) && !/announcements\.title|cost_items\.title|notifications\.title|cost_stats\.title/.test(c)), allCols.filter((c) => /(student_code|school_?(no|number)|student_number|currency|lesson|topic|teacher|\.title$)/.test(c) && !/announcements\.title|cost_items\.title|notifications\.title|cost_stats\.title/.test(c)));
t('DB-13 المفاتيح الأولية uuid (عدا مفردات الإعدادات والمركّب)', Object.entries(cols).every(([tb, cs]) => !cs.id || cs.id.ty === 'uuid' || ['public.app_meta', 'public.system_settings'].includes(tb)));
t('DB-14 لا عمود سرّي نصّي: لا pin/password/token/code صريح (code_hash وauth_key فقط)', !allCols.some((c) => /\.(pin|pin_hash|password|token|secret|code|otp)$/.test(c)), allCols.filter((c) => /\.(pin|password|token|secret|code|otp)$/.test(c)));
t('DB-15 النصوص المولَّدة: name_key وsubject_key', cols['public.students'].name_key && cols['public.grades'].subject_key && cols['public.preps'].subject_key);

// ═════════ 2) الدوال النقية ═════════
const f = (s) => q(`select private.fold_ar($$${s}$$)`);
t('DB-16 fold_ar: تشكيل وهمزات وة/ه وفراغات', f('  أَحْمَد   ') === 'احمد' && f('إنجليزي') === 'انجليزي' && f('مدرسة') === 'مدرسه' && f('ـعـلـي') === 'علي' && f('ٱلله') === 'الله');
t('DB-17 fold_ar: الأرقام العربية والفارسية واللاتينية الكبيرة', f('٠٧٧٠١٢٣') === '0770123' && f('۰۷۷۱') === '0771' && f('ABC') === 'abc' && q('select private.fold_ar(null)') === '');
const AS = require('../../js/academic-store.js').create();
const corpus = ['  إِنجليزي  مَدرسة ', 'الرِّياضيّات', 'آداب وأخلاق', 'علوم  الحياة', 'اللغة ـالعربية', 'ٱلتربية الإسلامية', 'Math', 'الكيمياء', 'أَحمد', 'إبراهيم', 'مُحَمَّد علي', 'فيزياء'];
t('DB-18 تكافؤ fold_ar مع foldText في V1 (لنصوص بلا أرقام)', corpus.every((s) => f(s) === AS.foldText(s)), corpus.filter((s) => f(s) !== AS.foldText(s)));
const jsToday = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Baghdad' });
const d1 = jsToday(), dq = q('select private.school_today()'), d2 = jsToday();
t('DB-19 school_today بتوقيت بغداد', dq === d1 || dq === d2, dq + ' vs ' + d1);

// ═════════ 3) الهوية والعضويات والطلاب ═════════
const NEWU = (n) => `insert into auth.users (id) values ('${uuid(n)}');`;
failTx('DB-20 دور رابع (مدرّس) يُرفض (R-003)', `insert into public.members (role, class_id, display_name) values ('teacher', '${A}', 'x');`, /members_role_check/);
failTx('DB-21 مطوّر ثانٍ يُرفض بأي مسار (R-012)', `insert into public.members (role, display_name) values ('developer', 'ثانٍ');`, /members_one_developer/);
failTx('DB-22 المطوّر لا يملك class_id والممثل يلزمه', `insert into public.members (role, class_id, display_name) values ('rep', null, 'x');`, /members_role_scope_chk/);
failTx('DB-23 الطالب يلزمه سجل طالب؛ الممثل لا يملكه', `insert into public.members (role, class_id) values ('student', '${A}');`, /members_student_link_chk|members_display_name_chk/);
failTx('DB-24 الطالب بلا اسم عرض (الاسم في students)', `insert into public.members (role, class_id, student_id, display_name) values ('student', '${A}', '${ST.s1}', 'x');`, /members_display_name_chk|members_one_per_student/);
failTx('DB-25 عضوية واحدة لكل طالب', `insert into public.members (role, class_id, student_id) values ('student', '${A}', '${ST.s1}');`, /members_one_per_student/);
failTx('DB-26 عضوية فعّالة ثانية لنفس مستخدم Auth تُرفض (T-77)', `insert into public.members (user_id, role, class_id, display_name, status, activated_at) values ('${ID.rep1}', 'rep', '${A}', 'مكرر', 'active', now());`, /members_one_live_per_user/);
okTx('DB-27 مستخدم جديد + عضوية مؤرشفة سابقة لا تتعارض', `${NEWU(1)} update public.members set status = 'archived' where id = '${M_.rep1}'; insert into public.members (user_id, role, class_id, display_name, status, activated_at) values ('${ID.rep1}', 'rep', '${A}', 'جديد', 'active', now());`);
failTx('DB-28 لا تعليق ولا أرشفة للمطوّر', `update public.members set status = 'suspended' where id = '${M_.dev}';`, /members_dev_status_chk/);
failTx('DB-29 عضوية فعّالة بلا مستخدم Auth تُرفض', `insert into public.members (role, class_id, display_name, status) values ('rep', '${A}', 'x', 'active');`, /members_active_user_chk/);
failTx('DB-30 user_id يُربط مرة واحدة', `${NEWU(2)} update public.members set user_id = '${uuid(2)}' where id = '${M_.rep1}';`, /bound once/);
failTx('DB-31 الدور وclass_id غير قابلين للتعديل', `update public.members set role = 'developer' where id = '${M_.rep1}';`, /immutable/);
failTx('DB-32 class_id للعضوية ثابت', `update public.members set class_id = '${B}' where id = '${M_.rep1}';`, /immutable/);
failTx('DB-33 لا عودة إلى pending', `update public.members set status = 'pending' where id = '${M_.rep1}';`, /pending/);
okTx('DB-34 تغيير الحالة يرفع session_epoch ويختم المؤرشف ويمسحه عند الاستعادة (ADR-307)', `update public.members set status = 'suspended' where id = '${M_.s1}'; update public.members set status = 'archived' where id = '${M_.s1}'; update public.members set status = 'active' where id = '${M_.s1}';
  select session_epoch || ',' || (archived_at is null) || ',' || (archived_by is null) from public.members where id = '${M_.s1}';`, '3,true,true');
okTx('DB-35 الأرشفة تضبط archived_at (قيد التطابق)', `update public.members set status = 'archived' where id = '${M_.s2}'; select (archived_at is not null) from public.members where id = '${M_.s2}';`, 't');
okTx('DB-36 طالبان بنفس الهاتف ينجحان وid لا يتغير بالتعديل (R-037)', `insert into public.students (class_id, full_name, phone) values ('${A}', 'كريم أحمد علي', '07701110001'); update public.students set full_name = 'أحمد علي حسين' where id = '${ST.s1}'; select count(*) from public.students where phone = '07701110001' and class_id = '${A}' and id = '${ST.s1}' or phone = '07701110001' and class_id = '${A}' and full_name = 'كريم أحمد علي';`, 2);
failTx('DB-37 id الطالب ثابت', `update public.students set id = gen_random_uuid() where id = '${ST.s1}';`, /immutable/);
failTx('DB-38 نقل طالب بين الشعب مرفوض', `update public.students set class_id = '${B}' where id = '${ST.s1}';`, /immutable/);
failTx('DB-39 هاتف غير صالح يُرفض', `insert into public.students (class_id, full_name, phone) values ('${A}', 'اسم ثلاثي هنا', 'abc12');`, /students_phone_check/);
failTx('DB-40 اسم فارغ أو بفراغات طرفية يُرفض', `insert into public.students (class_id, full_name, phone) values ('${A}', ' فلان ', '07701110009');`, /students_full_name_check/);
failTx('DB-41 هاتف مفقود يُرفض (R-036)', `insert into public.students (class_id, full_name) values ('${A}', 'أول ثاني ثالث');`, /null value.*phone/);
okTx('DB-42 ميلاد وغياب سابق اختياريان (افتراضي 0)', `insert into public.students (id, class_id, full_name, phone) values ('${uuid(9)}', '${A}', 'أول ثاني ثالث', '07701110009'); select prior_absences || ',' || (birth_date is null) from public.students where id = '${uuid(9)}';`, '0,true');
failTx('DB-43 غياب سابق خارج النطاق يُرفض', `update public.students set prior_absences = -1 where id = '${ST.s1}';`, /prior_absences/);
okTx('DB-44 بحث بالاسم بعد التوحيد (أحمد/أَحْمَد) والهاتف الجزئي', `select (select count(*) from public.students where name_key like '%' || private.fold_ar('أَحْمَد') || '%') || ',' || (select count(*) from public.students where phone like '%0111000%');`, '1,3');
failTx('DB-45 حذف صلب لطالب مرفوض (R-039)', `delete from public.students where id = '${ST.s1}';`, /hard delete/);
failTx('DB-46 تفريغ جدول الطلاب مرفوض', 'truncate public.students cascade;', /hard delete/);
okTx('DB-47 أرشفة الطالب تختم archived_by/at والسجلات باقية', `insert into public.attendance_sheets (id, class_id, school_date) values ('${uuid(20)}', '${A}', '2026-01-10'); insert into public.attendance_records (class_id, sheet_id, student_id) values ('${A}', '${uuid(20)}', '${ST.s1}');
  update public.students set archived_at = now() where id = '${ST.s1}'; select (select count(*) from public.attendance_records where student_id = '${ST.s1}') || ',' || (archived_at is not null) from public.students where id = '${ST.s1}';`, '1,true');
okTx('DB-48 إجمالي الغيابات = الرصيد السابق + أيام الغياب المسجلة، بلا سجلات من الرصيد (R-046)', `update public.students set prior_absences = 5 where id = '${ST.s1}';
  insert into public.attendance_sheets (id, class_id, school_date) values ('${uuid(21)}', '${A}', '2026-01-11'), ('${uuid(22)}', '${A}', '2026-01-12');
  insert into public.attendance_records (class_id, sheet_id, student_id, status) values ('${A}', '${uuid(21)}', '${ST.s1}', 'absent'), ('${A}', '${uuid(22)}', '${ST.s1}', 'late');
  select s.prior_absences + (select count(*) from public.attendance_records r where r.student_id = s.id and r.status = 'absent') || ',' || (select count(*) from public.attendance_records) from public.students s where s.id = '${ST.s1}';`, '6,2');

// ═════════ 4) رموز التفعيل ═════════
const HASH = (n) => `decode(lpad('${n}', 64, '0'), 'hex')`;
const CODE = (n, member, extra) => `insert into private.activation_codes (class_id, member_id, code_hash, purpose, issued_by, expires_at${extra ? ', ' + extra.cols : ''}) values ('${A}', '${member}', ${HASH(n)}, 'activate', '${M_.rep1}', now() + interval '7 days'${extra ? ', ' + extra.vals : ''});`;
okTx('DB-49 إصدار رمز لطالب وممثل', CODE(1, M_.s1) + CODE(2, M_.s2));
failTx('DB-50 لا رمز لعضوية المطوّر', `insert into private.activation_codes (class_id, member_id, code_hash, purpose, issued_by, expires_at) values ('${A}', '${M_.dev}', ${HASH(3)}, 'activate', '${M_.rep1}', now() + interval '1 day');`, /foreign key|target rep or student|targets rep or student/);
failTx('DB-51 بصمة بطول خاطئ تُرفض (لا نص صريح)', `insert into private.activation_codes (class_id, member_id, code_hash, purpose, issued_by, expires_at) values ('${A}', '${M_.s1}', '\\x1234', 'activate', '${M_.rep1}', now() + interval '1 day');`, /code_hash_check/);
failTx('DB-52 بصمة مكررة تُرفض', CODE(4, M_.s1) + CODE(4, M_.s2), /activation_codes_hash_key/);
failTx('DB-53 رمز نشط ثانٍ لنفس العضوية يُرفض', CODE(5, M_.s1) + CODE(6, M_.s1), /one_live_per_member/);
okTx('DB-54 إعادة الإصدار بعد إبطال القديم ناجحة وسجل الطالب نفسه (R-022)', CODE(7, M_.s1) + `update private.activation_codes set revoked_at = now(), revoked_by = '${M_.rep1}', revoke_reason = 'إعادة إصدار' where member_id = '${M_.s1}';` + CODE(8, M_.s1) + `select (select count(*) from private.activation_codes where member_id = '${M_.s1}') || ',' || (select count(*) from public.students where id = '${ST.s1}');`, '2,1');
okTx('DB-55 رمز مستهلك لا يمنع رمزاً جديداً', CODE(9, M_.s1) + `update private.activation_codes set consumed_at = now() where member_id = '${M_.s1}';` + CODE(10, M_.s1));
failTx('DB-56 صلاحية أطول من 30 يوماً تُرفض', `insert into private.activation_codes (class_id, member_id, code_hash, purpose, issued_by, expires_at) values ('${A}', '${M_.s1}', ${HASH(11)}, 'activate', '${M_.rep1}', now() + interval '31 days');`, /activation_codes_ttl_chk/);
failTx('DB-57 لا يجتمع الاستهلاك والإبطال', CODE(12, M_.s1) + `update private.activation_codes set consumed_at = now(), revoked_at = now(), revoked_by = '${M_.rep1}' where member_id = '${M_.s1}';`, /activation_codes_final_chk/);
failTx('DB-58 بصمة الرمز غير قابلة للتعديل', CODE(13, M_.s1) + `update private.activation_codes set code_hash = ${HASH(14)} where member_id = '${M_.s1}';`, /immutable/);
failTx('DB-59 الاستهلاك نهائي', CODE(15, M_.s1) + `update private.activation_codes set consumed_at = now() where member_id = '${M_.s1}'; update private.activation_codes set consumed_at = null where member_id = '${M_.s1}';`, /final/);
failTx('DB-60 الإبطال نهائي', CODE(16, M_.s1) + `update private.activation_codes set revoked_at = now(), revoked_by = '${M_.rep1}' where member_id = '${M_.s1}'; update private.activation_codes set revoked_at = null, revoked_by = null where member_id = '${M_.s1}';`, /final/);
failTx('DB-61 عضوية من شعبة أخرى لا ترتبط برمز شعبة أ', `insert into private.activation_codes (class_id, member_id, code_hash, purpose, issued_by, expires_at) values ('${A}', '${M_.s3}', ${HASH(17)}, 'activate', '${M_.rep1}', now() + interval '1 day');`, /activation_codes_member_fk/);
okTx('DB-62 محاولات التفعيل: نتيجة وبصمة عنوان صالحتان', `insert into private.activation_attempts (outcome, ip_hash) values ('invalid', decode(repeat('ab', 32), 'hex'));`);
failTx('DB-63 نتيجة محاولة غير معروفة تُرفض', `insert into private.activation_attempts (outcome) values ('weird');`, /outcome_check/);
failTx('DB-64 بصمة عنوان بطول خاطئ (IP خام) تُرفض', `insert into private.activation_attempts (outcome, ip_hash) values ('invalid', '\\x7f000001');`, /ip_hash_check/);

// ═════════ 5) الحضور ═════════
const SHEET = (id, d, cls) => `insert into public.attendance_sheets (id, class_id, school_date) values ('${id}', '${cls || A}', '${d}');`;
failTx('DB-65 كشف واحد لكل (شعبة، تاريخ) (R-042)', SHEET(uuid(30), '2026-02-01') + SHEET(uuid(31), '2026-02-01'), /attendance_sheets_day_key/);
okTx('DB-66 نفس التاريخ في شعبتين مختلفتين مسموح (تعدد الشعب)', SHEET(uuid(30), '2026-02-01') + SHEET(uuid(31), '2026-02-01', B));
failTx('DB-67 سجل واحد لكل (كشف، طالب)', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (class_id, sheet_id, student_id) values ('${A}', '${uuid(30)}', '${ST.s1}'), ('${A}', '${uuid(30)}', '${ST.s1}');`, /attendance_records_one_key/);
failTx('DB-68 حالة غير معتمدة (مرض) تُرفض', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (class_id, sheet_id, student_id, status) values ('${A}', '${uuid(30)}', '${ST.s1}', 'sick');`, /attendance_records_status_check/);
okTx('DB-69 الحالات الخمس مقبولة، والافتراضي حاضر (R-043)', SHEET(uuid(30), '2026-02-01') + `insert into public.students (id, class_id, full_name, phone) values ('${uuid(40)}','${A}','ا ب ج','07700000041'),('${uuid(41)}','${A}','ا ب ج','07700000042'),('${uuid(42)}','${A}','ا ب ج','07700000043');
  insert into public.attendance_records (class_id, sheet_id, student_id, status) values ('${A}','${uuid(30)}','${ST.s1}','absent'),('${A}','${uuid(30)}','${ST.s2}','excused'),('${A}','${uuid(30)}','${uuid(40)}','late'),('${A}','${uuid(30)}','${uuid(41)}','exceptional'),('${A}','${uuid(30)}','${uuid(42)}', default);
  select string_agg(status, ',' order by status) from public.attendance_records;`, 'absent,exceptional,excused,late,present');
failTx('DB-70 سجل بطالب من شعبة أخرى في كشف شعبة أ يُرفض', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (class_id, sheet_id, student_id) values ('${A}', '${uuid(30)}', '${ST.s3}');`, /attendance_records_student_fk/);
failTx('DB-71 سجل بكشف من شعبة أخرى يُرفض', SHEET(uuid(31), '2026-02-01', B) + `insert into public.attendance_records (class_id, sheet_id, student_id) values ('${A}', '${uuid(31)}', '${ST.s1}');`, /attendance_records_sheet_fk/);
failTx('DB-72 اعتماد كشف ناقص يُرفض (R-044)', SHEET(uuid(30), '2026-02-01') + `update public.attendance_sheets set status = 'approved', approved_at = now(), approved_by = '${M_.rep1}' where id = '${uuid(30)}';`, /sheet incomplete/);
const COMPLETE = (sid) => `insert into public.attendance_records (class_id, sheet_id, student_id) select class_id, '${sid}', id from public.students where class_id = '${A}' and archived_at is null;`;
okTx('DB-73 اعتماد كشف مكتمل يقفله ويختم المعتمِد', SHEET(uuid(30), '2026-02-01') + COMPLETE(uuid(30)) + `update public.attendance_sheets set status = 'approved', approved_at = now(), approved_by = '${M_.rep1}' where id = '${uuid(30)}'; select status from public.attendance_sheets where id = '${uuid(30)}';`, 'approved');
failTx('DB-74 الاعتماد بلا معتمِد يُرفض', SHEET(uuid(30), '2026-02-01') + COMPLETE(uuid(30)) + `update public.attendance_sheets set status = 'approved', approved_at = now() where id = '${uuid(30)}';`, /approval_chk/);
failTx('DB-75 كشف معتمد لا يعود مسودة', SHEET(uuid(30), '2026-02-01') + COMPLETE(uuid(30)) + `update public.attendance_sheets set status = 'approved', approved_at = now(), approved_by = '${M_.rep1}' where id = '${uuid(30)}'; update public.attendance_sheets set status = 'draft', approved_at = null, approved_by = null where id = '${uuid(30)}';`, /cannot return to draft/);
failTx('DB-76 تاريخ الكشف ثابت', SHEET(uuid(30), '2026-02-01') + `update public.attendance_sheets set school_date = '2026-02-02' where id = '${uuid(30)}';`, /immutable/);
okTx('DB-77 تعديل الحالة يسجل القديم والجديد والفاعل والوقت (R-045)', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}');
  select set_config('request.jwt.claim.sub', '${ID.rep1}', true); update public.attendance_records set status = 'absent', note = 'مراجعة' where id = '${uuid(50)}';
  select action || ',' || (changes->'status'->>'old') || ',' || (changes->'status'->>'new') || ',' || (actor_member_id = '${M_.rep1}') || ',' || (at is not null) || ',' || version from private.record_revisions where record_id = '${uuid(50)}';`, 'update,present,absent,true,true,2');
okTx('DB-78 تعديل بلا تغيير في أعمدة العمل لا يسجل مراجعة', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}'); update public.attendance_records set status = status where id = '${uuid(50)}'; select count(*) from private.record_revisions;`, 0);
okTx('DB-79 version يزداد وupdated_at يتقدم وupdated_by يُفرض من الفاعل', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}');
  select set_config('request.jwt.claim.sub', '${ID.rep1}', true); update public.attendance_records set status = 'late' where id = '${uuid(50)}'; update public.attendance_records set status = 'absent' where id = '${uuid(50)}';
  select version || ',' || (updated_by = '${M_.rep1}') from public.attendance_records where id = '${uuid(50)}';`, '3,true');
okTx('DB-80 أرشفة السجل تُسجَّل «archive» وتختم archived_by', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}');
  select set_config('request.jwt.claim.sub', '${ID.rep1}', true); update public.attendance_records set archived_at = now() where id = '${uuid(50)}';
  select (select action from private.record_revisions where record_id = '${uuid(50)}') || ',' || (archived_by = '${M_.rep1}') from public.attendance_records where id = '${uuid(50)}';`, 'archive,true');
failTx('DB-81 حذف صلب لسجل حضور مرفوض', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}'); delete from public.attendance_records;`, /hard delete/);
failTx('DB-82 معرّفات السجل (sheet_id, student_id) ثابتة', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}'); update public.attendance_records set student_id = '${ST.s2}' where id = '${uuid(50)}';`, /immutable/);
failTx('DB-83 ملاحظة أطول من 200 تُرفض', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (class_id, sheet_id, student_id, note) values ('${A}', '${uuid(30)}', '${ST.s1}', repeat('x', 201));`, /note_check/);

// ═════════ 6) الدرجات ═════════
const G = (cols, vals) => `insert into public.grades (class_id, student_id, ${cols}) values ('${A}', '${ST.s1}', ${vals});`;
okTx('DB-84 درجة شهرية بشهر ونهائية/نصف سنة بلا شهر (R-048)', G('subject, term, period_month, score, max_score', `'الرياضيات', 'monthly', 10, 45, 50`) + G('subject, term, score, max_score', `'الرياضيات', 'midyear', 80, 100`) + G('subject, term, score, max_score', `'الرياضيات', 'final', 9, 10`));
failTx('DB-85 فئة خارج الثلاث تُرفض', G('subject, term, score, max_score', `'الرياضيات', 'weekly', 1, 10`), /grades_term_check/);
failTx('DB-86 الشهرية بلا شهر تُرفض', G('subject, term, score, max_score', `'الرياضيات', 'monthly', 1, 10`), /grades_period_chk/);
failTx('DB-87 النصفية مع شهر تُرفض', G('subject, term, period_month, score, max_score', `'الرياضيات', 'midyear', 3, 1, 10`), /grades_period_chk/);
failTx('DB-88 الدرجة أكبر من العظمى تُرفض (R-049)', G('subject, term, score, max_score', `'الرياضيات', 'final', 11, 10`), /grades_range_chk/);
failTx('DB-89 الدرجة السالبة تُرفض', G('subject, term, score, max_score', `'الرياضيات', 'final', -1, 10`), /grades_range_chk/);
failTx('DB-90 العظمى صفر أو فوق 1000 تُرفض', G('subject, term, score, max_score', `'الرياضيات', 'final', 0, 0`), /grades_range_chk/);
okTx('DB-91 الدرجة 0 والدرجة = العظمى مقبولتان بدقة منزلتين', G('subject, term, score, max_score', `'علوم', 'final', 0, 10`) + G('subject, term, score, max_score', `'عربي', 'final', 99.55, 99.55`) + `select max_score from public.grades where subject = 'عربي';`, '99.55');
failTx('DB-92 درجة حية مكررة لنفس (طالب، مادة موحّدة، فئة، شهر) تُرفض', G('subject, term, score, max_score', `'إنجليزي', 'final', 5, 10`) + G('subject, term, score, max_score', `'انجليزي', 'final', 6, 10'`.replace("10'", '10')), /grades_one_live_idx/);
okTx('DB-93 بعد أرشفة القديمة تُقبل درجة جديدة لنفس المفتاح', G('subject, term, score, max_score', `'إنجليزي', 'final', 5, 10`) + `update public.grades set archived_at = now();` + G('subject, term, score, max_score', `'إنجليزي', 'final', 6, 10`));
okTx('DB-94 شهرا مختلفان لنفس المادة مقبولان', G('subject, term, period_month, score, max_score', `'عربي', 'monthly', 10, 1, 10`) + G('subject, term, period_month, score, max_score', `'عربي', 'monthly', 11, 1, 10`));
okTx('DB-95 تعديل الدرجة يسجل مراجعة بالقيم القديمة والجديدة', G('subject, term, score, max_score', `'عربي', 'final', 5, 10`) + `update public.grades set score = 7; select (changes->'score'->>'old') || '>' || (changes->'score'->>'new') from private.record_revisions where entity = 'grades';`, '5.00>7.00');
okTx('DB-96 قاعدة المعدل الافتراضية متوسط النسب (R-050)', `select grade_rule from public.class_settings where class_id = '${A}';`, 'mean_percent');

// ═════════ 7) الجدول والامتحانات والتحاضير والواجبات ═════════
failTx('DB-97 جدول: يوم خارج مفاتيح V1 يُرفض', `insert into public.schedule_entries (class_id, weekday, subject) values ('${A}', 'xyz', 'عربي');`, /weekday_check/);
failTx('DB-98 جدول: حصة 31 تُرفض', `insert into public.schedule_entries (class_id, weekday, subject, period_no) values ('${A}', 'sun', 'عربي', 31);`, /period_no_check/);
failTx('DB-99 جدول: نهاية قبل البداية تُرفض', `insert into public.schedule_entries (class_id, weekday, subject, start_time, end_time) values ('${A}', 'sun', 'عربي', '09:00', '08:00');`, /schedule_entries_time_chk/);
okTx('DB-100 جدول: إدخال صحيح بالأيام السبعة', `insert into public.schedule_entries (class_id, weekday, subject, period_no, start_time, end_time) select '${A}', d, 'عربي', 1, '08:00', '08:45' from unnest(array['sat','sun','mon','tue','wed','thu','fri']) d; select count(*) from public.schedule_entries;`, 7);
okTx('DB-101 امتحان: المادة والموعد مطلوبان والوقت اختياري (R-051)', `insert into public.exams (class_id, subject, exam_date) values ('${A}', 'فيزياء', '2026-03-01'); select start_time is null from public.exams;`, 't');
failTx('DB-102 امتحان بلا موعد يُرفض', `insert into public.exams (class_id, subject) values ('${A}', 'فيزياء');`, /null value.*exam_date/);
okTx('DB-103 تحضير: التاريخ الداخلي يُملأ تلقائياً باليوم الدراسي (R-053)', `insert into public.preps (class_id, subject) values ('${A}', 'عربي'); select school_date = private.school_today() from public.preps;`, 't');
failTx('DB-104 تحضير بلا مادة يُرفض', `insert into public.preps (class_id, subject) values ('${A}', '');`, /subject_check/);
const PREP = (id, d, subj) => `insert into public.preps (id, class_id, subject, school_date) values ('${id}', '${A}', '${subj || 'عربي'}', '${d || '2026-03-01'}');`;
okTx('DB-105 حالات الإغلاق الثلاث، والتأجيل بتاريخ لاحق بلا نسخ (R-058)', PREP(uuid(60)) + PREP(uuid(61)) + PREP(uuid(62)) +
  `insert into public.prep_status (class_id, prep_id, status) values ('${A}', '${uuid(60)}', 'taken'), ('${A}', '${uuid(61)}', 'not_taken');
   insert into public.prep_status (class_id, prep_id, status, postponed_to_date) values ('${A}', '${uuid(62)}', 'postponed', '2026-03-05');
   select (select count(*) from public.preps) || ',' || (select count(*) from public.prep_status);`, '3,3');
failTx('DB-106 «تأجل» بلا تاريخ يُرفض', PREP(uuid(60)) + `insert into public.prep_status (class_id, prep_id, status) values ('${A}', '${uuid(60)}', 'postponed');`, /prep_status_postpone_chk/);
failTx('DB-107 تاريخ تأجيل مع حالة أخرى يُرفض', PREP(uuid(60)) + `insert into public.prep_status (class_id, prep_id, status, postponed_to_date) values ('${A}', '${uuid(60)}', 'taken', '2026-03-05');`, /prep_status_postpone_chk/);
failTx('DB-108 التأجيل إلى يوم ليس بعد يوم التحضير يُرفض', PREP(uuid(60)) + `insert into public.prep_status (class_id, prep_id, status, postponed_to_date) values ('${A}', '${uuid(60)}', 'postponed', '2026-03-01');`, /after the prep day/);
failTx('DB-109 حالة واحدة لكل تحضير', PREP(uuid(60)) + `insert into public.prep_status (class_id, prep_id, status) values ('${A}', '${uuid(60)}', 'taken'), ('${A}', '${uuid(60)}', 'not_taken');`, /prep_status_one_key/);
failTx('DB-110 حالة تحضير لتحضير من شعبة أخرى تُرفض', PREP(uuid(60)) + `insert into public.prep_status (class_id, prep_id, status) values ('${B}', '${uuid(60)}', 'taken');`, /prep_status_prep_fk/);
okTx('DB-111 واجب مرتبط بتحضير يرث المادة واليوم (لا تكرار، R-062)', PREP(uuid(60)) + `insert into public.homework (class_id, prep_id, body) values ('${A}', '${uuid(60)}', 'حل التمارين'); select (subject is null) || ',' || (school_date is null) from public.homework;`, 'true,true');
failTx('DB-112 واجب مرتبط يكرّر المادة يُرفض', PREP(uuid(60)) + `insert into public.homework (class_id, prep_id, subject, school_date, body) values ('${A}', '${uuid(60)}', 'عربي', '2026-03-01', 'x');`, /homework_inherit_chk/);
okTx('DB-113 واجب قائم بذاته بمادة ويوم', `insert into public.homework (class_id, subject, school_date, body) values ('${A}', 'عربي', '2026-03-01', 'قراءة'); select subject_key from public.homework;`, 'عربي');
failTx('DB-114 واجب قائم بلا مادة أو يوم يُرفض', `insert into public.homework (class_id, body) values ('${A}', 'x');`, /homework_inherit_chk/);
failTx('DB-115 واجب حي واحد لكل تحضير', PREP(uuid(60)) + `insert into public.homework (class_id, prep_id, body) values ('${A}', '${uuid(60)}', 'a'), ('${A}', '${uuid(60)}', 'b');`, /homework_one_per_prep_idx/);
failTx('DB-116 واجب بتحضير من شعبة أخرى يُرفض', PREP(uuid(60)) + `insert into public.homework (class_id, prep_id, body) values ('${B}', '${uuid(60)}', 'a');`, /homework_prep_fk/);
okTx('DB-117 تثبيت التحضير وإلغاؤه (R-061)', PREP(uuid(60)) + `update public.preps set pinned_at = now(); update public.preps set pinned_at = null; select pinned_at is null from public.preps;`, 't');
okTx('DB-118 التحضير القديم باقٍ ومبحوث عنه بعد تغيّر اليوم؛ لا حذف (R-057)', PREP(uuid(60), '2026-01-01', 'الرِّياضيات') + `select count(*) from public.preps where subject_key = private.fold_ar('الرياضيات') and school_date < private.school_today();`, 1);
failTx('DB-119 حذف تحضير مرفوض', PREP(uuid(60)) + `delete from public.preps;`, /hard delete/);
// المرفقات
const PATH = (cls, kind, n, ext) => `${cls}/${kind}/90000000-0000-4000-8000-${String(n).padStart(12, '0')}.${ext || 'jpg'}`;
const FILE = (parent, val, n, o) => { o = o || {}; return `insert into public.file_objects (class_id, ${parent}, storage_path, mime_type, byte_size, sha256${o.extraCols || ''}) values ('${o.cls || A}', '${val}', '${o.path || PATH(o.cls || A, parent.replace('_id', ''), n, o.ext)}', '${o.mime || 'image/jpeg'}', ${o.size || 200000}, decode(repeat('ab', 32), 'hex')${o.extraVals || ''});`; };
okTx('DB-120 مرفق صورة وPDF على تحضير (صور وPDF أولاً)', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1) + FILE('prep_id', uuid(60), 2, { mime: 'application/pdf', ext: 'pdf', size: 1500000 }));
failTx('DB-121 SVG يُرفض', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { mime: 'image/svg+xml' }), /mime_type_check/);
failTx('DB-122 صورة فوق 2MB تُرفض', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { size: 2097153 }), /file_objects_size_chk/);
failTx('DB-123 PDF فوق 3MB يُرفض', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { mime: 'application/pdf', ext: 'pdf', size: 3145729 }), /file_objects_size_chk/);
failTx('DB-124 مسار لا يبدأ بـclass_id يُرفض', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { path: PATH(B, 'prep', 1) }), /file_objects_path_chk/);
failTx('DB-125 مسار بامتداد/نوع مجلد خاطئ يُرفض', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { path: `${A}/other/90000000-0000-4000-8000-000000000001.jpg` }), /file_objects_path_chk/);
failTx('DB-126 مسار مكرر يُرفض', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1) + FILE('prep_id', uuid(60), 1), /file_objects_path_key/);
failTx('DB-127 مرفق بلا أصل أو بأكثر من أصل يُرفض', `insert into public.file_objects (class_id, storage_path, mime_type, byte_size, sha256) values ('${A}', '${PATH(A, 'prep', 1)}', 'image/jpeg', 10, decode(repeat('ab', 32), 'hex'));`, /file_objects_one_parent_chk/);
failTx('DB-128 مرفق في شعبة أ لتحضير شعبة ب يُرفض', `insert into public.preps (id, class_id, subject) values ('${uuid(63)}', '${B}', 'عربي');` + FILE('prep_id', uuid(63), 1), /file_objects_prep_fk/);
failTx('DB-129 المرفق ثابت: مساره لا يتغير (الاستبدال = سجل جديد)', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1) + `update public.file_objects set storage_path = '${PATH(A, 'prep', 2)}';`, /immutable/);
okTx('DB-130 مرفقات الواجب والامتحان', `insert into public.exams (id, class_id, subject, exam_date) values ('${uuid(64)}', '${A}', 'فيزياء', '2026-03-01'); insert into public.homework (id, class_id, subject, school_date, body) values ('${uuid(65)}', '${A}', 'عربي', '2026-03-01', 'x');` + FILE('exam_id', uuid(64), 3) + FILE('homework_id', uuid(65), 4));
failTx('DB-131 مصغّر فوق 100KB يُرفض', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { extraCols: ', thumb_byte_size', extraVals: ', 102401' }), /thumb_byte_size_check/);
// السقف الناعم
const QUOTA = (n) => `update public.system_settings set storage_quota_bytes = ${n};`;
okTx('DB-132 استخدام التخزين: مستويات ok/warn/strong/reject وفق العتبات (ADR-312)', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { size: 1000 }) + QUOTA(10000) +
  `select level from private.storage_usage(); ` + QUOTA(1428) + `select level from private.storage_usage();` + QUOTA(1100) + `select level from private.storage_usage();` + QUOTA(1050) + `select level from private.storage_usage();`.replace(/\n/g, ' '), 'ok\nwarn\nstrong\nreject');
failTx('DB-133 رفع جديد مرفوض عند بلوغ عتبة الرفض 95%', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { size: 900 }) + QUOTA(1000) + FILE('prep_id', uuid(60), 2, { size: 100 }), /storage_quota_exceeded/);
okTx('DB-134 الملف المؤرشف يشغل مساحة ويُحتسب', PREP(uuid(60)) + FILE('prep_id', uuid(60), 1, { size: 5000 }) + `update public.file_objects set archived_at = now(); select used_bytes from private.storage_usage(null);`, 5000);

// ═════════ 8) التكاليف والدفعات ═════════
const ITEM = (id, amt) => `insert into public.cost_items (id, class_id, title, amount) values ('${id}', '${A}', 'ملزمة الرياضيات', ${amt || 3000});`;
const ASSIGN = (id, item, st, due) => `insert into public.cost_assignments (id, class_id, cost_item_id, student_id${due !== undefined ? ', amount_due' : ''}) values ('${id}', '${A}', '${item}', '${st}'${due !== undefined ? ', ' + due : ''});`;
const PAY = (id, as, st, amt) => `insert into public.payments (id, class_id, assignment_id, student_id, amount) values ('${id}', '${A}', '${as}', '${st}', ${amt});`;
okTx('DB-135 إنشاء بند ينشئ صفاً لكل طالب فعّال بحالة «لم يدفع» (R-063)', ITEM(uuid(70)) + `update public.students set archived_at = now() where id = '${ST.s2}';
  insert into public.cost_assignments (class_id, cost_item_id, student_id) select class_id, '${uuid(70)}', id from public.students where class_id = '${A}' and archived_at is null;
  select count(*) || ',' || min(pay_status) || ',' || min(amount_due) from public.cost_assignments;`, '1,unpaid,3000');
failTx('DB-136 مبلغ البند صفر أو سالب أو كسري يُرفض (أعداد صحيحة، R-066)', `insert into public.cost_items (class_id, title, amount) values ('${A}', 'x', 0);`, /cost_items_amount_check/);
okTx('DB-137 دفعة جزئية ثم الباقي: المجموع والحالة والمتبقي (R-064)', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 400) +
  `select paid_total || ',' || pay_status || ',' || (amount_due - paid_total) from public.cost_assignments;` + PAY(uuid(73), uuid(71), ST.s1, 600) + `select paid_total || ',' || pay_status from public.cost_assignments;`, 'x'.length && '400,partial,600\n1000,paid');
failTx('DB-138 دفعة تتجاوز المتبقي تُرفض (قرار E-016)', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 1001), /paid_le_due_chk/);
okTx('DB-139 إبطال دفعة يعيد المتبقي والحالة (E-009)', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 1000) +
  `update public.payments set archived_at = now(), archive_reason = 'خطأ إدخال' where id = '${uuid(72)}'; select paid_total || ',' || pay_status from public.cost_assignments;`, '0,unpaid');
failTx('DB-140 الإبطال بلا سبب يُرفض', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 100) + `update public.payments set archived_at = now() where id = '${uuid(72)}';`, /void_reason_chk/);
failTx('DB-141 الإبطال نهائي (لا تراجع)', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 100) + `update public.payments set archived_at = now(), archive_reason = 'x' where id = '${uuid(72)}'; update public.payments set archived_at = null, archive_reason = null where id = '${uuid(72)}';`, /final/);
failTx('DB-142 تعديل مبلغ دفعة مرفوض (للإلحاق فقط)', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 100) + `update public.payments set amount = 50;`, /append-only/);
failTx('DB-143 حذف دفعة مرفوض', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 100) + `delete from public.payments;`, /hard delete/);
failTx('DB-144 دفعة لإسناد مؤرشف تُرفض', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + `update public.cost_assignments set archived_at = now();` + PAY(uuid(72), uuid(71), ST.s1, 100), /archived assignment/);
failTx('DB-145 دفعة بطالب غير صاحب الإسناد تُرفض', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s2, 100), /payments_assignment_fk/);
failTx('DB-146 تعديل paid_total مباشرة مرفوض', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + `update public.cost_assignments set paid_total = 500;`, /maintained by payment triggers/);
failTx('DB-147 إدراج إسناد بـpaid_total غير صفر مرفوض', ITEM(uuid(70), 1000) + `insert into public.cost_assignments (class_id, cost_item_id, student_id, paid_total) values ('${A}', '${uuid(70)}', '${ST.s1}', 10);`, /starts at zero|paid_total/);
failTx('DB-148 خفض المستحق دون المدفوع مرفوض', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 600) + `update public.cost_assignments set amount_due = 500;`, /paid_le_due_chk/);
okTx('DB-149 مستحق صفر (إعفاء) = مدفوع', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1, 0) + `select pay_status from public.cost_assignments;`, 'paid');
failTx('DB-150 إسناد البند للطالب نفسه مرتين يُرفض', ITEM(uuid(70)) + ASSIGN(uuid(71), uuid(70), ST.s1) + ASSIGN(uuid(72), uuid(70), ST.s1), /cost_assignments_one_key/);
failTx('DB-151 إسناد بند شعبة أ لطالب شعبة ب يُرفض', ITEM(uuid(70)) + ASSIGN(uuid(71), uuid(70), ST.s3), /cost_assignments_student_fk/);
okTx('DB-152 الإجماليات = مجموع الصفوف وcost_stats مطابق (R-065)', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + ASSIGN(uuid(72), uuid(70), ST.s2) + PAY(uuid(73), uuid(71), ST.s1, 1000) + PAY(uuid(74), uuid(72), ST.s2, 250) +
  `select students_count || ',' || due_total || ',' || paid_total || ',' || remaining_total || ',' || paid_count || ',' || partial_count || ',' || unpaid_count from public.cost_stats;`, '2,2000,1250,750,1,1,0');
okTx('DB-153 verify_cost_totals نظيف، ويكشف انحرافاً مُتعمَّداً', ITEM(uuid(70), 1000) + ASSIGN(uuid(71), uuid(70), ST.s1) + PAY(uuid(72), uuid(71), ST.s1, 100) +
  `select count(*) from private.verify_cost_totals(); set local session_replication_role = replica; update public.cost_assignments set paid_total = 999; set local session_replication_role = origin; select count(*) from private.verify_cost_totals();`, '0\n1');

// ═════════ 9) الإعلانات والإشعارات ═════════
okTx('DB-154 إعلان واحد = إشعار واحد بعنوانه (R-069)', `insert into public.announcements (class_id, title, body) values ('${A}', 'اجتماع أولياء', 'غداً'); select count(*) || ',' || min(title) || ',' || min(kind) || ',' || min(event) from public.notifications;`, '1,اجتماع أولياء,announcement,created');
okTx('DB-155 تحضير وامتحان جديدان يولّدان إشعارين بلا بيانات شخصية', PREP(uuid(60)) + `insert into public.exams (class_id, subject, exam_date) values ('${A}', 'فيزياء', '2026-03-01'); select string_agg(title, ' | ' order by kind) from public.notifications;`, 'امتحان جديد: فيزياء | تحضير جديد: عربي');
okTx('DB-156 تعديل خلال 10 دقائق من الإنشاء لا يكرّر الإشعار', PREP(uuid(60)) + `update public.preps set notes = 'تعديل'; select count(*) from public.notifications;`, 1);
okTx('DB-157 تعديل لاحق (بعد 10 دقائق) يولّد إشعار «معدّل» واحداً', PREP(uuid(60)) + `set local session_replication_role = replica; update public.notifications set created_at = created_at - interval '1 hour'; set local session_replication_role = origin;
  update public.preps set notes = 'تعديل'; update public.preps set notes = 'تعديل ثانٍ'; select count(*) || ',' || max(title) filter (where event = 'updated') from public.notifications;`, '2,تحضير معدّل: عربي');
okTx('DB-158 التثبيت والأرشفة لا يولّدان إشعاراً', PREP(uuid(60)) + `set local session_replication_role = replica; update public.notifications set created_at = created_at - interval '1 hour'; set local session_replication_role = origin;
  update public.preps set pinned_at = now(); update public.preps set archived_at = now(); select count(*) from public.notifications;`, 1);
failTx('DB-159 الإشعار للإلحاق فقط (لا تعديل)', PREP(uuid(60)) + `update public.notifications set title = 'x';`, /append-only/);
okTx('DB-160 حالة القراءة: مرة لكل (عضو، إشعار) وبصفّ الإشعار نفسه', PREP(uuid(60)) + `insert into public.notification_reads (notification_id, member_id, class_id) select id, '${M_.s1}', class_id from public.notifications; select count(*) from public.notification_reads;`, 1);
failTx('DB-161 قراءة مكررة تُرفض', PREP(uuid(60)) + `insert into public.notification_reads (notification_id, member_id, class_id) select id, '${M_.s1}', class_id from public.notifications; insert into public.notification_reads (notification_id, member_id, class_id) select id, '${M_.s1}', class_id from public.notifications;`, /notification_reads_pkey/);
failTx('DB-162 حالة قراءة بشعبة غير شعبة الإشعار تُرفض', PREP(uuid(60)) + `insert into public.notification_reads (notification_id, member_id, class_id) select id, '${M_.s1}', '${B}' from public.notifications;`, /notification_reads_notification_fk/);
failTx('DB-163 جمهور غير معروف يُرفض', `insert into public.notifications (class_id, kind, event, ref_id, title, audience, dedupe_key) values ('${A}', 'prep', 'created', gen_random_uuid(), 't', 'everyone', 'k1');`, /audience_check/);
okTx('DB-164 اشتراك Push: https فقط وendpoint فريد', `insert into public.push_subscriptions (member_id, endpoint, p256dh, auth_key) values ('${M_.s1}', 'https://push.example.invalid/a', 'k', 'a'); select count(*) from public.push_subscriptions;`, 1);
failTx('DB-165 اشتراك Push بـhttp يُرفض', `insert into public.push_subscriptions (member_id, endpoint, p256dh, auth_key) values ('${M_.s1}', 'http://push.example.invalid/a', 'k', 'a');`, /endpoint_check/);
failTx('DB-166 endpoint مكرر يُرفض', `insert into public.push_subscriptions (member_id, endpoint, p256dh, auth_key) values ('${M_.s1}', 'https://x.invalid/a', 'k', 'a'), ('${M_.s2}', 'https://x.invalid/a', 'k', 'a');`, /push_subscriptions_endpoint_key/);
failTx('DB-167 endpoint الاشتراك ثابت', `insert into public.push_subscriptions (member_id, endpoint, p256dh, auth_key) values ('${M_.s1}', 'https://x.invalid/a', 'k', 'a'); update public.push_subscriptions set endpoint = 'https://x.invalid/b';`, /immutable/);
failTx('DB-168 إعلان بعنوان فارغ يُرفض', `insert into public.announcements (class_id, title, body) values ('${A}', '', 'x');`, /title_check/);

// ═════════ 10) الدعم والتدقيق ═════════
const SUP = (n, tgt, extra) => `insert into public.support_sessions (developer_member_id, target_member_id, reason, ends_at${extra ? ', ' + extra.c : ''}) values ('${M_.dev}', '${tgt}', 'فحص مشكلة', now() + interval '${n || 1} hour'${extra ? ', ' + extra.v : ''});`;
okTx('DB-169 جلسة دعم مطوّر ← طالب/ممثل', SUP(1, M_.s1));
failTx('DB-170 المستهدف لا يكون مطوّراً', `insert into public.support_sessions (developer_member_id, target_member_id, reason, ends_at) values ('${M_.rep1}', '${M_.dev}', 'x', now() + interval '1 hour');`, /developer -> rep\/student only/);
failTx('DB-171 الفاتح لا يكون غير المطوّر', `insert into public.support_sessions (developer_member_id, target_member_id, reason, ends_at) values ('${M_.rep1}', '${M_.s1}', 'x', now() + interval '1 hour');`, /developer -> rep\/student only/);
failTx('DB-172 جلسة أطول من 8 ساعات تُرفض', SUP(9, M_.s1), /support_sessions_ttl_chk/);
failTx('DB-173 جلسة مفتوحة واحدة للمطوّر', SUP(1, M_.s1) + SUP(1, M_.s2), /support_sessions_one_open_idx/);
failTx('DB-174 سبب الدعم مطلوب', `insert into public.support_sessions (developer_member_id, target_member_id, reason, ends_at) values ('${M_.dev}', '${M_.s1}', '  ', now() + interval '1 hour');`, /reason_check/);
failTx('DB-175 ended_at نهائي', SUP(1, M_.s1) + `update public.support_sessions set ended_at = now(); update public.support_sessions set ended_at = now() + interval '1 second';`, /immutable|final/);
failTx('DB-176 هدف الجلسة ثابت', SUP(1, M_.s1) + `update public.support_sessions set target_member_id = '${M_.s2}';`, /immutable/);
failTx('DB-177 حذف جلسة دعم مرفوض', SUP(1, M_.s1) + `delete from public.support_sessions;`, /hard delete/);
okTx('DB-178 support_target: الهدف أثناء الجلسة ثم null بعد الإغلاق/الانتهاء', SUP(1, M_.s1) + `select set_config('request.jwt.claim.sub', '${ID.dev}', true); select private.support_target() = '${M_.s1}'; update public.support_sessions set ended_at = now(); select private.support_target() is null;`, 't\nt');
okTx('DB-179 require_support_confirm: يرفض بلا تأكيد أثناء دعم مفتوح ويقبل مع التأكيد وبلا دعم (AM-20)', `select set_config('request.jwt.claim.sub', '${ID.dev}', true); select private.require_support_confirm(false) is not null;`.replace('is not null', '::text'), '');
const sc = tx(SUP(1, M_.s1) + `select set_config('request.jwt.claim.sub', '${ID.dev}', true); select private.require_support_confirm(false);`);
t('DB-180 بلا تأكيد أثناء دعم مفتوح: رفض صريح', sc.code !== 0 && /support_confirm_required/.test(sc.err), sc.err);
okTx('DB-181 مع التأكيد أثناء الدعم ينجح', SUP(1, M_.s1) + `select set_config('request.jwt.claim.sub', '${ID.dev}', true); select private.require_support_confirm(true)::text;`);
const nc = tx(`select set_config('request.jwt.claim.sub', '${ID.dev}', true); select private.require_support_confirm(false)::text;`);
t('DB-182 بلا جلسة دعم لا يُطلب تأكيد', nc.code === 0, nc.err);
okTx('DB-183 الدعم يُسجَّل في مراجعات التعديل (support_target)', SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}');` + SUP(1, M_.s1) +
  `select set_config('request.jwt.claim.sub', '${ID.dev}', true); update public.attendance_records set status = 'absent'; select (support_target_member_id = '${M_.s1}') || ',' || (actor_member_id = '${M_.dev}') from private.record_revisions;`, 'true,true');
okTx('DB-184 audit(): يملأ الفاعل والدور وهدف الدعم من الخادم (ADR-314)', SUP(1, M_.s1) + `select set_config('request.jwt.claim.sub', '${ID.dev}', true); select private.audit('support.write', 'attendance_records', gen_random_uuid(), '${A}') is not null;
  select (actor_member_id = '${M_.dev}') || ',' || actor_role || ',' || (support_target_member_id = '${M_.s1}') from public.audit_log;`, 't\ntrue,developer,true');
failTx('DB-185 حدث تدقيق غير معتمد يُرفض (R-034)', `select private.audit('made.up');`, /audit_event_types|violates foreign key/);
failTx('DB-186 تفاصيل التدقيق لا تقبل مفاتيح حساسة (اسم/هاتف/مبلغ…)', `select private.audit('student.created', p_details => '{"phone":"0770"}');`, /audit_log_details_keys_chk/);
failTx('DB-187 حجم التفاصيل ≤ 2KB', `select private.audit('student.created', p_details => jsonb_build_object('x', repeat('a', 3000)));`, /audit_log_details_size_chk/);
failTx('DB-188 نتيجة تدقيق غير معروفة تُرفض', `select private.audit('student.created', p_outcome => 'maybe');`, /outcome_check/);
failTx('DB-189 audit_log لا يُعدَّل حتى للمالك', `select private.audit('student.created'); update public.audit_log set outcome = 'error';`, /append-only/);
failTx('DB-190 audit_log لا يُحذف حتى للمالك', `select private.audit('student.created'); delete from public.audit_log;`, /append-only/);
failTx('DB-191 audit_log لا يُفرَّغ', `truncate public.audit_log;`, /append-only/);
const rc = pg.psql(`begin; do $$ begin insert into public.students (id, class_id, full_name, phone) values ('${uuid(80)}', '${A}', 'أ ب ج', '07700009999'); perform private.audit('not.registered'); end $$;`, DB);
pg.psql('rollback;', DB);
t('DB-192 فشل التدقيق يُفشل العملية كاملة (ذرية، T-74)', rc.code !== 0 && q(`select count(*) from public.students where id = '${uuid(80)}'`) === '0');
okTx('DB-193 كتالوج الأحداث يغطي قائمة 01.01/ADR-314 (≥ 30 حدثاً)', `select count(*) >= 30 from private.audit_event_types;`, 't');
t('DB-194 أعمدة audit_log بلا اسم/هاتف/مبلغ/درجة (معرّفات فقط)', !Object.keys(cols['public.audit_log']).some((c) => /^(name|full_name|phone|amount|score|note|email|ip|code|code_hash)$/.test(c)));
const pa = tx(`select private.purge_audit(null);`);
t('DB-195 purge_audit يرفض بلا تصدير موثق', pa.code !== 0 && /documented export/.test(pa.err), pa.err);
okTail('DB-196 purge_audit: يحذف الأقدم من 12 شهراً فقط ويُدوّن التدوير', `select private.audit('student.created'); select private.audit('student.created');
  set local session_replication_role = replica; update public.audit_log set at = now() - interval '13 months' where seq = (select min(seq) from public.audit_log); set local session_replication_role = origin;
  select private.purge_audit(now()); select count(*) || ',' || count(*) filter (where action = 'audit.purged') from public.audit_log;`, '1\n2,1');
okTail('DB-197 purge_audit لا يمس ما هو أحدث من 12 شهراً حتى بتصدير مستقبلي', `select private.audit('student.created'); select private.purge_audit(now() + interval '1 day'); select count(*) from public.audit_log where action = 'student.created';`, '0\n1'.replace('0\n', '0\n'));

// ═════════ 11) الرفض الافتراضي والمنح (شكل L-01…L-05) ═════════
t('DB-198 RLS مفعّل على كل جدول في public وprivate (L-01)', q(`select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and c.relkind = 'r' and not c.relrowsecurity`) === '0');
t('DB-199 لا سياسات في 01.02 (رفض افتراضي؛ السياسات 03.03)', q('select count(*) from pg_policies') === '0');
t('DB-200 anon وauthenticated بلا أي منحة على جدول/تسلسل (L-02/L-03)', q(`select count(*) from information_schema.role_table_grants where grantee in ('anon','authenticated') and table_schema in ('public','private')`) === '0' &&
  q(`select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and c.relkind in ('r','v','S') and (has_table_privilege('anon', c.oid, 'select,insert,update,delete,truncate,references,trigger') or has_table_privilege('authenticated', c.oid, 'select,insert,update,delete,truncate,references,trigger'))`) === '0');
t('DB-201 لا EXECUTE لـPUBLIC/anon على أي دالة؛ authenticated: المساعدات الأربع فقط', q(`select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname in ('public','private') and has_function_privilege('anon', p.oid, 'execute')`) === '0' &&
  q(`select string_agg(p.proname, ',' order by p.proname) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname in ('public','private') and has_function_privilege('authenticated', p.oid, 'execute')`) === 'actor_member_id,fold_ar,me,school_today');
t('DB-202 كل دالة security definer بـsearch_path فارغ (L-04)', q(`select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname in ('public','private') and p.prosecdef and not coalesce('search_path=""' = any(p.proconfig), false)`) === '0');
t('DB-203 cost_stats security_invoker وrecord_history security_barrier (L-05)', q(`select string_agg(c.relname || ':' || coalesce(c.reloptions::text, ''), ';' order by c.relname) from pg_class c where c.relname in ('cost_stats','record_history') and c.relkind = 'v'`) === 'cost_stats:{security_invoker=true};record_history:{security_barrier=true}');
okTx('DB-204 المحاكاة تمنح الجداول الجديدة افتراضياً (إثبات واقعية revoke الصريح)', `create table public.zz_probe (id int); select has_table_privilege('anon', 'public.zz_probe', 'select');`, 't');
// DB-205 مدمج في DB-206/210
const den = (name, role, sql) => { const r = tx(`set local role ${role}; ${sql}`); t(name, r.code !== 0 && /permission denied/.test(r.err), r.err || r.out); };
den('DB-206 authenticated لا يقرأ students مباشرة', 'authenticated', 'select * from public.students;');
den('DB-207 authenticated لا يقرأ private.activation_codes', 'authenticated', 'select * from private.activation_codes;');
den('DB-208 authenticated لا يستدعي private.audit', 'authenticated', `select private.audit('student.created');`);
den('DB-209 authenticated لا يستدعي purge_audit ولا purge_expired', 'authenticated', 'select private.purge_expired();');
den('DB-210 anon لا يقرأ audit_log', 'anon', 'select * from public.audit_log;');
okTx('DB-211 حتى مع منحة SELECT: RLS بلا سياسة = صفر صفوف', `grant select on public.students to authenticated; set local role authenticated; select set_config('request.jwt.claim.sub', '${ID.rep1}', true); select count(*) from public.students;`, 0);
okTx('DB-212 المستدعي يقيّم fold_ar/school_today في عمود مولَّد وافتراضي (EXECUTE مُنح)', `grant insert on public.preps to authenticated; create policy t_pi on public.preps for insert to authenticated with check (true); set local role authenticated; select set_config('request.jwt.claim.sub', '${ID.rep1}', true);
  insert into public.preps (class_id, subject) values ('${A}', 'عربي');`);

// ═════════ 12) استعلامات تجريبية بسياسات اختبارية (تثبت أن الأعمدة تتيح مرشحات المصفوفة؛ ليست سياسات 03.03) ═════════
const SMOKE = (u, body, extra) => asUser(u, body, ['grant select on public.attendance_records, public.attendance_sheets, public.cost_assignments, public.members, public.file_objects, public.notifications, public.record_history to authenticated'].concat(extra || []));
const POL = `create policy t_att on public.attendance_records for select to authenticated using (exists (select 1 from private.me() m where m.role = 'developer' or (m.role = 'rep' and m.class_id = attendance_records.class_id) or (m.role = 'student' and m.class_id = attendance_records.class_id and m.member_id = public.t_mem(attendance_records.student_id) and attendance_records.archived_at is null and public.t_sheet_ok(attendance_records.sheet_id))));
alter table public.attendance_records enable row level security;`;
const SH_APPR = SHEET(uuid(30), '2026-02-01') + COMPLETE(uuid(30)) + `update public.attendance_sheets set status = 'approved', approved_at = now(), approved_by = '${M_.rep1}' where id = '${uuid(30)}';` + SHEET(uuid(31), '2026-02-02') + COMPLETE(uuid(31));
const run = (u, body) => { const sql = 'begin;\n' + SH_APPR + HELP + HELP2 + `\ngrant select on public.attendance_records, public.attendance_sheets, public.members to authenticated;\n` + POL + `\nset local role authenticated;\nselect set_config('request.jwt.claim.sub', '${ID[u]}', true);\n` + body + '\nrollback;'; return pg.psql(sql, DB); };
let r = run('s1', `select count(*) from public.attendance_records;`); t('DB-213 [smoke] الطالب يرى سجله من كشف معتمد فقط (لا مسودة)', r.out === '1', r.out + r.err);
r = run('rep1', `select count(*) from public.attendance_records;`); t('DB-214 [smoke] الممثل يرى سجلات صفه كلها (مسودة ومعتمد)', r.out === '4', r.out + r.err);
r = run('rep2', `select count(*) from public.attendance_records;`); t('DB-215 [smoke] ممثل شعبة أخرى لا يرى شيئاً', r.out === '0', r.out + r.err);
r = run('dev', `select count(*) from public.attendance_records;`); t('DB-216 [smoke] المطوّر يرى الكل', r.out === '4', r.out + r.err);
const hist = (u) => pg.psql('begin;\n' + SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}'); update public.attendance_records set status = 'absent';
  grant select on public.record_history to authenticated; set local role authenticated; select set_config('request.jwt.claim.sub', '${ID[u]}', true); select count(*) from public.record_history;\nrollback;`, DB);
t('DB-217 record_history: المطوّر والممثل يريان، وممثل شعبة أخرى والطالب لا', hist('dev').out === '1' && hist('rep1').out === '1' && hist('rep2').out === '0' && hist('s1').out === '0', [hist('dev').out, hist('rep1').out, hist('rep2').out, hist('s1').out].join());
t('DB-218 record_history: الجدول الخلفي غير قابل للقراءة مباشرة', (() => { const x = tx(`grant select on public.record_history to authenticated; set local role authenticated; select * from private.record_revisions;`); return x.code !== 0 && /permission denied/.test(x.err); })());
t('DB-219 record_history بلا هوية (مجهول/بلا عضوية) = صفر', (() => { const x = pg.psql('begin;\n' + SHEET(uuid(30), '2026-02-01') + `insert into public.attendance_records (id, class_id, sheet_id, student_id) values ('${uuid(50)}', '${A}', '${uuid(30)}', '${ST.s1}'); update public.attendance_records set status = 'absent'; grant select on public.record_history to authenticated; set local role authenticated; select count(*) from public.record_history;\nrollback;`, DB); return x.out === '0'; })());
r = tx(`${HELP} ${ITEM(uuid(70))} ${ASSIGN(uuid(71), uuid(70), ST.s1)} ${ASSIGN(uuid(72), uuid(70), ST.s2)} grant select on public.cost_assignments, public.members to authenticated;
  create policy t_ca on public.cost_assignments for select to authenticated using (exists (select 1 from private.me() m where m.role = 'developer' or (m.role = 'rep' and m.class_id = cost_assignments.class_id) or (m.role = 'student' and m.member_id = public.t_mem(cost_assignments.student_id))));
  set local role authenticated; select set_config('request.jwt.claim.sub', '${ID.s1}', true); select count(*) from public.cost_assignments;`);
t('DB-220 [smoke] الطالب يرى إسناده فقط (student_id يتيح مرشح self)', r.out === '1', r.out + r.err);
r = tx(`grant select on public.members to authenticated; create policy t_m on public.members for select to authenticated using (exists (select 1 from private.me() m where m.role = 'developer' or (m.role = 'rep' and m.class_id = members.class_id and members.role in ('student','rep')) or m.member_id = members.id));
  set local role authenticated; select set_config('request.jwt.claim.sub', '${ID.rep1}', true); select string_agg(role, ',' order by role) from public.members;`);
t('DB-221 [smoke] الممثل لا يرى صف المطوّر ولا عضويات شعبة أخرى', r.out === 'rep,student,student', r.out + r.err);
r = tx(`${HELP} ${PREP(uuid(60))} ${PREP(uuid(61))} ${FILE('prep_id', uuid(60), 1)} update public.preps set archived_at = now() where id = '${uuid(61)}'; grant select on public.file_objects, public.preps to authenticated;
  create policy t_f on public.file_objects for select to authenticated using (exists (select 1 from private.me() m where m.role = 'developer' or m.class_id = file_objects.class_id) and public.t_prep_live(file_objects.prep_id));
  set local role authenticated; select set_config('request.jwt.claim.sub', '${ID.s1}', true); select count(*) from public.file_objects;`);
t('DB-222 [smoke] مرفق يُقرأ فقط إن كان أصله حياً ومقروءاً (parent)', r.out === '1', r.out + r.err);
r = tx(`insert into public.announcements (class_id, title, body) values ('${A}', 'عام', 'x'); grant select on public.notifications to authenticated;
  create policy t_n on public.notifications for select to authenticated using (exists (select 1 from private.me() m where (m.role = 'developer' or m.class_id = notifications.class_id) and (notifications.audience = 'all' or (notifications.audience = 'students' and m.role = 'student') or (notifications.audience = 'reps' and m.role = 'rep'))));
  set local role authenticated; select set_config('request.jwt.claim.sub', '${ID.s3}', true); select count(*) from public.notifications;`);
t('DB-223 [smoke] طالب شعبة أخرى لا يرى إشعار شعبة أ', r.out === '0', r.out + r.err);

// ═════════ 13) الاحتفاظ والتنظيف ═════════
const OLD = (tbl, col, iv, where) => `set local session_replication_role = replica; update ${tbl} set ${col} = now() - interval '${iv}' ${where || ''}; set local session_replication_role = origin;`;
r = tx(`insert into private.activation_attempts (outcome) values ('invalid'), ('invalid'); ${OLD('private.activation_attempts', 'attempted_at', '100 days', 'where id = (select id from private.activation_attempts limit 1)')}
  ${CODE(1, M_.s1)} ${CODE(2, M_.s2)} update private.activation_codes set revoked_at = now(), revoked_by = '${M_.rep1}' where member_id = '${M_.s1}';
  ${OLD('private.activation_codes', 'revoked_at', '200 days', `where member_id = '${M_.s1}'`)}
  ${PREP(uuid(60))} ${OLD('public.notifications', 'created_at', '13 months')}
  insert into public.push_subscriptions (member_id, endpoint, p256dh, auth_key, revoked_at) values ('${M_.s1}', 'https://a.invalid/1', 'k', 'a', now() - interval '40 days'), ('${M_.s1}', 'https://a.invalid/2', 'k', 'a', null);
  select private.purge_expired()::text;
  select (select count(*) from private.activation_attempts) || ',' || (select count(*) from private.activation_codes) || ',' || (select count(*) from public.notifications) || ',' || (select count(*) from public.push_subscriptions);`);
t('DB-224 purge_expired: يحذف المنتهي بعد مدة الاحتفاظ ويُبقي الحي', r.code === 0 && r.out.split('\n')[1] === '1,1,0,1', r.out + r.err);
t('DB-225 purge_expired يعيد عدّاد كل صنف', r.code === 0 && JSON.parse(r.out.split('\n')[0]).attempts === 1 && JSON.parse(r.out.split('\n')[0]).codes === 1 && JSON.parse(r.out.split('\n')[0]).notifications === 1 && JSON.parse(r.out.split('\n')[0]).push === 1, r.out);

// ═════════ 14) الإصدار والإعدادات وتعدد الشعب ═════════
okTx('DB-226 app_meta وsystem_settings صف واحد وbذور الإصدار 1', `select (select count(*) from public.app_meta) || ',' || (select schema_version from public.app_meta) || ',' || (select count(*) from public.system_settings);`.replace('bذور', ''), '1,1,1');
failTx('DB-227 صف ثانٍ في app_meta يُرفض', `insert into public.app_meta (id, schema_version) values (false, 2);`, /app_meta_id_check|violates check/);
failTx('DB-228 صف ثانٍ في system_settings يُرفض', `insert into public.system_settings (id) values (true);`, /system_settings_pkey/);
failTx('DB-229 عتبات التخزين يجب أن تكون متزايدة', `update public.system_settings set storage_warn_pct = 95;`, /system_settings_pct_chk/);
failTx('DB-230 الاحتفاظ بالتدقيق لا يقل عن 12 شهراً', `update public.system_settings set audit_retention_months = 6;`, /audit_retention_months/);
okTx('DB-231 class_settings تُبذر تلقائياً لكل شعبة جديدة', `insert into public.classes (name) values ('ج'); select count(*) from public.class_settings;`, 3);
failTx('DB-232 أيام الجدول: قيمة غير معروفة أو فارغة تُرفض', `update public.class_settings set schedule_days = array['xyz'];`, /class_settings_days_chk/);
okTx('DB-233 تعدد الشعب: ممثل ثالث بشعبة جديدة وطالب بنفس الهاتف في شعبة أخرى، بلا تعارض', `insert into public.classes (id, name) values ('${uuid(90)}', 'ج'); insert into auth.users (id) values ('${uuid(91)}');
  insert into public.members (user_id, role, class_id, display_name, status, activated_at) values ('${uuid(91)}', 'rep', '${uuid(90)}', 'ممثل ج', 'active', now());
  insert into public.students (class_id, full_name, phone) values ('${uuid(90)}', 'أحمد علي حسن', '07701110001'); select count(*) from public.members where role = 'rep';`, 3);
failTx('DB-234 حذف شعبة مرفوض', `delete from public.classes;`, /hard delete/);
okTx('DB-235 أرشفة شعبة ممكنة (جاهزية فقط، دون واجهة)', `update public.classes set archived_at = now() where id = '${B}'; select archived_at is not null from public.classes where id = '${B}';`, 't');
failTx('DB-236 اسم الشعبة بفراغات طرفية يُرفض', `insert into public.classes (name) values (' ج ');`, /classes_name_check/);

// ═════════ 15) التزامن (قاعدة مستقلة بالتثبيت الفعلي) ═════════
H.loadSchema(pg, 'c');
const C = { db: 'c' };
const cq = (s) => { const x = pg.psql(s, C); if (x.code !== 0) throw new Error(x.err); return x.out; };
const cA = cq("select id from public.classes limit 1");
cq(`insert into public.students (id, class_id, full_name, phone) values ('${ST.s1}', '${cA}', 'أحمد علي حسن', '07701110001');
 insert into public.cost_items (id, class_id, title, amount) values ('${uuid(70)}', '${cA}', 'ملزمة', 2000), ('${uuid(75)}', '${cA}', 'رحلة', 1000);
 insert into public.cost_assignments (id, class_id, cost_item_id, student_id) values ('${uuid(71)}', '${cA}', '${uuid(70)}', '${ST.s1}'), ('${uuid(76)}', '${cA}', '${uuid(75)}', '${ST.s1}');`);
const payTx = (id, as, amt, sleep) => `begin; insert into public.payments (id, class_id, assignment_id, student_id, amount) values ('${id}', '${cA}', '${as}', '${ST.s1}', ${amt}); select pg_sleep(${sleep}); commit;`;
(async () => {
  // حالتان: يتسع المستحق للدفعتين (لا ضياع تحديث) / لا يتسع (واحدة تفشل)
  let [r1, r2] = await Promise.all([pg.psqlAsync(payTx(uuid(80), uuid(71), 600, 1.2), C), new Promise((res) => setTimeout(res, 300)).then(() => pg.psqlAsync(payTx(uuid(81), uuid(71), 600, 0), C))]);
  t('DB-237 دفعتان متزامنتان يتسع لهما المستحق: كلتاهما تنجح والمجموع 1200 بلا ضياع تحديث (T-79)', r1.code === 0 && r2.code === 0 && cq(`select paid_total from public.cost_assignments where id = '${uuid(71)}'`) === '1200', r1.err + r2.err);
  [r1, r2] = await Promise.all([pg.psqlAsync(payTx(uuid(82), uuid(76), 600, 1.2), C), new Promise((res) => setTimeout(res, 300)).then(() => pg.psqlAsync(payTx(uuid(83), uuid(76), 600, 0), C))]);
  t('DB-238 دفعتان متزامنتان تتجاوزان المستحق: واحدة تفشل والمجموع لا يتجاوز المستحق', (r1.code === 0) !== (r2.code === 0) && /paid_le_due_chk/.test(r1.err + r2.err) && cq(`select paid_total from public.cost_assignments where id = '${uuid(76)}'`) === '600', r1.err + r2.err);
  t('DB-239 verify_cost_totals نظيف بعد التزامن', cq('select count(*) from private.verify_cost_totals()') === '0');

  // ═════════ 16) حمل اصطناعي لسنة دراسية كاملة (R-002): 100 طالب، 170 يوماً ═════════
  H.loadSchema(pg, 'l');
  const L = { db: 'l' };
  const lA = pg.psql('select id from public.classes limit 1', L).out;
  const t0 = Date.now();
  const load = pg.psql(`
    insert into auth.users (id) select gen_random_uuid() from generate_series(1, 103);
    insert into public.students (id, class_id, full_name, phone, name_key_dummy_never) select 1 where false;`.replace(/insert into public\.students[^;]*;/, '') + `
    insert into public.students (class_id, full_name, phone)
      select '${lA}', 'طالب رقم ' || g || ' علي حسن', '0770' || lpad(g::text, 7, '0') from generate_series(1, 100) g;
    -- 3 حسابات للإدارة + 100 عضوية طلاب
    with u as (select id, row_number() over () rn from auth.users)
    insert into public.members (user_id, role, display_name, status, activated_at) select id, 'developer', 'المطوّر', 'active', now() from u where rn = 1;
    with u as (select id, row_number() over () rn from auth.users)
    insert into public.members (user_id, role, class_id, display_name, status, activated_at) select id, 'rep', '${lA}', 'ممثل ' || rn, 'active', now() from u where rn in (2, 3);
    with u as (select id, row_number() over () rn from auth.users), s as (select id, row_number() over (order by full_name) rn from public.students)
    insert into public.members (user_id, role, class_id, student_id, status, activated_at) select u.id, 'student', '${lA}', s.id, 'active', now() from s join u on u.rn = s.rn + 3;
    -- 170 كشفاً × 100 سجلاً (تعديل ~3% غياباً بعد الإنشاء كما يحدث فعلياً)
    insert into public.attendance_sheets (class_id, school_date, status, approved_at, approved_by)
      select '${lA}', date '2026-09-01' + g, 'approved', now(), (select id from public.members where role = 'rep' limit 1) from generate_series(0, 169) g;
    insert into public.attendance_records (class_id, sheet_id, student_id) select '${lA}', sh.id, st.id from public.attendance_sheets sh cross join public.students st;
    update public.attendance_records set status = 'absent' where random() < 0.03;
    -- درجات: 8 مواد × (8 شهرية + نصفية + نهائية)
    insert into public.grades (class_id, student_id, subject, term, period_month, score, max_score)
      select '${lA}', st.id, s.name, 'monthly', m, 30 + (random() * 20)::int, 50 from public.students st cross join (values ('عربي'),('إنجليزي'),('رياضيات'),('فيزياء'),('كيمياء'),('أحياء'),('إسلامية'),('تاريخ')) s(name) cross join generate_series(1, 8) m;
    insert into public.grades (class_id, student_id, subject, term, score, max_score)
      select '${lA}', st.id, s.name, t.term, 60 + (random() * 40)::int, 100 from public.students st cross join (values ('عربي'),('إنجليزي'),('رياضيات'),('فيزياء'),('كيمياء'),('أحياء'),('إسلامية'),('تاريخ')) s(name) cross join (values ('midyear'),('final')) t(term);
    update public.grades set score = least(max_score, score + 1) where random() < 0.05;
    -- تحاضير: 170 يوماً × 6 مواد + واجب + حالة + 4 صور و PDF
    insert into public.preps (class_id, subject, school_date, notes) select '${lA}', s.name, date '2026-09-01' + g, 'ملاحظات اليوم' from generate_series(0, 169) g cross join (values ('عربي'),('إنجليزي'),('رياضيات'),('فيزياء'),('كيمياء'),('أحياء')) s(name);
    insert into public.homework (class_id, prep_id, body) select class_id, id, 'حل التمارين من الصفحة 20 إلى 25' from public.preps;
    insert into public.prep_status (class_id, prep_id, status) select class_id, id, 'taken' from public.preps;
    insert into public.file_objects (class_id, prep_id, storage_path, thumb_path, mime_type, byte_size, thumb_byte_size, sha256)
      select p.class_id, p.id, p.class_id || '/prep/' || gen_random_uuid() || '.jpg', p.class_id || '/thumb/' || gen_random_uuid() || '.webp', 'image/jpeg', 250000, 30000, decode(repeat('ab', 32), 'hex')
      from (select * from public.preps order by school_date limit 680) p;
    -- امتحانات وجدول وإعلانات
    insert into public.exams (class_id, subject, exam_date) select '${lA}', 'مادة ' || g, date '2026-10-01' + g from generate_series(1, 40) g;
    insert into public.schedule_entries (class_id, weekday, subject, period_no) select '${lA}', d, 'مادة ' || p, p from unnest(array['sun','mon','tue','wed','thu']) d cross join generate_series(1, 6) p;
    insert into public.announcements (class_id, title, body) select '${lA}', 'إعلان ' || g, 'نص الإعلان رقم ' || g from generate_series(1, 60) g;
    -- تكاليف: 15 بنداً × 100 طالب، دفعات (~1.3 لكل إسناد)
    insert into public.cost_items (class_id, title, amount) select '${lA}', 'بند ' || g, 2000 from generate_series(1, 15) g;
    insert into public.cost_assignments (class_id, cost_item_id, student_id) select i.class_id, i.id, s.id from public.cost_items i cross join public.students s;
    insert into public.payments (class_id, assignment_id, student_id, amount) select class_id, id, student_id, 1000 from public.cost_assignments;
    insert into public.payments (class_id, assignment_id, student_id, amount) select class_id, id, student_id, 1000 from public.cost_assignments where random() < 0.3;
    -- تدقيق: ~ 2800 حدث
    insert into public.audit_log (action, class_id, entity, entity_id, outcome) select (array['payment.recorded','attendance.approved','grade.changed','student.updated'])[1 + (g % 4)], '${lA}', 'x', gen_random_uuid(), 'success' from generate_series(1, 2800) g;
    select 'rows=' || (select count(*) from public.attendance_records) || ',' || (select count(*) from public.grades) || ',' || (select count(*) from public.payments) || ',' || (select count(*) from private.record_revisions) || ',' || (select count(*) from public.notifications);
    select 'dbmb=' || round(sum(pg_total_relation_size(c.oid)) / 1048576.0, 1) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and c.relkind = 'r';
    select 'top=' || string_agg(x, ' ' order by s desc) from (select c.relname || ':' || round(pg_total_relation_size(c.oid) / 1048576.0, 1) x, pg_total_relation_size(c.oid) s from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and c.relkind = 'r' order by s desc limit 6) z;
    select 'filesmb=' || round(files_count * 0 + used_bytes / 1048576.0, 1) from private.storage_usage();
    select 'verify=' || count(*) from private.verify_cost_totals();
  `, L);
  const secs = ((Date.now() - t0) / 1000).toFixed(1);
  const mb = parseFloat((/dbmb=([0-9.]+)/.exec(load.out) || [])[1]);
  console.log('INFO حمل سنة كاملة: ' + load.out.replace(/\n/g, ' | ') + ' | زمن التحميل ' + secs + ' ث');
  t('DB-240 تحميل سنة دراسية كاملة اصطناعية (100 طالب، 170 يوماً) ينجح بالمشغّلات الفعلية', load.code === 0 && /rows=17000,8000,/.test(load.out), load.err);
  t('DB-241 حجم القاعدة لسنة كاملة أقل من 100MB (≤ 20% من 500MB، تتسع 5 سنوات)', mb > 0 && mb < 100, mb);
  t('DB-242 مجاميع الدفعات متطابقة بعد الحمل الكبير', /verify=0/.test(load.out));
  console.log(`\nRESULT pass=${pass} fail=${fail}`);
  process.exit(fail ? 1 : 0);
})();
