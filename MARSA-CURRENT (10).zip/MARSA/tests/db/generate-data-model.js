// يولّد كتل GEN في docs/execution-v2/DATA-MODEL-V2.md ومخطط ER من قاعدة PostgreSQL مؤقتة حقيقية حُمِّل فيها schema-v2.sql.
// الاستعمال: node tests/db/generate-data-model.js          (يكتب الكتل ويولّد DATA-MODEL-ER.mmd)
//            node tests/db/generate-data-model.js --check  (يفشل إن اختلف الملف عمّا يولّده المخطط الحي)
'use strict';
const fs = require('fs'), path = require('path');
const H = require('./pg-harness.js');
const DOC = path.join(H.ROOT, 'docs', 'execution-v2', 'DATA-MODEL-V2.md');
const MMD = path.join(H.ROOT, 'docs', 'execution-v2', 'DATA-MODEL-ER.mmd');
const check = process.argv.includes('--check');

const av = H.available();
if (!av.ok) { console.log('SKIP generate-data-model: ' + av.why); process.exit(check ? 0 : 1); }
const pg = H.startPg();
process.on('exit', () => { try { pg.stop(); } catch (e) { /* مغلق */ } });
H.loadSchema(pg, 'g');
const q = (sql) => { const r = pg.psql(sql, { db: 'g' }); if (r.code !== 0) throw new Error(r.err); return r.out ? r.out.split('\n').map((l) => l.split('|')) : []; };
const esc = (s) => String(s).replace(/\|/g, '\\|');

const tables = q(`select n.nspname, c.relname, c.oid, coalesce(obj_description(c.oid, 'pg_class'), '') from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname in ('public','private') and c.relkind = 'r' order by (n.nspname = 'private'), c.oid`)
  .map((r) => ({ schema: r[0], name: r[1], oid: r[2], cls: (r[3].split('|')[0] || ''), desc: r.slice(3).join('|').split('|').slice(1).join('|') }));
const full = (t) => t.schema + '.' + t.name;

function gen(name) {
  if (name === 'TABLES') {
    const rows = tables.map((t, i) => {
      const n = q(`select count(*) from information_schema.columns where table_schema = '${t.schema}' and table_name = '${t.name}'`)[0][0];
      const flags = q(`select
        (select count(*) > 0 from information_schema.columns where table_schema='${t.schema}' and table_name='${t.name}' and column_name='class_id'),
        (select count(*) > 0 from information_schema.columns where table_schema='${t.schema}' and table_name='${t.name}' and column_name='version'),
        (select count(*) > 0 from information_schema.columns where table_schema='${t.schema}' and table_name='${t.name}' and column_name in ('archived_at','revoked_at')),
        (select count(*) from pg_trigger where tgrelid = ${t.oid} and not tgisinternal)`)[0];
      return `| ${i + 1} | \`${full(t)}\` | ${t.cls} | ${n} | ${flags[0] === 't' ? '✓' : '—'} | ${flags[1] === 't' ? '✓' : '—'} | ${flags[2] === 't' ? '✓' : '—'} | ${flags[3]} | ${esc(t.desc)} |`;
    });
    return '| # | الجدول | الصنف | أعمدة | `class_id` | `version` | أرشفة | مشغّلات | الغرض |\n|---|---|---|---|---|---|---|---|---|\n' + rows.join('\n');
  }
  if (name === 'COLUMNS') {
    return tables.map((t) => {
      const cols = q(`select a.attname, format_type(a.atttypid, a.atttypmod), case when a.attnotnull then 'NOT NULL' else '' end,
          coalesce(pg_get_expr(d.adbin, d.adrelid), ''), case when a.attgenerated <> '' then 'مولَّد' else '' end
        from pg_attribute a left join pg_attrdef d on d.adrelid = a.attrelid and d.adnum = a.attnum
        where a.attrelid = ${t.oid} and a.attnum > 0 and not a.attisdropped order by a.attnum`);
      const cons = q(`select conname, contype, pg_get_constraintdef(oid) from pg_constraint where conrelid = ${t.oid} order by (contype = 'p') desc, contype, conname`);
      return `#### \`${full(t)}\` — ${t.cls}\n\n| العمود | النوع | قيد | افتراضي |\n|---|---|---|---|\n` +
        cols.map((c) => `| \`${c[0]}\` | ${esc(c[1])} | ${[c[2], c[4]].filter(Boolean).join(' ')} | ${c[3] ? '`' + esc(c[3]).slice(0, 90) + '`' : ''} |`).join('\n') +
        '\n\nالقيود: ' + cons.map((c) => `\`${c[0]}\` (${{ p: 'PK', f: 'FK', u: 'UNIQUE', c: 'CHECK', x: 'EXCLUDE' }[c[1]] || c[1]})`).join('، ') + '\n';
    }).join('\n');
  }
  if (name === 'INDEXES') {
    const rows = q(`select schemaname || '.' || tablename, indexname, case when indexdef like 'CREATE UNIQUE%' then 'فريد' else '' end, regexp_replace(indexdef, '^.* USING ', '') from pg_indexes where schemaname in ('public','private') and indexname not like '%\\_pkey' escape '\\' order by 1, 2`);
    return '| الجدول | الفهرس | | التعريف |\n|---|---|---|---|\n' + rows.map((r) => `| \`${r[0]}\` | \`${r[1]}\` | ${r[2]} | \`${esc(r.slice(3).join('|')).slice(0, 140)}\` |`).join('\n');
  }
  if (name === 'TRIGGERS') {
    const rows = q(`select c.relname, t.tgname, regexp_replace(pg_get_triggerdef(t.oid), '^.*? (BEFORE|AFTER) ', '\\1 ') from pg_trigger t join pg_class c on c.oid = t.tgrelid join pg_namespace n on n.oid = c.relnamespace where not t.tgisinternal and n.nspname in ('public','private') order by c.relname, t.tgname`);
    return '| الجدول | المشغّل | التعريف |\n|---|---|---|\n' + rows.map((r) => `| \`${r[0]}\` | \`${r[1]}\` | \`${esc(r.slice(2).join('|')).replace(/ EXECUTE FUNCTION /, ' → ').slice(0, 150)}\` |`).join('\n');
  }
  if (name === 'FUNCTIONS') {
    const rows = q(`select n.nspname || '.' || p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ')', case when p.prosecdef then 'DEFINER' else 'INVOKER' end, p.provolatile::text,
        case when has_function_privilege('authenticated', p.oid, 'execute') then 'authenticated' else '—' end, coalesce(obj_description(p.oid, 'pg_proc'), '')
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname in ('public','private') and p.prokind = 'f' order by 1`);
    return '| الدالة | الامتياز | الثبات | EXECUTE | ملاحظة |\n|---|---|---|---|---|\n' + rows.map((r) => `| \`${esc(r[0])}\` | ${r[1]} | ${{ i: 'immutable', s: 'stable', v: 'volatile' }[r[2]]} | ${r[3]} | ${esc(r.slice(4).join('|'))} |`).join('\n');
  }
  if (name === 'GRANTS') {
    const g = (role) => q(`select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and c.relkind in ('r','v') and has_table_privilege('${role}', c.oid, 'select,insert,update,delete')`)[0][0];
    const rls = q(`select count(*) filter (where relrowsecurity), count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname in ('public','private') and relkind = 'r'`)[0];
    const pol = q('select count(*) from pg_policies')[0][0];
    return `| الفحص | القيمة |\n|---|---|\n| جداول بـRLS مفعّل | ${rls[0]} من ${rls[1]} |\n| سياسات RLS معرّفة | ${pol} (تُكتب في 03.03) |\n| جداول/عروض يملك \`anon\` عليها أي صلاحية DML | ${g('anon')} |\n| جداول/عروض يملك \`authenticated\` عليها أي صلاحية DML | ${g('authenticated')} |\n| دوال \`authenticated\` يستدعيها | ${q(`select string_agg(p.proname, '، ' order by p.proname) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname in ('public','private') and has_function_privilege('authenticated', p.oid, 'execute')`)[0][0]} |`;
  }
  if (name === 'EVENTS') {
    const rows = q('select action, category, description from private.audit_event_types order by category, action');
    return '| الحدث | الفئة | الوصف |\n|---|---|---|\n' + rows.map((r) => `| \`${r[0]}\` | ${r[1]} | ${esc(r.slice(2).join('|'))} |`).join('\n');
  }
  if (name === 'ER') {
    const lines = ['erDiagram'];
    const fk = q(`select conrelid::regclass::text, confrelid::regclass::text from pg_constraint where contype = 'f' and connamespace in ('public'::regnamespace, 'private'::regnamespace) group by 1, 2 order by 1, 2`);
    const nm = (x) => x.replace(/^(public|private)\./, '');
    fk.forEach((r) => lines.push(`  ${nm(r[1])} ||--o{ ${nm(r[0])} : ""`));
    return lines.join('\n');
  }
  throw new Error('GEN غير معروف: ' + name);
}
const NAMES = ['TABLES', 'COLUMNS', 'INDEXES', 'TRIGGERS', 'FUNCTIONS', 'GRANTS', 'EVENTS'];
let doc = fs.readFileSync(DOC, 'utf8');
let bad = 0;
NAMES.forEach((n) => {
  const re = new RegExp('(<!-- GEN:' + n + ':START -->)[\\s\\S]*?(<!-- GEN:' + n + ':END -->)');
  if (!re.test(doc)) { console.log('FAIL كتلة GEN:' + n + ' غير موجودة في الوثيقة'); bad++; return; }
  doc = doc.replace(re, (m, a, b) => a + '\n' + gen(n) + '\n' + b);
});
const er = gen('ER') + '\n';
if (check) {
  const cur = fs.readFileSync(DOC, 'utf8');
  const okDoc = cur === doc;
  const okEr = fs.existsSync(MMD) && fs.readFileSync(MMD, 'utf8') === er;
  console.log(okDoc ? 'PASS DATA-MODEL-V2.md مطابق للمخطط الحي' : 'FAIL DATA-MODEL-V2.md قديم؛ شغّل generate-data-model.js');
  console.log(okEr ? 'PASS DATA-MODEL-ER.mmd مطابق للمخطط الحي' : 'FAIL DATA-MODEL-ER.mmd قديم');
  process.exit(bad || !okDoc || !okEr ? 1 : 0);
}
fs.writeFileSync(DOC, doc);
fs.writeFileSync(MMD, er);
console.log('كُتب ' + NAMES.length + ' كتل + ER (' + er.split('\n').length + ' سطراً)');
process.exit(bad ? 1 : 0);
