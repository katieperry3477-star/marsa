// اختبار بوابة 5.06: يفحص اتساق وثائق التخطيط ولا يلمس كود التطبيق. التشغيل: node tests/gate/gate-docs.test.js
'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const ROOT = path.join(__dirname, '..', '..');
const A = (f) => path.join(ROOT, 'docs', 'architecture', f);
const read = (p) => fs.readFileSync(p, 'utf8');
let pass = 0, fail = 0;
const t = (name, ok, extra) => { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra || ''); } };

// ---- دوال الفحص (تُختبر أيضاً على نصوص مُفسَدة عمداً) ----
const candidateNotApproved = (s) => /مرشَّحة\s*—\s*غير معتمدة/.test(s) && !/الحالة:\s*\*{0,2}\s*معتمدة/.test(s);
const hasApprovalGate = (s) => /بوابة الموافقة/.test(s) && /المزود/.test(s) && /الخطة/.test(s);
const idsIn = (s, re) => new Set(s.match(re) || []);
const missing = (need, have) => need.filter((x) => !have.has(x));

const files = ['APPROVED-PLAN-CANDIDATE.md', 'ADR-INDEX.md', 'DECISION-LOG.md', 'USER-DECISIONS-STATUS.md', 'SOURCES-5.06.md', 'code-baseline.sha256'];
files.forEach((f) => t('المخرج موجود: ' + f, fs.existsSync(A(f))));

const cand = read(A('APPROVED-PLAN-CANDIDATE.md')), adr = read(A('ADR-INDEX.md')), log = read(A('DECISION-LOG.md')), st = read(A('USER-DECISIONS-STATUS.md'));

// 1) الخطة غير معتمدة وبوابة الموافقة موجودة
t('الخطة موسومة مرشحة وغير معتمدة', candidateNotApproved(cand));
t('بوابة الموافقة تذكر المزود والخطة', hasApprovalGate(cand));
t('حالة الأسئلة تطلب قرار المزود والخطة قبل 6.01', /المزوّد/.test(st) && /الخطة/.test(st) && /6\.01/.test(st));


// 1-ب) قرارات المستخدم الصريحة 2026-10-27 مسجلة ومنعكسة
t('قرارات المستخدم U-01..U-05 مسجلة', missing(['U-01','U-02','U-03','U-04','U-05'], idsIn(log, /U-0\d/g)).length === 0);
t('DEC-16 محسوم: لا ترحيل', /DEC-16[^\n]*معتمد: لا/.test(log) && /DEC-16/.test(st) && /لا ترحيل|لا — التطبيق جديد/.test(st));
t('ADR-002 معتمد صراحةً', /\|\s*ADR-002\s*\|[^\n]*معتمد — صريح/.test(adr));
t('الخطة تقول إن غير المعتمد يبقى مقترحاً (لا ادعاء اعتماد شامل)', /غير معتمدة كاملةً/.test(cand) && /مقترح/.test(cand));
t('المرحلة 10 مزامنة فقط والترحيل ملغى', /\|\s*\*\*10\*\*[^\n]*ملغى/.test(cand));
t('لا بند «مطلوب قراران قبل 6.01» بقي معلقاً', !/معلق — بانتظارك/.test(st));

// 2) تغطية المعرّفات
const decNeed = Array.from({ length: 20 }, (_, i) => 'DEC-' + String(i + 1).padStart(2, '0'));
t('كل DEC-01..20 في سجل القرارات', missing(decNeed, idsIn(log, /DEC-\d{2}/g)).length === 0, missing(decNeed, idsIn(log, /DEC-\d{2}/g)).join());
const qNeed = Array.from({ length: 17 }, (_, i) => 'Q' + (i + 1));
t('كل Q1..Q17 في سجل القرارات', missing(qNeed, idsIn(log, /\bQ\d{1,2}\b/g)).length === 0);
const adrNeed = Array.from({ length: 12 }, (_, i) => 'ADR-' + String(i + 1).padStart(3, '0'));
t('كل ADR-001..012 في الفهرس', missing(adrNeed, idsIn(adr, /ADR-\d{3}/g)).length === 0);
t('كل ADR له تصنيف (معتمد/مقترح)', adrNeed.every((id) => new RegExp('\\|\\s*' + id + '\\s*\\|[^\\n]*(معتمد|مقترح)').test(adr)));
const gNeed = ['G-01','G-02','G-03','G-04','G-05','G-06','G-07','G-08'];
t('قرارات البوابة G-01..08 مسجلة', missing(gNeed, idsIn(log, /G-0\d/g)).length === 0);
const stDec = new Set(); for (const m of st.matchAll(/DEC-(\d{2}(?:\s*\/\s*\d{2})*)/g)) m[1].split('/').forEach((n) => stDec.add('DEC-' + n.trim()));
t('كل DEC-01..20 ورد في حالة الأسئلة', missing(decNeed, stDec).length === 0, missing(decNeed, stDec).join());

// 3) خطة المراحل 6..16 كاملة، وكل مرحلة لها اختبار وبوابة
const stageRows = cand.split('\n').filter((l) => /^\|\s*\*\*\d{1,2}\*\*/.test(l));
const stages = stageRows.map((l) => +l.match(/\*\*(\d{1,2})\*\*/)[1]).sort((a, b) => a - b);
t('المراحل 6..16 مغطاة بصف لكل منها', JSON.stringify(stages) === JSON.stringify([6,7,8,9,10,11,12,13,14,15,16]), stages.join());
t('كل صف مرحلة بسبع أعمدة (تبعية/اختبار/بوابة...)', stageRows.every((l) => l.split('|').length - 2 === 7));
t('اختبارات الرفض مذكورة في المراحل الحساسة 7 و8 و9', [7, 8, 9].every((n) => /✗|ممنوع|رفض|لا يقرأ/.test(stageRows.find((l) => l.includes('**' + n + '**')))));
t('12 قبل 10 في ترتيب التنفيذ', /9 → \*\*12\*\* → 10/.test(cand));

// 4) كل مسار ملف مذكور في الخطة موجود فعلاً
const refs = [...cand.matchAll(/`((?:docs|tests)\/[A-Za-z0-9_./-]+)`/g)].map((m) => m[1]).filter((p) => !/[*]/.test(p));
const bad = refs.filter((p) => !fs.existsSync(path.join(ROOT, p)));
t('كل مسار مذكور في الخطة موجود (' + refs.length + ')', bad.length === 0, bad.join());

// 5) لا تغيير في كود التطبيق خارج النطاق + لا أسرار
const base = read(A('code-baseline.sha256')).trim().split('\n').map((l) => l.split(/\s+/));
const diffs = base.filter(([h, f]) => crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, f))).digest('hex') !== h);
t('كود التطبيق مطابق لبصمات 4.08 (' + base.length + ' ملفاً)', diffs.length === 0, diffs.map((d) => d[1]).join());
const secretRe = /(eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}|sb_secret_[A-Za-z0-9]+|service_role\s*[:=]\s*['"][^'"]{10,})/;
t('لا أسرار/مفاتيح في وثائق البوابة', files.filter((f) => f.endsWith('.md')).every((f) => !secretRe.test(read(A(f)))));

// 6) اختبارات سلبية على دوال الفحص نفسها (ليست فارغة)
t('NEG: نص يدّعي الاعتماد يُرفض', !candidateNotApproved('**الحالة: معتمدة**'));
t('NEG: خطة بلا بوابة موافقة تُرفض', !hasApprovalGate('لا شيء'));
t('NEG: معرّف ناقص يُكتشف', missing(['DEC-99'], idsIn(log, /DEC-\d{2}/g)).length === 1);
t('NEG: DEC ناقص في حالة الأسئلة يُكتشف', missing(['DEC-99'], stDec).length === 1);
t('NEG: ادعاء اعتماد كامل يُرفض', !candidateNotApproved('الحالة: **معتمدة**'));
t('NEG: بصمة مغيّرة تُكتشف', crypto.createHash('sha256').update('x').digest('hex') !== base[0][0]);
t('NEG: مسار وهمي يُكتشف', !fs.existsSync(path.join(ROOT, 'docs/architecture/NOPE.md')));

console.log(`\nالنتيجة: ${pass} نجاح، ${fail} فشل`);
process.exit(fail ? 1 : 0);
