// تشغيل: node tests/v1-text.test.js  (لا يحتاج مكتبات)
// غلاف نص V1: يحفظ الرموز التعبيرية المركّبة ويترك المنقّي القديم (preps-model.js) كما هو.
var assert = require('assert'), fs = require('fs'), path = require('path'), crypto = require('crypto');
var X = require('../js/v1-text.js'), M = require('../js/preps-model.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function ok(o) { var x = { subject: 'مادة', title: 'موضوع', date: '2026-10-28', content: 'نقاط' }, k; for (k in o) x[k] = o[k]; return x; }

var SEQ = ['🏃‍♂️', '👨‍👩‍👧‍👦', '❤️‍🔥', '🏳️‍🌈', '🧑🏽‍💻', '👩‍❤️‍👨', '🏴‍☠️', '🏃🏽‍♀️‍➡️'];
t('الرموز المركّبة (ZWJ) تُحفظ في كل الحقول النصية', function () {
  SEQ.forEach(function (e) {
    var r = X.validate(ok({ subject: 'م' + e, title: 'ع' + e, content: 'ن ' + e + ' ' + e, pages: e, homework: e, notes: e, group: e }));
    assert.ok(r.ok, e);
    ['subject', 'title', 'content', 'pages', 'homework', 'notes', 'group'].forEach(function (k) { assert.ok(r.values[k].indexOf(e) > -1, k + ' ' + e); });
  });
});
t('المنقّي القديم نفسه يفكّك هذه الرموز (سبب وجود الغلاف) ولم نغيّره', function () {
  var old = M.validate(ok({ content: '🏃‍♂️' }));
  assert.ok(old.ok && old.values.content !== '🏃‍♂️' && old.values.content.indexOf('\u200D') < 0, 'السلوك القديم كما هو');
  var base = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'docs', 'architecture', 'code-baseline.sha256'), 'utf8') ? JSON.stringify(fs.readFileSync(path.join(__dirname, '..', 'docs', 'architecture', 'code-baseline.sha256'), 'utf8')) : '""');
  var line = base.split('\n').filter(function (l) { return /js\/preps-model\.js/.test(l); })[0].split(/\s+/);
  assert.strictEqual(crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname, '..', 'js', 'preps-model.js'))).digest('hex'), line[0]);
});
t('ما عدا الرموز التعبيرية يبقى التنظيف القديم: ZWJ بين حروف عربية، ZWNJ، RLM/LRM، علامات الاتجاه، BOM، رموز التحكم', function () {
  var r = X.validate(ok({ content: 'ل\u200Dا و\u200Cز \u200Fأ\u200E \u202Eب\u202C \u2066ج\u2069 \uFEFFد \u0007هـ' }));
  assert.ok(r.ok);
  assert.strictEqual(r.values.content, M.validate(ok({ content: 'ل\u200Dا و\u200Cز \u200Fأ\u200E \u202Eب\u202C \u2066ج\u2069 \uFEFFد \u0007هـ' })).values.content);
  assert.ok(!/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF\u0007\uE000]/.test(r.values.content));
});
t('ZWJ بين رمز وحرف عربي أو في طرف النص أو مكرر يُحذف (لا يُحفظ إلا بين رمزين)', function () {
  ['😀\u200Dل', 'ل\u200D😀', '\u200D😀', '😀\u200D', '😀\u200D\u200D😀', '😀 \u200D 😀'].forEach(function (s) {
    var r = X.validate(ok({ content: s })); assert.ok(r.ok, s); assert.ok(r.values.content.indexOf('\u200D') < 0, JSON.stringify(s));
  });
});
t('حرف المنطقة الخاصة U+E000 لا يتحول إلى ZWJ: يُحذف من الإدخال', function () {
  var r = X.validate(ok({ content: 'ا\uE000ب 😀\uE000😀' })); assert.ok(r.ok);
  assert.ok(r.values.content.indexOf('\u200D') < 0 && r.values.content.indexOf('\uE000') < 0, JSON.stringify(r.values.content));
});
t('نفس أخطاء النموذج القديم: المطلوب والحدود والتاريخ (رسائل عربية)', function () {
  var cases = [{ subject: '' }, { title: ' ' }, { date: '' }, { date: '2026-02-30' }, { date: '1999-01-01' }, { content: '\u200B' }, { content: 'ا'.repeat(2001) }, { title: 'ا'.repeat(121) }, { subject: 'ا'.repeat(81) }];
  cases.forEach(function (c) {
    var a = X.validate(ok(c)), b = M.validate(ok(c));
    assert.strictEqual(a.ok, b.ok, JSON.stringify(c)); assert.strictEqual(a.firstError, b.firstError, JSON.stringify(c));
    assert.deepStrictEqual(a.errors, b.errors, JSON.stringify(c)); assert.ok(/[\u0600-\u06FF]/.test(a.errors[a.firstError]));
  });
});
t('الصف/الشعبة: اختياري، يُنظَّف، وحده الأقصى 60', function () {
  assert.ok(!('group' in X.validate(ok({})).values)); assert.ok(!('group' in X.validate(ok({ group: '  \u200F ' })).values));
  assert.strictEqual(X.validate(ok({ group: '  الخامس   العلمي\u200F — ب ' })).values.group, 'الخامس العلمي — ب');
  assert.ok(X.validate(ok({ group: 'ا'.repeat(60) })).ok);
  var r = X.validate(ok({ group: 'ا'.repeat(61) })); assert.ok(!r.ok && r.firstError === 'group' && /60/.test(r.errors.group));
  var r2 = X.validate(ok({ subject: '', group: 'ا'.repeat(61) })); assert.strictEqual(r2.firstError, 'subject'); assert.ok(r2.errors.group);
});
t('مُدخلات غريبة لا ترمي استثناءً: null وأرقام وكائنات وبلا حقول', function () {
  assert.ok(!X.validate().ok); assert.ok(!X.validate(null).ok); assert.ok(!X.validate({}).ok);
  var r = X.validate(ok({ content: 12345, pages: null, homework: undefined })); assert.ok(r.ok); assert.strictEqual(r.values.content, '12345');
});
t('عدّ الحروف في الحدود لا يتغير بسبب الحرف المؤقت: محتوى 2000 حرف بالضبط ينجح و2001 يفشل', function () {
  var e = '🏃‍♂️', body = 'ا'.repeat(2000 - e.length);
  assert.ok(X.validate(ok({ content: body + e })).ok); assert.ok(!X.validate(ok({ content: body + e + 'ب' })).ok);
});
console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
