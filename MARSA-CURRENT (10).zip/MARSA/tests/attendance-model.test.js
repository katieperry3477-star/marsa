// اختبارات منطق الحضور (4.03) — بعيداً عن DOM. تشغيل: node tests/attendance-model.test.js (لا يحتاج مكتبات)
var assert = require('assert'), cp = require('child_process'), path = require('path');
var M = require('../js/attendance-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake(opts) { var d = {}; opts = opts || {}; return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { if (opts.failWrite) throw new Error('QuotaExceededError'); d[k] = String(v); }, removeItem: function (k) { delete d[k]; } }; }
var A = { studentId: 'stu_a', name: 'أحمد', studentCode: 'AB12' }, B = { studentId: 'stu_b', name: 'بشرى', studentCode: 'CD34' }, C = { studentId: 'stu_c', name: 'جاسم', studentCode: 'EF56' };
var ACT = [A, B], ALL = [A, B, C], TODAY = '2026-10-22', CID = 'cls_t1';
function rec(sid, date, status, extra) { var r = { recordId: 'att_' + sid + date, classId: CID, studentId: sid, date: date, status: status }; for (var k in (extra || {})) r[k] = extra[k]; return r; }

t('الحالات الأربع وتسمياتها العربية', function () {
  assert.deepStrictEqual(M.STATUSES, ['present', 'absent', 'late', 'excused']);
  assert.deepStrictEqual(M.STATUSES.map(M.label), ['حاضر', 'غائب', 'متأخر', 'بعذر']);
  assert.strictEqual(M.label(null), 'لم يُسجَّل'); assert.strictEqual(M.label('bogus'), 'لم يُسجَّل');
});
t('validateEntry: كل حالة من الأربع صالحة، وغيرها مرفوضة', function () {
  M.STATUSES.forEach(function (s) { assert.ok(M.validateEntry({ studentId: 'stu_a', date: '2026-10-21', status: s }, { today: TODAY, activeIds: ['stu_a'] }).ok, s); });
  ['', 'حاضر', 'PRESENT', 'unknown', null, undefined].forEach(function (s) { assert.ok(M.validateEntry({ studentId: 'stu_a', date: '2026-10-21', status: s }, { today: TODAY }).errors.status, String(s)); });
});
t('التاريخ غير الصحيح: فارغ، يوم غير موجود، صيغة، خارج النطاق، مستقبلي', function () {
  ['', '2026-02-30', '2026-13-01', '2026/10/21', '21-10-2026', '2026-1-5', '1999-12-31', '2101-01-01', 'abc'].forEach(function (d) { assert.ok(M.validateDate(d, TODAY), 'يجب رفض ' + d); });
  assert.ok(M.validateDate('2026-10-23', TODAY), 'بعد اليوم'); assert.strictEqual(M.validateDate(TODAY, TODAY), null); assert.strictEqual(M.validateDate('2026-10-21', TODAY), null);
  assert.strictEqual(M.validateDate('2028-02-29', '2030-01-01'), null); assert.ok(M.validateDate('2027-02-29', '2030-01-01'));
});
t('studentId: صيغة صالحة وينتمي للفعّالين فقط (لا الاسم ولا الموضع)', function () {
  var ctx = { today: TODAY, activeIds: ['stu_a', 'stu_b'] };
  assert.ok(M.validateEntry({ studentId: 'stu_c', date: TODAY, status: 'present' }, ctx).errors.studentId);
  assert.ok(M.validateEntry({ studentId: 'أحمد', date: TODAY, status: 'present' }, ctx).errors.studentId);
  assert.ok(M.validateEntry({ studentId: '1', date: TODAY, status: 'present' }, ctx).errors.studentId);
  assert.ok(M.validateEntry({ studentId: '', date: TODAY, status: 'present' }, ctx).errors.studentId);
  assert.ok(M.validateEntry({ studentId: 'stu_a', date: TODAY, status: 'present' }, ctx).ok);
});
t('الملاحظة: تنظيف الخفي والتحكم، وحد 200 حرف', function () {
  assert.strictEqual(M.cleanNote('  مرض\u200B \n  خفيف\u0007 '), 'مرض خفيف');
  assert.ok(M.validateEntry({ studentId: 'stu_a', date: TODAY, status: 'late', note: new Array(202).join('ا') }, { today: TODAY }).errors.note);
  assert.ok(M.validateEntry({ studentId: 'stu_a', date: TODAY, status: 'late', note: new Array(201).join('ا') }, { today: TODAY }).ok);
});
t('الحالة غير المسجلة واضحة ولا تتحول إلى حاضر: buildDay بلا سجلات', function () {
  var d = M.buildDay(ACT, ALL, [], TODAY);
  assert.strictEqual(d.rows.length, 2); d.rows.forEach(function (r) { assert.strictEqual(r.status, null); assert.strictEqual(r.record, null); });
  assert.deepStrictEqual(M.countRows(d.rows), { present: 0, absent: 0, late: 0, excused: 0, unrecorded: 2, total: 2 });
});
t('أرقام القائمة من الترتيب فقط وليست معرّفاً', function () {
  var d = M.buildDay([B, A], ALL, [], TODAY); assert.deepStrictEqual(d.rows.map(function (r) { return r.number; }), [1, 2]);
  assert.deepStrictEqual(d.rows.map(function (r) { return r.studentId; }), ['stu_b', 'stu_a']);
});
t('العدّادات من السجلات الفعلية لليوم المحدد فقط', function () {
  var recs = [rec('stu_a', TODAY, 'present'), rec('stu_b', TODAY, 'excused'), rec('stu_a', '2026-10-21', 'absent')];
  var c = M.countRows(M.buildDay(ACT, ALL, recs, TODAY).rows);
  assert.deepStrictEqual(c, { present: 1, absent: 0, late: 0, excused: 1, unrecorded: 0, total: 2 });
  c = M.countRows(M.buildDay(ACT, ALL, recs, '2026-10-21').rows); assert.strictEqual(c.absent, 1); assert.strictEqual(c.unrecorded, 1);
});
t('الأرشفة: السجل القديم لطالب مؤرشف يُقرأ في legacy ولا يدخل العدّادات ولا الصفوف', function () {
  var recs = [rec('stu_c', TODAY, 'absent'), rec('stu_ghost', TODAY, 'late'), rec('stu_a', TODAY, 'present')];
  var d = M.buildDay(ACT, ALL, recs, TODAY);
  assert.strictEqual(d.rows.length, 2); assert.strictEqual(M.countRows(d.rows).absent, 0);
  assert.deepStrictEqual(d.legacy.map(function (x) { return x.kind + ':' + x.record.studentId; }).sort(), ['archived:stu_c', 'unknown:stu_ghost']);
  assert.strictEqual(d.legacy.filter(function (x) { return x.kind === 'archived'; })[0].name, 'جاسم');
});
t('planSave: لا تسجيل تلقائي لمن لم يُختر له حالة ولا إنشاء بلا قرار', function () {
  var p = M.planSave({ stu_a: { status: 'present' }, stu_b: {} }, [], { date: TODAY, today: TODAY, activeIds: ['stu_a', 'stu_b'] });
  assert.ok(p.ok); assert.strictEqual(p.records.length, 1); assert.strictEqual(p.records[0].studentId, 'stu_a'); assert.strictEqual(p.created, 1);
  assert.strictEqual(p.records[0].recordId, undefined, 'لا يُنشأ recordId في النموذج');
});
t('planSave: تعديل سجل قائم يحفظ recordId وclassId وcreatedAt ولا يضيف تكراراً', function () {
  var ex = rec('stu_a', TODAY, 'present', { createdAt: '2026-10-22T05:00:00.000Z', updatedAt: '2026-10-22T05:00:00.000Z' });
  var p = M.planSave({ stu_a: { status: 'absent', note: 'مريض' } }, [ex], { date: TODAY, today: TODAY, activeIds: ['stu_a'] });
  assert.strictEqual(p.records.length, 1); assert.strictEqual(p.updated, 1); assert.strictEqual(p.created, 0);
  assert.strictEqual(p.records[0].recordId, ex.recordId); assert.strictEqual(p.records[0].classId, CID); assert.strictEqual(p.records[0].createdAt, ex.createdAt); assert.strictEqual(p.records[0].note, 'مريض');
  assert.strictEqual(ex.status, 'present', 'السجل الأصلي لا يتغير');
});
t('planSave: بلا تغيير حقيقي لا سجلات؛ وحذف الملاحظة يزيل الحقل', function () {
  var ex = rec('stu_a', TODAY, 'late', { note: 'زحمة' });
  assert.strictEqual(M.planSave({ stu_a: { status: 'late', note: 'زحمة' } }, [ex], { date: TODAY, today: TODAY, activeIds: ['stu_a'] }).records.length, 0);
  var p = M.planSave({ stu_a: { status: 'late', note: '' } }, [ex], { date: TODAY, today: TODAY, activeIds: ['stu_a'] });
  assert.strictEqual(p.records.length, 1); assert.ok(!('note' in p.records[0]));
});
t('planSave: طالب غير فعّال أو تاريخ مستقبلي أو حالة خاطئة ⇒ ok=false ولا سجلات مقبولة تُهرَّب', function () {
  var p = M.planSave({ stu_c: { status: 'present' } }, [], { date: TODAY, today: TODAY, activeIds: ['stu_a'] });
  assert.strictEqual(p.ok, false); assert.strictEqual(p.errors[0].studentId, 'stu_c');
  p = M.planSave({ stu_a: { status: 'present' } }, [], { date: '2026-10-30', today: TODAY, activeIds: ['stu_a'] }); assert.strictEqual(p.ok, false);
  p = M.planSave({ stu_a: { status: 'oops' } }, [], { date: TODAY, today: TODAY, activeIds: ['stu_a'] }); assert.strictEqual(p.records.length, 0); // حالة غير معروفة = لا قرار
});
t('findConflicts: يكشف التكرار لنفس (studentId,date) دون حذف أو اختيار فائز', function () {
  var recs = [rec('stu_a', TODAY, 'present'), { recordId: 'att_dup', classId: CID, studentId: 'stu_a', date: TODAY, status: 'absent' }, rec('stu_b', TODAY, 'present')];
  var c = M.findConflicts(recs); assert.strictEqual(c.length, 1); assert.deepStrictEqual(c[0].recordIds.sort(), ['att_dup', 'att_stu_a' + TODAY].sort()); assert.strictEqual(recs.length, 3);
  assert.strictEqual(M.findConflicts([rec('stu_a', TODAY, 'present'), rec('stu_a', '2026-10-21', 'present')]).length, 0);
});
t('البحث بالاسم أو الكود (توحيد الهمزات والتشكيل) وفلتر الحالة وغير المسجل', function () {
  var recs = [rec('stu_a', TODAY, 'absent')], rows = M.buildDay([{ studentId: 'stu_a', name: 'أَحمد', studentCode: 'AB12' }, { studentId: 'stu_b', name: 'إبراهيم', studentCode: 'CD34' }, { studentId: 'stu_c', name: 'ليلى', studentCode: 'zz9' }], ALL, recs, TODAY).rows;
  function ids(o) { return M.filterRows(rows, o).map(function (r) { return r.studentId; }); }
  assert.deepStrictEqual(ids({ query: 'احمد' }), ['stu_a']); assert.deepStrictEqual(ids({ query: 'ابراهيم' }), ['stu_b']);
  assert.deepStrictEqual(ids({ query: 'ab12' }), ['stu_a']); assert.deepStrictEqual(ids({ query: 'ZZ9' }), ['stu_c']);
  assert.deepStrictEqual(ids({ status: 'absent' }), ['stu_a']); assert.deepStrictEqual(ids({ status: 'unrecorded' }), ['stu_b', 'stu_c']);
  assert.deepStrictEqual(ids({ query: 'xyz' }), []); assert.deepStrictEqual(ids({}), ['stu_a', 'stu_b', 'stu_c']); assert.deepStrictEqual(ids({ query: '   ' }), ['stu_a', 'stu_b', 'stu_c']);
});
t('summarizeDays: فلاتر التاريخ شاملة، فلتر الحالة، والفعّالون منفصلون عن legacy', function () {
  var recs = [rec('stu_a', '2026-10-20', 'present'), rec('stu_b', '2026-10-20', 'absent'), rec('stu_a', '2026-10-21', 'late'), rec('stu_c', '2026-10-21', 'absent'), rec('stu_a', '2026-10-22', 'excused')];
  var all = M.summarizeDays(recs, { activeIds: ['stu_a', 'stu_b'] });
  assert.deepStrictEqual(all.map(function (d) { return d.date; }), ['2026-10-22', '2026-10-21', '2026-10-20']);
  assert.strictEqual(all[1].late, 1); assert.strictEqual(all[1].absent, 0); assert.strictEqual(all[1].legacy, 1);
  assert.deepStrictEqual(M.summarizeDays(recs, { activeIds: ['stu_a', 'stu_b'], from: '2026-10-21', to: '2026-10-21' }).map(function (d) { return d.date; }), ['2026-10-21']);
  assert.deepStrictEqual(M.summarizeDays(recs, { activeIds: ['stu_a', 'stu_b'], status: 'absent' }).map(function (d) { return d.date; }), ['2026-10-20']);
});
t('isDirty: يميّز التعديل الفعلي عن عدم التغيير', function () {
  var rows = M.buildDay(ACT, ALL, [rec('stu_a', TODAY, 'present', { note: 'x' })], TODAY).rows;
  assert.strictEqual(M.isDirty({ stu_a: { status: 'present', note: 'x' } }, rows), false);
  assert.strictEqual(M.isDirty({ stu_a: { status: 'absent', note: 'x' } }, rows), true);
  assert.strictEqual(M.isDirty({ stu_a: { status: 'present', note: 'x' }, stu_b: { status: 'present' } }, rows), true);
  assert.strictEqual(M.isDirty({ stu_a: { status: 'present', note: 'x' }, stu_b: {} }, rows), false);
});
t('حدود اليوم المحلي: localDate من أجزاء Date المحلية لا UTC (في 3 مناطق زمنية)', function () {
  var code = "var M=require('./js/attendance-model.js');var a=new Date(2026,9,21,23,59,59),b=new Date(2026,9,22,0,0,1),c=new Date(2026,11,31,23,30);console.log([M.localDate(a),M.localDate(b),M.localDate(c),M.addDays('2026-10-31',1),M.addDays('2026-03-01',-1),M.addDays('2028-03-01',-1)].join(','))";
  ['Asia/Baghdad', 'Pacific/Kiritimati', 'America/Los_Angeles', 'UTC'].forEach(function (tz) {
    var out = cp.execFileSync(process.execPath, ['-e', code], { cwd: path.resolve(__dirname, '..'), env: { TZ: tz, PATH: process.env.PATH } }).toString().trim();
    assert.strictEqual(out, '2026-10-21,2026-10-22,2026-12-31,2026-11-01,2026-02-28,2028-02-29', tz + ': ' + out);
  });
});
t('formatDate وisLocalDate', function () { assert.strictEqual(M.formatDate('2026-10-05'), '05/10/2026'); assert.strictEqual(M.formatDate('bad'), 'bad'); assert.strictEqual(M.isLocalDate('2026-02-29'), false); assert.strictEqual(M.isLocalDate(20261021), false); });
t('sortRecords: الأحدث تاريخاً ثم الاسم، ولا يغيّر الأصل', function () {
  var recs = [rec('stu_b', '2026-10-21', 'present'), rec('stu_a', '2026-10-22', 'present'), rec('stu_a', '2026-10-21', 'present')], names = { stu_a: 'أحمد', stu_b: 'بشرى' };
  var s = M.sortRecords(recs, function (id) { return names[id]; });
  assert.deepStrictEqual(s.map(function (r) { return r.studentId + r.date; }), ['stu_a2026-10-22', 'stu_a2026-10-21', 'stu_b2026-10-21']); assert.strictEqual(recs[0].studentId, 'stu_b');
});

// ===== تكامل النموذج مع المتجر الحقيقي (تخزين وهمي في الذاكرة) =====
t('تكامل: حفظ جماعي ذرّي عبر upsertMany، ثم تعديل نفس اليوم يبقي recordId بلا تكرار', function () {
  var st = fake(), s = S.create({ storage: st }), ctx = { date: TODAY, today: TODAY, activeIds: ['stu_a', 'stu_b'] }, p, out, ids1, r2;
  p = M.planSave({ stu_a: { status: 'present' }, stu_b: { status: 'absent', note: 'سفر' } }, [], ctx);
  out = s.upsertMany('attendance', CID, p.records); assert.ok(out.ok, out.error);
  ids1 = s.readCollection('attendance', CID).records.map(function (r) { return r.studentId + ':' + r.recordId; }).sort();
  assert.ok(ids1.every(function (x) { return /:att_/.test(x); }));
  r2 = s.readCollection('attendance', CID).records;
  p = M.planSave({ stu_a: { status: 'late' }, stu_b: { status: 'absent', note: 'سفر' } }, r2, ctx);
  assert.strictEqual(p.records.length, 1); out = s.upsertMany('attendance', CID, p.records); assert.ok(out.ok);
  var after = s.readCollection('attendance', CID).records;
  assert.strictEqual(after.length, 2); assert.deepStrictEqual(after.map(function (r) { return r.studentId + ':' + r.recordId; }).sort(), ids1);
  assert.strictEqual(M.findByPair(after, 'stu_a', TODAY).status, 'late');
});
t('تكامل: خطة قديمة (لا تعرف بسجل أُنشئ بين القراءتين) ⇒ المتجر يرفض duplicate ولا يُكتب شيء', function () {
  var st = fake(), s = S.create({ storage: st }), ctx = { date: TODAY, today: TODAY, activeIds: ['stu_a'] }, stale = M.planSave({ stu_a: { status: 'present' } }, [], ctx), before, out;
  assert.ok(s.upsertRecord('attendance', CID, { studentId: 'stu_a', date: TODAY, status: 'absent' }).ok);
  before = st.d['marsa.academic.attendance.' + CID];
  out = s.upsertMany('attendance', CID, stale.records);
  assert.strictEqual(out.ok, false); assert.strictEqual(out.status, 'duplicate'); assert.strictEqual(st.d['marsa.academic.attendance.' + CID], before);
});
t('تكامل: فشل التخزين ⇒ ok=false بلا نجاح كاذب، والمخزّن كما كان', function () {
  var good = fake(), s0 = S.create({ storage: good }); s0.upsertRecord('attendance', CID, { studentId: 'stu_a', date: '2026-10-21', status: 'present' });
  var raw = good.d['marsa.academic.attendance.' + CID], bad = fake({ failWrite: true }); bad.d['marsa.academic.attendance.' + CID] = raw;
  var s = S.create({ storage: bad }), p = M.planSave({ stu_b: { status: 'absent' } }, s.readCollection('attendance', CID).records, { date: TODAY, today: TODAY, activeIds: ['stu_a', 'stu_b'] });
  var out = s.upsertMany('attendance', CID, p.records); assert.strictEqual(out.ok, false); assert.ok(/تعذّر|لم يُحفظ/.test(out.error)); assert.strictEqual(bad.d['marsa.academic.attendance.' + CID], raw);
});
t('تكامل: تكرار مخزَّن قديماً ⇒ المتجر يحجب القراءة (لا يُطمس ولا يُعرض فارغاً) وfindConflicts يكشفه', function () {
  var st = fake(), s = S.create({ storage: st }), dup = [rec('stu_a', TODAY, 'present'), { recordId: 'att_other', classId: CID, studentId: 'stu_a', date: TODAY, status: 'absent' }], r, raw;
  raw = JSON.stringify({ schemaVersion: 1, classId: CID, records: dup }); st.d['marsa.academic.attendance.' + CID] = raw;
  r = s.readCollection('attendance', CID); assert.strictEqual(r.ok, false); assert.strictEqual(r.blocked, true); assert.strictEqual(st.d['marsa.academic.attendance.' + CID], raw);
  assert.ok(Object.keys(st.d).some(function (k) { return /\.backup/.test(k); })); assert.strictEqual(M.findConflicts(dup).length, 1);
  assert.strictEqual(s.upsertRecord('attendance', CID, { studentId: 'stu_b', date: TODAY, status: 'present' }).ok, false);
});
t('تكامل: عزل الصفوف — سجل صف لا يظهر في صف آخر، وclassId مختلف مرفوض', function () {
  var st = fake(), s = S.create({ storage: st });
  assert.ok(s.upsertRecord('attendance', 'cls_a', { studentId: 'stu_a', date: TODAY, status: 'present' }).ok);
  assert.strictEqual(s.readCollection('attendance', 'cls_b').records.length, 0);
  assert.strictEqual(s.upsertRecord('attendance', 'cls_b', { classId: 'cls_a', studentId: 'stu_a', date: TODAY, status: 'present' }).status, 'class-mismatch');
  assert.strictEqual(M.countRows(M.buildDay(ACT, ALL, s.readCollection('attendance', 'cls_b').records, TODAY).rows).present, 0);
});
t('تكامل: دفعة بسجل مرفوض (تاريخ غير صالح) ⇒ لا يُحفظ شيء من الدفعة', function () {
  var st = fake(), s = S.create({ storage: st }), out = s.upsertMany('attendance', CID, [{ studentId: 'stu_a', date: TODAY, status: 'present' }, { studentId: 'stu_b', date: '2026-02-30', status: 'present' }]);
  assert.strictEqual(out.ok, false); assert.strictEqual(st.length, 0);
});

console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
