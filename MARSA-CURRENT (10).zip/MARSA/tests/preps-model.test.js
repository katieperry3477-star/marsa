// تشغيل: node tests/preps-model.test.js  (لا يحتاج مكتبات)
var assert = require('assert'), cp = require('child_process'), path = require('path');
var M = require('../js/preps-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake() { var d = {}; return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { d[k] = String(v); }, removeItem: function (k) { delete d[k]; } }; }
var ok = { subject: 'مادة', title: 'موضوع', date: '2026-10-23', content: 'نقاط' };
function v(o) { var x = {}, k; for (k in ok) x[k] = ok[k]; for (k in o) x[k] = o[k]; return M.validate(x); }
function ids(l) { return l.map(function (x) { return x.recordId; }); }

t('required: subject, title, date, content; optional: pages, homework, notes', function () {
  assert.ok(v({}).ok);
  assert.ok(v({ subject: '' }).errors.subject); assert.ok(v({ title: '' }).errors.title); assert.ok(v({ date: '' }).errors.date); assert.ok(v({ content: ' \n ' }).errors.content);
  assert.ok(v({ pages: '', homework: '', notes: '' }).ok);
});
t('invisible-only text is empty; one-line fields collapse, multiline keeps newlines', function () {
  assert.ok(v({ title: '\u200B\u200F\u202E ' }).errors.title);
  var r = v({ subject: '  رياضيات \n ٢ ', content: 'أ\r\n\r\n\r\n\r\nب  ' });
  assert.strictEqual(r.values.subject, 'رياضيات ٢'); assert.strictEqual(r.values.content, 'أ\n\nب');
});
t('length limits enforced per field (at limit ok, over limit rejected)', function () {
  var L = M.LIMITS, k;
  for (k in L) { var o = {}; o[k] = new Array(L[k] + 2).join('ا'); assert.ok(v(o).errors[k], k + ' over'); o[k] = new Array(L[k] + 1).join('ا'); assert.ok(!v(o).errors[k], k + ' at limit'); }
});
t('date validation: format, real day, range; past/future both accepted', function () {
  assert.ok(v({ date: '2026-02-30' }).errors.date); assert.ok(v({ date: '23-10-2026' }).errors.date); assert.ok(v({ date: '1999-12-31' }).errors.date); assert.ok(v({ date: '2101-01-01' }).errors.date);
  assert.ok(v({ date: '2028-02-29' }).ok); assert.ok(v({ date: '2020-01-01' }).ok); assert.ok(v({ date: '2030-01-01' }).ok);
});
t('firstError follows field order', function () { assert.strictEqual(v({ subject: '', content: '' }).firstError, 'subject'); assert.strictEqual(v({ content: '' }).firstError, 'content'); });
t('markup stays plain text verbatim', function () { var r = v({ title: '<img src=x onerror=alert(1)>' }); assert.ok(r.ok); assert.strictEqual(r.values.title, '<img src=x onerror=alert(1)>'); });
t('buildRecord: empty optionals removed, existing recordId/classId/createdAt/extra kept, never creates recordId', function () {
  var r = M.buildRecord(M.validate(ok).values, null);
  assert.ok(!('recordId' in r) && !('pages' in r) && !('homework' in r) && !('notes' in r)); assert.strictEqual(r.content, 'نقاط');
  var ex = { recordId: 'prep_1', classId: 'cls_a', createdAt: 'T0', pages: 'قديم', extra: 7, subject: 'x', title: 'y', date: '2026-01-01', content: 'z' };
  var e = M.buildRecord(M.validate({ subject: 'م', title: 'ع', date: '2026-10-21', content: 'ج', homework: 'و' }).values, ex);
  assert.strictEqual(e.recordId, 'prep_1'); assert.strictEqual(e.classId, 'cls_a'); assert.strictEqual(e.createdAt, 'T0'); assert.strictEqual(e.extra, 7);
  assert.ok(!('pages' in e)); assert.strictEqual(e.homework, 'و'); assert.strictEqual(ex.pages, 'قديم');
});
t('addDays: local calendar, month/year/leap boundaries, bad input', function () {
  assert.strictEqual(M.addDays('2026-10-22', 1), '2026-10-23'); assert.strictEqual(M.addDays('2026-10-31', 1), '2026-11-01');
  assert.strictEqual(M.addDays('2026-12-31', 1), '2027-01-01'); assert.strictEqual(M.addDays('2028-02-28', 1), '2028-02-29'); assert.strictEqual(M.addDays('2027-02-28', 1), '2027-03-01');
  assert.strictEqual(M.addDays('2026-01-01', -1), '2025-12-31'); assert.strictEqual(M.addDays('x', 1), ''); assert.strictEqual(M.addDays('2026-02-30', 1), '');
});
t('groupByDay: today / tomorrow / other, by local today', function () {
  var l = [{ recordId: 'a', date: '2026-10-22' }, { recordId: 'b', date: '2026-10-23' }, { recordId: 'c', date: '2026-10-25' }, { recordId: 'd', date: '2026-10-20' }, { recordId: 'e' }, { recordId: 'f', date: '2026-10-22' }];
  var g = M.groupByDay(l, '2026-10-22');
  assert.deepStrictEqual(ids(g.today), ['a', 'f']); assert.deepStrictEqual(ids(g.tomorrow), ['b']); assert.deepStrictEqual(ids(g.other), ['c', 'd', 'e']); assert.strictEqual(g.tomorrowDate, '2026-10-23');
  g = M.groupByDay(l, '2026-10-31'); assert.strictEqual(g.tomorrowDate, '2026-11-01');
});
t('sort nearest first: upcoming ascending, then past newest-first, then no/invalid date; ties by createdAt then id; input untouched', function () {
  var l = [{ recordId: 'p1', date: '2026-10-01', createdAt: '1' }, { recordId: 'u3', date: '2026-11-30', createdAt: '1' }, { recordId: 'p2', date: '2026-10-20', createdAt: '1' }, { recordId: 'x', date: 5 }, { recordId: 'u1', date: '2026-10-22', createdAt: '2' }, { recordId: 'u0', date: '2026-10-22', createdAt: '1' }, { recordId: 'u2', date: '2026-10-25', createdAt: '1' }, { recordId: 'n' }];
  assert.deepStrictEqual(ids(M.sortRecords(l, '2026-10-22')), ['u0', 'u1', 'u2', 'u3', 'p2', 'p1', 'n', 'x']);
  assert.strictEqual(l[0].recordId, 'p1');
});
t('search by title or subject only; hamza/taa-marbuta/diacritics insensitive', function () {
  var l = [{ recordId: '1', subject: 'الحاسوب', title: 'الذاكرة العشوائية', content: 'سرّي', notes: 'خفي' }, { recordId: '2', subject: 'رياضيات', title: 'المعادلات' }];
  assert.strictEqual(M.filterRecords(l, 'ذاكره').length, 1); assert.strictEqual(M.filterRecords(l, 'رياضيّات').length, 1);
  assert.strictEqual(M.filterRecords(l, 'سري').length, 0); assert.strictEqual(M.filterRecords(l, 'خفي').length, 0); assert.strictEqual(M.filterRecords(l, '').length, 2); assert.strictEqual(M.filterRecords(l, '<b>').length, 0);
});
t('subjectsOf lists only what the user wrote (no fixed list)', function () {
  assert.deepStrictEqual(M.subjectsOf([]), []);
  assert.deepStrictEqual(M.subjectsOf([{ subject: 'علوم', updatedAt: '1' }, { subject: 'علوم ', updatedAt: '2' }, { subject: 'فيزياء', updatedAt: '3' }]), ['فيزياء', 'علوم']);
});
t('formatDate never throws on bad input', function () { assert.strictEqual(M.formatDate(''), 'بلا تاريخ'); assert.strictEqual(M.formatDate(undefined), 'بلا تاريخ'); assert.strictEqual(M.formatDate('2026-02-30'), '2026-02-30'); });
t('store integration: add → edit keeps recordId/createdAt → delete; classes and types stay separate', function () {
  var s = S.create({ storage: fake() }), a, id, b;
  a = s.upsertRecord('preparations', 'cls_a', M.buildRecord(M.validate(ok).values, null));
  assert.ok(a.ok && a.created); id = a.record.recordId; assert.ok(/^prep_/.test(id));
  b = s.upsertRecord('preparations', 'cls_a', M.buildRecord(M.validate({ subject: 'م2', title: 'ع2', date: '2026-10-24', content: 'ج2' }).values, s.getRecord('preparations', 'cls_a', id).record));
  assert.ok(b.ok && !b.created && b.record.recordId === id && b.record.createdAt === a.record.createdAt);
  assert.strictEqual(s.readCollection('preparations', 'cls_b').records.length, 0);
  assert.strictEqual(s.readCollection('dailyLessons', 'cls_a').records.length, 0, 'prep must not appear in lessons');
  s.upsertRecord('preparations', 'cls_b', M.buildRecord(M.validate(ok).values, null));
  s.upsertRecord('dailyLessons', 'cls_a', { subject: 's', title: 't', date: '2026-10-22' });
  assert.strictEqual(s.readCollection('preparations', 'cls_a').records.length, 1); assert.strictEqual(s.readCollection('preparations', 'cls_b').records.length, 1);
  assert.ok(s.deleteRecord('preparations', 'cls_a', id).ok);
  assert.strictEqual(s.readCollection('preparations', 'cls_b').records.length, 1); assert.strictEqual(s.readCollection('dailyLessons', 'cls_a').records.length, 1, 'deleting a prep must not touch lessons');
});
t('store failure surfaces as not-ok (no false success)', function () {
  var st = fake(), s = S.create({ storage: st }), r;
  st.setItem = function () { throw new Error('QuotaExceededError'); };
  r = s.upsertRecord('preparations', 'cls_a', M.buildRecord(M.validate(ok).values, null));
  assert.strictEqual(r.ok, false); assert.strictEqual(s.readCollection('preparations', 'cls_a').records.length, 0);
});

// المنطقة الزمنية: اليوم وباجر المحليان لا ينقلبان بسبب UTC (عملية فرعية لكل TZ)
['Asia/Baghdad', 'UTC', 'America/Los_Angeles', 'Pacific/Kiritimati', 'Pacific/Pago_Pago'].forEach(function (tz) {
  t('timezone ' + tz + ': local today/tomorrow near midnight and across DST/month ends', function () {
    var code = "var S=require('./js/academic-store.js'),M=require('./js/preps-model.js'),r=[];" +
      "[new Date(2026,9,21,0,30),new Date(2026,9,21,23,59),new Date(2026,9,31,23,59),new Date(2026,2,8,23,30),new Date(2026,10,1,23,30),new Date(2026,11,31,0,1)].forEach(function(d){var t=S.toLocalDate(d);r.push(t+'>'+M.addDays(t,1));});console.log(JSON.stringify(r));";
    var out = cp.execFileSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: Object.assign({}, process.env, { TZ: tz }) }).toString().trim();
    assert.strictEqual(out, JSON.stringify(['2026-10-21>2026-10-22', '2026-10-21>2026-10-22', '2026-10-31>2026-11-01', '2026-03-08>2026-03-09', '2026-11-01>2026-11-02', '2026-12-31>2027-01-01']), tz + ' -> ' + out);
  });
});
console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
