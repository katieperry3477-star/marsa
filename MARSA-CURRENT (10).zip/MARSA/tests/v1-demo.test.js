// تشغيل: node tests/v1-demo.test.js  (لا يحتاج مكتبات)
// نموذج البيانات التجريبية الاصطناعية (01.03): بناء، تحقق صارم، حساب الأيام، تجميع الامتحانات، صياغة عربية، ونقاء الملف (بلا DOM ولا شبكة).
var assert = require('assert'), fs = require('fs'), path = require('path');
var D = require('../js/v1-demo.js');
var n = 0, f = 0;
function T(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '::', e && e.message); } }
function clone(o) { return JSON.parse(JSON.stringify(o)); }
var TODAY = '2026-11-03'; // الثلاثاء

T('البناء: أسبوع دراسة الأحد–الخميس بخمسة دروس يومياً والجمعة والسبت فارغان', function () {
  var d = D.build(TODAY), i;
  assert.strictEqual(d.schemaVersion, 1); assert.strictEqual(d.synthetic, true); assert.strictEqual(d.builtFor, TODAY);
  assert.strictEqual(d.timetable.length, 7);
  for (i = 0; i <= 4; i++) assert.strictEqual(d.timetable[i].length, 5, 'يوم ' + i);
  assert.strictEqual(d.timetable[5].length, 0); assert.strictEqual(d.timetable[6].length, 0);
});
T('البناء: خمسة امتحانات (ثلاثة قادمة واثنان منتهيان) بمعرّفات فريدة وكلها في أيام دراسة', function () {
  var d = D.build(TODAY), g = D.examGroups(d, TODAY), ids = {};
  assert.strictEqual(d.exams.length, 5);
  d.exams.forEach(function (e) { assert.ok(!ids[e.id]); ids[e.id] = 1; assert.ok(D.isSchoolDay(e.date), e.date); });
  assert.ok(g.nearest); assert.strictEqual(g.upcoming.length, 2); assert.strictEqual(g.finished.length, 2);
});
T('البناء صالح دائماً: 800 يوم متتالٍ يمرّ كلها من validate (بما فيها نهايات الأشهر والسنة الكبيسة)', function () {
  var day = '2026-01-01', i;
  for (i = 0; i < 800; i++) { assert.ok(D.validate(D.build(day)), day); day = D.shift(day, 1); }
});
T('البناء لا يعتمد على تاريخ غير صالح: يعود لتاريخ ثابت ولا يرمي', function () {
  assert.ok(D.validate(D.build('غير تاريخ'))); assert.ok(D.validate(D.build(undefined)));
});
T('التحقق يرفض الأشكال الخاطئة (فارغ، مصفوفة، إصدار، علم اصطناعي، تاريخ، جدول، وقت، مادة، معرّف مكرر، حدّ الامتحانات، طول النص)', function () {
  var ok = D.build(TODAY), bad = [];
  function mut(fn) { var c = clone(ok); fn(c); bad.push(c); }
  bad.push(null, undefined, [], 'x', 5);
  mut(function (c) { c.schemaVersion = 2; }); mut(function (c) { c.schemaVersion = '1'; });
  mut(function (c) { c.synthetic = false; }); mut(function (c) { delete c.synthetic; });
  mut(function (c) { c.builtFor = '2026-02-30'; }); mut(function (c) { c.builtFor = 'x'; });
  mut(function (c) { c.timetable.pop(); }); mut(function (c) { c.timetable[0] = 'x'; });
  mut(function (c) { c.timetable[0][0].start = '8:00'; }); mut(function (c) { c.timetable[0][0].end = '25:00'; });
  mut(function (c) { c.timetable[0][0].subject = ''; }); mut(function (c) { c.timetable[0][0].subject = 'م'.repeat(81); });
  mut(function (c) { c.timetable[0] = new Array(13).fill(c.timetable[0][0]); });
  mut(function (c) { c.exams[1].id = c.exams[0].id; }); mut(function (c) { c.exams[0].id = 'قصير'; }); mut(function (c) { c.exams[0].id = 'abc'; });
  mut(function (c) { c.exams[0].date = '2026-13-01'; }); mut(function (c) { c.exams[0].time = '9am'; });
  mut(function (c) { c.exams[0].subject = '   '; }); mut(function (c) { c.exams[0].topics = 'ن'.repeat(401); }); mut(function (c) { c.exams[0].notes = 5; });
  mut(function (c) { c.exams = []; while (c.exams.length < 41) c.exams.push({ id: 'demo-x-' + c.exams.length + 'abc', subject: 'م', date: TODAY, time: '', topics: '', notes: '' }); });
  bad.forEach(function (b, i) { assert.strictEqual(D.validate(b), false, 'حالة رفض رقم ' + i); });
  assert.strictEqual(D.validate(ok), true);
});
T('التحقق لا يتأثر بمفاتيح خطرة (__proto__ وconstructor) ولا يلوّث الكائنات', function () {
  var c = JSON.parse('{"__proto__":{"polluted":1},"constructor":{"x":1}}');
  assert.strictEqual(D.validate(c), false); assert.strictEqual(({}).polluted, undefined);
  var ok = clone(D.build(TODAY)); ok.exams[0].__proto__ = { subject: 'x' };
  assert.strictEqual(typeof D.validate(ok), 'boolean');
});
T('التواريخ: weekday وshift وdaysBetween حول نهاية الشهر والسنة والتوقيت الصيفي', function () {
  assert.strictEqual(D.weekday('2026-11-03'), 2); assert.strictEqual(D.weekday('2026-11-01'), 0); assert.strictEqual(D.weekday('2026-11-06'), 5);
  assert.strictEqual(D.shift('2026-10-31', 1), '2026-11-01'); assert.strictEqual(D.shift('2026-12-31', 1), '2027-01-01');
  assert.strictEqual(D.shift('2028-02-28', 1), '2028-02-29'); assert.strictEqual(D.shift('2027-02-28', 1), '2027-03-01'); assert.strictEqual(D.shift('2026-03-01', -1), '2026-02-28');
  assert.strictEqual(D.daysBetween('2026-03-28', '2026-03-30'), 2); assert.strictEqual(D.daysBetween('2026-10-24', '2026-10-26'), 2);
  assert.strictEqual(D.daysBetween('2026-11-03', '2026-11-03'), 0); assert.strictEqual(D.daysBetween('2026-11-10', '2026-11-03'), -7);
  assert.ok(isNaN(D.daysBetween('x', '2026-11-03'))); assert.strictEqual(D.weekday('2026-02-30'), -1); assert.strictEqual(D.shift('x', 3), 'x');
});
T('lessonsOn: ترتيب بالوقت، وفارغ يوم الجمعة وعند غياب البيانات', function () {
  var d = D.build(TODAY), l = D.lessonsOn(d, TODAY), i;
  assert.strictEqual(l.length, 5); for (i = 1; i < l.length; i++) assert.ok(l[i - 1].start < l[i].start);
  assert.strictEqual(D.lessonsOn(d, '2026-11-06').length, 0); assert.strictEqual(D.lessonsOn(null, TODAY).length, 0); assert.strictEqual(D.lessonsOn(d, 'x').length, 0);
  assert.strictEqual(D.hasTimetable(d), true); assert.strictEqual(D.hasTimetable(null), false);
  var empty = clone(d); empty.timetable = [[], [], [], [], [], [], []]; assert.strictEqual(D.hasTimetable(empty), false);
});
T('تجميع الامتحانات: الأقرب ثم القادمة ثم المنتهية (الأحدث أولاً)، وامتحان اليوم نفسه قادم', function () {
  var d = D.build(TODAY), g = D.examGroups(d, TODAY), up = [g.nearest].concat(g.upcoming), i;
  for (i = 1; i < up.length; i++) assert.ok(up[i - 1].date <= up[i].date);
  for (i = 1; i < g.finished.length; i++) assert.ok(g.finished[i - 1].date >= g.finished[i].date);
  g.finished.forEach(function (e) { assert.ok(e.date < TODAY); }); up.forEach(function (e) { assert.ok(e.date >= TODAY); });
  var same = D.examGroups(d, g.nearest.date); assert.strictEqual(same.nearest.id, g.nearest.id);
  var late = D.examGroups(d, '2027-06-01'); assert.strictEqual(late.nearest, null); assert.strictEqual(late.finished.length, 5);
  var none = D.examGroups(null, TODAY); assert.strictEqual(none.nearest, null); assert.strictEqual(none.upcoming.length + none.finished.length, 0);
});
T('getExam: يجد بالمعرّف ويرجع null لغير الموجود أو غير النص', function () {
  var d = D.build(TODAY); assert.strictEqual(D.getExam(d, 'demo-exam-1').id, 'demo-exam-1');
  assert.strictEqual(D.getExam(d, 'demo-exam-99'), null); assert.strictEqual(D.getExam(d, 5), null); assert.strictEqual(D.getExam(null, 'demo-exam-1'), null);
});
T('صياغة الأيام بالعربية: اليوم، باچر، بعد يومين، بعد 3–10 أيام، بعد 11 يوماً، وللماضي', function () {
  var cases = [[0, 'اليوم'], [1, 'باچر'], [2, 'بعد يومين'], [3, 'بعد 3 أيام'], [10, 'بعد 10 أيام'], [11, 'بعد 11 يوماً'], [45, 'بعد 45 يوماً'], [-1, 'أمس'], [-2, 'قبل يومين'], [-6, 'قبل 6 أيام'], [-13, 'قبل 13 يوماً']];
  cases.forEach(function (c) { assert.strictEqual(D.daysLabel(c[0]), c[1], String(c[0])); });
  assert.strictEqual(D.daysLabel(NaN), ''); assert.strictEqual(D.daysLabel('3'), '');
});
T('صياغة العدّ بالعربية: مفرد ومثنى وجمع (3–10) وتمييز (11+)', function () {
  assert.strictEqual(D.countText(1, 'lesson'), 'درس واحد'); assert.strictEqual(D.countText(2, 'lesson'), 'درسان'); assert.strictEqual(D.countText(3, 'lesson'), '3 دروس');
  assert.strictEqual(D.countText(10, 'prep'), '10 تحضيرات'); assert.strictEqual(D.countText(11, 'prep'), '11 تحضيراً'); assert.strictEqual(D.countText(2, 'homework'), 'واجبان');
  assert.strictEqual(D.countText(0, 'lesson'), ''); assert.strictEqual(D.countText(3, 'ما'), '');
});
T('ملخص البطاقة: يدمج الأعداد الموجبة فقط وإلا النص الفارغ', function () {
  assert.strictEqual(D.summaryText({ lessons: 3, preps: 2, homework: 1 }, 'لا شيء'), '3 دروس · تحضيران · واجب واحد');
  assert.strictEqual(D.summaryText({ lessons: 0, preps: 1, homework: 0 }, 'لا شيء'), 'تحضير واحد');
  assert.strictEqual(D.summaryText({ lessons: 0, preps: 0, homework: 0 }, 'لا شيء اليوم'), 'لا شيء اليوم'); assert.strictEqual(D.summaryText(null, 'x'), 'x');
});
T('التحية والتاريخ القصير: صباح قبل الظهر ومساء بعده، وأرقام لاتينية وأسماء عربية', function () {
  assert.strictEqual(D.greeting(0), 'صباح الخير'); assert.strictEqual(D.greeting(11), 'صباح الخير'); assert.strictEqual(D.greeting(12), 'مساء الخير'); assert.strictEqual(D.greeting(23), 'مساء الخير');
  var s = D.shortDate('2026-11-03'); assert.ok(/الثلاثاء/.test(s) && /نوفمبر/.test(s) && /\b3\b/.test(s), s); assert.ok(!/[٠-٩]/.test(s), 'أرقام هندية: ' + s);
  assert.strictEqual(D.shortDate('x'), 'x');
});
T('الملف نقي: لا DOM ولا شبكة ولا تخزين ولا إدراج HTML', function () {
  var src = fs.readFileSync(path.join(__dirname, '..', 'js', 'v1-demo.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  ['document', 'window', 'localStorage', 'sessionStorage', 'fetch(', 'XMLHttpRequest', 'innerHTML', 'eval(', 'new Function', 'Math.random', 'Date.now', 'new Date()'].forEach(function (k) { assert.ok(src.indexOf(k) < 0, k); });
});
console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
