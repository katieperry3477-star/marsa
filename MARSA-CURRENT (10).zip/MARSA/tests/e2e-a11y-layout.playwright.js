// اختبار المرحلة 03.12 (قابلية الاستخدام وإمكانية الوصول والتخطيط على الهاتف) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-a11y-layout.playwright.js
// ساعة مزيّفة: الخميس 2026-10-22 09:00 بغداد. لا يستخدم أي مكتبة خارجية غير Playwright.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var DEMO = 'cls_demo_001', NOW = '2026-10-22T06:00:00Z';
var LONG = 'ابراهيمعبدالرحمنمحمدعليحسنالموسويالبغدادي'.repeat(3);
var jsErrors = [], results = [];
function check(name, cond, detail) { results.push(!!cond); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
function rec(id, o) { return Object.assign({ recordId: id, classId: DEMO, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
async function seed(page, type, records) { await page.evaluate(function (a) { localStorage.setItem('marsa.academic.' + a.t + '.' + a.c, JSON.stringify({ schemaVersion: 1, classId: a.c, records: a.r })); }, { t: type, c: DEMO, r: records }); }
async function open(browser, vp, o) {
  o = o || {};
  var ctx = await browser.newContext({ viewport: vp, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true, colorScheme: o.scheme || 'light', reducedMotion: o.reduce ? 'reduce' : 'no-preference' });
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.clock.install({ time: new Date(NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])'); await page.evaluate(function () { document.getElementById('skip-intro').click(); }); await page.waitForSelector('#intro', { state: 'hidden' });
  return page;
}
async function reload(page) { await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.evaluate(function () { document.getElementById('skip-intro').click(); }); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function nav(page, label) { await page.evaluate(function (n) { var b = Array.prototype.slice.call(document.querySelectorAll('#nav-list button')).filter(function (x) { return x.textContent === n; })[0]; b.click(); }, label); }
async function toRep(page) {
  await nav(page, 'الإعدادات'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]'); await page.waitForTimeout(1700);
}
async function seedAll(page) {
  await seed(page, 'dailyLessons', [rec('l1', { subject: LONG, title: LONG, date: '2026-10-22', summary: LONG, pages: LONG, homework: 'x', notes: '' })]);
  await seed(page, 'preparations', [rec('p1', { subject: LONG, title: LONG, date: '2026-10-23', content: LONG, pages: '', homework: '', notes: '' }), rec('p2', { subject: 'رياضيات', title: 'قديم', date: '2026-10-01', content: 'ج', pages: '', homework: '', notes: '' })]);
  await seed(page, 'exams', [rec('e1', { subject: LONG, title: LONG, examDate: '2026-10-30', status: 'scheduled', topics: LONG, notes: '' }), rec('e2', { subject: 'علوم', title: 'ملغى', examDate: '2026-10-25', status: 'cancelled', topics: '', notes: '' })]);
  await seed(page, 'schedule', [rec('s1', { day: 'thu', subject: LONG, period: 1, startTime: '08:00', endTime: '08:45', notes: LONG }), rec('s2', { day: 'thu', subject: 'حاسوب', period: 2, startTime: '09:00', endTime: '09:45', notes: '' })]);
  await reload(page);
}
async function tabIntoMain(page) { for (var k = 0; k < 40; k++) { await page.keyboard.press('Tab'); if (await page.evaluate(function () { return !document.activeElement.closest('.top,#intro'); })) return; } }
var probe = function () {
  var out = { hscroll: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1, small: [], clipped: [] };
  document.querySelectorAll('button,a[href],input:not([type=hidden]):not([type=checkbox]),select,textarea,summary').forEach(function (e) {
    var r = e.getBoundingClientRect();
    if (!r.width || !r.height || e.closest('[hidden]') || e.closest('#mode-fx') || e.classList.contains('skip') || getComputedStyle(e).visibility === 'hidden') return;
    if (r.height < 43.5) out.small.push((e.textContent || e.id).trim().slice(0, 30) + ' h=' + Math.round(r.height));
    if (e.tagName === 'BUTTON' && (e.scrollHeight > e.clientHeight + 1 || e.scrollWidth > e.clientWidth + 1)) out.clipped.push('CLIP ' + e.textContent.trim().slice(0, 30));
    if (!e.closest('.nav') && (r.right > innerWidth + 1 || r.left < -1)) out.clipped.push('OFF ' + (e.textContent || '').trim().slice(0, 30));
  });
  document.querySelectorAll('.tag,.lc-t,.lcard h3,.prow h3,.tile').forEach(function (e) { var r = e.getBoundingClientRect(); if (r.width && (r.right > innerWidth + 1 || r.left < -1)) out.clipped.push('OFF ' + e.className); });
  return out;
};

(async function main() {
  var browser = await pw.chromium.launch(), page, r, i, s;

  // ===== 1) التخطيط على مقاسات الهاتف (عمودي وأفقي) مع نصوص طويلة بلا مسافات =====
  var sizes = [[320, 568], [360, 740], [375, 812], [390, 844], [412, 915], [667, 375], [568, 320]];
  for (i = 0; i < sizes.length; i++) {
    s = sizes[i]; page = await open(browser, { width: s[0], height: s[1] }); await seedAll(page);
    var bad = [], names = ['الرئيسية', 'الجدول', 'التحاضير', 'الأرشيف', 'الامتحانات'];
    for (var n of names) { await nav(page, n); await page.waitForTimeout(120); r = await page.evaluate(probe); if (r.hscroll || r.small.length || r.clipped.length) bad.push('student ' + n + ' ' + JSON.stringify(r)); }
    await toRep(page);
    for (var m of ['اللوحة', 'الطلاب', 'الجدول', 'ما أُخذ اليوم', 'التحاضير', 'الامتحانات']) { await nav(page, m); await page.waitForTimeout(120); r = await page.evaluate(probe); if (r.hscroll || r.small.length || r.clipped.length) bad.push('rep ' + m + ' ' + JSON.stringify(r)); }
    check('Layout ' + s.join('x') + ': no page h-scroll, targets >= 44px, no clipped/offscreen buttons on 11 views', !bad.length, bad.join(' ; ').slice(0, 400));
    if (s[0] === 320 && s[1] === 568) {
      var ul = await page.$eval('#nav-list', function (e) { return { ov: e.scrollWidth > e.clientWidth, ox: getComputedStyle(e).overflowX }; });
      check('Nav (rep mode, 320): horizontal bar scrolls by itself (not the page)', ul.ov && ul.ox === 'auto');
      check('Nav (320): edge-fade indicator shows that more items exist', await page.$eval('.nav', function (e) { return e.classList.contains('more-end') || e.classList.contains('more-start'); }));
      await page.evaluate(function () { var u = document.getElementById('nav-list'); u.scrollLeft = -u.scrollWidth; u.dispatchEvent(new Event('scroll')); });
      await page.waitForTimeout(100);
      check('Nav (320): fade state updates after scrolling to the far end', await page.$eval('.nav', function (e) { return e.classList.contains('more-start') && !e.classList.contains('more-end'); }));
    }
    await page.context().close();
  }

  // ===== 2) التركيز، نوافذ التأكيد، النماذج =====
  page = await open(browser, { width: 375, height: 812 }); await seedAll(page); await toRep(page);
  await nav(page, 'ما أُخذ اليوم'); await page.waitForTimeout(200);
  check('Focus: after navigation the page heading (h1) has focus', await page.evaluate(function () { return document.activeElement && document.activeElement.id === 'page-title'; }));
  await page.click('.lcard button.danger');
  await page.waitForSelector('#dlg-confirm[open]');
  var act = await page.evaluate(function () { var a = document.activeElement; return { id: a.id, tag: a.tagName }; });
  check('Confirm dialog: focus starts on the title, not on the destructive button', act.id === 'dlg-conf-t', JSON.stringify(act));
  check('Confirm dialog: aria-labelledby + aria-describedby point to existing nodes', await page.evaluate(function () { var d = document.getElementById('dlg-confirm'); return !!document.getElementById(d.getAttribute('aria-labelledby')) && !!document.getElementById(d.getAttribute('aria-describedby')); }));
  await page.keyboard.press('Enter');
  check('Confirm dialog: pressing Enter on the title does NOT delete', (await page.$$('.lcard')).length === 1 && (await page.evaluate(function () { return document.getElementById('dlg-confirm').open; })));
  check('Confirm dialog: delete button is a labelled danger action', await page.$eval('#dlg-confirm .primary', function (b) { return b.classList.contains('danger') && /^حذف/.test(b.textContent); }));
  await page.click('#dlg-confirm .link');
  check('Confirm dialog: cancel keeps the record', (await page.$$('.lcard')).length === 1);
  await page.click('.lcard button.danger'); await page.click('#dlg-confirm .primary');
  await page.waitForTimeout(100);
  check('After delete: focus moves to the list count (not lost on <body>)', await page.evaluate(function () { return document.activeElement && document.activeElement.classList.contains('count'); }));
  check('Status toast: role=status + aria-live polite and announces deletion', await page.$eval('#status', function (e) { return e.getAttribute('role') === 'status' && e.getAttribute('aria-live') === 'polite' && /تم حذف/.test(e.textContent); }));
  // نموذج الدرس: المطلوب/الاختياري ورسائل التحقق وعدم الإرسال المكرر
  await page.click('button:has-text("إضافة سجل درس")');
  var labs = await page.$$eval('#v-page form label.fl', function (l) { return l.map(function (x) { return x.textContent; }); });
  check('Lesson form: every label states required/optional', labs.length >= 7 && labs.every(function (t) { return /\(مطلوب\)|\(اختياري\)/.test(t); }), JSON.stringify(labs));
  await page.fill('#lf-date', '');
  await page.click('#v-page form button[type=submit]');
  var inv = await page.evaluate(function () { return { f: document.activeElement.id, a: document.getElementById('lf-subject').getAttribute('aria-invalid'), t: document.getElementById('lf-subject-e').textContent }; });
  check('Lesson form: validation errors shown in text, aria-invalid set, focus on first invalid', inv.f === 'lf-subject' && inv.a === 'true' && inv.t.length > 3, JSON.stringify(inv));
  await page.fill('#lf-subject', 'م'); await page.fill('#lf-title', 'د'); await page.fill('#lf-date', '2026-10-22');
  await page.evaluate(function () { var f = document.querySelector('#v-page form'); f.requestSubmit(); f.requestSubmit(); });
  await page.waitForTimeout(150);
  check('Lesson form: double submit saves exactly one record', (await page.$$('.lcard')).length === 1);
  // نافذة تعديل اسم الطالب وإضافة الطلاب
  await nav(page, 'الطلاب'); await page.click('button:has-text("إضافة طلاب")');
  check('Add-students dialog: textarea has a visible label marked required', await page.evaluate(function () { var t = document.getElementById('add-names'), l = document.querySelector('label[for=add-names]'); return !!l && /مطلوب/.test(l.textContent) && t.getAttribute('aria-required') === 'true' && !!document.getElementById(t.getAttribute('aria-describedby')); }));
  await page.fill('#add-names', 'طالب اختبار'); await page.click('button:has-text("معاينة الأسماء")'); await page.click('button:has-text("تأكيد الإضافة")');
  await page.waitForTimeout(150);
  await page.click('button:has-text("تعديل الاسم")');
  check('Edit-name dialog: label marked required + aria-required', await page.evaluate(function () { var l = document.querySelector('label[for=edit-name]'); return /مطلوب/.test(l.textContent) && document.getElementById('edit-name').getAttribute('aria-required') === 'true'; }));
  await page.fill('#edit-name', ''); await page.keyboard.press('Enter');
  check('Edit-name dialog: empty name → text error + invalid state + focus stays on field', await page.evaluate(function () { var i = document.getElementById('edit-name'); return i.getAttribute('aria-invalid') === 'true' && document.getElementById('edit-name-e').textContent.length > 3 && document.activeElement === i; }));
  await page.click('#dlg-add .link:has-text("إلغاء")');
  await page.context().close();

  // ===== 3) اللون وحده، الجدول، التركيز المرئي =====
  page = await open(browser, { width: 375, height: 812 }); await seedAll(page);
  await nav(page, 'الجدول'); await page.waitForTimeout(150);
  r = await page.$eval('.dtab.is-today', function (b) { return { t: b.querySelector('.dt') && b.querySelector('.dt').textContent, a: b.getAttribute('aria-label') }; });
  check('Schedule today tab: visible text marker «اليوم» (not colour only) + aria-label', r.t === 'اليوم' && /حصتان.*اليوم/.test(r.a), JSON.stringify(r));
  await nav(page, 'الامتحانات'); await page.waitForTimeout(150);
  check('Exam states carry text (status tag), cancelled exam not conveyed by colour alone', await page.$$eval('.ecard', function (l) { return l.every(function (c) { return c.querySelector('.tag[class*=st-]') && c.querySelector('.tag[class*=st-]').textContent.trim().length > 2; }); }));
  await tabIntoMain(page);
  var ring = await page.evaluate(function () { var a = document.activeElement, cs = getComputedStyle(a); return { w: cs.outlineWidth, c: cs.outlineColor, tag: a.tagName }; });
  check('Keyboard focus ring in page content (light) is 3px dark navy, not the weak gold', ring.w === '3px' && ring.c === 'rgb(11, 19, 36)', JSON.stringify(ring));
  await page.context().close();
  page = await open(browser, { width: 375, height: 812 }, { scheme: 'dark' });
  await nav(page, 'الإعدادات'); await page.waitForTimeout(200);
  await tabIntoMain(page);
  ring = await page.evaluate(function () { var cs = getComputedStyle(document.activeElement); return { w: cs.outlineWidth, c: cs.outlineColor }; });
  check('Keyboard focus ring (dark) is 3px gold', ring.w === '3px' && ring.c === 'rgb(214, 179, 106)', JSON.stringify(ring));
  await page.context().close();

  // ===== 4) تقليل الحركة =====
  page = await open(browser, { width: 375, height: 812 }, { reduce: true });
  await toRep(page).catch(function () {});
  check('Reduced motion: mode switch shows no full-screen overlay (#mode-fx stays hidden)', await page.$eval('#mode-fx', function (e) { return e.hidden || getComputedStyle(e).display === 'none'; }));
  check('Reduced motion: mode switch announced as text in the status region', /وضع ممثل الصف/.test(await page.textContent('#status')));
  check('Reduced motion: view-enter animation disabled', await page.$eval('#v-page', function (e) { return getComputedStyle(e).animationName === 'none'; }));
  await page.context().close();

  // ===== 5) التباين (نصوص الصفحات الرئيسية، فاتح وداكن) =====
  for (var scheme of ['light', 'dark']) {
    page = await open(browser, { width: 390, height: 844 }, { scheme: scheme }); await seedAll(page);
    var low = [];
    for (var nm of ['الرئيسية', 'الجدول', 'التحاضير', 'الأرشيف', 'الامتحانات', 'الإعدادات']) {
      await nav(page, nm); await page.waitForTimeout(500);
      low = low.concat(await page.evaluate(function () {
        function parse(c) { var m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; var p = m[1].split(/[ ,\/]+/).map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; }
        function lum(c) { var f = function (v) { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(c.r) + .7152 * f(c.g) + .0722 * f(c.b); }
        function bgOf(e) { var L = [], bc; while (e) { var cs = getComputedStyle(e), c = parse(cs.backgroundColor); if (c && c.a > 0) { L.push(c); if (c.a >= 1) break; } if (cs.backgroundImage.indexOf('gradient') > -1 && e.closest('.top,.class-card')) { L.push({ r: 16, g: 30, b: 52, a: 1 }); break; } e = e.parentElement; }
          var base = { r: 255, g: 255, b: 255 }; if (!L.length || L[L.length - 1].a < 1) { bc = parse(getComputedStyle(document.body).backgroundColor); if (bc && bc.a > 0) base = bc; }
          L.reverse().forEach(function (l) { base = { r: base.r * (1 - l.a) + l.r * l.a, g: base.g * (1 - l.a) + l.g * l.a, b: base.b * (1 - l.a) + l.b * l.a }; }); return base; }
        var bad = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT), n;
        while ((n = w.nextNode())) {
          var t = n.textContent.trim(), e = n.parentElement; if (!t || !e || e.closest('[hidden],#intro,#mode-fx,svg,#status')) continue;
          var rr = e.getBoundingClientRect(); if (!rr.width || !rr.height) continue;
          var cs = getComputedStyle(e); if (e.disabled || (e.closest && e.closest(':disabled'))) continue;
          var fg = parse(cs.color), bg = bgOf(e), a = fg.a, fc = { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a) };
          var l1 = lum(fc), l2 = lum(bg), cr = (Math.max(l1, l2) + .05) / (Math.min(l1, l2) + .05), size = parseFloat(cs.fontSize), bold = parseInt(cs.fontWeight, 10) >= 700, need = (size >= 24 || (size >= 18.66 && bold)) ? 3 : 4.5;
          if (cr < need) bad.push((e.className || e.tagName) + ' ' + cr.toFixed(2) + ' ' + t.slice(0, 18));
        }
        return bad;
      }));
    }
    check('Contrast (' + scheme + '): all visible text on 6 student pages >= 4.5:1 (3:1 large)', !low.length, low.slice(0, 6).join(' | '));
    await page.context().close();
  }

  check('No uncaught JS errors in any session', !jsErrors.length, jsErrors.join(' | '));
  await browser.close();
  var ok = results.filter(Boolean).length;
  console.log('\n' + ok + ' passed, ' + (results.length - ok) + ' failed');
  process.exit(ok === results.length ? 0 : 1);
})();
