// يبني docs/execution-v2/ui/UI-DESIGN-PREVIEW-V2.html من preview.template.html + ui-map-v2.js. التشغيل: node tests/ui/build-preview.js [--check]
// صفحة ثابتة: بلا شبكة ولا مكتبات. لا تلمس كود التطبيق.
'use strict';
var fs = require('fs'), path = require('path');
var U = require('./ui-map-v2.js');
var OUT = path.join(__dirname, '..', '..', 'docs', 'execution-v2', 'ui', 'UI-DESIGN-PREVIEW-V2.html');
function vars(o) { return Object.keys(o).map(function (k) { return '--' + k + ':' + o[k] + ';'; }).join(''); }
function build() {
  var fut = {}; U.FUTURE.forEach(function (f) { fut[f.key] = f; });
  var sidebars = {};
  ['s', 'r', 'd'].forEach(function (k) {
    sidebars[k] = U.SIDEBARS[k].map(function (g) {
      return { title: g.title, footer: !!g.footer, items: g.items.map(function (it) {
        if (it.future) return { t: 'future', key: it.future, ar: fut[it.future].ar, note: fut[it.future].note };
        if (it.action) return { t: 'action', ar: it.ar };
        return { t: 'link', ar: it.ar, screen: it.screen };
      }) };
    });
  });
  var data = { tokens: U.TOKENS, contrast: U.contrastTable(), motion: U.MOTION, home: U.HOME, tabbars: U.TABBARS, sidebars: sidebars, screens: U.SCREENS.map(function (s) { return { id: s.id, ar: s.ar }; }) };
  var t = fs.readFileSync(path.join(__dirname, 'preview.template.html'), 'utf8');
  return t.replace('/*TOKENS_LIGHT*/', vars(U.TOKENS.light)).split('/*TOKENS_DARK*/').join(vars(U.TOKENS.dark)).replace('/*EASE*/', U.EASE).replace('/*DATA*/null', JSON.stringify(data));
}
if (require.main === module) {
  var html = build();
  if (process.argv.indexOf('--check') >= 0) { var cur = fs.existsSync(OUT) ? fs.readFileSync(OUT, 'utf8') : ''; if (cur !== html) { console.error('المعاينة لا تطابق القالب/البيانات'); process.exit(1); } console.log('المعاينة مطابقة'); }
  else { fs.mkdirSync(path.dirname(OUT), { recursive: true }); fs.writeFileSync(OUT, html); console.log('بُنيت المعاينة: ' + html.length + ' بايت'); }
}
module.exports = { build: build, OUT: OUT };
