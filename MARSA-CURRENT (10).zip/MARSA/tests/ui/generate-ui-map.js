// يولّد كتل الجداول داخل docs/execution-v2/UI-MAP-V2.md من tests/ui/ui-map-v2.js. التشغيل: node tests/ui/generate-ui-map.js [--check]
// --check: يفشل (خروج 1) إن اختلفت الوثيقة عن البيانات. لا يلمس كود التطبيق.
'use strict';
var fs = require('fs'), path = require('path');
var U = require('./ui-map-v2.js');
var DOC = path.join(__dirname, '..', '..', 'docs', 'execution-v2', 'UI-MAP-V2.md');
var byId = {}; U.SCREENS.forEach(function (s) { byId[s.id] = s; });
var fx = function (n, d) { return n.toFixed(d === undefined ? 2 : d); };
var rolesAr = function (r) { return r.split('').map(function (c) { return U.ROLE_AR[c]; }).join('، '); };
var actsStr = function (s) { var o = []; Object.keys(s.acts).forEach(function (e) { var per = s.acts[e]; o.push('`' + e + '` ' + Object.keys(per).map(function (k) { return k + ':' + per[k]; }).join(' ')); }); return o.join('؛ ') || '—'; };
var statesStr = function (s) { return s.states ? s.states.split('').join(' ') : '—'; };

var B = {};
B.SCREENS = function () {
  var h = '| ID | الشاشة | المسار | الأدوار | المدخل | النوع | الكيانات (دور:عمليات) | حالات | المطالب | تنفيذ | V1/full.html |\n|---|---|---|---|---|---|---|---|---|---|---|\n';
  return h + U.SCREENS.map(function (s) { return '| `' + s.id + '` | ' + s.ar + ' | `' + s.route + '` | ' + rolesAr(s.roles) + ' | ' + s.entry + ' | ' + U.KIND_AR[s.kind] + ' | ' + actsStr(s) + ' | ' + statesStr(s) + ' | ' + s.req + ' | ' + s.prompt + ' | ' + s.v1 + ' |'; }).join('\n');
};
B.COUNTS = function () {
  var per = { d: 0, r: 0, s: 0 }; U.SCREENS.forEach(function (s) { s.roles.split('').forEach(function (c) { per[c]++; }); });
  return '**' + U.SCREENS.length + ' شاشة** (' + U.SCREENS.filter(function (s) { return U.GLOSSARY_IDS.indexOf(s.id) < 0; }).length + ' منها أُضيفت في 01.05 خارج المعجم المؤقت) + ' + U.FRAME.length + ' مكوّن إطار. حسب الدور: مطوّر ' + per.d + ' · ممثل ' + per.r + ' · طالب ' + per.s + '.';
};
B.FRAME = function () { return '| ID | المكوّن | الوصف | المطالب |\n|---|---|---|---|\n' + U.FRAME.map(function (f) { return '| `' + f[0] + '` | ' + f[1] + ' | ' + f[2] + ' | ' + f[3] + ' |'; }).join('\n'); };
B.ALIASES = function () { return '| اسم المعجم المؤقت (00.03) | ما ثُبِّت |\n|---|---|\n' + Object.keys(U.ALIASES).map(function (k) { return '| `' + k + '` | ' + U.ALIASES[k] + ' |'; }).join('\n'); };
B.TABBARS = function () {
  return U.TABBARS && ['s', 'r', 'd'].map(function (k) {
    var t = U.TABBARS[k];
    return '**' + U.ROLE_AR[k] + '** (`' + t.frame + '`): ' + t.tabs.map(function (x) { return '«' + x[0] + '» ◄ `' + x[1] + '`'; }).join(' · ');
  }).join('\n\n');
};
B.SIDEBARS = function () {
  return ['s', 'r', 'd'].map(function (k) {
    var out = '#### ' + U.ROLE_AR[k] + '\n\n';
    U.SIDEBARS[k].forEach(function (g) {
      out += '- **' + (g.title || (g.footer ? 'أسفل القائمة' : '(بلا عنوان)')) + '**: ' + g.items.map(function (it) {
        if (it.future) { var f = U.FUTURE.filter(function (x) { return x.key === it.future; })[0]; return f.ar + ' _(قيد التطوير)_'; }
        if (it.action) return it.ar + ' _(إجراء)_';
        return it.ar + ' ◄ `' + it.screen + '`';
      }).join(' · ') + '\n';
    });
    return out;
  }).join('\n');
};
B.FUTURE = function () { return '| المفتاح | البند | يظهر لـ | ما يعرضه عند اللمس (نص فقط) |\n|---|---|---|---|\n' + U.FUTURE.map(function (f) { return '| `' + f.key + '` | ' + f.ar + ' | ' + rolesAr(f.roles) + ' | «' + f.ar + ' — قيد التطوير ولم يُفعَّل بعد. ' + f.note + '» |'; }).join('\n'); };
B.HOME = function () {
  return '| الدور | عدد البطاقات (الحد ' + U.HOME.maxCards + ') | المحتوى | أزرار سريعة (الحد ' + U.HOME.maxQuick + ') |\n|---|---|---|---|\n' + ['s', 'r', 'd'].map(function (k) { var h = U.HOME[k]; return '| ' + U.ROLE_AR[k] + ' | ' + h.n + ' | ' + h.cards.map(function (c, i) { return (i + 1) + '. ' + c; }).join('<br>') + ' | ' + (h.quick.join('، ') || '—') + ' |'; }).join('\n');
};
B.TOKENS = function () {
  var keys = Object.keys(U.TOKENS.light);
  return '| الرمز | فاتح | داكن | الحالة |\n|---|---|---|---|\n' + keys.map(function (k) { return '| `--' + k + '` | `' + U.TOKENS.light[k] + '` | `' + U.TOKENS.dark[k] + '` | ' + (U.NEW_TOKENS.indexOf(k) >= 0 ? '**جديد V2**' : 'موجود في `css/v1.css`') + ' |'; }).join('\n');
};
B.CONTRAST = function () {
  return '| الزوج | الحد | فاتح | داكن | النتيجة |\n|---|---|---|---|---|\n' + U.contrastTable().map(function (r) { var ok = r.light >= r.min && r.dark >= r.min; return '| ' + r.name + ' (`' + r.fg + '`/`' + r.bg + '`) | ' + r.min + ' | ' + fx(r.light) + ' | ' + fx(r.dark) + ' | ' + (ok ? '✔' : '✘') + ' |'; }).join('\n');
};
B.MOTION = function () { return '| المفتاح | الحركة | الخصائص (transform/opacity فقط) | المدة | مع `prefers-reduced-motion` |\n|---|---|---|---|---|\n' + U.MOTION.map(function (m) { return '| `' + m[0] + '` | ' + m[1] + ' | ' + m[2] + ' | ' + m[3] + ' | ' + m[4] + ' |'; }).join('\n'); };
B.STATES = function () { return Object.keys(U.STATE_CODES).map(function (k) { return '`' + k + '` ' + U.STATE_CODES[k]; }).join(' · '); };
B.BREAKPOINTS = function () { return '| العرض (px) | السلوك |\n|---|---|\n' + U.BREAKPOINTS.map(function (b) { return '| ' + b[0] + ' | ' + b[1] + ' |'; }).join('\n'); };
B.COVERAGE = function () {
  var frameIds = U.FRAME.map(function (f) { return f[0]; });
  return '| معرّف المعجم المؤقت (00.03 §2) | يقابله هنا |\n|---|---|\n' + U.GLOSSARY_IDS.map(function (g) {
    var how = byId[g] ? 'شاشة `' + g + '`' : frameIds.indexOf(g) >= 0 ? 'مكوّن إطار `' + g + '`' : U.ALIASES[g] ? 'مرادف ◄ `' + U.ALIASES[g] + '`' : '✘ غير مغطّى';
    return '| `' + g + '` | ' + how + ' |';
  }).join('\n');
};
B.THREE = function () { return U.THREE.map(function (t) { return '«' + t.q + '» ◄ `' + t.id + '` (`' + t.route + '`)'; }).join(' · '); };

function render(doc) {
  return doc.replace(/<!-- GEN:([A-Z]+):START -->[\s\S]*?<!-- GEN:\1:END -->/g, function (m, k) {
    if (!B[k]) throw new Error('كتلة غير معروفة: ' + k);
    return '<!-- GEN:' + k + ':START -->\n' + B[k]() + '\n<!-- GEN:' + k + ':END -->';
  });
}
if (require.main === module) {
  var cur = fs.readFileSync(DOC, 'utf8'), next = render(cur);
  if (process.argv.indexOf('--check') >= 0) { if (cur !== next) { console.error('UI-MAP-V2.md لا يطابق البيانات — شغّل: node tests/ui/generate-ui-map.js'); process.exit(1); } console.log('UI-MAP-V2.md مطابق للبيانات'); }
  else { fs.writeFileSync(DOC, next); console.log('حُدّثت الكتل في UI-MAP-V2.md'); }
}
module.exports = { render: render, blocks: B };
