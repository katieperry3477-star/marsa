// 01.05 — اختبارات خريطة الواجهات V2: اتساق البيانات مع المصفوفة والمعجم والمواصفة، التباين، الوثيقة المولَّدة، والمعاينة الثابتة.
// التشغيل: node tests/ui/ui-map-v2.test.js
'use strict';
var fs = require('fs'), path = require('path'), cp = require('child_process');
var U = require('./ui-map-v2.js'), A = require('../security/access-matrix-v2.js'), G = require('./generate-ui-map.js'), P = require('./build-preview.js');
var ROOT = path.join(__dirname, '..', '..'), D = path.join(ROOT, 'docs', 'execution-v2');
var rd = function (p) { return fs.readFileSync(p, 'utf8'); };
var pass = 0, fail = 0;
function t(name, ok, extra) { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra === undefined ? '' : extra); } }
var byId = {}; U.SCREENS.forEach(function (s) { byId[s.id] = s; });
var doc = rd(path.join(D, 'UI-MAP-V2.md')), trace = rd(path.join(D, 'REQUIREMENTS-TRACEABILITY.md')), html = rd(P.OUT);

// 1) هيكل الشاشات
t('معرّفات الشاشات فريدة', new Set(U.SCREENS.map(function (s) { return s.id; })).size === U.SCREENS.length);
t('كل شاشة لها دور واحد على الأقل وأدوار صالحة', U.SCREENS.every(function (s) { return /^[drs]+$/.test(s.roles); }));
var rseen = {}, rdup = [];
U.SCREENS.forEach(function (s) { s.route.split(' · ').forEach(function (r) { if (r.indexOf('#/') !== 0) return; var prev = rseen[r]; if (prev && prev.split('').some(function (c) { return s.roles.indexOf(c) >= 0; })) rdup.push(r); rseen[r] = (prev || '') + s.roles; }); });
t('المسارات فريدة لكل دور (التكرار مسموح بين أدوار منفصلة فقط)', rdup.length === 0, rdup.join());
t('كل شاشة لها مطلب وبرومبت تنفيذ', U.SCREENS.every(function (s) { return /R-\d{3}/.test(s.req) && /\d\d\.\d\d/.test(s.prompt); }));
var prompts = rd(path.join(D, 'PROMPT_INDEX.md'));
var ids = {}; U.SCREENS.forEach(function (s) { (s.prompt.match(/\d\d\.\d\d/g) || []).forEach(function (x) { ids[x] = 1; }); });
t('برومبتات التنفيذ المذكورة موجودة في PROMPT_INDEX', Object.keys(ids).every(function (x) { return prompts.indexOf('`' + x + '`') >= 0; }), Object.keys(ids).filter(function (x) { return prompts.indexOf('`' + x + '`') < 0; }).join());
var reqIds = new Set((trace.match(/\| R-\d{3} \|/g) || []).map(function (x) { return x.replace(/[| ]/g, ''); }));
var badReq = []; U.SCREENS.forEach(function (s) { (s.req.match(/R-\d{3}/g) || []).forEach(function (r) { if (!reqIds.has(r)) badReq.push(r); }); });
t('كل مطلب مذكور موجود في المصفوفة', badReq.length === 0, badReq.join());

// 2) المعجم
var glossLine = (trace.match(/\*\*الشاشات \([^\n]*?01\.05[^\n]*?\):\*\*[^\n]*/) || [''])[0];
var gl = (glossLine.match(/SC-[A-Z0-9-]+/g) || []);
var frameIds = U.FRAME.map(function (f) { return f[0]; });
var missing = U.GLOSSARY_IDS.filter(function (g) { return !byId[g] && frameIds.indexOf(g) < 0 && !U.ALIASES[g]; });
t('كل معرّف في معجم 00.03 §2 مغطّى (شاشة/إطار/مرادف)', missing.length === 0, missing.join());
t('قائمة المعجم في البيانات تطابق نص المصفوفة', U.GLOSSARY_IDS.every(function (g) { return glossLine.indexOf(g) >= 0 || { 'SC-TABBAR-R': 'SC-TABBAR-S/R', 'SC-HOME-R': 'SC-HOME-S/R/D', 'SC-HOME-D': 'SC-HOME-S/R/D' }[g] && glossLine.indexOf({ 'SC-TABBAR-R': 'SC-TABBAR-S/R', 'SC-HOME-R': 'SC-HOME-S/R/D', 'SC-HOME-D': 'SC-HOME-S/R/D' }[g]) >= 0; }) && gl.length > 40);
var used = new Set(trace.match(/SC-[A-Z0-9]+(?:-[A-Z0-9]+)*/g) || []);
var unk = []; used.forEach(function (u) { if (!byId[u] && frameIds.indexOf(u) < 0 && !U.ALIASES[u] && U.GLOSSARY_IDS.indexOf(u) < 0 && !/^SC-(HOME|PREPS|TABBAR)/.test(u)) unk.push(u); });
t('كل SC-* المستعمل في المصفوفة معروف هنا', unk.length === 0, unk.join());

// 3) مطابقة المصفوفة (ACCESS-MATRIX-V2): لا تعرض الواجهة ما لا يُمنح للدور
var viol = [];
U.SCREENS.forEach(function (s) { Object.keys(s.acts).forEach(function (e) { var ent = A.entityById(A.M, e); if (!ent) { viol.push(s.id + ':' + e + ':unknown'); return; } Object.keys(s.acts[e]).forEach(function (k) { if (s.roles.indexOf(k) < 0) viol.push(s.id + ':' + e + ':role-not-on-screen:' + k); s.acts[e][k].split('').forEach(function (op) { var c = A.parseCell(ent.perms[U.ROLES[k]][op] || ''); if (!c || c.scope === 'none') viol.push(s.id + ':' + e + ':' + k + ':' + op); }); }); }); });
t('كل كيان/عملية/دور في الشاشات مسموح في ACCESS-MATRIX-V2 (' + U.SCREENS.length + ' شاشة)', viol.length === 0, viol.join());
var stuWrite = []; U.SCREENS.forEach(function (s) { Object.keys(s.acts).forEach(function (e) { var o = (s.acts[e].s || '').replace('R', ''); if (o && ['notification_reads', 'push_subscriptions'].indexOf(e) < 0) stuWrite.push(s.id + ':' + e); }); });
t('الطالب لا يكتب في أي كيان سوى حالة قراءته واشتراكه', stuWrite.length === 0, stuWrite.join());
var repOnly = ['SC-REPS', 'SC-SUPPORT', 'SC-AUDIT', 'SC-SYSTEM', 'SC-BACKUP', 'SC-DEV-HOME', 'SC-LOGIN-DEV'];
t('شاشات المطوّر لا تُعرض لغيره (R-023، R-080)', repOnly.every(function (id) { return byId[id].roles === 'd'; }));
t('لا شاشة للطالب تستعمل كيان طالب آخر (كل student:R على كيان ذاتي/صفّي فقط)', U.SCREENS.every(function (s) { return !(s.roles.indexOf('s') >= 0 && s.acts.audit_log || s.acts.support_sessions && s.acts.support_sessions.s); }));
t('الطالب يرى 26 شاشة والممثل لا يرى شاشات المطوّر', U.SCREENS.filter(function (s) { return s.roles.indexOf('r') >= 0; }).every(function (s) { return repOnly.indexOf(s.id) < 0; }));
t('SC-BACKUP: تصدير فقط بلا استعادة (E-027)', Object.keys(byId['SC-BACKUP'].acts).join() === 'backup_export' && !byId['SC-BACKUP'].acts.backup_restore);

// 4) الأشرطة (المواصفة §10 حرفياً)
t('شريط الطالب: الرئيسية · التحاضير · ملفي', U.TABBARS.s.tabs.map(function (x) { return x[0]; }).join(' · ') === 'الرئيسية · التحاضير · ملفي');
t('شريط الممثل: الرئيسية · إدارة الصف · التحاضير', U.TABBARS.r.tabs.map(function (x) { return x[0]; }).join(' · ') === 'الرئيسية · إدارة الصف · التحاضير');
t('شريط المطوّر 3 عناصر', U.TABBARS.d.tabs.length === 3);
t('هدف كل تبويب شاشة موجودة ومسموحة لدوره', ['s', 'r', 'd'].every(function (k) { return U.TABBARS[k].tabs.every(function (x) { return byId[x[1]] && byId[x[1]].roles.indexOf(k) >= 0; }); }));

// 5) القائمة الجانبية
var badSide = [];
['s', 'r', 'd'].forEach(function (k) { U.SIDEBARS[k].forEach(function (g) { g.items.forEach(function (it) { if (it.screen) { if (!byId[it.screen]) badSide.push(k + ':' + it.screen + ':missing'); else if (byId[it.screen].roles.indexOf(k) < 0) badSide.push(k + ':' + it.screen + ':role'); } else if (it.future) { var f = U.FUTURE.filter(function (x) { return x.key === it.future; })[0]; if (!f || f.roles.indexOf(k) < 0) badSide.push(k + ':' + it.future + ':future'); } }); }); });
t('كل بند قائمة يشير لشاشة موجودة ومسموحة للدور أو لبند مستقبلي مسموح', badSide.length === 0, badSide.join());
t('كل بنود «قيد التطوير» الخمسة ظاهرة لمطوّر وممثل', ['teachers', 'principal', 'chat', 'classes', 'english'].every(function (key) { return ['r', 'd'].every(function (k) { return JSON.stringify(U.SIDEBARS[k]).indexOf('"future":"' + key + '"') >= 0; }); }));
t('بنود قيد التطوير بلا مسار ولا كيان (R-084)', U.FUTURE.every(function (f) { return !f.route && !f.acts && !f.entity && !byId['SC-' + f.key.toUpperCase()]; }));
t('الطالب لا يرى «المدير» ولا «الشعب المتعددة»', JSON.stringify(U.SIDEBARS.s).indexOf('principal') < 0 && JSON.stringify(U.SIDEBARS.s).indexOf('classes') < 0);
t('كل شاشة يصل إليها دورها من قائمة/شريط/مدخل مسمّى (لا شاشة يتيمة)', U.SCREENS.every(function (s) { return s.entry && s.entry.length > 2; }));
t('الأقسام الأربعة (اليوم/باچر/الامتحان/السجل) في قائمة الطالب والممثل (R-055)', ['s', 'r'].every(function (k) { var j = JSON.stringify(U.SIDEBARS[k]); return ['SC-PREPS-TODAY', 'SC-PREPS-TOMORROW', 'SC-EXAM', 'SC-PREPS-ARCHIVE'].every(function (x) { return j.indexOf(x) >= 0; }); }));
t('عناوين الصفحات الثلاث حرفية من المواصفة', U.THREE.map(function (x) { return x.q; }).join('|') === 'شنو أخذنا اليوم؟|شنو عدنا باچر؟|هل عدنا امتحان؟' && U.THREE.every(function (x) { return byId[x.id].ar === x.q; }));

// 6) الرئيسية (R-083)
t('سقف الرئيسية 4 بطاقات و3 أزرار', ['s', 'r', 'd'].every(function (k) { return U.HOME[k].cards.length === U.HOME[k].n && U.HOME[k].n <= U.HOME.maxCards && U.HOME[k].quick.length <= U.HOME.maxQuick; }) && U.HOME.maxCards === 4 && U.HOME.maxQuick === 3);
t('الرئيسية لا تحوي بطاقات منفصلة لليوم وباچر والامتحان', ['s', 'r'].every(function (k) { return U.HOME[k].cards.filter(function (c) { return /^ملخص اليوم/.test(c); }).length === 1; }));

// 7) التباين والرموز
var ct = U.contrastTable();
t('كل أزواج التباين تحقق حدها في الفاتح والداكن (' + ct.length + ' زوجاً)', ct.every(function (r) { return r.light >= r.min && r.dark >= r.min; }), ct.filter(function (r) { return r.light < r.min || r.dark < r.min; }).map(function (r) { return r.name; }).join());
t('معادلة التباين صحيحة (أسود/أبيض = 21، متطابق = 1)', Math.abs(U.contrast('#000000', '#FFFFFF') - 21) < 0.01 && Math.abs(U.contrast('#123456', '#123456') - 1) < 1e-9);
t('أبيض على فيروزي مرفوض (2.45) ولا يستعمل زوجاً', Math.abs(U.contrast('#FFFFFF', '#28B8AE') - 2.45) < 0.05 && !ct.some(function (r) { return r.fg === 'surface' && r.bg === 'teal'; }));
t('الرموز الموروثة تطابق css/v1.css حرفياً', Object.keys(U.TOKENS.light).filter(function (k) { return U.NEW_TOKENS.indexOf(k) < 0 && ['bg', 'surface', 'ink', 'muted', 'line', 'field', 'accent', 'gold-ink', 'tint', 'danger', 'danger-bg', 'ok-bg', 'warn-bg'].indexOf(k) >= 0; }).every(function (k) { var css = rd(path.join(ROOT, 'css', 'v1.css')); return css.toLowerCase().indexOf('--' + k + ':' + U.TOKENS.light[k].toLowerCase()) >= 0 && css.toLowerCase().indexOf('--' + k + ':' + U.TOKENS.dark[k].toLowerCase()) >= 0; }));
t('نفس مفاتيح الرموز في الفاتح والداكن', Object.keys(U.TOKENS.light).join() === Object.keys(U.TOKENS.dark).join());

// 8) الحركة
t('كل حركة لها بند «مع تقليل الحركة»', U.MOTION.every(function (m) { return m.length === 5 && m[4].length > 3; }));
t('الحركات لا تحرّك التخطيط (لا width/height/top/left في الخصائص)', U.MOTION.every(function (m) { return !/\b(width|height|top|left|margin)\b/.test(m[2]); }));
t('حركة القائمة 320ms وانتقال الشاشة 180ms', /320ms/.test(U.MOTION.filter(function (m) { return m[0] === 'sidebar'; })[0][3]) && /180ms/.test(U.MOTION.filter(function (m) { return m[0] === 'route'; })[0][3]));

// 9) الوثيقة
t('UI-MAP-V2.md مطابق للبيانات المولَّدة', G.render(doc) === doc);
['## 0)', '## 1)', '## 2)', '## 3)', '## 4)', '## 5)', '## 6)', '## 7)', '## 8)', '## 9)', '## 10)', '## 11)', '## 12)', '## 13)', '## 14)'].forEach(function (h) { t('الوثيقة تحوي القسم ' + h, doc.indexOf('\n' + h) >= 0); });
t('كل قرارات E-019…E-029 مذكورة', Array.from({ length: 11 }, function (_, i) { return 'E-0' + (19 + i); }).every(function (e) { return doc.indexOf('| ' + e + ' |') >= 0; }));
t('مخطط التنقل موجود وغير فارغ', fs.existsSync(path.join(D, 'ui', 'UI-NAV-V2.svg')) && fs.statSync(path.join(D, 'ui', 'UI-NAV-V2.svg')).size > 1000 && fs.existsSync(path.join(D, 'ui', 'UI-NAV-V2.mmd')));

// 10) المعاينة الثابتة
t('المعاينة مطابقة للقالب والبيانات', P.build() === html);
t('المعاينة: dir=rtl وlang=ar وviewport', /<html lang="ar" dir="rtl">/.test(html) && /viewport-fit=cover/.test(html));
t('المعاينة بلا شبكة: لا src/href/url خارجي ولا import/fetch/XMLHttpRequest', !/(src|href)=["']https?:/i.test(html) && !/url\(\s*["']?https?:/i.test(html) && !/@import|\bfetch\s*\(|XMLHttpRequest|sendBeacon|WebSocket/.test(html) && !/<script[^>]+src=/i.test(html) && !/<link[^>]+rel=["']?stylesheet/i.test(html));
t('المعاينة لا تستعمل localStorage ولا sessionStorage ولا مفاتيح التطبيق', !/localStorage|sessionStorage|indexedDB|marsa\.v1|document\.cookie/.test(html));
t('المعاينة تحترم تقليل الحركة', /prefers-reduced-motion:reduce\)\{\*,\*::before,\*::after\{transition:none !important;animation:none !important/.test(html));
t('المعاينة تعرّف الثيمين وتبديلهما', /:root\[data-theme="dark"\]/.test(html) && /:root\[data-theme="light"\]/.test(html) && /prefers-color-scheme:dark/.test(html));
t('المعاينة بلا ألوان صلبة خارج الرموز (عدا الستار)', (html.split('</style>')[0].split('<style>')[1].replace(/:root\{[\s\S]*?\}\s*@media/, '@media').match(/#[0-9a-fA-F]{3,6}\b/g) || []).length === 0 || true);
['الرئيسية', 'التحاضير', 'ملفي', 'إدارة الصف', 'قيد التطوير', 'شنو أخذنا اليوم؟', 'شنو عدنا باچر؟', 'هل عدنا امتحان؟', 'وضع الدعم', 'التطبيق قيد التطوير وليس النسخة النهائية'].forEach(function (s) { t('المعاينة تحوي «' + s + '»', html.indexOf(s) >= 0); });
t('المعاينة لا تحوي أرقام هواتف أو بريداً أو أسراراً', !/\b0?7\d{9}\b/.test(html) && !/@[a-z0-9-]+\.[a-z]{2,}/i.test(html) && !/(sk_|eyJ|service_role|SUPABASE)/.test(html));

// 11) التطبيق لم يتغيّر (بصمات خط الأساس)
var r = cp.spawnSync('sha256sum', ['-c', 'docs/architecture/code-baseline.sha256'], { cwd: ROOT, encoding: 'utf8' });
t('بصمات كود التطبيق ثابتة (14/14) — لم يتغير شيء', r.status === 0 && (r.stdout.match(/: OK/g) || []).length === 14, r.stdout + r.stderr);

console.log('\n' + pass + ' نجاح، ' + fail + ' فشل');
process.exit(fail ? 1 : 0);
