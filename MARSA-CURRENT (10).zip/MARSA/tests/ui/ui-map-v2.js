// 01.05 — بيانات خريطة الواجهات V2 (مصدر الحقيقة لـUI-MAP-V2.md). وثائق/تصميم فقط: لا يُحمَّل في التطبيق ولا يغيّر شيئاً منه.
// القواعد: الأدوار بنفس رموز المصفوفة (developer/rep/student)؛ كل كيان يطابق ACCESS-MATRIX-V2؛ الواجهة تعرض فقط ما تسمح به المصفوفة،
// والإنفاذ الحقيقي في الخادم (R-029) — اختفاء عنصر هنا ليس حماية.
'use strict';

var ROLES = { d: 'developer', r: 'rep', s: 'student' };
var ROLE_AR = { d: 'مطوّر', r: 'ممثل', s: 'طالب' };

// ===== رموز التصميم (من css/v1.css الموجود + رموز V2 الجديدة مُعلَّمة new) =====
var TOKENS = {
  light: { bg: '#F4F7FB', surface: '#FFFFFF', ink: '#0B1324', muted: '#4A5A73', line: '#D5DEEA', field: '#6B7A92', accent: '#0B6F69', teal: '#28B8AE', 'gold-ink': '#7A5C1C', tint: '#E8F1F6', danger: '#B3261E', 'danger-bg': '#FBEAE8', 'ok-bg': '#E3F4F2', 'warn-bg': '#FBF3E2', focus: '#0B1324', 'navy-900': '#0B1324', 'navy-700': '#14233A', gold: '#D6B36A', mist: '#F4F7FB', 'support-bg': '#D6B36A', 'support-ink': '#0B1324', skeleton: '#E3EAF3' },
  dark: { bg: '#0B1324', surface: '#14233A', ink: '#F4F7FB', muted: '#A9B7CC', line: '#25395A', field: '#7C8BA6', accent: '#28B8AE', teal: '#28B8AE', 'gold-ink': '#D6B36A', tint: '#102036', danger: '#FF9A92', 'danger-bg': '#3A1B1D', 'ok-bg': '#0F2F33', 'warn-bg': '#2E2614', focus: '#D6B36A', 'navy-900': '#0B1324', 'navy-700': '#14233A', gold: '#D6B36A', mist: '#F4F7FB', 'support-bg': '#D6B36A', 'support-ink': '#0B1324', skeleton: '#1B2D49' }
};
var NEW_TOKENS = ['support-bg', 'support-ink', 'skeleton']; // الباقي موجود في css/v1.css

// أزواج (نص/عنصر على خلفية) مع الحد الأدنى WCAG: 4.5 نص عادي · 3 عنصر واجهة/نص كبير. لا يُقبل لون وحده (القاعدة: أيقونة + كلمة).
var PAIRS = [
  ['النص الأساسي على الخلفية', 'ink', 'bg', 4.5], ['النص الأساسي على البطاقة', 'ink', 'surface', 4.5],
  ['النص الثانوي على البطاقة', 'muted', 'surface', 4.5], ['النص الثانوي على الخلفية', 'muted', 'bg', 4.5],
  ['الرابط/الإجراء الثانوي على البطاقة', 'accent', 'surface', 4.5], ['«تم أخذه» على خلفية الحالة', 'accent', 'ok-bg', 4.5],
  ['«تأجل»/الامتحان على خلفية التحذير', 'gold-ink', 'warn-bg', 4.5], ['الامتحان/التنبيه على البطاقة', 'gold-ink', 'surface', 4.5],
  ['«لم يتم أخذه»/الخطأ على خلفية الخطأ', 'danger', 'danger-bg', 4.5], ['الخطأ على البطاقة', 'danger', 'surface', 4.5],
  ['الزر الرئيسي (كحلي على فيروزي)', 'navy-900', 'teal', 4.5], ['نص الشريط العلوي', 'mist', 'navy-900', 4.5],
  ['شريط وضع الدعم (جديد)', 'support-ink', 'support-bg', 4.5], ['شارة المادة', 'accent', 'tint', 4.5],
  ['حدّ الحقل على البطاقة (عنصر واجهة)', 'field', 'surface', 3], ['حلقة التركيز على الخلفية (عنصر واجهة)', 'focus', 'bg', 3],
  ['حلقة التركيز على البطاقة (عنصر واجهة)', 'focus', 'surface', 3], ['حلقة التركيز على الشريط العلوي', 'gold', 'navy-900', 3]
];
function lum(hex) { var c = [1, 3, 5].map(function (i) { var v = parseInt(hex.substr(i, 2), 16) / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
function contrastTable() { return PAIRS.map(function (p) { return { name: p[0], fg: p[1], bg: p[2], min: p[3], light: contrast(TOKENS.light[p[1]], TOKENS.light[p[2]]), dark: contrast(TOKENS.dark[p[1]], TOKENS.dark[p[2]]) }; }); }

// ===== الحركة =====
var EASE = 'cubic-bezier(.2,.8,.2,1)';
var MOTION = [
  ['intro', 'الشاشة الافتتاحية', 'opacity فقط (تلاشٍ)', '1500ms إجمالاً، تُتخطّى بلمسة', 'تُتخطّى كلياً (R-086)'],
  ['sidebar', 'فتح/إغلاق القائمة الجانبية (هاتف/لوح)', 'transform: translateX من الحافة اليمنى (RTL) + opacity للستار', '320ms · ' + EASE + ' (الإغلاق 240ms)', 'تظهر/تختفي فوراً بلا انزلاق'],
  ['route', 'الانتقال بين الشاشات', 'opacity + translateY(8px)', '180ms', 'بلا انتقال'],
  ['card-in', 'ظهور البطاقات عند أول تحميل', 'opacity + translateY(8px)، تتابع 40ms لأول 4 بطاقات فقط', '200ms', 'بلا حركة'],
  ['seg', 'مؤشر التبويب (اليوم/باچر/الامتحان)', 'transform على المؤشر', '200ms', 'تغيير فوري'],
  ['tab', 'عنصر الشريط السفلي النشط', 'transform: scale(1.06) للأيقونة', '100ms', 'بلا تكبير'],
  ['press', 'ضغط الأزرار', 'transform: scale(.98)', '100ms', 'بلا حركة'],
  ['theme', 'تبديل الثيم', 'background-color وcolor فقط', '200ms', 'تغيير فوري'],
  ['skeleton', 'هيكل التحميل', 'تبديل opacity بين .6 و1 (لا شريط لامع متحرك)', '1200ms تكرار (يتوقف بعد 8 ث)', 'ثابت بلا نبض'],
  ['toast', 'الرسائل العابرة', 'opacity + translateY(8px)', '200ms، تبقى 4 ث', 'تظهر فوراً وتبقى 4 ث'],
  ['expand', 'فتح بند «قيد التطوير» وتفاصيل البطاقة', 'grid-template-rows / opacity', '200ms', 'فوري']
];

// ===== مكونات الإطار =====
var FRAME = [
  ['SC-HEADER', 'الترويسة', 'شعار مَرسى + اسم الشعبة + زر القائمة + الجرس (عدّاد نصي) + سطر هادئ «التطبيق قيد التطوير وليس النسخة النهائية» على الشاشات الرئيسية (جذور التبويبات) في النسخة التجريبية', 'R-081'],
  ['SC-SIDEBAR', 'القائمة الجانبية', 'انظر §القائمة الجانبية؛ تختلف بالدور؛ عرض 320px (≤ 86vw)؛ على الحاسبة ≥1024 مثبّتة على اليمين 280px', 'R-082، R-084'],
  ['SC-TABBAR-S', 'الشريط السفلي — طالب', 'الرئيسية · التحاضير · ملفي', 'R-078'],
  ['SC-TABBAR-R', 'الشريط السفلي — ممثل', 'الرئيسية · إدارة الصف · التحاضير', 'R-079'],
  ['SC-TABBAR-D', 'الشريط السفلي — مطوّر (جديد؛ قرار منفّذ E-021)', 'لوحة التحكم · الممثلون · النظام', 'R-080'],
  ['SC-OFFLINE-BANNER', 'شريط «دون اتصال» وختم آخر تحديث', 'شريط رفيع تحت الترويسة + ختم «آخر تحديث: …» على كل شاشة قراءة مخزّنة؛ أزرار الحفظ تُعطَّل بسبب مكتوب', 'R-008، R-009'],
  ['SC-SUPPORT-BAR', 'شريط وضع الدعم (جديد)', 'شريط ثابت غير قابل للإخفاء فوق الترويسة بخلفية `--support-bg`: «وضع الدعم — تعرض حساب: {الاسم} ({الدور}) · الكتابة تتطلب تأكيداً · [إنهاء]» + مؤقت الانتهاء', 'R-017، R-035']
];

// ===== الأدوار الظاهرة (letters: d r s) =====
// الشاشات: [id, اسم, مسار, أدوار, مدخل, نوع, acts(كيان→{دور:عمليات}), حالات, مطالب, برومبت التنفيذ, ما يقابلها في V1/full.html]
// الحالات: L تحميل · E فراغ · X خطأ · O دون اتصال (مخزّنة) · B محجوبة دون اتصال (تحتاج الخادم) · C تعارض نسخ · V تحقق مدخلات · W كتابة معطّلة دون اتصال
// الأنواع: auth · root (جذر تبويب/شاشة رئيسية) · tabpage (صفحة داخل مجموعة تبويب) · page · form · sheet · static · system
var S = function (a) { return { id: a[0], ar: a[1], route: a[2], roles: a[3], entry: a[4], kind: a[5], acts: a[6] || {}, states: a[7] || '', req: a[8], prompt: a[9], v1: a[10] || '—' }; };
var RW = { s: 'R', r: 'RCUA', d: 'RCUA' }; // محتوى الصف C0: الطالب قراءة، الممثل والمطوّر كاملة
var SCREENS = [
  S(['SC-INTRO', 'الشاشة الافتتاحية', '— (قبل التوجيه)', 'drs', 'فتح التطبيق', 'system', {}, '', 'R-086', '02.02', 'V1: انترو ✅']),
  S(['SC-LOGIN-DEV', 'دخول المطوّر', '#/login', 'd', 'لا جلسة', 'auth', {}, 'XV', 'R-012، R-013', '04.01']),
  S(['SC-ACTIVATE', 'التفعيل بالرمز', '#/activate', 'rs', 'لا جلسة/جهاز جديد/استرداد', 'auth', {}, 'XV', 'R-018، R-019، R-025، R-026', '04.02، 04.03', 'V1: رمز تحضير (دلالة مختلفة)']),
  S(['SC-PIN-SETUP', 'إنشاء PIN (6 أرقام، تأكيدان)', '#/pin/setup', 'drs', 'بعد الدخول/التفعيل', 'auth', {}, 'V', 'R-013، R-019، R-025', '04.01، 04.02، 04.03']),
  S(['SC-PIN-UNLOCK', 'فتح بـPIN', '#/pin', 'drs', 'فتح التطبيق بجلسة صالحة · «قفل»', 'auth', {}, 'XV', 'R-014، R-026', '04.04']),
  S(['SC-INSTALL-HELP', 'تثبيت التطبيق', '#/install', 'drs', 'الإعدادات', 'static', {}, '', 'R-006', '02.03']),

  S(['SC-HOME-S', 'الرئيسية — طالب', '#/home', 's', 'تبويب «الرئيسية»', 'root', { announcements: { s: 'R' }, preps: { s: 'R' }, exams: { s: 'R' }, notifications: { s: 'R' } }, 'LEXO', 'R-075، R-083', '08.01', 'V1: بطاقات متعددة (تُستبدل)']),
  S(['SC-HOME-R', 'الرئيسية — ممثل', '#/home', 'r', 'تبويب «الرئيسية»', 'root', { announcements: { r: 'R' }, preps: { r: 'R' }, attendance_sheets: { r: 'R' }, cost_stats: { r: 'R' }, notifications: { r: 'R' } }, 'LEXO', 'R-075، R-083', '08.02', 'V1: وضع الممثل (تُستبدل)']),
  S(['SC-DEV-HOME', 'لوحة تحكم المطوّر (≡ SC-HOME-D)', '#/dev', 'd', 'تبويب «لوحة التحكم»', 'root', { members: { d: 'R' }, storage_usage: { d: 'R' }, audit_log: { d: 'R' }, app_meta: { d: 'R' } }, 'LEXB', 'R-016، R-080', '08.03']),

  S(['SC-PREPS-TODAY', 'شنو أخذنا اليوم؟', '#/preps/today', 'drs', 'تبويب «التحاضير» (الصفحة 1) · القائمة', 'tabpage', { preps: RW, prep_status: RW, file_objects: { s: 'R', r: 'RCUA', d: 'RCUA' } }, 'LEXOCW', 'R-055، R-056، R-058، R-060، R-061', '06.01، 06.03، 08.01، 08.02', 'full.html: دروس اليوم']),
  S(['SC-PREPS-TOMORROW', 'شنو عدنا باچر؟', '#/preps/tomorrow', 'drs', 'تبويب «التحاضير» (الصفحة 2) · القائمة', 'tabpage', { preps: RW, schedule_entries: { s: 'R', r: 'R', d: 'R' }, exams: { s: 'R', r: 'R', d: 'R' }, file_objects: { s: 'R', r: 'RCUA', d: 'RCUA' } }, 'LEXOCW', 'R-055، R-056، R-060', '06.01، 08.01، 08.02', 'full.html: تحضيرات باچر']),
  S(['SC-EXAM', 'هل عدنا امتحان؟', '#/preps/exam', 'drs', 'تبويب «التحاضير» (الصفحة 3) · القائمة', 'tabpage', { exams: { s: 'R', r: 'R', d: 'R' }, file_objects: { s: 'R', r: 'R', d: 'R' } }, 'LEXO', 'R-051، R-055', '05.04، 08.01، 08.02', 'full.html: الامتحان القريب']),
  S(['SC-PREPS-ARCHIVE', 'سجل التحاضير', '#/preps/archive', 'drs', 'القائمة · رابط من صفحتي اليوم وباچر', 'page', { preps: RW, prep_status: RW, record_history: { r: 'R', d: 'R' } }, 'LEXO', 'R-057، R-059', '06.03']),
  S(['SC-PREP-VIEW', 'تفاصيل تحضير (جديد)', '#/preps/:id', 'drs', 'لمس بطاقة تحضير', 'page', { preps: { s: 'R', r: 'R', d: 'R' }, file_objects: { s: 'R', r: 'R', d: 'R' }, storage_objects: { s: 'R', r: 'R', d: 'R' } }, 'LEXO', 'R-059', '06.01، 06.02']),
  S(['SC-PREP-FORM', 'إنشاء/تعديل تحضير', '#/preps/new · #/preps/:id/edit', 'dr', 'زر «+ تحضير» · القائمة', 'form', { preps: { r: 'RCUA', d: 'RCUA' }, file_objects: { r: 'RCUA', d: 'RCUA' }, storage_objects: { r: 'RC', d: 'RC' } }, 'VCWX', 'R-053، R-054، R-061', '06.01', 'V1: نموذج بحقول أخرى (C-13)']),
  S(['SC-ATTACH', 'المرفقات: اختيار/ضغط/معاينة', 'ورقة داخل النماذج + عارض', 'drs', 'من نموذج أو تفاصيل', 'sheet', { file_objects: { s: 'R', r: 'RCUA', d: 'RCUA' }, storage_objects: { s: 'R', r: 'RC', d: 'RC' }, storage_usage: { r: 'R', d: 'R' } }, 'LXVW', 'R-059، R-073', '06.02']),
  S(['SC-HOMEWORK', 'الواجبات', '#/homework', 'drs', 'القائمة', 'page', { homework: RW, file_objects: { s: 'R', r: 'RCUA', d: 'RCUA' } }, 'LEXOCVW', 'R-062', '06.04']),
  S(['SC-EXAMS', 'كل الامتحانات', '#/exams', 'drs', 'القائمة · رابط من «هل عدنا امتحان؟»', 'page', { exams: RW, file_objects: { s: 'R', r: 'RCUA', d: 'RCUA' } }, 'LEXOCW', 'R-051', '05.04', 'full.html: الامتحانات']),
  S(['SC-EXAM-FORM', 'إضافة/تعديل امتحان (جديد)', '#/exams/new · #/exams/:id/edit', 'dr', 'من SC-EXAMS', 'form', { exams: { r: 'CUA', d: 'CUA' }, file_objects: { r: 'C', d: 'C' } }, 'VCWX', 'R-051', '05.04']),
  S(['SC-SCHEDULE', 'الجدول الدراسي', '#/schedule', 'drs', 'القائمة', 'page', { schedule_entries: RW }, 'LEXOCVW', 'R-052', '05.02', 'full.html: الجدول']),
  S(['SC-ANNOUNCE', 'الإعلانات', '#/announcements', 'drs', 'القائمة · البطاقة المثبّتة في الرئيسية', 'page', { announcements: RW }, 'LEXOW', 'R-067، R-068', '07.01']),
  S(['SC-ANNOUNCE-FORM', 'إنشاء/تعديل إعلان (جديد)', '#/announcements/new', 'dr', 'من SC-ANNOUNCE', 'form', { announcements: { r: 'CUA', d: 'CUA' } }, 'VCWX', 'R-067', '07.01']),
  S(['SC-NOTIFS', 'مركز الإشعارات', '#/notifications', 'drs', 'أيقونة الجرس في الترويسة', 'page', { notifications: { s: 'R', r: 'R', d: 'R' }, notification_reads: { s: 'RCU', r: 'RCU', d: 'RCU' } }, 'LEXO', 'R-069', '07.02']),

  S(['SC-PROFILE', 'ملفي', '#/me', 'drs', 'تبويب «ملفي» (طالب) · «حسابي» في القائمة (ممثل/مطوّر)', 'root', { students: { s: 'R' }, members: { s: 'R', r: 'R', d: 'R' } }, 'LEXO', 'R-027', '08.01']),
  S(['SC-ABSENCES-MINE', 'غياباتي', '#/me/absences', 's', 'ملفي ◄ تبويب «الغيابات»', 'tabpage', { attendance_records: { s: 'R' }, students: { s: 'R' } }, 'LEXO', 'R-027، R-046', '08.01']),
  S(['SC-GRADES-MINE', 'درجاتي', '#/me/grades', 's', 'ملفي ◄ تبويب «الدرجات»', 'tabpage', { grades: { s: 'R' }, class_settings: { s: 'R' } }, 'LEXO', 'R-027، R-049', '08.01']),
  S(['SC-PAYMENTS-MINE', 'دفعاتي', '#/me/payments', 's', 'ملفي ◄ تبويب «الدفعات»', 'tabpage', { cost_items: { s: 'R' }, cost_assignments: { s: 'R' }, payments: { s: 'R' } }, 'LEXO', 'R-027، R-065', '08.01']),

  S(['SC-CLASS-MGMT', 'إدارة الصف', '#/class', 'dr', 'تبويب «إدارة الصف» (ممثل) · القائمة', 'root', { students: { r: 'R', d: 'R' }, attendance_sheets: { r: 'R', d: 'R' }, cost_stats: { r: 'R', d: 'R' }, storage_usage: { r: 'R', d: 'R' } }, 'LEXO', 'R-021، R-079', '08.02']),
  S(['SC-STUDENTS', 'الطلاب', '#/class/students', 'dr', 'إدارة الصف', 'page', { students: { r: 'RCUA', d: 'RCUA' }, members: { r: 'R', d: 'R' } }, 'LEXOCW', 'R-039، R-040', '05.01', 'full.html: الطلاب']),
  S(['SC-STUDENT-FORM', 'إضافة/تعديل طالب', '#/class/students/new · #/class/students/:id/edit', 'dr', 'من SC-STUDENTS', 'form', { students: { r: 'CU', d: 'CU' }, members: { r: 'C', d: 'C' }, activation_codes: { r: 'C', d: 'C' } }, 'VCWX', 'R-036، R-038', '04.03، 05.01']),
  S(['SC-STUDENT-PROFILE', 'ملف طالب (منظور الممثل)', '#/class/students/:id', 'dr', 'من SC-STUDENTS', 'page', { students: { r: 'RUA', d: 'RUA' }, attendance_records: { r: 'R', d: 'R' }, grades: { r: 'R', d: 'R' }, cost_assignments: { r: 'R', d: 'R' }, payments: { r: 'R', d: 'R' }, activation_codes: { r: 'C', d: 'C' }, members: { r: 'U', d: 'U' } }, 'LEXOCW', 'R-022', '04.03، 04.04، 05.01']),
  S(['SC-STUDENT-IMPORT', 'استيراد/تصدير الطلاب', '#/class/students/import', 'dr', 'من SC-STUDENTS', 'page', { students: { r: 'C', d: 'C' }, roster_export: { r: 'C', d: 'C' } }, 'XVBW', 'R-041', '05.01']),
  S(['SC-ATTENDANCE', 'الحضور والغياب', '#/class/attendance', 'dr', 'إدارة الصف · «اعتماد حضور اليوم» من الرئيسية', 'page', { attendance_sheets: { r: 'RCUA', d: 'RCUA' }, attendance_records: { r: 'RCUA', d: 'RCUA' }, students: { r: 'R', d: 'R' }, record_history: { r: 'R', d: 'R' } }, 'LEXOCW', 'R-042، R-043، R-044، R-045، R-047', '05.03', 'full.html: حضور']),
  S(['SC-GRADES', 'الدرجات', '#/class/grades', 'dr', 'إدارة الصف', 'page', { grades: { r: 'RCUA', d: 'RCUA' }, students: { r: 'R', d: 'R' }, class_settings: { r: 'RU', d: 'RU' }, record_history: { r: 'R', d: 'R' } }, 'LEXOCVW', 'R-048، R-049، R-050', '05.04', 'full.html: درجات']),
  S(['SC-COSTS', 'التكاليف والدفعات', '#/class/costs', 'dr', 'إدارة الصف', 'page', { cost_items: { r: 'RCUA', d: 'RCUA' }, cost_assignments: { r: 'RCUA', d: 'RCUA' }, payments: { r: 'RCA', d: 'RCA' }, cost_stats: { r: 'R', d: 'R' } }, 'LEXOCVW', 'R-063، R-064، R-065، R-066', '05.05', 'V1/full.html: مقبوضات فقط (C-15)']),

  S(['SC-SETTINGS', 'الإعدادات', '#/settings', 'drs', 'القائمة (أسفل)', 'page', { push_subscriptions: { s: 'RCUA', r: 'RCUA', d: 'RCUA' }, class_settings: { s: 'R', r: 'R', d: 'R' }, storage_usage: { r: 'R', d: 'R' } }, 'LXOW', 'R-070، R-071، R-076', '08.04', 'V1: مظهر ثلاثي ✅']),
  S(['SC-UPCOMING', 'التحديثات القادمة', '#/settings/upcoming', 'drs', 'الإعدادات فقط', 'static', {}, '', 'R-004، R-085', '08.04']),
  S(['SC-ABOUT', 'عن مَرسى', '#/about', 'drs', 'القائمة (أسفل)', 'static', {}, '', 'R-001، R-087', '08.04', 'V1: «عن مَرسى وحدوده» بمحتوى مختلف']),

  S(['SC-REPS', 'الممثلون', '#/dev/reps', 'd', 'تبويب «الممثلون» · القائمة', 'root', { members: { d: 'RCUA' }, activation_codes: { d: 'RCA' } }, 'LEXOCW', 'R-015، R-018، R-020', '04.02']),
  S(['SC-SUPPORT', 'وضع الدعم', '#/dev/support', 'd', 'القائمة (إدارة)', 'page', { support_sessions: { d: 'RCU' }, members: { d: 'R' }, students: { d: 'R' } }, 'LEXBW', 'R-017، R-035', '04.04']),
  S(['SC-AUDIT', 'سجل التدقيق', '#/dev/audit', 'd', 'القائمة (إدارة)', 'page', { audit_log: { d: 'R' } }, 'LEXB', 'R-034', '04.04، 08.03']),
  S(['SC-SYSTEM', 'النظام والتخزين', '#/dev/system', 'd', 'تبويب «النظام» · القائمة', 'root', { system_settings: { d: 'RU' }, storage_usage: { d: 'R' }, app_meta: { d: 'R' } }, 'LEXBW', 'R-016، R-073', '08.03']),
  S(['SC-BACKUP', 'النسخ الاحتياطي', '#/dev/backup', 'd', 'النظام ◄ النسخ', 'page', { backup_export: { d: 'C' } }, 'XBW', 'R-090، R-092، R-094', '09.05']),

  S(['SC-FORBIDDEN', 'غير متاح لحسابك (جديد)', 'أي مسار مرفوض للدور', 'drs', 'حارس المسار', 'system', {}, '', 'R-075، R-029', '02.02']),
  S(['SC-NOTFOUND', 'الصفحة غير موجودة', 'أي مسار مجهول', 'drs', 'حارس المسار', 'system', {}, '', 'R-077', '02.02', 'V1: notFound ✅'])
];

// مرادفات المعجم المؤقت في REQUIREMENTS-TRACEABILITY §2 → ما ثُبِّت هنا
var ALIASES = { 'SC-HOME-D': 'SC-DEV-HOME', 'SC-HOME-S/R/D': 'SC-HOME-S + SC-HOME-R + SC-DEV-HOME', 'SC-TABBAR-S/R': 'SC-TABBAR-S + SC-TABBAR-R', 'SC-HOME-': 'SC-HOME-S/R + SC-DEV-HOME', 'SC-PREPS-': 'SC-PREPS-TODAY/TOMORROW/ARCHIVE + SC-EXAM' };

// ===== الأشرطة السفلية =====
var TABBARS = {
  s: { frame: 'SC-TABBAR-S', tabs: [['الرئيسية', 'SC-HOME-S', 'home'], ['التحاضير', 'SC-PREPS-TODAY', 'book'], ['ملفي', 'SC-PROFILE', 'user']] },
  r: { frame: 'SC-TABBAR-R', tabs: [['الرئيسية', 'SC-HOME-R', 'home'], ['إدارة الصف', 'SC-CLASS-MGMT', 'grid'], ['التحاضير', 'SC-PREPS-TODAY', 'book']] },
  d: { frame: 'SC-TABBAR-D', tabs: [['لوحة التحكم', 'SC-DEV-HOME', 'gauge'], ['الممثلون', 'SC-REPS', 'users'], ['النظام', 'SC-SYSTEM', 'server']] }
};

// ===== بنود «قيد التطوير» (لا مسار ولا كيان ولا نموذج ولا شبكة — R-084) =====
var FUTURE = [
  { key: 'teachers', ar: 'المدرّسون', roles: 'drs', note: 'حسابات للمدرّسين لمتابعة موادهم.' },
  { key: 'principal', ar: 'المدير', roles: 'dr', note: 'منظور إداري لمتابعة الصف.' },
  { key: 'chat', ar: 'المحادثات', roles: 'drs', note: 'مراسلة داخلية بين الطالب والممثل/المطوّر.' },
  { key: 'classes', ar: 'الشعب المتعددة', roles: 'dr', note: 'إدارة أكثر من شعبة (المخطط يدعمها، الواجهة لا).' },
  { key: 'english', ar: 'الإنجليزية', roles: 'drs', note: 'واجهة بالإنجليزية إلى جانب العربية.' }
];

// ===== القائمة الجانبية =====
var L = function (ar, screen) { return { ar: ar, screen: screen }; };
var F = function (key) { return { future: key }; };
var SIDEBARS = {
  s: [
    { title: null, items: [L('الرئيسية', 'SC-HOME-S')] },
    { title: 'التحاضير', items: [L('شنو أخذنا اليوم؟', 'SC-PREPS-TODAY'), L('شنو عدنا باچر؟', 'SC-PREPS-TOMORROW'), L('هل عدنا امتحان؟', 'SC-EXAM'), L('سجل التحاضير', 'SC-PREPS-ARCHIVE')] },
    { title: 'الدراسة', items: [L('الواجبات', 'SC-HOMEWORK'), L('الجدول الدراسي', 'SC-SCHEDULE'), L('كل الامتحانات', 'SC-EXAMS'), L('الإعلانات', 'SC-ANNOUNCE'), L('الإشعارات', 'SC-NOTIFS')] },
    { title: 'ملفي', items: [L('ملفي', 'SC-PROFILE'), L('غياباتي', 'SC-ABSENCES-MINE'), L('درجاتي', 'SC-GRADES-MINE'), L('دفعاتي', 'SC-PAYMENTS-MINE')] },
    { title: 'قريباً', items: [F('teachers'), F('chat'), F('english')] },
    { title: null, footer: true, items: [L('الإعدادات', 'SC-SETTINGS'), L('عن مَرسى', 'SC-ABOUT'), { action: 'lock', ar: 'قفل التطبيق' }, { action: 'logout', ar: 'تسجيل الخروج' }] }
  ],
  r: [
    { title: null, items: [L('الرئيسية', 'SC-HOME-R')] },
    { title: 'إدارة الصف', items: [L('الطلاب', 'SC-STUDENTS'), L('الحضور والغياب', 'SC-ATTENDANCE'), L('الدرجات', 'SC-GRADES'), L('الامتحانات', 'SC-EXAMS'), L('الجدول الدراسي', 'SC-SCHEDULE'), L('التكاليف والدفعات', 'SC-COSTS'), L('الإعلانات', 'SC-ANNOUNCE')] },
    { title: 'التحاضير', items: [L('شنو أخذنا اليوم؟', 'SC-PREPS-TODAY'), L('شنو عدنا باچر؟', 'SC-PREPS-TOMORROW'), L('هل عدنا امتحان؟', 'SC-EXAM'), L('سجل التحاضير', 'SC-PREPS-ARCHIVE'), L('إضافة تحضير', 'SC-PREP-FORM'), L('الواجبات', 'SC-HOMEWORK')] },
    { title: null, items: [L('الإشعارات', 'SC-NOTIFS'), L('حسابي', 'SC-PROFILE')] },
    { title: 'قريباً', items: [F('teachers'), F('principal'), F('chat'), F('classes'), F('english')] },
    { title: null, footer: true, items: [L('الإعدادات', 'SC-SETTINGS'), L('عن مَرسى', 'SC-ABOUT'), { action: 'lock', ar: 'قفل التطبيق' }, { action: 'logout', ar: 'تسجيل الخروج' }] }
  ],
  d: [
    { title: null, items: [L('لوحة التحكم', 'SC-DEV-HOME')] },
    { title: 'الإدارة', items: [L('الممثلون', 'SC-REPS'), L('وضع الدعم', 'SC-SUPPORT'), L('سجل التدقيق', 'SC-AUDIT'), L('النظام والتخزين', 'SC-SYSTEM'), L('النسخ الاحتياطي', 'SC-BACKUP')] },
    { title: 'عرض الصف', items: [L('إدارة الصف', 'SC-CLASS-MGMT'), L('شنو أخذنا اليوم؟', 'SC-PREPS-TODAY'), L('شنو عدنا باچر؟', 'SC-PREPS-TOMORROW'), L('هل عدنا امتحان؟', 'SC-EXAM'), L('سجل التحاضير', 'SC-PREPS-ARCHIVE'), L('الإعلانات', 'SC-ANNOUNCE')] },
    { title: null, items: [L('الإشعارات', 'SC-NOTIFS'), L('حسابي', 'SC-PROFILE')] },
    { title: 'قريباً', items: [F('teachers'), F('principal'), F('chat'), F('classes'), F('english')] },
    { title: null, footer: true, items: [L('الإعدادات', 'SC-SETTINGS'), L('عن مَرسى', 'SC-ABOUT'), { action: 'lock', ar: 'قفل التطبيق' }, { action: 'logout', ar: 'تسجيل الخروج' }] }
  ]
};

// ===== سقف الرئيسية (R-083): أقصى عدد بطاقات وأزرار سريعة =====
var HOME = {
  maxCards: 4, maxQuick: 3,
  s: { cards: ['الإعلان المثبّت (0–1)', 'ملخص اليوم: ثلاثة أسطر روابط (اليوم · باچر · الامتحان) — بطاقة واحدة', 'آخر الإشعارات غير المقروءة (شريط ≤ 2)'], quick: [] },
  r: { cards: ['ملخص اليوم: ثلاثة أسطر روابط', 'تنبيهات الصف (كشف اليوم غير معتمد · تكاليف متأخرة)', 'الإعلان المثبّت (0–1)'], quick: ['إضافة تحضير', 'اعتماد حضور اليوم', 'إعلان جديد'] },
  d: { cards: ['حالة النظام (اتصال · إصدار المخطط · آخر نسخة)', 'التخزين (قاعدة/ملفات مقابل الحد المجاني)', 'الممثلون (نشط/موقوف)', 'آخر نشاط تدقيق (≤ 5 أسطر)'], quick: ['فتح وضع الدعم'] }
};
HOME.s.n = 3; HOME.r.n = 3; HOME.d.n = 4;

// ===== الصفحات الثلاث =====
var THREE = [
  { id: 'SC-PREPS-TODAY', q: 'شنو أخذنا اليوم؟', route: '#/preps/today', idx: 1 },
  { id: 'SC-PREPS-TOMORROW', q: 'شنو عدنا باچر؟', route: '#/preps/tomorrow', idx: 2 },
  { id: 'SC-EXAM', q: 'هل عدنا امتحان؟', route: '#/preps/exam', idx: 3 }
];

var STATE_CODES = { L: 'تحميل (هيكل)', E: 'فراغ', X: 'خطأ', O: 'دون اتصال (بيانات مخزّنة + ختم)', B: 'محجوبة دون اتصال (لا كاش)', C: 'تعارض نسخ (version)', V: 'تحقق مدخلات', W: 'الكتابة معطّلة دون اتصال بسبب مكتوب' };
var KIND_AR = { auth: 'مصادقة', root: 'جذر', tabpage: 'صفحة تبويب', page: 'صفحة', form: 'نموذج', sheet: 'ورقة', static: 'ثابتة', system: 'نظام' };

var GLOSSARY_IDS = ['SC-INTRO', 'SC-LOGIN-DEV', 'SC-ACTIVATE', 'SC-PIN-SETUP', 'SC-PIN-UNLOCK', 'SC-HEADER', 'SC-SIDEBAR', 'SC-TABBAR-S', 'SC-TABBAR-R', 'SC-HOME-S', 'SC-HOME-R', 'SC-HOME-D', 'SC-PREPS-TODAY', 'SC-PREPS-TOMORROW', 'SC-EXAM', 'SC-PREPS-ARCHIVE', 'SC-PREP-FORM', 'SC-ATTACH', 'SC-HOMEWORK', 'SC-CLASS-MGMT', 'SC-STUDENTS', 'SC-STUDENT-FORM', 'SC-STUDENT-PROFILE', 'SC-STUDENT-IMPORT', 'SC-ATTENDANCE', 'SC-ABSENCES-MINE', 'SC-GRADES', 'SC-GRADES-MINE', 'SC-EXAMS', 'SC-SCHEDULE', 'SC-COSTS', 'SC-PAYMENTS-MINE', 'SC-ANNOUNCE', 'SC-NOTIFS', 'SC-PROFILE', 'SC-REPS', 'SC-SUPPORT', 'SC-AUDIT', 'SC-SYSTEM', 'SC-BACKUP', 'SC-SETTINGS', 'SC-UPCOMING', 'SC-ABOUT', 'SC-INSTALL-HELP', 'SC-DEV-HOME', 'SC-OFFLINE-BANNER'];

var BREAKPOINTS = [['≤ 359', 'أدنى مدعوم 320: عمود واحد، الشريط السفلي 3 عناصر بأيقونة + كلمة، لا تمرير أفقي'], ['360–767', 'هاتف (مرجع 390): ترويسة + محتوى + شريط سفلي؛ القائمة الجانبية ورقة من اليمين'], ['768–1023', 'لوح: المحتوى عمود وسط ≤ 720؛ الشريط السفلي يبقى؛ القائمة ورقة'], ['≥ 1024', 'حاسبة: القائمة مثبّتة يميناً 280px بدل الورقة؛ الشريط السفلي يختفي؛ المحتوى ≤ 960 وعمودان في الرئيسية فقط']];

module.exports = { ROLES: ROLES, ROLE_AR: ROLE_AR, TOKENS: TOKENS, NEW_TOKENS: NEW_TOKENS, PAIRS: PAIRS, contrast: contrast, contrastTable: contrastTable, EASE: EASE, MOTION: MOTION, FRAME: FRAME, SCREENS: SCREENS, ALIASES: ALIASES, TABBARS: TABBARS, FUTURE: FUTURE, SIDEBARS: SIDEBARS, HOME: HOME, THREE: THREE, STATE_CODES: STATE_CODES, KIND_AR: KIND_AR, GLOSSARY_IDS: GLOSSARY_IDS, BREAKPOINTS: BREAKPOINTS };
