// MARSA 4.02 — اختبارات منطق المتجر للأنواع الجديدة: attendance / grades / payments
// تشغيل: node tests/academic-store-stage4.test.js  (لا يحتاج مكتبات)
var assert = require('assert'), S = require('../js/academic-store.js');

function fake(opt) {
  opt = opt || {}; var d = {}, o;
  o = {
    d: d, sets: 0, removes: 0,
    get length() { return Object.keys(d).length; },
    key: function (i) { return Object.keys(d)[i] || null; },
    getItem: function (k) { if (opt.blocked || opt.failRead) throw new Error('blocked'); return k in d ? d[k] : null; },
    setItem: function (k, v) { if (opt.blocked || opt.full) throw new Error('quota'); o.sets++; d[k] = String(v); },
    removeItem: function (k) { o.removes++; delete d[k]; }
  };
  return o;
}
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }

var A = 'cls_a', B = 'cls_b', S1 = 'stu-1', S2 = 'stu-2';
function att(o) { var r = { studentId: S1, date: '2026-10-21', status: 'present' }; for (var k in o) r[k] = o[k]; return r; }
function grd(o) { var r = { studentId: S1, subject: 'رياضيات', title: 'اختبار قصير', date: '2026-10-21', score: 7.5, maxScore: 10 }; for (var k in o) r[k] = o[k]; return r; }
function pay(o) { var r = { studentId: S1, amount: 5000, purpose: 'رحلة', date: '2026-10-21' }; for (var k in o) r[k] = o[k]; return r; }
var MK = { attendance: att, grades: grd, payments: pay };
function fresh(opt) { var st = fake(opt); return { st: st, s: S.create({ storage: st }) }; }
function keyOf(type, cls) { return 'marsa.academic.' + type + '.' + cls; }

// ---------- 1) الأنواع والمفاتيح والمعرّفات
t('TYPES: الأربعة القديمة بترتيبها + الثلاثة الجديدة؛ لا تغيير في ما سبق', function () {
  assert.deepStrictEqual(S.TYPES, ['dailyLessons', 'preparations', 'schedule', 'exams', 'attendance', 'grades', 'payments']);
  assert.deepStrictEqual(S.create({ storage: fake() }).TYPES, S.TYPES);
});
t('المفتاح marsa.academic.<type>.<classId> وبادئات المعرّفات att_ grd_ pay_', function () {
  var s = S.create({ storage: fake() });
  assert.strictEqual(s.keyFor('attendance', A), 'marsa.academic.attendance.cls_a');
  assert.strictEqual(s.keyFor('grades', A), 'marsa.academic.grades.cls_a');
  assert.strictEqual(s.keyFor('payments', A), 'marsa.academic.payments.cls_a');
  assert.ok(/^att_[A-Za-z0-9_-]+$/.test(s.newId('attendance')) && /^grd_/.test(s.newId('grades')) && /^pay_/.test(s.newId('payments')));
  assert.ok(/^dl_/.test(s.newId('dailyLessons')) && /^prep_/.test(s.newId('preparations')) && /^sch_/.test(s.newId('schedule')) && /^exam_/.test(s.newId('exams')));
  var seen = {}, i, id; for (i = 0; i < 300; i++) { id = s.newId('payments'); assert.ok(S.create && /^[A-Za-z0-9_-]{1,64}$/.test(id) && !seen[id]); seen[id] = 1; }
});
t('نوع غير معروف أو صف غير صالح: invalid-args ولا كتابة (كل طرق الواجهة)', function () {
  var x = fresh(), s = x.s, bad = ['students', 'Attendance', '', undefined, null, '__proto__'], i;
  for (i = 0; i < bad.length; i++) {
    assert.strictEqual(s.readCollection(bad[i], A).status, 'invalid-args');
    assert.strictEqual(s.upsertRecord(bad[i], A, att()).status, 'invalid-args');
    assert.strictEqual(s.upsertMany(bad[i], A, [att()]).status, 'invalid-args');
    assert.strictEqual(s.deleteRecord(bad[i], A, 'x').status, 'invalid-args');
  }
  ['../x', 'a b', '', null, undefined, 5, 'a/b', 'x'.repeat(65)].forEach(function (c) {
    assert.strictEqual(s.readCollection('attendance', c).status, 'invalid-args');
    assert.strictEqual(s.upsertRecord('grades', c, grd()).status, 'invalid-args');
    assert.strictEqual(s.upsertMany('payments', c, [pay()]).status, 'invalid-args');
  });
  assert.strictEqual(x.st.length, 0);
});

// ---------- 2) انحدار الأنواع القديمة
t('انحدار: الأنواع القديمة لا تخضع للتحقق النوعي ولا لقيد تفرّد', function () {
  var s = fresh().s;
  // exams/schedule/dailyLessons/preparations بلا studentId ولا status، وتكرار نفس المحتوى مسموح كما كان
  assert.ok(s.upsertRecord('exams', A, { title: 'x', examDate: '2026-11-01' }).ok);
  assert.ok(s.upsertRecord('exams', A, { title: 'x', examDate: '2026-11-01' }).ok);
  assert.strictEqual(s.readCollection('exams', A).records.length, 2);
  assert.ok(s.upsertRecord('dailyLessons', A, { date: '2026-10-21', status: 'whatever', score: 'abc', amount: -1, extra: 1 }).ok);
  assert.ok(s.upsertRecord('preparations', A, { title: 'p', studentId: 'غير صالح مسافات' }).ok);
  assert.ok(s.upsertRecord('schedule', A, { startTime: '08:00' }).ok);
  assert.strictEqual(s.upsertRecord('exams', A, { examDate: '2026-13-01' }).status, 'invalid-records');
  assert.strictEqual(s.upsertRecord('schedule', A, { startTime: '25:00' }).status, 'invalid-records');
});
t('انحدار: schemaVersion يبقى 1 لكل الأنواع القديمة والجديدة', function () {
  var x = fresh(); assert.strictEqual(x.s.SCHEMA_VERSION, 1);
  x.s.upsertRecord('exams', A, { title: 'x' }); x.s.upsertRecord('attendance', A, att());
  assert.strictEqual(JSON.parse(x.st.d[keyOf('exams', A)]).schemaVersion, 1);
  assert.strictEqual(JSON.parse(x.st.d[keyOf('attendance', A)]).schemaVersion, 1);
});
t('انحدار: بيانات قديمة مخزّنة بنفس الشكل تُقرأ كما هي (لا ترحيل)', function () {
  var x = fresh(), raw = JSON.stringify({ schemaVersion: 1, classId: A, records: [{ recordId: 'dl_old', classId: A, date: '2026-10-01', subject: 'م' }] });
  x.st.d[keyOf('dailyLessons', A)] = raw;
  assert.strictEqual(x.s.readCollection('dailyLessons', A).records.length, 1);
  x.s.upsertRecord('attendance', A, att());
  assert.strictEqual(x.st.d[keyOf('dailyLessons', A)], raw);
});

// ---------- 3) تحقق نوعي: قبول السجل الصالح
t('سجل صالح لكل نوع يُحفظ مع recordId وclassId وطوابع زمنية', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var s = fresh().s, r = s.upsertRecord(ty, A, MK[ty]());
    assert.ok(r.ok && r.created && r.status === 'saved', ty);
    assert.ok(/^[A-Za-z0-9_-]{1,64}$/.test(r.record.recordId) && r.record.classId === A, ty);
    assert.ok(!isNaN(Date.parse(r.record.createdAt)) && !isNaN(Date.parse(r.record.updatedAt)), ty);
    assert.strictEqual(s.readCollection(ty, A).records.length, 1);
  });
});
t('الحالات الأربع للحضور كلها مقبولة وغيرها مرفوض', function () {
  var s = fresh().s, sts = ['present', 'absent', 'late', 'excused'], i;
  for (i = 0; i < sts.length; i++) assert.ok(s.upsertRecord('attendance', A, att({ studentId: 'stu-' + i, status: sts[i] })).ok, sts[i]);
  ['', 'Present', 'حاضر', 'unknown', null, 1, undefined, true].forEach(function (b) {
    var r = att({ studentId: 'zz', status: b }); if (b === undefined) delete r.status;
    assert.strictEqual(s.upsertRecord('attendance', A, r).status, 'invalid-records', String(b));
  });
  assert.strictEqual(s.readCollection('attendance', A).records.length, 4);
});

// ---------- 4) تحقق نوعي: الحقول المشتركة
t('studentId مطلوب وبصيغة صالحة في الأنواع الثلاثة (ليس الاسم ولا الرقم المعروض)', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var s = fresh().s;
    [undefined, null, '', 'a b', '../x', 'محمد', 7, {}, [], 'x'.repeat(65)].forEach(function (b) {
      var r = MK[ty](); if (b === undefined) delete r.studentId; else r.studentId = b;
      assert.strictEqual(s.upsertRecord(ty, A, r).status, 'invalid-records', ty + ':' + String(b));
    });
    assert.strictEqual(s.readCollection(ty, A).status, 'empty');
  });
});
t('date مطلوب وبصيغة YYYY-MM-DD محلية فقط', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var s = fresh().s;
    [undefined, null, '', '2026-02-30', '2026-13-01', '2026-1-1', '21-10-2026', '2026/10/21', '2026-10-21T00:00:00Z', '2026-10-21T08:00', ' 2026-10-21', 20261021, new Date(2026, 9, 21)].forEach(function (b) {
      var r = MK[ty](); if (b === undefined) delete r.date; else r.date = b;
      assert.strictEqual(s.upsertRecord(ty, A, r).status, 'invalid-records', ty + ':' + String(b));
    });
    assert.ok(s.upsertRecord(ty, A, MK[ty]({ date: '2024-02-29' })).ok, 'تاريخ كبيس صالح');
    assert.strictEqual(s.upsertRecord(ty, A, MK[ty]({ date: '2026-02-29', studentId: 'q' })).status, 'invalid-records');
  });
});
t('note اختياري ≤ 200 حرف ونص فقط', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var s = fresh().s, r;
    assert.ok(s.upsertRecord(ty, A, MK[ty]({ note: 'ملاحظة' })).ok);
    r = s.upsertRecord(ty, A, MK[ty]({ studentId: 'k2', note: 'ن'.repeat(200) })); assert.ok(r.ok, ty);
    assert.strictEqual(s.upsertRecord(ty, A, MK[ty]({ studentId: 'k3', note: 'ن'.repeat(201) })).status, 'invalid-records');
    assert.strictEqual(s.upsertRecord(ty, A, MK[ty]({ studentId: 'k4', note: 5 })).status, 'invalid-records');
    assert.strictEqual(s.upsertRecord(ty, A, MK[ty]({ studentId: 'k5', note: null })).status, 'invalid-records');
  });
});
t('recordId: يُنشأ تلقائياً إن غاب، والمقدَّم غير الصالح مرفوض، وclassId مخالف مرفوض', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var s = fresh().s;
    ['a b', '../x', '', null, 5, 'x'.repeat(65), 'عربي'].forEach(function (b) {
      assert.strictEqual(s.upsertRecord(ty, A, MK[ty]({ recordId: b })).status, 'invalid-records', ty + ':' + String(b));
    });
    assert.strictEqual(s.upsertRecord(ty, A, MK[ty]({ classId: B })).status, 'class-mismatch');
    assert.strictEqual(s.readCollection(ty, A).status, 'empty');
    assert.ok(s.upsertRecord(ty, A, MK[ty]({ recordId: 'my_id-1', classId: A })).ok);
    assert.strictEqual(s.readCollection(ty, A).records[0].recordId, 'my_id-1');
  });
});

// ---------- 5) الدرجات
t('grades: score/maxScore أرقام ضمن الحدود وبخانتين عشريتين كحد أقصى', function () {
  var s = fresh().s, i = 0;
  function ok(o, why) { o.studentId = 's' + (++i); assert.ok(s.upsertRecord('grades', A, grd(o)).ok, why); }
  function no(o, why) { o.studentId = 's' + (++i); assert.strictEqual(s.upsertRecord('grades', A, grd(o)).status, 'invalid-records', why); }
  ok({ score: 0, maxScore: 10 }, 'صفر مسموح');
  ok({ score: 10, maxScore: 10 }, 'الكاملة');
  ok({ score: 0.25, maxScore: 1000 }, 'max=1000');
  ok({ score: 8.35, maxScore: 10 }, 'خانتان');
  ok({ score: 0.07, maxScore: 0.5 }, 'max كسري');
  no({ score: 10.01, maxScore: 10 }, 'فوق القصوى');
  no({ score: -1 }, 'سالب');
  no({ score: -0.01 }, 'سالب صغير');
  no({ score: 1.005 }, 'ثلاث خانات');
  no({ score: 7.123 }, 'ثلاث خانات 2');
  no({ score: '7.5' }, 'نص');
  no({ score: NaN }, 'NaN');
  no({ score: Infinity }, 'Infinity');
  no({ score: null }, 'null');
  no({ score: undefined }, 'غائب');
  no({ score: true }, 'منطقي');
  no({ maxScore: 0 }, 'max=0');
  no({ maxScore: -5 }, 'max سالب');
  no({ maxScore: 1000.01, score: 1 }, 'max>1000');
  no({ maxScore: 1001, score: 1 }, 'max>1000 ب');
  no({ maxScore: '10' }, 'max نص');
  no({ maxScore: NaN }, 'max NaN');
  no({ maxScore: Infinity }, 'max Inf');
  no({ maxScore: 10.123 }, 'max ثلاث خانات');
  assert.strictEqual(s.readCollection('grades', A).records.length, 5);
});
t('grades: الدرجة المفقودة ليست صفراً (لا سجل بلا score) والنسبة لا تُخزَّن', function () {
  var s = fresh().s, r = grd(); delete r.score;
  assert.strictEqual(s.upsertRecord('grades', A, r).status, 'invalid-records');
  ['percent', 'percentage', 'total', 'average'].forEach(function (k) { var o = grd({ studentId: 'p' + k }); o[k] = 75; assert.strictEqual(s.upsertRecord('grades', A, o).status, 'invalid-records', k); });
  assert.strictEqual(s.readCollection('grades', A).status, 'empty');
});
t('grades: subject/title مطلوبان 1–80 بعد التقليم ويُخزَّنان مقلَّمين', function () {
  var s = fresh().s, r;
  ['', '   ', undefined, null, 5, 'م'.repeat(81)].forEach(function (b, i) {
    var o = grd({ studentId: 'a' + i, subject: b }), o2 = grd({ studentId: 'b' + i, title: b });
    if (b === undefined) { delete o.subject; delete o2.title; }
    assert.strictEqual(s.upsertRecord('grades', A, o).status, 'invalid-records', 'subject ' + String(b));
    assert.strictEqual(s.upsertRecord('grades', A, o2).status, 'invalid-records', 'title ' + String(b));
  });
  assert.ok(s.upsertRecord('grades', A, grd({ studentId: 'c1', subject: 'م'.repeat(80), title: 'ع'.repeat(80) })).ok);
  r = s.upsertRecord('grades', A, grd({ studentId: 'c2', subject: '  علوم  ', title: '\tنهائي\n' }));
  assert.ok(r.ok && r.record.subject === 'علوم' && r.record.title === 'نهائي');
});

// ---------- 6) المدفوعات
t('payments: amount عدد صحيح موجب فقط', function () {
  var s = fresh().s, i = 0;
  [1, 5000, 250000, Number.MAX_SAFE_INTEGER].forEach(function (a) { assert.ok(s.upsertRecord('payments', A, pay({ amount: a, studentId: 'o' + (++i) })).ok, String(a)); });
  [0, -1, -5000, 1.5, 0.01, 5000.5, '5000', '', null, undefined, NaN, Infinity, -Infinity, Number.MAX_SAFE_INTEGER + 2, true, [], {}].forEach(function (a) {
    var r = pay({ amount: a, studentId: 'x' + (++i) }); if (a === undefined) delete r.amount;
    assert.strictEqual(s.upsertRecord('payments', A, r).status, 'invalid-records', String(a));
  });
  assert.strictEqual(s.readCollection('payments', A).records.length, 4);
});
t('payments: purpose مطلوب 1–80؛ receiptNo اختياري ≤40؛ لا حقول مشتقة (رصيد/متبقٍ)', function () {
  var s = fresh().s;
  ['', '  ', undefined, null, 'غ'.repeat(81), 3].forEach(function (b, i) {
    var r = pay({ studentId: 'p' + i, purpose: b }); if (b === undefined) delete r.purpose;
    assert.strictEqual(s.upsertRecord('payments', A, r).status, 'invalid-records', String(b));
  });
  assert.ok(s.upsertRecord('payments', A, pay({ studentId: 'r1', receiptNo: '12'.repeat(20) })).ok);
  assert.strictEqual(s.upsertRecord('payments', A, pay({ studentId: 'r2', receiptNo: '1'.repeat(41) })).status, 'invalid-records');
  assert.strictEqual(s.upsertRecord('payments', A, pay({ studentId: 'r3', receiptNo: 12 })).status, 'invalid-records');
  ['balance', 'remaining', 'due', 'debt', 'total'].forEach(function (k) { var o = pay({ studentId: 'z' + k }); o[k] = 1; assert.strictEqual(s.upsertRecord('payments', A, o).status, 'invalid-records', k); });
});
t('payments: دفعتان متطابقتان مسموحتان (لا منع تكرار تلقائي) وبمعرّفين مختلفين', function () {
  var s = fresh().s, a = s.upsertRecord('payments', A, pay()), b = s.upsertRecord('payments', A, pay());
  assert.ok(a.ok && b.ok && a.record.recordId !== b.record.recordId);
  assert.strictEqual(s.readCollection('payments', A).records.length, 2);
  assert.ok(s.upsertRecord('payments', A, pay({ receiptNo: 'R1' })).ok && s.upsertRecord('payments', A, pay({ receiptNo: 'R1' })).ok, 'تكرار رقم الوصل ليس منعاً في المتجر');
});

// ---------- 7) ثبات recordId عند التعديل
t('ثبات recordId وclassId وcreatedAt عند التعديل في الأنواع الثلاثة، ولا سجل جديد', function () {
  var tick = 1000;
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var st = fake(), s = S.create({ storage: st, now: function () { return (tick += 60000); } }), a, b, c, edit;
    a = s.upsertRecord(ty, A, MK[ty]()); assert.ok(a.created);
    edit = ty === 'attendance' ? { status: 'absent', note: 'مريض' } : ty === 'grades' ? { score: 9, note: 'حسّن' } : { amount: 6000, note: 'تصحيح' };
    var upd = {}; for (var k in a.record) upd[k] = a.record[k]; for (k in edit) upd[k] = edit[k];
    b = s.upsertRecord(ty, A, upd);
    assert.ok(b.ok && !b.created, ty);
    assert.strictEqual(b.record.recordId, a.record.recordId, ty);
    assert.strictEqual(b.record.classId, A); assert.strictEqual(b.record.createdAt, a.record.createdAt, ty);
    assert.notStrictEqual(b.record.updatedAt, a.record.updatedAt, ty);
    c = s.readCollection(ty, A).records;
    assert.strictEqual(c.length, 1, ty); assert.strictEqual(c[0].recordId, a.record.recordId, ty);
    for (k in edit) assert.deepStrictEqual(c[0][k], edit[k], ty + '.' + k);
    // تعديل متكرر 5 مرات: المعرّف نفسه
    for (var i = 0; i < 5; i++) { upd = c[0]; upd.note = 'n' + i; assert.strictEqual(s.upsertRecord(ty, A, upd).record.recordId, a.record.recordId); c = s.readCollection(ty, A).records; }
    assert.strictEqual(c.length, 1);
    // محاولة تعديل بـclassId آخر مرفوضة ولا تغيّر شيئاً
    var before = st.d[keyOf(ty, A)]; upd = c[0]; upd.classId = B;
    assert.strictEqual(s.upsertRecord(ty, A, upd).status, 'class-mismatch'); assert.strictEqual(st.d[keyOf(ty, A)], before);
  });
});
t('تعديل لا يغيّر studentId (الأنواع الثلاثة) ولا date (الحضور)؛ ولا يطمس السجل', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var st = fake(), s = S.create({ storage: st }), a = s.upsertRecord(ty, A, MK[ty]()), before = st.d[keyOf(ty, A)], u;
    u = JSON.parse(JSON.stringify(a.record)); u.studentId = S2;
    assert.strictEqual(s.upsertRecord(ty, A, u).status, 'immutable-field', ty);
    assert.strictEqual(st.d[keyOf(ty, A)], before, ty);
    if (ty === 'attendance') {
      u = JSON.parse(JSON.stringify(a.record)); u.date = '2026-10-22';
      assert.strictEqual(s.upsertRecord(ty, A, u).status, 'immutable-field');
      assert.strictEqual(st.d[keyOf(ty, A)], before);
    }
  });
  // في الدرجات يجوز تغيير date/subject/title (يعيد فحص التفرّد)
  var s2 = fresh().s, g = s2.upsertRecord('grades', A, grd()), u2 = JSON.parse(JSON.stringify(g.record)); u2.date = '2026-10-25'; u2.title = 'نهائي';
  assert.ok(s2.upsertRecord('grades', A, u2).ok);
});

// ---------- 8) تكرار recordId
t('recordId المكرر داخل المجموعة المخزّنة: مجموعة تالفة محجوبة + نسخة خام، لا مسح', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var x = fresh(), k = keyOf(ty, A), r1 = MK[ty](), r2 = MK[ty]({ studentId: S2 }), raw;
    r1.recordId = r2.recordId = 'dup_1'; r1.classId = r2.classId = A;
    raw = JSON.stringify({ schemaVersion: 1, classId: A, records: [r1, r2] }); x.st.d[k] = raw;
    var r = x.s.readCollection(ty, A);
    assert.ok(!r.ok && r.status === 'corrupt' && r.blocked && /مكرر/.test(r.error), ty);
    assert.strictEqual(r.records.length, 0); assert.strictEqual(x.st.d[k], raw); assert.strictEqual(x.st.d[k + '.backup'], raw);
    assert.ok(!x.s.upsertRecord(ty, A, MK[ty]({ studentId: 'new' })).ok); assert.ok(!x.s.upsertMany(ty, A, [MK[ty]({ studentId: 'new' })]).ok); assert.ok(!x.s.deleteRecord(ty, A, 'dup_1').ok);
    assert.strictEqual(x.st.d[k], raw, 'لم يُكتب شيء فوق البيانات التالفة');
  });
});
t('saveCollection يرفض recordId مكرراً في القائمة الممرَّرة', function () {
  var s = fresh().s, a = att({ recordId: 'same', classId: A }), b = att({ recordId: 'same', classId: A, studentId: S2 });
  assert.strictEqual(s.saveCollection('attendance', A, [a, b]).status, 'invalid-records');
  assert.strictEqual(s.readCollection('attendance', A).status, 'empty');
});
t('recordId بأسماء خاصة (__proto__ / constructor) يُحفظ ويُقرأ وتكراره يُكتشف', function () {
  var s = fresh().s, st2;
  assert.ok(s.upsertRecord('attendance', A, att({ recordId: '__proto__' })).ok);
  assert.ok(s.upsertRecord('attendance', A, att({ recordId: 'constructor', studentId: S2 })).ok);
  assert.strictEqual(s.readCollection('attendance', A).records.length, 2);
  var a = att({ recordId: '__proto__', classId: A }), b = att({ recordId: '__proto__', classId: A, studentId: S2 });
  assert.strictEqual(s.saveCollection('attendance', A, [a, b]).status, 'invalid-records');
});

// ---------- 9) منع التكرار بالمفتاح الطبيعي
t('الحضور: (studentId,date) فريد → duplicate مع existingRecordId ولا تغيير', function () {
  var x = fresh(), a = x.s.upsertRecord('attendance', A, att()), before = x.st.d[keyOf('attendance', A)], r;
  r = x.s.upsertRecord('attendance', A, att({ status: 'absent' }));
  assert.ok(!r.ok && r.status === 'duplicate' && r.existingRecordId === a.record.recordId);
  assert.strictEqual(x.st.d[keyOf('attendance', A)], before);
  assert.ok(x.s.upsertRecord('attendance', A, att({ date: '2026-10-22' })).ok, 'تاريخ آخر');
  assert.ok(x.s.upsertRecord('attendance', A, att({ studentId: S2 })).ok, 'طالب آخر');
  assert.strictEqual(x.s.readCollection('attendance', A).records.length, 3);
});
t('الحضور: التعديل بنفس recordId لا يُعدّ تكراراً', function () {
  var s = fresh().s, a = s.upsertRecord('attendance', A, att()), u = JSON.parse(JSON.stringify(a.record));
  u.status = 'late'; assert.ok(s.upsertRecord('attendance', A, u).ok);
  assert.strictEqual(s.readCollection('attendance', A).records[0].status, 'late');
});
t('الحضور: حذف السجل ثم إنشاء جديد لنفس الزوج مسموح (بمعرّف جديد)', function () {
  var s = fresh().s, a = s.upsertRecord('attendance', A, att()), id = a.record.recordId;
  assert.ok(s.deleteRecord('attendance', A, id).ok);
  var b = s.upsertRecord('attendance', A, att()); assert.ok(b.ok && b.created && b.record.recordId !== id);
});
t('تكرار طبيعي في بيانات مخزّنة (تلف/تلاعب): قراءة محجوبة + نسخة .backup، لا مسح', function () {
  var x = fresh(), k = keyOf('attendance', A), a = att({ recordId: 'a1', classId: A }), b = att({ recordId: 'a2', classId: A, status: 'absent' }), raw;
  raw = JSON.stringify({ schemaVersion: 1, classId: A, records: [a, b] }); x.st.d[k] = raw;
  var r = x.s.readCollection('attendance', A);
  assert.ok(!r.ok && r.status === 'corrupt' && r.blocked && r.backedUp, 'att');
  assert.strictEqual(x.st.d[k], raw); assert.strictEqual(x.st.d[k + '.backup'], raw);
  assert.ok(!x.s.upsertRecord('attendance', A, att({ studentId: 'zz' })).ok);
  var k2 = keyOf('grades', A), g1 = grd({ recordId: 'g1', classId: A }), g2 = grd({ recordId: 'g2', classId: A, subject: 'رياضيّات' });
  raw = JSON.stringify({ schemaVersion: 1, classId: A, records: [g1, g2] }); x.st.d[k2] = raw;
  r = x.s.readCollection('grades', A); assert.ok(!r.ok && r.status === 'corrupt' && r.blocked, 'grd'); assert.strictEqual(x.st.d[k2], raw);
});
t('الدرجات: التفرّد المركّب مع توحيد النص العربي (همزات/تشكيل/مسافات)', function () {
  var x = fresh(), a = x.s.upsertRecord('grades', A, grd({ subject: 'أحياء', title: 'اختبار  قصير' })), r;
  r = x.s.upsertRecord('grades', A, grd({ subject: 'احياء', title: 'اختبار قصير' }));
  assert.ok(!r.ok && r.status === 'duplicate' && r.existingRecordId === a.record.recordId, 'همزة + مسافة');
  assert.strictEqual(x.s.upsertRecord('grades', A, grd({ subject: 'أَحْيَاء', title: 'اختبار قصير' })).status, 'duplicate', 'تشكيل');
  assert.strictEqual(x.s.upsertRecord('grades', A, grd({ subject: 'أحياء', title: 'ٱختبار قصير' })).status, 'duplicate', 'ألف وصل');
  assert.strictEqual(x.s.upsertRecord('grades', A, grd({ subject: ' أحياء ', title: 'اختبار قصير', score: 1 })).status, 'duplicate', 'تقليم');
  assert.ok(x.s.upsertRecord('grades', A, grd({ subject: 'أحياء', title: 'اختبار قصير', date: '2026-10-22' })).ok, 'تاريخ آخر');
  assert.ok(x.s.upsertRecord('grades', A, grd({ subject: 'أحياء', title: 'اختبار قصير', studentId: S2 })).ok, 'طالب آخر');
  assert.ok(x.s.upsertRecord('grades', A, grd({ subject: 'أحياء', title: 'واجب' })).ok, 'عنوان آخر');
  assert.ok(x.s.upsertRecord('grades', A, grd({ subject: 'كيمياء', title: 'اختبار قصير' })).ok, 'مادة أخرى');
  assert.strictEqual(x.s.readCollection('grades', A).records.length, 5);
});
t('الدرجات: تعديل subject/title/date إلى تركيبة موجودة لسجل آخر → duplicate ولا تغيير', function () {
  var x = fresh(), a = x.s.upsertRecord('grades', A, grd({ title: 'أ' })), b = x.s.upsertRecord('grades', A, grd({ title: 'ب' })), before = x.st.d[keyOf('grades', A)], u;
  u = JSON.parse(JSON.stringify(b.record)); u.title = 'أ';
  var r = x.s.upsertRecord('grades', A, u);
  assert.ok(!r.ok && r.status === 'duplicate' && r.existingRecordId === a.record.recordId);
  assert.strictEqual(x.st.d[keyOf('grades', A)], before);
});

// ---------- 10) العزل بين الصفوف
t('عزل: سجلات صفين لا تتداخل (كل نوع، مفتاح مستقل، نفس studentId والتاريخ مسموحان)', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var x = fresh(), a = x.s.upsertRecord(ty, A, MK[ty]({ note: 'AAA' })), rawA, b;
    rawA = x.st.d[keyOf(ty, A)];
    b = x.s.upsertRecord(ty, B, MK[ty]({ note: 'BBB' }));
    assert.ok(b.ok && b.created, 'نفس الطالب/التاريخ في صف آخر ليس تكراراً: ' + ty);
    assert.strictEqual(x.st.d[keyOf(ty, A)], rawA, 'صف A لم يُمسّ');
    assert.deepStrictEqual(Object.keys(x.st.d).sort(), [keyOf(ty, A), keyOf(ty, B)].sort());
    assert.strictEqual(x.s.readCollection(ty, A).records[0].note, 'AAA'); assert.strictEqual(x.s.readCollection(ty, B).records[0].note, 'BBB');
    assert.strictEqual(x.s.readCollection(ty, A).records[0].classId, A); assert.strictEqual(x.s.readCollection(ty, B).records[0].classId, B);
    // استخدام recordId لصف A داخل صف B: يُنشأ سجل جديد في B فقط، ولا يعدّل A
    var u = JSON.parse(JSON.stringify(a.record)); u.classId = undefined; delete u.classId; u.note = 'X'; u.studentId = 'other-student'; u.date = '2025-01-01'; u.subject = u.subject; 
    var r = x.s.upsertRecord(ty, B, u); assert.ok(r.ok && r.created, 'recordId الصف A في صف B = سجل جديد في B');
    assert.strictEqual(x.st.d[keyOf(ty, A)], rawA, 'صف A ما زال كما هو');
    assert.strictEqual(x.s.readCollection(ty, A).records.length, 1); assert.strictEqual(x.s.readCollection(ty, B).records.length, 2);
    // حذف في B لا يمس A
    assert.ok(x.s.deleteRecord(ty, B, b.record.recordId).ok); assert.strictEqual(x.st.d[keyOf(ty, A)], rawA);
    assert.strictEqual(x.s.deleteRecord(ty, B, a.record.recordId).ok, true, 'سجل B بنفس المعرّف حُذف');
    assert.strictEqual(x.st.d[keyOf(ty, A)], rawA);
  });
});
t('عزل: الأنواع الثلاثة لنفس الصف لا تتداخل مع بعضها ولا مع الأنواع القديمة', function () {
  var x = fresh(); x.s.upsertRecord('exams', A, { title: 'x' });
  ['attendance', 'grades', 'payments'].forEach(function (ty) { x.s.upsertRecord(ty, A, MK[ty]()); });
  assert.deepStrictEqual(Object.keys(x.st.d).sort(), ['exams', 'attendance', 'grades', 'payments'].map(function (ty) { return keyOf(ty, A); }).sort());
  assert.strictEqual(x.s.readCollection('exams', A).records.length, 1);
  assert.strictEqual(x.s.readCollection('attendance', A).records.length, 1);
});
t('classId داخل سجل مخزّن لا يطابق الصف → تالف محجوب (لا يظهر في الصف الآخر)', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var x = fresh(), rec = MK[ty](), k = keyOf(ty, A), raw;
    rec.recordId = 'r1'; rec.classId = B; rec.note = 'BBB';
    raw = JSON.stringify({ schemaVersion: 1, classId: A, records: [rec] }); x.st.d[k] = raw;
    var r = x.s.readCollection(ty, A);
    assert.ok(!r.ok && r.status === 'corrupt' && r.blocked && r.records.length === 0, ty);
    assert.strictEqual(x.st.d[k], raw); assert.ok(x.st.d[k + '.backup'] === raw);
    assert.strictEqual(x.s.readCollection(ty, B).status, 'empty', 'لا يظهر في B أيضاً');
  });
});
t('classId الغلاف لا يطابق مفتاح الصف → class-mismatch محجوب', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var x = fresh(), k = keyOf(ty, A), raw = JSON.stringify({ schemaVersion: 1, classId: B, records: [] });
    x.st.d[k] = raw;
    var r = x.s.readCollection(ty, A);
    assert.ok(!r.ok && r.status === 'class-mismatch' && r.blocked, ty); assert.strictEqual(x.st.d[k], raw);
    assert.ok(!x.s.upsertRecord(ty, A, MK[ty]()).ok); assert.strictEqual(x.st.d[k], raw);
  });
});

// ---------- 11) بيانات فاسدة و schemaVersion
t('بيانات فاسدة (JSON مكسور/ليس كائناً/records ليست قائمة/سجل ليس كائناً): لا تُعرض فارغة ولا تُكتب فوقها', function () {
  var bads = ['{broken', 'null', '[]', '"text"', '123', '{}', JSON.stringify({ schemaVersion: 1, classId: A, records: {} }), JSON.stringify({ schemaVersion: 1, classId: A, records: [5] }), JSON.stringify({ schemaVersion: '1', classId: A, records: [] }), JSON.stringify({ schemaVersion: 1, classId: A, records: [null] }), JSON.stringify({ schemaVersion: 1, classId: A })];
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    bads.forEach(function (raw) {
      var x = fresh(), k = keyOf(ty, A); x.st.d[k] = raw;
      var r = x.s.readCollection(ty, A);
      assert.ok(!r.ok && r.blocked && r.status !== 'empty', ty + ' ' + raw);
      assert.deepStrictEqual(r.records, []); assert.strictEqual(x.st.d[k], raw); assert.strictEqual(x.st.d[k + '.backup'], raw);
      assert.ok(!x.s.upsertRecord(ty, A, MK[ty]()).ok); assert.ok(!x.s.upsertMany(ty, A, [MK[ty]()]).ok); assert.ok(!x.s.saveCollection(ty, A, []).ok);
      assert.strictEqual(x.st.d[k], raw, 'لم تُطمس: ' + ty + ' ' + raw);
    });
  });
});
t('سجل مخزّن غير صالح نوعياً (status/amount/score/date/studentId) → تالف محجوب لا يظهر كفارغ', function () {
  var cases = [['attendance', { status: 'gone' }], ['attendance', { date: '2026-02-30' }], ['attendance', { studentId: '' }], ['grades', { score: 11 }], ['grades', { score: '7' }], ['grades', { maxScore: 0 }], ['payments', { amount: -5 }], ['payments', { amount: 2.5 }], ['payments', { purpose: '' }]];
  cases.forEach(function (c) {
    var x = fresh(), rec = MK[c[0]](), k = keyOf(c[0], A), raw, kk;
    rec.recordId = 'r1'; rec.classId = A; for (kk in c[1]) rec[kk] = c[1][kk];
    raw = JSON.stringify({ schemaVersion: 1, classId: A, records: [rec] }); x.st.d[k] = raw;
    var r = x.s.readCollection(c[0], A);
    assert.ok(!r.ok && r.status === 'corrupt' && r.blocked, c[0] + JSON.stringify(c[1])); assert.strictEqual(x.st.d[k], raw);
  });
});
t('schemaVersion أحدث / أقل من 1: محجوب بلا تعديل ولا ترقية', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var x = fresh(), k = keyOf(ty, A), raw = JSON.stringify({ schemaVersion: 2, classId: A, records: [{ future: true }] });
    x.st.d[k] = raw; var r = x.s.readCollection(ty, A);
    assert.ok(!r.ok && r.status === 'newer' && r.blocked, ty); assert.strictEqual(x.st.d[k], raw);
    assert.ok(!x.s.upsertRecord(ty, A, MK[ty]()).ok); assert.strictEqual(x.st.d[k], raw);
    raw = JSON.stringify({ schemaVersion: 0, classId: A, records: [] }); x.st.d[k] = raw; assert.strictEqual(x.s.readCollection(ty, A).status, 'unsupported');
    assert.strictEqual(x.st.d[k], raw);
  });
});
t('القراءة لا تكتب شيئاً (مجموعة جديدة وغير فارغة)', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var x = fresh(); x.s.readCollection(ty, A); assert.strictEqual(x.st.length, 0); assert.strictEqual(x.st.sets, 0);
    x.s.upsertRecord(ty, A, MK[ty]()); var sets = x.st.sets, snap = JSON.stringify(x.st.d);
    x.s.readCollection(ty, A); x.s.getRecord(ty, A, 'nope'); assert.strictEqual(x.st.sets, sets); assert.strictEqual(JSON.stringify(x.st.d), snap);
  });
});
t('النسخ الاحتياطي لا يُستبدل: نسختان مختلفتان تُحفظان (نمط المتجر الحالي) للنوع الجديد', function () {
  var x = fresh(), k = keyOf('payments', A);
  x.st.d[k] = 'bad1'; x.s.readCollection('payments', A); x.st.d[k] = 'bad2'; x.s.readCollection('payments', A); x.s.readCollection('payments', A);
  assert.strictEqual(x.st.d[k + '.backup'], 'bad1');
  var others = Object.keys(x.st.d).filter(function (z) { return z.indexOf(k + '.backup.') === 0; });
  assert.strictEqual(others.length, 1); assert.strictEqual(x.st.d[others[0]], 'bad2');
});

// ---------- 12) فشل القراءة والكتابة وتعطل localStorage
t('امتلاء التخزين: write-failed ولا رسالة نجاح والمخزَّن السابق سليم (كل نوع، مفرد ودفعي)', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var st = fake(), s = S.create({ storage: st }), a = s.upsertRecord(ty, A, MK[ty]()), before = st.d[keyOf(ty, A)], realSet = st.setItem;
    st.setItem = function () { throw new Error('QuotaExceededError'); };
    var r = s.upsertRecord(ty, A, MK[ty]({ studentId: S2 }));
    assert.ok(!r.ok && r.status === 'write-failed' && !r.record && !r.created, ty);
    var m = s.upsertMany(ty, A, [MK[ty]({ studentId: S2 }), MK[ty]({ studentId: 'stu-3' })]);
    assert.ok(!m.ok && m.status === 'write-failed' && !m.results, ty);
    var d = s.deleteRecord(ty, A, a.record.recordId); assert.ok(!d.ok && d.status === 'write-failed', ty);
    assert.strictEqual(st.d[keyOf(ty, A)], before, ty); st.setItem = realSet;
    assert.strictEqual(s.readCollection(ty, A).records.length, 1);
  });
});
t('فشل التحقق بعد الكتابة: verify-failed وتُعاد القيمة السابقة (فردي ودفعي)', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var st = fake(), s = S.create({ storage: st }), k = keyOf(ty, A), before, realSet;
    s.upsertRecord(ty, A, MK[ty]()); before = st.d[k]; realSet = st.setItem;
    st.setItem = function (kk, v) { if (kk === k) st.d[kk] = 'garbled'; else realSet(kk, v); };
    var r = s.upsertRecord(ty, A, MK[ty]({ studentId: S2 })); assert.ok(!r.ok && r.status === 'verify-failed', ty);
    st.d[k] = before; var m = s.upsertMany(ty, A, [MK[ty]({ studentId: S2 })]); assert.ok(!m.ok && m.status === 'verify-failed', ty);
  });
});
t('localStorage معطّل (يرمي دائماً): لا ادعاء حفظ دائم، persistent=false مع تحذير، ولا فقدان للدفعة', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var s = S.create({ storage: fake({ blocked: true }) }), r = s.upsertRecord(ty, A, MK[ty]());
    assert.ok(r.ok && r.persistent === false && /ليس بشكل دائم/.test(r.warning), ty);
    assert.strictEqual(s.isPersistent(), false);
    var m = s.upsertMany(ty, A, [MK[ty]({ studentId: S2 })]); assert.ok(m.ok && m.persistent === false && /ليس بشكل دائم/.test(m.warning), ty);
    var c = s.readCollection(ty, A); assert.strictEqual(c.records.length, 2); assert.ok(c.warning && c.persistent === false);
    assert.strictEqual(s.upsertRecord(ty, A, MK[ty]()).status === 'duplicate' || ty === 'payments', true, 'التفرّد يعمل في وضع الذاكرة');
  });
});
t('فشل القراءة فقط (getItem يرمي): تحذير صريح بأن التخزين الدائم غير متاح، لا ادعاء حفظ دائم', function () {
  var s = S.create({ storage: fake({ failRead: true }) }), r = s.readCollection('attendance', A);
  assert.ok(r.ok && r.persistent === false && /غير متاح/.test(r.warning));
  var w = s.upsertRecord('attendance', A, att()); assert.ok(w.ok && w.persistent === false && /ليس بشكل دائم/.test(w.warning));
});
t('storage=null (لا localStorage): وضع ذاكرة مع تحذير', function () {
  var s = S.create({ storage: null }), r = s.upsertRecord('grades', A, grd());
  assert.ok(r.ok && r.persistent === false && r.warning); assert.strictEqual(s.readCollection('grades', A).records.length, 1);
});

// ---------- 13) upsertMany
t('upsertMany: كتابة واحدة ذرّية لدفعة كاملة (إنشاء + تعديل) وتحفظ المعرّفات', function () {
  var st = fake(), s = S.create({ storage: st }), first = s.upsertRecord('attendance', A, att({ studentId: 's0' })), batch = [], i, r, base;
  for (i = 1; i <= 35; i++) batch.push(att({ studentId: 's' + i, status: i % 7 === 0 ? 'absent' : 'present' }));
  var e = JSON.parse(JSON.stringify(first.record)); e.status = 'late'; batch.push(e);
  base = st.sets; r = s.upsertMany('attendance', A, batch);
  assert.ok(r.ok && r.status === 'saved' && r.count === 36, JSON.stringify(r.status));
  assert.strictEqual(st.sets - base, 1, 'كتابة واحدة فقط');
  assert.strictEqual(r.results.filter(function (x) { return x.created; }).length, 35);
  assert.strictEqual(r.results[35].recordId, first.record.recordId); assert.strictEqual(r.results[35].created, false);
  var all = s.readCollection('attendance', A).records;
  assert.strictEqual(all.length, 36); assert.strictEqual(all.filter(function (x) { return x.recordId === first.record.recordId; }).length, 1);
  assert.strictEqual(all.filter(function (x) { return x.recordId === first.record.recordId; })[0].status, 'late');
  var ids = {}; all.forEach(function (x) { assert.ok(!ids[x.recordId] && x.classId === A); ids[x.recordId] = 1; });
});
t('upsertMany: سجل واحد غير صالح يُفشل الدفعة كلها ولا يُحفظ شيء (مع رقم السجل)', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var st = fake(), s = S.create({ storage: st }); s.upsertRecord(ty, A, MK[ty]({ studentId: 'keep' }));
    var before = st.d[keyOf(ty, A)], bad = MK[ty]({ studentId: 'b3' });
    if (ty === 'attendance') bad.status = 'zzz'; else if (ty === 'grades') bad.score = 99; else bad.amount = -3;
    var r = s.upsertMany(ty, A, [MK[ty]({ studentId: 'b1' }), MK[ty]({ studentId: 'b2' }), bad, MK[ty]({ studentId: 'b4' })]);
    assert.ok(!r.ok && r.status === 'invalid-records' && r.index === 2 && /3/.test(r.error), ty);
    assert.strictEqual(st.d[keyOf(ty, A)], before, ty); assert.strictEqual(s.readCollection(ty, A).records.length, 1);
  });
});
t('upsertMany: تكرار طبيعي (مع القائم أو داخل الدفعة) أو recordId مكرر → رفض كامل', function () {
  var st = fake(), s = S.create({ storage: st }), a = s.upsertRecord('attendance', A, att({ studentId: 's1' })), before = st.d[keyOf('attendance', A)], r;
  r = s.upsertMany('attendance', A, [att({ studentId: 's2' }), att({ studentId: 's1' })]);
  assert.ok(!r.ok && r.status === 'duplicate' && r.existingRecordId === a.record.recordId && r.index === 1);
  r = s.upsertMany('attendance', A, [att({ studentId: 's5' }), att({ studentId: 's5' })]);
  assert.ok(!r.ok && r.status === 'duplicate' && r.index === 1, 'تكرار داخل الدفعة نفسها');
  r = s.upsertMany('attendance', A, [att({ studentId: 's6', recordId: 'same' }), att({ studentId: 's7', recordId: 'same' })]);
  assert.ok(!r.ok && r.status === 'invalid-records' && /مكرر/.test(r.error), 'recordId مكرر داخل الدفعة');
  r = s.upsertMany('grades', A, [grd({ subject: 'أحياء' }), grd({ subject: 'احياء' })]); assert.ok(!r.ok && r.status === 'duplicate', 'درجات: توحيد عربي داخل الدفعة');
  assert.strictEqual(st.d[keyOf('attendance', A)], before); assert.strictEqual(st.d[keyOf('grades', A)], undefined);
});
t('upsertMany: دفعة فارغة/ليست قائمة/أكبر من الحد → رفض ولا نجاح كاذب', function () {
  var st = fake(), s = S.create({ storage: st }), big = [], i;
  [[], null, undefined, {}, 'x', 5].forEach(function (b) { var r = s.upsertMany('attendance', A, b); assert.ok(!r.ok && r.status === 'invalid-records', String(b)); });
  for (i = 0; i < 501; i++) big.push(att({ studentId: 's' + i }));
  assert.strictEqual(s.upsertMany('attendance', A, big).status, 'invalid-records');
  assert.strictEqual(s.upsertMany('attendance', A, [null]).status, 'invalid-records');
  assert.strictEqual(st.length, 0); assert.strictEqual(st.sets, 0);
});
t('upsertMany: classId مخالف في أي سجل يرفض الدفعة؛ وclassId المطابق يُقبل', function () {
  var st = fake(), s = S.create({ storage: st });
  var r = s.upsertMany('attendance', A, [att({ studentId: 's1' }), att({ studentId: 's2', classId: B })]);
  assert.ok(!r.ok && r.status === 'class-mismatch' && r.index === 1); assert.strictEqual(st.length, 0);
  assert.ok(s.upsertMany('attendance', A, [att({ studentId: 's1', classId: A })]).ok);
});
t('upsertMany: لا يكتب فوق مجموعة تالفة ولا يخفيها', function () {
  var x = fresh(), k = keyOf('attendance', A); x.st.d[k] = '{x';
  var r = x.s.upsertMany('attendance', A, [att()]); assert.ok(!r.ok && r.blocked && r.status === 'corrupt'); assert.strictEqual(x.st.d[k], '{x');
});
t('upsertMany: لا يؤثر في صف آخر', function () {
  var x = fresh(); x.s.upsertMany('attendance', B, [att({ studentId: 's1' })]); var rawB = x.st.d[keyOf('attendance', B)];
  x.s.upsertMany('attendance', A, [att({ studentId: 's1' }), att({ studentId: 's2' })]);
  assert.strictEqual(x.st.d[keyOf('attendance', B)], rawB); assert.strictEqual(x.s.readCollection('attendance', B).records.length, 1);
});
t('حقول غير معروفة/مشتقة تُرفض عند الكتابة فقط، وتحذف بيانات مخزّنة بها لا تُمحى', function () {
  var x = fresh(), o = att({ present: true }), k = keyOf('attendance', A);
  assert.strictEqual(x.s.upsertRecord('attendance', A, o).status, 'invalid-records');
  assert.strictEqual(x.s.upsertMany('attendance', A, [o]).status, 'invalid-records');
  // سجل مخزّن يحمل حقلاً زائداً (مثلاً من نسخة أحدث ضمن نفس schemaVersion): يُقرأ ولا يُمحى
  var rec = att({ recordId: 'a1', classId: A, extra: 'x' }), raw = JSON.stringify({ schemaVersion: 1, classId: A, records: [rec] });
  x.st.d[k] = raw; var r = x.s.readCollection('attendance', A); assert.ok(r.ok && r.records[0].extra === 'x'); assert.strictEqual(x.st.d[k], raw);
});

// ---------- 14) الحذف والاسترجاع
t('deleteRecord للأنواع الجديدة: يحذف الهدف فقط، not-found بلا كتابة', function () {
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var st = fake(), s = S.create({ storage: st }), a = s.upsertRecord(ty, A, MK[ty]({ studentId: 'x1' })), b = s.upsertRecord(ty, A, MK[ty]({ studentId: 'x2' }));
    var sets = st.sets, nf = s.deleteRecord(ty, A, 'nope'); assert.ok(!nf.ok && nf.status === 'not-found'); assert.strictEqual(st.sets, sets);
    assert.ok(s.deleteRecord(ty, A, a.record.recordId).ok);
    var left = s.readCollection(ty, A).records; assert.strictEqual(left.length, 1); assert.strictEqual(left[0].recordId, b.record.recordId);
    assert.strictEqual(s.getRecord(ty, A, a.record.recordId).status, 'not-found'); assert.ok(s.getRecord(ty, A, b.record.recordId).ok);
  });
});

// ---------- 15) مفاتيح الصفوف والطلاب
t('مفاتيح الصفوف والطلاب لا تُمسّ بأي عملية على الأنواع الجديدة', function () {
  var st = fake(), s = S.create({ storage: st }); st.d['marsa.roster'] = 'R'; st.d['marsa.classes'] = 'C'; st.d['marsa.roster.cls_a'] = 'R2'; st.d['marsa.schedule.days.cls_a'] = 'D';
  var snap = {}; Object.keys(st.d).forEach(function (k) { snap[k] = st.d[k]; });
  ['attendance', 'grades', 'payments'].forEach(function (ty) {
    var a = s.upsertRecord(ty, A, MK[ty]()); s.upsertMany(ty, A, [MK[ty]({ studentId: 'm1' })]); s.deleteRecord(ty, A, a.record.recordId); s.readCollection(ty, B);
  });
  Object.keys(snap).forEach(function (k) { assert.strictEqual(st.d[k], snap[k], k); });
  assert.strictEqual(st.removes, 0, 'لا removeItem');
});

// ---------- 16) مثال الواجهة: الطالب الأرشيفي/المجهول لا يُحذف من المتجر
t('المتجر لا يعرف قائمة الطلاب: سجل بـstudentId غير موجود في الصف يُحفظ ويُقرأ كما هو (التحقق من الانتماء في الواجهة)', function () {
  var s = fresh().s, r = s.upsertRecord('attendance', A, att({ studentId: 'stu-archived-or-unknown' }));
  assert.ok(r.ok); assert.strictEqual(s.readCollection('attendance', A).records[0].studentId, 'stu-archived-or-unknown');
});

// ---------- 17) واجهة الوحدة
t('الواجهة العامة: دوال وثوابت 4.02 مصدَّرة', function () {
  var s = S.create({ storage: fake() });
  assert.strictEqual(typeof s.upsertMany, 'function');
  assert.deepStrictEqual(S.ATTENDANCE_STATUSES, ['present', 'absent', 'late', 'excused']); assert.deepStrictEqual(s.ATTENDANCE_STATUSES, S.ATTENDANCE_STATUSES);
  assert.strictEqual(S.foldText('  أَحْيَاءٌ  '), 'احياء'); assert.strictEqual(s.uniqueKey('payments', pay()), null);
  assert.ok(s.uniqueKey('attendance', att()).indexOf(S1) === 0);
  assert.strictEqual(S.LIMITS.batchMax, 500);
});

console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
