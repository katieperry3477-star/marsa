// اختبار واجهة المرحلة 03.6 (عرض الطالب للقراءة فقط: التحاضير وما أُخذ سابقاً) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-student-views.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة بساعة مزيّفة ثابتة البداية. لقطات الشاشة تُحفظ في SHOTS_DIR إن عُرّف.
var pw = require('playwright'), path = require('path'), fs = require('fs');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var SHOTS = process.env.SHOTS_DIR || '';
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
// 2026-10-22 09:00 بتوقيت بغداد (UTC+3): اليوم 2026-10-22، باجر 2026-10-23
var NOW = '2026-10-22T06:00:00Z', TODAY = '2026-10-22', TOMORROW = '2026-10-23';
var DEMO = 'cls_demo_001', PKEY = 'marsa.academic.preparations.' + DEMO, LKEY = 'marsa.academic.dailyLessons.' + DEMO;

async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(opts.clock || NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function unlock(page) {
  await page.click('.nav button:has-text("الإعدادات")');
  await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
  await page.click('button:has-text("تفعيل")');
}
async function toRep(page) { await unlock(page); await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function nav(page, label) { await page.click('.nav button:has-text("' + label + '")'); await page.waitForSelector('#page-title'); }
async function store(page, key) { return page.evaluate(function (k) { var r = localStorage.getItem(k); return r === null ? null : JSON.parse(r); }, key); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function keys(page) { return page.evaluate(function () { var o = []; for (var i = 0; i < localStorage.length; i++) o.push(localStorage.key(i)); return o.sort(); }); }
async function seed(page, key, classId, records) { await page.evaluate(function (a) { localStorage.setItem(a.key, JSON.stringify({ schemaVersion: 1, classId: a.classId, records: a.records })); }, { key: key, classId: classId, records: records }); }
async function titles(page) { return page.$$eval('#v-page .st-card h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function group(page, g) { return page.$$eval('.pgroup[data-group="' + g + '"] .st-card h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function pageText(page) { return page.textContent('#v-page'); }
async function shot(page, name) { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); }
function prep(id, o) { return Object.assign({ recordId: id, classId: DEMO, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
function lesson(id, o) { return Object.assign({ recordId: id, classId: DEMO, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
async function fillPrepForm(page, o) {
  await page.click('button:has-text("إضافة تحضير")');
  await page.fill('#pf-subject', o.subject); await page.fill('#pf-title', o.title); await page.fill('#pf-date', o.date); await page.fill('#pf-content', o.content);
  if (o.pages !== undefined || o.homework !== undefined) {
    if (!(await page.$eval('details.opt', function (d) { return d.open; }))) await page.click('details.opt summary');
    if (o.pages !== undefined) await page.fill('#pf-pages', o.pages);
    if (o.homework !== undefined) await page.fill('#pf-homework', o.homework);
  }
  await page.click('button:has-text("حفظ التحضير")'); await page.waitForSelector('.lform', { state: 'hidden' });
}
async function fillLessonForm(page, o) {
  await page.click('button:has-text("إضافة سجل درس")');
  await page.fill('#lf-subject', o.subject); await page.fill('#lf-title', o.title); await page.fill('#lf-date', o.date);
  if (o.summary !== undefined || o.pages !== undefined || o.homework !== undefined) {
    if (!(await page.$eval('details.opt', function (d) { return d.open; }))) await page.click('details.opt summary');
    if (o.summary !== undefined) await page.fill('#lf-summary', o.summary);
    if (o.pages !== undefined) await page.fill('#lf-pages', o.pages);
    if (o.homework !== undefined) await page.fill('#lf-homework', o.homework);
  }
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lform', { state: 'hidden' });
}

(async function main() {
  var browser = await pw.chromium.launch();
  var c, page, t, k0, k1, before, i;

  // ===== 1) حالات الفراغ (بلا أي بيانات) =====
  c = await open(browser, { label: 'empty' }); page = c.page;
  await nav(page, 'التحاضير');
  t = await pageText(page);
  check('Student prep (no data): clear empty state telling how it fills', /لا توجد تحاضير مضافة لهذا الصف بعد/.test(t) && /ممثل الصف/.test(t));
  check('Student prep (no data): no fake data, no cards, no search box shown', (await titles(page)).length === 0 && (await page.$eval('.st-search', function (e) { return e.hidden || e.offsetParent === null; })));
  check('Student prep: read-only note present', /عرض للقراءة فقط/.test(t));
  check('Student prep: no placeholder «يُفعّل في مرحلة لاحقة» / «هذا القسم جاهز للربط»', !/يُفعّل في مرحلة لاحقة|هذا القسم جاهز للربط/.test(t));
  check('Student prep (empty) 390px: no horizontal scroll', !(await overflow(page)));
  await shot(page, 'prep-empty-390');
  await nav(page, 'الأرشيف');
  t = await pageText(page);
  check('Student archive (no data): clear empty state (03.9 wording)', /لا توجد سجلات دراسية لهذا الصف بعد/.test(t) && /ما أُخذ اليوم/.test(t));
  check('Student archive (empty): no horizontal scroll', !(await overflow(page)));
  await shot(page, 'archive-empty-390');
  k0 = await keys(page);
  check('Viewing empty student pages writes no academic keys', k0.filter(function (x) { return x.indexOf('marsa.academic.') === 0; }).length === 0, k0.join(','));
  await c.ctx.close();

  // ===== 2) ممثل ينشئ → الطالب يرى (التدفق الحقيقي) =====
  c = await open(browser, { label: 'flow' }); page = c.page;
  await toRep(page);
  await nav(page, 'التحاضير');
  await fillPrepForm(page, { subject: 'مادة أ', title: 'تحضير اليوم', date: TODAY, content: 'نقطة 1\nنقطة 2', pages: 'ص 10-12', homework: 'حل التمرين 3' });
  await fillPrepForm(page, { subject: 'مادة ب', title: 'تحضير باجر', date: TOMORROW, content: 'محتوى باجر فقط' });
  await fillPrepForm(page, { subject: 'مادة ج', title: 'تحضير بعيد', date: '2026-11-05', content: 'محتوى بعيد' });
  await fillPrepForm(page, { subject: 'مادة د', title: 'تحضير فات موعده', date: '2026-10-15', content: 'قديم' });
  await nav(page, 'ما أُخذ اليوم');
  await fillLessonForm(page, { subject: 'مادة أ', title: 'درس اليوم المأخوذ', date: TODAY, summary: 'ملخص الدرس', pages: 'ص 5', homework: 'واجب الدرس' });
  await fillLessonForm(page, { subject: 'مادة ب', title: 'درس أقدم بلا تفاصيل', date: '2026-10-19' });
  await toStudent(page);
  await nav(page, 'التحاضير');
  check('Rep-created preps appear in student view, grouped اليوم/باجر/أخرى',
    (await group(page, 'today')).join('|') === 'تحضير اليوم' && (await group(page, 'tomorrow')).join('|') === 'تحضير باجر' && (await group(page, 'other')).join('|') === 'تحضير بعيد|تحضير فات موعده',
    [await group(page, 'today'), await group(page, 'tomorrow'), await group(page, 'other')].join(' / '));
  t = await pageText(page);
  check('Student prep card shows subject, topic, content, pages, homework', /مادة أ/.test(t) && /تحضير اليوم/.test(t) && /نقطة 1/.test(t) && /ص 10-12/.test(t) && /حل التمرين 3/.test(t));
  check('Group headings visible: اليوم، باجر، تحاضير أخرى', /اليوم \(1\)/.test(t) && /باجر \(1\)/.test(t) && /تحاضير أخرى \(2\)/.test(t));
  check('Past-due prep marked «مضى موعده» in the other group', /مضى موعده/.test(await page.textContent('.pgroup[data-group="other"]')));
  var tomorrowCard = await page.textContent('.pgroup[data-group="tomorrow"] .st-card');
  check('Optional empty fields (pages/homework) are hidden, not shown as labels or null/undefined', !/الصفحات|الواجب|null|undefined/.test(tomorrowCard), tomorrowCard);
  check('No null/undefined/NaN text anywhere on prep page', !/\bnull\b|undefined|NaN/.test(t));
  check('Multi-line content keeps its lines (white-space pre-wrap)', await page.$eval('.pgroup[data-group="today"] .lc-t', function (e) { return getComputedStyle(e).whiteSpace === 'pre-wrap'; }));
  await shot(page, 'prep-filled-390');
  check('Student prep (filled) 390px: no horizontal scroll', !(await overflow(page)));

  await nav(page, 'الأرشيف');
  t = await pageText(page);
  check('Rep-created lessons and the past-due prep appear in student archive, newest first (03.9)', (await titles(page)).join('|') === 'درس اليوم المأخوذ|درس أقدم بلا تفاصيل|تحضير فات موعده', (await titles(page)).join('|'));
  check('Archive card shows subject, topic, explanation date, summary, pages, homework', /مادة أ/.test(t) && /ملخص الدرس/.test(t) && /ص 5/.test(t) && /واجب الدرس/.test(t) && /الخميس/.test(t) && /2026/.test(t), t.slice(0, 300));
  check('Archive does NOT contain preps (future prep not shown as taught)', !/تحضير اليوم|تحضير باجر|تحضير بعيد|نقطة 1/.test(t));
  var oldCard = (await page.$$eval('.st-card', function (l) { return l.map(function (x) { return x.textContent; }); }))[1];
  check('Archive card with no optional fields hides their labels', !/الملخص|الصفحات|الواجب|null|undefined/.test(oldCard), oldCard);
  check('«اليوم» tag on today lesson only', (await page.$$eval('.st-card .tag.on', function (l) { return l.length; })) === 1);
  await shot(page, 'archive-filled-390');
  check('Student archive 390px: no horizontal scroll', !(await overflow(page)));

  // ===== 3) القراءة فقط =====
  for (var vi = 0; vi < 2; vi++) {
    await nav(page, vi ? 'الأرشيف' : 'التحاضير');
    var ctrls = await page.$$eval('#v-page button:not(.back), #v-page form, #v-page textarea, #v-page select, #v-page input, #v-page [contenteditable], #v-page a[href]', function (l) {
      return l.map(function (x) { return x.tagName.toLowerCase() + ':' + (x.type || '') + ':' + x.textContent.trim().slice(0, 20); });
    });
    if (vi) check('Student archive (03.9): controls are only search + filter toggle/kind chips/period select/date inputs/clear; no forms, textareas, links or edit controls', ctrls.every(function (x) { return /^(input:search|input:date|select:select-one|button:button:(تصفية|الكل|الدروس|التحاضير|الامتحانات|مسح الفلاتر))/.test(x); }) && ctrls.length >= 2, ctrls.join(' | '));
    else check('Student prep: only control is the search field besides the «رجوع» nav button (no add/edit/delete buttons, forms, textareas)', ctrls.length === 1 && ctrls[0].indexOf('input:search') === 0, ctrls.join(' | '));
    check('Student ' + (vi ? 'archive' : 'prep') + ': no «تعديل/حذف/إضافة» text', !/تعديل|حذف|إضافة/.test((await pageText(page)).replace(/تعديل السجل/g, '')));
    check('Student ' + (vi ? 'archive' : 'prep') + ': no .acts or dialogs available from the page', (await page.$$eval('#v-page .acts', function (l) { return l.length; })) === 0);
  }
  before = await raw(page, PKEY) + '||' + await raw(page, LKEY);
  await page.fill('.st-search', 'مادة');
  await page.click('.st-card h3');
  await page.keyboard.press('Enter');
  check('Interacting with student UI (search, click, Enter) leaves stored study data byte-identical', (await raw(page, PKEY) + '||' + await raw(page, LKEY)) === before);
  await page.fill('.st-search', '');

  // ===== 4) البحث =====
  await nav(page, 'التحاضير');
  await page.fill('.st-search', 'باجر');
  check('Search filters student preps by topic', (await titles(page)).join('|') === 'تحضير باجر' && /النتائج: 1 من 4/.test(await pageText(page)));
  await page.fill('.st-search', 'لا يوجد شيء كهذا');
  check('Search with no hits shows a "no match" message, not the empty-data state', /لا توجد نتائج مطابقة/.test(await pageText(page)) && !/لا توجد تحاضير مضافة لهذا الصف بعد/.test(await pageText(page)));
  await page.fill('.st-search', '');

  // ===== 5) التعديل والحذف في وضع الممثل ينعكسان على الطالب (نفس المخزن) =====
  var keysBefore = (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic.') === 0; }).join(',');
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
  await nav(page, 'التحاضير');
  await page.click('.lcard:has-text("تحضير باجر") button:has-text("تعديل")');
  await page.fill('#pf-title', 'تحضير باجر (معدّل)'); await page.fill('#pf-content', 'محتوى معدّل');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  await page.click('.lcard:has-text("تحضير بعيد") button:has-text("حذف")');
  await page.click('#dlg-confirm button:has-text("حذف التحضير")'); await page.waitForSelector('#dlg-confirm', { state: 'hidden' });
  await toStudent(page); await nav(page, 'التحاضير');
  check('Edit by rep is reflected for student (same record, new title/content)', (await group(page, 'tomorrow')).join('|') === 'تحضير باجر (معدّل)' && /محتوى معدّل/.test(await pageText(page)) && !/محتوى باجر فقط/.test(await pageText(page)));
  check('Delete by rep removed it from student view', (await group(page, 'other')).join('|') === 'تحضير فات موعده');
  var keysAfter = (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic.') === 0; }).join(',');
  check('No second store was created (academic keys unchanged by edit/delete/view)', keysBefore === keysAfter && keysAfter === LKEY + ',' + PKEY, keysBefore + ' => ' + keysAfter);
  check('Only 3 prep records remain in the single source', (await store(page, PKEY)).records.length === 3);
  await c.ctx.close();

  // ===== 6) الفصل بين الصفوف + تحديث بعد تبديل الصف =====
  c = await open(browser, { label: 'classes' }); page = c.page;
  await seed(page, PKEY, DEMO, [prep('prep_a1', { subject: 'مادة الصف أ', title: 'تحضير الصف التجريبي', date: TODAY, content: 'ج أ' })]);
  await seed(page, LKEY, DEMO, [lesson('dl_a1', { subject: 'مادة الصف أ', title: 'درس الصف التجريبي', date: '2026-10-20' })]);
  await toRep(page);
  await page.click('.nav button:has-text("اللوحة")'); await page.click('.tile:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', 'الثالث المتوسط'); await page.fill('#cf-section', 'ب');
  await page.check('.cform .chk input'); await page.click('button:has-text("إضافة الصف")');
  await page.waitForFunction(function () { return !document.getElementById('dlg-class').open; });
  var otherId = await page.getAttribute('main', 'data-class-id');
  await nav(page, 'التحاضير');
  await fillPrepForm(page, { subject: 'مادة الصف ب', title: 'تحضير الصف الآخر', date: TOMORROW, content: 'ج ب' });
  await toStudent(page); await nav(page, 'التحاضير');
  check('Student sees ONLY the active (new) class preps', (await titles(page)).join('|') === 'تحضير الصف الآخر', (await titles(page)).join('|'));
  check('Student view shows the active class label in the chip', /الثالث المتوسط/.test(await page.textContent('#chip-v')));
  await nav(page, 'الأرشيف');
  check('Student archive of new class is empty (no lessons leaked from other class)', (await titles(page)).length === 0 && /لا توجد سجلات سابقة بعد/.test(await pageText(page)));
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
  await nav(page, 'التحاضير');
  await page.selectOption('#cb-sel', DEMO); await page.waitForSelector('.lcard:has-text("تحضير الصف التجريبي")');
  await toStudent(page); await nav(page, 'التحاضير');
  check('After switching class (in rep mode) student prep shows the other class only', (await titles(page)).join('|') === 'تحضير الصف التجريبي', (await titles(page)).join('|'));
  await nav(page, 'الأرشيف');
  check('Student archive after class switch shows that class lessons only', (await titles(page)).join('|') === 'درس الصف التجريبي', (await titles(page)).join('|'));
  check('Each class keeps its own key and classId', (await store(page, 'marsa.academic.preparations.' + otherId)).classId === otherId && (await store(page, PKEY)).records.length === 1);
  await c.ctx.close();

  // ===== 7) تحديث حيّ أثناء بقاء صفحة الطالب مفتوحة (تبويب آخر / عودة للتبويب) =====
  c = await open(browser, { label: 'live' }); page = c.page;
  await seed(page, PKEY, DEMO, [prep('prep_l1', { subject: 'م', title: 'أول تحضير', date: TODAY, content: 'x' })]);
  await nav(page, 'التحاضير');
  check('Live: initial student view', (await titles(page)).join('|') === 'أول تحضير');
  await page.evaluate(function (a) {
    localStorage.setItem(a.k, JSON.stringify({ schemaVersion: 1, classId: a.c, records: [{ recordId: 'prep_l1', classId: a.c, subject: 'م', title: 'أول تحضير', date: a.t, content: 'x' }, { recordId: 'prep_l2', classId: a.c, subject: 'م', title: 'تحضير مضاف من تبويب آخر', date: a.t, content: 'y', createdAt: '2026-10-22T06:00:00.000Z' }] }));
    window.dispatchEvent(new StorageEvent('storage', { key: a.k }));
  }, { k: PKEY, c: DEMO, t: TODAY });
  check('Live: storage event refreshes the student list from the same store', (await titles(page)).length === 2 && (await titles(page)).indexOf('تحضير مضاف من تبويب آخر') > -1, (await titles(page)).join('|'));
  await page.evaluate(function (a) { localStorage.setItem(a.k, JSON.stringify({ schemaVersion: 1, classId: a.c, records: [] })); }, { k: PKEY, c: DEMO });
  await page.clock.fastForward(61000);
  check('Live: 60s check picks up a change made without any event (e.g. return to tab)', (await titles(page)).length === 0 && /لا توجد تحاضير مضافة/.test(await pageText(page)));
  await c.ctx.close();

  // ===== 8) عبور منتصف الليل =====
  c = await open(browser, { label: 'midnight', clock: '2026-10-22T20:59:00Z' }); page = c.page; // 23:59 بغداد
  await seed(page, PKEY, DEMO, [prep('prep_m1', { subject: 'م', title: 'تحضير باجر الليلة', date: TOMORROW, content: 'x' })]);
  await nav(page, 'التحاضير');
  check('Midnight: before midnight it is under باجر', (await group(page, 'tomorrow')).join('|') === 'تحضير باجر الليلة');
  await page.clock.fastForward(120000);
  check('Midnight: after midnight (page left open) it moves to اليوم', (await group(page, 'today')).join('|') === 'تحضير باجر الليلة', (await group(page, 'today')).join('|'));
  await c.ctx.close();

  // ===== 9) بيانات تالفة / نسخة أحدث / صف غير مطابق: رسالة صريحة وليس فراغاً =====
  var corrupt = [
    ['invalid JSON', function () { localStorage.setItem('marsa.academic.preparations.cls_demo_001', '{not json'); localStorage.setItem('marsa.academic.dailyLessons.cls_demo_001', '{not json'); }],
    ['newer schemaVersion', function () { localStorage.setItem('marsa.academic.preparations.cls_demo_001', JSON.stringify({ schemaVersion: 9, classId: 'cls_demo_001', records: [] })); localStorage.setItem('marsa.academic.dailyLessons.cls_demo_001', JSON.stringify({ schemaVersion: 9, classId: 'cls_demo_001', records: [] })); }],
    ['invalid record (bad date)', function () { var rec = { recordId: 'x1', classId: 'cls_demo_001', subject: 'م', title: 'ت', date: '2026-13-45', content: 'c' }; localStorage.setItem('marsa.academic.preparations.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', records: [rec] })); localStorage.setItem('marsa.academic.dailyLessons.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', records: [rec] })); }],
    ['classId mismatch', function () { localStorage.setItem('marsa.academic.preparations.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_other', records: [] })); localStorage.setItem('marsa.academic.dailyLessons.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_other', records: [] })); }]
  ];
  for (i = 0; i < corrupt.length; i++) {
    c = await open(browser, { label: 'corrupt-' + i }); page = c.page;
    await page.evaluate(corrupt[i][1]);
    var rawP = await raw(page, PKEY), rawL = await raw(page, LKEY);
    await nav(page, 'التحاضير');
    t = await pageText(page);
    check('Corrupt (' + corrupt[i][0] + ') prep: explicit error alert, not an empty list', (await page.$$eval('#v-page [role="alert"]', function (l) { return l.length; })) === 1 && /تعذّرت قراءة التحاضير/.test(t) && /لا يمكن الجزم بأن القائمة فارغة/.test(t));
    check('Corrupt (' + corrupt[i][0] + ') prep: the empty-state "no preps yet" is NOT shown', !/لا توجد تحاضير مضافة لهذا الصف بعد/.test(t) && (await titles(page)).length === 0);
    await nav(page, 'الأرشيف');
    t = await pageText(page);
    check('Corrupt (' + corrupt[i][0] + ') archive: explicit error alert, not an empty list', (await page.$$eval('#v-page [role="alert"]', function (l) { return l.length; })) === 1 && /تعذّرت قراءة بعض سجلات/.test(t) && /الدروس:/.test(t) && !/لا توجد سجلات دراسية لهذا الصف بعد/.test(t));
    check('Corrupt (' + corrupt[i][0] + '): study data bytes untouched by student viewing', (await raw(page, PKEY)) === rawP && (await raw(page, LKEY)) === rawL);
    if (i === 0) { await shot(page, 'archive-error-390'); check('Corrupt: error view 390px has no horizontal scroll', !(await overflow(page))); }
    await c.ctx.close();
  }

  // ===== 10) التخزين غير متاح (وضع الذاكرة) =====
  c = await open(browser, { label: 'nostorage', init: 'Object.defineProperty(window, "localStorage", { get: function () { throw new Error("blocked"); } });' }); page = c.page;
  await nav(page, 'التحاضير');
  t = await pageText(page);
  check('No storage: student prep page still renders (no crash) and says storage is temporary', /التخزين الدائم غير متاح/.test(t) && /لا توجد تحاضير مضافة/.test(t));
  await c.ctx.close();

  // ===== 11) أمان: XSS وروابط =====
  c = await open(browser, { label: 'xss' }); page = c.page;
  var evil = '<img src=x onerror="window.__pwn=1"><script>window.__pwn=2<\/script>';
  await seed(page, PKEY, DEMO, [prep('prep_x1', { subject: evil, title: evil, date: TODAY, content: evil + '\nراجع https://example.com/lesson?id=1، وكذلك javascript:window.__pwn=3 و data:text/html,<b>x</b> و HTTPS://EXAMPLE.ORG/A.', pages: '<b>صفحة</b>', homework: 'file:///etc/passwd' })]);
  await seed(page, LKEY, DEMO, [lesson('dl_x1', { subject: evil, title: evil, date: TODAY, summary: 'https://good.example/s و javascript:alert(1)', pages: evil, homework: evil })]);
  await nav(page, 'التحاضير');
  check('XSS: raw HTML shown as literal text in prep (no img/script elements created)', (await page.$$eval('#v-page img, #v-page script, #v-page b', function (l) { return l.length; })) === 0 && /<img src=x/.test(await pageText(page)));
  check('XSS: no injected script ran', (await page.evaluate(function () { return window.__pwn; })) === undefined);
  var links = await page.$$eval('#v-page a', function (l) { return l.map(function (a) { return { href: a.getAttribute('href'), rel: a.rel, target: a.target }; }); });
  check('Links: only http(s) become anchors', links.length === 2 && links.every(function (l) { return /^https?:\/\//.test(l.href); }), JSON.stringify(links));
  check('Links: rel=noopener noreferrer nofollow and target=_blank', links.every(function (l) { return /noopener/.test(l.rel) && /noreferrer/.test(l.rel) && l.target === '_blank'; }));
  check('Links: trailing punctuation (، and .) excluded from href', links[0].href === 'https://example.com/lesson?id=1' && links[1].href === 'https://example.org/A', JSON.stringify(links));
  check('javascript:/data:/file: remain visible plain text, not clickable', /javascript:window\.__pwn=3/.test(await pageText(page)) && /file:\/\/\/etc\/passwd/.test(await pageText(page)));
  await nav(page, 'الأرشيف');
  check('XSS (archive): literal text, no elements, no script ran', (await page.$$eval('#v-page img, #v-page script', function (l) { return l.length; })) === 0 && (await page.evaluate(function () { return window.__pwn; })) === undefined && /<img src=x/.test(await pageText(page)));
  var alinks = await page.$$eval('#v-page a', function (l) { return l.map(function (a) { return a.getAttribute('href'); }); });
  check('Archive links: only the https one is an anchor', alinks.length === 1 && alinks[0] === 'https://good.example/s', JSON.stringify(alinks));
  await c.ctx.close();

  // ===== 12) نص عربي طويل + شاشات ضيقة =====
  var longWord = new Array(260).join('طويلة');
  var longAr = 'هذا نص عربي طويل جداً يُستخدم لاختبار الالتفاف داخل البطاقة على الشاشات الضيقة دون أي تمرير أفقي. '.repeat(12);
  var widths = [320, 360, 390, 430];
  for (i = 0; i < widths.length; i++) {
    c = await open(browser, { label: 'w' + widths[i], viewport: { width: widths[i], height: 700 } }); page = c.page;
    await seed(page, PKEY, DEMO, [prep('prep_w1', { subject: longWord, title: longWord, date: TODAY, content: longAr + longWord, pages: longWord, homework: 'https://example.com/' + new Array(200).join('a/') })]);
    await seed(page, LKEY, DEMO, [lesson('dl_w1', { subject: longWord, title: longWord, date: TODAY, summary: longAr + longWord, pages: longWord, homework: longWord })]);
    await nav(page, 'التحاضير');
    check('Width ' + widths[i] + ': long unbroken Arabic + long URL in prep wraps (no horizontal scroll)', !(await overflow(page)));
    if (widths[i] === 320) await shot(page, 'prep-long-320');
    await nav(page, 'الأرشيف');
    check('Width ' + widths[i] + ': long text in archive wraps (no horizontal scroll)', !(await overflow(page)));
    if (widths[i] === 320) await shot(page, 'archive-long-320');
    var h = await page.$eval('.st-search', function (e) { return e.getBoundingClientRect().height; });
    check('Width ' + widths[i] + ': search field touch height >= 44px', h >= 44, String(h));
    await c.ctx.close();
  }

  // ===== 13) المظهر الداكن + لا hover مطلوب + اتجاه RTL =====
  c = await open(browser, { label: 'dark' }); page = c.page;
  await page.emulateMedia({ colorScheme: 'dark' });
  await seed(page, PKEY, DEMO, [prep('prep_d1', { subject: 'م', title: 'تحضير داكن', date: TODAY, content: 'محتوى' })]);
  await nav(page, 'التحاضير');
  check('RTL document direction kept in student view', await page.evaluate(function () { return document.documentElement.dir === 'rtl' && getComputedStyle(document.querySelector('.st-card')).direction === 'rtl'; }));
  await shot(page, 'prep-dark-390');
  await c.ctx.close();

  // ===== 14) الرجوع إلى وضع الطالب لا يكشف عناصر الممثل =====
  c = await open(browser, { label: 'nav' }); page = c.page;
  await toRep(page); await toStudent(page);
  var navLabels = await page.$$eval('.nav button', function (l) { return l.map(function (x) { return x.textContent.trim(); }); });
  check('Student nav has no rep sections (no «ما أُخذ اليوم»/«اللوحة»)', navLabels.indexOf('ما أُخذ اليوم') < 0 && navLabels.indexOf('اللوحة') < 0 && navLabels.indexOf('التحاضير') > -1 && navLabels.indexOf('الأرشيف') > -1, navLabels.join('|'));
  await c.ctx.close();

  await browser.close();
  check('No uncaught JavaScript errors in any scenario', jsErrors.length === 0, jsErrors.join(' ;; '));
  var failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('RUNNER ERROR', e); process.exit(2); });
