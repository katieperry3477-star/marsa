// اختبار واجهة 4.08: تدقيق القبول النهائي للمرحلة الرابعة (سيناريو واحد متكامل على بيانات معزولة).
// يغطي: خصوصية وضع الطالب للأنواع الثلاثة معاً (محتوى DOM + عدم القراءة)، بقاء البيانات بعد إعادة التحميل،
// حماية مسودة الحضور/الدرجات/المدفوعات عند تبديل الوضع، رفض فاصلة الآلاف الملتبسة في الدرجات، وعدم تلوّث الصفوف.
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-stage4-final-audit.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
async function skip(page) { await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
}
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 }); }
async function newClass(page, stage) {
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', stage); await page.click('#dlg-class button.primary');
  await page.waitForSelector('#dlg-class', { state: 'hidden' });
  var card = page.locator('li.cls', { hasText: stage }).filter({ has: page.locator('button:has-text("اختيار كصف نشط")') });
  if (await card.count()) await card.first().locator('button:has-text("اختيار كصف نشط")').click();
  return page.evaluate(function () { return JSON.parse(localStorage.getItem('marsa.classes')).activeClassId; });
}
async function addStudents(page, names) {
  await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")'); await page.fill('#add-names', names.join('\n'));
  await page.click('button:has-text("معاينة الأسماء")'); await page.click('button:has-text("تأكيد الإضافة")'); await page.waitForSelector('#dlg-add', { state: 'hidden' });
}
async function recs(page, type, cid) { return page.evaluate(function (a) { var raw = localStorage.getItem('marsa.academic.' + a.t + '.' + a.c); return raw ? JSON.parse(raw).records : []; }, { t: type, c: cid }); }
async function status(page) { return page.textContent('#status'); }

(async function () {
  var browser = await pw.chromium.launch();
  var ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  var page = await ctx.newPage(); page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.addInitScript(function () {
    window.__reads = []; var g = Storage.prototype.getItem;
    Storage.prototype.getItem = function (k) { if (/^marsa\.academic\.(attendance|grades|payments)\./.test(String(k))) window.__reads.push(k); return g.apply(this, arguments); };
  });
  await page.goto(URL); await skip(page);
  await toRep(page);
  var cid = await newClass(page, 'صف التدقيق النهائي');
  check('صف جديد نشط', !!cid);
  await addStudents(page, ['زيد التدقيق', 'ليلى التدقيق']);

  // ===== 1) إدخال سجل من كل نوع عبر الواجهة (بيانات تجريبية بعلامات فريدة) =====
  await page.click('.nav button:text-is("الحضور")'); await page.waitForSelector('#att-date');
  await page.click('.arow[data-student-id]:has(.ar-n:has-text("زيد")) label.st-absent');
  await page.click('button:has-text("حفظ الحضور")'); await page.waitForTimeout(150);
  var att = await recs(page, 'attendance', cid);
  check('الحضور: سجل واحد غائب محفوظ', att.length === 1 && att[0].status === 'absent' && att[0].classId === cid, JSON.stringify(att));

  await page.click('.nav button:text-is("الدرجات")'); await page.waitForSelector('#gr-score');
  await page.selectOption('#gr-studentId', { label: 'زيد التدقيق' }); await page.fill('#gr-subject', 'مادةعلامة'); await page.fill('#gr-title', 'عنوانعلامة');
  await page.fill('#gr-score', '7.5'); await page.fill('#gr-maxScore', '10'); await page.click('.gr-form button.primary'); await page.waitForTimeout(150);
  var gr = await recs(page, 'grades', cid);
  check('الدرجات: سجل 7.5/10 محفوظ', gr.length === 1 && gr[0].score === 7.5 && gr[0].maxScore === 10, JSON.stringify(gr));

  await page.click('.nav button:text-is("المدفوعات")'); await page.waitForSelector('#pay-amount');
  await page.selectOption('#pay-studentId', { label: 'ليلى التدقيق' }); await page.fill('#pay-amount', '13579'); await page.fill('#pay-purpose', 'غرضعلامة');
  await page.click('.pay-form .toolbar button.primary'); await page.waitForTimeout(150);
  var pay = await recs(page, 'payments', cid);
  check('المدفوعات: سجل 13579 محفوظ كعدد صحيح', pay.length === 1 && pay[0].amount === 13579, JSON.stringify(pay));

  // ===== 2) درجات: فاصلة الآلاف الملتبسة لا تُقرأ بصمت =====
  await page.click('.nav button:text-is("الدرجات")'); await page.waitForSelector('#gr-score');
  await page.selectOption('#gr-studentId', { label: 'ليلى التدقيق' }); await page.fill('#gr-subject', 'س'); await page.fill('#gr-title', 'ع');
  await page.fill('#gr-score', '1'); await page.fill('#gr-maxScore', '1,000'); await page.click('.gr-form button.primary'); await page.waitForTimeout(150);
  check('درجة قصوى «1,000» مرفوضة بدل أن تُقرأ 1', (await recs(page, 'grades', cid)).length === 1 && (await page.textContent('#gr-maxScore-e')) !== '', await page.textContent('#gr-maxScore-e'));
  await page.fill('#gr-maxScore', '10'); await page.fill('#gr-score', '7,500'); await page.click('.gr-form button.primary'); await page.waitForTimeout(150);
  check('درجة «7,500» مرفوضة بدل أن تُقرأ 7.5', (await recs(page, 'grades', cid)).length === 1 && (await page.textContent('#gr-score-e')) !== '', await page.textContent('#gr-score-e'));
  await page.fill('#gr-score', '7,5'); await page.click('.gr-form button.primary'); await page.waitForTimeout(150);
  var gr2 = await recs(page, 'grades', cid);
  check('الفاصلة العشرية العربية «7,5» ما زالت تعمل', gr2.length === 2 && gr2.some(function (r) { return r.score === 7.5 && r.subject === 'س'; }), JSON.stringify(gr2));

  // ===== 3) حماية المسودة عند تبديل الوضع =====
  await page.click('.nav button:text-is("المدفوعات")'); await page.waitForSelector('#pay-amount');
  await page.fill('#pay-amount', '555');
  await page.click('.seg button[data-m="student"]'); await page.waitForTimeout(400);
  var dlgOpen = await page.evaluate(function () { var d = document.getElementById('dlg-confirm'); return !!d && d.open; });
  check('تبديل الوضع مع مسودة مدفوعات: نافذة تأكيد وليس فقداً صامتاً', dlgOpen);
  if (dlgOpen) {
    var cancelBtn = page.locator('#dlg-confirm button', { hasText: /إلغاء|البقاء|رجوع/ }).first();
    await cancelBtn.click(); await page.waitForTimeout(200);
    check('إلغاء التبديل: نبقى في وضع الممثل والمسودة باقية', (await page.inputValue('#pay-amount')) === '555' && (await page.getAttribute('html', 'data-mode')) === 'rep');
    await page.click('.seg button[data-m="student"]'); await page.waitForTimeout(300);
    await page.locator('#dlg-confirm button.primary, #dlg-confirm button.danger').last().click();
    await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
    check('تأكيد التجاهل: ينتقل لوضع الطالب', (await page.getAttribute('html', 'data-mode')) === 'student');
  } else {
    await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
  }
  check('لم تُكتب المسودة 555 في التخزين', (await recs(page, 'payments', cid)).length === 1);

  // نفس الحارس للحضور والدرجات (مسار الكود نفسه؛ يُختبر هنا فعلاً لا افتراضاً)
  async function guardCase(label, navText, readySel, dirtyFn) {
    await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
    await page.click('.nav button:text-is("' + navText + '")'); await page.waitForSelector(readySel);
    await dirtyFn();
    await page.click('.seg button[data-m="student"]'); await page.waitForTimeout(400);
    var open = await page.evaluate(function () { var d = document.getElementById('dlg-confirm'); return !!d && d.open; });
    check('تبديل الوضع مع مسودة ' + label + ': نافذة تأكيد', open);
    if (open) {
      await page.locator('#dlg-confirm button.link').first().click(); await page.waitForTimeout(200);
      check('إلغاء (' + label + '): نبقى في وضع الممثل', (await page.getAttribute('html', 'data-mode')) === 'rep');
      await page.click('.seg button[data-m="student"]'); await page.waitForTimeout(300);
      await page.locator('#dlg-confirm button.primary').last().click();
      await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 });
      check('تأكيد التجاهل (' + label + '): وضع الطالب', (await page.getAttribute('html', 'data-mode')) === 'student');
    }
  }
  await guardCase('الحضور', 'الحضور', '#att-date', async function () { await page.click('.arow[data-student-id]:has(.ar-n:has-text("ليلى")) label.st-late'); });
  check('الحضور: المسودة لم تُكتب في التخزين', (await recs(page, 'attendance', cid)).length === 1);
  await guardCase('الدرجات', 'الدرجات', '#gr-score', async function () { await page.fill('#gr-score', '3'); });
  check('الدرجات: المسودة لم تُكتب في التخزين', (await recs(page, 'grades', cid)).length === 2);

  // ===== 4) خصوصية وضع الطالب: أي صفحة، أي نوع =====
  await page.evaluate(function () { window.__reads.length = 0; });
  var navs = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent.trim(); }); });
  var seen = '';
  for (var i = 0; i < navs.length; i++) { await page.click('.nav button >> nth=' + i); await page.waitForTimeout(80); seen += '\n' + await page.evaluate(function () { return document.body.innerText; }); }
  var markers = ['مادةعلامة', 'عنوانعلامة', 'غرضعلامة', '13579', '13,579', '7.5', 'زيد التدقيق', 'ليلى التدقيق'];
  var leaked = markers.filter(function (m) { return seen.indexOf(m) > -1; });
  // أسماء الطلاب قد تظهر في صفحة غير متصلة بالأنواع الثلاثة؛ نفصلها عن الأنواع الحساسة
  var sensitive = leaked.filter(function (m) { return m !== 'زيد التدقيق' && m !== 'ليلى التدقيق'; });
  check('وضع الطالب: لا درجة ولا مبلغ ولا غرض ولا مادة تقييم في أي صفحة', sensitive.length === 0, sensitive.join());
  var reads = await page.evaluate(function () { return window.__reads.slice(); });
  check('وضع الطالب: لم تُقرأ مفاتيح attendance/grades/payments إطلاقاً', reads.length === 0, JSON.stringify(reads));
  check('وضع الطالب: لا نموذج حضور/درجات/مدفوعات في DOM', (await page.$('#pay-amount, #gr-score, #att-date, .att-list')) === null);
  var absTxt = await page.evaluate(function () { var b = Array.from(document.querySelectorAll('.nav button')).filter(function (x) { return /غياب/.test(x.textContent); })[0]; if (b) b.click(); return document.getElementById('v-page').innerText; });
  check('وضع الطالب: صفحة «غيابي» تعرض تنبيه المصادقة لا سجلاً', /مصادقة/.test(absTxt) && !/غائب|حاضر/.test(absTxt.replace(/تنبيه/g, '')) , absTxt.slice(0, 160));

  // ===== 5) بقاء البيانات بعد إعادة التحميل وعدم تلوث صف آخر =====
  await page.reload(); await skip(page);
  check('بعد إعادة التحميل: السجلات الثلاثة باقية', (await recs(page, 'attendance', cid)).length === 1 && (await recs(page, 'grades', cid)).length === 2 && (await recs(page, 'payments', cid)).length === 1);
  var otherKeys = await page.evaluate(function (c) { return Object.keys(localStorage).filter(function (k) { return /^marsa\.academic\.(attendance|grades|payments)\./.test(k) && k.indexOf(c) < 0; }); }, cid);
  check('لا مفاتيح أكاديمية لصفوف أخرى (لا تلوّث)', otherKeys.length === 0, otherKeys.join());
  check('بعد إعادة التحميل: التطبيق يبدأ في وضع الطالب', (await page.getAttribute('html', 'data-mode')) === 'student');

  check('لا أخطاء JavaScript أثناء الجلسة كلها', jsErrors.length === 0, jsErrors.join(' | '));
  await browser.close();
  var failed = results.filter(function (r) { return !r.ok; }).length;
  console.log('\n' + (results.length - failed) + ' passed, ' + failed + ' failed; JS errors: ' + jsErrors.length);
  process.exit(failed ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
