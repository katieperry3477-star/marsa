// 01.05 — فحص معاينة التصميم الثابتة بـPlaywright/Chromium (لا يمسّ التطبيق). التشغيل: NODE_PATH=$(npm root -g) node tests/e2e-ui-preview.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'docs', 'execution-v2', 'ui', 'UI-DESIGN-PREVIEW-V2.html');
var results = [], jsErrors = [], external = [];
function check(n, c, d) { results.push(!!c); console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' :: ' + (d || ''))); }
async function open(b, w, o) {
  o = o || {};
  var ctx = await b.newContext({ viewport: { width: w, height: 800 }, locale: 'ar-IQ', hasTouch: w < 800, colorScheme: o.scheme || 'light', reducedMotion: o.reduce ? 'reduce' : 'no-preference' });
  await ctx.route(function (u) { return u.protocol !== 'file:'; }, function (r) { external.push(r.request().url()); r.abort(); });
  var p = await ctx.newPage(); p.on('pageerror', function (e) { jsErrors.push(e.message); });
  await p.goto(URL); await p.waitForSelector('#role-frames .phone'); return p;
}
var hs = function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; };
(async function () {
  var b = await pw.chromium.launch();
  // 1) لا تمرير أفقي في 3 عروض × ثيمين
  for (var w of [320, 390, 1280]) for (var sc of ['light', 'dark']) {
    var p = await open(b, w, { scheme: sc }); check('لا تمرير أفقي ' + w + ' ' + sc, !(await p.evaluate(hs)));
    await p.evaluate(function () { document.querySelectorAll('.phone').forEach(function (x) { x.classList.add('open'); }); });
    check('لا تمرير أفقي والقوائم مفتوحة ' + w + ' ' + sc, !(await p.evaluate(hs))); await p.context().close();
  }
  var p = await open(b, 390);
  // 2) الرئيسية: سقف البطاقات
  var caps = await p.evaluate(function () { return [].map.call(document.querySelectorAll('#role-frames .phone'), function (ph) { return [ph.getAttribute('data-role'), ph.querySelectorAll('[data-home-card]').length, ph.querySelectorAll('[data-home-quick] button').length]; }); });
  check('سقف الرئيسية ≤4 بطاقات و≤3 أزرار لكل دور', caps.length === 3 && caps.every(function (c) { return c[1] <= 4 && c[2] <= 3; }), JSON.stringify(caps));
  check('طالب 3 بطاقات · ممثل 3 + شريط 3 أزرار · مطوّر 4 + زر', JSON.stringify(caps) === JSON.stringify([['s', 3, 0], ['r', 3, 3], ['d', 4, 1]]), JSON.stringify(caps));
  var tb = await p.evaluate(function () { return [].map.call(document.querySelectorAll('#role-frames .phone'), function (ph) { return [].map.call(ph.querySelectorAll('.p-tabs a'), function (a) { return a.textContent.trim(); }).join('|'); }); });
  check('أشرطة سفلية بأسماء المواصفة', tb.join(';') === 'الرئيسية|التحاضير|ملفي;الرئيسية|إدارة الصف|التحاضير;لوحة التحكم|الممثلون|النظام', tb.join(';'));
  check('الشريط السفلي: عنصر واحد aria-current لكل دور', await p.evaluate(function () { return [].every.call(document.querySelectorAll('#role-frames .phone'), function (ph) { return ph.querySelectorAll('.p-tabs [aria-current="page"]').length === 1; }); }));
  check('ترويسة: شعار + اسم الشعبة + سطر «قيد التطوير» ظاهرة', await p.evaluate(function () { return [].every.call(document.querySelectorAll('#role-frames .phone'), function (ph) { return /مَرسى/.test(ph.querySelector('.brand').textContent) && /شعبة/.test(ph.querySelector('.brand').textContent) && /قيد التطوير وليس النسخة النهائية/.test(ph.querySelector('.p-note').textContent); }); }));
  // 3) القائمة الجانبية
  var ph = p.locator('#side-slot .phone');
  check('القائمة مغلقة مخفية عن القارئ افتراضياً', await ph.locator('.side').evaluate(function (e) { return getComputedStyle(e).visibility === 'hidden'; }));
  await ph.locator('[data-open]').click(); await p.waitForTimeout(450);
  check('فتح القائمة ينقل التركيز إلى داخلها', await p.evaluate(function () { return !!document.activeElement.closest('.side'); }));
  var box = await ph.locator('.side').boundingBox(), pb = await ph.boundingBox();
  check('القائمة تنزلق من اليمين (RTL)', Math.abs((box.x + box.width) - (pb.x + pb.width)) < 3 && box.width >= 300 - 2 && box.width <= 321, JSON.stringify([box, pb]));
  for (var k = 0; k < 40; k++) await p.keyboard.press('Tab');
  check('Tab لا يهرب من القائمة المفتوحة (حبس التركيز)', await p.evaluate(function () { return !!document.activeElement.closest('.side'); }));
  await p.keyboard.press('Escape'); await p.waitForTimeout(350);
  check('Esc يغلق القائمة ويعيد التركيز إلى ☰', await p.evaluate(function () { return !document.querySelector('#side-slot .phone').classList.contains('open') && document.activeElement.hasAttribute('data-open'); }));
  await ph.locator('[data-open]').click(); await p.waitForTimeout(450); await ph.locator('[data-scrim]').click({ position: { x: 20, y: 300 } }); await p.waitForTimeout(350);
  check('النقر على الستار يغلق القائمة', await p.evaluate(function () { return !document.querySelector('#side-slot .phone').classList.contains('open'); }));
  // قيد التطوير
  await ph.locator('[data-open]').click(); await p.waitForTimeout(450);
  var h0 = await p.evaluate(function () { return location.href; });
  var fut = ph.locator('button[data-future="teachers"]'); await fut.click(); await p.waitForTimeout(300);
  check('«قيد التطوير»: aria-expanded=true ونص ظاهر بلا تنقل', (await fut.getAttribute('aria-expanded')) === 'true' && (await p.evaluate(function () { return location.href; })) === h0 && /قيد التطوير ولم يُفعَّل بعد/.test(await p.locator('#' + (await fut.getAttribute('aria-controls'))).innerText()));
  check('«قيد التطوير» ليست روابط ولا تفتح نافذة', await ph.locator('.fut-note a, [data-future][href]').count() === 0 && await ph.locator('.dlg').count() === 0);
  await fut.click(); check('إعادة اللمس تطوي النص', (await fut.getAttribute('aria-expanded')) === 'false');
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  // القوائم حسب الدور
  var sideRoles = {};
  for (var r of ['s', 'r', 'd']) { await p.click('#side-role [data-v="' + r + '"]'); sideRoles[r] = await p.evaluate(function () { var s = document.querySelector('#side-slot .side'); return { links: [].map.call(s.querySelectorAll('a[data-screen]'), function (a) { return a.textContent.trim(); }), fut: [].map.call(s.querySelectorAll('[data-future]'), function (a) { return a.getAttribute('data-future'); }), chip: s.querySelector('.role-chip').textContent.trim() }; }); }
  check('قائمة الطالب: 3 قيد التطوير بلا المدير/الشعب', sideRoles.s.fut.join() === 'teachers,chat,english' && sideRoles.s.chip === 'طالب', JSON.stringify(sideRoles.s));
  check('قائمة الممثل والمطوّر: 5 قيد التطوير', sideRoles.r.fut.length === 5 && sideRoles.d.fut.length === 5);
  check('قائمة الطالب لا تحوي «الطلاب» ولا «وضع الدعم»؛ المطوّر وحده يحوي «وضع الدعم»', sideRoles.s.links.indexOf('الطلاب') < 0 && sideRoles.s.links.indexOf('وضع الدعم') < 0 && sideRoles.r.links.indexOf('وضع الدعم') < 0 && sideRoles.d.links.indexOf('وضع الدعم') >= 0 && sideRoles.r.links.indexOf('الطلاب') >= 0);
  check('الدور يظهر كنص (شارة) لا بلون وحده', sideRoles.r.chip === 'ممثل الصف' && sideRoles.d.chip === 'المطوّر');
  // 4) الصفحات الثلاث
  var t3 = p.locator('#three-slot');
  async function cur() { return await t3.locator('.sub-tabs [aria-current="page"]').innerText(); }
  check('الصفحة الأولى «شنو أخذنا اليوم؟» افتراضياً وبتبويب واحد حالي', (await cur()) === 'شنو أخذنا اليوم؟' && await t3.locator('.sub-tabs [aria-current="page"]').count() === 1);
  check('طالب: لا زر إضافة ولا إغلاق يوم', await t3.locator('.fab, [data-close-day]').count() === 0);
  check('بطاقة التحضير: مادة + الواجب + ملاحظات + مرفقات + حالة؛ بلا عنوان درس/مدرّس', await p.evaluate(function () { var c = document.querySelector('#three-slot .prep'); var x = c.textContent; return !!c.querySelector('.subj') && /الواجب/.test(x) && /ملاحظات/.test(x) && !!c.querySelector('.thumbs') && !!c.querySelector('.chip.ok,.chip.no,.chip.later') && !/المدرّس|عنوان الدرس/.test(x); }));
  await t3.locator('[data-pg="1"]').click(); check('تبويب «شنو عدنا باچر؟» وشريط الامتحان', (await cur()) === 'شنو عدنا باچر؟' && /عدنا امتحان/.test(await t3.locator('.p-body').innerText()));
  await t3.locator('[data-pg="2"]').click(); check('تبويب «هل عدنا امتحان؟» يجيب «إي» أولاً', (await cur()) === 'هل عدنا امتحان؟' && /إي، عدنا امتحان/.test(await t3.locator('.answer').innerText()));
  await p.click('#three-state [data-v="empty"]'); await t3.locator('[data-pg="2"]').click(); check('فراغ الامتحان = جواب «لا» (ليس خطأ)', /لا، ما كو امتحان خلال 7 أيام/.test(await t3.locator('.answer').innerText()) && await t3.locator('[role=alert]').count() === 0);
  await p.click('#three-state [data-v="err"]'); check('الخطأ: role=alert وزر إعادة المحاولة', await t3.locator('[role=alert] button').count() === 1);
  await p.click('#three-state [data-v="load"]'); check('التحميل: هياكل بلا نص خام', await t3.locator('.sk').count() === 3);
  await p.click('#three-state [data-v="off"]'); check('دون اتصال: شريط + ختم آخر تحديث', /دون اتصال/.test(await t3.locator('.off').innerText()) && /آخر تحديث/.test(await t3.locator('.p-body').innerText()));
  await p.click('#three-state [data-v="ok"]'); await p.click('#three-role [data-v="r"]'); await t3.locator('[data-pg="0"]').click();
  check('ممثل: زر «＋ تحضير» و«إغلاق اليوم»', await t3.locator('.fab').count() === 1 && await t3.locator('[data-close-day]').count() === 1);
  await t3.locator('[data-close-day]').click(); await p.waitForTimeout(350);
  var sh = t3.locator('.sheet');
  check('إغلاق اليوم: ورقة بثلاث حالات لكل تحضير (تم/لم يتم/تأجل)', await sh.locator('.opt').count() === 3 && /تم أخذه/.test(await sh.innerText()) && /لم يتم أخذه/.test(await sh.innerText()) && /تأجل/.test(await sh.innerText()));
  await sh.locator('[data-sheet-close]').first().click(); check('تأكيد الإغلاق يغلق الورقة', await t3.locator('.sheet').count() === 0);
  await p.click('#three-state [data-v="off"]'); check('دون اتصال: زر الاعتماد aria-disabled ولا يفتح شيئاً', (await t3.locator('[data-close-day]').getAttribute('aria-disabled')) === 'true' && (await t3.locator('[data-close-day]').click({ force: true }), await t3.locator('.sheet').count()) === 0);
  // 5) الدعم
  var sp = p.locator('#support-phone');
  check('شريط الدعم ظاهر ومكتوب فيه الحساب والدور وتأكيد الكتابة', /وضع الدعم — تعرض حساب/.test(await sp.locator('.sbar').innerText()) && /الكتابة تتطلب تأكيداً/.test(await sp.locator('.sbar').innerText()));
  await sp.locator('#sup-write').click(); check('الكتابة أثناء الدعم تفتح نافذة تأكيد alertdialog', await sp.locator('[role=alertdialog]').count() === 1);
  await p.keyboard.press('Escape'); check('Esc يغلق نافذة التأكيد دون كتابة', await sp.locator('[role=alertdialog]').count() === 0);
  // 6) الثيم
  var bg1 = await p.evaluate(function () { return getComputedStyle(document.body).backgroundColor; });
  await p.click('[data-theme-set="dark"]'); await p.waitForTimeout(300);
  var bg2 = await p.evaluate(function () { return [getComputedStyle(document.body).backgroundColor, document.documentElement.getAttribute('data-theme')]; });
  check('تبديل الثيم إلى داكن يغيّر الخلفية فوراً', bg2[1] === 'dark' && bg2[0] !== bg1 && bg2[0] === 'rgb(11, 19, 36)', JSON.stringify([bg1, bg2]));
  await p.click('[data-theme-set="light"]'); await p.waitForTimeout(300); check('الفاتح', (await p.evaluate(function () { return getComputedStyle(document.body).backgroundColor; })) === 'rgb(244, 247, 251)');
  await p.click('[data-theme-set="auto"]'); check('تلقائي يزيل data-theme', (await p.evaluate(function () { return document.documentElement.hasAttribute('data-theme'); })) === false);
  // 7) أهداف اللمس (العناصر غير النصّية داخل الفقرات)
  var small = await p.evaluate(function () { var out = []; document.querySelectorAll('button,a[href],[role=button]').forEach(function (e) { if (e.closest('p,.stamp') ) return; var r = e.getBoundingClientRect(), cs = getComputedStyle(e); if (!r.width || !r.height || cs.visibility === 'hidden' || e.closest('.side') && !e.closest('.phone.open') || e.closest('.skip')) return; if (r.height < 43.5 || r.width < 43.5) out.push((e.textContent || e.getAttribute('aria-label')).trim().slice(0, 20) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height)); }); return out; });
  check('أهداف اللمس ≥ 44px', small.length === 0, small.slice(0, 8).join(' | '));
  await p.context().close();
  // 8) تقليل الحركة
  var q = await open(b, 390, { reduce: true });
  var m = await q.evaluate(function () { var c = document.querySelector('.card'), s = document.querySelector('.side'); return [getComputedStyle(c).animationName, getComputedStyle(s).transitionDuration, document.getElementById('rm-state').textContent]; });
  check('تقليل الحركة: لا animation ولا transition', m[0] === 'none' && /^0s/.test(m[1]) && /مفعّل/.test(m[2]), JSON.stringify(m));
  await q.locator('#role-frames [data-open]').first().click(); check('تقليل الحركة: القائمة تظهر فوراً', await q.evaluate(function () { return getComputedStyle(document.querySelector('#role-frames .side')).visibility === 'visible'; }));
  await q.context().close();
  var q2 = await open(b, 390); var m2 = await q2.evaluate(function () { return [getComputedStyle(document.querySelector('.card')).animationName, document.getElementById('rm-state').textContent]; });
  check('بلا تقليل الحركة: الحركة تعمل', m2[0] === 'cardin' && /غير مفعّل/.test(m2[1]), JSON.stringify(m2)); await q2.context().close();
  // 9) عام
  check('لا طلبات خارجية (كلها file://)', external.length === 0, external.join());
  check('لا أخطاء JavaScript', jsErrors.length === 0, jsErrors.join());
  await b.close();
  var f = results.filter(function (x) { return !x; }).length; console.log('\n' + (results.length - f) + ' نجاح، ' + f + ' فشل'); process.exit(f ? 1 : 0);
})().catch(function (e) { console.error(e); process.exit(1); });
