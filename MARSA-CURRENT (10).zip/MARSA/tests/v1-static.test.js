// تشغيل: node tests/v1-static.test.js  (لا يحتاج مكتبات)
// فحص ثابت لـ MARSA V1: اكتمال الملفات، عدم الاتصال بالإنترنت، أمان العرض، اتساق المصطلحات، سلامة الأرشيف، وصدق الوثائق.
var assert = require('assert'), fs = require('fs'), path = require('path'), cp = require('child_process'), crypto = require('crypto');
var ROOT = path.join(__dirname, '..');
var n = 0, f = 0, skipped = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function read(p) { return fs.readFileSync(path.join(ROOT, p), 'utf8'); }
function exists(p) { return fs.existsSync(path.join(ROOT, p)); }
function sha(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }
function stripJs(s) { return s.replace(/\/\*[\s\S]*?\*\//g, '').split('\n').filter(function (l) { return !/^\s*\/\//.test(l); }).join('\n'); }
var V1JS = ['js/v1-text.js', 'js/v1-share.js', 'js/v1-demo.js', 'js/v1-store.js', 'js/v1-app.js', 'js/v1-boot.js'];
var html = read('index.html'), css = read('css/v1.css');

t('index.html: عربية RTL وviewport وترميز وعنوان', function () {
  assert.ok(/^<!DOCTYPE html>/i.test(html)); assert.ok(/<html lang="ar" dir="rtl">/.test(html)); assert.ok(/<meta charset="utf-8">/i.test(html));
  assert.ok(/<meta name="viewport" content="width=device-width, initial-scale=1/.test(html)); assert.ok(/<title>مَرسى — التحاضير بالكود<\/title>/.test(html)); assert.ok(/<noscript>/.test(html));
});
t('index.html: السكربتات بالترتيب الصحيح، كلها موجودة، ولا سكربت مضمّن', function () {
  var src = (html.match(/<script[^>]*\bsrc="([^"]+)"/g) || []).map(function (s) { return /src="([^"]+)"/.exec(s)[1]; });
  assert.deepStrictEqual(src, ['js/safe-text.js', 'js/preps-model.js', 'js/v1-text.js', 'js/v1-share.js', 'js/v1-demo.js', 'js/v1-store.js', 'js/v1-app.js', 'js/v1-boot.js']);
  src.forEach(function (s) { assert.ok(exists(s), s); });
  assert.strictEqual((html.match(/<script(?![^>]*\bsrc=)/g) || []).length, 0, 'سكربت مضمّن');
  assert.ok((html.match(/<script[^>]*\bdefer\b/g) || []).length === 8);
  assert.ok(/href="css\/v1\.css"/.test(html) && exists('css/v1.css'));
});
t('index.html: لا موارد خارجية ولا معالجات مضمّنة ولا javascript:', function () {
  (html.match(/\b(?:href|src|action)="([^"]*)"/g) || []).forEach(function (a) { var v = /="([^"]*)"/.exec(a)[1]; assert.ok(!/^(https?:)?\/\//i.test(v) && !/^javascript:/i.test(v), 'مرجع خارجي: ' + v); });
  assert.ok(!/\son[a-z]+\s*=/.test(html), 'معالج حدث مضمّن'); assert.ok(!/javascript:/i.test(html)); assert.ok(!/<link[^>]+(?:fonts\.googleapis|preconnect)/i.test(html));
});
t('CSS: بلا @import ولا روابط خارجية ولا خطوط بعيدة، مع الوضع الداكن وتقليل الحركة وهدف لمس ≥ ٤٤px', function () {
  assert.ok(!/@import/.test(css)); assert.ok(!/url\(\s*['"]?(https?:)?\/\//i.test(css)); assert.ok(!/@font-face/.test(css));
  assert.ok(/prefers-color-scheme:dark/.test(css) && /prefers-reduced-motion:reduce/.test(css));
  var tap = /--tap:(\d+)px/.exec(css); assert.ok(tap && +tap[1] >= 44, 'tap');
  assert.ok(/direction:ltr/.test(css) === true && /env\(safe-area-inset-top/.test(css));
});
t('JS الخاص بـ V1: صياغة سليمة (node --check)', function () { V1JS.forEach(function (p) { cp.execFileSync(process.execPath, ['--check', path.join(ROOT, p)]); }); });
t('JS الخاص بـ V1: لا إدراج HTML ولا eval ولا شبكة ولا window.open ولا كوكيز', function () {
  V1JS.forEach(function (p) {
    var s = stripJs(read(p));
    ['innerHTML', 'outerHTML', 'insertAdjacentHTML', 'document.write', 'eval(', 'new Function', 'XMLHttpRequest', 'fetch(', 'WebSocket', 'sendBeacon', 'importScripts', 'import(', 'window.open', 'document.cookie', 'sessionStorage', 'DecompressionStream', 'EventSource', 'new Blob(', 'createObjectURL', '.download =', 'window.print'].forEach(function (k) { assert.ok(s.indexOf(k) < 0, p + ' يحوي ' + k); });
    assert.ok(!/set(?:Timeout|Interval)\s*\(\s*['"`]/.test(s), p + ' setTimeout بنص');
    assert.ok(!/\bon(click|error|load)\s*=/.test(s), p + ' معالج مضمّن');
  });
});
t('JS V1: localStorage لا يُستعمل إلا في v1-store.js', function () { V1JS.forEach(function (p) { var s = stripJs(read(p)); assert.strictEqual(/localStorage/.test(s), p === 'js/v1-store.js', p); }); });
t('JS V1: الروابط الخارجية الوحيدة المسموحة: رابط مشاركة واتساب wa.me (يُفتح بنقرة المستخدم فقط)', function () {
  var seen = {};
  V1JS.forEach(function (p) { (stripJs(read(p)).match(/https?:\/\/[^\s'"`)]*/g) || []).forEach(function (u) { seen[u] = 1; }); });
  // http://www.w3.org/2000/svg معرّف فضاء أسماء XML لـ createElementNS (ليس عنواناً يُطلب من الشبكة)
  Object.keys(seen).forEach(function (u) { assert.ok(['https://wa.me/?text=', 'https://…', 'https://', 'http://www.w3.org/2000/svg'].indexOf(u) > -1, 'رابط غير متوقع: ' + u); });
  assert.ok(seen['https://wa.me/?text=']);
});
t('مفاتيح التخزين: كلها تحت marsa.v1.* ولا تصادم مفاتيح التطبيق الكامل', function () {
  var s = read('js/v1-store.js'), keys = s.match(/'marsa\.[a-z0-9.]+'/g) || [];
  assert.ok(keys.length >= 5); keys.forEach(function (k) { assert.ok(/^'marsa\.v1\.[a-z]+/.test(k) || k === "'marsa.v1.probe'", k); });
  var legacy = read('js/app.js') + read('js/academic-store.js'); assert.ok(legacy.indexOf('marsa.v1.') < 0, 'التطبيق القديم لا يستعمل marsa.v1');
});
t('اتساق المصطلحات: «إنشاء تحضير» و«إضافة تحضير» و«تحضيراتي» موجودة، ولا صيغ بديلة مربكة', function () {
  var ui = stripJs(read('js/v1-app.js')) + html, all = ui + stripJs(read('js/v1-store.js')) + stripJs(read('js/v1-share.js'));
  ['إنشاء تحضير', 'إضافة تحضير', 'تحضيراتي', 'معاينة التحضير', 'إضافة إلى تحضيراتي', 'تحاضير أنشأتها'].forEach(function (k) { assert.ok(ui.indexOf(k) > -1, k); });
  ['تحاضيري', 'إضافة تحضيرة', 'انشاء تحضير', 'اضافة تحضير', 'تحضيراتك المحفوظة', 'تحضيراتي الخاصة', 'إنشاء درس', 'إضافة درس', 'استيراد التحضير'].forEach(function (k) { assert.ok(all.indexOf(k) < 0, 'صيغة بديلة: ' + k); });
});
function literals(src) { // يستخرج النصوص الحرفية ('..' و\"..\") بدقة ويتخطى التعليقات السطرية
  var out = [], i = 0, q, s;
  while (i < src.length) {
    var c = src.charAt(i);
    if (c === '"' || c === "'") {
      q = c; s = ''; i++;
      while (i < src.length && src.charAt(i) !== q && src.charAt(i) !== '\n') { if (src.charAt(i) === '\\') { s += src.charAt(i + 1); i += 2; continue; } s += src.charAt(i++); }
      i++; out.push(s);
    } else if (c === '/' && src.charAt(i + 1) === '/') { while (i < src.length && src.charAt(i) !== '\n') i++; }
    else i++;
  }
  return out;
}
t('كل رسائل المستخدم في V1 عربية: لا جملة إنجليزية ظاهرة (٣ كلمات إنجليزية فأكثر)', function () {
  var bad = [], seen = 0;
  ['js/v1-app.js', 'js/v1-store.js', 'js/v1-share.js', 'js/v1-text.js', 'js/v1-demo.js', 'js/v1-boot.js'].forEach(function (p) {
    literals(stripJs(read(p))).forEach(function (s) {
      seen++;
      var words = s.trim().split(/\s+/);
      if (/^[\x20-\x7E]+$/.test(s) && words.length >= 3 && words.every(function (w) { return /^[A-Za-z][A-Za-z'-]{2,}[.!?]?$/.test(w); })) bad.push(p + ': ' + s);
    });
  });
  assert.ok(seen > 300, 'عدد النصوص المفحوصة ' + seen);
  assert.deepStrictEqual(bad, []);
});
t('full.html (التطبيق الكامل السابق) موجود وبصمته مطابقة لبصمة index.html الأصلي', function () {
  var base = read('docs/architecture/code-baseline.sha256').trim().split('\n').map(function (l) { return l.split(/\s+/); }), line = base.filter(function (x) { return x[1] === 'full.html'; })[0];
  assert.ok(line, 'full.html في ملف البصمات'); assert.strictEqual(sha(fs.readFileSync(path.join(ROOT, 'full.html'))), line[0]);
  ['js/app.js', 'css/styles.css', 'js/academic-store.js', 'js/preps-model.js'].forEach(function (p) { var l = base.filter(function (x) { return x[1] === p; })[0]; assert.ok(l && sha(fs.readFileSync(path.join(ROOT, p))) === l[0], p + ' تغيّر'); });
  var fh = read('full.html'); (fh.match(/<script[^>]*\bsrc="([^"]+)"/g) || []).forEach(function (s) { assert.ok(exists(/src="([^"]+)"/.exec(s)[1]), s); }); assert.ok(exists('css/styles.css'));
});
t('النسخة الأصلية محفوظة: archive/MARSA-stage5-original.zip يحوي index.html مطابقاً لـ full.html', function () {
  assert.ok(exists('archive/MARSA-stage5-original.zip'));
  var out; try { out = cp.execFileSync('unzip', ['-p', path.join(ROOT, 'archive', 'MARSA-stage5-original.zip'), 'MARSA/index.html'], { maxBuffer: 1 << 26 }); } catch (e) { skipped++; console.log('SKIP (unzip غير متاح) — لم يُفحص محتوى الأرشيف'); return; }
  assert.strictEqual(sha(out), sha(fs.readFileSync(path.join(ROOT, 'full.html'))));
});
t('الاختبارات القديمة تقرأ full.html لا index.html (للتطبيق القديم)', function () {
  assert.ok(/full\.html/.test(read('tests/isolation-static.test.js'))); assert.ok(/full\.html/.test(read('tests/e2e-preps.playwright.js')));
});
t('وثائق V1 موجودة: README بالعربية، التقرير، القرارات، وREADME المرحلة 5 محفوظ', function () {
  ['README.md', 'docs/v1/V1-REPORT.md', 'docs/v1/V1-DECISIONS.md', 'docs/README-stage5.md'].forEach(function (p) { assert.ok(exists(p), p); });
  var r = read('README.md'); ['MARSA V1', 'التحاضير بالكود', 'full.html', 'archive/MARSA-stage5-original.zip', 'node tests/v1-share.test.js', 'e2e-v1.playwright.js'].forEach(function (k) { assert.ok(r.indexOf(k) > -1, 'README ينقصه: ' + k); });
  assert.ok((r.match(/[\u0600-\u06FF]/g) || []).length > 2000, 'README يجب أن يكون بالعربية في معظمه');
});
t('التقرير يفصل الأقسام الستة المطلوبة', function () {
  var r = read('docs/v1/V1-REPORT.md'); ['ما احتفظت به', 'ما بسّطته', 'ما أجّلته', 'ما أزلته', 'نتائج الاختبار', 'المشكلات المتبقية'].forEach(function (k) { assert.ok(r.indexOf(k) > -1, k); });
});
t('صدق الوثائق: لا ادّعاء بخادم أو حسابات أو مزامنة أو حماية خادم، مع ذكر الحدود صراحةً', function () {
  var docs = ['README.md', 'docs/v1/V1-REPORT.md', 'docs/v1/V1-DECISIONS.md'].map(read).join('\n');
  ['مزامنة تلقائية', 'حسابات آمنة', 'حماية على مستوى الخادم', 'خادم جاهز', 'تشفير من طرف إلى طرف', 'كود قصير جداً', 'يعمل على كل الأجهزة دون استثناء'].forEach(function (k) { assert.ok(docs.indexOf(k) < 0, 'ادّعاء غير صحيح: ' + k); });
  ['لا حسابات', 'لا مزامنة', 'لا خادم', 'يطول بطول التحضير'].forEach(function (k) { assert.ok(docs.indexOf(k) > -1, 'حدّ غير مذكور: ' + k); });
});
t('لا أسرار أو مفاتيح في ملفات V1 ووثائقه', function () {
  var re = /(eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}|sb_secret_[A-Za-z0-9]+|service_role\s*[:=]\s*['"][^'"]{10,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY)/;
  ['index.html', 'css/v1.css', 'README.md', 'docs/v1/V1-REPORT.md', 'docs/v1/V1-DECISIONS.md'].concat(V1JS).forEach(function (p) { assert.ok(!re.test(read(p)), p); });
});
t('أسماء الملفات والمجلدات الجديدة قصيرة وواضحة (≤ 40 حرفاً) بلا مجلدات متداخلة زائدة', function () {
  ['index.html', 'full.html', 'README.md', 'css/v1.css', 'js/v1-app.js', 'js/v1-share.js', 'js/v1-store.js', 'js/v1-text.js', 'js/v1-demo.js', 'js/v1-boot.js', 'docs/v1/V1-REPORT.md', 'docs/v1/V1-DECISIONS.md', 'archive/MARSA-stage5-original.zip', 'tests/v1-static.test.js', 'tests/e2e-v1-ui.playwright.js', 'tests/v1-ui-store.test.js', 'tests/v1-demo.test.js'].forEach(function (p) { assert.ok(p.length <= 40 && p.split('/').length <= 3, p); });
});
console.log('\n' + n + ' passed, ' + f + ' failed' + (skipped ? ' (' + skipped + ' skipped)' : '')); process.exit(f ? 1 : 0);
