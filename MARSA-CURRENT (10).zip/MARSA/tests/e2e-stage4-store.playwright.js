// اختبار واجهة 4.02: الأنواع الجديدة داخل المتجر الحقيقي في الصفحة (بلا واجهات جديدة بعد).
// يتحقق من: تحميل المتجر عبر file://، حماية حذف الصف من السجلات الجديدة، تنظيف المفاتيح الفارغة، عدم ظهور شيء في وضع الطالب.
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-stage4-store.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
async function skip(page) { await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function unlock(page) { await page.click('.nav button:has-text("الإعدادات")'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")'); }
async function toRep(page) { if (await page.$eval('.seg', function (s) { return s.hidden; })) await unlock(page); await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 8000 }); }
(async function () {
  var browser = await pw.chromium.launch();
  var ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  var page = await ctx.newPage(); page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.goto(URL); await skip(page);
  var types = await page.evaluate(function () { return window.MarsaAcademicStore.TYPES; });
  check('المتجر محمّل عبر file:// ويضم الأنواع الثلاثة', ['attendance', 'grades', 'payments'].every(function (t) { return types.indexOf(t) > -1; }) && types.length === 7, JSON.stringify(types));
  await toRep(page);
  // صف جديد فارغ عبر الواجهة
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', 'صف-4.02'); await page.click('#dlg-class button.primary');
  await page.waitForSelector('#dlg-class', { state: 'hidden' });
  var cid = await page.evaluate(function () { var c = JSON.parse(localStorage.getItem('marsa.classes')); return c.classes.filter(function (x) { return x.status === 'active'; }).pop().classId; });
  check('صف جديد بمعرّف فريد', /^cls_/.test(cid), cid);
  // 1) صف فارغ يُحذف (والمفاتيح الفارغة لا تبقى يتيمة) — صف ثانٍ للتجربة
  var cases = [['attendance', { studentId: 'stu-x1', date: '2026-10-21', status: 'present' }], ['grades', { studentId: 'stu-x1', subject: 'م', title: 'ع', date: '2026-10-21', score: 5, maxScore: 10 }], ['payments', { studentId: 'stu-x1', amount: 1000, purpose: 'غرض', date: '2026-10-21' }]];
  for (var i = 0; i < cases.length; i++) {
    var ty = cases[i][0];
    var r = await page.evaluate(function (a) { return window.MarsaAcademicStore.upsertRecord(a[0], a[1], a[2]); }, [ty, cid, cases[i][1]]);
    check(ty + ': حُفظ فعلاً عبر المتجر في الصفحة', r.ok && r.record && /^(att|grd|pay)_/.test(r.record.recordId), JSON.stringify(r));
    check(ty + ': المفتاح marsa.academic.' + ty + '.<classId> في localStorage', await page.evaluate(function (k) { return localStorage.getItem(k) !== null; }, 'marsa.academic.' + ty + '.' + cid));
    // محاولة حذف الصف نهائياً → ممنوعة بسبب هذا النوع
    await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
    await page.click('button:has-text("حذف نهائي") >> nth=-1').catch(function () { });
    await page.waitForTimeout(200);
    var txt = await page.evaluate(function () { return document.getElementById('dlg-confirm').textContent; });
    check(ty + ': الحذف النهائي ممنوع ويذكر السجلات الدراسية', /لا يمكن حذف هذا الصف نهائياً/.test(txt) && /السجلات الدراسية/.test(txt), txt.slice(0, 160));
    await page.click('#dlg-confirm button:has-text("حسناً")');
    check(ty + ': الصف والسجل ما زالا موجودين بعد المنع', await page.evaluate(function (a) { var c = JSON.parse(localStorage.getItem('marsa.classes')); return c.classes.some(function (x) { return x.classId === a[0]; }) && window.MarsaAcademicStore.readCollection(a[1], a[0]).records.length === 1; }, [cid, ty]));
    // أفرغ هذا النوع ليختبر التالي بمعزل
    await page.evaluate(function (a) { var s = window.MarsaAcademicStore, id = s.readCollection(a[0], a[1]).records[0].recordId; return s.deleteRecord(a[0], a[1], id).ok; }, [ty, cid]);
  }
  // 2) بيانات تالفة من نوع جديد → الحذف ممنوع (لا نعرف أنه فارغ)
  await page.evaluate(function (id) { localStorage.setItem('marsa.academic.payments.' + id, '{broken'); }, cid);
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("حذف نهائي") >> nth=-1'); await page.waitForTimeout(200);
  var t2 = await page.evaluate(function () { return document.getElementById('dlg-confirm').textContent; });
  check('payments تالف: الحذف ممنوع بدل اعتباره فارغاً', /تعذّر التأكد/.test(t2), t2.slice(0, 160));
  await page.click('#dlg-confirm button:has-text("حسناً")');
  check('payments تالف: البيانات الخام لم تُمسّ', (await page.evaluate(function (id) { return localStorage.getItem('marsa.academic.payments.' + id); }, cid)) === '{broken');
  await page.evaluate(function (id) { localStorage.removeItem('marsa.academic.payments.' + id); }, cid);
  // 3) صف خالٍ تماماً بعد الإفراغ: الحذف يتم وتُزال مفاتيح الأنواع الثلاثة الفارغة
  await page.evaluate(function (id) { ['attendance', 'grades', 'payments'].forEach(function (t) { localStorage.setItem('marsa.academic.' + t + '.' + id, JSON.stringify({ schemaVersion: 1, classId: id, records: [] })); }); }, cid);
  await page.click('.nav button:has-text("اللوحة")'); await page.click('button:has-text("إدارة الصفوف")');
  await page.click('button:has-text("حذف نهائي") >> nth=-1'); await page.waitForTimeout(200);
  await page.click('#dlg-confirm button:has-text("حذف نهائي")'); await page.waitForTimeout(300);
  check('صف بمجموعات جديدة فارغة يُحذف', await page.evaluate(function (id) { return !JSON.parse(localStorage.getItem('marsa.classes')).classes.some(function (x) { return x.classId === id; }); }, cid));
  check('مفاتيح الأنواع الثلاثة الفارغة أُزيلت (لا يتامى)', await page.evaluate(function (id) { return ['attendance', 'grades', 'payments'].every(function (t) { return localStorage.getItem('marsa.academic.' + t + '.' + id) === null; }); }, cid));
  // 4) وضع الطالب: لا تظهر أي بيانات من الأنواع الجديدة (لا واجهات لها بعد)
  var demo = await page.evaluate(function () { var s = window.MarsaAcademicStore; return s.upsertRecord('grades', 'cls_demo_001', { studentId: 'stu-secret', subject: 'سرّي-م', title: 'سرّي-ع', date: '2026-10-21', score: 3, maxScore: 10 }).ok && s.upsertRecord('payments', 'cls_demo_001', { studentId: 'stu-secret', amount: 987654, purpose: 'سرّي-غ', date: '2026-10-21' }).ok && s.upsertRecord('attendance', 'cls_demo_001', { studentId: 'stu-secret', date: '2026-10-21', status: 'absent', note: 'سرّي-ن' }).ok; });
  check('بذر سجلات تجريبية في صف الاختبار عبر المتجر', demo);
  // اجعل الصف التجريبي (الذي فيه السجلات السرّية) هو النشط ثم أعد التحميل: يعود التطبيق لوضع الطالب
  var act = await page.evaluate(function () { var c = JSON.parse(localStorage.getItem('marsa.classes')); var d = c.classes.filter(function (x) { return x.classId === 'cls_demo_001'; })[0]; if (!d || d.status !== 'active') return false; c.activeClassId = 'cls_demo_001'; localStorage.setItem('marsa.classes', JSON.stringify(c)); return true; });
  check('الصف التجريبي نشط ويحوي السجلات السرّية قبل فحص وضع الطالب', act);
  await page.reload(); await skip(page);
  check('الوضع طالب بعد إعادة التحميل', (await page.getAttribute('html', 'data-mode')) === 'student');
  var leaks = [];
  var navs = await page.$$eval('.nav button', function (bs) { return bs.map(function (b) { return b.textContent.trim(); }); });
  for (var n = 0; n < navs.length; n++) {
    await page.click('.nav button >> nth=' + n).catch(function () { }); await page.waitForTimeout(120);
    var body = await page.evaluate(function () { return document.body.innerText; });
    if (/سرّي|987654|987,654|٩٨٧٬?٦٥٤/.test(body)) leaks.push(navs[n]);
  }
  check('وضع الطالب: لا تسرّب لبيانات الأنواع الجديدة في أي صفحة (' + navs.length + ' صفحة)', leaks.length === 0, leaks.join(','));
  await page.evaluate(function () { var s = window.MarsaAcademicStore; ['grades', 'payments', 'attendance'].forEach(function (t) { s.readCollection(t, 'cls_demo_001').records.forEach(function (r) { s.deleteRecord(t, 'cls_demo_001', r.recordId); }); }); });
  check('أخطاء JS في الصفحة: 0', jsErrors.length === 0, jsErrors.join(' | '));
  await browser.close();
  var f = results.filter(function (r) { return !r.ok; }).length;
  console.log('\n' + (results.length - f) + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
})().catch(function (e) { console.log('CRASH: ' + e.message); process.exit(2); });
