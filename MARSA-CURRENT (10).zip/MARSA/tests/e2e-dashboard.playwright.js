// اختبار واجهة المرحلة 03.10 (لوحة اليوم وملخص لوحة الممثل من بيانات حقيقية) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-dashboard.playwright.js
// ساعة مزيّفة: الخميس 2026-10-22 09:00 بغداد. لقطات الشاشة تُحفظ في SHOTS_DIR إن عُرّف.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var SHOTS = process.env.SHOTS_DIR || '';
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z';
var DEMO = 'cls_demo_001', TWO = 'cls_two';
function classesJson(active) {
  return JSON.stringify({ schemaVersion: 1, activeClassId: active, classes: [
    { classId: DEMO, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null },
    { classId: TWO, schoolName: '', stage: 'الثالث المتوسط', branch: '', section: 'ب', year: '', status: 'active', createdAt: null, archivedAt: null }] });
}
async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  if (opts.ctx) await opts.ctx(ctx);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(opts.clock || NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function reload(page) { await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' }); }
async function toRep(page) {
  if ((await page.$('.seg button[data-m="rep"]:not([hidden])')) === null) {
    await page.click('.nav button:has-text("الإعدادات")');
    await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
    await page.click('button:has-text("تفعيل")');
  }
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function seed(page, key, classId, records) { await page.evaluate(function (a) { localStorage.setItem(a.key, JSON.stringify({ schemaVersion: 1, classId: a.classId, records: a.records })); }, { key: key, classId: classId, records: records }); }
function rec(id, o, cls) { return Object.assign({ recordId: id, classId: cls || DEMO, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
async function txt(page, sel) { return (await page.textContent(sel)) || ''; }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function shot(page, name) { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); }
async function kpis(page) { return page.$$eval('#dash-kpis li', function (l) { return l.map(function (x) { return x.getAttribute('data-k') + '=' + x.querySelector('b').textContent; }); }); }
async function visibleKpis(page) { return page.$eval('#dash-kpis', function (e) { return !e.hidden && getComputedStyle(e).display !== 'none'; }); }
var K = { l: 'marsa.academic.dailyLessons.', s: 'marsa.academic.schedule.', p: 'marsa.academic.preparations.', e: 'marsa.academic.exams.' };

(async function main() {
  var browser = await pw.chromium.launch(), c, page, t, k, i;

  // ===== 1) لا بيانات: حالات فراغ تشرح البدء، لا أرقام، «يُفعّل في مرحلة لاحقة» للإعلانات فقط =====
  c = await open(browser, { label: 'empty' }); page = c.page;
  check('Empty: counters strip hidden (no numbers)', !(await visibleKpis(page)) && (await kpis(page)).length === 0);
  t = await txt(page, '#dash-grid');
  check('Empty: lessons card explains how to start', /لم يُسجَّل أي درس بعد/.test(t) && /ما أُخذ اليوم/.test(t));
  check('Empty: schedule/exam/prep cards explain how to start', /لا يوجد جدول بعد/.test(t) && /لا توجد امتحانات مضافة/.test(t) && /لم يُضف أي تحضير بعد/.test(t));
  check('Empty: no digits in schedule/exam/prep cards', !/\d/.test((await txt(page, '#dash-sched')) + (await txt(page, '#dash-exam')) + (await txt(page, '#dash-prep'))));
  var soon = await page.$$eval('#dash-grid .soon', function (l) { return l.map(function (x) { return x.closest('section').querySelector('h3').textContent; }); });
  check('«يُفعّل في مرحلة لاحقة» بقيت للإعلانات وحدها وزالت من ملخص اليوم والتحضير', soon.length === 1 && soon[0] === 'آخر إعلان', JSON.stringify(soon));
  check('No loading placeholder left behind', !/جارٍ تحميل/.test(await txt(page, '#dash-grid')));
  await shot(page, 'home-empty-390');
  await c.ctx.close();

  // ===== 2) بيانات مخزّنة: البطاقات والعدادات تعكسها (مخزّنة بترتيب مخلوط عمداً) =====
  c = await open(browser, { label: 'data', ctx: async function (ctx) { await ctx.addInitScript(function () { }); } }); page = c.page;
  await seed(page, K.l + DEMO, DEMO, [
    rec('l1', { subject: 'الشبكات', title: 'أنواع الكابلات', date: '2026-10-22' }),
    rec('l2', { subject: 'الأمن', title: 'درس أمس', date: '2026-10-21' }),
    rec('l3', { subject: 'الصيانة', title: 'فحص اللوحة الأم', date: '2026-10-22', createdAt: '2026-10-22T04:00:00.000Z' })]);
  await seed(page, K.s + DEMO, DEMO, [
    rec('s3', { day: 'thu', period: 3, startTime: '10:30', endTime: '11:15', subject: 'الصيانة' }),
    rec('s1', { day: 'thu', period: 1, startTime: '08:00', endTime: '08:45', subject: 'الشبكات' }),
    rec('s9', { day: 'sun', period: 1, subject: 'أحد' })]);
  await seed(page, K.p + DEMO, DEMO, [
    rec('p1', { subject: 'الأمن', title: 'تحضير قديم', date: '2026-10-10', createdAt: '2026-10-01T05:00:00.000Z' }),
    rec('p2', { subject: 'الشبكات', title: 'تحضير باجر', date: '2026-10-23', createdAt: '2026-10-21T05:00:00.000Z' }),
    rec('p3', { subject: 'الصيانة', title: 'تحضير بعيد', date: '2026-11-10', createdAt: '2026-10-02T05:00:00.000Z' })]);
  await seed(page, K.e + DEMO, DEMO, [
    rec('e1', { subject: 'الحاسوب', title: 'امتحان أخير', examDate: '2026-12-01', status: 'scheduled' }),
    rec('e2', { subject: 'الشبكات', title: 'امتحان شهري', examDate: '2026-10-25', status: 'scheduled', topics: 'الفصل الأول والثاني' }),
    rec('e3', { subject: 'الأمن', title: 'ملغى', examDate: '2026-10-23', status: 'cancelled' })]);
  await reload(page);
  t = await txt(page, '#dash-day');
  check('Day card: two lessons taken today, not yesterday', /درسان/.test(t) && /أنواع الكابلات/.test(t) && /فحص اللوحة الأم/.test(t) && !/درس أمس/.test(t), t);
  t = await txt(page, '#dash-sched');
  check('Schedule card: Thursday only, ordered by period', /الخميس/.test(t) && t.indexOf('الشبكات') < t.indexOf('الصيانة') && !/أحد/.test(t), t);
  check('Schedule card: period numbers and time ranges as entered', /حصة 1/.test(t) && /حصة 3/.test(t) && /8:00 ص/.test(t) && /10:30 ص/.test(t), t);
  t = await txt(page, '#dash-exam');
  check('Exam card: nearest scheduled (cancelled ignored), relative label, topics', /امتحان شهري/.test(t) && /بعد 3 أيام/.test(t) && /الفصل الأول والثاني/.test(t) && !/ملغى/.test(t) && /وبعده امتحان واحد/.test(t), t);
  t = await txt(page, '#dash-prep');
  check('Prep card: latest added (باجر item), tomorrow tag, upcoming count 2', /تحضير باجر/.test(t) && /باجر/.test(t) && /القادمة[^:]*: 2/.test(t), t);
  k = await kpis(page);
  check('Counters computed from data', k.join() === 'lessons=2,periods=2,preps=2,exams=2', k.join());
  await shot(page, 'home-data-390');

  // ===== 3) الحالة بعد إعادة التحميل ثابتة =====
  await reload(page);
  check('After reload: same counters and cards', (await kpis(page)).join() === 'lessons=2,periods=2,preps=2,exams=2' && /امتحان شهري/.test(await txt(page, '#dash-exam')));

  // ===== 4) إضافة/تعديل/حذف من واجهة الممثل ثم العودة للطالب: تظهر فوراً دون تكرار =====
  await toRep(page);
  await page.click('.nav button:has-text("ما أُخذ اليوم")'); await page.waitForSelector('#page-title');
  await page.click('button:has-text("إضافة سجل درس")');
  await page.fill('#lf-subject', 'مادة جديدة'); await page.fill('#lf-title', 'درس مضاف الآن'); await page.fill('#lf-date', '2026-10-22');
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard:has-text("درس مضاف الآن")');
  await page.click('.nav button:has-text("اللوحة")'); await page.waitForSelector('#page-title');
  t = await txt(page, '#v-page');
  check('Rep summary shows real counts: lessons total 4 (today 3)', /ما أُخذ اليوم/.test(t) && /4 \(منها اليوم: 3\)/.test(t), t);
  check('Rep summary: schedule 3 (today 2), preps 3 (upcoming 2), exams 3 (upcoming 2)', /3 \(حصص اليوم: 2\)/.test(t) && /3 \(القادمة: 2\)/.test(t), t);
  check('Rep summary has no numbers for unbuilt sections (attendance/payments/news)', !/الحضور:|المدفوعات:|الإعلانات:/.test(await txt(page, 'section.part')));
  await toStudent(page);
  t = await txt(page, '#dash-day');
  check('After add (rep→student): lessons card shows 3 incl. new one', /3 دروس/.test(t) && /درس مضاف الآن/.test(t), t);
  check('After add: counter updated', (await kpis(page)).indexOf('lessons=3') > -1, (await kpis(page)).join());
  check('No duplicated records on card', (await page.$$eval('#dash-day li[data-record-id]', function (l) { return l.map(function (x) { return x.getAttribute('data-record-id'); }); })).length === 3);
  // تعديل
  await toRep(page);
  await page.click('.nav button:has-text("ما أُخذ اليوم")'); await page.waitForSelector('.lcard:has-text("درس مضاف الآن")');
  await page.click('.lcard:has-text("درس مضاف الآن") button:has-text("تعديل")');
  await page.fill('#lf-title', 'عنوان معدّل'); await page.click('button:has-text("حفظ")'); await page.waitForSelector('.lcard:has-text("عنوان معدّل")');
  await toStudent(page);
  t = await txt(page, '#dash-day');
  check('After edit: new title shown, old title gone', /عنوان معدّل/.test(t) && !/درس مضاف الآن/.test(t), t);
  // حذف
  await toRep(page);
  await page.click('.nav button:has-text("ما أُخذ اليوم")'); await page.waitForSelector('.lcard:has-text("عنوان معدّل")');
  await page.click('.lcard:has-text("عنوان معدّل") button:has-text("حذف")');
  await page.click('dialog[open] button:has-text("حذف")'); await page.waitForFunction(function () { return !document.querySelector('.lcard h3') || ![].some.call(document.querySelectorAll('.lcard h3'), function (h) { return h.textContent === 'عنوان معدّل'; }); });
  await toStudent(page);
  check('After delete: back to 2 lessons today', /درسان/.test(await txt(page, '#dash-day')) && (await kpis(page)).indexOf('lessons=2') > -1);

  // ===== 5) تبديل الصف: محتوى الصف الجديد فقط ثم العودة =====
  await page.evaluate(function (j) { localStorage.setItem('marsa.classes', j); }, classesJson(DEMO));
  await reload(page);
  await toRep(page);
  await page.click('.nav button:has-text("اللوحة")'); await page.waitForSelector('#page-title');
  await page.click('.tile:has-text("إدارة الصفوف")'); await page.waitForSelector('#page-title');
  await page.click('.cls:has-text("الثالث المتوسط") button:has-text("اختيار")');
  await toStudent(page);
  t = await txt(page, '#dash-grid');
  check('Switch class: second class shows its own empty state (no data of first)', /لم يُسجَّل أي درس بعد/.test(t) && !/أنواع الكابلات|امتحان شهري|تحضير باجر/.test(t) && !(await visibleKpis(page)), t);
  check('Switch class: home card names the new class', /الثالث المتوسط/.test(await txt(page, '#home-card')));
  await seed(page, K.e + TWO, TWO, [rec('x1', { subject: 'العلوم', title: 'امتحان الصف الثاني', examDate: '2026-10-23', status: 'scheduled' }, TWO)]);
  await reload(page);
  t = await txt(page, '#dash-exam');
  check('Second class data appears after reload', /امتحان الصف الثاني/.test(t) && /باجر/.test(t), t);
  await toRep(page);
  await page.click('.nav button:has-text("اللوحة")'); await page.waitForSelector('#page-title');
  await page.click('.tile:has-text("إدارة الصفوف")'); await page.waitForSelector('#page-title');
  await page.click('.cls:has-text("الثاني المهني") button:has-text("اختيار")');
  await toStudent(page);
  check('Switch back: first class data returns', /درسان/.test(await txt(page, '#dash-day')) && /امتحان شهري/.test(await txt(page, '#dash-exam')) && (await kpis(page)).join() === 'lessons=2,periods=2,preps=2,exams=2');

  // ===== 6) تلف بيانات مجموعة: رسالة خطأ لا صفر، ولا عدّاد لها، والبقية سليمة =====
  await page.evaluate(function (k) { localStorage.setItem(k, '{bad json'); }, K.e + DEMO);
  await reload(page);
  t = await txt(page, '#dash-exam');
  check('Corrupt exams: error shown (not zero/empty) and no exams counter', /تعذّرت قراءة الامتحانات/.test(t) && (await kpis(page)).join() === 'lessons=2,periods=2,preps=2', t + ' | ' + (await kpis(page)).join());
  check('Corrupt exams: other cards still fine', /درسان/.test(await txt(page, '#dash-day')));
  check('Corrupt data not overwritten', (await page.evaluate(function (k) { return localStorage.getItem(k); }, K.e + DEMO)) === '{bad json');
  await page.evaluate(function (k) { localStorage.removeItem(k); }, K.e + DEMO);

  // ===== 7) نقر وتنقل بلوحة المفاتيح =====
  await reload(page);
  var map = [['ملخص ما أُخذ اليوم', 'الأرشيف الدراسي'], ['جدول حصص اليوم', 'الجدول الدراسي'], ['آخر تحضير', 'تحاضير اليوم']];
  for (i = 0; i < map.length; i++) {
    await page.click('.panel:has(h3:has-text("' + map[i][0] + '")) .go');
    await page.waitForSelector('#v-page:not([hidden])');
    check('Card «' + map[i][0] + '» navigates to ' + map[i][1], (await txt(page, '#page-title')).indexOf(map[i][1]) > -1, await txt(page, '#page-title'));
    await page.click('.nav button:has-text("الرئيسية")'); await page.waitForSelector('#v-home:not([hidden])');
  }
  // نقر على جسم البطاقة (لا الزر فقط)
  var pnl = await page.$('.panel:has(h3:has-text("أقرب امتحان"))'); await pnl.scrollIntoViewIfNeeded(); await page.waitForTimeout(700); // بعد انتهاء حركة دخول الصفحة
  var box = await pnl.boundingBox();
  await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  await page.waitForSelector('#v-page:not([hidden])');
  check('Tapping the card body (not only the button) navigates', /الامتحانات/.test(await txt(page, '#page-title')));
  await page.click('.nav button:has-text("الرئيسية")'); await page.waitForSelector('#v-home:not([hidden])');
  await page.focus('.panel:has(h3:has-text("أقرب امتحان")) .go');
  await page.keyboard.press('Enter');
  await page.waitForSelector('#v-page:not([hidden])');
  check('Keyboard Enter on card button navigates', /الامتحانات/.test(await txt(page, '#page-title')));
  await page.click('.nav button:has-text("الرئيسية")'); await page.waitForSelector('#v-home:not([hidden])');
  check('One button per card (no duplicate tab stops / listeners)', (await page.$$eval('#dash-grid .panel', function (l) { return l.every(function (p) { return p.querySelectorAll('button').length === 1; }); })));
  var goCount = await page.$$eval('#dash-grid .go', function (l) { return l.length; });
  check('Buttons not duplicated after many re-renders', goCount === 5, String(goCount));
  var tgt = await page.$$eval('#dash-grid .go', function (l) { return l.map(function (b) { var r = b.getBoundingClientRect(); return r.height >= 43.5; }); });
  check('Card buttons are ≥44px tall touch targets', tgt.every(Boolean), JSON.stringify(tgt));

  // ===== 8) مضيّ الوقت (عبور منتصف الليل) وتعديل من تبويب آخر =====
  await seed(page, K.l + DEMO, DEMO, [rec('l1', { subject: 'الشبكات', title: 'درس اليوم', date: '2026-10-22' })]);
  await page.evaluate(function () { window.dispatchEvent(new Event('focus')); });
  check('External change picked up on focus (no manual reload)', /درس اليوم/.test(await txt(page, '#dash-day')) && !/أنواع الكابلات/.test(await txt(page, '#dash-day')));
  await page.clock.fastForward('15:00:00'); // 09:00 → 00:00 اليوم التالي (الجمعة)
  await page.evaluate(function () { window.dispatchEvent(new Event('focus')); });
  t = await txt(page, '#dash-day');
  check('After midnight: nothing is «today» anymore, last lesson shown as before today', /لم يُسجَّل درس اليوم بعد/.test(t) && /درس اليوم/.test(t), t);
  check('After midnight: schedule shows Friday with no periods', /لا حصص ليوم الجمعة/.test(await txt(page, '#dash-sched')), await txt(page, '#dash-sched'));
  await c.ctx.close();

  // ===== 9) شاشات ضيقة: بلا تمرير أفقي، ولوحة اليوم قريبة من الأعلى =====
  var widths = [320, 360, 390, 430];
  for (i = 0; i < widths.length; i++) {
    c = await open(browser, { label: 'w' + widths[i], viewport: { width: widths[i], height: 740 } }); page = c.page;
    await seed(page, K.l + DEMO, DEMO, [rec('l1', { subject: 'مادة بعنوان طويل جداً جداً جداً جداً جداً جداً جداً', title: 'عنوان درس طويل جداً '.repeat(6), date: '2026-10-22' })]);
    await seed(page, K.s + DEMO, DEMO, [rec('s1', { day: 'thu', period: 1, startTime: '08:00', endTime: '08:45', subject: 'مادة طويلة '.repeat(8) })]);
    await seed(page, K.e + DEMO, DEMO, [rec('e1', { subject: 'مادة', title: 'امتحان '.repeat(15), examDate: '2026-10-23', status: 'scheduled', topics: 'مواضيع '.repeat(60) })]);
    await seed(page, K.p + DEMO, DEMO, [rec('p1', { subject: 'مادة', title: 'تحضير '.repeat(15), date: '2026-10-22' })]);
    await reload(page);
    check('Width ' + widths[i] + ': no horizontal scroll on home', !(await overflow(page)));
    var top = await page.$eval('#t-today', function (e) { return Math.round(e.getBoundingClientRect().top + window.scrollY); });
    check('Width ' + widths[i] + ': «لوحة اليوم» heading within first ~' + (widths[i] < 360 ? 640 : 560) + 'px', top < (widths[i] < 360 ? 640 : 560), 'top=' + top);
    if (widths[i] === 360) await shot(page, 'home-long-360');
    await c.ctx.close();
  }
  // ملخص الممثل على 320
  c = await open(browser, { label: 'rep320', viewport: { width: 320, height: 700 } }); page = c.page;
  await toRep(page);
  check('Rep dash 320: no horizontal scroll (empty state)', !(await overflow(page)));
  t = await txt(page, 'section.part');
  check('Rep dash empty: guides how to start, no fake zeros', /ابدأ من «ما أُخذ اليوم»/.test(t) && /ابدأ من «الجدول الدراسي الأسبوعي»/.test(t) && !/: 0|\b0 \(/.test(t), t);
  await shot(page, 'rep-dash-empty-320');
  await c.ctx.close();

  // ===== 10) الوضع الداكن/تقليل الحركة لا يكسران الصفحة، وحقن HTML يبقى نصاً =====
  c = await open(browser, { label: 'xss' }); page = c.page;
  await seed(page, K.l + DEMO, DEMO, [rec('l1', { subject: '<img src=x onerror=window.__x=1>', title: '<b>غامق</b><script>window.__y=1</script>', date: '2026-10-22' })]);
  await reload(page);
  check('User text is rendered as text (no HTML injection) on the dashboard', (await page.$('#dash-day img, #dash-day b b, #dash-day script')) === null && /<b>غامق<\/b>/.test(await txt(page, '#dash-day')) && (await page.evaluate(function () { return window.__x === undefined && window.__y === undefined; })));
  await c.ctx.close();

  await browser.close();
  var failed = results.filter(function (r) { return !r.ok; });
  check('No uncaught JS errors', jsErrors.length === 0, jsErrors.join(' | '));
  failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
