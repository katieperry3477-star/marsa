// تشغيل: node tests/exams-model.test.js  (لا يحتاج مكتبات)
var assert = require('assert'), cp = require('child_process'), path = require('path');
var M = require('../js/exams-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake() { var d = {}; return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { d[k] = String(v); }, removeItem: function (k) { delete d[k]; } }; }
var ok = { subject: 'مادة', title: 'امتحان شهري', examDate: '2026-11-01', status: 'scheduled' };
function v(o) { var x = {}, k; for (k in ok) x[k] = ok[k]; for (k in o) x[k] = o[k]; return M.validate(x); }
function rec(id, date, status, extra) { var r = { recordId: id, classId: 'c1', subject: 's', title: id, createdAt: '2026-10-01T00:00:00.000Z' }; if (date !== null) r.examDate = date; if (status) r.status = status; for (var k in extra) r[k] = extra[k]; return r; }
function ids(l) { return l.map(function (x) { return x.recordId; }).join('|'); }

t('required: subject, title, date; optional: topics, notes; status defaults to scheduled', function () {
  assert.ok(v({}).ok);
  assert.ok(v({ subject: '' }).errors.subject); assert.ok(v({ title: '' }).errors.title); assert.ok(v({ examDate: '' }).errors.examDate);
  assert.ok(v({ topics: '', notes: '' }).ok);
  assert.strictEqual(v({ status: undefined }).values.status, 'scheduled');
});
t('status must be one of the three known values', function () {
  assert.ok(v({ status: 'held' }).ok); assert.ok(v({ status: 'cancelled' }).ok);
  assert.ok(v({ status: 'done' }).errors.status); assert.ok(v({ status: 'مجدول' }).errors.status);
});
t('invisible-only/whitespace text is empty; multiline keeps newlines', function () {
  assert.ok(v({ title: '​‏‮ ' }).errors.title);
  assert.ok(v({ subject: '   ' }).errors.subject);
  var r = v({ topics: 'الفصل 1\r\n\r\n\r\n\r\nالفصل 2  ' });
  assert.strictEqual(r.values.topics, 'الفصل 1\n\nالفصل 2');
});
t('length limits enforced per field (at limit ok, over limit rejected)', function () {
  var L = M.LIMITS, k;
  for (k in L) { var o = {}; o[k] = new Array(L[k] + 2).join('ا'); assert.ok(v(o).errors[k], k + ' over'); o[k] = new Array(L[k] + 1).join('ا'); assert.ok(!v(o).errors[k], k + ' at limit'); }
});
t('date validation: format, real day, range; past and future accepted', function () {
  assert.ok(v({ examDate: '2026-02-30' }).errors.examDate); assert.ok(v({ examDate: '01-11-2026' }).errors.examDate); assert.ok(v({ examDate: '1999-12-31' }).errors.examDate); assert.ok(v({ examDate: '2101-01-01' }).errors.examDate);
  assert.ok(v({ examDate: '2028-02-29' }).ok); assert.ok(v({ examDate: '2020-01-01' }).ok);
});
t('firstError follows field order', function () { assert.strictEqual(v({ subject: '', examDate: '' }).firstError, 'subject'); assert.strictEqual(v({ examDate: '', status: 'x' }).firstError, 'examDate'); });
t('markup stays plain text verbatim', function () { var r = v({ title: '<img src=x onerror=alert(1)>' }); assert.ok(r.ok); assert.strictEqual(r.values.title, '<img src=x onerror=alert(1)>'); });
t('buildRecord: keeps existing keys (recordId/classId/createdAt), drops emptied optionals, never adds score/questions', function () {
  var ex = { recordId: 'exam_1', classId: 'c1', createdAt: 'X', topics: 'قديم', notes: 'قديم', extra: 1 };
  var b = M.buildRecord(v({ topics: '', notes: 'جديد' }).values, ex);
  assert.strictEqual(b.recordId, 'exam_1'); assert.strictEqual(b.classId, 'c1'); assert.strictEqual(b.createdAt, 'X'); assert.strictEqual(b.extra, 1);
  assert.ok(!('topics' in b)); assert.strictEqual(b.notes, 'جديد'); assert.strictEqual(b.examDate, '2026-11-01');
  assert.ok(!('score' in b) && !('grade' in b) && !('questions' in b) && !('date' in b));
  assert.ok(!('recordId' in M.buildRecord(v({}).values, null)));
});
t('partition: upcoming = scheduled & date >= today, ascending; today counts as upcoming', function () {
  var p = M.partition([rec('c', '2026-11-05'), rec('a', '2026-10-22'), rec('b', '2026-10-30'), rec('z', '2026-10-21')], '2026-10-22');
  assert.strictEqual(ids(p.upcoming), 'a|b|c'); assert.strictEqual(ids(p.finished), 'z');
});
t('partition: date passed does NOT cancel or mark held (stays scheduled, flagged overdue, in finished)', function () {
  var r = rec('old', '2026-10-01'), p = M.partition([r], '2026-10-22');
  assert.strictEqual(M.statusOf(r), 'scheduled'); assert.ok(M.isOverdue(r, '2026-10-22')); assert.ok(!M.isUpcoming(r, '2026-10-22'));
  assert.strictEqual(ids(p.finished), 'old'); assert.strictEqual(r.status, undefined);
});
t('partition: held/cancelled go to finished at any date; changing status or date moves the record', function () {
  var today = '2026-10-22', held = rec('h', '2026-12-01', 'held'), canc = rec('c', '2026-12-02', 'cancelled'), s = rec('s', '2026-12-03', 'scheduled');
  var p = M.partition([held, canc, s], today);
  assert.strictEqual(ids(p.upcoming), 's');
  assert.strictEqual(ids(p.finished).split('|').sort().join(), 'c,h');
  var s2 = M.buildRecord(M.validate({ subject: 's', title: 's', examDate: '2026-12-03', status: 'held' }).values, s);
  assert.strictEqual(ids(M.partition([s2], today).finished), 's');
  var s3 = M.buildRecord(M.validate({ subject: 's', title: 's', examDate: '2026-10-01', status: 'scheduled' }).values, s);
  assert.strictEqual(ids(M.partition([s3], today).finished), 's');
});
t('partition: finished newest first, then invalid/missing date last; ties by createdAt then recordId', function () {
  var p = M.partition([rec('nodate', null), rec('a', '2026-09-01'), rec('b', '2026-10-01'), rec('c', '2026-10-01', null, { createdAt: '2026-09-01T00:00:00.000Z' }), rec('d', '2026-10-01', 'cancelled')], '2026-10-22');
  assert.strictEqual(ids(p.finished), 'c|b|d|a|nodate');
});
t('partition: unknown stored status is treated as scheduled and not hidden', function () {
  var r = rec('u', '2026-12-01', 'weird'); assert.strictEqual(M.statusOf(r), 'scheduled'); assert.strictEqual(ids(M.partition([r], '2026-10-22').upcoming), 'u');
});
t('partition does not mutate input; relativeLabel by calendar days', function () {
  var l = [rec('b', '2026-10-30'), rec('a', '2026-10-25')], copy = JSON.stringify(l); M.partition(l, '2026-10-22'); assert.strictEqual(JSON.stringify(l), copy);
  assert.strictEqual(M.relativeLabel('2026-10-22', '2026-10-22'), 'اليوم'); assert.strictEqual(M.relativeLabel('2026-10-23', '2026-10-22'), 'باجر');
  assert.strictEqual(M.relativeLabel('2026-10-24', '2026-10-22'), 'بعد يومين'); assert.strictEqual(M.relativeLabel('2026-10-27', '2026-10-22'), 'بعد 5 أيام'); assert.strictEqual(M.relativeLabel('2026-12-22', '2026-10-22'), 'بعد 61 يوماً');
  assert.strictEqual(M.relativeLabel('2026-10-21', '2026-10-22'), '');
});
t('integration with store: add, edit by same recordId, delete; classes independent; no key for other types', function () {
  var fk = fake(), st = S.create({ storage: fk }), a, b, id, e;
  a = st.upsertRecord('exams', 'c1', M.buildRecord(v({ topics: 'ف1' }).values, null));
  assert.ok(a.ok && a.created && /^exam_/.test(a.record.recordId));
  id = a.record.recordId;
  e = st.upsertRecord('exams', 'c1', M.buildRecord(v({ title: 'معدّل', status: 'held' }).values, st.getRecord('exams', 'c1', id).record));
  assert.ok(e.ok && !e.created && e.records.length === 1 && e.record.recordId === id && e.record.createdAt === a.record.createdAt && e.record.status === 'held');
  b = st.upsertRecord('exams', 'c2', M.buildRecord(v({}).values, null));
  assert.strictEqual(st.readCollection('exams', 'c1').records.length, 1); assert.strictEqual(st.readCollection('exams', 'c2').records.length, 1);
  assert.deepStrictEqual(Object.keys(fk.d).sort(), ['marsa.academic.exams.c1', 'marsa.academic.exams.c2']);
  assert.ok(st.deleteRecord('exams', 'c1', id).ok); assert.strictEqual(st.readCollection('exams', 'c1').records.length, 0);
  assert.strictEqual(st.readCollection('exams', 'c2').records.length, 1);
});
t('store rejects an invalid examDate and write failure leaves data unchanged', function () {
  var fk = fake(), st = S.create({ storage: fk }), a = st.upsertRecord('exams', 'c1', M.buildRecord(v({}).values, null)), before = fk.d['marsa.academic.exams.c1'], bad, fail;
  bad = st.upsertRecord('exams', 'c1', { subject: 's', title: 't', examDate: '2026-13-40' }); assert.ok(!bad.ok);
  fk.setItem = function () { throw new Error('quota'); };
  fail = st.upsertRecord('exams', 'c1', M.buildRecord(v({ title: 'جديد' }).values, null)); assert.ok(!fail.ok && fail.status === 'write-failed');
  assert.strictEqual(fk.d['marsa.academic.exams.c1'], before);
});
t('subjectsOf returns only user-entered subjects, deduped ignoring diacritics', function () {
  assert.strictEqual(M.subjectsOf([]).length, 0);
  assert.strictEqual(M.subjectsOf([rec('a', '2026-10-30', null, { subject: 'الرياضيات' }), rec('b', '2026-10-30', null, { subject: 'الرياضيّات' }), rec('c', '2026-10-30', null, { subject: 'فيزياء' })]).length, 2);
});
// المنطقة الزمنية: الفاصل بين «قادم» و«سابق» يتبع اليوم المحلي لا UTC (عملية فرعية لكل TZ)
var CASES = [
  ['Asia/Baghdad', '2026-10-22T23:30:00+03:00', '2026-10-22'], ['Asia/Baghdad', '2026-10-23T00:30:00+03:00', '2026-10-23'],
  ['UTC', '2026-10-22T23:59:00Z', '2026-10-22'], ['America/Los_Angeles', '2026-03-08T01:30:00-08:00', '2026-03-08'],
  ['Pacific/Kiritimati', '2026-10-22T00:30:00+14:00', '2026-10-22'], ['Pacific/Pago_Pago', '2026-10-22T23:30:00-11:00', '2026-10-22']
];
CASES.forEach(function (c) {
  t('TZ ' + c[0] + ' at ' + c[1] + ': local today ' + c[2] + '; exam today upcoming, yesterday finished, +1 = باجر', function () {
    var code = "var S=require('./js/academic-store.js'),M=require('./js/exams-model.js');var RealDate=Date;var fixed=new RealDate('" + c[1] + "').getTime();" +
      "global.Date=class extends RealDate{constructor(...a){if(a.length===0){super(fixed);}else{super(...a);}} static now(){return fixed;}};" +
      "var today=S.toLocalDate();var rs=[{recordId:'t',examDate:today},{recordId:'y',examDate:M.addDays(today,-1)},{recordId:'n',examDate:M.addDays(today,1)}];" +
      "var p=M.partition(rs,today);console.log(JSON.stringify({today:today,up:p.upcoming.map(function(x){return x.recordId}),fin:p.finished.map(function(x){return x.recordId}),rel:M.relativeLabel(M.addDays(today,1),today),d2:M.daysBetween(today,M.addDays(today,30))}));";
    var out = JSON.parse(cp.execFileSync(process.execPath, ['-e', code], { cwd: path.join(__dirname, '..'), env: Object.assign({}, process.env, { TZ: c[0] }) }).toString().trim());
    assert.strictEqual(out.today, c[2]); assert.deepStrictEqual(out.up, ['t', 'n']); assert.deepStrictEqual(out.fin, ['y']); assert.strictEqual(out.rel, 'باجر'); assert.strictEqual(out.d2, 30);
  });
});
t('daysBetween is DST-safe (US spring-forward week, 2026-03-08)', function () {
  assert.strictEqual(M.daysBetween('2026-03-07', '2026-03-09'), 2); assert.strictEqual(M.daysBetween('2026-10-31', '2026-11-02'), 2); assert.strictEqual(M.daysBetween('bad', '2026-11-02'), null);
});
t('filterRecords (03.8): empty query returns a copy; matches subject/title/topics with Arabic normalisation; no match -> []', function () {
  var L = [{ recordId: 'a', subject: 'الرياضيات', title: 'امتحان شهري', topics: 'الفصل الأول' }, { recordId: 'b', subject: 'العلوم', title: 'اختبار', topics: 'أنظمة الإدارة' }];
  var all = M.filterRecords(L, ''); assert.deepStrictEqual(all.map(function (x) { return x.recordId; }), ['a', 'b']); assert.notStrictEqual(all, L);
  assert.deepStrictEqual(M.filterRecords(L, 'رياضيات').map(function (x) { return x.recordId; }), ['a']);
  assert.deepStrictEqual(M.filterRecords(L, 'اختبار').map(function (x) { return x.recordId; }), ['b']);
  assert.deepStrictEqual(M.filterRecords(L, 'الاداره').map(function (x) { return x.recordId; }), ['b']);
  assert.deepStrictEqual(M.filterRecords(L, 'xyz'), []);
  assert.strictEqual(L.length, 2);
});
console.log('\n' + n + ' passed, ' + f + ' failed');
process.exit(f ? 1 : 0);
