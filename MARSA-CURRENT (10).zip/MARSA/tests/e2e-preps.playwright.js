// اختبار واجهة المرحلة 03.3 (التحاضير) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-preps.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة، بساعة مزيّفة ثابتة البداية، ويحقن بيانات الاختبار في تخزين السياق المؤقت فقط.
var pw = require('playwright'), path = require('path'), fs = require('fs');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
// 2026-10-22 09:00 بتوقيت بغداد (UTC+3)
var NOW = '2026-10-22T06:00:00Z';
async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: opts.tz || 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: !!opts.touch, isMobile: !!opts.touch });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(opts.clock || NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")');
  await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
  await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toPrep(page) { await page.click('.nav button:has-text("التحاضير")'); await page.waitForSelector('#page-title'); }
async function toLessons(page) { await page.click('.nav button:has-text("ما أُخذ اليوم")'); await page.waitForSelector('#page-title'); }
async function fill(page, o) {
  if (o.subject !== undefined) await page.fill('#pf-subject', o.subject);
  if (o.title !== undefined) await page.fill('#pf-title', o.title);
  if (o.date !== undefined) await page.fill('#pf-date', o.date);
  if (o.content !== undefined) await page.fill('#pf-content', o.content);
  var opt = ['pages', 'homework', 'notes'].filter(function (k) { return o[k] !== undefined; });
  if (opt.length) {
    if (!(await page.$eval('details.opt', function (d) { return d.open; }))) await page.click('details.opt summary');
    for (var i = 0; i < opt.length; i++) await page.fill('#pf-' + opt[i], o[opt[i]]);
  }
}
async function addPrep(page, o) {
  await page.click('button:has-text("إضافة تحضير")');
  await fill(page, o);
  await page.click('button:has-text("حفظ التحضير")');
  await page.waitForSelector('.lform', { state: 'hidden' });
}
async function store(page, key) { return page.evaluate(function (k) { var r = localStorage.getItem(k); return r === null ? null : JSON.parse(r); }, key); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function keys(page) { return page.evaluate(function () { var o = []; for (var i = 0; i < localStorage.length; i++) o.push(localStorage.key(i)); return o.sort(); }); }
async function group(page, g) { return page.$$eval('.pgroup[data-group="' + g + '"] .pcard h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function allCards(page) { return page.$$eval('.pcard h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function toast(page) { return page.$eval('#status', function (s) { return s.textContent; }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
var KEY = 'marsa.academic.preparations.cls_demo_001', LKEY = 'marsa.academic.dailyLessons.cls_demo_001';

(async function main() {
  var browser = await pw.chromium.launch();
  var c, page, col, rec, before, after;

  // ===== 1) بداية نظيفة =====
  c = await open(browser, { label: 'fresh' }); page = c.page;
  await toRep(page);
  var navTexts = await page.$$eval('.nav button', function (l) { return l.map(function (b) { return b.textContent; }); });
  check('Nav (rep): exactly one «التحاضير» tab and «ما أُخذ اليوم» still present', navTexts.filter(function (x) { return x === 'التحاضير'; }).length === 1 && navTexts.indexOf('ما أُخذ اليوم') > -1, navTexts.join('|'));
  await toPrep(page);
  check('Route opens r-prep page', (await page.getAttribute('html', 'data-view')) === 'r-prep');
  check('Old placeholder (disabled «إضافة تحضير» + «يُفعّل في مرحلة لاحقة» + archive part) is gone', (await page.$('.page-head .act')) === null && !/الأرشيف الدراسي|يُفعّل في مرحلة لاحقة/.test(await page.textContent('#v-page')));
  check('Fresh start: no fake preps; empty state explains how to start', (await allCards(page)).length === 0 && /لم تُضف أي تحاضير/.test(await page.textContent('#v-page .empty')) && /إضافة تحضير/.test(await page.textContent('#v-page .empty')));
  check('Fresh start: opening page writes NO academic key', (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0; }).length === 0, (await keys(page)).join(','));
  check('Fresh start: search hidden, count 0, class bar shown', (await page.$eval('input[type=search]', function (e) { return e.hidden || getComputedStyle(e).display === 'none'; })) && /عدد التحاضير: 0/.test(await page.textContent('.count')) && (await page.$('.classbar')) !== null);
  check('Semantic separation note + link to «ما أُخذ اليوم» present', /ما أُخذ اليوم/.test(await page.textContent('.sepnote')) && /لا يُنسخ/.test(await page.textContent('.sepnote')) && (await page.$('.sepnote button')) !== null);

  // ===== 2) النموذج والتحقق =====
  await page.click('button:has-text("إضافة تحضير")');
  check('Form: 4 required marked, optionals collapsed', (await page.$eval('details.opt', function (d) { return !d.open; })) && /مطلوب/.test(await page.textContent('label[for=pf-subject]')) && /مطلوب/.test(await page.textContent('label[for=pf-content]')) && /اختياري/.test(await page.textContent('label[for=pf-pages]')) && /اختياري/.test(await page.textContent('label[for=pf-homework]')) && /اختياري/.test(await page.textContent('label[for=pf-notes]')));
  check('Default date = local tomorrow (2026-10-23)', (await page.inputValue('#pf-date')) === '2026-10-23', await page.inputValue('#pf-date'));
  await page.click('button:has-text("حفظ التحضير")');
  check('Empty required: errors on subject/title/content, focus first, nothing saved', /المادة/.test(await page.textContent('#pf-subject-e')) && /عنوان/.test(await page.textContent('#pf-title-e')) && /محتوى/.test(await page.textContent('#pf-content-e')) && (await page.evaluate(function () { return document.activeElement.id; })) === 'pf-subject' && (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0; }).length === 0);
  await fill(page, { subject: '  ', title: '  ', content: '   \n ' });
  await page.click('button:has-text("حفظ التحضير")');
  check('Whitespace-only rejected', /اسم المادة/.test(await page.textContent('#pf-subject-e')) && /محتوى/.test(await page.textContent('#pf-content-e')));
  check('maxlength attributes from limits', (await page.$eval('#pf-subject', function (e) { return e.maxLength; })) === 80 && (await page.$eval('#pf-title', function (e) { return e.maxLength; })) === 120 && (await page.$eval('#pf-content', function (e) { return e.maxLength; })) === 2000);
  await fill(page, { subject: 'مادة أ', title: 'تحضير باجر', content: 'نقطة 1\nنقطة 2', date: '' });
  await page.click('button:has-text("حفظ التحضير")');
  check('Cleared date rejected', /اختر تاريخ/.test(await page.textContent('#pf-date-e')) && (await page.evaluate(function () { return document.activeElement.id; })) === 'pf-date');

  // ===== 3) تجميع اليوم / باجر / أخرى بالتاريخ المحلي =====
  await fill(page, { date: '2026-10-23', pages: 'ص 10-12', homework: 'حل التمرين 3', notes: 'ملاحظة' });
  await page.click('button:has-text("حفظ التحضير")');
  await page.waitForSelector('.pcard');
  check('Add: success toast and form closed', /تم حفظ التحضير/.test(await toast(page)) && (await page.$('.lform:not([hidden])')) === null);
  col = await store(page, KEY); rec = col.records[0];
  check('Stored: schemaVersion 1, classId cls_demo_001, type preparations key only', col.schemaVersion === 1 && col.classId === 'cls_demo_001' && col.records.length === 1 && (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0; }).join() === KEY);
  check('Stored record fields (prep_ id, classId, content with newline, optionals, local date)', /^prep_/.test(rec.recordId) && rec.classId === 'cls_demo_001' && rec.date === '2026-10-23' && rec.content === 'نقطة 1\nنقطة 2' && rec.pages === 'ص 10-12' && rec.homework === 'حل التمرين 3' && rec.notes === 'ملاحظة' && rec.subject === 'مادة أ' && rec.title === 'تحضير باجر', JSON.stringify(rec));
  await addPrep(page, { subject: 'مادة ب', title: 'تحضير اليوم', date: '2026-10-22', content: 'محتوى اليوم' });
  await addPrep(page, { subject: 'مادة أ', title: 'تحضير بعيد', date: '2026-10-30', content: 'محتوى بعيد' });
  await addPrep(page, { subject: 'مادة ج', title: 'تحضير ماضٍ', date: '2026-10-10', content: 'محتوى ماضٍ' });
  await addPrep(page, { subject: 'مادة ب', title: 'تحضير أقرب', date: '2026-10-25', content: 'محتوى أقرب' });
  check('Today group has only today prep', (await group(page, 'today')).join('|') === 'تحضير اليوم', (await group(page, 'today')).join('|'));
  check('Tomorrow group has only tomorrow prep', (await group(page, 'tomorrow')).join('|') === 'تحضير باجر', (await group(page, 'tomorrow')).join('|'));
  check('Other group separate and sorted nearest first (future ascending, then past)', (await group(page, 'other')).join('|') === 'تحضير أقرب|تحضير بعيد|تحضير ماضٍ', (await group(page, 'other')).join('|'));
  check('Group order on page: اليوم, باجر, تحاضير أخرى', (await page.$$eval('.pgroup h2', function (l) { return l.map(function (h) { return h.textContent.replace(/\s*\(\d+\)/, ''); }); })).join('|') === 'اليوم|باجر|تحاضير أخرى');
  check('Tags: اليوم / باجر / مضى موعده', /اليوم/.test(await page.textContent('.pgroup[data-group=today] .tag.on')) && /باجر/.test(await page.textContent('.pgroup[data-group=tomorrow] .tag.on')) && /مضى موعده/.test(await page.textContent('.pgroup[data-group=other] .pcard:has-text("ماضٍ")')));
  check('Card shows multi-line content with pre-wrap + optional fields', (await page.$eval('.pgroup[data-group=tomorrow] .lc-t', function (e) { return getComputedStyle(e).whiteSpace; })) === 'pre-wrap' && /حل التمرين 3/.test(await page.textContent('.pgroup[data-group=tomorrow] .pcard')) && /ص 10-12/.test(await page.textContent('.pgroup[data-group=tomorrow] .pcard')));
  check('Count shows 5', /عدد التحاضير: 5/.test(await page.textContent('.count')));

  // ===== 4) بحث =====
  await page.fill('input[type=search]', 'مادة ب');
  check('Search by subject across groups (empty groups hidden)', (await allCards(page)).join('|') === 'تحضير اليوم|تحضير أقرب' && (await page.$('.pgroup[data-group=tomorrow]')) === null && /النتائج: 2 من 5/.test(await page.textContent('.resc')), (await allCards(page)).join('|'));
  await page.fill('input[type=search]', 'بعيد');
  check('Search by title', (await allCards(page)).join('|') === 'تحضير بعيد');
  await page.fill('input[type=search]', 'محتوى اليوم');
  check('Search does NOT match content text', (await allCards(page)).length === 0 && /لا توجد تحاضير مطابقة/.test(await page.textContent('main')));
  await page.fill('input[type=search]', 'ماض');
  check('Search ignores diacritics (title «ماضٍ» found by «ماض»)', (await allCards(page)).join('|') === 'تحضير ماضٍ');
  await page.fill('input[type=search]', '');
  check('Cleared search restores all groups', (await allCards(page)).length === 5 && (await page.$$('.pgroup')).length === 3);
  await page.click('button:has-text("إضافة تحضير")');
  var sugg = await page.$$eval('#pf-subjects option', function (l) { return l.map(function (o) { return o.value; }).sort(); });
  check('datalist has only user-entered subjects', sugg.join('|') === ['مادة أ', 'مادة ب', 'مادة ج'].sort().join('|'), sugg.join('|'));
  await page.click('.lform button:has-text("إلغاء")');
  check('Cancel on untouched form closes it without confirm', (await page.$('.lform:not([hidden])')) === null);

  // ===== 5) تعديل: recordId ثابت والتحاضير تنتقل بين الأقسام =====
  before = (await store(page, KEY)).records.filter(function (x) { return x.title === 'تحضير بعيد'; })[0];
  await page.click('.pcard:has-text("تحضير بعيد") button:has-text("تعديل")');
  check('Edit prefilled incl. content', (await page.inputValue('#pf-title')) === 'تحضير بعيد' && (await page.inputValue('#pf-date')) === '2026-10-30' && (await page.inputValue('#pf-content')) === 'محتوى بعيد');
  await page.fill('#pf-title', 'تحضير بعيد (معدّل)'); await page.fill('#pf-date', '2026-10-23');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.pcard:has-text("معدّل")');
  after = (await store(page, KEY)).records.filter(function (x) { return x.title === 'تحضير بعيد (معدّل)'; })[0];
  check('Edit: same recordId/classId/createdAt, no new record', after && after.recordId === before.recordId && after.classId === before.classId && after.createdAt === before.createdAt && (await store(page, KEY)).records.length === 5);
  check('Edit: updatedAt set; untouched fields kept', after.updatedAt && after.content === 'محتوى بعيد' && after.date === '2026-10-23');
  check('Edit: card moved from «أخرى» to «باجر», toast shown', (await group(page, 'tomorrow')).indexOf('تحضير بعيد (معدّل)') > -1 && (await group(page, 'other')).indexOf('تحضير بعيد (معدّل)') === -1 && /تم حفظ التعديل/.test(await toast(page)), (await group(page, 'tomorrow')).join('|'));
  await page.click('.pcard:has-text("تحضير باجر") button:has-text("تعديل")');
  await page.fill('#pf-pages', ''); await page.fill('#pf-homework', '');
  await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  rec = (await store(page, KEY)).records.filter(function (x) { return x.title === 'تحضير باجر'; })[0];
  check('Edit: emptied optionals removed from record, others kept', !('pages' in rec) && !('homework' in rec) && rec.notes === 'ملاحظة');

  // ===== 6) حماية النموذج المتسخ =====
  await page.click('.pcard:has-text("تحضير اليوم") button:has-text("تعديل")');
  await page.fill('#pf-title', 'تغيير غير محفوظ');
  await page.click('.pcard:has-text("تحضير ماضٍ") button:has-text("تعديل")');
  check('Dirty form: switching asks to confirm', (await page.$eval('#dlg-confirm', function (d) { return d.open; })) && /تجاهل/.test(await page.textContent('#dlg-confirm-body')));
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  check('Dirty form: cancel keeps typed text', (await page.inputValue('#pf-title')) === 'تغيير غير محفوظ');
  await page.click('.lform button:has-text("إلغاء")');
  await page.click('#dlg-confirm-body button:has-text("تجاهل والمتابعة")');
  check('Dirty form: confirm discards; record unchanged', (await page.$('.lform:not([hidden])')) === null && (await group(page, 'today')).join() === 'تحضير اليوم');

  // ===== 7) حذف بتأكيد =====
  await page.click('.pcard:has-text("تحضير ماضٍ") button:has-text("حذف")');
  check('Delete: confirmation names the record, warns irreversible, says lessons unaffected', (await page.$eval('#dlg-confirm', function (d) { return d.open; })) && /تحضير ماضٍ/.test(await page.textContent('#dlg-confirm-body')) && /لا يمكن التراجع/.test(await page.textContent('#dlg-confirm-body')) && /ما أُخذ اليوم/.test(await page.textContent('#dlg-confirm-body')));
  await page.click('#dlg-confirm-body button:has-text("إلغاء")');
  check('Delete cancelled: still there', (await allCards(page)).length === 5 && (await store(page, KEY)).records.length === 5);
  await page.click('.pcard:has-text("تحضير ماضٍ") button:has-text("حذف")');
  await page.click('#dlg-confirm-body button:has-text("حذف التحضير")');
  check('Delete confirmed: removed from list and storage + toast', (await allCards(page)).indexOf('تحضير ماضٍ') === -1 && (await store(page, KEY)).records.length === 4 && /تم حذف التحضير/.test(await toast(page)));

  // ===== 8) إعادة التحميل =====
  await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  await page.click('.seg button[data-m="rep"]').catch(function () { });
  check('Reload: stored data survives (preps in storage)', (await store(page, KEY)).records.length === 4);
  await c.ctx.close();

  // ===== 9) فصل عن «ما أُخذ اليوم» وعن الصفوف الأخرى =====
  c = await open(browser, { label: 'sep' }); page = c.page; await toRep(page); await toPrep(page);
  await addPrep(page, { subject: 'م', title: 'عنوان مشترك', date: '2026-10-22', content: 'تحضير' });
  var lraw0 = await raw(page, LKEY);
  check('Adding a prep does not create/touch the lessons key', lraw0 === null && (await keys(page)).indexOf(LKEY) === -1);
  await toLessons(page);
  check('Lessons page shows nothing from preps (no auto copy)', (await page.$$('.lcard')).length === 0 && /لم تُسجَّل أي دروس/.test(await page.textContent('#v-page .empty')));
  await page.click('button:has-text("إضافة سجل درس")');
  await page.fill('#lf-subject', 'م'); await page.fill('#lf-title', 'عنوان مشترك'); await page.fill('#lf-date', '2026-10-22');
  await page.click('button:has-text("حفظ السجل")'); await page.waitForSelector('.lcard');
  var lraw1 = await raw(page, LKEY), praw1 = await raw(page, KEY);
  check('Lesson record created independently (dl_ id) with the same title', /"recordId":"dl_/.test(lraw1) && (await store(page, LKEY)).records.length === 1);
  await toPrep(page);
  check('Prep page unaffected by lesson with same title (1 prep only, not duplicated)', (await allCards(page)).join('|') === 'عنوان مشترك' && (await group(page, 'today')).length === 1);
  await page.click('.pcard button:has-text("تعديل")'); await page.fill('#pf-content', 'تحضير معدّل'); await page.click('button:has-text("حفظ التعديل")'); await page.waitForSelector('.lform', { state: 'hidden' });
  check('Editing a prep leaves lessons bytes untouched', (await raw(page, LKEY)) === lraw1);
  await page.click('.pcard button:has-text("حذف")'); await page.click('#dlg-confirm-body button:has-text("حذف التحضير")');
  check('Deleting a prep leaves lessons bytes untouched and lesson still listed', (await raw(page, LKEY)) === lraw1 && (await store(page, KEY)).records.length === 0);
  await toLessons(page);
  check('Lesson still shown after prep deleted', (await page.$$('.lcard')).length === 1);
  // صف آخر
  await toPrep(page);
  await addPrep(page, { subject: 'م', title: 'تحضير الصف التجريبي', date: '2026-10-22', content: 'ج' });
  var demoRaw = await raw(page, KEY);
  await page.click('.nav button:has-text("اللوحة")'); await page.click('.tile:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")');
  await page.fill('#cf-stage', 'الثالث المتوسط'); await page.fill('#cf-section', 'ب');
  await page.check('.cform .chk input'); await page.click('button:has-text("إضافة الصف")');
  await page.waitForFunction(function () { return !document.getElementById('dlg-class').open; });
  await toPrep(page);
  var otherId = await page.getAttribute('main', 'data-class-id');
  check('Second class starts with EMPTY preps (no mixing)', (await allCards(page)).length === 0 && /لم تُضف أي تحاضير/.test(await page.textContent('#v-page .empty')));
  await addPrep(page, { subject: 'ج', title: 'تحضير الصف الآخر', date: '2026-10-23', content: 'ج' });
  colB = await store(page, 'marsa.academic.preparations.' + otherId);
  var colB;
  check('Other class saved under its own key/classId', colB && colB.classId === otherId && otherId !== 'cls_demo_001' && colB.records.length === 1 && colB.records[0].classId === otherId);
  check('Demo class collection bytes untouched by other-class add', (await raw(page, KEY)) === demoRaw);
  await page.selectOption('#cb-sel', 'cls_demo_001'); await page.waitForSelector('.pcard:has-text("الصف التجريبي")');
  check('Switch back: only demo preps', (await allCards(page)).join('|') === 'تحضير الصف التجريبي', (await allCards(page)).join('|'));
  await page.selectOption('#cb-sel', otherId); await page.waitForSelector('.pcard:has-text("الصف الآخر")');
  check('Switch to other: only its prep', (await allCards(page)).join('|') === 'تحضير الصف الآخر');
  await page.click('.classbar button:has-text("إدارة الصفوف")');
  await page.click('.cls:has-text("الثالث المتوسط") button:has-text("حذف نهائي")');
  check('Class with preps cannot be permanently deleted (explained)', /السجلات الدراسية/.test(await page.textContent('#dlg-confirm-body')) && (await store(page, 'marsa.academic.preparations.' + otherId)) !== null);
  await page.click('#dlg-confirm-body button:has-text("حسناً")');
  await c.ctx.close();

  // ===== 10) فشل الحفظ =====
  c = await open(browser, { label: 'fail' }); page = c.page; await toRep(page); await toPrep(page);
  await page.click('button:has-text("إضافة تحضير")');
  await fill(page, { subject: 'مادة', title: 'لن يُحفظ الآن', date: '2026-10-23', content: 'نص طويل أدخله المستخدم', notes: 'ملاحظة' });
  await page.evaluate(function () { window.__orig = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (String(k).indexOf('marsa.academic') === 0) throw new Error('QuotaExceededError'); return window.__orig.call(this, k, v); }; });
  await page.click('button:has-text("حفظ التحضير")');
  check('Failed add: error inside form (not saved, retry hint)', /لم يُحفظ التحضير/.test(await page.textContent('#pf-msg')) && /أعد المحاولة/.test(await page.textContent('#pf-msg')), await page.textContent('#pf-msg'));
  check('Failed add: ALL typed data kept', (await page.inputValue('#pf-title')) === 'لن يُحفظ الآن' && (await page.inputValue('#pf-subject')) === 'مادة' && (await page.inputValue('#pf-content')) === 'نص طويل أدخله المستخدم' && (await page.inputValue('#pf-notes')) === 'ملاحظة' && (await page.inputValue('#pf-date')) === '2026-10-23');
  check('Failed add: NO success toast, no card, nothing in storage', !/تم حفظ/.test(await toast(page)) && (await allCards(page)).length === 0 && (await keys(page)).filter(function (x) { return x.indexOf('marsa.academic') === 0; }).length === 0);
  check('Failed add: submit usable again', !(await page.$eval('button:has-text("حفظ التحضير")', function (b) { return b.disabled; })));
  await page.evaluate(function () { Storage.prototype.setItem = window.__orig; });
  await page.click('button:has-text("حفظ التحضير")'); await page.waitForSelector('.pcard');
  check('Retry after recovery: saved once with success toast', (await allCards(page)).join() === 'لن يُحفظ الآن' && /تم حفظ التحضير/.test(await toast(page)) && (await store(page, KEY)).records.length === 1);
  // فشل تعديل
  await page.click('.pcard button:has-text("تعديل")'); await page.fill('#pf-title', 'عنوان جديد لن يُحفظ');
  await page.evaluate(function () { window.__orig = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (String(k).indexOf('marsa.academic') === 0) throw new Error('QuotaExceededError'); return window.__orig.call(this, k, v); }; });
  await page.click('button:has-text("حفظ التعديل")');
  check('Failed edit: error + form kept + storage record unchanged + no success toast', /لم يُحفظ التحضير/.test(await page.textContent('#pf-msg')) && (await page.inputValue('#pf-title')) === 'عنوان جديد لن يُحفظ' && (await store(page, KEY)).records[0].title === 'لن يُحفظ الآن' && !/تم حفظ التعديل/.test(await toast(page)));
  await page.click('.lform button:has-text("إلغاء")'); await page.click('#dlg-confirm-body button:has-text("تجاهل والمتابعة")');
  // فشل حذف
  await page.click('.pcard button:has-text("حذف")'); await page.click('#dlg-confirm-body button:has-text("حذف التحضير")');
  check('Failed delete: record still listed and stored; no «تم حذف» toast', (await allCards(page)).length === 1 && (await store(page, KEY)).records.length === 1 && !/تم حذف/.test(await toast(page)) && /لم يُحذف/.test(await toast(page)), await toast(page));
  await page.evaluate(function () { Storage.prototype.setItem = window.__orig; });
  await c.ctx.close();

  // ===== 11) تخزين مؤقت فقط =====
  c = await open(browser, { label: 'temp', init: function () { try { Object.defineProperty(window, 'localStorage', { get: function () { throw new Error('blocked'); } }); } catch (e) { } } }); page = c.page;
  await toRep(page); await toPrep(page);
  check('Blocked storage: «مؤقتة» banner on prep page', /مؤقتة/.test(await page.textContent('#v-page .warnbox')), await page.textContent('main'));
  await addPrep(page, { subject: 'م', title: 'مؤقت', date: '2026-10-23', content: 'ج' });
  check('Blocked storage: record visible in session and toast says NOT permanent', (await allCards(page)).join() === 'مؤقت' && /ليس بشكل دائم/.test(await toast(page)), await toast(page));
  await c.ctx.close();

  // ===== 12) بيانات تالفة =====
  c = await open(browser, { label: 'corrupt', init: function () { try { if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); localStorage.setItem('marsa.academic.preparations.cls_demo_001', '{broken'); } } catch (e) { } } }); page = c.page;
  await toRep(page); await toPrep(page);
  check('Corrupt collection: warning shown, add disabled, bytes unchanged, backup made', /تالفة/.test(await page.textContent('#v-page .warnbox')) && (await page.$eval('button:has-text("إضافة تحضير")', function (b) { return b.disabled; })) && (await raw(page, 'marsa.academic.preparations.cls_demo_001')) === '{broken' && (await keys(page)).some(function (k) { return k.indexOf('marsa.academic.preparations.cls_demo_001.backup') === 0; }));
  await c.ctx.close();

  // ===== 13) النص كنص (XSS) =====
  c = await open(browser, { label: 'xss' }); page = c.page; await toRep(page); await toPrep(page);
  var X = '<img src=x onerror="window.__xss=1"><script>window.__xss=2</script>';
  await addPrep(page, { subject: X, title: X, date: '2026-10-22', content: X, pages: X, homework: X, notes: X });
  check('XSS: markup shown as text everywhere, nothing executed, no injected elements', (await page.$$('.pcard img, .pcard script, #v-page img[src="x"]')).length === 0 && (await page.evaluate(function () { return window.__xss; })) === undefined && (await page.textContent('.pcard h3')) === X && (await page.$$eval('.pcard .lc-t', function (l) { return l.every(function (e) { return e.textContent === '<img src=x onerror="window.__xss=1"><script>window.__xss=2</script>'; }); })));
  await page.click('.pcard button:has-text("تعديل")');
  check('XSS: edit form holds the raw text verbatim', (await page.inputValue('#pf-content')) === X);
  await c.ctx.close();

  // ===== 14) التاريخ المحلي عبر المناطق ونقطة منتصف الليل =====
  var zones = [['Pacific/Kiritimati', '2026-10-21T10:30:00Z', '2026-10-22', '2026-10-23'], ['America/Los_Angeles', '2026-10-22T06:30:00Z', '2026-10-21', '2026-10-22'], ['Asia/Baghdad', '2026-10-21T21:30:00Z', '2026-10-22', '2026-10-23'], ['Pacific/Pago_Pago', '2026-10-22T10:30:00Z', '2026-10-21', '2026-10-22']];
  for (var z = 0; z < zones.length; z++) {
    c = await open(browser, { label: 'tz' + z, tz: zones[z][0], clock: zones[z][1] }); page = c.page; await toRep(page); await toPrep(page);
    await page.click('button:has-text("إضافة تحضير")');
    check(zones[z][0] + ': default date = local tomorrow', (await page.inputValue('#pf-date')) === zones[z][3], await page.inputValue('#pf-date'));
    await fill(page, { subject: 'م', title: 'لمحلي اليوم', date: zones[z][2], content: 'ج' }); await page.click('button:has-text("حفظ التحضير")'); await page.waitForSelector('.lform', { state: 'hidden' });
    await addPrep(page, { subject: 'م', title: 'لمحلي باجر', date: zones[z][3], content: 'ج' });
    check(zones[z][0] + ': local today/tomorrow grouping (not UTC)', (await group(page, 'today')).join() === 'لمحلي اليوم' && (await group(page, 'tomorrow')).join() === 'لمحلي باجر', (await group(page, 'today')).join() + '/' + (await group(page, 'tomorrow')).join());
    await c.ctx.close();
  }
  // عبور منتصف الليل والصفحة مفتوحة
  c = await open(browser, { label: 'midnight', clock: '2026-10-22T20:59:00Z' }); page = c.page; await toRep(page); await toPrep(page);
  await addPrep(page, { subject: 'م', title: 'سيصبح اليوم', date: '2026-10-23', content: 'ج' });
  check('Before midnight (23:59 Baghdad): prep is in «باجر»', (await group(page, 'tomorrow')).join() === 'سيصبح اليوم' && (await group(page, 'today')).length === 0);
  await page.clock.fastForward(3 * 60 * 1000);
  await page.waitForFunction(function () { var g = document.querySelector('.pgroup[data-group="today"]'); return g && /سيصبح اليوم/.test(g.textContent); }, null, { timeout: 5000 }).catch(function () { });
  check('After midnight with page open: prep regrouped into «اليوم» (no reload)', (await group(page, 'today')).join() === 'سيصبح اليوم' && (await group(page, 'tomorrow')).length === 0, (await group(page, 'today')).join() + '/' + (await group(page, 'tomorrow')).join());
  await c.ctx.close();

  // ===== 15) موبايل =====
  var widths = [320, 360, 375, 390, 412];
  var longTxt = 'ااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااا';
  for (var w = 0; w < widths.length; w++) {
    c = await open(browser, { label: 'mob' + widths[w], viewport: { width: widths[w], height: 700 }, touch: true }); page = c.page; await toRep(page); await toPrep(page);
    var ov0 = await overflow(page);
    await page.click('button:has-text("إضافة تحضير")');
    await fill(page, { subject: longTxt.slice(0, 80), title: longTxt, date: '2026-10-22', content: longTxt + '\n' + longTxt, pages: longTxt.slice(0, 80), homework: longTxt, notes: longTxt });
    var ovForm = await overflow(page);
    var small = await page.$$eval('.lform button, .lform input, .lform textarea, .lform summary, .toolbar button, .sepnote button', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + Math.round(e.getBoundingClientRect().height); }); });
    var fonts = await page.$$eval('.lform input, .lform textarea, input[type=search]', function (l) { return l.filter(function (e) { return e.offsetParent && parseFloat(getComputedStyle(e).fontSize) < 16; }).length; });
    await page.click('button:has-text("حفظ التحضير")'); await page.waitForSelector('.pcard');
    await addPrep(page, { subject: 'م', title: 'ثانٍ', date: '2026-10-23', content: 'ج' });
    await addPrep(page, { subject: 'م', title: 'ثالث', date: '2026-11-15', content: 'ج' });
    var ovList = await overflow(page);
    var smallList = await page.$$eval('.pcard button, input[type=search]', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return e.tagName + ':' + Math.round(e.getBoundingClientRect().height); }); });
    await page.click('.pcard button:has-text("حذف")');
    var dlgOverflow = await page.evaluate(function () { var d = document.getElementById('dlg-confirm'), r = d.getBoundingClientRect(); return r.left < 0 || r.right > window.innerWidth + 1 || document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; });
    await page.click('#dlg-confirm-body button:has-text("إلغاء")');
    check('Mobile ' + widths[w] + 'px: no horizontal scroll (empty / open form w/ long text / grouped list / delete dialog)', !ov0 && !ovForm && !ovList && !dlgOverflow, [ov0, ovForm, ovList, dlgOverflow].join(','));
    check('Mobile ' + widths[w] + 'px: form/list controls >= 44px tall', small.length === 0 && smallList.length === 0, small.concat(smallList).join(','));
    check('Mobile ' + widths[w] + 'px: inputs font-size >= 16px', fonts === 0);
    await c.ctx.close();
  }
  c = await open(browser, { label: 'land', viewport: { width: 568, height: 320 }, touch: true }); page = c.page; await toRep(page); await toPrep(page);
  await page.click('button:has-text("إضافة تحضير")');
  var reach = await page.evaluate(function () { var b = Array.from(document.querySelectorAll('.lform button')).filter(function (x) { return x.textContent === 'حفظ التحضير'; })[0]; b.scrollIntoView({ block: 'center' }); var r = b.getBoundingClientRect(); return r.top >= 0 && r.bottom <= window.innerHeight; });
  check('Mobile 568x320 landscape: save reachable, no horizontal scroll', reach && !(await overflow(page)));
  await c.ctx.close();

  // ===== 16) انحدار: الطلاب والصفوف وسجل الدروس =====
  c = await open(browser, { label: 'reg' }); page = c.page; await toRep(page);
  await page.click('.nav button:has-text("الطلاب")'); await page.click('button:has-text("إضافة طلاب")');
  await page.fill('#dlg-add-body textarea', 'زيد\nأحمد\nباسم'); await page.click('button:has-text("معاينة الأسماء")');
  await page.click('#dlg-add-body button.primary'); await page.waitForTimeout(300);
  var roster = await store(page, 'marsa.roster');
  check('Regression: bulk add students still works (schema/classId/codes)', roster && roster.students && roster.students.length === 3 && roster.students.every(function (s) { return s.studentId && s.studentCode; }), JSON.stringify(roster).slice(0, 200));
  var names = await page.$$eval('.stu .stu-name', function (l) { return l.map(function (b) { return b.textContent; }); });
  check('Regression: Arabic sort of students (أحمد, باسم, زيد)', names.join('|') === 'أحمد|باسم|زيد', names.join('|'));
  await toPrep(page);
  await addPrep(page, { subject: 'م', title: 'ت', date: '2026-10-22', content: 'ج' });
  check('Regression: preps do not touch the roster key', JSON.stringify(await store(page, 'marsa.roster')) === JSON.stringify(roster));
  await page.click('.nav button:has-text("اللوحة")');
  check('Dashboard: exactly one tile for preps, with the new description', (await page.$$eval('.tile', function (l) { return l.filter(function (b) { return /^التحاضير/.test(b.textContent); }).length; })) === 1);
  await page.click('.tile:has-text("إدارة الصفوف")');
  await page.click('button:has-text("إضافة صف")'); await page.fill('#cf-stage', 'صف فارغ للحذف'); await page.check('.cform .chk input'); await page.click('button:has-text("إضافة الصف")');
  await page.waitForFunction(function () { return !document.getElementById('dlg-class').open; });
  await page.click('.cls:has-text("صف فارغ للحذف") button:has-text("حذف نهائي")'); await page.click('#dlg-confirm-body button:has-text("حذف نهائي")');
  check('Regression: empty class can still be permanently deleted', (await page.$('.cls:has-text("صف فارغ للحذف")')) === null);
  await c.ctx.close();

  // ===== 17) تدقيق ثابت =====
  var src = ['js/app.js', 'js/preps-model.js', 'js/lessons-model.js', 'js/academic-store.js'].map(function (f) { return fs.readFileSync(path.resolve(__dirname, '..', f), 'utf8'); }).join('\n');
  check('Static: no eval / new Function / innerHTML / outerHTML / insertAdjacentHTML / document.write', !/\beval\s*\(|new\s+Function|\.innerHTML|\.outerHTML|insertAdjacentHTML|document\.write/.test(src));
  check('Static: no string timers', !/set(Timeout|Interval)\s*\(\s*['"`]/.test(src));
  var css = fs.readFileSync(path.resolve(__dirname, '..', 'css/styles.css'), 'utf8').replace(/@media \(hover:hover\)\{[^{}]*\{[^{}]*\}\}/g, '');
  check('Static: no :hover rule outside @media (hover:hover)', !/:hover/.test(css));
  check('Static: full.html loads preps-model.js before app.js', /preps-model\.js[\s\S]*app\.js/.test(fs.readFileSync(path.resolve(__dirname, '..', 'full.html'), 'utf8')));
  check('No uncaught JS errors across all runs', jsErrors.length === 0, jsErrors.join(' || '));

  await browser.close();
  var failed = results.filter(function (x) { return !x.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed (of ' + results.length + ')');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('RUNNER ERROR', e); process.exit(2); });
