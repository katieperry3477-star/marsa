// اختبار واجهة المرحلة 03.8 (الامتحانات للطالب، قراءة فقط) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-student-exams.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة بساعة مزيّفة (الخميس 2026-10-22 09:00 بغداد). لقطات الشاشة تُحفظ في SHOTS_DIR إن عُرّف.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var SHOTS = process.env.SHOTS_DIR || '';
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z'; // 09:00 بغداد
var DEMO = 'cls_demo_001', TWOID = 'cls_two', KEY = 'marsa.academic.exams.' + DEMO, KEY2 = 'marsa.academic.exams.' + TWOID;
function classesJson(active) {
  return JSON.stringify({ schemaVersion: 1, activeClassId: active, classes: [
    { classId: DEMO, schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null },
    { classId: TWOID, schoolName: '', stage: 'الثالث المتوسط', branch: '', section: 'ب', year: '', status: 'active', createdAt: null, archivedAt: null }] });
}
async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: opts.tz || 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(opts.clock || NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  if ((await page.$('.seg button[data-m="rep"]:not([hidden])')) === null) {
    await page.click('.nav button:has-text("الإعدادات")');
    await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
    await page.click('button:has-text("تفعيل")');
  }
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toStudent(page) { await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 }); }
async function nav(page, label) { await page.click('.nav button:has-text("' + label + '")'); await page.waitForSelector('#page-title'); }
async function seed(page, key, classId, records) { await page.evaluate(function (a) { localStorage.setItem(a.key, JSON.stringify({ schemaVersion: 1, classId: a.classId, records: a.records })); }, { key: key, classId: classId, records: records }); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function allStorage(page) { return page.evaluate(function () { var o = {}; for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('marsa.ui') !== 0) o[k] = localStorage.getItem(k); } return JSON.stringify(o); }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function pageText(page) { return page.textContent('#v-page'); }
async function ids(page, group) { return page.$$eval('#v-page [data-group="' + group + '"] .st-ecard', function (l) { return l.map(function (x) { return x.getAttribute('data-record-id'); }); }); }
async function shot(page, name) { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); }
function rec(id, o, cls) { return Object.assign({ recordId: id, classId: cls || DEMO, createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' }, o); }
// اليوم 2026-10-22. بيانات مخزَّنة بترتيب مخلوط عمداً.
function mixed() {
  return [
    rec('e_far', { subject: 'الإنجليزي', title: 'امتحان نصف السنة', examDate: '2026-12-15', status: 'scheduled', topics: 'الوحدات 1 إلى 5' }),
    rec('e_held', { subject: 'العلوم', title: 'امتحان شهري أول', examDate: '2026-10-05', status: 'held' }),
    rec('e_next', { subject: 'الرياضيات', title: 'امتحان شهري ثان', examDate: '2026-10-25', status: 'scheduled', topics: 'الفصل الأول\nالفصل الثاني: الأمثلة 1-12', notes: 'أحضروا الأدوات الهندسية\nانظر https://example.com/m' }),
    rec('e_cancel_future', { subject: 'التاريخ', title: 'امتحان ملغى مستقبلي', examDate: '2026-10-28', status: 'cancelled', topics: 'ملغى' }),
    rec('e_over', { subject: 'الجغرافيا', title: 'امتحان فات موعده', examDate: '2026-10-10', status: 'scheduled' }),
    rec('e_today', { subject: 'الحاسوب', title: 'امتحان اليوم', examDate: '2026-10-22', status: 'scheduled' }),
    rec('e_cancel_past', { subject: 'الفيزياء', title: 'ملغى سابق', examDate: '2026-09-01', status: 'cancelled' }),
    rec('e_later', { subject: 'الكيمياء', title: 'امتحان لاحق', examDate: '2026-11-03', status: 'scheduled' })
  ];
}

(async function main() {
  var browser = await pw.chromium.launch(), c, page, t, before, i;

  // ===== 1) فراغ: بلا بيانات وهمية، رسالة تشرح البدء، لا عناصر تحرير =====
  c = await open(browser, { label: 'empty' }); page = c.page;
  await nav(page, 'الامتحانات');
  t = await pageText(page);
  check('Empty: explains how to start (rep adds exams) and is not an error', /لا توجد امتحانات مضافة لهذا الصف بعد/.test(t) && /ممثل الصف/.test(t) && (await page.$('.st-err')) === null);
  check('Empty: no fake exam cards and no old placeholder «يُفعّل في مرحلة لاحقة»/disabled action', (await page.$$('#v-page .st-ecard')).length === 0 && !/يُفعّل في مرحلة لاحقة|هذا القسم جاهز للربط/.test(t) && (await page.$('.page-head .act')) === null);
  check('Empty: nothing written to storage', (await raw(page, KEY)) === null);
  await c.ctx.close();

  // ===== 2) تقسيم بحسب التاريخ والحالة =====
  c = await open(browser, { label: 'mixed' }); page = c.page;
  await seed(page, KEY, DEMO, mixed());
  before = await allStorage(page);
  await nav(page, 'الامتحانات');
  var sections = await page.$$eval('#v-page .pgroup', function (l) { return l.map(function (s) { return s.getAttribute('data-group'); }); });
  check('Section order: nearest, upcoming, finished', JSON.stringify(sections) === '["nearest","upcoming","finished"]', JSON.stringify(sections));
  check('Nearest exam is the earliest scheduled today-or-later (امتحان اليوم), first on page', JSON.stringify(await ids(page, 'nearest')) === '["e_today"]' && (await page.$eval('#v-page .pgroup', function (s) { return s.getAttribute('data-group'); })) === 'nearest', JSON.stringify(await ids(page, 'nearest')));
  check('Upcoming list = remaining scheduled by date, nearest not duplicated', JSON.stringify(await ids(page, 'upcoming')) === '["e_next","e_later","e_far"]', JSON.stringify(await ids(page, 'upcoming')));
  check('Finished: held + cancelled (even future-dated) + overdue scheduled; newest date first', JSON.stringify(await ids(page, 'finished')) === '["e_cancel_future","e_over","e_held","e_cancel_past"]', JSON.stringify(await ids(page, 'finished')));
  check('Cancelled exam is never in nearest/upcoming', (await ids(page, 'nearest')).concat(await ids(page, 'upcoming')).indexOf('e_cancel_future') < 0);
  var tags = await page.$$eval('#v-page .st-ecard', function (l) { var o = {}; l.forEach(function (li) { o[li.getAttribute('data-record-id')] = Array.prototype.map.call(li.querySelectorAll('.lc-meta .tag'), function (x) { return x.textContent; }).join('|'); }); return o; });
  check('Status shown explicitly: scheduled «مجدول», held «أُجري», cancelled «أُلغي»', /مجدول/.test(tags.e_next) && /أُجري/.test(tags.e_held) && /أُلغي/.test(tags.e_cancel_past) && /أُلغي/.test(tags.e_cancel_future), JSON.stringify(tags));
  check('Relative labels: اليوم / بعد 3 أيام', /اليوم/.test(tags.e_today) && /بعد 3 أيام/.test(tags.e_next), JSON.stringify(tags));
  check('Overdue scheduled is flagged «مضى موعده» but stays «مجدول» (not cancelled/held)', /مجدول/.test(tags.e_over) && /مضى موعده/.test(tags.e_over) && !/أُلغي|أُجري/.test(tags.e_over), tags.e_over);
  check('Cancelled card is styled as cancelled and has no «قادم» relative label', await page.evaluate(function () { var li = document.querySelector('[data-record-id="e_cancel_future"]'); return li.classList.contains('is-cancelled') && !li.querySelector('.tag.rel'); }));
  check('Past records are not removed because of date: held/cancelled/overdue all still rendered (8 cards total)', (await page.$$('#v-page .st-ecard')).length === 8);
  check('Count line shows 8', /عدد الامتحانات: 8/.test(t = await pageText(page)), t.slice(0, 200));
  // التفاصيل كما أُدخلت
  var nextTxt = await page.$eval('[data-record-id="e_next"]', function (li) { return li.textContent; });
  var topicsEl = await page.$eval('[data-record-id="e_next"] .lc-f .lc-t', function (p) { return p.textContent; });
  check('Topics shown unchanged incl. line breaks', topicsEl === 'الفصل الأول\nالفصل الثاني: الأمثلة 1-12', JSON.stringify(topicsEl));
  check('Instructions (notes) shown; http link becomes a safe external link', /أحضروا الأدوات الهندسية/.test(nextTxt) && (await page.$eval('[data-record-id="e_next"] a.st-link', function (a) { return a.href + '|' + a.rel + '|' + a.target; })) === 'https://example.com/m|noopener noreferrer nofollow|_blank');
  check('Field labels «المواضيع المطلوبة» / «التعليمات» present', /المواضيع المطلوبة/.test(nextTxt) && /التعليمات/.test(nextTxt));
  var heldTxt = await page.$eval('[data-record-id="e_held"]', function (li) { return li.textContent; });
  check('Empty optional fields hidden entirely (no label, no null/undefined/NaN)', !/المواضيع المطلوبة|التعليمات|undefined|null|NaN/.test(heldTxt), heldTxt);
  check('Dates formatted locally with Latin digits and Gregorian month', /2026/.test(await page.$eval('[data-record-id="e_next"] .lc-date', function (x) { return x.textContent; })) && /أكتوبر/.test(await page.$eval('[data-record-id="e_next"] .lc-date', function (x) { return x.textContent; })));
  // قراءة فقط
  var inter = await page.$$eval('#v-page button:not(.back), #v-page select, #v-page textarea, #v-page input, #v-page form, #v-page [contenteditable]', function (l) { return l.map(function (x) { return x.tagName + ':' + (x.type || '') + ':' + (x.textContent || '').trim(); }); });
  check('Read-only: only the search field exists (the only button is the «رجوع» navigation link; no forms/select/textarea; no edit/delete/add text)', inter.length === 1 && /^INPUT:search/.test(inter[0]) && !/تعديل|حذف|إضافة امتحان|حفظ|درجة|نتيجة|سؤال/.test(await page.$$eval('#v-page .st-ecard', function (l) { return l.map(function (x) { return x.textContent; }).join(' '); })), JSON.stringify(inter));
  check('Read-only note present', /عرض للقراءة فقط/.test(await pageText(page)));
  check('Browsing does not change a single stored byte', (await allStorage(page)) === before);
  check('No horizontal page scroll at 390px', !(await overflow(page)));
  await shot(page, 'exams-student-390');
  // بحث
  await page.fill('.st-search', 'الرياضيات');
  check('Search by subject keeps matching exam only', JSON.stringify(await ids(page, 'upcoming')) === '[]' && (await page.$$('#v-page .st-ecard')).length === 1 && /النتائج: 1 من 8/.test(await pageText(page)));
  await page.fill('.st-search', 'الفصل الثاني');
  check('Search by topics works', (await page.$$('#v-page .st-ecard')).length === 1);
  await page.fill('.st-search', 'لا شيء مطابق');
  check('Search with no match shows no-results text, not the empty-state', /لا توجد نتائج مطابقة للبحث/.test(await pageText(page)) && !/لا توجد امتحانات مضافة/.test(await pageText(page)));
  await page.fill('.st-search', '');
  check('Clearing search restores all 8', (await page.$$('#v-page .st-ecard')).length === 8);
  check('Search field height >= 44px and font >= 16px', await page.evaluate(function () { var s = document.querySelector('.st-search'), cs = getComputedStyle(s); return s.getBoundingClientRect().height >= 44 && parseFloat(cs.fontSize) >= 16; }));
  await c.ctx.close();

  // ===== 3) حالة بلا امتحان قادم =====
  c = await open(browser, { label: 'noupcoming' }); page = c.page;
  await seed(page, KEY, DEMO, [rec('p1', { subject: 'العلوم', title: 'أُجري', examDate: '2026-10-01', status: 'held' }), rec('p2', { subject: 'الأحياء', title: 'ملغى', examDate: '2026-11-20', status: 'cancelled' })]);
  await nav(page, 'الامتحانات');
  t = await pageText(page);
  check('No upcoming: nearest section says no scheduled exam; cancelled future exam is NOT promoted to nearest', /لا يوجد امتحان مجدول قادم/.test(t) && JSON.stringify(await ids(page, 'nearest')) === '[]' && JSON.stringify(await ids(page, 'finished')) === '["p2","p1"]');
  await c.ctx.close();

  // ===== 4) تدفق ممثل → طالب: التفاصيل كما أُدخلت، ثم التعديل والإلغاء =====
  c = await open(browser, { label: 'flow' }); page = c.page;
  await toRep(page);
  await nav(page, 'الامتحانات');
  await page.click('button:has-text("إضافة امتحان")');
  await page.fill('#ef-subject', 'الرياضيات'); await page.fill('#ef-title', 'امتحان شهري'); await page.fill('#ef-examDate', '2026-10-30');
  await page.fill('#ef-topics', 'الفصل الثالث\nالمعادلات التربيعية\nتمارين 1-10'); await page.fill('#ef-notes', 'يُسمح بالآلة الحاسبة');
  await page.click('button:has-text("حفظ الامتحان")');
  await page.waitForSelector('.ecard');
  await toStudent(page); await nav(page, 'الامتحانات');
  check('Rep-added exam appears to student under nearest with all details unchanged', JSON.stringify(await ids(page, 'nearest')).length > 4 && (await page.$eval('#v-page [data-group="nearest"] .lc-f .lc-t', function (p) { return p.textContent; })) === 'الفصل الثالث\nالمعادلات التربيعية\nتمارين 1-10' && /يُسمح بالآلة الحاسبة/.test(await pageText(page)));
  var rid = (await ids(page, 'nearest'))[0];
  // الممثل يلغي الامتحان
  await toRep(page); await nav(page, 'الامتحانات');
  await page.click('.ecard button:has-text("تعديل")'); await page.selectOption('#ef-status', 'cancelled'); await page.click('button:has-text("حفظ التعديل")');
  await page.waitForSelector('.ecard.is-cancelled');
  await toStudent(page); await nav(page, 'الامتحانات');
  check('After rep cancels: student sees it under finished as «أُلغي», not nearest/upcoming; same recordId', JSON.stringify(await ids(page, 'finished')) === JSON.stringify([rid]) && JSON.stringify(await ids(page, 'nearest')) === '[]' && /أُلغي/.test(await page.$eval('[data-record-id="' + rid + '"]', function (li) { return li.textContent; })));
  // الممثل يحذف
  await toRep(page); await nav(page, 'الامتحانات');
  await page.click('.ecard button:has-text("حذف")'); await page.click('#dlg-confirm-body button:has-text("حذف الامتحان")');
  await page.waitForTimeout(150);
  await toStudent(page); await nav(page, 'الامتحانات');
  check('After rep deletes: student list reflects it (empty state)', (await page.$$('#v-page .st-ecard')).length === 0 && /لا توجد امتحانات مضافة/.test(await pageText(page)));
  await c.ctx.close();

  // ===== 5) فصل الصفوف + تبديل الصف النشط + تحديث حي =====
  c = await open(browser, { label: 'classes', init: 'try{if(!localStorage.getItem("marsa.classes"))localStorage.setItem("marsa.classes",' + JSON.stringify(classesJson(DEMO)) + ');}catch(e){}' }); page = c.page;
  await seed(page, KEY, DEMO, [rec('a1', { subject: 'مادة الصف الأول', title: 'امتحان أ', examDate: '2026-10-24', status: 'scheduled' })]);
  await seed(page, KEY2, TWOID, [rec('b1', { subject: 'مادة الصف الثاني', title: 'امتحان ب', examDate: '2026-10-26', status: 'scheduled' }, TWOID)]);
  await nav(page, 'الامتحانات');
  check('Class 1 shows only its own exam', JSON.stringify(await ids(page, 'nearest')) === '["a1"]' && !/مادة الصف الثاني/.test(await pageText(page)));
  // تبديل الصف النشط والصفحة مفتوحة عبر حدث storage
  await page.evaluate(function (j) { localStorage.setItem('marsa.classes', j); window.dispatchEvent(new StorageEvent('storage', { key: 'marsa.classes' })); }, classesJson(TWOID));
  await page.waitForFunction(function () { return /مادة الصف الثاني/.test(document.getElementById('v-page').textContent); });
  check('Active class switch refreshes the open page to class 2 only', JSON.stringify(await ids(page, 'nearest')) === '["b1"]' && !/مادة الصف الأول/.test(await pageText(page)));
  // تحديث حي عند تغيّر بيانات الامتحان
  await seed(page, KEY2, TWOID, [rec('b1', { subject: 'مادة الصف الثاني', title: 'امتحان ب', examDate: '2026-10-26', status: 'scheduled' }, TWOID), rec('b2', { subject: 'مادة جديدة', title: 'امتحان جديد', examDate: '2026-10-23', status: 'scheduled', topics: 'وصل حياً' }, TWOID)]);
  await page.evaluate(function (k) { window.dispatchEvent(new StorageEvent('storage', { key: k })); }, KEY2);
  await page.waitForFunction(function () { return /وصل حياً/.test(document.getElementById('v-page').textContent); });
  check('Live storage change re-renders: new nearer exam becomes nearest', JSON.stringify(await ids(page, 'nearest')) === '["b2"]' && JSON.stringify(await ids(page, 'upcoming')) === '["b1"]');
  // منتصف الليل: امتحان باجر يصبح اليوم، وامتحان اليوم يمرّ إلى «مضى موعده»
  await seed(page, KEY2, TWOID, [rec('m1', { subject: 'م', title: 'اليوم', examDate: '2026-10-22', status: 'scheduled' }, TWOID), rec('m2', { subject: 'م', title: 'باجر', examDate: '2026-10-23', status: 'scheduled' }, TWOID)]);
  await page.evaluate(function (k) { window.dispatchEvent(new StorageEvent('storage', { key: k })); }, KEY2);
  await page.waitForFunction(function () { return !!document.querySelector('[data-record-id="m1"]'); });
  check('Before midnight: m1 nearest, m2 upcoming', JSON.stringify(await ids(page, 'nearest')) === '["m1"]' && JSON.stringify(await ids(page, 'upcoming')) === '["m2"]');
  await page.clock.fastForward(16 * 3600 * 1000 + 60000 * 2); // يتجاوز منتصف الليل ببغداد ويشغّل الفحص الدوري
  await page.waitForFunction(function () { return JSON.stringify(Array.prototype.map.call(document.querySelectorAll('#v-page [data-group="nearest"] .st-ecard'), function (x) { return x.getAttribute('data-record-id'); })) === '["m2"]'; }, null, { timeout: 5000 });
  check('After midnight (page left open): nearest becomes m2, m1 moves to finished as overdue (not cancelled/held)', JSON.stringify(await ids(page, 'finished')) === '["m1"]' && /مضى موعده/.test(await page.$eval('[data-record-id="m1"]', function (x) { return x.textContent; })) && /مجدول/.test(await page.$eval('[data-record-id="m1"]', function (x) { return x.textContent; })));
  check('Stored records untouched by passage of time (still scheduled, still 2 records)', (function (o) { return o.records.length === 2 && o.records[0].status === 'scheduled'; })(JSON.parse(await raw(page, KEY2))));
  await c.ctx.close();

  // ===== 6) خطأ ≠ فراغ =====
  var bads = [
    ['corrupt JSON', function () { localStorage.setItem('marsa.academic.exams.cls_demo_001', '{not json'); }],
    ['newer schemaVersion', function () { localStorage.setItem('marsa.academic.exams.cls_demo_001', JSON.stringify({ schemaVersion: 9, classId: 'cls_demo_001', records: [] })); }],
    ['classId mismatch', function () { localStorage.setItem('marsa.academic.exams.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'other', records: [] })); }],
    ['invalid record (bad examDate)', function () { localStorage.setItem('marsa.academic.exams.cls_demo_001', JSON.stringify({ schemaVersion: 1, classId: 'cls_demo_001', records: [{ recordId: 'x1', classId: 'cls_demo_001', examDate: '2026-13-45', subject: 's', title: 't' }] })); }]
  ];
  for (i = 0; i < bads.length; i++) {
    c = await open(browser, { label: 'bad' + i }); page = c.page;
    await page.evaluate(bads[i][1]);
    await nav(page, 'الامتحانات');
    t = await pageText(page);
    check('Error ≠ empty (' + bads[i][0] + '): role=alert, says emptiness cannot be asserted, no empty-state, no cards', (await page.$('.st-err[role="alert"]')) !== null && /لا يمكن الجزم بأن القائمة فارغة/.test(t) && !/لا توجد امتحانات مضافة لهذا الصف/.test(t) && (await page.$$('#v-page .st-ecard')).length === 0, t.slice(0, 300));
    if (i === 0) check('Corrupt data: raw value preserved, raw backup saved, nothing overwritten', (await raw(page, KEY)) === '{not json' && (await raw(page, KEY + '.backup')) === '{not json');
    await c.ctx.close();
  }

  // ===== 7) تخزين غير متاح =====
  c = await open(browser, { label: 'nostorage', init: 'try{Object.defineProperty(window,"localStorage",{get:function(){throw new Error("blocked")}});}catch(e){}' }); page = c.page;
  await page.click('.nav button:has-text("الامتحانات")'); await page.waitForSelector('#page-title');
  check('Storage unavailable: page still renders (empty-state + temporary-storage warning), no crash', /تخزين|مؤقت/.test(await pageText(page)) || /لا توجد امتحانات مضافة/.test(await pageText(page)));
  await c.ctx.close();

  // ===== 8) لا صف نشط =====
  c = await open(browser, { label: 'noclass', init: 'try{localStorage.setItem("marsa.classes",' + JSON.stringify(JSON.stringify({ schemaVersion: 1, activeClassId: null, classes: [] })) + ');}catch(e){}' }); page = c.page;
  await nav(page, 'الامتحانات');
  check('No active class: explicit message, no cards', /لا يوجد صف نشط/.test(await pageText(page)) && (await page.$$('#v-page .st-ecard')).length === 0);
  await c.ctx.close();

  // ===== 9) XSS =====
  c = await open(browser, { label: 'xss' }); page = c.page;
  await seed(page, KEY, DEMO, [rec('x1', { subject: '<img src=x onerror="window.__x=1">', title: '<script>window.__x=2</script>', examDate: '2026-10-30', status: 'scheduled', topics: '<b>عريض</b> javascript:alert(1) [x](javascript:alert(2))', notes: '<a href="javascript:window.__x=3">اضغط</a>' })]);
  await nav(page, 'الامتحانات');
  check('Markup stays text: no injected elements, no script run, no javascript: links', await page.evaluate(function () { var v = document.getElementById('v-page'); return !window.__x && !v.querySelector('img,script,b') && !Array.prototype.some.call(v.querySelectorAll('a'), function (a) { return /^javascript:/i.test(a.getAttribute('href') || ''); }) && /<img src=x/.test(v.textContent) && /<b>عريض<\/b>/.test(v.textContent); }));
  await c.ctx.close();

  // ===== 10) تخطيط الهاتف: عروض ضيقة + نص طويل =====
  var long = 'ن'.repeat(300), url = 'https://example.com/' + 'a'.repeat(200);
  for (i = 0, t = [320, 360, 390, 430]; i < t.length; i++) {
    c = await open(browser, { label: 'w' + t[i], viewport: { width: t[i], height: 780 } }); page = c.page;
    var many = mixed(); many.push(rec('long', { subject: long, title: long, examDate: '2026-10-23', status: 'scheduled', topics: long + '\n' + url, notes: url }));
    await seed(page, KEY, DEMO, many);
    await nav(page, 'الامتحانات');
    check('No horizontal page scroll at ' + t[i] + 'px with long title/subject/topics/link', !(await overflow(page)));
    if (t[i] === 320) await shot(page, 'exams-student-320');
    await c.ctx.close();
  }

  // ===== 11) داكن + RTL =====
  c = await open(browser, { label: 'dark' }); page = c.page;
  await page.emulateMedia({ colorScheme: 'dark' });
  await seed(page, KEY, DEMO, mixed());
  await nav(page, 'الامتحانات');
  check('RTL direction on exam cards', await page.evaluate(function () { return document.documentElement.dir === 'rtl' && getComputedStyle(document.querySelector('.st-ecard')).direction === 'rtl'; }));
  await shot(page, 'exams-student-dark-390');
  await c.ctx.close();

  // ===== 12) الرئيسية والصفحات الأخرى =====
  c = await open(browser, { label: 'others' }); page = c.page;
  await nav(page, 'التحاضير'); check('Student prep page still renders', /عرض للقراءة فقط/.test(await pageText(page)));
  await nav(page, 'الجدول'); check('Student schedule page still renders', (await page.$('#page-title')) !== null);
  await page.click('.nav button:has-text("الرئيسية")'); await page.waitForSelector('#welcome');
  check('Home exam panel no longer says «يُفعّل في مرحلة لاحقة» / «لا يوجد امتحان مجدول»', !/يُفعّل في مرحلة لاحقة|لا يوجد امتحان مجدول/.test(await page.evaluate(function () { return document.querySelector('#v-home section[aria-labelledby="t-exam"]').textContent; })));
  await page.click('.link[data-go="exams"]');
  check('Home «فتح الامتحانات» opens the student exams page', (await page.evaluate(function () { return document.documentElement.getAttribute('data-view'); })) === 'exams');
  await c.ctx.close();

  await browser.close();
  check('No uncaught JavaScript errors in any scenario', jsErrors.length === 0, jsErrors.join(' ;; '));
  var failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('RUNNER ERROR', e); process.exit(2); });
