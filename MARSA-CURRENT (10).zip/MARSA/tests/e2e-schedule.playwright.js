// اختبار واجهة المرحلة 03.4 (الجدول الأسبوعي) بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-schedule.playwright.js
// يفتح full.html عبر file:// في سياقات معزولة بساعة مزيّفة (الخميس 2026-10-22 09:00 بغداد) ويحقن بيانات الاختبار في تخزين السياق المؤقت فقط.
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', 'full.html');
var results = [], jsErrors = [];
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z';
var KEY = 'marsa.academic.schedule.cls_demo_001', KEY2 = 'marsa.academic.schedule.cls_two', DKEY = 'marsa.scheduleDays.cls_demo_001';
var TWO = JSON.stringify({ schemaVersion: 1, activeClassId: 'cls_demo_001', classes: [
  { classId: 'cls_demo_001', schoolName: '', stage: 'الثاني المهني', branch: 'صناعة — صيانة وتجميع الحاسوب', section: '', year: '', status: 'active', createdAt: null, archivedAt: null },
  { classId: 'cls_two', schoolName: '', stage: 'الثالث المتوسط', branch: '', section: 'ب', year: '', status: 'active', createdAt: null, archivedAt: null }] });
async function open(browser, opts) {
  opts = opts || {};
  var ctx = await browser.newContext({ viewport: opts.viewport || { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: !!opts.touch, isMobile: !!opts.touch });
  if (opts.init) await ctx.addInitScript(opts.init);
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push((opts.label || '') + ': ' + e.message); });
  await page.clock.install({ time: new Date(NOW) });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])');
  await page.click('#skip-intro');
  await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function toRep(page) {
  await page.click('.nav button:has-text("الإعدادات")');
  await page.fill('#rep-code-in', 'MRS-REP-DEMO-26');
  await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]');
  await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
}
async function toSched(page) { await page.click('.nav button:has-text("الجدول")'); await page.waitForSelector('#page-title'); }
async function fill(page, o) {
  if (o.day !== undefined) await page.selectOption('#sf-day', o.day);
  if (o.subject !== undefined) await page.fill('#sf-subject', o.subject);
  if (o.period !== undefined) await page.fill('#sf-period', o.period);
  if (o.start !== undefined) await page.fill('#sf-startTime', o.start);
  if (o.end !== undefined) await page.fill('#sf-endTime', o.end);
  if (o.notes !== undefined) await page.fill('#sf-notes', o.notes);
}
async function add(page, o) { await page.click('button:has-text("إضافة حصة") >> nth=0'); await fill(page, o); await page.click('button[type=submit]'); await page.waitForSelector('.lform', { state: 'hidden' }); }
async function store(page, key) { return page.evaluate(function (k) { var r = localStorage.getItem(k); return r === null ? null : JSON.parse(r); }, key); }
async function raw(page, key) { return page.evaluate(function (k) { return localStorage.getItem(k); }, key); }
async function keys(page) { return page.evaluate(function () { var o = []; for (var i = 0; i < localStorage.length; i++) o.push(localStorage.key(i)); return o.sort(); }); }
async function rows(page) { return page.$$eval('.sbody .prow h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function toast(page) { return page.$eval('#status', function (s) { return s.textContent; }); }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1; }); }
async function tab(page, name) { await page.click('.dtab:has-text("' + name + '")'); }
async function warnText(page) { return page.$eval('.sfwarn', function (e) { return e.textContent; }); }

(async function main() {
  var browser = await pw.chromium.launch();
  var c, page, rec, before, t, k;

  // ---------- بداية نظيفة ----------
  c = await open(browser, { label: 'clean' }); page = c.page;
  check('وضع الطالب لا يعرض صفحة r-schedule (الجدول المخصص للممثل)', (await page.$$eval('.nav button', function (l) { return l.map(function (x) { return x.textContent; }); })).indexOf('الجدول') > -1 && (await page.evaluate(function () { return document.documentElement.getAttribute('data-mode'); })) === 'student');
  await toRep(page);
  check('الشريط العلوي في وضع الممثل يحتوي «الجدول»', (await page.$$eval('.nav button', function (l) { return l.map(function (x) { return x.textContent; }); })).indexOf('الجدول') > -1);
  await page.click('.nav button:has-text("اللوحة")');
  check('لوحة الممثل تحتوي بلاطة الجدول الدراسي', await page.$('.tile:has-text("الجدول الدراسي الأسبوعي")') !== null);
  await page.click('.tile:has-text("الجدول الدراسي الأسبوعي")');
  check('البلاطة تفتح r-schedule', (await page.evaluate(function () { return document.documentElement.getAttribute('data-view'); })) === 'r-schedule');
  await page.click('.nav button:has-text("الإعدادات")');
  check('الإعدادات العامة لا تحتوي إعداد الجدول', !/جدول|حصص/.test(await page.$eval('#v-page', function (e) { return e.textContent; })));
  await toSched(page);
  check('لا حصص تجريبية: حالة فراغ تشرح البدء', /لم يُبنَ جدول هذا الصف بعد/.test(await page.$eval('.sbody', function (e) { return e.textContent; })) && (await rows(page)).length === 0);
  check('لا مفاتيح جدول ولا أي بيانات مكتوبة عند الفتح', (await keys(page)).filter(function (x) { return /schedule|scheduleDays|dailyLessons|preparations/.test(x); }).length === 0, JSON.stringify(await keys(page)));
  check('الأيام الافتراضية الظاهرة: الأحد..الخميس بالعربية وبهذا الترتيب', JSON.stringify(await page.$$eval('.dtab .dn', function (l) { return l.map(function (x) { return x.textContent; }); })) === JSON.stringify(['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس']));
  check('اليوم الحالي (الخميس) محدد افتراضياً', (await page.$eval('.dtab[aria-pressed="true"] .dn', function (e) { return e.textContent; })) === 'الخميس');
  check('زر الإضافة مفعّل وعدد الحصص 0', /0/.test(await page.$eval('.count', function (e) { return e.textContent; })) && !(await page.$eval('button:has-text("إضافة حصة")', function (b) { return b.disabled; })));

  // ---------- التحقق ----------
  await page.click('button:has-text("إضافة حصة")');
  check('النموذج يقترح اليوم المحدد', (await page.$eval('#sf-day', function (e) { return e.value; })) === 'thu');
  await page.selectOption('#sf-day', '');
  await page.click('button[type=submit]');
  check('اليوم والمادة مطلوبان: رسائل خطأ ولا حفظ', /اختر اليوم/.test(await page.$eval('#sf-day-e', function (e) { return e.textContent; })) && /اسم المادة/.test(await page.$eval('#sf-subject-e', function (e) { return e.textContent; })) && (await store(page, KEY)) === null);
  await fill(page, { day: 'sun', subject: 'مادة', start: '09:00', end: '08:00' });
  await page.click('button[type=submit]');
  check('وقت نهاية قبل البداية يُرفض برسالة واضحة', /بعد وقت البداية/.test(await page.$eval('#sf-endTime-e', function (e) { return e.textContent; })) && (await store(page, KEY)) === null);
  await fill(page, { start: '', end: '08:45' });
  await page.click('button[type=submit]');
  check('نهاية بلا بداية تُرفض', /وقت البداية/.test(await page.$eval('#sf-startTime-e', function (e) { return e.textContent; })));
  await fill(page, { start: '08:00', end: '08:45', period: '31' });
  await page.click('button[type=submit]');
  check('رقم حصة خارج 1..30 يُرفض', /من 1 إلى 30/.test(await page.$eval('#sf-period-e', function (e) { return e.textContent; })) && (await store(page, KEY)) === null);
  check('حقل رقم الحصة رقمي للوحة مفاتيح الهاتف والوقت type=time', (await page.$eval('#sf-period', function (e) { return e.getAttribute('inputmode') + e.type; })) === 'numericnumber' && (await page.$eval('#sf-startTime', function (e) { return e.type; })) === 'time');
  await page.click('.lform button:has-text("إلغاء")');
  await page.click('#dlg-confirm button:has-text("تجاهل والمتابعة")');

  // ---------- بناء أسبوع بأعداد حصص مختلفة ----------
  await add(page, { day: 'sun', subject: 'الحصة الثانية', period: '2', start: '08:50', end: '09:35' });
  await add(page, { day: 'sun', subject: 'الحصة الأولى', period: '1', start: '08:00', end: '08:45' });
  await add(page, { day: 'sun', subject: 'بلا رقم', notes: 'ملاحظة اختيارية' });
  await add(page, { day: 'mon', subject: 'يوم الاثنين فقط' });
  rec = await store(page, KEY);
  check('4 سجلات بمعرّفات sch_ وclassId الحالي وعدد حصص مختلف لكل يوم', rec && rec.classId === 'cls_demo_001' && rec.schemaVersion === 1 && rec.records.length === 4 && rec.records.every(function (r) { return /^sch_/.test(r.recordId) && r.classId === 'cls_demo_001'; }));
  check('الحقل الاختياري الفارغ لا يُخزَّن (بلا period/startTime/notes)', (function () { var r = rec.records.filter(function (x) { return x.subject === 'يوم الاثنين فقط'; })[0]; return !('period' in r) && !('startTime' in r) && !('endTime' in r) && !('notes' in r); })());
  check('بعد الحفظ ينتقل العرض ليوم الحصة', (await page.$eval('.dtab[aria-pressed="true"] .dn', function (e) { return e.textContent; })) === 'الاثنين');
  await tab(page, 'الأحد');
  check('ترتيب الحصص: بحسب رقم الحصة ثم بلا رقم أخيراً', JSON.stringify(await rows(page)) === JSON.stringify(['الحصة الأولى', 'الحصة الثانية', 'بلا رقم']), JSON.stringify(await rows(page)));
  check('الوقت يظهر بتنسيق 12 ساعة بالعربية', /8:00 ص – 8:45 ص/.test(await page.$eval('.sbody', function (e) { return e.textContent; })));
  check('عدّاد اليوم على التبويب صحيح', (await page.$eval('.dtab:has-text("الأحد") .dc', function (e) { return e.textContent; })) === '3');
  await page.click('.sv button:has-text("الأسبوع كله")');
  check('عرض الأسبوع: بطاقة لكل يوم ظاهر بالترتيب (الأحد قبل الاثنين...)', JSON.stringify(await page.$$eval('.daycard h2', function (l) { return l.map(function (x) { return x.textContent.replace(/ \(\d+\)/, ''); }); })) === JSON.stringify(['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس']));
  check('عرض الأسبوع: تبويبات اليوم مخفية', await page.$eval('.dtabs', function (e) { return e.hidden; }));
  check('الأيام الفارغة تعرض «لا توجد حصص»', (await page.$$eval('.daycard[data-day="tue"] .muted', function (l) { return l.map(function (x) { return x.textContent; }); })).indexOf('لا توجد حصص.') > -1);
  await page.click('.daycard[data-day="wed"] button:has-text("إضافة حصة")');
  check('زر إضافة في بطاقة يوم يقترح ذلك اليوم', (await page.$eval('#sf-day', function (e) { return e.value; })) === 'wed');
  await page.click('.lform button:has-text("إلغاء")');
  await page.click('.sv button:has-text("يوم واحد")');

  // ---------- حفظ وإضافة أخرى ----------
  await tab(page, 'الثلاثاء');
  await page.click('button:has-text("إضافة حصة") >> nth=0');
  await fill(page, { subject: 'أولى الثلاثاء', period: '1', start: '08:00', end: '08:45' });
  await page.click('button:has-text("حفظ وإضافة حصة أخرى")');
  await page.waitForTimeout(100);
  check('«حفظ وإضافة أخرى»: نموذج جديد بنفس اليوم والحصة التالية وبداية = نهاية السابقة', (await page.$eval('#sf-day', function (e) { return e.value; })) === 'tue' && (await page.$eval('#sf-period', function (e) { return e.value; })) === '2' && (await page.$eval('#sf-startTime', function (e) { return e.value; })) === '08:45' && (await page.$eval('#sf-subject', function (e) { return e.value; })) === '');
  await page.click('.lform button:has-text("إلغاء")');
  check('الإلغاء بلا تعديلات لا يطلب تأكيداً', await page.$('.lform:not([hidden])') === null);

  // ---------- التعارض ----------
  before = await raw(page, KEY);
  await page.click('button:has-text("إضافة حصة") >> nth=0');
  await fill(page, { day: 'tue', subject: 'مكررة', period: '1' });
  await page.click('button[type=submit]');
  check('رقم حصة مكرر: تنبيه مفهوم ولا حفظ في الضغطة الأولى', /تعارض/.test(await warnText(page)) && /الحصة رقم 1 يوم الثلاثاء مضافة مسبقاً/.test(await warnText(page)) && (await raw(page, KEY)) === before, await warnText(page));
  check('زر الحفظ يتحول إلى «حفظ رغم التنبيه» والنموذج يبقى', (await page.$eval('button[type=submit]', function (b) { return b.textContent; })) === 'حفظ رغم التنبيه' && await page.$('.lform:not([hidden])') !== null);
  await fill(page, { period: '5' });
  check('تعديل الحقل يزيل التنبيه ويعيد الزر', (await warnText(page)) === '' && (await page.$eval('button[type=submit]', function (b) { return b.textContent; })) === 'حفظ الحصة');
  await fill(page, { period: '1' });
  await page.click('button[type=submit]'); await page.click('button[type=submit]');
  await page.waitForSelector('.lform', { state: 'hidden' });
  rec = await store(page, KEY);
  check('الضغطة الثانية تحفظ قرار المستخدم، وكل السجلات الأخرى سليمة (لا حذف صامت)', rec.records.length === 6 && JSON.parse(before).records.every(function (o) { return JSON.stringify(rec.records.filter(function (r) { return r.recordId === o.recordId; })[0]) === JSON.stringify(o); }));
  before = await raw(page, KEY);
  await page.click('button:has-text("إضافة حصة") >> nth=0');
  await fill(page, { day: 'sun', subject: 'متداخلة', start: '08:30', end: '09:00' });
  await page.click('button[type=submit]');
  check('تداخل أوقات: تنبيه يذكر الحصتين وأوقاتهما', /يتداخل مع «الحصة الأولى»/.test(await warnText(page)) && /8:00 ص – 8:45 ص/.test(await warnText(page)) && (await raw(page, KEY)) === before, await warnText(page));
  await fill(page, { start: '08:45', end: '08:50' });
  await page.click('button[type=submit]');
  await page.waitForSelector('.lform', { state: 'hidden' });
  check('حدّان متلامسان (8:45) ليسا تعارضاً', (await store(page, KEY)).records.length === 7);

  // ---------- التعديل ----------
  await tab(page, 'الأحد');
  var id0 = (await store(page, KEY)).records.filter(function (r) { return r.subject === 'الحصة الأولى'; })[0];
  await page.click('.prow:has-text("الحصة الأولى") button:has-text("تعديل")');
  check('التعديل يملأ الحقول', (await page.$eval('#sf-subject', function (e) { return e.value; })) === 'الحصة الأولى' && (await page.$eval('#sf-startTime', function (e) { return e.value; })) === '08:00');
  await page.click('button[type=submit]');
  await page.waitForSelector('.lform', { state: 'hidden' });
  check('حفظ التعديل بلا تغيير لا يعدّ تعارضاً مع نفسه', (await store(page, KEY)).records.length === 7);
  await page.click('.prow:has-text("الحصة الأولى") button:has-text("تعديل")');
  await fill(page, { day: 'wed', subject: 'الحصة الأولى معدّلة' });
  await page.click('button[type=submit]');
  await page.waitForSelector('.lform', { state: 'hidden' });
  rec = (await store(page, KEY)).records.filter(function (r) { return r.recordId === id0.recordId; })[0];
  check('التعديل يُبقي recordId وclassId وcreatedAt وينقل اليوم', rec && rec.day === 'wed' && rec.classId === id0.classId && rec.createdAt === id0.createdAt && rec.updatedAt >= id0.updatedAt && rec.subject === 'الحصة الأولى معدّلة', JSON.stringify(rec));
  check('الحصة انتقلت إلى يوم الأربعاء (والعرض تبعها)', (await rows(page)).indexOf('الحصة الأولى معدّلة') > -1 && (await page.$eval('.dtab[aria-pressed="true"] .dn', function (e) { return e.textContent; })) === 'الأربعاء');
  check('مسح الحقول الاختيارية عند التعديل يحذفها من السجل', await (async function () { await page.click('.prow:has-text("معدّلة") button:has-text("تعديل")'); await fill(page, { start: '', end: '', period: '' }); await page.click('button[type=submit]'); await page.waitForSelector('.lform', { state: 'hidden' }); var r = (await store(page, KEY)).records.filter(function (x) { return x.recordId === id0.recordId; })[0]; return !('period' in r) && !('startTime' in r) && !('endTime' in r); })());
  await page.click('.prow:has-text("معدّلة") button:has-text("تعديل")');
  await fill(page, { subject: 'نص غير محفوظ' });
  await page.click('.lform button:has-text("إلغاء")');
  check('إلغاء نموذج فيه نص غير محفوظ يطلب تأكيد التجاهل', await page.$('#dlg-confirm[open]') !== null);
  await page.click('#dlg-confirm button:has-text("إلغاء")');
  check('الرجوع من نافذة التأكيد يُبقي النص في النموذج', (await page.$eval('#sf-subject', function (e) { return e.value; })) === 'نص غير محفوظ');
  await page.click('.lform button:has-text("إلغاء")');
  await page.click('#dlg-confirm button:has-text("تجاهل والمتابعة")');
  check('«تجاهل والمتابعة» يغلق النموذج دون حفظ', await page.$('.lform:not([hidden])') === null && (await store(page, KEY)).records.filter(function (r) { return r.subject === 'نص غير محفوظ'; }).length === 0);

  // ---------- الحذف ----------
  await tab(page, 'الاثنين');
  before = await raw(page, KEY);
  await page.click('.prow:has-text("يوم الاثنين فقط") button:has-text("حذف")');
  check('الحذف يطلب تأكيداً يسمّي الحصة واليوم', /يوم الاثنين فقط/.test(await page.$eval('#dlg-confirm-body', function (e) { return e.textContent; })) && /الاثنين/.test(await page.$eval('#dlg-confirm-body', function (e) { return e.textContent; })));
  await page.click('#dlg-confirm button:has-text("إلغاء")');
  check('إلغاء الحذف لا يغيّر التخزين', (await raw(page, KEY)) === before);
  await page.click('.prow:has-text("يوم الاثنين فقط") button:has-text("حذف")');
  await page.click('#dlg-confirm button:has-text("حذف الحصة")');
  check('تأكيد الحذف يزيل الحصة فقط', (await store(page, KEY)).records.length === 6 && (await rows(page)).length === 0 && /تم حذف الحصة/.test(await toast(page)));

  // ---------- الفصل عن ما أُخذ والتحاضير ----------
  check('لا مفاتيح dailyLessons/preparations أُنشئت من الجدول', (await keys(page)).filter(function (x) { return /dailyLessons|preparations/.test(x); }).length === 0, JSON.stringify(await keys(page)));
  check('ملاحظة الفصل ظاهرة مع زر إلى «ما أُخذ اليوم»', /ما شرحته فعلاً/.test(await page.$eval('.sepnote', function (e) { return e.textContent; })));

  // ---------- أيام الأسبوع ----------
  await page.click('.dayset-box summary');
  check('الأيام التي فيها حصص: مؤشرة وغير قابلة للإيقاف', await page.$eval('input[data-day="sun"]', function (e) { return e.checked && e.disabled; }));
  await page.check('input[data-day="fri"]');
  check('تفعيل الجمعة يظهرها ويحفظ الإعداد', (await page.$$eval('.dtab .dn', function (l) { return l.map(function (x) { return x.textContent; }); })).indexOf('الجمعة') > -1 && JSON.stringify((await store(page, DKEY)).days) === JSON.stringify(['sun', 'mon', 'tue', 'wed', 'thu', 'fri']));
  await page.check('input[data-day="sat"]');
  check('السبت يظهر أولاً (ترتيب الأسبوع)', (await page.$$eval('.dtab .dn', function (l) { return l[0].textContent; })) === 'السبت');
  await page.uncheck('input[data-day="thu"]');
  check('إخفاء يوم بلا حصص يعمل', (await page.$$eval('.dtab .dn', function (l) { return l.map(function (x) { return x.textContent; }); })).indexOf('الخميس') < 0);
  await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro');
  check('إعادة التحميل تُبقي البيانات والأيام (والوضع يعود للطالب)', (await store(page, KEY)).records.length === 6 && JSON.stringify((await store(page, DKEY)).days) === JSON.stringify(['sat', 'sun', 'mon', 'tue', 'wed', 'fri']));
  await c.ctx.close();

  // ---------- تبدّل الصف ----------
  c = await open(browser, { label: 'classes', init: 'if(!localStorage.getItem("marsa.classes"))localStorage.setItem("marsa.classes",' + JSON.stringify(TWO) + ');' }); page = c.page;
  await toRep(page); await toSched(page);
  await add(page, { day: 'thu', subject: 'مادة الصف الأول' });
  check('البيانات تُحفظ تحت classId الصف النشط', (await store(page, KEY)).records.length === 1 && (await store(page, KEY2)) === null);
  await page.selectOption('#cb-sel', 'cls_two');
  await page.waitForSelector('.classbar b:has-text("الثالث المتوسط")');
  check('بعد تبديل الصف: لا حصص من الصف الأول (فراغ)', (await rows(page)).length === 0 && /لم يُبنَ جدول/.test(await page.$eval('.sbody', function (e) { return e.textContent; })));
  await add(page, { day: 'thu', subject: 'مادة الصف الثاني' });
  check('الصف الثاني محفوظ بمعرّف صفه، والأول لم يتغير', (await store(page, KEY2)).records.length === 1 && (await store(page, KEY2)).classId === 'cls_two' && (await store(page, KEY)).records[0].subject === 'مادة الصف الأول');
  await page.selectOption('#cb-sel', 'cls_demo_001');
  await page.waitForSelector('.classbar b:has-text("الثاني المهني")');
  check('الرجوع للصف الأول يعرض حصصه فقط', JSON.stringify(await rows(page)) === JSON.stringify(['مادة الصف الأول']));
  check('أيام العرض إعداد لكل صف (لا مفتاح للصف الثاني بلا ضبط)', (await store(page, 'marsa.scheduleDays.cls_two')) === null);
  await c.ctx.close();

  // ---------- XSS ----------
  c = await open(browser, { label: 'xss' }); page = c.page;
  await toRep(page); await toSched(page);
  await add(page, { day: 'thu', subject: '<img src=x onerror="window.__x=1">', notes: '<script>window.__x=2</script><b>غامق</b>' });
  check('HTML/script في المادة والملاحظة يظهر نصاً لا يُنفَّذ', (await page.evaluate(function () { return window.__x; })) === undefined && (await page.$$('.sbody img, .sbody script, .sbody b')).length === 0 && /<img src=x/.test(await page.$eval('.prow h3', function (e) { return e.textContent; })));
  check('النص ذو التنسيق الظاهر عبر textContent (الملاحظة تحوي <b> حرفياً)', /<b>غامق<\/b>/.test(await page.$eval('.pr-note', function (e) { return e.textContent; })));
  await c.ctx.close();

  // ---------- فشل التخزين ----------
  c = await open(browser, { label: 'fail' }); page = c.page;
  await toRep(page); await toSched(page);
  await page.evaluate(function () { var o = Storage.prototype.setItem; Storage.prototype.setItem = function (k) { if (/academic\.schedule/.test(k)) throw new Error('quota'); return o.apply(this, arguments); }; });
  await page.click('button:has-text("إضافة حصة")');
  await fill(page, { day: 'thu', subject: 'لن تُحفظ' });
  await page.click('button[type=submit]');
  check('فشل الكتابة: رسالة خطأ، لا نجاح كاذب، والنص يبقى في النموذج', /لم تُحفظ الحصة/.test(await page.$eval('#sf-msg', function (e) { return e.textContent; })) && !/تم حفظ/.test(await toast(page)) && (await page.$eval('#sf-subject', function (e) { return e.value; })) === 'لن تُحفظ' && (await rows(page)).length === 0);
  await c.ctx.close();

  // ---------- مجموعة تالفة + إعداد أيام تالف ----------
  c = await open(browser, { label: 'corrupt', init: 'if(!localStorage.getItem("' + KEY + '")){localStorage.setItem("' + KEY + '","{bad json");localStorage.setItem("' + DKEY + '","not json");}' }); page = c.page;
  await toRep(page); await toSched(page);
  check('مجموعة تالفة: تحذير واضح والإضافة معطّلة ولم تُطمس', /تالفة/.test(await page.$eval('.warnbox', function (e) { return e.textContent; })) && await page.$eval('button:has-text("إضافة حصة")', function (b) { return b.disabled; }) && (await raw(page, KEY)) === '{bad json');
  check('نسخة خام احتياطية للمجموعة وللإعداد التالف', (await keys(page)).filter(function (x) { return x.indexOf(KEY + '.backup') === 0; }).length >= 1 && (await keys(page)).filter(function (x) { return x.indexOf(DKEY + '.backup') === 0; }).length >= 1, JSON.stringify(await keys(page)));
  check('إعداد الأيام التالف: عودة للأيام الافتراضية مع رسالة', /الأيام الافتراضية/.test(await page.$eval('#v-page', function (e) { return e.textContent; })));
  await c.ctx.close();

  // ---------- يوم غير معروف لا يُخفى ----------
  c = await open(browser, { label: 'unknown', init: 'if(!localStorage.getItem("' + KEY + '"))localStorage.setItem("' + KEY + '",JSON.stringify({schemaVersion:1,classId:"cls_demo_001",records:[{recordId:"sch_old1",classId:"cls_demo_001",subject:"قديمة",day:"zzz"},{recordId:"sch_old2",classId:"cls_demo_001",subject:"بلا يوم"}]}));' }); page = c.page;
  await toRep(page); await toSched(page);
  check('سجلات بيوم غير معروف تظهر في قسم مستقل للتعديل أو الحذف', /حصص بيوم غير معروف \(2\)/.test(await page.$eval('.sbody', function (e) { return e.textContent; })));
  await page.click('.prow:has-text("قديمة") button:has-text("تعديل")');
  check('تعديلها يفرض اختيار يوم صالح', (await page.$eval('#sf-day', function (e) { return e.value; })) === '');
  await c.ctx.close();

  // ---------- الموبايل ----------
  var sizes = [[320, 640], [360, 740], [375, 667], [390, 844], [412, 915], [568, 320]];
  for (var i = 0; i < sizes.length; i++) {
    var w = sizes[i][0], h = sizes[i][1], long = 'م'.repeat(80), url = 'ا'.repeat(60);
    var seed = { schemaVersion: 1, classId: 'cls_demo_001', records: [
      { recordId: 'sch_a1', classId: 'cls_demo_001', day: 'thu', subject: long, period: 12, startTime: '08:00', endTime: '08:45', notes: url + ' ' + 'ن'.repeat(250) },
      { recordId: 'sch_a2', classId: 'cls_demo_001', day: 'thu', subject: 'قصيرة', period: 30 }, { recordId: 'sch_a3', classId: 'cls_demo_001', day: 'sun', subject: 'x' }] };
    c = await open(browser, { label: 'm' + w, viewport: { width: w, height: h }, touch: true, init: 'if(!localStorage.getItem("' + KEY + '"))localStorage.setItem("' + KEY + '",' + JSON.stringify(JSON.stringify(seed)) + ');' }); page = c.page;
    await toRep(page); await toSched(page);
    var lbl = w + '×' + h;
    check('[' + lbl + '] لا تمرير أفقي (عرض يوم) بنصوص طويلة', !(await overflow(page)));
    await page.click('.sv button:has-text("الأسبوع كله")');
    check('[' + lbl + '] لا تمرير أفقي (عرض الأسبوع)', !(await overflow(page)));
    await page.click('.dayset-box summary');
    check('[' + lbl + '] لا تمرير أفقي (ضبط الأيام مفتوح)', !(await overflow(page)));
    await page.click('.sv button:has-text("يوم واحد")');
    await page.click('button:has-text("إضافة حصة") >> nth=0');
    check('[' + lbl + '] لا تمرير أفقي والنموذج مفتوح', !(await overflow(page)));
    var small = await page.$$eval('#v-page button:not([hidden]), #v-page select, #v-page input:not([type=checkbox]):not([type=hidden]), #v-page summary, #v-page label.dchk', function (l) { return l.filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 43.5; }).map(function (e) { return (e.id || e.className || e.tagName) + ':' + Math.round(e.getBoundingClientRect().height); }); });
    check('[' + lbl + '] أهداف اللمس ≥ 44px', small.length === 0, small.join(','));
    var fs = await page.$$eval('.lf input, .lf select, .lf textarea', function (l) { return l.filter(function (e) { return parseFloat(getComputedStyle(e).fontSize) < 16; }).map(function (e) { return e.id; }); });
    check('[' + lbl + '] خطوط الحقول ≥ 16px (لا تكبير تلقائي في iOS)', fs.length === 0, fs.join(','));
    var inView = await page.$eval('#sf-endTime', function (e) { var r = e.getBoundingClientRect(); return r.left >= 0 && r.right <= document.documentElement.clientWidth + 1; });
    check('[' + lbl + '] حقلا الوقت ضمن عرض الشاشة', inView);
    await c.ctx.close();
  }

  await browser.close();
  check('لا أخطاء JavaScript أثناء كل السيناريوهات', jsErrors.length === 0, jsErrors.join(' | '));
  var failed = results.filter(function (r) { return !r.ok; });
  console.log('\n' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed');
  process.exit(failed.length ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
