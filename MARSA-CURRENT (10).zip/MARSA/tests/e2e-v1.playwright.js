// اختبار رحلة MARSA V1 كاملة بـ Playwright + Chromium (اختياري؛ لا يدخل في التطبيق).
// تشغيل: NODE_PATH=$(npm root -g) node tests/e2e-v1.playwright.js
// جهازان منفصلان تماماً = سياقان معزولان بتخزين مستقل: «الممثل» و«الطالب». الكود ينتقل بينهما نصاً فقط (نسخ ولصق).
// يخدم المجلد عبر خادم محلي مؤقت (للحافظة والسياق الآمن) ويجرّب file:// أيضاً. لا اتصال خارجي ولا بيانات حقيقية.
var pw = require('playwright'), path = require('path'), http = require('http'), fs = require('fs');
var ROOT = path.resolve(__dirname, '..');
var results = [], jsErrors = [], allRequests = [], BASE = '', server;
function check(name, cond, detail) { results.push({ name: name, ok: !!cond, detail: cond ? '' : (detail || '') }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var NOW = '2026-10-22T06:00:00Z'; // 2026-10-22 09:00 بتوقيت بغداد
var TODAY = '2026-10-22';

// ===== بيانات الاختبار (تجريبية فقط) =====
var WORDS = 'الحال الفاعل المفعول الجملة الاسمية الفعلية المبتدأ الخبر الدرس الطالب المعلم الكتاب الصفحة التمرين الواجب المثال القاعدة الإعراب منصوب مرفوع مجرور علامة الفتحة الضمة الكسرة جاء ذهب كتب قرأ سمع فهم حفظ راجع حل أجب اشرح استخرج اذكر وضح قارن علل بين ما هو الذي التي في من إلى على عن مع بعد قبل حيث كيف لماذا متى أين نوع حالة صفة موصوف نعت تابع عطف توكيد بدل مضاف إليه جار ومجرور'.split(' ');
function arabicText(len, seed) { var s = seed || 7, out = '', w; function r() { s = (s * 1103515245 + 12345) & 0x7fffffff; return s; } while (out.length < len) { w = WORDS[r() % WORDS.length]; out += (out ? (r() % 13 === 0 ? '.\n' : ' ') : '') + w; } return out.slice(0, len).trim(); }
function noise(len) { var s = 99, out = '', i; for (i = 0; i < len; i++) { s = (s * 1103515245 + 12345) & 0x7fffffff; out += String.fromCharCode(0x4E00 + (s % 20000)); } return out; }
var EMOJI = '😀 🏃‍♂️ 👨‍👩‍👧‍👦 ❤️‍🔥 🇮🇶 ✅ 📚';
var LONG = arabicText(1900, 3) + '\nرابط مفيد: https://example.com/lesson?id=5&x=y\n' + EMOJI;
var P1 = { subject: 'اللغة العربية', title: 'درس الحال 😀', date: TODAY, content: LONG, homework: 'حل التمرين ٣ ص ١٢ 📚', group: 'الخامس العلمي — ب', pages: 'ص 10-12', notes: 'أحضروا الدفاتر' };
var P2 = { subject: 'الرياضيات', title: 'المعادلات', date: '2026-10-23', content: 'حل المعادلة س + ٣ = ٧\nالجواب: س = ٤', homework: '' };
var LEGACY = { 'marsa.academic.preparations.cls_demo': '{"schemaVersion":1,"records":[{"recordId":"x1","subject":"فيزياء","title":"تحضير قديم من التطبيق الكامل","date":"2026-10-01","content":"ن"}]}', 'marsa.students': '[{"name":"طالب تجريبي"}]', 'marsa.ui.v1': '{"a":1}', 'other.app.key': 'قيمة 😀' };
var SAVED_BEFORE = { schemaVersion: 1, records: [
  { id: 'old000001', subject: 'كيمياء', title: 'محفوظ سابقاً ١', date: '2026-10-20', content: 'محتوى قديم ١', sourceUpdatedAt: 5, addedAt: '2026-10-20T08:00:00.000Z', createdAt: '2026-10-20T08:00:00.000Z', updatedAt: '2026-10-20T08:00:00.000Z' },
  { id: 'old000002', subject: 'أحياء', title: 'محفوظ سابقاً ٢', date: '2026-10-21', content: 'محتوى قديم ٢', homework: 'واجب قديم', pages: 'ص ٥', notes: 'ملاحظة قديمة', sourceUpdatedAt: 6, addedAt: '2026-10-21T08:00:00.000Z', createdAt: '2026-10-21T08:00:00.000Z', updatedAt: '2026-10-21T08:00:00.000Z' }] };

// ===== أدوات =====
function serve() {
  var types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.md': 'text/markdown; charset=utf-8' };
  return new Promise(function (resolve) {
    server = http.createServer(function (req, res) {
      var p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
      var file = path.join(ROOT, p);
      if (file.indexOf(ROOT) !== 0 || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
      res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' }); fs.createReadStream(file).pipe(res);
    }).listen(0, '127.0.0.1', function () { BASE = 'http://localhost:' + server.address().port; resolve(); });
  });
}
async function device(browser, o) {
  o = o || {};
  var ctx = await browser.newContext({ viewport: o.viewport || { width: 390, height: 800 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', colorScheme: o.scheme || 'light', permissions: o.noClip ? [] : ['clipboard-read', 'clipboard-write'] });
  if (o.seed) await ctx.addInitScript(function (seed) { try { if (!sessionStorage.getItem('seeded')) { Object.keys(seed).forEach(function (k) { localStorage.setItem(k, seed[k]); }); sessionStorage.setItem('seeded', '1'); } } catch (e) { /* لا شيء */ } }, o.seed);
  if (o.init) await ctx.addInitScript(o.init);
  var isIndex = !o.url || /index\.html/.test(o.url);
  // 01.03: الترحيب يظهر أول مرة فقط؛ هذه الأجهزة تبدأ كمستخدم أنهى الترحيب سابقاً كي تبقى كل رحلات الكود كما هي (اختبار الترحيب نفسه في e2e-v1-ui)
  if (isIndex && !o.firstRun) await ctx.addInitScript(function () { try { if (!sessionStorage.getItem('ui-seeded')) { if (localStorage.getItem('marsa.v1.ui') === null) localStorage.setItem('marsa.v1.ui', JSON.stringify({ schemaVersion: 1, mode: 'student', appUrl: '', welcomed: true })); sessionStorage.setItem('ui-seeded', '1'); } } catch (e) { /* لا شيء */ } });
  var page = await ctx.newPage(), label = o.label || 'device';
  page.on('pageerror', function (e) { jsErrors.push(label + ': ' + e.message); });
  if (!o.ignoreConsole) page.on('console', function (m) { if (m.type() === 'error') jsErrors.push(label + ' console: ' + m.text()); });
  page.on('request', function (r) { allRequests.push(label + ' ' + r.url()); });
  page.on('dialog', function (d) { jsErrors.push(label + ' unexpected dialog: ' + d.message()); d.dismiss(); });
  await page.clock.install({ time: new Date(o.clock || NOW) });
  await page.goto(o.url || (BASE + '/index.html'));
  await page.waitForSelector(o.waitFor || '#app h1');
  if (isIndex) await page.waitForSelector('#intro', { state: 'detached', timeout: 10000 }); // الانترو ≈1.5ث عند كل فتح ثم يزول
  return { ctx: ctx, page: page };
}
async function setMode(page, m) { await page.click('.seg button[data-m="' + m + '"]'); await page.waitForSelector('html[data-mode="' + m + '"]'); }
async function fillForm(page, v) {
  await page.fill('#f-subject', v.subject); await page.fill('#f-title', v.title);
  if (v.date) await page.fill('#f-date', v.date);
  await page.fill('#f-content', v.content); if (v.homework) await page.fill('#f-homework', v.homework);
  if (v.group || v.pages || v.notes) {
    if (!(await page.$eval('details.more', function (d) { return d.open; }))) await page.click('details.more > summary');
    if (v.group) await page.fill('#f-group', v.group); if (v.pages) await page.fill('#f-pages', v.pages); if (v.notes) await page.fill('#f-notes', v.notes);
  }
}
async function createAndShare(page, v) {
  await page.goto(BASE + '/index.html#/new'); await page.waitForSelector('#f-subject');
  await fillForm(page, v);
  await page.click('button[type=submit]'); await page.waitForSelector('.prep');
  await page.click('button:has-text("حفظ وإنشاء الكود")'); await page.waitForSelector('textarea.codebox:not(.msg)');
  return shareData(page);
}
async function shareData(page) {
  await page.waitForFunction(function () { var t = document.querySelector('textarea.codebox:not(.msg)'); return t && t.value.indexOf('MARSA1-') === 0; });
  return { code: await page.inputValue('textarea.codebox:not(.msg)'), msg: await page.inputValue('textarea.codebox.msg'), id: (await page.evaluate(function () { return location.hash; })).split('/')[2] };
}
async function importPreview(page, text) {
  await page.goto(BASE + '/index.html#/add'); await page.waitForSelector('#code-in');
  await page.fill('#code-in', text); await page.click('button:has-text("معاينة التحضير")');
}
async function savedTitles(page) { await page.goto(BASE + '/index.html#/saved'); await page.waitForSelector('#app h1'); return page.$$eval('a.card h3', function (l) { return l.map(function (x) { return x.textContent; }); }); }
async function storageDump(page) { return page.evaluate(function () { var o = {}, i, k; for (i = 0; i < localStorage.length; i++) { k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; }); }
async function noteText(page, kind) { var el = await page.$('#app .note.' + kind); return el ? (await el.innerText()) : ''; }
async function overflow(page) { return page.evaluate(function () { return document.documentElement.scrollWidth - window.innerWidth; }); }
function lum(c) { var a = c.map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2]; }
async function contrast(page, sels) {
  return page.evaluate(function (sels) {
    function parse(s) { var m = /rgba?\(([^)]+)\)/.exec(s); if (!m) return null; var p = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; }
    function bgOf(el) { var e = el; while (e) { var c = parse(getComputedStyle(e).backgroundColor); if (c && c.a > 0.95) return c; e = e.parentElement; } return { r: 255, g: 255, b: 255, a: 1 }; }
    function L(c) { var a = [c.r, c.g, c.b].map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2]; }
    var out = [];
    sels.forEach(function (s) { var el = document.querySelector(s); if (!el) { out.push({ sel: s, missing: true }); return; } var fg = parse(getComputedStyle(el).color), bg = bgOf(el), l1 = L(fg), l2 = L(bg), r = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05), fs = parseFloat(getComputedStyle(el).fontSize), bold = parseInt(getComputedStyle(el).fontWeight, 10) >= 700; out.push({ sel: s, ratio: Math.round(r * 100) / 100, need: (fs >= 24 || (fs >= 18.66 && bold)) ? 3 : 4.5 }); });
    return out;
  }, sels);
}
function badContrast(rep) { return rep.filter(function (r) { return r.missing || r.ratio < r.need; }).map(function (r) { return r.missing ? r.sel + '=غير موجود' : r.sel + '=' + r.ratio + '<' + r.need; }).join(' | '); }

(async function () {
  await serve();
  var browser = await pw.chromium.launch();
  try {
    // ================= ١) الصفحة الرئيسية والهوية =================
    var A = await device(browser, { label: 'rep', init: function () { /* بلا navigator.share */ } }), pa = A.page;
    var lang = await pa.evaluate(function () { return { lang: document.documentElement.lang, dir: document.documentElement.dir, title: document.title, vp: document.querySelector('meta[name=viewport]').content }; });
    check('V1 الصفحة عربية RTL ولها عنوان وviewport للهاتف', lang.lang === 'ar' && lang.dir === 'rtl' && /مَرسى/.test(lang.title) && /width=device-width/.test(lang.vp), JSON.stringify(lang));
    var tiles = await pa.$$eval('a.tile', function (l) { return l.map(function (x) { return x.querySelector('b').textContent; }); });
    check('V1 رئيسية الطالب الافتراضية: «إضافة تحضير» و«تحضيراتي» فقط (بلا إحصائيات ولا بطاقات)', tiles.join('|') === 'إضافة تحضير|تحضيراتي' && (await pa.$$('#app .card, #app .stat, #app canvas, #app table')).length === 0, tiles.join('|'));
    await setMode(pa, 'rep');
    tiles = await pa.$$eval('a.tile', function (l) { return l.map(function (x) { return x.querySelector('b').textContent; }); });
    check('V1 رئيسية الممثل: «إنشاء تحضير» و«تحاضير أنشأتها»', tiles.join('|') === 'إنشاء تحضير|تحاضير أنشأتها', tiles.join('|'));
    check('V1 وضع الممثل يُحفظ بعد التحديث', (await (async function () { await pa.reload(); await pa.waitForSelector('#app h1'); return pa.getAttribute('html', 'data-mode'); })()) === 'rep');

    // ================= ٢) إنشاء تحضير بنص عربي ورموز ومحتوى طويل =================
    await pa.click('a.tile.primary'); await pa.waitForSelector('#f-subject');
    check('V1 النموذج: التاريخ الافتراضي اليوم، والحقول الاختيارية الأخرى مطوية', (await pa.inputValue('#f-date')) === TODAY && !(await pa.$eval('details.more', function (d) { return d.open; })));
    await pa.click('button[type=submit]');
    var errs = await pa.$$eval('.err', function (l) { return l.map(function (x) { return x.textContent; }).filter(Boolean); });
    check('V1 الإرسال الفارغ: أخطاء عربية للمادة والعنوان والمحتوى مع تركيز أول خطأ', errs.length === 3 && errs.every(function (e) { return /[\u0600-\u06FF]/.test(e); }) && (await pa.evaluate(function () { return document.activeElement.id; })) === 'f-subject', errs.join('|'));
    await fillForm(pa, P1);
    var counter = await pa.textContent('.counter');
    check('V1 عدّاد المحتوى يظهر ويحسب الحروف', new RegExp('^' + LONG.length + ' / 2000$').test(counter.trim()), counter);
    await pa.click('button[type=submit]'); await pa.waitForSelector('.prep');
    var prevText = await pa.innerText('.prep');
    check('V1 المعاينة قبل الحفظ تعرض كل المعلومات والرموز كما سيراها الطالب', ['اللغة العربية', 'درس الحال 😀', 'الخامس العلمي — ب', '🏃‍♂️', '👨‍👩‍👧‍👦', 'حل التمرين ٣', 'ص 10-12', 'أحضروا الدفاتر', 'اليوم'].every(function (s) { return prevText.indexOf(s) > -1; }), prevText.slice(0, 300));
    check('V1 المعاينة: الرابط يظهر رابطاً آمناً (noopener) والنص الآخر نص', (await pa.$$eval('.prep a', function (l) { return l.map(function (a) { return a.href + '|' + a.rel + '|' + a.target; }); })).join() === 'https://example.com/lesson?id=5&x=y|noopener noreferrer|_blank');
    var bbSave = await pa.locator('button:has-text("حفظ وإنشاء الكود")').boundingBox();
    check('V1 زر «حفظ وإنشاء الكود» ظاهر دون تمرير حتى مع معاينة طويلة (شريط لاصق)', !!bbSave && bbSave.y >= 0 && bbSave.y + bbSave.height <= 801, JSON.stringify(bbSave));
    check('V1 المعاينة لم تحفظ شيئاً بعد', (await storageDump(pa))['marsa.v1.mine'] === undefined);
    await pa.click('button:has-text("حفظ وإنشاء الكود")'); await pa.waitForSelector('textarea.codebox:not(.msg)');
    var S1 = await shareData(pa);
    check('V1 بعد الحفظ: صفحة المشاركة بكود حقيقي MARSA1- وحقل نسخ ورسالة', /^MARSA1-[A-Za-z0-9+\/]+$/.test(S1.code) && S1.msg.indexOf(S1.code) > -1 && (await pa.innerText('h1')) === 'تم حفظ التحضير', S1.code.slice(0, 30));
    check('V1 الحفظ على جهاز الممثل: التحضير في التخزين المحلي (marsa.v1.mine)', JSON.parse((await storageDump(pa))['marsa.v1.mine']).records.length === 1);
    var hint = await pa.innerText('.hint >> nth=0');
    check('V1 يعرض طول الكود ويصرّح بأنه يطول بطول التحضير', /طول الكود: \d+ حرفاً/.test(hint) && /طال الكود/.test(hint), hint);
    console.log('   • طول كود التحضير التجريبي الطويل (' + LONG.length + ' حرفاً عربياً): ' + S1.code.length + ' حرفاً');
    check('V1 الرسالة: المادة والعنوان والصف والتاريخ العربي والكود داخل ``` وطريقة الاستيراد', ['المادة: اللغة العربية', 'العنوان: درس الحال 😀', 'الصف: الخامس العلمي — ب', 'التاريخ: ', 'أكتوبر 2026', '«إضافة تحضير»', '«معاينة التحضير»', '«إضافة إلى تحضيراتي»'].every(function (s) { return S1.msg.indexOf(s) > -1; }) && (S1.msg.match(/```/g) || []).length === 2, S1.msg.slice(0, 200));
    check('V1 الكود عرضه LTR في مربع للقراءة فقط وقابل للتمرير/التمدد', await pa.$eval('textarea.codebox:not(.msg)', function (t) { return t.readOnly && getComputedStyle(t).direction === 'ltr' && getComputedStyle(t).wordBreak === 'break-all'; }));
    var wa = await pa.getAttribute('a:has-text("فتح واتساب")', 'href');
    check('V1 رابط واتساب https://wa.me/?text= ويحمل الرسالة نفسها', wa.indexOf('https://wa.me/?text=') === 0 && decodeURIComponent(wa.slice(20)) === S1.msg);
    check('V1 بلا Web Share: لا يظهر زر «مشاركة الرسالة» ويبقى فتح واتساب أساسياً + النسخ اليدوي', (await pa.$$('button:has-text("مشاركة الرسالة")')).length === 0 && /primary/.test(await pa.getAttribute('a:has-text("فتح واتساب")', 'class')) && (await pa.$$('button:has-text("نسخ الرسالة")')).length === 1);
    await pa.click('button:has-text("نسخ الكود")'); await pa.waitForFunction(function () { return /تم نسخ الكود/.test(document.getElementById('status').textContent); });
    check('V1 «نسخ الكود» ينسخ الكود فعلاً إلى الحافظة', (await pa.evaluate(function () { return navigator.clipboard.readText(); })) === S1.code);
    await pa.click('button:has-text("نسخ الرسالة")'); await pa.waitForFunction(function () { return /تم نسخ الرسالة/.test(document.getElementById('status').textContent); });
    var clipMsg = await pa.evaluate(function () { return navigator.clipboard.readText(); });
    check('V1 «نسخ الرسالة» ينسخ الرسالة الكاملة بكودها', clipMsg === S1.msg);

    // ================= إعادة النسخ من قائمة الممثل بعد التحديث =================
    await pa.goto(BASE + '/index.html#/mine'); await pa.waitForSelector('.card');
    check('V1 تحاضير الممثل: بطاقة بالمادة والعنوان والصف والتاريخ وأزرار الكود/التعديل/الحذف', await pa.$eval('.card', function (c) { var t = c.innerText; return t.indexOf('اللغة العربية') > -1 && t.indexOf('درس الحال') > -1 && t.indexOf('الخامس العلمي') > -1 && t.indexOf('الكود والرسالة') > -1 && t.indexOf('تعديل') > -1 && t.indexOf('حذف') > -1; }));
    await pa.click('a:has-text("الكود والرسالة")'); var S1b = await shareData(pa);
    check('V1 إعادة فتح الكود بعد التحديث تعطي نفس الكود حرفياً (لم يتغير التحضير)', S1b.code === S1.code && (await pa.innerText('h1')) === 'الكود والرسالة');

    // ================= المسودة =================
    await pa.goto(BASE + '/index.html#/new'); await pa.waitForSelector('#f-subject');
    await pa.fill('#f-subject', 'مسودة'); await pa.fill('#f-content', 'نص غير مكتمل 😀'); await pa.waitForTimeout(500);
    await pa.reload(); await pa.waitForSelector('#f-subject');
    check('V1 المسودة تُسترجع بعد تحديث الصفحة', (await pa.inputValue('#f-subject')) === 'مسودة' && (await pa.inputValue('#f-content')) === 'نص غير مكتمل 😀');
    await pa.click('button:has-text("مسح الحقول")'); await pa.click('#dlg button:has-text("مسح")'); await pa.waitForFunction(function () { return document.getElementById('f-subject').value === ''; });
    check('V1 مسح الحقول يتطلب تأكيداً ويحذف المسودة', (await storageDump(pa))['marsa.v1.draft'] === undefined);

    // ================= ٣) جهاز الطالب (تخزين مستقل تماماً) =================
    var B = await device(browser, { label: 'student', seed: Object.assign({ 'marsa.v1.saved': JSON.stringify(SAVED_BEFORE) }, LEGACY) }), pb = B.page;
    check('V1 جهاز الطالب لا يرى شيئاً من جهاز الممثل (تخزين منفصل)', (await storageDump(pb))['marsa.v1.mine'] === undefined);
    var legacyBefore = {}; var dump0 = await storageDump(pb); Object.keys(LEGACY).forEach(function (k) { legacyBefore[k] = dump0[k]; });
    var savedBefore = dump0['marsa.v1.saved'];
    // أخطاء الكود
    await pb.goto(BASE + '/index.html#/add'); await pb.waitForSelector('#code-in');
    await pb.click('button:has-text("معاينة التحضير")'); await pb.waitForSelector('.note.err');
    check('V1 كود فارغ ⇒ رسالة عربية واضحة ولا تُضاف تحضيرات', /الصق الكود أولاً/.test(await noteText(pb, 'err')));
    var cases = [['hello world', /ليس كود مَرسى/], [S1.code.slice(0, Math.floor(S1.code.length * 0.6)), /ناقص/], [S1.code.slice(0, 80) + (S1.code.charAt(80) === 'Q' ? 'R' : 'Q') + S1.code.slice(81), /تالف/], ['MARSA2-' + S1.code.slice(7), /إصدار أحدث/], ['MARSA1-' + S1.code.slice(7, 12), /ناقص/]];
    for (var ci = 0; ci < cases.length; ci++) {
      await pb.fill('#code-in', cases[ci][0]); await pb.click('button:has-text("معاينة التحضير")'); await pb.waitForSelector('.note.err');
      var en = await noteText(pb, 'err');
      check('V1 كود خاطئ/ناقص/تالف/غير مدعوم (' + (ci + 1) + '): ' + cases[ci][1], cases[ci][1].test(en) && (await pb.$$('.prep')).length === 0 && (await pb.getAttribute('#code-in', 'aria-invalid')) === 'true', en);
    }
    check('V1 الأكواد الخاطئة لم تغيّر التخزين إطلاقاً', (await storageDump(pb))['marsa.v1.saved'] === savedBefore);

    // لصق الرسالة كاملة عبر زر «لصق من الحافظة» الحقيقي
    await pb.evaluate(function (t) { return navigator.clipboard.writeText(t); }, clipMsg);
    await pb.fill('#code-in', ''); await pb.click('button:has-text("لصق من الحافظة")'); await pb.waitForSelector('.prep');
    check('V1 «لصق من الحافظة» يلتقط الكود من رسالة واتساب كاملة ويعرض المعاينة تلقائياً', (await pb.inputValue('#code-in')) === clipMsg && /درس الحال 😀/.test(await pb.innerText('.prep')));
    var pvText = await pb.innerText('.prep');
    check('V1 معاينة الطالب مطابقة لمعاينة الممثل (مادة/عنوان/صف/محتوى/واجب/رموز مركّبة/تاريخ)', ['اللغة العربية', 'درس الحال 😀', 'الخامس العلمي — ب', '🏃‍♂️', '👨‍👩‍👧‍👦', '❤️‍🔥', 'حل التمرين ٣', 'ص 10-12', 'أحضروا الدفاتر', 'اليوم'].every(function (s) { return pvText.indexOf(s) > -1; }) && (await pb.$$('button:has-text("إضافة إلى تحضيراتي")')).length === 1);
    var bbAdd = await pb.locator('button:has-text("إضافة إلى تحضيراتي")').boundingBox();
    check('V1 زر «إضافة إلى تحضيراتي» ظاهر في الشاشة دون تمرير حتى مع معاينة طويلة (شريط لاصق)', !!bbAdd && bbAdd.y >= 0 && bbAdd.y + bbAdd.height <= 801, JSON.stringify(bbAdd));
    check('V1 المعاينة لا تكتب في التخزين قبل الضغط على «إضافة إلى تحضيراتي»', (await storageDump(pb))['marsa.v1.saved'] === savedBefore);
    await pb.click('button:has-text("إضافة إلى تحضيراتي")'); await pb.waitForSelector('.note.ok');
    check('V1 رسالة نجاح عربية بعد الإضافة مع أزرار فتح/تحضيراتي/إضافة آخر', /تمت إضافة «درس الحال 😀» إلى تحضيراتي/.test(await noteText(pb, 'ok')) && (await pb.$$('a:has-text("فتح التحضير"), a:has-text("تحضيراتي"), button:has-text("إضافة تحضير آخر")')).length === 3);
    var dump1 = await storageDump(pb), saved1 = JSON.parse(dump1['marsa.v1.saved']);
    check('V1 الإضافة لم تمسح التحاضير القديمة وأبقتها كما هي حرفياً', saved1.records.length === 3 && JSON.stringify(saved1.records.slice(0, 2)) === JSON.stringify(SAVED_BEFORE.records));
    check('V1 مفاتيح التطبيق الكامل والتطبيقات الأخرى لم تُمسّ (بايتاً ببايت)', Object.keys(LEGACY).every(function (k) { return dump1[k] === legacyBefore[k]; }));
    check('V1 بيانات التحضير المحفوظة تطابق الأصل (بما فيها الرموز المركّبة)', saved1.records[2].content.indexOf('🏃‍♂️') > -1 && saved1.records[2].group === 'الخامس العلمي — ب' && saved1.records[2].homework === 'حل التمرين ٣ ص ١٢ 📚' && saved1.records[2].id === S1.id);

    // ٧) التحديث والبقاء
    await pb.reload(); await pb.waitForSelector('#app h1');
    var titles = await savedTitles(pb);
    check('V1 بعد تحديث الصفحة: التحضير باقٍ مع القديمين (٣ تحضيرات)', titles.length === 3 && titles.indexOf('درس الحال 😀') > -1, titles.join('|'));
    check('V1 «تحضيراتي» تعرض المادة والعنوان والتاريخ وجزءاً من المحتوى', await pb.$$eval('a.card', function (l) { var c = l.filter(function (x) { return x.innerText.indexOf('درس الحال') > -1; })[0]; return !!c && /اللغة العربية/.test(c.innerText) && /أكتوبر 2026/.test(c.innerText) && /اليوم/.test(c.innerText) && c.querySelector('.snip').textContent.length > 20; }));
    await pb.click('a.card:has-text("درس الحال")'); await pb.waitForSelector('article.prep');
    var dText = await pb.innerText('article.prep');
    check('V1 فتح التحضير للقراءة الكاملة: المحتوى والواجب والصفحات والملاحظات وتاريخ الإضافة', ['الحال', 'الواجب', 'صفحات الكتاب', 'ملاحظات', 'أُضيف إلى تحضيراتي في', '🏃‍♂️'].every(function (s) { return dText.indexOf(s) > -1; }) && (await pb.$$('button:has-text("حذف من تحضيراتي")')).length === 1);

    // ١٠) التكرار
    await importPreview(pb, S1.code);
    await pb.waitForSelector('.note.warn');
    check('V1 إدخال الكود نفسه ثانية: تنبيه «موجود مسبقاً» بلا زر إضافة', /موجود عندك مسبقاً/.test(await noteText(pb, 'warn')) && (await pb.$$('button:has-text("إضافة إلى تحضيراتي")')).length === 0 && (await pb.$$('a:has-text("فتح النسخة المحفوظة")')).length === 1);
    check('V1 التكرار لم يضف شيئاً', (await savedTitles(pb)).length === 3);
    await importPreview(pb, clipMsg); await pb.waitForSelector('.note.warn');
    check('V1 لصق الرسالة الكاملة نفسها ثانية: يُمنع التكرار أيضاً', /موجود عندك مسبقاً/.test(await noteText(pb, 'warn')) && (await savedTitles(pb)).length === 3);

    // فشل الكتابة لا يفسد المخزّن
    var P2s = await createAndShare(pa, P2);
    var rawBefore = (await storageDump(pb))['marsa.v1.saved'];
    await importPreview(pb, P2s.code); await pb.waitForSelector('.prep');
    await pb.evaluate(function () { var real = Storage.prototype.setItem; window.__real = real; Storage.prototype.setItem = function (k, v) { if (k === 'marsa.v1.saved') { var e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; } return real.call(this, k, v); }; });
    await pb.click('button:has-text("إضافة إلى تحضيراتي")'); await pb.waitForSelector('.note.err');
    check('V1 فشل الحفظ (مساحة ممتلئة): رسالة عربية «تعذّر الحفظ» ولا نجاح كاذب', /تعذّر الحفظ/.test(await noteText(pb, 'err')) && (await pb.$$('.note.ok')).length === 0);
    await pb.evaluate(function () { Storage.prototype.setItem = window.__real; });
    check('V1 فشل الاستيراد لم يفسد التخزين: القيمة المخزّنة كما كانت حرفياً', (await storageDump(pb))['marsa.v1.saved'] === rawBefore);
    await pb.click('button:has-text("إضافة إلى تحضيراتي")'); await pb.waitForSelector('.note.ok');
    check('V1 بعد زوال العطل تنجح الإضافة نفسها ويصبح العدد ٤', JSON.parse((await storageDump(pb))['marsa.v1.saved']).records.length === 4);

    // تحديث التحضير بعد تعديل الممثل
    await pa.goto(BASE + '/index.html#/edit/' + S1.id); await pa.waitForSelector('#f-content');
    check('V1 تعديل تحضير: الحقول معبّأة بقيمه (بما فيها الاختيارية)', (await pa.inputValue('#f-title')) === 'درس الحال 😀' && (await pa.inputValue('#f-group')) === 'الخامس العلمي — ب' && (await pa.$eval('details.more', function (d) { return d.open; })));
    await pa.fill('#f-content', 'محتوى بعد تعديل الممثل ✏️'); await pa.click('button[type=submit]'); await pa.waitForSelector('.prep');
    await pa.click('button:has-text("حفظ التعديل وإنشاء الكود")'); await pa.waitForSelector('textarea.codebox:not(.msg)'); var S1c = await shareData(pa);
    check('V1 بعد التعديل: كود جديد بنفس المعرّف مع تنبيه للممثل', S1c.code !== S1.code && S1c.id === S1.id && /حُفظ التعديل/.test(await pa.innerText('#app')));
    await importPreview(pb, S1c.code); await pb.waitForSelector('.note.warn');
    check('V1 الطالب: كود معدّل لتحضير موجود ⇒ يُسأل عن التحديث (ليس إضافة مكررة)', /عندك نسخة سابقة/.test(await noteText(pb, 'warn')) && (await pb.$$('button:has-text("تحديث نسختي")')).length === 1 && (await pb.$$('button:has-text("إضافة إلى تحضيراتي")')).length === 0);
    await pb.click('button:has-text("تحديث نسختي")'); await pb.waitForSelector('.note.ok');
    var after = JSON.parse((await storageDump(pb))['marsa.v1.saved']).records;
    check('V1 التحديث يستبدل النسخة نفسها دون تكرار ودون مسّ البقية', after.length === 4 && after.filter(function (r) { return r.id === S1.id; })[0].content === 'محتوى بعد تعديل الممثل ✏️' && JSON.stringify(after.slice(0, 2)) === JSON.stringify(SAVED_BEFORE.records));
    await importPreview(pb, S1.code); await pb.waitForSelector('.note.warn');
    check('V1 الكود القديم بعد التحديث ⇒ «عندك نسخة أحدث» ولا يرجّع القديم', /نسخة أحدث/.test(await noteText(pb, 'warn')) && JSON.parse((await storageDump(pb))['marsa.v1.saved']).records.filter(function (r) { return r.id === S1.id; })[0].content === 'محتوى بعد تعديل الممثل ✏️');

    // الحذف
    await pb.goto(BASE + '/index.html#/saved'); await pb.click('a.card:has-text("المعادلات")'); await pb.waitForSelector('article.prep');
    await pb.click('button:has-text("حذف من تحضيراتي")'); await pb.waitForSelector('#dlg[open]'); await pb.click('#dlg button:has-text("إلغاء")');
    check('V1 إلغاء الحذف لا يحذف شيئاً', (await savedTitles(pb)).length === 4);
    await pb.click('a.card:has-text("المعادلات")'); await pb.click('button:has-text("حذف من تحضيراتي")'); await pb.waitForSelector('#dlg[open]'); await pb.click('#dlg button:has-text("حذف")'); await pb.waitForSelector('#app h1:has-text("تحضيراتي")');
    titles = await savedTitles(pb);
    check('V1 الحذف يزيل تحضيراً واحداً فقط ويُبقي البقية', titles.length === 3 && titles.indexOf('المعادلات') < 0, titles.join('|'));

    // أمان العرض
    var evil = { subject: '<img src=x onerror=alert(1)>', title: '<script>window.__x=1</script>عنوان', date: TODAY, content: '<img src=x onerror="window.__y=1"> <b>غامق</b> javascript:alert(2) [رابط](javascript:alert(3)) https://example.com/<b>' };
    var Se = await createAndShare(pa, evil);
    await importPreview(pb, Se.code); await pb.waitForSelector('.prep');
    var inj = await pb.evaluate(function () { return { img: document.querySelectorAll('.prep img, #app img').length, scr: document.querySelectorAll('#app script').length, b: document.querySelectorAll('.prep b').length, x: window.__x, y: window.__y, anchors: Array.prototype.map.call(document.querySelectorAll('.prep a'), function (a) { return a.href; }), text: document.querySelector('.prep').textContent }; });
    check('V1 HTML/سكربت داخل التحضير يُعرض نصاً حرفياً: لا عناصر ولا تنفيذ ولا روابط javascript:', inj.img === 0 && inj.scr === 0 && inj.b === 0 && inj.x === undefined && inj.y === undefined && inj.anchors.every(function (h) { return /^https?:/.test(h); }) && inj.text.indexOf('<b>غامق</b>') > -1, JSON.stringify(inj).slice(0, 300));
    await pb.click('button:has-text("إضافة إلى تحضيراتي")'); await pb.waitForSelector('.note.ok');
    await pb.click('a:has-text("فتح التحضير")'); await pb.waitForSelector('article.prep');
    check('V1 المحفوظ الخبيث يُقرأ لاحقاً نصاً أيضاً (لا حقن عند القراءة)', (await pb.$$('article.prep img, article.prep b, #app script')).length === 0 && (await pb.evaluate(function () { return window.__x === undefined && window.__y === undefined; })));

    // ================= محتوى غير قابل للضغط (كود طويل جداً) =================
    var BIG = { subject: 'اختبار حدّي', title: 'ع'.repeat(100), date: TODAY, content: noise(1990), homework: noise(480), notes: noise(900), pages: noise(70), group: 'ج'.repeat(55) };
    var Sb = await createAndShare(pa, BIG);
    console.log('   • أسوأ حالة (محتوى غير قابل للضغط بحدود الحقول): كود ' + Sb.code.length + ' حرفاً');
    check('V1 الكود الطويل جداً: تحذير «الكود طويل» وإخفاء رابط واتساب الطويل مع بقاء النسخ', /الكود طويل/.test(await pa.innerText('#app .note.warn')) && (await pa.$$eval('a:has-text("فتح واتساب")', function (l) { return l.every(function (a) { return a.hidden; }); })) && /الرسالة طويلة/.test(await pa.innerText('.hint >> nth=-1')) && (await pa.$$('button:has-text("نسخ الرسالة")')).length === 1, String(Sb.code.length));
    await importPreview(pb, Sb.msg); await pb.waitForSelector('.prep'); await pb.click('button:has-text("إضافة إلى تحضيراتي")'); await pb.waitForSelector('.note.ok');
    var big = JSON.parse((await storageDump(pb))['marsa.v1.saved']).records.filter(function (r) { return r.id === Sb.id; })[0];
    check('V1 الكود الطويل جداً يُستورد سليماً بحروفه الكاملة', !!big && big.content === BIG.content && big.notes === BIG.notes && big.homework === BIG.homework && big.title === BIG.title);

    // ================= Web Share + عدم الاتصال + الشبكة =================
    var C = await device(browser, { label: 'rep-share-api', init: function () { navigator.share = function (d) { window.__shared = d; return Promise.resolve(); }; } });
    var Sc = await createAndShare(C.page, P2);
    check('V1 مع Web Share: يظهر «مشاركة الرسالة» أساسياً ويمرّر الرسالة كاملة', (await C.page.$$('button.primary:has-text("مشاركة الرسالة")')).length === 1);
    await C.page.click('button:has-text("مشاركة الرسالة")'); await C.page.waitForFunction(function () { return !!window.__shared; });
    check('V1 مشاركة النظام تستلم النص الذي يحوي الكود', (await C.page.evaluate(function () { return window.__shared.text; })) === Sc.msg);
    var D = await device(browser, { label: 'rep-share-abort', init: function () { navigator.share = function () { var e = new Error('x'); e.name = 'AbortError'; return Promise.reject(e); }; } });
    await createAndShare(D.page, P2); await D.page.click('button:has-text("مشاركة الرسالة")'); await D.page.waitForTimeout(300);
    check('V1 إلغاء المستخدم لنافذة المشاركة لا يُظهر رسالة خطأ', !/تعذّرت/.test(await D.page.textContent('#status')));
    var E = await device(browser, { label: 'offline-student' });
    await E.ctx.setOffline(true);
    await importPreview(E.page, Sc.code); await E.page.waitForSelector('.prep'); await E.page.click('button:has-text("إضافة إلى تحضيراتي")'); await E.page.waitForSelector('.note.ok');
    check('V1 يعمل دون إنترنت: استيراد وقراءة تحضير والمتصفح في وضع عدم الاتصال', (await savedTitles(E.page)).join() === 'المعادلات');
    var ext = allRequests.filter(function (r) { var u = r.replace(/^\S+ /, ''); return !(u.indexOf(BASE) === 0 || /^data:/.test(u) || /^file:/.test(u)); });
    check('V1 لا أي طلب شبكة خارجي أثناء كل الجلسات (خطوط/مكتبات/تحليلات/خوادم)', ext.length === 0, ext.slice(0, 5).join(' | '));

    // ================= التنقل وزر الرجوع =================
    await pb.goto(BASE + '/index.html#/'); await pb.click('a.tile:has-text("تحضيراتي")'); await pb.click('a.card >> nth=0'); await pb.waitForSelector('article.prep'); await pb.goBack(); await pb.waitForSelector('a.card');
    check('V1 زر الرجوع في الهاتف يعود إلى القائمة ثم الرئيسية', (await pb.evaluate(function () { return location.hash; })) === '#/saved' && (await (async function () { await pb.goBack(); await pb.waitForSelector('a.tile'); return pb.evaluate(function () { return location.hash; }); })()).replace('#/', '') === '');
    await pb.goto(BASE + '/index.html#/share/zzzzzz0000'); await pb.waitForSelector('#app h1');
    check('V1 رابط مجهول أو تحضير غير موجود: صفحة عربية هادئة لا انهيار', /غير موجود/.test(await pb.innerText('#app h1')) || /أهلاً/.test(await pb.innerText('#app h1')));
    await pb.goto(BASE + '/index.html#/%00weird/../x'); await pb.waitForSelector('#app h1');
    check('V1 مسار عشوائي يعود للرئيسية بلا أخطاء', /أهلاً بك/.test(await pb.innerText('#app h1')));
    await pb.goto(BASE + '/index.html#/new'); await pb.waitForSelector('#f-subject');
    check('V1 فتح مسار الممثل مباشرة يبدّل الوضع إلى ممثل تلقائياً', (await pb.getAttribute('html', 'data-mode')) === 'rep');
    await pb.goto(BASE + '/index.html#/preview'); await pb.waitForSelector('#f-subject');
    check('V1 المعاينة بلا بيانات (بعد تحديث الصفحة) تُعيد إلى النموذج لا إلى صفحة فارغة', (await pb.evaluate(function () { return location.hash; })) === '#/new');

    // ================= واجهة: لمس، تباين، تدفق، إتاحة =================
    var small = [];
    for (var pi = 0; pi < 5; pi++) {
      var route = ['#/', '#/new', '#/mine', '#/add', '#/saved'][pi];
      await pb.goto(BASE + '/index.html' + route); await pb.waitForSelector('#app h1');
      if (route === '#/new') await pb.click('details.more > summary');
      var sm = await pb.evaluate(function () {
        var out = [];
        Array.prototype.forEach.call(document.querySelectorAll('a.tile, .btn, .seg button, .back, a.card, input:not([type=hidden]), textarea, summary, .linkbtn, #brand'), function (e) {
          var r = e.getBoundingClientRect(); if (r.width === 0 || r.height === 0 || e.closest('[hidden]')) return;
          if (r.height < 43.5 || r.width < 43.5) out.push((e.className || e.tagName) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height) + ' ' + (e.textContent || '').trim().slice(0, 14));
        });
        return out;
      });
      small = small.concat(sm.map(function (s) { return route + ' ' + s; }));
    }
    check('V1 كل أهداف اللمس ٤٤px فأكثر (أزرار، روابط، حقول، تبويب الوضع) في الصفحات الخمس', small.length === 0, small.slice(0, 6).join(' | '));
    var ov = {};
    for (var wi = 0; wi < 3; wi++) {
      var W = [320, 390, 1280][wi]; await pb.setViewportSize({ width: W, height: 800 });
      for (var ri = 0; ri < 6; ri++) { var r2 = ['#/', '#/new', '#/mine', '#/add', '#/saved', '#/saved/' + Sb.id][ri]; await pb.goto(BASE + '/index.html' + r2); await pb.waitForSelector('#app h1'); var o = await overflow(pb); if (o > 1) ov[W + r2] = o; }
    }
    await pb.setViewportSize({ width: 320, height: 800 }); await pa.setViewportSize({ width: 320, height: 800 });
    await pa.goto(BASE + '/index.html#/share/' + Sb.id); await pa.waitForSelector('textarea.codebox'); var oa = await overflow(pa); if (oa > 1) ov['share320'] = oa;
    await pb.goto(BASE + '/index.html#/add'); await pb.fill('#code-in', Sb.code); await pb.click('button:has-text("معاينة التحضير")'); await pb.waitForSelector('.prep'); var ob = await overflow(pb); if (ob > 1) ov['add-long320'] = ob;
    check('V1 لا تمرير أفقي في أي صفحة عند ٣٢٠/٣٩٠/١٢٨٠ (بما فيها الكود الطويل)', Object.keys(ov).length === 0, JSON.stringify(ov));
    await pb.setViewportSize({ width: 390, height: 800 }); await pa.setViewportSize({ width: 390, height: 800 });
    await pb.goto(BASE + '/index.html#/saved'); await pb.waitForSelector('a.card'); await pb.click('a.card >> nth=0'); await pb.waitForSelector('article.prep');
    check('V1 التركيز ينتقل إلى عنوان الصفحة عند التنقل (قارئ الشاشة) ويوجد منطقة إعلان status', (await pb.evaluate(function () { return document.activeElement && document.activeElement.tagName; })) === 'H1' && (await pb.getAttribute('#status', 'aria-live')) === 'polite');
    var unnamed = await pb.evaluate(function () { return Array.prototype.filter.call(document.querySelectorAll('button, a[href], input, textarea, select'), function (e) { if (e.closest('[hidden]') || e.getBoundingClientRect().width === 0) return false; var n = (e.getAttribute('aria-label') || e.textContent || '').trim(); if (!n && e.id) { var l = document.querySelector('label[for="' + e.id + '"]'); n = l ? l.textContent.trim() : ''; } return !n; }).map(function (e) { return e.outerHTML.slice(0, 60); }); });
    check('V1 كل زر ورابط وحقل له اسم يمكن لقارئ الشاشة نطقه', unnamed.length === 0, unnamed.join(' | '));
    check('V1 لا يوجد onclick/إدراج HTML/روابط javascript: في صفحات التطبيق الحيّة', await pb.evaluate(function () { return !document.querySelector('[onclick],[onerror],[onload],[onchange],[oninput]') && !document.querySelector('a[href^="javascript:"]'); }));
    // تباين الألوان في الوضعين الفاتح والداكن: أي محدّد مفقود يُعدّ فشلاً (لا مرور بصمت)
    for (var si = 0; si < 2; si++) {
      var scheme = ['light', 'dark'][si], X = await device(browser, { label: 'contrast-' + scheme, scheme: scheme, seed: { 'marsa.v1.saved': JSON.stringify(SAVED_BEFORE) } }), px = X.page, bad = [], measured = 0;
      var chk = async function (sels) { var r = await contrast(px, sels); measured += r.length; var b = badContrast(r); if (b) bad.push(b); };
      await chk(['body', '.lead', '.tile b', '.tile small', '.tile.primary b', '.tile.primary small', '.count', '.seg button[aria-pressed=true]', '.seg button[aria-pressed=false]', '.foot p', '.foot .linkbtn', '.brand-text b']);
      await setMode(px, 'rep'); await chk(['.seg button[aria-pressed=true]']);
      await px.goto(BASE + '/index.html#/new'); await px.waitForSelector('#f-subject'); await px.click('button[type=submit]'); await px.waitForSelector('.err:not(:empty)');
      await chk(['.err:not(:empty)', '.f label', '.opt', '.counter', '.hint', 'details.more > summary', '.field', '.btn.primary', '.btn:not(.primary)']);
      var sx = await createAndShare(px, P2);
      await chk(['.back', '.sec-t', '.hint', '.codebox', '.codebox.msg', 'a.btn', '.card h3', '.card .meta', '.badge', 'button.btn']);
      await px.goto(BASE + '/index.html#/mine'); await px.waitForSelector('.card');
      await chk(['.card h3', '.card .meta', '.card .snip', '.badge', '.badge.today', '.card .btn.danger', '.card .btn.primary', '.card .btn:not(.primary):not(.danger)']);
      await setMode(px, 'student'); await px.goto(BASE + '/index.html#/add'); await px.waitForSelector('#code-in');
      await px.fill('#code-in', 'xyz'); await px.click('button:has-text("معاينة التحضير")'); await px.waitForSelector('.note.err');
      await chk(['.note.err', '.note.err strong', '.note.err p', '#code-in', '.btn.primary', '.btn:not(.primary)']);
      await px.fill('#code-in', sx.code); await px.click('button:has-text("معاينة التحضير")'); await px.waitForSelector('.prep');
      await chk(['.prep .meta', '.prep h2', '.prep .body', '.sec-t', '.sticky-actions .btn.primary']);
      await px.click('button:has-text("إضافة إلى تحضيراتي")'); await px.waitForSelector('.note.ok');
      await chk(['.note.ok', '.note.ok strong', '.note.ok p', 'a.btn.primary', 'button.btn']);
      await importPreview(px, sx.code); await px.waitForSelector('.note.warn');
      await chk(['.note.warn', '.note.warn strong', '.note.warn p', 'a.btn.primary']);
      await px.goto(BASE + '/index.html#/saved'); await px.waitForSelector('a.card');
      await chk(['.card h3', '.card .meta', '.card .snip', '.badge', '.btn.primary', '.back']);
      await px.goto(BASE + '/index.html#/saved/old000002'); await px.waitForSelector('article.prep');
      await chk(['.prep h3', '.prep .body', '.prep .meta', '.prep .foot-meta', '.btn.danger', '.back']);
      await px.click('button:has-text("حذف من تحضيراتي")'); await px.waitForSelector('#dlg[open]');
      await chk(['#dlg h2', '#dlg p', '#dlg .btn.danger', '#dlg .btn:not(.danger)']);
      console.log('   • قيس تباين ' + measured + ' عنصراً في الوضع ' + (scheme === 'light' ? 'الفاتح' : 'الداكن'));
      check('V1 تباين الألوان ≥ ٤٫٥ (٣ للنص الكبير) في الوضع ' + (scheme === 'light' ? 'الفاتح' : 'الداكن') + ' عبر كل الحالات (أخطاء/نجاح/تنبيه/حذف/قراءة)', bad.length === 0 && measured >= 70, bad.join(' | ') + ' measured=' + measured);
      await X.ctx.close();
    }

    // ================= file:// =================
    var F1 = await device(browser, { label: 'file-rep', url: 'file://' + path.join(ROOT, 'index.html'), noClip: true }), F2 = await device(browser, { label: 'file-student', url: 'file://' + path.join(ROOT, 'index.html'), noClip: true });
    await F1.page.goto('file://' + path.join(ROOT, 'index.html') + '#/new'); await F1.page.waitForSelector('#f-subject'); await fillForm(F1.page, P2);
    await F1.page.click('button[type=submit]'); await F1.page.waitForSelector('.prep'); await F1.page.click('button:has-text("حفظ وإنشاء الكود")');
    await F1.page.waitForFunction(function () { var t = document.querySelector('textarea.codebox:not(.msg)'); return t && t.value.indexOf('MARSA1-') === 0; });
    var Sf = { code: await F1.page.inputValue('textarea.codebox:not(.msg)'), msg: await F1.page.inputValue('textarea.codebox.msg') };
    await F1.page.click('button:has-text("نسخ الكود")'); await F1.page.waitForFunction(function () { return /تم نسخ الكود|تعذّر النسخ/.test(document.getElementById('status').textContent); });
    check('V1 فتحه من file:// يعمل: إنشاء تحضير وكود حقيقي، ونسخ الكود يُنجح أو يعرض النسخ اليدوي بوضوح', /^MARSA1-/.test(Sf.code) && /تم نسخ الكود|محدّد الآن/.test(await F1.page.textContent('#status')), await F1.page.textContent('#status'));
    await F2.page.goto('file://' + path.join(ROOT, 'index.html') + '#/add'); await F2.page.waitForSelector('#code-in'); await F2.page.fill('#code-in', Sf.msg); await F2.page.click('button:has-text("معاينة التحضير")'); await F2.page.waitForSelector('.prep'); await F2.page.click('button:has-text("إضافة إلى تحضيراتي")'); await F2.page.waitForSelector('.note.ok');
    await F2.page.reload(); await F2.page.goto('file://' + path.join(ROOT, 'index.html') + '#/saved'); await F2.page.waitForSelector('a.card');
    check('V1 file://: الطالب على جهاز آخر يستورد من الكود ويبقى التحضير بعد التحديث', (await F2.page.$$eval('a.card h3', function (l) { return l.map(function (x) { return x.textContent; }); })).join() === 'المعادلات');

    // ================= التطبيق الكامل المؤرشف ما زال يعمل =================
    // full.html يستعمل خط Google الخارجي (قديم، أُبقي كما هو): نتجاهل خطأ تحميل المورد الخارجي هنا ونعدّ أخطاء JavaScript فقط
    var errsBefore = jsErrors.length;
    var G = await device(browser, { label: 'full-archive', url: 'file://' + path.join(ROOT, 'full.html'), ignoreConsole: true, waitFor: '#intro, .nav' }).catch(function (e) { return { err: e }; });
    check('V1 التطبيق الكامل السابق (full.html) ما زال يُحمَّل ويعرض واجهته بلا أخطاء JavaScript', !G.err && jsErrors.length === errsBefore, (G.err && G.err.message) || jsErrors.slice(errsBefore).join(' | '));

    // ================= أخطاء JS =================
    check('V1 لا أخطاء JavaScript أو أخطاء كونسول في كل الجلسات', jsErrors.length === 0, jsErrors.slice(0, 5).join(' | '));
  } catch (e) {
    check('V1 لم ينهَر الاختبار بخطأ غير متوقع', false, (e && e.stack ? e.stack : String(e)).split('\n').slice(0, 4).join(' / '));
  } finally {
    await browser.close(); server.close();
    var failed = results.filter(function (r) { return !r.ok; }).length;
    console.log('\n' + (results.length - failed) + ' passed, ' + failed + ' failed (of ' + results.length + ')');
    process.exit(failed ? 1 : 0);
  }
})();
