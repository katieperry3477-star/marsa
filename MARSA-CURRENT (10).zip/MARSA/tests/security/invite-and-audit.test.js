// 5.04 — اختبارات مرجعية لرمز الدعوة وتدقيق الأحداث (نماذج خالصة؛ لا خادم). تشغيل: node tests/security/invite-and-audit.test.js
'use strict';
var fs = require('fs'), path = require('path'), oracle = require('./policy-oracle.js');
var ROOT = path.resolve(__dirname, '..', '..'), pass = 0, fail = 0;
function check(n, c, d) { if (c) { pass++; console.log('PASS ' + n); } else { fail++; console.log('FAIL ' + n + (d ? ' :: ' + d : '')); } }
var spec = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs/stage5/security/audit-events.json'), 'utf8'));
var NOW = Date.parse('2026-11-01T10:00:00Z'), DAY = 86400000;

// ---- رمز الدعوة ----
check('INV-01 إنتروبيا رمز الدعوة المقترح ≥ 48 بت', oracle.entropyBits(31, oracle.INVITE_LEN) >= 48, String(oracle.entropyBits(31, oracle.INVITE_LEN)));
check('INV-02 إنتروبيا studentCode الحالي (6 رموز) < 32 بت ⇒ معرّف لا سر', oracle.entropyBits(31, 6) < 32, String(oracle.entropyBits(31, 6)));
var seen = {}, dup = 0, i, c;
for (i = 0; i < 2000; i++) { c = oracle.generateInvite(); if (seen[c]) dup++; seen[c] = 1; if (!/^[2-9A-HJKMNP-Z]{10}$/.test(c)) dup += 1000; }
check('INV-03 المولِّد: 2000 رمز بلا تكرار وبالأبجدية الصحيحة', dup === 0, 'dup=' + dup);
function freshStore() {
  var good = 'ABCDEFGH23', st = { codes: {}, attempts: {}, members: [] };
  st.codes[oracle.hashCode(good)] = { role: 'student', classId: 'c1', studentId: 's1', expiresAt: NOW + 7 * DAY, redeemedBy: null, revoked: false };
  st.codes[oracle.hashCode('EXPIRED234')] = { role: 'student', classId: 'c1', studentId: 's2', expiresAt: NOW - 1000, redeemedBy: null, revoked: false };
  st.codes[oracle.hashCode('REVOKED234')] = { role: 'student', classId: 'c1', studentId: 's3', expiresAt: NOW + DAY, redeemedBy: null, revoked: true };
  st.codes[oracle.hashCode('USEDCODE23')] = { role: 'student', classId: 'c1', studentId: 's4', expiresAt: NOW + DAY, redeemedBy: 'u-old', revoked: false };
  return st;
}
check('INV-04 التخزين hash فقط: لا نص صريح كمفتاح ولا قيمة', Object.keys(freshStore().codes).every(function (k) { return /^[0-9a-f]{64}$/.test(k); }));
var st = freshStore(), r = oracle.redeemInvite(st, 'u1', 'abcdefgh23', NOW);
check('INV-05 رمز صالح (حتى بأحرف صغيرة/مسافات) ينشئ عضوية بدور وصف وطالب محدَّدة من الخادم', r.ok && st.members.length === 1 && st.members[0].role === 'student' && st.members[0].classId === 'c1' && st.members[0].studentId === 's1');
check('INV-06 إعادة استعمال الرمز نفسه (ولو من مستخدم آخر) مرفوضة', !oracle.redeemInvite(st, 'u2', 'ABCDEFGH23', NOW).ok && st.members.length === 1);
var msgs = ['WRONGCODE2', 'EXPIRED234', 'REVOKED234', 'USEDCODE23', '', null, undefined, 'short', 'ABCDEFGH2O'].map(function (x) { var s = freshStore(); return oracle.redeemInvite(s, 'uX', x, NOW); });
check('INV-07 كل أسباب الرفض (خاطئ/منتهٍ/ملغى/مستخدم/فارغ/قصير) تُرجع رسالة موحّدة واحدة', msgs.every(function (x) { return !x.ok && x.message === oracle.UNIFORM_FAIL; }) && new Set(msgs.map(function (x) { return JSON.stringify(x); })).size === 1);
st = freshStore(); var k; for (k = 0; k < oracle.MAX_ATTEMPTS; k++) oracle.redeemInvite(st, 'bad', 'ZZZZZZZZZZ'.replace(/Z/g, 'K'), NOW);
check('INV-08 بعد ' + oracle.MAX_ATTEMPTS + ' محاولات فاشلة يُحظر المستخدم حتى لو أدخل رمزاً صحيحاً (نفس الرسالة)', (function () { var x = oracle.redeemInvite(st, 'bad', 'ABCDEFGH23', NOW); return !x.ok && x.message === oracle.UNIFORM_FAIL && st.members.length === 0; })());
check('INV-09 محاولات مستخدم لا تحظر مستخدماً آخر', oracle.redeemInvite(st, 'other', 'ABCDEFGH23', NOW).ok);
check('INV-10 رمز studentCode الحالي (MR-XXXXXX) لا يُقبل كرمز دعوة', !oracle.redeemInvite(freshStore(), 'u9', 'MR-ABCDEF', NOW).ok);
check('INV-11 رمز بحروف تحكم/اتجاه مخفية يُنظَّف ثم يُحكم عليه (لا تجاوز)', (function () { var s = freshStore(); return oracle.redeemInvite(s, 'u8', '‏ABCDEFGH23‎', NOW).ok; })());
check('INV-12 لا يُحقن في الاستجابة أي من الدور المطلوب من العميل (الدور من سجل الرمز)', (function () { var s = freshStore(); var x = oracle.redeemInvite(s, 'u7', 'ABCDEFGH23', NOW, { role: 'developer' }); return x.ok && x.role === 'student'; })());

// ---- تدقيق الأحداث ----
function evt(o) { return Object.assign({ eventId: 'e1', eventType: 'invite.issued', occurredAt: '2026-11-01T10:00:00Z', actorUserId: 'u1', actorRole: 'rep', classId: 'c1', outcome: 'success', requestId: 'r1', targetType: 'invite_code', targetId: 'inv_1' }, o || {}); }
check('AUD-01 حدث سليم يُقبل', oracle.validateAuditEvent(evt(), spec).length === 0);
['name', 'studentName', 'studentCode', 'code', 'inviteCode', 'codeHash', 'amount', 'purpose', 'receiptNo', 'score', 'note', 'password', 'token', 'accessToken', 'jwt', 'apiKey', 'secret', 'email', 'phone', 'payload', 'records'].forEach(function (f) {
  var o = evt(); o[f] = 'x'; check('AUD-NEG ممنوع في السجل: ' + f, oracle.validateAuditEvent(o, spec).indexOf('forbidden:' + f) >= 0);
});
spec.requiredFields.forEach(function (f) { var o = evt(); delete o[f]; check('AUD-NEG حقل مطلوب ناقص: ' + f, oracle.validateAuditEvent(o, spec).indexOf('missing:' + f) >= 0); });
check('AUD-NEG نوع حدث مجهول مرفوض', oracle.validateAuditEvent(evt({ eventType: 'x.y' }), spec).indexOf('unknown-eventType') >= 0);
check('AUD-NEG طالب لا يُصدر invite.issued', oracle.validateAuditEvent(evt({ actorRole: 'student' }), spec).indexOf('actor-not-allowed') >= 0);
check('AUD-NEG حقل غير متوقع مرفوض (لا تسريب صامت)', oracle.validateAuditEvent(evt({ extraField: 1 }), spec).indexOf('unexpected:extraField') >= 0);
check('AUD-NEG وقت غير صالح مرفوض', oracle.validateAuditEvent(evt({ occurredAt: 'yesterday' }), spec).indexOf('bad-time') >= 0);
check('AUD-NEG نتيجة غير معرّفة مرفوضة', oracle.validateAuditEvent(evt({ outcome: 'maybe' }), spec).indexOf('bad-outcome') >= 0);
check('AUD-02 كل نوع حدث له فئة وجهات فاعلة ووصف «must»', Object.keys(spec.events).every(function (k) { var e = spec.events[k]; return e.category && e.actors.length && e.must; }));
check('AUD-03 الأحداث المطلوبة موجودة: إصدار/استرداد/فشل/إلغاء/تصدير/استعادة/رفض/حذف/أرشفة', ['invite.issued', 'invite.redeemed', 'invite.redeem_failed', 'invite.revoked', 'export.created', 'restore.executed', 'access.denied', 'record.deleted', 'record.corrected', 'student.archived', 'selfview.toggled'].every(function (k) { return !!spec.events[k]; }));
check('AUD-04 قائمة المحظور تضم الأسرار والبيانات الحساسة الخمسة (اسم/مبلغ/درجة/رمز/توكن)', ['name', 'amount', 'score', 'code', 'token'].every(function (f) { return spec.forbiddenFields.indexOf(f) >= 0; }));

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
