// 5.04 — يولّد (1) جدول المصفوفة داخل docs/stage5/5.04-PERMISSIONS.md و(2) docs/stage5/security/rls-contract-cases.json
// من docs/stage5/security/permissions-matrix.json. تشغيل: node tests/security/generate.js --write   (بدون --write يطبع فقط)
'use strict';
var fs = require('fs'), path = require('path'), oracle = require('./policy-oracle.js');
var ROOT = path.resolve(__dirname, '..', '..');
var MATRIX = path.join(ROOT, 'docs/stage5/security/permissions-matrix.json');
var CASES = path.join(ROOT, 'docs/stage5/security/rls-contract-cases.json');
var DOC = path.join(ROOT, 'docs/stage5/5.04-PERMISSIONS.md');
var BEGIN = '<!-- MATRIX:BEGIN (مولَّد من permissions-matrix.json — لا تعدّله يدوياً) -->', END = '<!-- MATRIX:END -->';
var ROLE_AR = { student: 'طالب', rep: 'ممثل الصف', developer: 'مطور', anonymous: 'مجهول بلا عضوية' };
var SCOPE_AR = { none: '', self: ' · سجله', selfIfConsented: ' · سجله إن فُعّل+موافقة', class: ' · صفّه', any: ' · أي صف' };

function load() { return JSON.parse(fs.readFileSync(MATRIX, 'utf8')); }

function matrixTable(m) {
  var head = '| المورد (الحساسية) | ' + m.roles.map(function (r) { return ROLE_AR[r]; }).join(' | ') + ' | ملاحظة |\n|---|' + m.roles.map(function () { return '---'; }).join('|') + '|---|\n';
  var rows = Object.keys(m.resources).map(function (id) {
    var r = m.resources[id];
    var cells = m.roles.map(function (role) {
      var p = r.perms[role];
      return p.actions ? '`' + p.actions + '`' + SCOPE_AR[p.scope] : '✗';
    });
    return '| `' + id + '` — ' + r.label + ' (' + r.sensitivity + ') | ' + cells.join(' | ') + ' | ' + (r.note || '').replace(/\|/g, '/') + ' |';
  });
  return head + rows.join('\n') + '\n';
}

var CTX = { 'own-self': { classId: 'c1', studentId: 's1' }, 'own-peer': { classId: 'c1', studentId: 's2' }, 'other-class': { classId: 'c2', studentId: 's1' }, 'no-student': { classId: 'c1', studentId: undefined } };
var POL = {
  'off': { attendance: { enabled: false, consentRef: null }, grades: { enabled: false, consentRef: null }, payments: { enabled: false, consentRef: null } },
  'on+consent': { attendance: { enabled: true, consentRef: 'doc-1' }, grades: { enabled: true, consentRef: 'doc-1' }, payments: { enabled: true, consentRef: 'doc-1' } },
  'on-noconsent': { attendance: { enabled: true, consentRef: null }, grades: { enabled: true, consentRef: '' }, payments: { enabled: true, consentRef: ' ' } }
};
function actorFor(role, status) { var a = { role: role, status: status }; if (role !== 'developer') { a.classId = 'c1'; if (role === 'student') a.studentId = 's1'; } return a; }

function buildCases(m) {
  var out = [], n = 0, sens = ['attendance', 'grades', 'payments'];
  m.roles.forEach(function (role) {
    Object.keys(m.resources).forEach(function (type) {
      oracle.ACTIONS.forEach(function (action) {
        Object.keys(CTX).forEach(function (cx) {
          var pols = sens.indexOf(type) >= 0 ? Object.keys(POL) : ['off'];
          pols.forEach(function (pk) {
            [['active', true], ['suspended', cx === 'own-self']].forEach(function (st) {
              if (!st[1]) return;
              var actor = actorFor(role, st[0]), res = { type: type, classId: CTX[cx].classId, studentId: CTX[cx].studentId };
              var d = oracle.can(actor, action, res, m, POL[pk]);
              n++;
              out.push([n, role, st[0], cx, type, action, pk, d.allow ? 1 : 0, d.reason]);
            });
          });
        });
      });
    });
  });
  return out;
}
function casesJson(m) {
  var c = buildCases(m);
  return '{\n"schemaVersion": 1,\n"note": "عقد حالات قابل لإعادة التشغيل على RLS الحقيقية لاحقاً. الأعمدة: [رقم, الدور, حالة الحساب, السياق(own-self/own-peer/other-class/no-student), المورد, الإجراء, سياسة selfView(off/on+consent/on-noconsent), متوقع(1 سماح/0 رفض), سبب]. actor: classId=c1، studentId=s1 للطالب؛ السياق يحدد classId/studentId للمورد (c1/s1، c1/s2، c2/s1، c1/بلا). مولَّد من permissions-matrix.json بـ tests/security/generate.js.",\n"count": ' + c.length + ',\n"cases": [\n' + c.map(function (x) { return JSON.stringify(x); }).join(',\n') + '\n]\n}\n';
}
function injectDoc(text, table) {
  var i = text.indexOf(BEGIN), j = text.indexOf(END);
  if (i < 0 || j < 0 || j < i) return null;
  return text.slice(0, i) + BEGIN + '\n' + table + END + text.slice(j + END.length);
}
module.exports = { load: load, matrixTable: matrixTable, buildCases: buildCases, casesJson: casesJson, injectDoc: injectDoc, paths: { MATRIX: MATRIX, CASES: CASES, DOC: DOC }, BEGIN: BEGIN, END: END, POL: POL, CTX: CTX, actorFor: actorFor };

if (require.main === module) {
  var m = load(), table = matrixTable(m), cj = casesJson(m);
  if (process.argv.indexOf('--write') >= 0) {
    fs.writeFileSync(CASES, cj);
    if (fs.existsSync(DOC)) { var t = injectDoc(fs.readFileSync(DOC, 'utf8'), table); if (t === null) { console.error('markers missing in doc'); process.exit(1); } fs.writeFileSync(DOC, t); }
    console.log('written: cases=' + buildCases(m).length);
  } else { process.stdout.write(table); }
}
