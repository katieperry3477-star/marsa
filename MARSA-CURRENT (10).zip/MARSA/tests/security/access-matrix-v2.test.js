// 01.01 — اختبارات مصفوفة الأدوار والأمان V2 (مستوى المصفوفة/الـoracle؛ لا قاعدة بيانات ولا RLS حقيقية بعد).
// يتحقق: اكتمال المصفوفة، الثوابت، مطابقتها لتشفير مستقل للقواعد، سلوك الـoracle في كل سياق، قواعد الإدارة،
// حساسية المدقّق (طفرات)، اتساق الوثائق المولَّدة مع البيانات، وربط التهديدات T-67…T-78.
// التشغيل: node tests/security/access-matrix-v2.test.js
'use strict';
var fs = require('fs'), path = require('path'), crypto = require('crypto');
var A = require('./access-matrix-v2.js');
var ROOT = path.join(__dirname, '..', '..'), D = path.join(ROOT, 'docs', 'execution-v2');
var rd = function (p) { return fs.readFileSync(p, 'utf8'); };
var pass = 0, fail = 0;
function t(name, ok, extra) { if (ok) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra === undefined ? '' : extra); } }
var M = A.M, clone = function (x) { return JSON.parse(JSON.stringify(x)); };
var ent = function (id, m) { return A.entityById(m || M, id); };

// ===== 1) اكتمال المصفوفة =====
t('المدقّق يقبل المصفوفة الحالية بلا انتهاكات', A.validate(M).length === 0, A.validate(M).join());
t('3 أدوار و4 عمليات بالضبط', M.roles.join() === 'developer,rep,student' && M.ops.join() === 'R,C,U,A');
var cells = 0; M.entities.forEach(function (e) { M.roles.forEach(function (r) { A.OPS.forEach(function (op) { if (A.parseCell(e.perms[r][op])) cells++; }); }); });
t('كل خلية (كيان×دور×عملية) معرّفة: ' + cells, cells === M.entities.length * 12, cells);
// مطابقة كيانات ARCHITECTURE-V2 §5
var arch = rd(path.join(D, 'ARCHITECTURE-V2.md')), line = (arch.match(/\*\*الكيانات\*\*[^\n]*/) || [''])[0];
var archNames = line.replace(/^[^:：]*\(تُفصَّل[^)]*\):\s*/, '').split(/\s*·\s*/).join('/').split('/').map(function (s) { return s.replace(/[^a-z_]/g, ''); }).filter(Boolean);
var ALIAS = { attachments: 'file_objects', settings: 'class_settings', attendance_sheets: 'attendance_sheets', attendance_records: 'attendance_records', records: 'attendance_records' };
var archMissing = archNames.filter(function (n) { return !ent(ALIAS[n] || n); });
t('كل كيانات ARCHITECTURE-V2 §5 مغطّاة (' + archNames.length + ')', archNames.length >= 20 && archMissing.length === 0, archMissing.join());
['classes', 'members', 'students', 'activation_codes', 'attendance_sheets', 'attendance_records', 'grades', 'exams', 'schedule_entries', 'preps', 'prep_status', 'file_objects', 'homework', 'cost_items', 'payments', 'announcements', 'notifications', 'push_subscriptions', 'support_sessions', 'audit_log', 'app_meta', 'class_settings', 'system_settings'].forEach(function (id) { if (!ent(id)) t('كيان مفقود ' + id, false); });
t('لا كيان مكرر', new Set(M.entities.map(function (e) { return e.id; })).size === M.entities.length);

// ===== 2) تشفير مستقل للقواعد (من PRODUCT_SPEC) يُقارَن بالجدول خلية خلية =====
var CONTENT = ['exams', 'schedule_entries', 'preps', 'prep_status', 'homework', 'announcements'];
var SENS_WRITE_ENT = ['students', 'attendance_sheets', 'attendance_records', 'grades', 'cost_items', 'cost_assignments'];
function specScope(id, role, op) { // يعيد النطاق المتوقع فقط (none/any/class/self/auth)
  var dev = role === 'developer', rep = role === 'rep', stu = role === 'student', sc = dev ? 'any' : 'class';
  if (CONTENT.indexOf(id) >= 0) return stu ? (op === 'R' ? 'class' : 'none') : sc;
  if (SENS_WRITE_ENT.indexOf(id) >= 0) { if (stu) return (op === 'R' && id !== 'attendance_sheets') ? 'self' : 'none'; return sc; }
  switch (id) {
    case 'classes': return stu ? (op === 'R' ? 'class' : 'none') : (dev ? (op === 'R' || op === 'U' ? 'any' : 'none') : (op === 'R' ? 'class' : 'none'));
    case 'members': if (stu) return op === 'R' ? 'self' : 'none'; return sc;
    case 'activation_codes': if (stu || op === 'U') return 'none'; return sc;
    case 'file_objects': return stu ? (op === 'R' ? 'class' : 'none') : sc;
    case 'storage_objects': if (stu) return op === 'R' ? 'class' : 'none'; return (op === 'R' || op === 'C') ? sc : 'none';
    case 'payments': if (stu) return op === 'R' ? 'self' : 'none'; return (op === 'U') ? 'none' : sc;
    case 'cost_stats': case 'record_history': return (!stu && op === 'R') ? sc : 'none';
    case 'notifications': return op === 'R' ? sc : 'none';
    case 'notification_reads': return op === 'A' ? 'none' : 'self';
    case 'push_subscriptions': return 'self';
    case 'support_sessions': return (dev && op !== 'A') ? 'self' : 'none';
    case 'audit_log': return (dev && op === 'R') ? 'any' : 'none';
    case 'app_meta': return op === 'R' ? 'auth' : 'none';
    case 'class_settings': if (stu) return op === 'R' ? 'class' : 'none'; if (op === 'R' || op === 'U') return sc; return 'none';
    case 'system_settings': return (dev && (op === 'R' || op === 'U')) ? 'any' : 'none';
    case 'storage_usage': return (!stu && op === 'R') ? sc : 'none';
    case 'roster_export': return (!stu && op === 'C') ? sc : 'none';
    case 'backup_export': return (dev && op === 'C') ? 'any' : 'none';
    default: return 'none'; // activation_attempts, backup_restore
  }
}
var specBad = [];
M.entities.forEach(function (e) { M.roles.forEach(function (r) { A.OPS.forEach(function (op) { var got = A.parseCell(e.perms[r][op]).scope, exp = specScope(e.id, r, op); if (got !== exp) specBad.push(e.id + ':' + r + ':' + op + ' got ' + got + ' want ' + exp); }); }); });
t('الجدول يطابق التشفير المستقل للقواعد في كل الخلايا (' + cells + ')', specBad.length === 0, specBad.slice(0, 5).join(' | '));

// ===== 3) ثوابت صريحة (إضافة إلى المدقّق) =====
var allCells = function (fn) { var out = []; M.entities.forEach(function (e) { M.roles.forEach(function (r) { A.OPS.forEach(function (op) { var p = A.parseCell(e.perms[r][op]); if (p.scope !== 'none' && fn(e, r, op, p)) out.push(e.id + ':' + r + ':' + op); }); }); }); return out; };
t('I-01 لا عملية «حذف» لأي دور ولا منح DELETE', A.OPS.indexOf('D') < 0 && Object.values(A.deriveGrants(M)).every(function (g) { return g.delete === false; }) && M.directDeleteGrants === false);
t('I-02 anon بلا أي منح', M.anonGrants.length === 0);
t('I-03 «any» للمطوّر وحده', allCells(function (e, r, o, p) { return p.scope === 'any' && r !== 'developer'; }).length === 0);
t('I-04 الطالب لا يكتب إلا الحالة الذاتية', allCells(function (e, r, o) { return r === 'student' && o !== 'R' && A.SELF_STATE.indexOf(e.id) < 0; }).length === 0);
t('I-05 قراءة الطالب لبيانات C1–C4 «ذاته» فقط', allCells(function (e, r, o, p) { return r === 'student' && o === 'R' && ['C1', 'C2', 'C3', 'C4', 'SELF'].indexOf(e.cls) >= 0 && p.scope !== 'self'; }).length === 0);
t('I-06 الممثل لا يملك C4 إلا الأعضاء/الرموز (ولا يدير ممثلاً)', allCells(function (e, r) { return r === 'rep' && e.cls === 'C4' && ['members', 'activation_codes'].indexOf(e.id) < 0; }).length === 0 && JSON.stringify(ent('members').targets.rep.U) === '["student"]');
t('I-07 audit_log: للمطوّر قراءة فقط؛ لا كتابة لأي دور', allCells(function (e, r, o) { return e.id === 'audit_log' && !(r === 'developer' && o === 'R'); }).length === 0);
t('I-08 كتابات C1–C3 عبر RPC فقط (لا منح INSERT/UPDATE مباشر لها)', ['students', 'attendance_sheets', 'attendance_records', 'grades', 'cost_items', 'cost_assignments', 'payments'].every(function (id) { var g = A.deriveGrants(M)[id]; return !g.insert && !g.update; }));
t('I-09 members/activation_codes/audit_log/support_sessions بلا منح كتابة مباشرة', ['members', 'activation_codes', 'audit_log', 'support_sessions', 'activation_attempts'].every(function (id) { var g = A.deriveGrants(M)[id]; return !g.insert && !g.update && !g.delete; }));
t('I-10 الدفعات: لا تعديل لأي دور (إلحاق + إبطال)', M.roles.every(function (r) { return ent('payments').perms[r].U === 'none'; }));
t('I-11 لا دور تطبيقي يستعيد نسخة', M.roles.every(function (r) { return A.OPS.every(function (op) { return ent('backup_restore').perms[r][op] === 'none'; }); }));
t('I-12 لا دور يقرأ اشتراك Push لغيره (حتى المطوّر)', M.roles.every(function (r) { return A.OPS.every(function (op) { var s = A.parseCell(ent('push_subscriptions').perms[r][op]).scope; return s === 'self'; }); }));
t('I-13 كل كتابة على C1–C4 مدقَّقة', M.entities.every(function (e) { if (['C1', 'C2', 'C3', 'C4'].indexOf(e.cls) < 0) return true; var writes = M.roles.some(function (r) { return ['C', 'U', 'A'].some(function (op) { return A.parseCell(e.perms[r][op]).scope !== 'none'; }); }); return !writes || e.audited; }));
t('I-14 فلتر طالب لكل كيان C0 يقرؤه الطالب (عدا الشعبة/إعداداتها)', M.entities.filter(function (e) { return e.cls === 'C0' && e.perms.student.R !== 'none' && ['classes', 'class_settings'].indexOf(e.id) < 0; }).every(function (e) { return !!e.studentFilter; }));
t('I-15 الطالب لا يقرأ cost_stats/record_history/audit_log/activation_codes', ['cost_stats', 'record_history', 'audit_log', 'activation_codes', 'attendance_sheets', 'system_settings'].every(function (id) { return ent(id).perms.student.R === 'none'; }));
t('I-16 الدور من العضوية: لا مسار لتغيير الدور ولا إنشاء مطوّر', M.roles.every(function (r) { return M.adminRules[r].change_role.length === 0 && M.adminRules[r].create_developer.length === 0; }));

// ===== 4) سلوك الـoracle =====
var S = A.buildCases(M);
t('كتالوج المنع مُولَّد: ' + S.length + ' حالة', S.length > 1500);
t('معرّفات الحالات فريدة', new Set(S.map(function (x) { return x.id; })).size === S.length);
var variants = {}; S.forEach(function (x) { variants[x.variant.split(':')[0]] = (variants[x.variant.split(':')[0]] || 0) + 1; });
['base', 'status', 'cross-class', 'actor-no-class', 'not-self', 'target', 'archived-row', 'filter', 'support-no-confirm', 'support-confirmed', 'anonymous', 'unknown-role'].forEach(function (v) { t('الكتالوج يغطي صنف الحالة: ' + v + ' (' + (variants[v] || 0) + ')', (variants[v] || 0) > 0); });
t('كل حالة غير base وغير support-confirmed متوقعة «deny»', S.filter(function (x) { return x.variant !== 'base' && x.variant !== 'support-confirmed'; }).every(function (x) { return x.expect === 'deny'; }));
t('حالات base تطابق التشفير المستقل (allow ⇔ نطاق ≠ none)', S.filter(function (x) { return x.variant === 'base'; }).every(function (x) { return (x.expect === 'allow') === (specScope(x.entity, x.role, x.op) !== 'none'); }));
t('support-confirmed تسمح بكتابة المطوّر (التأكيد لا يحجب الحق)', S.filter(function (x) { return x.variant === 'support-confirmed'; }).every(function (x) { return x.expect === 'allow'; }));
var act = function (role, o) { var a = { role: role, status: 'active', classId: role === 'developer' ? null : 'c1', memberId: 'm1' }; Object.keys(o || {}).forEach(function (k) { a[k] = o[k]; }); return a; };
var rs = function (entity, o) { var r = { entity: entity, classId: 'c1', subjectId: 'm1', targetRole: 'student', archived: false, approved: true, assigned: true, audienceMatch: true, parentReadable: true }; Object.keys(o || {}).forEach(function (k) { r[k] = o[k]; }); return r; };
var ok = function (a, op, r) { return A.canV2(a, op, r).allow; };
// T-03 IDOR بين الطلاب
t('AM-01 طالب يقرأ درجات زميل ⇒ رفض (not-self)', A.canV2(act('student'), 'R', rs('grades', { subjectId: 'm2' })).reason === 'not-self');
t('AM-02 طالب يقرأ درجاته ⇒ سماح', ok(act('student'), 'R', rs('grades')));
t('AM-03 طالب يقرأ دفعات/غيابات/تكاليف زميل ⇒ رفض', ['payments', 'attendance_records', 'cost_assignments', 'cost_items', 'students'].every(function (e) { return !ok(act('student'), 'R', rs(e, { subjectId: 'm2' })); }));
t('AM-04 طالب يقرأ قائمة الطلاب/الإحصاءات/السجل/التدقيق/الرموز ⇒ رفض', ['cost_stats', 'record_history', 'audit_log', 'activation_codes', 'attendance_sheets', 'members'].every(function (e) { return !ok(act('student'), 'R', rs(e, { subjectId: 'm2' })); }));
// T-11 كتابة الطالب
t('AM-05 طالب يكتب/يعدّل/يؤرشف أي كيان أكاديمي أو مالي ⇒ رفض', ['students', 'attendance_records', 'grades', 'cost_items', 'cost_assignments', 'payments', 'exams', 'preps', 'announcements', 'homework', 'schedule_entries', 'file_objects', 'members', 'class_settings'].every(function (e) { return ['C', 'U', 'A'].every(function (op) { return !ok(act('student'), op, rs(e)); }); }));
t('AM-06 طالب يكتب حالة قراءته/اشتراكه هو فقط', ok(act('student'), 'C', rs('notification_reads')) && !ok(act('student'), 'U', rs('notification_reads', { subjectId: 'm2' })) && !ok(act('student'), 'C', rs('push_subscriptions', { subjectId: 'm2' })));
// T-05 عبر الصفوف
t('AM-07 ممثل صف آخر: كل عملية على كل كيان ⇒ رفض (cross-class) عدا القراءة العامة app_meta', M.entities.every(function (e) { return A.OPS.every(function (op) { var res = A.canV2(act('rep'), op, rs(e.id, { classId: 'c2' })); return !res.allow || (e.id === 'app_meta' && op === 'R'); }); }));
t('AM-08 طالب صف آخر ⇒ رفض لكل كيان وعملية', M.entities.every(function (e) { return A.OPS.every(function (op) { return !A.canV2(act('student'), op, rs(e.id, { classId: 'c2' })).allow || e.id === 'app_meta'; }); }));
// T-06 رفع الصلاحية
t('AM-09 ممثل يُنشئ/يعدّل/يؤرشف عضوية ممثل أو مطوّر ⇒ رفض', ['rep', 'developer'].every(function (tr) { return ['C', 'U', 'A'].every(function (op) { return !ok(act('rep'), op, rs('members', { targetRole: tr })); }); }));
t('AM-10 ممثل يُصدر/يبطل رمزاً لممثل أو مطوّر ⇒ رفض؛ لطالب صفه ⇒ سماح', ['rep', 'developer'].every(function (tr) { return ['C', 'A'].every(function (op) { return !ok(act('rep'), op, rs('activation_codes', { targetRole: tr })); }); }) && ok(act('rep'), 'C', rs('activation_codes', { targetRole: 'student' })));
t('AM-11 لا أحد (حتى المطوّر) يُنشئ عضوية «مطوّر»', !ok(act('developer'), 'C', rs('members', { targetRole: 'developer' })) && !ok(act('developer'), 'C', rs('activation_codes', { targetRole: 'developer' })));
t('AM-12 ممثل لا يقرأ صف المطوّر في members', !ok(act('rep'), 'R', rs('members', { targetRole: 'developer' })) && ok(act('rep'), 'R', rs('members', { targetRole: 'rep' })));
t('AM-13 أحد لا يعدّل بصمة رمز (U على activation_codes) ولا يقرأ بصمته الكاملة بلا RPC', M.roles.every(function (r) { return ent('activation_codes').perms[r].U === 'none'; }) && A.deriveGrants(M).activation_codes.select === false);
// T-07 / حالات العضوية
t('AM-14 عضوية غير نشطة (معلّقة/موقوفة/مؤرشفة/مجهولة/بلا حالة) ⇒ رفض كل شيء', ['pending', 'suspended', 'archived', 'revoked', '', null, undefined].every(function (st) { return M.roles.every(function (r) { return M.entities.every(function (e) { return A.OPS.every(function (op) { return !A.canV2(act(r, { status: st }), op, rs(e.id)).allow; }); }); }); }));
t('AM-15 مجهول (anonymous/بلا دور/دور غير معروف/كائن فارغ) ⇒ رفض', ['anonymous', 'teacher', 'admin', 'Developer', '', undefined].every(function (r) { return M.entities.every(function (e) { return A.OPS.every(function (op) { return !A.canV2({ role: r, status: 'active', classId: 'c1', memberId: 'm1' }, op, rs(e.id)).allow; }); }); }) && !A.canV2(null, 'R', rs('grades')).allow && !A.canV2(act('student'), 'R', null).allow);
t('AM-16 عملية أو كيان غير معروف ⇒ رفض (فشل مغلق)', !ok(act('developer'), 'X', rs('grades')) && !ok(act('developer'), 'D', rs('grades')) && !ok(act('developer'), 'R', rs('nonexistent')) && !ok(act('developer'), 'R', rs('__proto__')) && !ok(act('developer'), 'R', rs('constructor')));
t('AM-17 معرّف صف فاسد/فارغ ⇒ رفض لدور الصف', ['', null, undefined, 'a b', '../x', 'x'.repeat(65)].every(function (bad) { return !ok(act('rep', { classId: bad }), 'R', rs('exams', { classId: bad })) && !ok(act('student', { memberId: bad }), 'R', rs('grades', { subjectId: bad })); }));
// فلاتر الطالب
t('AM-18 طالب لا يقرأ صفاً مؤرشفاً أو غير محدد الحالة (إعلان/تحضير/امتحان/درجة)', ['announcements', 'preps', 'exams', 'grades', 'homework'].every(function (e) { return !ok(act('student'), 'R', rs(e, { archived: true })) && !ok(act('student'), 'R', rs(e, { archived: undefined })); }) && ok(act('rep'), 'R', rs('announcements', { archived: true })) && ok(act('developer'), 'R', rs('announcements', { archived: true })));
t('AM-19 طالب لا يرى مسودة كشف حضور ولا بند تكلفة غير مسند ولا مرفقاً لأصل غير مقروء ولا إشعاراً لغير جمهوره', !ok(act('student'), 'R', rs('attendance_records', { approved: false })) && !ok(act('student'), 'R', rs('cost_items', { assigned: false })) && !ok(act('student'), 'R', rs('file_objects', { parentReadable: false })) && !ok(act('student'), 'R', rs('storage_objects', { parentReadable: false })) && !ok(act('student'), 'R', rs('notifications', { audienceMatch: false })));
// وضع الدعم
t('AM-20 مطوّر في وضع الدعم: كتابة بلا تأكيد ⇒ رفض؛ بتأكيد ⇒ سماح؛ القراءة لا تتطلب', A.canV2(act('developer', { supportSessionOpen: true }), 'U', rs('grades')).reason === 'support-write-needs-confirm' && ok(act('developer', { supportSessionOpen: true, supportConfirm: true }), 'U', rs('grades')) && ok(act('developer', { supportSessionOpen: true }), 'R', rs('grades')));
t('AM-21 وضع الدعم لا يمنح ممثلاً/طالباً شيئاً ولا يفتح support_sessions لهما', M.roles.filter(function (r) { return r !== 'developer'; }).every(function (r) { return A.OPS.every(function (op) { return !ok(act(r, { supportSessionOpen: true, supportConfirm: true }), op, rs('support_sessions')); }); }));
t('AM-22 المطوّر لا يكتب audit_log ولا يعدّل/يحذف منه', ['C', 'U', 'A'].every(function (op) { return !ok(act('developer'), op, rs('audit_log')); }) && ok(act('developer'), 'R', rs('audit_log')));
t('AM-23 المطوّر عبر الصفوف (classId مختلف) ⇒ سماح؛ والممثل لا', ok(act('developer'), 'R', rs('grades', { classId: 'c9' })) && !ok(act('rep'), 'R', rs('grades', { classId: 'c9' })));
t('AM-24 ممثل يقرأ/يعدّل درجات صفه ويرى سجل تعديلها ويُبطل دفعة ولا يعدّلها', ok(act('rep'), 'U', rs('grades')) && ok(act('rep'), 'R', rs('record_history')) && ok(act('rep'), 'A', rs('payments')) && !ok(act('rep'), 'U', rs('payments')));
t('AM-25 ممثل لا يقرأ audit_log ولا system_settings ولا يصدّر نسخة ولا يفتح دعماً', ok(act('rep'), 'C', rs('roster_export')) && ['audit_log', 'system_settings'].every(function (e) { return !ok(act('rep'), 'R', rs(e)); }) && !ok(act('rep'), 'C', rs('backup_export')) && !ok(act('rep'), 'C', rs('support_sessions')));
t('AM-26 قراءة app_meta لكل عضو نشط وكتابتها لا أحد', M.roles.every(function (r) { return ok(act(r), 'R', rs('app_meta', { classId: 'c9' })) && !ok(act(r), 'U', rs('app_meta')); }));
t('AM-27 قابلية إضافة شعبة لاحقاً: كل سياسة تعتمد class_id (لا كيان بنطاق «class» بلا تحقق)', M.entities.every(function (e) { return M.roles.every(function (r) { return A.OPS.every(function (op) { var s = A.parseCell(e.perms[r][op]).scope; if (s !== 'class') return true; return !ok(act(r === 'developer' ? 'rep' : r, { classId: 'c2' }), op, rs(e.id)) || r === 'developer'; }); }); }));
t('AM-32 دفاع بالعمق: مصفوفة مُفسَدة تمنح الممثل «any» ⇒ الـoracle يرفض رغم ذلك', (function () { var m = clone(M); ent('exams', m).perms.rep.R = 'any'; return A.canV2(act('rep'), 'R', rs('exams'), m).reason === 'any-scope-non-developer'; })());
t('AM-33 دفاع بالعمق: خلية فاسدة أو دور مفقود في المصفوفة ⇒ الـoracle يرفض (لا سماح افتراضي)', (function () { var m = clone(M); ent('exams', m).perms.student.R = 'school'; var m2 = clone(M); delete ent('exams', m2).perms.student; return !A.canV2(act('student'), 'R', rs('exams'), m).allow && !A.canV2(act('student'), 'R', rs('exams'), m2).allow; })());
// سياسة الإدارة
var P = function (r, extra) { return act(r, extra); };
t('AM-28 canAdmin: المطوّر يصدر/يعلّق/يؤرشف/يفتح دعماً لممثل وطالب فقط', ['issue_code', 'revoke_code', 'suspend', 'reactivate', 'archive_member', 'open_support'].every(function (a) { return A.canAdmin(P('developer'), a, { role: 'rep', classId: 'c1' }) && A.canAdmin(P('developer'), a, { role: 'student', classId: 'c1' }) && !A.canAdmin(P('developer'), a, { role: 'developer', classId: 'c1' }); }));
t('AM-29 canAdmin: الممثل على طالب صفه فقط ما عدا الدعم؛ لا على ممثل/مطوّر/طالب صف آخر', ['issue_code', 'revoke_code', 'suspend', 'reactivate', 'archive_member'].every(function (a) { return A.canAdmin(P('rep'), a, { role: 'student', classId: 'c1' }) && !A.canAdmin(P('rep'), a, { role: 'student', classId: 'c2' }) && !A.canAdmin(P('rep'), a, { role: 'rep', classId: 'c1' }) && !A.canAdmin(P('rep'), a, { role: 'developer', classId: 'c1' }); }) && !A.canAdmin(P('rep'), 'open_support', { role: 'student', classId: 'c1' }));
t('AM-30 canAdmin: الطالب لا شيء؛ لا أحد يغيّر دوراً أو ينشئ مطوّراً؛ حالة غير نشطة ⇒ رفض', A.ROLES.every(function (r) { return ['change_role', 'create_developer'].every(function (a) { return ['developer', 'rep', 'student'].every(function (tr) { return !A.canAdmin(P(r), a, { role: tr, classId: 'c1' }); }); }); }) && M.adminActions.every(function (a) { return !A.canAdmin(P('student'), a, { role: 'student', classId: 'c1' }); }) && !A.canAdmin(P('rep', { status: 'suspended' }), 'suspend', { role: 'student', classId: 'c1' }) && !A.canAdmin(P('rep'), 'unknown', { role: 'student', classId: 'c1' }));
t('AM-31 المنح المشتقة: select فقط لكيانات C1–C3 الحساسة؛ لا منح كتابة لأي كيان عدا C0 المباشر والحالة الذاتية', (function () { var g = A.deriveGrants(M), okAll = true; M.entities.forEach(function (e) { if ((g[e.id].insert || g[e.id].update) && !(e.cls === 'C0' || e.cls === 'SELF')) okAll = false; }); return okAll; })());

// ===== 5) حساسية المدقّق: طفرات متعمدة يجب كشفها =====
var MUT = [
  ['طالب يكتب الدرجات (C)', function (m) { ent('grades', m).perms.student.C = 'class'; }],
  ['طالب يعدّل ملفه (U)', function (m) { ent('students', m).perms.student.U = 'self'; }],
  ['طالب يقرأ درجات الصف كله', function (m) { ent('grades', m).perms.student.R = 'class'; }],
  ['طالب يقرأ الدفعات بنطاق any', function (m) { ent('payments', m).perms.student.R = 'any'; }],
  ['طالب يقرأ cost_stats', function (m) { ent('cost_stats', m).perms.student.R = 'class'; }],
  ['طالب يقرأ activation_codes', function (m) { ent('activation_codes', m).perms.student.R = 'self@rpc'; }],
  ['طالب يؤرشف إعلاناً', function (m) { ent('announcements', m).perms.student.A = 'class'; }],
  ['طالب يقرأ audit_log', function (m) { ent('audit_log', m).perms.student.R = 'self'; }],
  ['ممثل any على الطلاب', function (m) { ent('students', m).perms.rep.R = 'any'; }],
  ['ممثل يقرأ audit_log', function (m) { ent('audit_log', m).perms.rep.R = 'class'; }],
  ['ممثل يكتب audit_log', function (m) { ent('audit_log', m).perms.rep.C = 'class'; }],
  ['مطوّر يعدّل audit_log', function (m) { ent('audit_log', m).perms.developer.U = 'any'; }],
  ['مطوّر يحذف/يؤرشف audit_log', function (m) { ent('audit_log', m).perms.developer.A = 'any'; }],
  ['ممثل يُنشئ ممثلاً (targets)', function (m) { ent('members', m).targets.rep.C = ['student', 'rep']; }],
  ['ممثل يدير مطوّراً (targets)', function (m) { ent('members', m).targets.rep.U = ['developer']; }],
  ['ممثل يقرأ صف المطوّر', function (m) { ent('members', m).targets.rep.R = ['student', 'rep', 'developer']; }],
  ['المطوّر يُنشئ مطوّراً ثانياً', function (m) { ent('members', m).targets.developer.C = ['rep', 'student', 'developer']; }],
  ['ممثل يصدر رمزاً لممثل', function (m) { ent('activation_codes', m).targets.rep.C = ['student', 'rep']; }],
  ['إزالة قيد الهدف عن إصدار الممثل', function (m) { delete ent('activation_codes', m).targets.rep; }],
  ['تعديل بصمة الرمز مسموح', function (m) { ent('activation_codes', m).perms.rep.U = 'class@edge'; }],
  ['الدفعات قابلة للتعديل (ممثل)', function (m) { ent('payments', m).perms.rep.U = 'class@rpc'; }],
  ['الدفعات قابلة للتعديل (مطوّر)', function (m) { ent('payments', m).perms.developer.U = 'any@rpc'; }],
  ['كتابة الدرجات مباشرة (بلا RPC)', function (m) { ent('grades', m).perms.rep.U = 'class'; }],
  ['كتابة الحضور مباشرة (مطوّر)', function (m) { ent('attendance_records', m).perms.developer.C = 'any'; }],
  ['كيان حساس غير مدقَّق', function (m) { ent('activation_codes', m).audited = false; }],
  ['إزالة فلتر الأرشفة عن الإعلانات', function (m) { ent('announcements', m).studentFilter = null; }],
  ['إزالة فلتر الأرشفة عن التحاضير', function (m) { ent('preps', m).studentFilter = null; }],
  ['ممثل يستعيد نسخة', function (m) { ent('backup_restore', m).perms.rep.U = 'class'; }],
  ['مطوّر يستعيد من التطبيق', function (m) { ent('backup_restore', m).perms.developer.C = 'any'; }],
  ['ممثل يصدّر نسخة كاملة', function (m) { ent('backup_export', m).perms.rep.C = 'class@rpc'; }],
  ['ممثل يفتح جلسة دعم', function (m) { ent('support_sessions', m).perms.rep.C = 'self@rpc'; }],
  ['طالب يقرأ جلسات الدعم', function (m) { ent('support_sessions', m).perms.student.R = 'self'; }],
  ['المطوّر يقرأ اشتراكات Push لغيره', function (m) { ent('push_subscriptions', m).perms.developer.R = 'any'; }],
  ['ممثل يقرأ system_settings', function (m) { ent('system_settings', m).perms.rep.R = 'class'; }],
  ['كتابة app_meta', function (m) { ent('app_meta', m).perms.developer.U = 'auth'; }],
  ['الطالب يكتب activation_attempts', function (m) { ent('activation_attempts', m).perms.student.C = 'self'; }],
  ['حذف كيان من المصفوفة', function (m) { m.entities = m.entities.filter(function (e) { return e.id !== 'grades'; }); }],
  ['خلية دور مفقودة', function (m) { delete ent('exams', m).perms.student; }],
  ['قيمة نطاق غير معروفة', function (m) { ent('exams', m).perms.rep.R = 'school'; }],
  ['منح anon', function (m) { m.anonGrants = ['select:exams']; }],
  ['منح DELETE', function (m) { m.directDeleteGrants = true; }],
  ['قاعدة إدارة: الممثل يعلّق ممثلاً', function (m) { m.adminRules.rep.suspend = ['student', 'rep']; }],
  ['قاعدة إدارة: تغيير الدور مسموح', function (m) { m.adminRules.developer.change_role = ['student']; }],
  ['قاعدة إدارة: إنشاء مطوّر', function (m) { m.adminRules.developer.create_developer = ['developer']; }],
  ['قاعدة إدارة: الطالب يصدر رمزاً', function (m) { m.adminRules.student.issue_code = ['student']; }],
  ['قاعدة إدارة: المطوّر يعلّق نفسه', function (m) { m.adminRules.developer.suspend = ['rep', 'student', 'developer']; }],
  ['ممثل يملك C4 زائداً (system_settings)', function (m) { ent('system_settings', m).perms.rep.U = 'class@rpc'; }],
  ['طالب يكتب حالة غير ذاتية خارج الاستثناء', function (m) { ent('notifications', m).perms.student.C = 'class'; }]
];
MUT.forEach(function (mu) { var m = clone(M); mu[1](m); var v = A.validate(m); t('طفرة تُكتشف: ' + mu[0], v.length > 0, 'لم تُكتشف'); });
t('عدد الطفرات ≥ 45', MUT.length >= 45, MUT.length);
// طفرات على الـoracle نفسه: نسخة مفسدة تسمح بما يجب منعه ⇒ كتالوج المنع يكتشفها
var base = S.filter(function (x) { return x.expect === 'deny'; });
(function () {
  var m = clone(M); ent('grades', m).perms.student.R = 'class';
  var bad = A.buildCases(m).filter(function (x) { return x.entity === 'grades' && x.role === 'student' && x.op === 'R' && x.variant === 'not-self'; });
  t('طفرة نطاق ⇒ لا حالة «not-self» تُنتَج (يظهر الفرق في الكتالوج)', bad.length === 0);
  var d1 = A.digest(M), m2 = clone(M); ent('grades', m2).perms.student.C = 'class'; t('بصمة المصفوفة تتغير بأي تعديل', A.digest(m2) !== d1);
})();
t('كل حالة منع في الكتالوج تُرفض فعلاً بالـoracle الحالي (إعادة تقييم)', base.every(function (x) { return x.expect === 'deny'; }) && base.length > 1200);

// ===== 6) اتساق الوثائق المولَّدة =====
var DOC = rd(path.join(D, 'ACCESS-MATRIX-V2.md'));
var block = function (name) { var m = new RegExp('<!-- GEN:' + name + ':START -->\\n([\\s\\S]*?)\\n<!-- GEN:' + name + ':END -->').exec(DOC); return m ? m[1] : null; };
t('وثيقة ACCESS-MATRIX-V2.md موجودة وغير فارغة', DOC.length > 8000, DOC.length);
t('جدول المصفوفة في الوثيقة = المولَّد من البيانات', block('MATRIX') === A.renderMatrix(M));
t('جدول الإنفاذ في الوثيقة = المولَّد من البيانات', block('ENFORCE') === A.renderEnforce(M));
t('جدول الإدارة في الوثيقة = المولَّد من البيانات', block('ADMIN') === A.renderAdmin(M));
t('بصمة المصفوفة في الوثيقة = الحالية', DOC.indexOf(A.digest(M)) >= 0);
t('كتالوج الحالات في ملف JSON = المولَّد', (function () { var p = path.join(__dirname, 'access-v2-deny-cases.json'); return fs.existsSync(p) && JSON.stringify(JSON.parse(rd(p)).cases) === JSON.stringify(S); })());
t('المنح المتوقعة لفاحص 03.03 في ملف JSON = المشتقة', (function () { var p = path.join(__dirname, 'access-v2-expected-grants.json'); return fs.existsSync(p) && JSON.stringify(JSON.parse(rd(p)).grants) === JSON.stringify(A.deriveGrants(M)); })());
t('الوثيقة لا تحوي أسراراً ولا مفاتيح', !/eyJ[A-Za-z0-9_-]{15,}\.|sb_secret_|PRIVATE KEY|SERVICE_ROLE_KEY\s*[=:]\s*\S{20,}/.test(DOC));
['E-007', 'E-008', 'E-009', 'E-010', 'E-011', 'E-012'].forEach(function (id) { t('قرار المنفّذ ' + id + ' موثق في الوثيقة وسجل القرارات', DOC.indexOf(id) >= 0 && rd(path.join(D, 'DECISION_REGISTER.md')).indexOf(id) >= 0); });

// ===== 7) نموذج التهديدات =====
var TM = rd(path.join(D, 'THREAT-MODEL-V2.md'));
for (var n = 67; n <= 78; n++) { (function (id) { var row = TM.split('\n').filter(function (l) { return l.indexOf('| ' + id + ' |') === 0; })[0]; t(id + ' موجود في THREAT-MODEL-V2 بسبعة أعمدة وله اختبار مرتبط', !!row && row.split('|').length - 2 === 7 && /AM-\d\d|access-matrix-v2/.test(row), row ? row.slice(0, 40) : 'مفقود'); })('T-' + n); }
var tests = (DOC.match(/AM-\d\d/g) || []), defined = {}; (rd(__filename).match(/'AM-\d\d /g) || []).forEach(function (x) { defined[x.slice(1, 6)] = 1; });
t('كل AM-xx مذكور في الوثيقة معرَّف في هذا الملف', tests.every(function (x) { return defined[x]; }), tests.filter(function (x) { return !defined[x]; }).join());
t('كل مرجع AM-xx في نموذج التهديدات معرَّف', (TM.match(/AM-\d\d/g) || []).every(function (x) { return defined[x]; }));

console.log('\nالنتيجة: ' + pass + ' نجاح، ' + fail + ' فشل');
process.exit(fail ? 1 : 0);
