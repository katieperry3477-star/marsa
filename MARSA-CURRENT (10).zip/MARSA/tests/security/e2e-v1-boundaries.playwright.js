// 02.02 — اختبار حدود V1 في متصفح حقيقي (Chromium) عبر file:// (مثل تشغيل المستخدم). بيانات اصطناعية فقط.
// تشغيل: NODE_PATH=$(npm root -g) node tests/security/e2e-v1-boundaries.playwright.js
// يثبت: (1) V1 لا يقرأ/يكتب/يعدّ مفاتيح التطبيق القديم الحساسة رغم أن file:// يتشاركها مع full.html، (2) لا شبكة،
// (3) وضع «ممثل» لا يكشف شيئاً إضافياً، (4) كود خبيث لا يُنفَّذ ولا يُنشئ عناصر، (5) كود بمفاتيح ممنوعة يُرفض.
var pw = require('playwright'), path = require('path');
var ROOT = path.resolve(__dirname, '..', '..'), INDEX = 'file://' + ROOT + '/index.html', FULL = 'file://' + ROOT + '/full.html';
var S = require('../../js/v1-share.js');
var results = [];
function check(name, cond, detail) { results.push(!!cond); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }

var SENT = { grade: 'SENTGRADE7731', pay: 'SENTPAY8842', att: 'SENTATT6620', name: 'SENTNAME5519' };
var LEGACY = {
  'marsa.academic.grades.clsX': JSON.stringify({ schemaVersion: 1, records: [{ recordId: 'g1', note: SENT.grade, score: 17 }] }),
  'marsa.academic.payments.clsX': JSON.stringify({ schemaVersion: 1, records: [{ recordId: 'p1', purpose: SENT.pay, amount: 25000 }] }),
  'marsa.academic.attendance.clsX': JSON.stringify({ schemaVersion: 1, records: [{ recordId: 'a1', note: SENT.att }] }),
  'marsa.roster': JSON.stringify([{ name: SENT.name }])
};
async function load(page, url) {
  await page.goto('about:blank'); await page.goto(url); await page.waitForSelector('#app', { state: 'attached' });
  await page.evaluate(function () { return new Promise(function (r) { var d = document.getElementById('intro'); if (!d) return r(); var t = setTimeout(r, 3000); document.addEventListener('marsa:intro-done', function () { clearTimeout(t); r(); }, { once: true }); }); });
  await page.waitForFunction(function () { return !document.getElementById('intro') || document.getElementById('app').inert !== true; }, null, { timeout: 5000 }).catch(function () {});
  await page.waitForTimeout(120);
}
var ROUTES = ['#/', '#/day', '#/day/tomorrow', '#/exam', '#/saved', '#/add', '#/new', '#/mine', '#/settings', '#/about', '#/welcome/role'];

(async function () {
  var browser = await pw.chromium.launch(), ctx = await browser.newContext({ locale: 'ar' }), page = await ctx.newPage();
  var keyLog = [], reqs = [], errs = [];
  await ctx.exposeFunction('__lsLog', function (op, k) { keyLog.push(op + ':' + k); });
  await ctx.addInitScript(function () {
    var P = Storage.prototype, g = P.getItem, s = P.setItem, r = P.removeItem, k = P.key;
    P.getItem = function (x) { if (window.__lsLog) window.__lsLog('get', String(x)); return g.apply(this, arguments); };
    P.setItem = function (x) { if (window.__lsLog) window.__lsLog('set', String(x)); return s.apply(this, arguments); };
    P.removeItem = function (x) { if (window.__lsLog) window.__lsLog('rm', String(x)); return r.apply(this, arguments); };
    P.key = function (i) { if (window.__lsLog) window.__lsLog('enum', String(i)); return k.apply(this, arguments); };
  });
  page.on('request', function (rq) { reqs.push(rq.url()); });
  page.on('pageerror', function (e) { errs.push(String(e)); });

  // بذر: مفاتيح قديمة حساسة (كما لو استعمل المستخدم full.html على المتصفح نفسه) + V1 «تمّ الترحيب»
  await page.goto(FULL);
  await page.evaluate(function (L) { Object.keys(L).forEach(function (k) { localStorage.setItem(k, L[k]); }); localStorage.setItem('marsa.v1.ui', JSON.stringify({ schemaVersion: 1, mode: 'student', appUrl: '', theme: 'auto', welcomed: true })); }, LEGACY);
  var shared = await (await ctx.newPage()).goto(INDEX).then(function () { return null; });
  var p2 = ctx.pages()[ctx.pages().length - 1];
  var visible = await p2.evaluate(function () { return localStorage.getItem('marsa.academic.grades.clsX'); });
  check('[E2-01] توصيفي: full.html وindex.html يتشاركان localStorage على file:// (الأصل نفسه) — الخطر T-38 قائم', visible && visible.indexOf(SENT.grade) >= 0);
  await p2.close();
  keyLog.length = 0; reqs.length = 0;

  async function visit(mode) {
    for (var i = 0; i < ROUTES.length; i++) {
      await load(page, INDEX + ROUTES[i]);
      var txt = await page.evaluate(function () { return document.body.innerText + ' ' + document.documentElement.outerHTML.length; });
      Object.keys(SENT).forEach(function (k) { if (txt.indexOf(SENT[k]) >= 0) check('[E2-02] تسريب ' + k + ' في ' + mode + ' ' + ROUTES[i], false); });
    }
  }
  await page.goto(INDEX); await page.evaluate(function () { var u = JSON.parse(localStorage.getItem('marsa.v1.ui')); u.mode = 'student'; localStorage.setItem('marsa.v1.ui', JSON.stringify(u)); });
  await visit('student');
  await page.goto(INDEX); await page.evaluate(function () { var u = JSON.parse(localStorage.getItem('marsa.v1.ui')); u.mode = 'rep'; localStorage.setItem('marsa.v1.ui', JSON.stringify(u)); });
  await visit('rep');
  var leaked = results.length === 1; // لم تُسجَّل أي فشل تسريب بعد البند الأول
  check('[E2-02] ' + 2 * ROUTES.length + ' صفحة (11 مساراً × وضعي الطالب والممثل): لا ظهور لأي قيمة حساسة قديمة (درجات/دفعات/حضور/أسماء)', leaked);

  var bad = keyLog.filter(function (e) { return !/^(get|set|rm):marsa\.v1\./.test(e) && e.indexOf('enum:') !== 0; });
  var enums = keyLog.filter(function (e) { return e.indexOf('enum:') === 0; });
  check('[E2-03] كل عمليات localStorage في V1 على مفاتيح marsa.v1.* فقط (' + keyLog.length + ' عملية مسجَّلة)، لا قراءة لأي مفتاح قديم', keyLog.length > 10 && bad.length === 0, JSON.stringify(bad.slice(0, 5)));
  check('[E2-04] V1 لا يعدّ مفاتيح التخزين (key()/length) فلا يكتشف مفاتيح التطبيق القديم', enums.length === 0, enums.slice(0, 3).join(','));
  var net = reqs.filter(function (u) { return !/^(file:|data:|blob:|about:)/.test(u); });
  check('[E2-05] لا أي طلب شبكة (' + reqs.length + ' طلباً محلياً/ملفياً، 0 خارجي)', reqs.length > 0 && net.length === 0, net.slice(0, 3).join(','));

  // الدور تبديل واجهة: طالب يفتح #/new فيتحول إلى «ممثل» بلا أي توثيق (توصيفي T-30) ولا يظهر شيء إضافي
  await page.goto(INDEX); await page.evaluate(function () { var u = JSON.parse(localStorage.getItem('marsa.v1.ui')); u.mode = 'student'; localStorage.setItem('marsa.v1.ui', JSON.stringify(u)); });
  await load(page, INDEX + '#/mine'); await page.waitForSelector('#app h1');
  var mode = await page.evaluate(function () { return JSON.parse(localStorage.getItem('marsa.v1.ui')).mode; });
  var shown = await page.evaluate(function () { return document.body.innerText; });
  check('[E2-06] توصيفي: رابط #/mine يحوّل الطالب إلى وضع الممثل بلا أي توثيق (الدور تبديل واجهة، T-30) ولا يُعرض به شيء حساس', mode === 'rep' && Object.keys(SENT).every(function (k) { return shown.indexOf(SENT[k]) < 0; }), mode);

  // كود خبيث: لا تنفيذ ولا عناصر
  var evil = '<img src=x onerror="window.__pwn=1"><script>window.__pwn=2<\/script>\nرابط https://phish.example/login وهذا javascript:window.__pwn=3 وهذا data:text/html,<b>x</b>';
  var enc = await S.encode({ id: 'p4k2m9x7q1ab', subject: 'مادة اختبار', title: 'عنوان <b>غامق</b>', date: '2026-11-04', content: evil, updatedAt: 1780000000000 });
  await load(page, INDEX + '#/add'); await page.waitForSelector('#code-in');
  await page.fill('#code-in', enc.code); await page.click('button:has-text("معاينة التحضير")'); await page.waitForSelector('.prep');
  var r = await page.evaluate(function () {
    var p = document.querySelector('.prep');
    return { pwn: typeof window.__pwn, imgs: p.querySelectorAll('img,script,iframe,object,embed,svg').length, bold: p.querySelectorAll('b').length, txt: p.innerText, js: document.querySelectorAll('a[href^="javascript:"],a[href^="data:"]').length,
      links: Array.prototype.map.call(p.querySelectorAll('a'), function (a) { return { h: a.getAttribute('href'), t: a.target, r: a.rel }; }) };
  });
  check('[E2-07] كود خبيث: لا تنفيذ سكربت/معالج، لا عناصر img/script/iframe/b مُنشأة، والنص يظهر حرفياً', r.pwn === 'undefined' && r.imgs === 0 && r.bold === 0 && r.txt.indexOf('<img src=x') >= 0 && r.txt.indexOf('<script>') >= 0, JSON.stringify(r));
  check('[E2-08] الروابط: لا a[href=javascript:/data:]؛ رابط https وحيد يُنقر بـtarget=_blank وrel=noopener (توصيفي T-29: التصيّد عبر https ممكن)', r.js === 0 && r.links.length === 1 && r.links[0].h === 'https://phish.example/login' && r.links[0].t === '_blank' && /noopener/.test(r.links[0].r), JSON.stringify(r.links));

  // كود بمفتاح ممنوع (درجات) وقناة بلا هوية
  function forge(obj) { var raw = new TextEncoder().encode(JSON.stringify(obj)), crc = S.crc32(raw), len = raw.length, all = new Uint8Array(8 + len), h = [0, (len >>> 16) & 255, (len >>> 8) & 255, len & 255, (crc >>> 24) & 255, (crc >>> 16) & 255, (crc >>> 8) & 255, crc & 255], i; for (i = 0; i < 8; i++) all[i] = h[i]; all.set(raw, 8); return 'MARSA1-' + S.b64encode(all); }
  var forbidden = forge({ v: 1, i: 'p4k2m9x7q1ab', s: 'م', t: 'ع', d: '2026-11-04', c: 'ن', u: 1, grades: [{ name: SENT.name, score: 3 }] });
  await load(page, INDEX + '#/add'); await page.waitForSelector('#code-in');
  await page.fill('#code-in', forbidden); await page.click('button:has-text("معاينة التحضير")'); await page.waitForSelector('.note.err');
  var noPrep = await page.$$('.prep'), errTxt = await page.innerText('.note.err');
  check('[E2-09] كود يحمل مفتاح درجات/طلاب (حمولة ممنوعة): يُرفض برسالة عربية، لا معاينة ولا حفظ', noPrep.length === 0 && /[؀-ۿ]/.test(errTxt), errTxt);

  var after = await page.evaluate(function () { var o = {}; ['marsa.academic.grades.clsX', 'marsa.academic.payments.clsX', 'marsa.academic.attendance.clsX', 'marsa.roster'].forEach(function (k) { o[k] = localStorage.getItem(k); }); return o; });
  var same = Object.keys(LEGACY).every(function (k) { return after[k] === LEGACY[k]; });
  var written = keyLog.filter(function (e) { return /^(set|rm):/.test(e) && e.indexOf(':marsa.v1.') < 0; });
  check('[E2-10] المفاتيح القديمة الحساسة بقيت بايتاً ببايت بعد كل الاستعمال (بما فيه الاستيراد الخبيث)، ولم يُكتب/يُحذف أي مفتاح غير V1', same && written.length === 0, JSON.stringify(written));
  check('[E2-11] لا أخطاء JavaScript غير ملتقطة', errs.length === 0, errs.slice(0, 2).join(' | '));

  await browser.close();
  var fails = results.filter(function (x) { return !x; }).length;
  console.log('\n' + results.length + ' checks, ' + fails + ' failed'); process.exit(fails ? 1 : 0);
})().catch(function (e) { console.log('FAIL [E2-00] استثناء:', e && e.stack || e); process.exit(2); });
