// 02.02 — اختبارات الرفض (deny-by-default) لمصفوفة المرحلة 2 وقناة الكود V1. لا يحتاج مكتبات.
// تشغيل: node tests/security/stage2-deny.test.js
// يختبر: المصفوفة بمرجع التقرير policy-oracle.can() + جدول ذهبي مكتوب يدوياً + 18 طفرة + حقائق V1 الساكنة والتشغيلية + اتساق الوثائق.
// لا يمسّ كود التطبيق؛ كل البيانات اصطناعية.
'use strict';
var fs = require('fs'), path = require('path'), assert = require('assert');
var ROOT = path.resolve(__dirname, '..', '..');
var O = require('./policy-oracle.js'), SM = require('./stage2-matrix.js');
var S = require('../../js/v1-share.js'), ST = require('../../js/v1-store.js'), SAFE = require('../../js/safe-text.js');
var n = 0, f = 0, tasks = [];
function T(name, fn) { tasks.push(function () { return Promise.resolve().then(fn).then(function () { n++; console.log('PASS', name); }, function (e) { f++; console.log('FAIL', name, '::', e && e.message); }); }); }
function read(p) { return fs.readFileSync(path.join(ROOT, p), 'utf8'); }
function strip(src) { return src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"\\])\/\/[^\n]*/g, '$1'); }
function clone(o) { return JSON.parse(JSON.stringify(o)); }

var MAT = SM.load(), OLD = JSON.parse(read('docs/stage5/security/permissions-matrix.json'));
var ROLES = ['student', 'rep', 'developer', 'anonymous'], ACTS = ['C', 'R', 'U', 'D'], SENS = ['attendance', 'grades', 'payments'];
var CONTENT = ['dailyLessons', 'preparations', 'schedule', 'exams'];
var NOPOL = {};
function actor(role, extra) { var a = { role: role, status: 'active', classId: 'clsA', studentId: 'stu1' }, k; for (k in (extra || {})) a[k] = extra[k]; return a; }
function res(type, extra) { var r = { type: type, classId: 'clsA', studentId: 'stu1' }, k; for (k in (extra || {})) r[k] = extra[k]; return r; }
function allowedSet(m, role, type, ctx, pol) { return ACTS.filter(function (a) { return O.can(actor(role, ctx && ctx.actor), a, res(type, ctx && ctx.res), m, pol || NOPOL).allow; }).join(''); }

// ----- ثوابت السرية على مصفوفة (تُشغَّل على الحقيقية وعلى الطفرات) -----
function invariants(m, pol) {
  var v = [], res_ = m.resources || {}, types = Object.keys(res_), pols = pol || m.selfViewPolicy || {};
  function g(role, type, a, ctx) { try { return O.can(actor(role, ctx && ctx.actor), a, res(type, ctx && ctx.res), m, pols).allow; } catch (e) { return 'throw'; } }
  if (m.defaultPolicy !== 'deny') v.push('defaultPolicy');
  if (JSON.stringify(m.roles) !== JSON.stringify(ROLES)) v.push('roles-set');
  types.forEach(function (t) {
    var r = res_[t];
    ROLES.forEach(function (role) {
      var p = r.perms && r.perms[role];
      if (!p) { v.push('missing-perm:' + role + ':' + t); return; }
      if (p.scope === 'any' && role !== 'developer') v.push('any-non-dev:' + role + ':' + t);
      if (role === 'anonymous' && (p.actions || '') !== '') v.push('anon-grant:' + t);
      if (role === 'student' && /[CUD]/.test(p.actions || '')) v.push('student-write:' + t);
    });
    ACTS.forEach(function (a) {
      if (g('anonymous', t, a) !== false) v.push('anon-allow:' + t + a);
      if (g('student', t, a, { res: { classId: 'clsB' } }) !== false) v.push('student-cross-class:' + t + a);
      if (g('rep', t, a, { res: { classId: 'clsB' } }) !== false) v.push('rep-cross-class:' + t + a);
      if (g('student', t, a, { res: { studentId: 'stu2' } }) !== false && (t === 'roster' || SENS.indexOf(t) >= 0)) v.push('student-other-student:' + t + a);
      ROLES.forEach(function (role) { if (g(role, t, a, { actor: { status: 'suspended' } }) !== false) v.push('inactive-allow:' + role + t + a); });
    });
  });
  SENS.concat(['reports']).forEach(function (t) { ACTS.forEach(function (a) { if (g('developer', t, a) !== false) v.push('dev-direct:' + t + a); }); });
  CONTENT.forEach(function (t) { ['C', 'U', 'D'].forEach(function (a) { if (g('developer', t, a) !== false) v.push('dev-content-write:' + t + a); }); });
  ['audit_log', 'membership', 'restore_op', 'selfview_policy'].forEach(function (t) { ['student', 'rep'].forEach(function (role) { ACTS.forEach(function (a) { if (g(role, t, a) !== false) v.push('priv-resource:' + role + t + a); }); }); });
  ['audit_log', 'membership', 'restore_op'].forEach(function (t) { ['C', 'U', 'D'].forEach(function (a) { if (t === 'audit_log' && g('developer', t, a) !== false) v.push('audit-mutable:' + a); }); });
  // الدعوات: لا أحد يصدر مطوراً؛ الطالب لا يصدر؛ الممثل لصفه وللطالب فقط
  if (O.canIssueInvite(actor('developer'), { role: 'developer', classId: 'clsA' }, m)) v.push('issue-developer-by-dev');
  if (O.canIssueInvite(actor('rep'), { role: 'rep', classId: 'clsA' }, m)) v.push('rep-issues-rep');
  if (O.canIssueInvite(actor('rep'), { role: 'student', classId: 'clsB' }, m)) v.push('rep-issues-other-class');
  if (O.canIssueInvite(actor('student'), { role: 'student', classId: 'clsA' }, m)) v.push('student-issues');
  // selfView: لا يُفتح إلا بـenabled===true مع consentRef، للقراءة وسجله فقط، ولا يفتح نوعاً آخر
  SENS.forEach(function (t) {
    var on = {}; on[t] = { enabled: true, consentRef: 'DEC-test-1' };
    if (g('student', t, 'R') !== false) v.push('selfview-default-open:' + t);
    var half = {}; half[t] = { enabled: true, consentRef: '' };
    if (O.can(actor('student'), 'R', res(t), m, half).allow) v.push('selfview-no-consent:' + t);
    ['C', 'U', 'D'].forEach(function (a) { if (O.can(actor('student'), a, res(t), m, on).allow) v.push('selfview-write:' + t + a); });
    SENS.forEach(function (o) { if (o !== t && O.can(actor('student'), 'R', res(o), m, on).allow) v.push('selfview-leaks-other:' + t + '>' + o); });
  });
  // قناة الكود
  var cp = m.channelPolicy || {};
  if (cp.authority !== 'none') v.push('channel-authority');
  ['grades', 'attendance', 'payments', 'roster', 'studentCode'].forEach(function (k) { if ((cp.allowedPayloadKeys || []).indexOf(k) >= 0) v.push('channel-key:' + k); });
  return v;
}

// ===== D2-M: المصفوفة =====
T('[D2-M01] المخطط: الأدوار الأربعة ثابتة، كل مورد يحدد كل الأدوار، والافتراضي deny', function () {
  assert.deepStrictEqual(MAT.roles, ROLES); assert.strictEqual(MAT.defaultPolicy, 'deny');
  Object.keys(MAT.resources).forEach(function (t) {
    ROLES.forEach(function (r) { var p = MAT.resources[t].perms[r]; assert.ok(p, t + ':' + r); assert.ok(/^[CRUD]*$/.test(p.actions), t + ':' + r + ' actions'); assert.ok(Object.prototype.hasOwnProperty.call(MAT.scopes, p.scope), t + ':' + r + ' scope'); if (!p.actions) assert.strictEqual(p.scope, 'none', t + ':' + r + ' empty⇒none'); });
    assert.ok(['none', 'soft', 'archive'].indexOf(MAT.resources[t].deleteMode) >= 0, t + ' deleteMode');
  });
  assert.strictEqual(Object.keys(MAT.resources).length, 16);
});
T('[D2-M02] الفشل المغلق: دور/مورد/إجراء/حالة/مدخل مشوّه ⇒ رفض (28 حالة)', function () {
  var bad = [
    [null, 'R', res('class')], [actor('rep'), 'R', null], [actor('rep'), 'R', 'class'], [{}, 'R', res('class')],
    [actor('hacker'), 'R', res('class')], [actor('teacher'), 'R', res('grades')], [actor('admin'), 'R', res('class')], [actor('rep', { role: 'constructor' }), 'R', res('class')],
    [actor('rep'), 'X', res('class')], [actor('rep'), '', res('class')], [actor('rep'), 'RU', res('class')], [actor('rep'), 'r', res('class')], [actor('rep'), undefined, res('class')],
    [actor('rep'), 'R', res('nope')], [actor('rep'), 'R', res('constructor')], [actor('rep'), 'R', res('__proto__')], [actor('rep'), 'R', res('toString')], [actor('rep'), 'R', res('hasOwnProperty')],
    [actor('rep', { status: undefined }), 'R', res('class')], [actor('rep', { status: '' }), 'R', res('class')], [actor('rep', { status: 'ACTIVE' }), 'R', res('class')], [actor('rep', { status: 'archived' }), 'R', res('class')],
    [actor('rep', { classId: undefined }), 'R', res('class')], [actor('rep', { classId: '' }), 'R', res('class', { classId: '' })], [actor('rep', { classId: '../x' }), 'R', res('class', { classId: '../x' })],
    [actor('student', { studentId: undefined }), 'R', res('roster', { studentId: undefined })], [actor('student'), 'R', res('roster', { studentId: '' })], [actor('student', { classId: null }), 'R', res('preparations', { classId: null })]
  ];
  assert.strictEqual(bad.length, 28);
  bad.forEach(function (c, i) { assert.strictEqual(O.can(c[0], c[1], c[2], MAT, NOPOL).allow, false, 'case ' + i); });
});
T('[D2-M03] الجدول الذهبي (مكتوب يدوياً): الصف/الدرس/التحضير/الحضور/الدرجات/المقبوضات × الأدوار في صف المستخدم نفسه', function () {
  var GOLD = {
    'class': { student: 'R', rep: 'RU', developer: 'CRU', anonymous: '' },
    dailyLessons: { student: 'R', rep: 'CRUD', developer: 'R', anonymous: '' },
    preparations: { student: 'R', rep: 'CRUD', developer: 'R', anonymous: '' },
    attendance: { student: '', rep: 'CRUD', developer: '', anonymous: '' },
    grades: { student: '', rep: 'CRUD', developer: '', anonymous: '' },
    payments: { student: '', rep: 'CRUD', developer: '', anonymous: '' },
    selfview_policy: { student: '', rep: '', developer: 'RU', anonymous: '' }
  };
  Object.keys(GOLD).forEach(function (t) { ROLES.forEach(function (r) { var ctx = r === 'developer' ? { actor: { classId: 'clsZ' } } : null; assert.strictEqual(allowedSet(MAT, r, t, ctx), GOLD[t][r], t + ' × ' + r); }); });
});
T('[D2-M04] لا وصول عبر الصفوف: طالب/ممثل على صف آخر مرفوض في كل مورد × إجراء (128 خلية)', function () {
  var c = 0; Object.keys(MAT.resources).forEach(function (t) { ['student', 'rep'].forEach(function (r) { ACTS.forEach(function (a) { assert.strictEqual(O.can(actor(r), a, res(t, { classId: 'clsB' }), MAT, NOPOL).allow, false, r + t + a); c++; }); }); });
  assert.strictEqual(c, 128);
});
T('[D2-M05] لا كشف طالب لطالب: حتى مع تفعيل كل selfView، سجل زميل مرفوض (C2/C3/القائمة)', function () {
  var on = { attendance: { enabled: true, consentRef: 'DEC-t' }, grades: { enabled: true, consentRef: 'DEC-t' }, payments: { enabled: true, consentRef: 'DEC-t' } };
  SENS.concat(['roster']).forEach(function (t) { ACTS.forEach(function (a) { assert.strictEqual(O.can(actor('student'), a, res(t, { studentId: 'stu2' }), MAT, on).allow, false, t + a); }); });
});
T('[D2-M06] selfView: مغلق افتراضياً؛ يحتاج enabled===true وconsentRef؛ قراءة سجله فقط؛ لا يفتح نوعاً آخر', function () {
  SENS.forEach(function (t) {
    assert.strictEqual(O.can(actor('student'), 'R', res(t), MAT, NOPOL).allow, false);
    assert.strictEqual(O.can(actor('student'), 'R', res(t), MAT, MAT.selfViewPolicy).allow, false, 'سياسة الملف نفسها معطّلة');
    var p = {}; p[t] = { enabled: 'true', consentRef: 'DEC-1' }; assert.strictEqual(O.can(actor('student'), 'R', res(t), MAT, p).allow, false, 'enabled نصي');
    p[t] = { enabled: true, consentRef: ' ' }; assert.strictEqual(O.can(actor('student'), 'R', res(t), MAT, p).allow, false, 'بلا consent');
    p[t] = { enabled: true, consentRef: 'DEC-1' }; assert.strictEqual(O.can(actor('student'), 'R', res(t), MAT, p).allow, true, 'ضابط إيجابي');
    ['C', 'U', 'D'].forEach(function (a) { assert.strictEqual(O.can(actor('student'), a, res(t), MAT, p).allow, false); });
    SENS.filter(function (o) { return o !== t; }).forEach(function (o) { assert.strictEqual(O.can(actor('student'), 'R', res(o), MAT, p).allow, false, t + '>' + o); });
  });
  SENS.forEach(function (t) { assert.strictEqual(MAT.selfViewPolicy[t].enabled, false); });
});
T('[D2-M07] حساب غير فعّال (موقوف/مؤرشف/ملغى/ناقص) يُرفض في كل خلية (4 أدوار × 16 مورد × 4 إجراء × 5 حالات)', function () {
  var c = 0; ['suspended', 'archived', 'revoked', '', undefined].forEach(function (s) { Object.keys(MAT.resources).forEach(function (t) { ROLES.forEach(function (r) { ACTS.forEach(function (a) { assert.strictEqual(O.can(actor(r, { status: s }), a, res(t), MAT, NOPOL).allow, false); c++; }); }); }); });
  assert.strictEqual(c, 1280);
});
T('[D2-M08] المجهول/حامل الكود: كل مورد × إجراء مرفوض (64 خلية) — CONF-05/17', function () {
  var c = 0; Object.keys(MAT.resources).forEach(function (t) { ACTS.forEach(function (a) { assert.strictEqual(O.can(actor('anonymous'), a, res(t), MAT, MAT.selfViewPolicy).allow, false); c++; }); }); assert.strictEqual(c, 64);
});
T('[D2-M09] المطور: لا CRUD مباشر على الحضور/الدرجات/المقبوضات/التقارير، ومحتوى الصف قراءة فقط (CONF-10، DEC-13)', function () {
  SENS.concat(['reports']).forEach(function (t) { assert.strictEqual(allowedSet(MAT, 'developer', t, { actor: { classId: 'clsZ' } }), '', t); });
  CONTENT.forEach(function (t) { assert.strictEqual(allowedSet(MAT, 'developer', t, { actor: { classId: 'clsZ' } }), 'R', t); });
});
T('[D2-M10] الطالب بلا C/U/D في أي مورد (CONF-03)', function () { Object.keys(MAT.resources).forEach(function (t) { assert.ok(!/[CUD]/.test(MAT.resources[t].perms.student.actions), t); }); });
T('[D2-M11] الطالب والممثل ✗ على التدقيق والعضويات والاستعادة ومفتاح selfView (CONF-18)', function () {
  ['audit_log', 'membership', 'restore_op', 'selfview_policy'].forEach(function (t) { ['student', 'rep'].forEach(function (r) { assert.strictEqual(allowedSet(MAT, r, t), '', r + t); }); });
  assert.strictEqual(allowedSet(MAT, 'developer', 'audit_log', { actor: { classId: 'z' } }), 'R', 'التدقيق للقراءة فقط (append-only)');
});
T('[D2-M12] قواعد الإصدار: لا أحد يصدر مطوراً؛ الطالب لا يصدر؛ الممثل: طالب لصفه فقط', function () {
  ROLES.forEach(function (r) { assert.strictEqual(O.canIssueInvite(actor(r), { role: 'developer', classId: 'clsA' }, MAT), false, r + ' يصدر مطوراً'); });
  assert.strictEqual(O.canIssueInvite(actor('student'), { role: 'student', classId: 'clsA' }, MAT), false);
  assert.strictEqual(O.canIssueInvite(actor('anonymous'), { role: 'student', classId: 'clsA' }, MAT), false);
  assert.strictEqual(O.canIssueInvite(actor('rep'), { role: 'student', classId: 'clsA' }, MAT), true, 'ضابط إيجابي');
  assert.strictEqual(O.canIssueInvite(actor('rep'), { role: 'student', classId: 'clsB' }, MAT), false);
  assert.strictEqual(O.canIssueInvite(actor('rep'), { role: 'rep', classId: 'clsA' }, MAT), false);
});
T('[D2-M13] لا منحة جديدة عن 5.04: الخلايا المشتركة مطابقة حرفياً؛ المضاف مورد واحد فقط وهو selfview_policy', function () {
  var added = Object.keys(MAT.resources).filter(function (t) { return !OLD.resources[t]; });
  assert.deepStrictEqual(added, ['selfview_policy']);
  Object.keys(OLD.resources).forEach(function (t) { assert.deepStrictEqual(MAT.resources[t].perms, OLD.resources[t].perms, t); assert.strictEqual(MAT.resources[t].deleteMode, OLD.resources[t].deleteMode, t + ' deleteMode'); });
  assert.deepStrictEqual(MAT.issueRules, OLD.issueRules);
});
T('[D2-M14] المنح المشروطة (DEC-25) هي بالضبط منح الممثل على C2/C3/التقارير وكلها موجودة فعلاً', function () {
  var got = MAT.conditionalGrants.map(function (g) { return g.role + ':' + g.resource; }).sort();
  assert.deepStrictEqual(got, ['rep:attendance', 'rep:grades', 'rep:payments', 'rep:reports']);
  MAT.conditionalGrants.forEach(function (g) { assert.ok(MAT.resources[g.resource].perms[g.role].actions.length > 0); assert.strictEqual(g.decision, 'DEC-25'); });
});
T('[D2-M15] لا انجراف: جدول 02.02-PERMISSIONS.md == المولَّد من JSON', function () { assert.strictEqual(SM.inDoc(), SM.block(MAT)); });
T('[D2-M16] الثوابت تمرّ على المصفوفة الحقيقية بلا مخالفة', function () { assert.deepStrictEqual(invariants(MAT), []); });

// ===== D2-X: الطفرات (إثبات أن الاختبارات ليست فارغة) =====
var MUTS = [
  ['student يقرأ المقبوضات بنطاق الصف', function (m) { m.resources.payments.perms.student = { actions: 'R', scope: 'class' }; }],
  ['anonymous يقرأ الصف', function (m) { m.resources['class'].perms.anonymous = { actions: 'R', scope: 'class' }; }],
  ['developer CRUD على المقبوضات', function (m) { m.resources.payments.perms.developer = { actions: 'CRUD', scope: 'any' }; }],
  ['rep بنطاق any على الصف', function (m) { m.resources['class'].perms.rep = { actions: 'RU', scope: 'any' }; }],
  ['student ينشئ تحضيراً', function (m) { m.resources.preparations.perms.student = { actions: 'CR', scope: 'class' }; }],
  ['rep يقرأ التدقيق', function (m) { m.resources.audit_log.perms.rep = { actions: 'R', scope: 'class' }; }],
  ['student يعدّل مفتاح selfView', function (m) { m.resources.selfview_policy.perms.student = { actions: 'RU', scope: 'self' }; }],
  ['rep يبدّل مفتاح selfView', function (m) { m.resources.selfview_policy.perms.rep = { actions: 'U', scope: 'class' }; }],
  ['developer يكتب على الدروس (DEC-13)', function (m) { m.resources.dailyLessons.perms.developer = { actions: 'RU', scope: 'any' }; }],
  ['defaultPolicy = allow', function (m) { m.defaultPolicy = 'allow'; }],
  ['rep يصدر ممثلين', function (m) { m.issueRules.rep.issuesRoles = ['student', 'rep']; }],
  ['rep يصدر لأي صف', function (m) { m.issueRules.rep.classScope = 'any'; }],
  ['مفتاح grades في حمولة الكود', function (m) { m.channelPolicy.allowedPayloadKeys.push('grades'); }],
  ['سلطة للكود', function (m) { m.channelPolicy.authority = 'membership'; }],
  ['student يقرأ القائمة بنطاق الصف (DEC-04)', function (m) { m.resources.roster.perms.student = { actions: 'R', scope: 'class' }; }],
  ['developer يقرأ الحضور مباشرة', function (m) { m.resources.attendance.perms.developer = { actions: 'R', scope: 'any' }; }],
  ['دور جديد teacher بقراءة الدرجات', function (m) { m.roles = m.roles.concat(['teacher']); Object.keys(m.resources).forEach(function (t) { m.resources[t].perms.teacher = { actions: t === 'grades' ? 'R' : '', scope: t === 'grades' ? 'any' : 'none' }; }); }],
  ['حذف دور anonymous من مورد (نقص ⇒ يجب أن يُكتشف)', function (m) { delete m.resources.grades.perms.anonymous; }]
];
T('[D2-X01] ' + MUTS.length + ' طفرة تُضعف المصفوفة وكلها تُكتشف', function () {
  MUTS.forEach(function (mu) { var m = clone(MAT); mu[1](m); var v = invariants(m); assert.ok(v.length > 0, 'طفرة لم تُكتشف: ' + mu[0]); });
  assert.strictEqual(MUTS.length, 18);
});
T('[D2-X02] طفرة التفعيل الذاتي للمعلّم: تفعيل selfView بلا consentRef في سياسة الملف لا يفتح شيئاً', function () {
  var m = clone(MAT); m.selfViewPolicy.grades = { enabled: true, consentRef: null };
  assert.strictEqual(O.can(actor('student'), 'R', res('grades'), m, m.selfViewPolicy).allow, false);
});

// ===== D2-C: قناة الكود وV1 (ساكن) =====
var V1_JS = ['v1-app.js', 'v1-boot.js', 'v1-demo.js', 'v1-share.js', 'v1-store.js', 'v1-text.js'].map(function (x) { return 'js/' + x; });
var V1_ALL = V1_JS.concat(['index.html']);
var V1_CODE = {}; V1_ALL.forEach(function (p) { V1_CODE[p] = p.slice(-5) === '.html' ? read(p) : strip(read(p)); });
T('[D2-C01] V1 بلا أي قناة شبكة: fetch/XHR/WebSocket/EventSource/sendBeacon/Worker/importScripts/serviceWorker', function () {
  V1_ALL.forEach(function (p) { assert.ok(!/\b(fetch\s*\(|XMLHttpRequest|WebSocket|EventSource|sendBeacon|importScripts|new\s+Worker|SharedWorker|serviceWorker|indexedDB)\b/.test(V1_CODE[p]), p); });
});
T('[D2-C02] مفاتيح التخزين في V1 محصورة بـmarsa.v1.* المعروفة؛ لا مفتاح قديم/حساس', function () {
  var allowed = /^marsa\.v1\.(mine|saved|draft|ui|demo|probe|backup\.)?$/, seen = [];
  V1_JS.forEach(function (p) { (V1_CODE[p].match(/['"]marsa\.[A-Za-z0-9_.\-]*['"]/g) || []).forEach(function (s) { seen.push(s.slice(1, -1)); }); });
  assert.ok(seen.length >= 6); seen.forEach(function (k) { assert.ok(allowed.test(k), 'مفتاح غير متوقع: ' + k); });
});
T('[D2-C03] V1 لا يذكر مفاتيح/مفاهيم التطبيق القديم الحساسة (marsa.academic/students/roster/classes، attendance/grades/payments)', function () {
  V1_JS.forEach(function (p) { assert.ok(!/marsa\.(academic|students|classes|roster|ui\.v1)|attendance|payments|\bgrades\b/i.test(V1_CODE[p]), p); });
});
T('[D2-C04] لا رمز ممثل/مطور ثابت في V1 ولا في index.html (T-01 لا ينتقل إلى V1)', function () {
  V1_ALL.forEach(function (p) { assert.ok(!/MRS-REP|REP_DEMO|DEV-CODE|BOOTSTRAP/i.test(V1_CODE[p]), p); });
});
T('[D2-C04b] توصيفي: الرمز التجريبي القديم ما زال في app.js/full.html المستضافَين مع V1 (الخطر T-01/T-38 موثق لا مُعالَج)', function () {
  assert.ok(/MRS-REP-DEMO/.test(read('js/app.js'))); assert.ok(fs.existsSync(path.join(ROOT, 'full.html')));
});
T('[D2-C05] لا حقن HTML في V1: لا innerHTML/outerHTML/insertAdjacentHTML/document.write/eval/new Function/setTimeout(نص)', function () {
  V1_ALL.filter(function (p) { return p.slice(-3) === '.js'; }).forEach(function (p) { assert.ok(!/\.(innerHTML|outerHTML)\b|insertAdjacentHTML|document\.write|\beval\s*\(|new\s+Function\b|setTimeout\s*\(\s*['"`]|setInterval\s*\(\s*['"`]/.test(V1_CODE[p]), p); });
  assert.ok(!/<script[^>]+src=["']https?:|\son[a-z]+\s*=|javascript:/i.test(V1_CODE['index.html']));
});
T('[D2-C06] التنقل الخارجي الوحيد wa.me (رابط https) وتسمية SVG؛ لا غيرها في V1', function () {
  var urls = []; V1_ALL.forEach(function (p) { (V1_CODE[p].match(/https?:\/\/[^\s'"`)<>]+/g) || []).forEach(function (u) { urls.push(u); }); });
  urls.forEach(function (u) { assert.ok(/^https:\/\/wa\.me\/\?text=|^http:\/\/www\.w3\.org\/2000\/svg|^https:\/\/…?$|^https:\/\/$/.test(u) || /^https?:\/\/$/.test(u), 'عنوان غير متوقع: ' + u); });
  assert.ok(urls.some(function (u) { return /wa\.me/.test(u); }));
});
T('[D2-C07] تخزين الواجهة لا يُسجّل إلا mode/appUrl/theme/welcomed؛ الدور ليس ادّعاء صلاحية (CONF-19)', function () {
  var m = {}, st = { getItem: function (k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem: function (k, v) { m[k] = String(v); }, removeItem: function (k) { delete m[k]; } };
  var s = ST.create({ storage: st, now: function () { return 1780000000000; } });
  assert.strictEqual(s.saveUi({ mode: 'rep', appUrl: 'https://x.example', isAdmin: true, role: 'developer', token: 'T' }), true);
  var d = JSON.parse(m['marsa.v1.ui']); assert.deepStrictEqual(Object.keys(d).sort(), ['appUrl', 'mode', 'schemaVersion', 'theme', 'welcomed']);
  assert.ok(['rep', 'student'].indexOf(d.mode) >= 0); assert.strictEqual(JSON.stringify(m).indexOf('developer'), -1);
  assert.strictEqual(s.saveUi({ mode: 'developer' }), true); assert.strictEqual(JSON.parse(m['marsa.v1.ui']).mode, 'student', 'دور غير معروف ⇒ student');
});

// ===== D2-K: حمولة الكود =====
var UTF = new TextEncoder();
function forge(payload, o) { o = o || {}; var raw = UTF.encode(typeof payload === 'string' ? payload : JSON.stringify(payload)), crc = o.crc !== undefined ? o.crc : S.crc32(raw), len = o.len !== undefined ? o.len : raw.length, head = [0, (len >>> 16) & 255, (len >>> 8) & 255, len & 255, (crc >>> 24) & 255, (crc >>> 16) & 255, (crc >>> 8) & 255, crc & 255], all = new Uint8Array(8 + raw.length), i; for (i = 0; i < 8; i++) all[i] = head[i]; all.set(raw, 8); return 'MARSA1-' + S.b64encode(all); }
function good(x) { var o = { v: 1, i: 'p4k2m9x7q1ab', s: 'مادة', t: 'عنوان', d: '2026-10-28', c: 'نص', u: 1780000000000 }, k; for (k in (x || {})) { if (x[k] === undefined) delete o[k]; else o[k] = x[k]; } return o; }
T('[D2-K01] ضابط إيجابي: كود سليم يُقبل', function () { var r = S.decode(forge(good())); assert.strictEqual(r.ok, true); });
T('[D2-K02] مفاتيح غير مسموحة (طلاب/درجات/دفعات/رموز/__proto__/constructor) ⇒ يُرفض الكود كله (CONF-20)', function () {
  ['studentName', 'students', 'grades', 'grade', 'attendance', 'payments', 'amount', 'phone', 'studentCode', 'token', 'role', 'isAdmin', 'classId', 'memberId'].forEach(function (k) { var o = good(); o[k] = 'x'; assert.strictEqual(S.decode(forge(o)).ok, false, k); });
  assert.strictEqual(S.decode(forge('{"v":1,"i":"p4k2m9x7q1ab","s":"م","t":"ع","d":"2026-10-28","c":"ن","u":1,"__proto__":{"role":"developer"}}')).ok, false, '__proto__');
  assert.strictEqual(S.decode(forge('{"v":1,"i":"p4k2m9x7q1ab","s":"م","t":"ع","d":"2026-10-28","c":"ن","u":1,"constructor":{"prototype":{}}}')).ok, false, 'constructor');
  assert.strictEqual(({}).role, undefined, 'لا تلوّث للنموذج');
});
T('[D2-K03] الناتج المفكوك يحوي حقول التحضير فقط', function () {
  var r = S.decode(forge(good({ p: 'ص 1', h: 'واجب', n: 'ملاحظة', g: 'ب' })));
  assert.strictEqual(r.ok, true); var allowed = ['id', 'subject', 'title', 'date', 'content', 'homework', 'pages', 'notes', 'group', 'updatedAt'];
  Object.keys(r.prep).forEach(function (k) { assert.ok(allowed.indexOf(k) >= 0, 'حقل غير متوقع: ' + k); });
});
T('[D2-K04] قناة بلا هوية: لا تتغير النتيجة بتغيير «المُرسل»؛ CRC32 يكشف التلف لكنه لا يوثّق (توصيفي T-26)', function () {
  var raw = UTF.encode(JSON.stringify(good())); var bad = forge(good(), { crc: (S.crc32(raw) ^ 1) >>> 0 }); assert.strictEqual(S.decode(bad).ok, false, 'CRC خاطئ ⇒ مرفوض');
  var forged = forge(good({ t: 'إعلان من الممثل: الامتحان أُلغي', c: 'تعليمات مزوّرة تنتحل الممثل' })); var r = S.decode(forged);
  assert.strictEqual(r.ok, true, 'التزوير بـCRC صحيح يُقبل — الخطر T-26 قائم في V1 ومقبول للتجربة فقط'); assert.ok(!('issuer' in r.prep) && !('signature' in r.prep));
});
T('[D2-K05] قنبلة الضغط/طول مخادع: أكبر من 200KB أو طول معلن لا يطابق الواقع ⇒ رفض', function () {
  var zlib = require('zlib'), big = zlib.deflateRawSync(Buffer.alloc(5 * 1024 * 1024, 97)), head, all, crc = 0, i;
  function mk(len, body) { var h = [1, (len >>> 16) & 255, (len >>> 8) & 255, len & 255, (crc >>> 24) & 255, (crc >>> 16) & 255, (crc >>> 8) & 255, crc & 255], a = new Uint8Array(8 + body.length); for (i = 0; i < 8; i++) a[i] = h[i]; a.set(body, 8); return 'MARSA1-' + S.b64encode(a); }
  assert.strictEqual(S.decode(mk(5 * 1024 * 1024 & 0xFFFFFF, big)).ok, false, 'طول معلن كبير');
  assert.strictEqual(S.decode(mk(100, big)).ok, false, 'طول معلن صغير والفعلي ضخم');
  assert.strictEqual(S.decode(forge(good({ c: 'ا'.repeat(250000) }))).ok, false, 'خام أكبر من الحد');
});
T('[D2-K06] محتوى HTML/سكربت في الحقول لا يُنفَّذ: يُقبل نصاً حرفياً (يُعرض بـtextContent) أو يُرفض برسالة عربية', function () {
  var evil = '<img src=x onerror="window.__pwn=1"><script>window.__pwn=2<\/script>', r = S.decode(forge(good({ c: evil, t: 'عنوان <b>x</b>' })));
  if (r.ok) { assert.strictEqual(r.prep.content, evil, 'النص كما هو حرفياً (لا تفسير)'); assert.strictEqual(r.prep.title, 'عنوان <b>x</b>'); }
  else assert.ok(/[\u0600-\u06FF]/.test(r.message), 'رفض برسالة عربية');
  assert.strictEqual(typeof globalThis.__pwn, 'undefined');
});
T('[D2-K07] الروابط: http/https فقط تُنقر؛ javascript:/data:/file:/vbscript: نص غير قابل للنقر (توصيفي T-29: روابط https التصيّدية تبقى قابلة للنقر)', function () {
  ['javascript:alert(1)', 'data:text/html,<b>x', 'file:///etc/passwd', 'vbscript:x', 'JaVaScRiPt:alert(1)'].forEach(function (u) { SAFE.segments('انظر ' + u + ' الآن').forEach(function (seg) { assert.ok(!seg.href, u); }); });
  var segs = SAFE.segments('زر https://phish.example/login الآن'); assert.ok(segs.some(function (s) { return s.href === 'https://phish.example/login'; }), 'توصيفي: الرابط قابل للنقر');
});

// ===== D2-R: اتساق الوثائق =====
var D = {}; ['02.02-THREAT-MODEL.md', '02.02-PERMISSIONS.md', '02.02-ABUSE-AND-TESTS.md', '02.02-DECISIONS-AND-ASSUMPTIONS.md', '02.02-REPORT.md'].forEach(function (x) { var p = path.join(ROOT, 'docs', 'stage2', x); D[x] = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : ''; });
T('[D2-R01] الوثائق الخمس موجودة وغير فارغة', function () { Object.keys(D).forEach(function (x) { assert.ok(D[x].length > 1500, x); }); });
T('[D2-R02] كل معرّف اختبار D2-/E2- مذكور في وثيقة الإساءة موجود فعلاً في ملفات الاختبار', function () {
  var src = read('tests/security/stage2-deny.test.js') + read('tests/security/e2e-v1-boundaries.playwright.js'), ids = D['02.02-ABUSE-AND-TESTS.md'].match(/\b[DE]2-[A-Z]?\d{2}b?\b/g) || [];
  assert.ok(ids.length >= 20); ids.forEach(function (id) { assert.ok(src.indexOf('[' + id + ']') >= 0, 'معرّف بلا اختبار: ' + id); });
});
T('[D2-R03] كل معرّف تهديد T-xx في الإساءة معرَّف في نموذج التهديدات', function () {
  var tm = D['02.02-THREAT-MODEL.md'], ids = D['02.02-ABUSE-AND-TESTS.md'].match(/\bT-\d{2}\b/g) || []; assert.ok(ids.length >= 15);
  ids.forEach(function (t) { assert.ok(new RegExp('\\|\\s*' + t + '\\s*\\|').test(tm) || tm.indexOf('**' + t + '**') >= 0, t); });
});
T('[D2-R04] كل قرار معلّق في JSON موثّق في وثيقة القرارات، وتغطي الوثيقة: رؤية الطالب لبياناته الخاصة + القاصرون + هوية الممثل + مفتاح selfView', function () {
  var dd = D['02.02-DECISIONS-AND-ASSUMPTIONS.md']; MAT.pendingDecisions.forEach(function (id) { assert.ok(dd.indexOf(id) >= 0, id); });
  ['حضوره', 'درجاته', 'مدفوعات', 'قاصر', 'ولي', 'ممثل الصف', 'selfView'].forEach(function (w) { assert.ok(dd.indexOf(w) >= 0, w); });
});
T('[D2-R05] سجل الافتراضات المؤقتة: ≥ 12 بنداً لكل منها (القيمة الافتراضية، سبب الأمان، كيف يُعكس، اختبار يثبته)', function () {
  var dd = D['02.02-DECISIONS-AND-ASSUMPTIONS.md'], rows = dd.split('\n').filter(function (l) { return /^\|\s*A-\d{2}\s*\|/.test(l); });
  assert.ok(rows.length >= 12, rows.length); rows.forEach(function (l) { assert.ok(l.split('|').length >= 6, l.slice(0, 40)); assert.ok(/(D2|E2)-[A-Z]\d{2}|✋|⏳/.test(l), 'بلا إثبات: ' + l.slice(0, 40)); });
});
T('[D2-R06] لا أسرار/رموز حقيقية في وثائق 02.02 ولا مصفوفتها', function () {
  var pats = [/eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}/, /sb_secret_[A-Za-z0-9]{10,}/, /service_role\s*[:=]\s*['"]?ey/i, /AKIA[0-9A-Z]{16}/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /https:\/\/[a-z0-9]{15,}\.supabase\.co/i];
  Object.keys(D).forEach(function (x) { pats.forEach(function (p) { assert.ok(!p.test(D[x]), x + ' ' + p); }); }); pats.forEach(function (p) { assert.ok(!p.test(JSON.stringify(MAT))); });
  assert.ok(pats[0].test('eyJhbGciOiJIUzI1NiJ9AAAAAAAAAAAA.BBBBBBBBBBBB'), 'الفاحص يلتقط عيّنة مصطنعة');
});

tasks.reduce(function (p, t) { return p.then(t); }, Promise.resolve()).then(function () { console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0); });
