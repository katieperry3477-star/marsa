// 5.04 — مرجع قرار الصلاحيات (oracle) وقواعد رمز الدعوة وتدقيق الأحداث. مواصفة قابلة للتنفيذ، لا كود تطبيق.
// لا يُحمَّل من index.html ولا يُغيّر سلوك التطبيق. سيُعاد تشغيل حالاته لاحقاً على سياسات RLS الحقيقية.
// تشغيل الاختبارات: node tests/security/security-matrix.test.js
'use strict';
var crypto = require('crypto');

var ACTIONS = ['C', 'R', 'U', 'D'];
var SENSITIVE_PERSONAL = ['attendance', 'grades', 'payments'];

// can(actor, action, resource, matrix, policy) → { allow, reason, mode? }   (الفشل المغلق: أي نقص ⇒ رفض)
// actor: { role, status, classId, studentId };  resource: { type, classId, studentId }
function can(actor, action, resource, matrix, policy) {
  var deny = function (r) { return { allow: false, reason: r }; };
  if (!actor || typeof actor !== 'object' || !resource || typeof resource !== 'object') return deny('malformed');
  if (ACTIONS.indexOf(action) < 0) return deny('unknown-action');
  if (matrix.roles.indexOf(actor.role) < 0) return deny('unknown-role');
  var res = matrix.resources[resource.type];
  if (!res || !Object.prototype.hasOwnProperty.call(matrix.resources, resource.type)) return deny('unknown-resource');
  if (actor.role === 'anonymous') return deny('no-membership');
  if (actor.status !== 'active') return deny('inactive-actor');
  var p = res.perms[actor.role];
  if (!p || p.actions.indexOf(action) < 0) return deny('action-not-granted');
  var sc = p.scope;
  if (sc === 'none') return deny('scope-none');
  if (sc === 'any') {
    if (actor.role !== 'developer') return deny('any-scope-non-developer');
    return grant(res, action);
  }
  if (!isId(actor.classId) || !isId(resource.classId) || actor.classId !== resource.classId) return deny('cross-class');
  if (sc === 'class') return grant(res, action);
  if (!isId(actor.studentId) || !isId(resource.studentId) || actor.studentId !== resource.studentId) return deny('not-self');
  if (sc === 'self') return grant(res, action);
  if (sc === 'selfIfConsented') {
    if (action !== 'R') return deny('selfview-read-only');
    var sv = policy && policy[resource.type];
    if (!sv || sv.enabled !== true) return deny('selfview-disabled');
    if (typeof sv.consentRef !== 'string' || sv.consentRef.trim().length < 3) return deny('selfview-no-consent');
    return grant(res, action);
  }
  return deny('unknown-scope');
}
function grant(res, action) { return action === 'D' ? { allow: true, reason: 'ok', mode: res.deleteMode } : { allow: true, reason: 'ok' }; }
function isId(x) { return typeof x === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(x); }

// canIssueInvite(actor, {role, classId}, matrix) — من يُصدر رمزاً لأي دور/صف
function canIssueInvite(actor, target, matrix) {
  if (!actor || !target || matrix.roles.indexOf(actor.role) < 0 || actor.status !== 'active') return false;
  var rule = matrix.issueRules[actor.role];
  if (!rule || rule.issuesRoles.indexOf(target.role) < 0) return false;
  if (rule.classScope === 'any') return isId(target.classId);
  if (rule.classScope === 'own') return isId(actor.classId) && actor.classId === target.classId;
  return false;
}

// ===== مرجع استرداد رمز الدعوة (نموذج خالص؛ الخادم الحقيقي يجب أن يطابق سلوكه) =====
var INVITE_ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ'; // نفس أبجدية الكود الحالي (31 رمزاً)
var INVITE_LEN = 10, MAX_ATTEMPTS = 5, UNIFORM_FAIL = 'الرمز غير صالح.';
function entropyBits(alphabetSize, len) { return len * Math.log2(alphabetSize); }
function hashCode(c) { return crypto.createHash('sha256').update(String(c).toUpperCase().trim()).digest('hex'); }
function generateInvite(rng) {
  var out = '', b, bytes = (rng || crypto.randomBytes)(64), i;
  for (i = 0; i < bytes.length && out.length < INVITE_LEN; i++) if (bytes[i] < 248) out += INVITE_ALPHABET.charAt(bytes[i] % 31);
  if (out.length < INVITE_LEN) throw new Error('rng');
  return out;
}
// store: { codes: { [hash]: {role, classId, studentId, expiresAt, redeemedBy, revoked} }, attempts: { [userId]: n }, members: [] }
function redeemInvite(store, userId, input, nowMs) {
  var fail = { ok: false, message: UNIFORM_FAIL };
  if (typeof userId !== 'string' || !userId) return fail;
  store.attempts[userId] = store.attempts[userId] || 0;
  if (store.attempts[userId] >= MAX_ATTEMPTS) return fail; // حظر مؤقت: نفس الرسالة
  var norm = String(input == null ? '' : input).replace(/[​-‏‪-‮⁦-⁩﻿]/g, '').trim().toUpperCase();
  var rec = /^[2-9A-HJKMNP-Z]{10}$/.test(norm) ? store.codes[hashCode(norm)] : null;
  if (!rec || rec.revoked || rec.redeemedBy || rec.expiresAt <= nowMs) { store.attempts[userId]++; return fail; }
  rec.redeemedBy = userId;
  store.members.push({ userId: userId, role: rec.role, classId: rec.classId, studentId: rec.studentId || null, status: 'active' });
  return { ok: true, role: rec.role, classId: rec.classId };
}

// ===== تدقيق الأحداث =====
function validateAuditEvent(evt, spec) {
  var errs = [], k;
  if (!evt || typeof evt !== 'object') return ['not-object'];
  spec.requiredFields.forEach(function (f) { if (evt[f] === undefined || evt[f] === null || evt[f] === '') errs.push('missing:' + f); });
  if (!spec.events[evt.eventType]) errs.push('unknown-eventType');
  else if (spec.events[evt.eventType].actors.indexOf(evt.actorRole) < 0) errs.push('actor-not-allowed');
  if (spec.outcomes.indexOf(evt.outcome) < 0) errs.push('bad-outcome');
  var allowed = spec.requiredFields.concat(spec.optionalFields);
  for (k in evt) if (Object.prototype.hasOwnProperty.call(evt, k)) {
    if (spec.forbiddenFields.indexOf(k) >= 0) errs.push('forbidden:' + k);
    else if (allowed.indexOf(k) < 0) errs.push('unexpected:' + k);
  }
  if (typeof evt.occurredAt === 'string' && isNaN(Date.parse(evt.occurredAt))) errs.push('bad-time');
  return errs;
}

// ===== ثوابت السرية CONF — تُفحص على أي مصفوفة؛ تُرجع قائمة مخالفات =====
function checkInvariants(matrix, policyOff) {
  var v = [], R = matrix.resources, types = Object.keys(R), A = 'CRUD', ctxs, role, t, a, act, res, out;
  var off = policyOff || { attendance: { enabled: false, consentRef: null }, grades: { enabled: false, consentRef: null }, payments: { enabled: false, consentRef: null } };
  var full = { attendance: { enabled: true, consentRef: 'doc-1' }, grades: { enabled: true, consentRef: 'doc-1' }, payments: { enabled: true, consentRef: 'doc-1' } };
  var me = { role: 'student', status: 'active', classId: 'c1', studentId: 's1' };
  var rep = { role: 'rep', status: 'active', classId: 'c1' };
  var dev = { role: 'developer', status: 'active' };
  function chk(id, cond, msg) { if (!cond) v.push(id + ': ' + msg); }
  types.forEach(function (t) {
    ACTIONS.forEach(function (a) {
      // CONF-05 المجهول
      chk('CONF-05', !can({ role: 'anonymous', status: 'active', classId: 'c1' }, a, { type: t, classId: 'c1', studentId: 's1' }, matrix, full).allow, 'anonymous ' + a + ' ' + t);
      // CONF-03 الطالب لا يكتب أي شيء
      if (a !== 'R') chk('CONF-03', !can(me, a, { type: t, classId: 'c1', studentId: 's1' }, matrix, full).allow, 'student ' + a + ' ' + t);
      // CONF-04 لا عبور صفوف لغير المطور
      chk('CONF-04', !can(me, a, { type: t, classId: 'c2', studentId: 's1' }, matrix, full).allow, 'student cross-class ' + a + ' ' + t);
      chk('CONF-04', !can(rep, a, { type: t, classId: 'c2', studentId: 's1' }, matrix, full).allow, 'rep cross-class ' + a + ' ' + t);
      // CONF-08 غير الفعّال
      ['archived', 'suspended', 'revoked', undefined, null, ''].forEach(function (st) {
        [me, rep, dev].forEach(function (u) { var x = Object.assign({}, u, { status: st }); chk('CONF-08', !can(x, a, { type: t, classId: 'c1', studentId: 's1' }, matrix, full).allow, 'inactive(' + st + ') ' + u.role + ' ' + a + ' ' + t); });
      });
      // CONF-06 سجل التدقيق: لا U/D؛ الهاش لا يُقرأ؛ لا C من عميل
      if (t === 'audit_log' && a !== 'R') [me, rep, dev].forEach(function (u) { chk('CONF-06', !can(u, a, { type: t, classId: 'c1' }, matrix, full).allow, 'audit ' + u.role + ' ' + a); });
      // CONF-07 لا إنشاء عضوية من عميل
      if (t === 'membership' && a === 'C') [me, rep, dev].forEach(function (u) { chk('CONF-07', !can(u, a, { type: t, classId: 'c1' }, matrix, full).allow, 'membership C ' + u.role); });
      // CONF-09 فشل مغلق: نوع/إجراء مجهول
    });
    SENSITIVE_PERSONAL.forEach(function (st) {
      if (t !== st) return;
      // CONF-02 زميل
      ['R', 'C', 'U', 'D'].forEach(function (a2) {
        chk('CONF-02', !can(me, a2, { type: t, classId: 'c1', studentId: 's2' }, matrix, full).allow, 'peer ' + a2 + ' ' + t + ' (selfView on)');
        chk('CONF-02', !can(me, a2, { type: t, classId: 'c1', studentId: 's2' }, matrix, off).allow, 'peer ' + a2 + ' ' + t + ' (selfView off)');
      });
      // CONF-01 الافتراضي رفض (حتى لسجله)
      chk('CONF-01', !can(me, 'R', { type: t, classId: 'c1', studentId: 's1' }, matrix, off).allow, 'student own ' + t + ' allowed while selfView off');
      // CONF-14 بلا consentRef رفض؛ ومعه قراءة ذاتية فقط
      [null, undefined, '', '  ', 5, {}].forEach(function (cr) { chk('CONF-14', !can(me, 'R', { type: t, classId: 'c1', studentId: 's1' }, matrix, Object.assign({}, off, (function () { var o = {}; o[t] = { enabled: true, consentRef: cr }; return o; })())).allow, 'selfView without valid consent (' + String(cr) + ') ' + t); });
      chk('CONF-14', !can(me, 'R', { type: t, classId: 'c1', studentId: 's1' }, matrix, Object.assign({}, off, (function () { var o = {}; o[t] = { enabled: 'true', consentRef: 'doc-1' }; return o; })())).allow, 'selfView enabled must be boolean true ' + t);
      // CONF-10 المطور لا CRUD مباشر
      ACTIONS.forEach(function (a3) { chk('CONF-10', !can(dev, a3, { type: t, classId: 'c1', studentId: 's1' }, matrix, full).allow, 'developer direct ' + a3 + ' ' + t); });
      // CONF-13 حذف ناعم
      chk('CONF-13', R[t].deleteMode === 'soft', t + ' deleteMode=' + R[t].deleteMode);
    });
  });
  // CONF-11 التقارير: الطالب ✗
  ['C', 'R', 'U', 'D'].forEach(function (a) { chk('CONF-11', !can(me, a, { type: 'reports', classId: 'c1', studentId: 's1' }, matrix, full).allow, 'student reports ' + a); });
  // CONF-12 الطالب لا يقرأ قائمة الصف: سطره فقط
  chk('CONF-12', can(me, 'R', { type: 'roster', classId: 'c1', studentId: 's1' }, matrix, off).allow, 'student cannot read own roster row');
  chk('CONF-12', !can(me, 'R', { type: 'roster', classId: 'c1', studentId: 's2' }, matrix, full).allow, 'student can read peer roster row');
  chk('CONF-12', !can(me, 'R', { type: 'roster', classId: 'c1' }, matrix, full).allow, 'student can list roster (no studentId)');
  // CONF-13 الطلاب أرشفة لا حذف صلب
  chk('CONF-13', R.roster.deleteMode === 'archive', 'roster deleteMode=' + R.roster.deleteMode);
  // CONF-15 قواعد الإصدار
  chk('CONF-15', !canIssueInvite(me, { role: 'student', classId: 'c1' }, matrix), 'student can issue');
  chk('CONF-15', !canIssueInvite(rep, { role: 'rep', classId: 'c1' }, matrix), 'rep issues rep');
  chk('CONF-15', !canIssueInvite(rep, { role: 'developer', classId: 'c1' }, matrix), 'rep issues developer');
  chk('CONF-15', !canIssueInvite(rep, { role: 'student', classId: 'c2' }, matrix), 'rep issues for other class');
  chk('CONF-15', !canIssueInvite(dev, { role: 'developer', classId: 'c1' }, matrix), 'app issues developer');
  chk('CONF-15', !canIssueInvite({ role: 'anonymous', status: 'active' }, { role: 'student', classId: 'c1' }, matrix), 'anonymous issues');
  chk('CONF-15', canIssueInvite(rep, { role: 'student', classId: 'c1' }, matrix), 'rep cannot issue student code for own class (functional)');
  // CONF-16 القارئ لا يرى الهاش ولا النص الصريح: invite_code لا يمنح R لغير المصدرين، ولا لطالب
  chk('CONF-16', !can(me, 'R', { type: 'invite_code', classId: 'c1' }, matrix, full).allow, 'student reads invite_code');
  // CONF-09 فشل مغلق
  chk('CONF-09', !can(me, 'R', { type: '__nope__', classId: 'c1' }, matrix, full).allow, 'unknown resource allowed');
  chk('CONF-09', !can(me, 'X', { type: 'dailyLessons', classId: 'c1' }, matrix, full).allow, 'unknown action allowed');
  chk('CONF-09', !can({ role: 'root', status: 'active' }, 'R', { type: 'dailyLessons', classId: 'c1' }, matrix, full).allow, 'unknown role allowed');
  chk('CONF-09', !can(me, 'R', { type: 'dailyLessons' }, matrix, full).allow, 'missing resource classId allowed');
  chk('CONF-09', !can({ role: 'student', status: 'active', studentId: 's1' }, 'R', { type: 'dailyLessons', classId: 'c1' }, matrix, full).allow, 'missing actor classId allowed');
  chk('CONF-09', !can(me, 'R', { type: 'constructor', classId: 'c1' }, matrix, full).allow, 'prototype key allowed');
  chk('CONF-09', !can(null, 'R', { type: 'dailyLessons', classId: 'c1' }, matrix, full).allow, 'null actor allowed');
  return v;
}

// تحقق مخطط المصفوفة (طبقة دفاع ثانية: يلتقط ما يتجاوزه سلوك can() الدفاعي، مثل منح مجهول صلاحية في الملف)
function validateSchema(m) {
  var errs = [];
  Object.keys(m.resources).forEach(function (t) {
    var r = m.resources[t];
    m.roles.forEach(function (role) {
      var p = r.perms[role];
      if (!p) { errs.push(t + ':' + role + ' missing'); return; }
      if (!/^[CRUD]*$/.test(p.actions)) errs.push(t + ':' + role + ' bad actions');
      if (!(p.scope in m.scopes)) errs.push(t + ':' + role + ' bad scope');
      if (p.actions && p.scope === 'none') errs.push(t + ':' + role + ' actions with scope none');
      if (!p.actions && p.scope !== 'none') errs.push(t + ':' + role + ' scope without actions');
      if (p.scope === 'any' && role !== 'developer') errs.push(t + ':' + role + ' any-scope for non-developer');
      if (p.scope === 'selfIfConsented' && p.actions.replace('R', '') !== '') errs.push(t + ':' + role + ' selfIfConsented must be read-only');
      if (role === 'anonymous' && (p.actions !== '' || p.scope !== 'none')) errs.push(t + ':anonymous must have no permissions (CONF-05)');
    });
    if (['soft', 'archive', 'none'].indexOf(r.deleteMode) < 0) errs.push(t + ' bad deleteMode');
    if (r.deleteMode === 'none' && ['dailyLessons', 'attendance', 'grades', 'payments'].indexOf(t) >= 0) errs.push(t + ' must be soft');
  });
  return errs;
}

module.exports = { validateSchema: validateSchema, can: can, canIssueInvite: canIssueInvite, checkInvariants: checkInvariants, validateAuditEvent: validateAuditEvent, redeemInvite: redeemInvite, generateInvite: generateInvite, hashCode: hashCode, entropyBits: entropyBits, INVITE_ALPHABET: INVITE_ALPHABET, INVITE_LEN: INVITE_LEN, MAX_ATTEMPTS: MAX_ATTEMPTS, UNIFORM_FAIL: UNIFORM_FAIL, ACTIONS: ACTIONS };
