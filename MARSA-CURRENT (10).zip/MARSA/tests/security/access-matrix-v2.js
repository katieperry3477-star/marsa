// 01.01 — مصفوفة الأدوار والأمان V2: المصدر الوحيد لبيانات المصفوفة + مرجع القرار (oracle) + المدقّق + المولِّدات.
// مواصفة قابلة للتنفيذ، لا كود تطبيق. لا يُحمَّل من index.html. سيُعاد تشغيل حالاتها على سياسات RLS الحقيقية في 03.03/09.02.
// التشغيل: node tests/security/access-matrix-v2.test.js    ·    التوليد: node tests/security/generate-access-v2.js [--check]
'use strict';
var crypto = require('crypto');

var ROLES = ['developer', 'rep', 'student'];
var OPS = ['R', 'C', 'U', 'A'];            // قراءة · إضافة · تعديل · أرشفة/استعادة (حذف منطقي). لا حذف صلب لأي دور.
var N = 'none';
var SELF_STATE = ['notification_reads', 'push_subscriptions']; // الكيانان الوحيدان اللذان يكتب فيهما الطالب (حالة ذاتية)

function c(R, C, U, A) { return { R: R, C: C, U: U, A: A }; }
var CONTENT_DEV = c('any', 'any', 'any', 'any'), CONTENT_REP = c('class', 'class', 'class', 'class'), CONTENT_STU = c('class', N, N, N);
var WR_DEV = c('any', 'any@rpc', 'any@rpc', 'any@rpc'), WR_REP = c('class', 'class@rpc', 'class@rpc', 'class@rpc');
var NONE = c(N, N, N, N);

function E(id, ar, cls, path, perms, extra) {
  var e = { id: id, ar: ar, cls: cls, path: path, perms: perms, studentFilter: null, targets: null, audited: false, version: false, note: '' };
  Object.keys(extra || {}).forEach(function (k) { e[k] = extra[k]; });
  return e;
}

var ENTITIES = [
  E('classes', 'الشعبة', 'C0', 'rls', { developer: c('any', N, 'any@rpc', N), rep: c('class', N, N, N), student: c('class', N, N, N) }, { audited: true, note: 'شعبة واحدة تُبذر بالـmigration؛ الإنشاء/الأرشفة غير منفّذين في الإصدار الأول (قابلية توسع فقط).' }),
  E('members', 'العضويات (الدور والحالة)', 'C4', 'rpc',
    { developer: c('any', 'any@edge', 'any@edge', 'any@edge'), rep: c('class', 'class@edge', 'class@edge', 'class@edge'), student: c('self', N, N, N) },
    { targets: { developer: { C: ['rep', 'student'], U: ['rep', 'student'], A: ['rep', 'student'] }, rep: { R: ['student', 'rep'], C: ['student'], U: ['student'], A: ['student'] } }, audited: true,
      note: 'لا كتابة مباشرة. الدور غير قابل للتعديل بأي مسار؛ تغيير الدور = عضوية جديدة. الممثل لا يرى صف المطوّر ولا يدير ممثلاً.' }),
  E('students', 'ملف الطالب (اسم، هاتف، ميلاد، غياب سابق)', 'C1', 'rls', { developer: WR_DEV, rep: WR_REP, student: c('self', N, N, N) }, { audited: true, version: true, note: 'الطالب يقرأ سطره فقط ولا يعدّله (لا منح كتابة). الاستيراد الجماعي RPC بحد دفعة.' }),
  E('activation_codes', 'رموز التفعيل (بصمات HMAC)', 'C4', 'edge',
    { developer: c('any@rpc', 'any@edge', N, 'any@edge'), rep: c('class@rpc', 'class@edge', N, 'class@edge'), student: NONE },
    { targets: { developer: { R: ['rep', 'student'], C: ['rep', 'student'], A: ['rep', 'student'] }, rep: { R: ['student'], C: ['student'], A: ['student'] } }, audited: true,
      note: 'لا منح على الجدول لأي دور. القراءة = بيانات وصفية فقط (الحالة، الانتهاء، المُصدِر) عبر RPC؛ لا بصمة ولا رمز. لا تعديل: الاستهلاك للخادم وحده.' }),
  E('activation_attempts', 'محاولات التفعيل وحدود المعدل', 'SYS', 'system', { developer: NONE, rep: NONE, student: NONE }, { note: 'للخادم/`service_role` فقط؛ عناوين مُجزَّأة بملح يومي.' }),
  E('attendance_sheets', 'كشوف الحضور اليومية (الاعتماد)', 'C2', 'rls', { developer: WR_DEV, rep: WR_REP, student: NONE }, { audited: true, version: true, note: 'الاعتماد وتعديل كشف سابق عبر RPC ذري مع تدقيق. الطالب لا يرى رأس الكشف.' }),
  E('attendance_records', 'سجلات الحضور والغياب', 'C2', 'rls', { developer: WR_DEV, rep: WR_REP, student: c('self', N, N, N) }, { studentFilter: 'approved', audited: true, version: true, note: 'الطالب يرى سجله هو من كشوف معتمدة فقط، لا مسودات.' }),
  E('grades', 'الدرجات', 'C2', 'rls', { developer: WR_DEV, rep: WR_REP, student: c('self', N, N, N) }, { studentFilter: 'live', audited: true, version: true }),
  E('exams', 'الامتحانات', 'C0', 'rls', { developer: CONTENT_DEV, rep: CONTENT_REP, student: CONTENT_STU }, { studentFilter: 'live', version: true }),
  E('schedule_entries', 'الجدول الدراسي', 'C0', 'rls', { developer: CONTENT_DEV, rep: CONTENT_REP, student: CONTENT_STU }, { studentFilter: 'live', version: true }),
  E('preps', 'التحاضير', 'C0', 'rls', { developer: CONTENT_DEV, rep: CONTENT_REP, student: CONTENT_STU }, { studentFilter: 'live' }),
  E('prep_status', 'حالة التحضير (تم/لم يتم/تأجل)', 'C0', 'rls', { developer: CONTENT_DEV, rep: CONTENT_REP, student: CONTENT_STU }, { studentFilter: 'live' }),
  E('homework', 'الواجبات', 'C0', 'rls', { developer: CONTENT_DEV, rep: CONTENT_REP, student: CONTENT_STU }, { studentFilter: 'live' }),
  E('announcements', 'الإعلانات', 'C0', 'rls', { developer: CONTENT_DEV, rep: CONTENT_REP, student: CONTENT_STU }, { studentFilter: 'live', note: 'التثبيت = تعديل. النشر يولّد إشعاراً بمشغّل خادمي لا بكتابة العميل.' }),
  E('file_objects', 'سجلات المرفقات (بيانات وصفية)', 'C0', 'rls', { developer: c('any', 'any@rpc', 'any@rpc', 'any@rpc'), rep: c('class', 'class@rpc', 'class@rpc', 'class@rpc'), student: CONTENT_STU }, { studentFilter: 'parent', audited: true, note: 'الإضافة عبر RPC لفحص الحصة والنوع. الطالب يرى مرفقاً فقط إن كان الأصل (تحضير/واجب/امتحان) مقروءاً له.' }),
  E('storage_objects', 'ملفات التخزين (bucket خاص)', 'C0', 'storage', { developer: c('any@rpc', 'any@rpc', N, N), rep: c('class@rpc', 'class@rpc', N, N), student: c('class@rpc', N, N, N) }, { studentFilter: 'parent', note: 'روابط موقّعة قصيرة العمر فقط؛ لا listing. لا تعديل (الاستبدال = كائن جديد). الإزالة الفعلية صيانة خادمية لا دور تطبيقي.' }),
  E('cost_items', 'بنود التكاليف', 'C3', 'rls', { developer: WR_DEV, rep: WR_REP, student: c('self', N, N, N) }, { studentFilter: 'assigned', audited: true, version: true, note: 'الطالب يرى فقط البنود المسندة إليه.' }),
  E('cost_assignments', 'إسناد البنود للطلاب وحالتها', 'C3', 'rls', { developer: WR_DEV, rep: WR_REP, student: c('self', N, N, N) }, { studentFilter: 'live', audited: true, version: true }),
  E('payments', 'سجل الدفعات', 'C3', 'rls', { developer: c('any', 'any@rpc', N, 'any@rpc'), rep: c('class', 'class@rpc', N, 'class@rpc'), student: c('self', N, N, N) }, { studentFilter: 'live', audited: true, version: true, note: 'سجل للإلحاق فقط: لا تعديل. التصحيح = إبطال (أرشفة بسبب) + دفعة جديدة. (E-009)' }),
  E('cost_stats', 'إحصاءات التكاليف المجمّعة (view)', 'C3', 'view', { developer: c('any', N, N, N), rep: c('class', N, N, N), student: NONE }, { note: '`security_invoker`. الطالب لا يقرأ أي تجميع (يكشف أعداد زملائه).' }),
  E('notifications', 'الإشعارات', 'C0', 'rls', { developer: c('any', N, N, N), rep: c('class', N, N, N), student: c('class', N, N, N) }, { studentFilter: 'audience', note: 'يُنشئها مشغّل/RPC خادمي فقط؛ لا دور يكتبها. حمولة Push بلا بيانات شخصية.' }),
  E('notification_reads', 'حالة قراءة الإشعار (ذاتية)', 'SELF', 'rls', { developer: c('self', 'self', 'self', N), rep: c('self', 'self', 'self', N), student: c('self', 'self', 'self', N) }, { note: 'استثناء مقصود: الطالب يكتب حالة قراءته هو فقط.' }),
  E('push_subscriptions', 'اشتراكات Push (ذاتية)', 'SELF', 'rls', { developer: c('self', 'self', 'self', 'self'), rep: c('self', 'self', 'self', 'self'), student: c('self', 'self', 'self', 'self') }, { note: 'لا دور يقرأ اشتراك غيره (حتى المطوّر)؛ `send-push` وحدها تقرأها بمفتاح الخدمة.' }),
  E('support_sessions', 'جلسات وضع الدعم', 'C4', 'rpc', { developer: c('self', 'self@rpc', 'self@rpc', N), rep: NONE, student: NONE }, { audited: true, note: 'ADR-308: عرض بصفة؛ لا توكن بالنيابة. لا يُعرض للمستهدف (E-011).' }),
  E('audit_log', 'سجل التدقيق', 'C4', 'rls', { developer: c('any', N, N, N), rep: NONE, student: NONE }, { note: 'للإلحاق فقط بمشغّلات/RPC خادمية؛ لا INSERT/UPDATE/DELETE لأي دور حتى المطوّر.' }),
  E('record_history', 'سجل تعديلات السجلات الأكاديمية (view)', 'C2', 'view', { developer: c('any', N, N, N), rep: c('class', N, N, N), student: NONE }, { note: 'يلبّي «سجل تعديل ومن قام به» (المواصفة §5) دون فتح `audit_log` للممثل: حضور/درجات فقط.' }),
  E('app_meta', 'إصدار المخطط والحد الأدنى للعميل', 'SYS', 'rls', { developer: c('auth', N, N, N), rep: c('auth', N, N, N), student: c('auth', N, N, N) }, { note: 'قراءة لكل عضو نشط؛ الكتابة بالـmigrations فقط.' }),
  E('class_settings', 'إعدادات الشعبة (قاعدة المعدل، تسميات)', 'C0', 'rls', { developer: c('any', N, 'any@rpc', N), rep: c('class', N, 'class@rpc', N), student: c('class', N, N, N) }, { audited: true, version: true }),
  E('system_settings', 'إعدادات النظام (حصص، نسخ)', 'C4', 'rls', { developer: c('any', N, 'any@rpc', N), rep: NONE, student: NONE }, { audited: true }),
  E('storage_usage', 'لقطة استخدام التخزين والحصص', 'SYS', 'rpc', { developer: c('any@rpc', N, N, N), rep: c('class@rpc', N, N, N), student: NONE }),
  E('roster_export', 'تصدير قائمة الطلاب (CSV)', 'C1', 'rpc', { developer: c(N, 'any@rpc', N, N), rep: c(N, 'class@rpc', N, N), student: NONE }, { audited: true, note: '«C» = تنفيذ التصدير. كل تصدير يُدقَّق (T-63).' }),
  E('backup_export', 'نسخة احتياطية كاملة', 'C4', 'rpc', { developer: c(N, 'any@rpc', N, N), rep: NONE, student: NONE }, { audited: true }),
  E('backup_restore', 'استعادة نسخة', 'SYS', 'system', { developer: NONE, rep: NONE, student: NONE }, { note: 'لا يملكها أي دور تطبيقي: سكربت محلي بمفتاح خدمة إلى مشروع منفصل (ADR-315).' })
];

// قواعد إدارة العضويات (من يستطيع ماذا على أي دور) — يُنفَّذ في Edge `issue-code`/`set-member-status` وRPC.
var ADMIN_ACTIONS = ['issue_code', 'revoke_code', 'suspend', 'reactivate', 'archive_member', 'open_support', 'change_role', 'create_developer'];
var ADMIN_RULES = {
  developer: { issue_code: ['rep', 'student'], revoke_code: ['rep', 'student'], suspend: ['rep', 'student'], reactivate: ['rep', 'student'], archive_member: ['rep', 'student'], open_support: ['rep', 'student'], change_role: [], create_developer: [] },
  rep: { issue_code: ['student'], revoke_code: ['student'], suspend: ['student'], reactivate: ['student'], archive_member: ['student'], open_support: [], change_role: [], create_developer: [] },
  student: { issue_code: [], revoke_code: [], suspend: [], reactivate: [], archive_member: [], open_support: [], change_role: [], create_developer: [] }
};

var REQUIRED_ENTITIES = ['classes', 'members', 'students', 'activation_codes', 'activation_attempts', 'attendance_sheets', 'attendance_records', 'grades', 'exams', 'schedule_entries', 'preps', 'prep_status', 'homework', 'file_objects', 'storage_objects', 'cost_items', 'cost_assignments', 'payments', 'cost_stats', 'announcements', 'notifications', 'notification_reads', 'push_subscriptions', 'support_sessions', 'audit_log', 'record_history', 'app_meta', 'class_settings', 'system_settings', 'storage_usage', 'roster_export', 'backup_export', 'backup_restore'];
var M = { version: 2, roles: ROLES, ops: OPS, selfState: SELF_STATE, entities: ENTITIES, adminActions: ADMIN_ACTIONS, adminRules: ADMIN_RULES, anonGrants: [], directDeleteGrants: false };

// ---------- تحليل خلية ----------
var CELL_RE = /^(none|any|class|self|auth)(@(rls|rpc|edge))?$/;
function parseCell(s) { var m = CELL_RE.exec(s); return m ? { scope: m[1], via: m[3] || null } : null; }
function entityById(m, id) { for (var i = 0; i < m.entities.length; i++) if (m.entities[i].id === id) return m.entities[i]; return null; }
function isId(x) { return typeof x === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(x); }
function viaOf(e, role, op) { var p = parseCell(e.perms[role][op]); return p.via || 'rls'; }

// ---------- مرجع القرار canV2 ----------
// actor: { role, status, classId, memberId, supportSessionOpen, supportConfirm }
// res:   { entity, classId, subjectId, targetRole, archived, approved, assigned, audienceMatch, parentReadable }
function canV2(actor, op, res, m) {
  m = m || M;
  var deny = function (r) { return { allow: false, reason: r }; };
  if (!actor || typeof actor !== 'object' || !res || typeof res !== 'object') return deny('malformed');
  if (OPS.indexOf(op) < 0) return deny('unknown-op');
  if (typeof res.entity !== 'string') return deny('malformed');
  var e = null; for (var i = 0; i < m.entities.length; i++) if (m.entities[i].id === res.entity) e = m.entities[i];
  if (!e) return deny('unknown-entity');
  if (actor.role === 'anonymous') return deny('no-membership');
  if (m.roles.indexOf(actor.role) < 0) return deny('unknown-role');
  if (actor.status !== 'active') return deny('inactive-actor');
  var raw = e.perms && e.perms[actor.role] && e.perms[actor.role][op];
  var cell = parseCell(raw || '');
  if (!cell) return deny('bad-cell');
  if (cell.scope === 'none') return deny('not-granted');
  var tg = e.targets && e.targets[actor.role] && e.targets[actor.role][op];
  if (tg && tg.indexOf(res.targetRole) < 0) return deny('target-role-forbidden');
  if (actor.role === 'developer' && op !== 'R' && actor.supportSessionOpen === true && actor.supportConfirm !== true) return deny('support-write-needs-confirm');
  var sc = cell.scope;
  if (sc === 'any') { if (actor.role !== 'developer') return deny('any-scope-non-developer'); }
  else if (sc === 'auth') { /* أي عضو نشط */ }
  else if (sc === 'class' || sc === 'self') {
    if (actor.role !== 'developer' || sc === 'class') { if (!isId(actor.classId) || !isId(res.classId) || actor.classId !== res.classId) return deny('cross-class'); }
    if (sc === 'self') { if (!isId(actor.memberId) || !isId(res.subjectId) || actor.memberId !== res.subjectId) return deny('not-self'); }
  } else return deny('unknown-scope');
  if (actor.role === 'student' && op === 'R' && e.studentFilter) {
    if (res.archived !== false) return deny('student-archived-or-unknown');
    if (e.studentFilter === 'approved' && res.approved !== true) return deny('student-unapproved');
    if (e.studentFilter === 'assigned' && res.assigned !== true) return deny('student-not-assigned');
    if (e.studentFilter === 'audience' && res.audienceMatch !== true) return deny('student-not-audience');
    if (e.studentFilter === 'parent' && res.parentReadable !== true) return deny('student-parent-unreadable');
  }
  return { allow: true, reason: 'ok', via: cell.via || 'rls' };
}

// canAdmin(actor, action, target) — target: { role, classId }
function canAdmin(actor, action, target, m) {
  m = m || M;
  if (!actor || !target || m.roles.indexOf(actor.role) < 0 || actor.status !== 'active') return false;
  if (m.adminActions.indexOf(action) < 0) return false;
  var allowed = m.adminRules[actor.role] && m.adminRules[actor.role][action];
  if (!allowed || allowed.indexOf(target.role) < 0) return false;
  if (actor.role === 'developer') return true;
  return isId(actor.classId) && isId(target.classId) && actor.classId === target.classId && !(actor.memberId && actor.memberId === target.memberId && target.role !== 'student');
}

// ---------- منح الجداول المشتقة (لفاحص 03.03) ----------
function deriveGrants(m) {
  m = m || M; var out = {};
  m.entities.forEach(function (e) {
    var g = { select: false, insert: false, update: false, delete: false };
    m.roles.forEach(function (r) { OPS.forEach(function (op) {
      var p = parseCell(e.perms[r][op]); if (!p || p.scope === 'none') return;
      if ((p.via || 'rls') !== 'rls') return;
      if (op === 'R') g.select = true; else if (op === 'C') g.insert = true; else g.update = true; // الأرشفة = UPDATE لـarchived_at
    }); });
    if (e.path === 'view' || e.path === 'storage' || e.path === 'system' || e.path === 'edge') { g.insert = false; g.update = false; }
    out[e.id] = g;
  });
  return out;
}

// ---------- المدقّق: يُعيد قائمة رموز انتهاك (فارغة = سليم) ----------
function validate(m) {
  var bad = [], push = function (x) { bad.push(x); };
  if (!m || !Array.isArray(m.entities)) return ['V0:no-entities'];
  if (JSON.stringify(m.roles) !== JSON.stringify(ROLES)) push('V1:roles');
  if (JSON.stringify(m.ops) !== JSON.stringify(OPS)) push('V1:ops');
  if (!Array.isArray(m.anonGrants) || m.anonGrants.length !== 0) push('V16:anon-grants');
  if (m.directDeleteGrants !== false) push('V16:delete-grants');
  var seen = {};
  REQUIRED_ENTITIES.forEach(function (id) { if (!entityById(m, id)) push('V2:missing-entity:' + id); });
  m.entities.forEach(function (e) {
    if (seen[e.id]) push('V1:dup:' + e.id); seen[e.id] = 1;
    if (!e.ar || !/^(C0|C1|C2|C3|C4|SELF|SYS)$/.test(e.cls) || !/^(rls|rpc|edge|view|storage|system)$/.test(e.path)) push('V1:meta:' + e.id);
    m.roles.forEach(function (r) {
      if (!e.perms || !e.perms[r]) { push('V1:role-missing:' + e.id + ':' + r); return; }
      OPS.forEach(function (op) {
        var p = parseCell(e.perms[r][op] || ''); if (!p) { push('V1:cell:' + e.id + ':' + r + ':' + op); return; }
        if (Object.keys(e.perms[r]).length !== 4) push('V1:extra-op:' + e.id + ':' + r);
        var s = p.scope;
        if (s === 'any' && r !== 'developer') push('V3:any-non-dev:' + e.id + ':' + r);
        if (s === 'none') return;
        // طالب
        if (r === 'student') {
          if (op !== 'R' && SELF_STATE.indexOf(e.id) < 0) push('V4:student-write:' + e.id + ':' + op);
          if (op === 'R' && ['C1', 'C2', 'C3', 'C4', 'SELF'].indexOf(e.cls) >= 0 && s !== 'self') push('V14:student-read-wide:' + e.id);
          if (op === 'R' && s === 'auth' && e.id !== 'app_meta') push('V14:student-auth-scope:' + e.id);
        }
        // ممثل
        if (r === 'rep') {
          if (s === 'any') push('V6:rep-any:' + e.id);
          if (e.cls === 'C4' && ['members', 'activation_codes', 'support_sessions'].indexOf(e.id) < 0) push('V6:rep-c4:' + e.id);
          if (e.id === 'support_sessions' || e.id === 'audit_log' || e.id === 'system_settings' || e.id === 'backup_export' || e.id === 'backup_restore') push('V6:rep-forbidden:' + e.id);
        }
        // كتابة الحساس لا تكون مباشرة
        if (op !== 'R' && ['C1', 'C2', 'C3', 'C4'].indexOf(e.cls) >= 0 && SELF_STATE.indexOf(e.id) < 0) {
          if ((p.via || 'rls') === 'rls' && ['students', 'attendance_sheets', 'attendance_records', 'grades', 'cost_items', 'cost_assignments', 'payments', 'system_settings'].indexOf(e.id) < 0) push('V11:direct-sensitive-write:' + e.id + ':' + r + ':' + op);
          if (!e.audited) push('V12:unaudited-write:' + e.id);
        }
        if (op !== 'R' && ['students', 'attendance_sheets', 'attendance_records', 'grades', 'cost_items', 'cost_assignments', 'payments'].indexOf(e.id) >= 0 && (p.via || 'rls') !== 'rpc') push('V11:direct-write:' + e.id + ':' + r + ':' + op);
        if (r !== 'developer' && s === 'self' && op === 'R' && e.id === 'push_subscriptions' && s !== 'self') push('V17:push');
      });
    });
    // C0: طالب يقرأ صف الشعبة فيلزم فلتر الأرشفة
    if (e.perms.student && e.perms.student.R !== N && e.cls === 'C0' && e.id !== 'classes' && e.id !== 'class_settings' && !e.studentFilter) push('V13:no-student-filter:' + e.id);
    if (['C1', 'C2', 'C3'].indexOf(e.cls) >= 0 && e.perms.student.R === 'self' && !e.studentFilter && ['students', 'cost_assignments'].indexOf(e.id) < 0 && e.id !== 'roster_export') push('V13:no-filter-sensitive:' + e.id);
  });
  var g = function (id) { return entityById(m, id); };
  // تدقيق
  var al = g('audit_log');
  if (!al) push('V7:no-audit-log'); else m.roles.forEach(function (r) { ['C', 'U', 'A'].forEach(function (op) { if (al.perms[r] && al.perms[r][op] !== N) push('V7:audit-write:' + r + ':' + op); }); if (r !== 'developer' && al.perms[r] && al.perms[r].R !== N) push('V7:audit-read:' + r); });
  // أعضاء ورموز
  ['members', 'activation_codes'].forEach(function (id) {
    var e = g(id); if (!e) { push('V9:missing:' + id); return; }
    ['C', 'U', 'A'].forEach(function (op) {
      var dt = e.targets && e.targets.developer && e.targets.developer[op]; if (dt && (dt.indexOf('developer') >= 0)) push('V8:dev-targets-developer:' + id + ':' + op);
      var rt = e.targets && e.targets.rep && e.targets.rep[op];
      if (e.perms.rep[op] !== N && (!rt || rt.length !== 1 || rt[0] !== 'student')) push('V9:rep-targets:' + id + ':' + op);
      if (e.perms.developer[op] !== N && !dt) push('V8:dev-targets-missing:' + id + ':' + op);
    });
    var rr = e.targets && e.targets.rep && e.targets.rep.R; if (id === 'members' && (!rr || rr.indexOf('developer') >= 0)) push('V9:rep-reads-dev');
    if (id === 'activation_codes') { m.roles.forEach(function (r) { if (e.perms[r].U !== N) push('V9:code-update:' + r); }); if (e.perms.student.R !== N) push('V4:student-codes'); }
    if (id === 'members' && ['developer', 'rep', 'student'].some(function (r) { return e.perms[r].C !== N && r === 'student'; })) push('V9:student-creates-member');
  });
  // دفعات
  var pay = g('payments'); if (pay) m.roles.forEach(function (r) { if (pay.perms[r].U !== N) push('V10:payment-update:' + r); }); else push('V10:missing');
  // دعم
  var sup = g('support_sessions'); if (sup) { if (sup.perms.rep.R !== N || sup.perms.student.R !== N || sup.perms.rep.C !== N || sup.perms.student.C !== N) push('V19:support-non-dev'); if (sup.perms.developer.A !== N) push('V19:support-archive'); ['R', 'C', 'U'].forEach(function (op) { if (sup.perms.developer[op].indexOf('self') !== 0) push('V19:support-scope:' + op); }); } else push('V19:missing');
  // نسخ
  var be = g('backup_export'), br = g('backup_restore');
  if (!be || be.perms.rep.C !== N || be.perms.student.C !== N || be.perms.developer.C === N) push('V18:export'); if (!br) push('V18:restore-missing'); else m.roles.forEach(function (r) { OPS.forEach(function (op) { if (br.perms[r][op] !== N) push('V18:restore:' + r + ':' + op); }); });
  // push اشتراكات: لا أحد يقرأ اشتراك غيره
  var ps = g('push_subscriptions'); if (ps) m.roles.forEach(function (r) { OPS.forEach(function (op) { var p = parseCell(ps.perms[r][op]); if (p && p.scope !== 'none' && p.scope !== 'self') push('V17:push-scope:' + r + ':' + op); }); });
  // app_meta
  var am = g('app_meta'); if (am) m.roles.forEach(function (r) { ['C', 'U', 'A'].forEach(function (op) { if (am.perms[r][op] !== N) push('V21:app-meta-write:' + r); }); });
  var ap = g('activation_attempts'); if (ap) m.roles.forEach(function (r) { OPS.forEach(function (op) { if (ap.perms[r][op] !== N) push('V22:attempts:' + r); }); });
  // إدارة
  var ar = m.adminRules; if (!ar) push('V20:no-admin'); else {
    ROLES.forEach(function (r) { if (!ar[r]) { push('V20:role:' + r); return; }
      if ((ar[r].change_role || []).length) push('V20:change-role:' + r);
      if ((ar[r].create_developer || []).length) push('V20:create-dev:' + r);
      m.adminActions.forEach(function (a) { var t = ar[r][a]; if (!t) { push('V20:missing:' + r + ':' + a); return; } if (t.indexOf('developer') >= 0) push('V20:targets-dev:' + r + ':' + a); });
    });
    if (ar.rep) m.adminActions.forEach(function (a) { var t = ar.rep[a] || []; if (t.some(function (x) { return x !== 'student'; })) push('V20:rep-nonstudent:' + a); });
    if (ar.student) m.adminActions.forEach(function (a) { if ((ar.student[a] || []).length) push('V20:student-admin:' + a); });
  }
  return bad;
}

// ---------- مولِّدات التوثيق ----------
var SCOPE_AR = { none: '—', any: 'كل', class: 'الصف', self: 'ذاته', auth: 'عام' };
function cellText(c4) {
  var parts = [];
  OPS.forEach(function (op) { var p = parseCell(c4[op]); if (p.scope === 'none') return; parts.push(op + ':' + p.scope + (p.via && p.via !== 'rls' ? '@' + p.via : '')); });
  return parts.length ? parts.join(' ') : '—';
}
function renderMatrix(m) {
  var L = ['| الكيان | الصنف | المطوّر | ممثل الصف | الطالب |', '|---|---|---|---|---|'];
  m.entities.forEach(function (e) { L.push('| `' + e.id + '` — ' + e.ar + ' | ' + e.cls + ' | ' + cellText(e.perms.developer) + ' | ' + cellText(e.perms.rep) + ' | ' + cellText(e.perms.student) + ' |'); });
  return L.join('\n');
}
function renderEnforce(m) {
  var gr = deriveGrants(m), L = ['| الكيان | المسار | منح الجدول لـ`authenticated` | فلتر قراءة الطالب | قيود الهدف | تدقيق | `version` | ملاحظة |', '|---|---|---|---|---|---|---|---|'];
  m.entities.forEach(function (e) {
    var g = gr[e.id], gs = ['select', 'insert', 'update'].filter(function (k) { return g[k]; }).join('+') || '—';
    var tg = []; if (e.targets) Object.keys(e.targets).forEach(function (r) { Object.keys(e.targets[r]).forEach(function (op) { tg.push(r + '.' + op + '→{' + e.targets[r][op].join(',') + '}'); }); });
    L.push('| `' + e.id + '` | ' + e.path + ' | ' + gs + ' | ' + (e.studentFilter || '—') + ' | ' + (tg.join(' ؛ ') || '—') + ' | ' + (e.audited ? 'نعم' : '—') + ' | ' + (e.version ? 'نعم' : '—') + ' | ' + (e.note || '').replace(/\|/g, '/') + ' |');
  });
  return L.join('\n');
}
var ACTION_AR = { issue_code: 'إصدار رمز تفعيل/إعادة تفعيل', revoke_code: 'إبطال رمز', suspend: 'تعليق عضوية', reactivate: 'إعادة تفعيل عضوية', archive_member: 'أرشفة عضوية (مغادرة)', open_support: 'فتح وضع الدعم على حساب', change_role: 'تغيير دور عضوية', create_developer: 'إنشاء مطوّر' };
function renderAdmin(m) {
  var L = ['| الإجراء | المطوّر على | الممثل على (صفه فقط) | الطالب على |', '|---|---|---|---|'];
  var f = function (a) { return a.length ? a.join('، ') : '—'; };
  m.adminActions.forEach(function (a) { L.push('| ' + ACTION_AR[a] + ' (`' + a + '`) | ' + f(m.adminRules.developer[a]) + ' | ' + f(m.adminRules.rep[a]) + ' | ' + f(m.adminRules.student[a]) + ' |'); });
  return L.join('\n');
}
function digest(m) { return crypto.createHash('sha256').update(JSON.stringify(m)).digest('hex'); }

// ---------- كتالوج حالات المنع (يُولَّد من الـoracle + حالات اختلاف السياق) ----------
var CLS = 'cls-A', OTHER = 'cls-B';
function baseActor(role) { return { role: role, status: 'active', classId: role === 'developer' ? null : CLS, memberId: 'm-' + role }; }
function baseRes(e, role) {
  return { entity: e.id, classId: CLS, subjectId: 'm-' + role, targetRole: 'student', archived: false, approved: true, assigned: true, audienceMatch: true, parentReadable: true };
}
function buildCases(m) {
  m = m || M; var out = [], n = 0;
  var add = function (e, role, op, variant, actor, res) { var r = canV2(actor, op, res, m); out.push({ id: 'D-' + String(++n).padStart(4, '0'), entity: e.id, role: role, op: op, variant: variant, expect: r.allow ? 'allow' : 'deny', reason: r.reason }); };
  m.entities.forEach(function (e) { m.roles.forEach(function (role) { OPS.forEach(function (op) {
    var a = baseActor(role), r = baseRes(e, role), tgt = e.targets && e.targets[role] && e.targets[role][op];
    if (tgt) r.targetRole = tgt[0];
    add(e, role, op, 'base', a, r);
    var granted = canV2(a, op, r, m).allow;
    if (!granted) return;
    ['pending', 'suspended', 'archived', 'unknown', undefined].forEach(function (st) { var x = baseActor(role); x.status = st; add(e, role, op, 'status:' + st, x, r); });
    var cell = parseCell(e.perms[role][op]);
    if (cell.scope === 'class' || (cell.scope === 'self' && role !== 'developer')) { var rc = baseRes(e, role); if (tgt) rc.targetRole = tgt[0]; rc.classId = OTHER; add(e, role, op, 'cross-class', a, rc); var ac = baseActor(role); ac.classId = null; add(e, role, op, 'actor-no-class', ac, r); }
    if (cell.scope === 'self') { var rs = baseRes(e, role); if (tgt) rs.targetRole = tgt[0]; rs.subjectId = 'm-other'; add(e, role, op, 'not-self', a, rs); }
    if (tgt) ['developer', 'rep', 'student'].forEach(function (tr) { if (tgt.indexOf(tr) < 0) { var rt = baseRes(e, role); rt.targetRole = tr; add(e, role, op, 'target:' + tr, a, rt); } });
    if (role === 'student' && op === 'R' && e.studentFilter) {
      var ra = baseRes(e, role); ra.archived = true; add(e, role, op, 'archived-row', a, ra);
      var f = { approved: 'approved', assigned: 'assigned', audience: 'audienceMatch', parent: 'parentReadable' }[e.studentFilter];
      if (f) { var rf = baseRes(e, role); rf[f] = false; add(e, role, op, 'filter:' + e.studentFilter, a, rf); }
    }
    if (role === 'developer' && op !== 'R') { var ds = baseActor(role); ds.supportSessionOpen = true; ds.supportConfirm = false; add(e, role, op, 'support-no-confirm', ds, r); var dc = baseActor(role); dc.supportSessionOpen = true; dc.supportConfirm = true; add(e, role, op, 'support-confirmed', dc, r); }
  }); }); });
  m.entities.forEach(function (e) { OPS.forEach(function (op) { add(e, 'anonymous', op, 'anonymous', { role: 'anonymous', status: 'active' }, baseRes(e, 'student')); add(e, 'future-teacher', op, 'unknown-role', { role: 'teacher', status: 'active', classId: CLS, memberId: 'm-t' }, baseRes(e, 'student')); }); });
  return out;
}

module.exports = { M: M, ROLES: ROLES, OPS: OPS, SELF_STATE: SELF_STATE, parseCell: parseCell, canV2: canV2, canAdmin: canAdmin, deriveGrants: deriveGrants, validate: validate, renderMatrix: renderMatrix, renderEnforce: renderEnforce, renderAdmin: renderAdmin, digest: digest, buildCases: buildCases, entityById: entityById, viaOf: viaOf };
