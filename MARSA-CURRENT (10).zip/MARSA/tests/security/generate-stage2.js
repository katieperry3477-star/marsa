// node tests/security/generate-stage2.js [--write]  — يعيد توليد جدول المصفوفة في 02.02-PERMISSIONS.md من JSON.
'use strict';
var fs = require('fs'), M = require('./stage2-matrix.js');
var t = fs.readFileSync(M.DOC_PATH, 'utf8'), a = t.indexOf(M.BEGIN), b = t.indexOf(M.END);
if (a < 0 || b < 0) { console.error('علامات MATRIX غير موجودة'); process.exit(1); }
var out = t.slice(0, a) + M.block(M.load()) + t.slice(b + M.END.length);
if (process.argv.indexOf('--write') >= 0) { fs.writeFileSync(M.DOC_PATH, out); console.log('written'); } else console.log(out === t ? 'in sync' : 'DRIFT');
