// 5.04 — اختبارات مصفوفة الصلاحيات (مواصفة قابلة للتنفيذ) بما فيها حالات الرفض والطفرات. تشغيل: node tests/security/security-matrix.test.js
'use strict';
var fs = require('fs'), path = require('path'), oracle = require('./policy-oracle.js'), gen = require('./generate.js');
var ROOT = path.resolve(__dirname, '..', '..'), pass = 0, fail = 0;
function check(n, c, d) { if (c) { pass++; console.log('PASS ' + n); } else { fail++; console.log('FAIL ' + n + (d ? ' :: ' + d : '')); } }
function clone(o) { return JSON.parse(JSON.stringify(o)); }
var m = gen.load();
var retention = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs/stage5/security/retention-policy.json'), 'utf8'));

// ---- 1) سلامة المخطط ----
var types = Object.keys(m.resources), schemaErr = oracle.validateSchema(m);
check('SCH-01 المصفوفة: كل مورد×دور معرَّف وبلا قيم غير صالحة', schemaErr.length === 0, schemaErr.join('; '));
check('SCH-02 الحالة المؤقتة معلنة وغير معتمدة', m.status === 'provisional-unapproved');
check('SCH-03 سياسة selfView معطّلة افتراضياً ولا consentRef (لا موافقة موثقة بعد)', ['attendance', 'grades', 'payments'].every(function (k) { return m.selfViewPolicy[k].enabled === false && m.selfViewPolicy[k].consentRef === null; }));
check('SCH-04 الأنواع الأكاديمية السبعة الحالية كلها في المصفوفة (لا نوع بلا قاعدة)', ['dailyLessons', 'preparations', 'schedule', 'exams', 'attendance', 'grades', 'payments'].every(function (t) { return types.indexOf(t) >= 0; }));
check('SCH-05 مفاتيح المصفوفة تغطي المطلوب: صفوف/طلاب/دروس/تحاضير/جدول/امتحانات/حضور/درجات/مقبوضات/تقارير/نسخ', ['class', 'roster', 'dailyLessons', 'preparations', 'schedule', 'exams', 'attendance', 'grades', 'payments', 'reports', 'export_file', 'restore_op'].every(function (t) { return types.indexOf(t) >= 0; }));

// ---- 2) ثوابت السرية على المصفوفة الفعلية ----
var viol = oracle.checkInvariants(m);
check('CONF-01..16 كل الثوابت تتحقق على المصفوفة (عدد المخالفات 0)', viol.length === 0, viol.slice(0, 8).join(' | '));

// ---- 3) اختبارات الطفرات: يجب أن تكتشف الثوابت أي ضعف حُقن ----
function mutate(desc, fn, expectId) {
  var mm = clone(m); fn(mm);
  var v = oracle.checkInvariants(mm), sv = oracle.validateSchema(mm);
  // تُعدّ الطفرة مكتشفة إن خالفت الثابت المعني، أو سقطت في فحص المخطط (طبقة ثانية) لأن can() يرفض دفاعياً بعض الحالات
  check('MUT ' + desc + ' ⇒ تُكتشف (' + expectId + ')', v.some(function (x) { return x.indexOf(expectId) === 0; }) || sv.length > 0, (v.slice(0, 3).concat(sv.slice(0, 2))).join(' | ') || 'لم تُكتشف');
}
mutate('منح الطالب R بنطاق الصف على المقبوضات', function (x) { x.resources.payments.perms.student = { actions: 'R', scope: 'class' }; }, 'CONF-02');
mutate('منح الطالب R بنطاق الصف على الدرجات', function (x) { x.resources.grades.perms.student = { actions: 'R', scope: 'class' }; }, 'CONF-02');
mutate('منح الطالب كتابة على الدروس', function (x) { x.resources.dailyLessons.perms.student = { actions: 'CRUD', scope: 'class' }; }, 'CONF-03');
mutate('منح الممثل نطاق any على الحضور', function (x) { x.resources.attendance.perms.rep = { actions: 'CRUD', scope: 'any' }; }, 'CONF-04');
mutate('منح المجهول قراءة الدروس', function (x) { x.resources.dailyLessons.perms.anonymous = { actions: 'R', scope: 'class' }; }, 'CONF-05');
mutate('السماح بحذف سجل التدقيق للمطور', function (x) { x.resources.audit_log.perms.developer = { actions: 'RD', scope: 'any' }; }, 'CONF-06');
mutate('السماح للممثل بإنشاء عضوية', function (x) { x.resources.membership.perms.rep = { actions: 'C', scope: 'class' }; }, 'CONF-07');
mutate('منح المطور CRUD مباشراً على المقبوضات', function (x) { x.resources.payments.perms.developer = { actions: 'CRUD', scope: 'any' }; }, 'CONF-10');
mutate('منح الطالب قراءة التقارير', function (x) { x.resources.reports.perms.student = { actions: 'R', scope: 'class' }; }, 'CONF-11');
mutate('منح الطالب قراءة قائمة الصف كاملة', function (x) { x.resources.roster.perms.student = { actions: 'R', scope: 'class' }; }, 'CONF-12');
mutate('جعل حذف المقبوضات صلباً (none)', function (x) { x.resources.payments.deleteMode = 'none'; }, 'CONF-13');
mutate('السماح للممثل بإصدار رمز ممثل', function (x) { x.issueRules.rep.issuesRoles = ['student', 'rep']; }, 'CONF-15');
mutate('السماح للمطور بإصدار رمز مطور من التطبيق', function (x) { x.issueRules.developer.issuesRoles = ['developer', 'rep', 'student']; }, 'CONF-15');
mutate('منح الطالب قراءة رموز الدعوة', function (x) { x.resources.invite_code.perms.student = { actions: 'R', scope: 'class' }; }, 'CONF-16');
mutate('تحويل نطاق الطالب في المقبوضات إلى self دون موافقة', function (x) { x.resources.payments.perms.student = { actions: 'R', scope: 'self' }; }, 'CONF-01');

// ---- 4) قواعد selfView: لا عرض فردي بلا موافقة موثقة ----
var s1 = { role: 'student', status: 'active', classId: 'c1', studentId: 's1' };
var own = function (t) { return { type: t, classId: 'c1', studentId: 's1' }; };
var peer = function (t) { return { type: t, classId: 'c1', studentId: 's2' }; };
['attendance', 'grades', 'payments'].forEach(function (t) {
  check('SV ' + t + ': الافتراضي الطالب لا يقرأ سجله', !oracle.can(s1, 'R', own(t), m, m.selfViewPolicy).allow);
  var pol = {}; pol[t] = { enabled: true, consentRef: 'consent-2026-001' };
  check('SV ' + t + ': مع تفعيل+موافقة يقرأ سجله هو فقط', oracle.can(s1, 'R', own(t), m, pol).allow && !oracle.can(s1, 'R', peer(t), m, pol).allow);
  check('SV ' + t + ': التفعيل لا يمنح كتابة', ['C', 'U', 'D'].every(function (a) { return !oracle.can(s1, a, own(t), m, pol).allow; }));
  var pol2 = {}; pol2[t] = { enabled: true, consentRef: null };
  check('SV ' + t + ': تفعيل بلا consentRef مرفوض', !oracle.can(s1, 'R', own(t), m, pol2).allow);
  check('SV ' + t + ': تفعيل نوع لا يفتح نوعاً آخر', (function () { var o = ['attendance', 'grades', 'payments'].filter(function (x) { return x !== t; }); return o.every(function (x) { return !oracle.can(s1, 'R', own(x), m, pol).allow; }); })());
});

// ---- 5) مصفوفة الرفض الصريحة (أمثلة مقروءة) ----
var rep1 = { role: 'rep', status: 'active', classId: 'c1' }, dev = { role: 'developer', status: 'active' }, anon = { role: 'anonymous', status: 'active' };
var cases = [
  ['ممثل صف A لا يقرأ مقبوضات صف B', oracle.can(rep1, 'R', { type: 'payments', classId: 'c2', studentId: 's9' }, m, m.selfViewPolicy), false],
  ['ممثل صف A لا يكتب حضور صف B', oracle.can(rep1, 'C', { type: 'attendance', classId: 'c2', studentId: 's9' }, m, m.selfViewPolicy), false],
  ['ممثل صفه يقرأ مقبوضات صفه', oracle.can(rep1, 'R', { type: 'payments', classId: 'c1', studentId: 's1' }, m, m.selfViewPolicy), true],
  ['طالب لا يقرأ مقبوضات زميله', oracle.can(s1, 'R', peer('payments'), m, m.selfViewPolicy), false],
  ['طالب لا يقرأ حضور زميله', oracle.can(s1, 'R', peer('attendance'), m, m.selfViewPolicy), false],
  ['طالب يقرأ دروس صفه', oracle.can(s1, 'R', { type: 'dailyLessons', classId: 'c1' }, m, m.selfViewPolicy), true],
  ['طالب لا يقرأ دروس صف آخر', oracle.can(s1, 'R', { type: 'dailyLessons', classId: 'c2' }, m, m.selfViewPolicy), false],
  ['طالب لا يعدّل جدول صفه', oracle.can(s1, 'U', { type: 'schedule', classId: 'c1' }, m, m.selfViewPolicy), false],
  ['مجهول بلا عضوية لا يقرأ الدروس', oracle.can(anon, 'R', { type: 'dailyLessons', classId: 'c1' }, m, m.selfViewPolicy), false],
  ['مطور لا يقرأ الدرجات مباشرة', oracle.can(dev, 'R', { type: 'grades', classId: 'c1', studentId: 's1' }, m, m.selfViewPolicy), false],
  ['مطور يقرأ سجل التدقيق', oracle.can(dev, 'R', { type: 'audit_log', classId: 'c1' }, m, m.selfViewPolicy), true],
  ['ممثل لا يقرأ سجل التدقيق', oracle.can(rep1, 'R', { type: 'audit_log', classId: 'c1' }, m, m.selfViewPolicy), false],
  ['ممثل لا يستعيد نسخة', oracle.can(rep1, 'C', { type: 'restore_op', classId: 'c1' }, m, m.selfViewPolicy), false],
  ['ممثل يصدّر صفه', oracle.can(rep1, 'C', { type: 'export_file', classId: 'c1' }, m, m.selfViewPolicy), true],
  ['ممثل لا يصدّر صفاً آخر', oracle.can(rep1, 'C', { type: 'export_file', classId: 'c2' }, m, m.selfViewPolicy), false],
  ['حذف مقبوضة من الممثل يكون ناعماً', (function () { var d = oracle.can(rep1, 'D', { type: 'payments', classId: 'c1', studentId: 's1' }, m, m.selfViewPolicy); return d.allow && d.mode === 'soft'; })(), true],
  ['ممثل لا يعدّل سجل التدقيق', oracle.can(rep1, 'U', { type: 'audit_log', classId: 'c1' }, m, m.selfViewPolicy), false],
  ['طالب موقوف لا يقرأ الدروس', oracle.can(Object.assign({}, s1, { status: 'suspended' }), 'R', { type: 'dailyLessons', classId: 'c1' }, m, m.selfViewPolicy), false]
];
cases.forEach(function (c) { var got = typeof c[1] === 'boolean' ? c[1] : c[1].allow; check('CASE ' + c[0], got === c[2]); });

// ---- 6) تطابق الوثيقة والعقد المولَّد مع المصفوفة (لا انجراف) ----
var doc = fs.readFileSync(gen.paths.DOC, 'utf8');
var expectedDoc = gen.injectDoc(doc, gen.matrixTable(m));
check('DRIFT-01 جدول 5.04-PERMISSIONS.md مطابق لـpermissions-matrix.json (شغّل generate.js --write عند التعديل)', expectedDoc !== null && expectedDoc === doc);
var casesOnDisk = fs.readFileSync(gen.paths.CASES, 'utf8');
check('DRIFT-02 rls-contract-cases.json مطابق لما تولّده المصفوفة الحالية', casesOnDisk === gen.casesJson(m));
var parsed = JSON.parse(casesOnDisk);
check('CONTRACT-01 عقد الحالات يحتوي حالات رفض وسماح (ليس كله سماحاً)', parsed.cases.some(function (c) { return c[7] === 1; }) && parsed.cases.filter(function (c) { return c[7] === 0; }).length > parsed.cases.filter(function (c) { return c[7] === 1; }).length, 'allow=' + parsed.cases.filter(function (c) { return c[7] === 1; }).length + ' deny=' + parsed.cases.filter(function (c) { return c[7] === 0; }).length);
check('CONTRACT-02 كل حالة طالب-مقبوضات/حضور/درجات بسياسة off أو بلا موافقة ⇒ رفض', parsed.cases.filter(function (c) { return c[1] === 'student' && ['attendance', 'grades', 'payments'].indexOf(c[4]) >= 0 && c[6] !== 'on+consent'; }).every(function (c) { return c[7] === 0; }));
check('CONTRACT-03 لا حالة تسمح لطالب بقراءة سجل زميله', parsed.cases.filter(function (c) { return c[1] === 'student' && c[3] === 'own-peer' && ['attendance', 'grades', 'payments'].indexOf(c[4]) >= 0; }).every(function (c) { return c[7] === 0; }));
check('CONTRACT-04 لا حالة تسمح بعبور الصفوف لغير المطور', parsed.cases.filter(function (c) { return c[1] !== 'developer' && c[3] === 'other-class'; }).every(function (c) { return c[7] === 0; }));

// ---- 7) سياسة الاحتفاظ تغطي كل مورد وتتسق مع أنماط الحذف ----
var missing = types.filter(function (t) { return !retention.items[t]; });
check('RET-01 كل مورد في المصفوفة له بند احتفاظ/حذف', missing.length === 0, missing.join(','));
check('RET-02 لا بند احتفاظ يتيم بلا مورد', Object.keys(retention.items).every(function (t) { return types.indexOf(t) >= 0; }));
check('RET-03 الحذف الصلب للأنواع الحساسة يتطلب المطور + تصدير + تدقيق', retention.defaults.hardDeleteRequiresDeveloper && retention.defaults.hardDeleteRequiresAudit && retention.defaults.hardDeleteRequiresExportFirst && ['attendance', 'grades', 'payments', 'roster'].every(function (t) { return /المطور/.test(retention.items[t].hardDelete) && /تدقيق/.test(retention.items[t].hardDelete); }));
check('RET-04 المقبوضات لا حذف صلب من التطبيق', /لا حذف صلب/.test(retention.items.payments.deletion));
check('RET-05 الطلاب أرشفة لا حذف (Q8)', /أرشفة لا حذف/.test(retention.items.roster.deletion) && m.resources.roster.deleteMode === 'archive');
check('RET-06 سجل التدقيق: لا حذف يدوي', /لا حذف يدوي/.test(retention.items.audit_log.deletion) && !/D/.test(m.resources.audit_log.perms.developer.actions));

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
