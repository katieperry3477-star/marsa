// يولّد: كتل الجداول في ACCESS-MATRIX-V2.md + access-v2-deny-cases.json + access-v2-expected-grants.json من بيانات المصفوفة.
// node tests/security/generate-access-v2.js          يكتب
// node tests/security/generate-access-v2.js --check  يفحص التطابق دون كتابة (رمز خروج 1 عند الاختلاف)
'use strict';
var fs = require('fs'), path = require('path');
var A = require('./access-matrix-v2.js');
var DOCP = path.join(__dirname, '..', '..', 'docs', 'execution-v2', 'ACCESS-MATRIX-V2.md');
var check = process.argv.indexOf('--check') >= 0;
var cases = A.buildCases(A.M), dg = A.digest(A.M);
function stats() {
  var by = {}; cases.forEach(function (c) { var k = c.variant.split(':')[0]; by[k] = by[k] || { allow: 0, deny: 0 }; by[k][c.expect]++; });
  var L = ['**الإحصاء المولَّد:** ' + A.M.entities.length + ' كياناً × 3 أدوار × 4 عمليات = ' + A.M.entities.length * 12 + ' خلية · ' + cases.length + ' حالة في كتالوج المنع (' + cases.filter(function (c) { return c.expect === 'deny'; }).length + ' منع، ' + cases.filter(function (c) { return c.expect === 'allow'; }).length + ' سماح) · بصمة المصفوفة SHA-256: `' + dg + '`', '',
    '| صنف الحالة | منع | سماح |', '|---|---|---|'];
  Object.keys(by).forEach(function (k) { L.push('| ' + k + ' | ' + by[k].deny + ' | ' + by[k].allow + ' |'); });
  return L.join('\n');
}
var blocks = { MATRIX: A.renderMatrix(A.M), ENFORCE: A.renderEnforce(A.M), ADMIN: A.renderAdmin(A.M), STATS: stats() };
var doc = fs.readFileSync(DOCP, 'utf8'), out = doc;
Object.keys(blocks).forEach(function (k) {
  var re = new RegExp('(<!-- GEN:' + k + ':START -->\\n)[\\s\\S]*?(\\n?<!-- GEN:' + k + ':END -->)');
  if (!re.test(out)) throw new Error('علامة مفقودة: ' + k);
  out = out.replace(re, function (_, a, b) { return a + blocks[k] + '\n' + b.replace(/^\n/, ''); });
});
var casesJson = JSON.stringify({ note: 'يُولَّد آلياً من access-matrix-v2.js؛ لا يُعدَّل يدوياً. يُعاد تشغيله على RLS حقيقية في 03.03/09.02.', digest: dg, count: cases.length, cases: cases }, null, 1) + '\n';
var grantsJson = JSON.stringify({ note: 'المنح المتوقعة لدور authenticated لكل جدول؛ anon بلا أي منح؛ لا DELETE. لفاحص 03.03 (L-03).', digest: dg, grants: A.deriveGrants(A.M) }, null, 1) + '\n';
var files = [[DOCP, out], [path.join(__dirname, 'access-v2-deny-cases.json'), casesJson], [path.join(__dirname, 'access-v2-expected-grants.json'), grantsJson]];
var diff = files.filter(function (f) { return !fs.existsSync(f[0]) || fs.readFileSync(f[0], 'utf8') !== f[1]; });
if (check) { console.log(diff.length ? 'غير متطابق: ' + diff.map(function (f) { return path.basename(f[0]); }).join(', ') : 'متطابق'); process.exit(diff.length ? 1 : 0); }
files.forEach(function (f) { fs.writeFileSync(f[0], f[1]); });
console.log('كُتب:', files.map(function (f) { return path.basename(f[0]); }).join(', '));
