// 02.02 — تحميل مصفوفة المرحلة 2 وتوليد جدولها. مواصفة فقط؛ لا يُحمَّل من index.html.
'use strict';
var fs = require('fs'), path = require('path');
var ROOT = path.resolve(__dirname, '..', '..');
var JSON_PATH = path.join(ROOT, 'docs', 'stage2', 'security', '02.02-permissions.json');
var DOC_PATH = path.join(ROOT, 'docs', 'stage2', '02.02-PERMISSIONS.md');
var BEGIN = '<!-- MATRIX:BEGIN (مولَّد من security/02.02-permissions.json — لا تعدّله يدوياً) -->';
var END = '<!-- MATRIX:END -->';
var SCOPE_AR = { none: '', self: 'سجله', selfIfConsented: 'سجله إن فُعّل+موافقة', 'class': 'صفّه', any: 'أي صف' };
function load() { return JSON.parse(fs.readFileSync(JSON_PATH, 'utf8')); }
function cell(role, p, mat) {
  if (!p || !p.actions) return '✗';
  var s = p.actions + ' · ' + (SCOPE_AR[p.scope] || p.scope);
  if (role === 'student' && p.scope === 'selfIfConsented') s = '✗ (مغلق افتراضياً) — ' + s;
  return s;
}
function render(mat) {
  var rows = ['| المورد (الحساسية) | طالب | ممثل الصف | مطور | مجهول/حامل كود |', '|---|---|---|---|---|'];
  Object.keys(mat.resources).forEach(function (k) {
    var r = mat.resources[k], p = r.perms;
    var rep = cell('rep', p.rep, mat);
    if (rep !== '✗' && (mat.conditionalGrants || []).some(function (g) { return g.role === 'rep' && g.resource === k; })) rep += ' ⚠ مشروط DEC-25';
    rows.push('| `' + k + '` — ' + r.label + ' (' + r.sensitivity + ') | ' + cell('student', p.student, mat) + ' | ' + rep + ' | ' + cell('developer', p.developer, mat) + ' | ' + cell('anonymous', p.anonymous, mat) + ' |');
  });
  return rows.join('\n');
}
function block(mat) { return BEGIN + '\n' + render(mat) + '\n' + END; }
function inDoc() { var t = fs.readFileSync(DOC_PATH, 'utf8'), a = t.indexOf(BEGIN), b = t.indexOf(END); return a < 0 || b < 0 ? null : t.slice(a, b + END.length); }
module.exports = { load: load, render: render, block: block, inDoc: inDoc, BEGIN: BEGIN, END: END, DOC_PATH: DOC_PATH, JSON_PATH: JSON_PATH };
