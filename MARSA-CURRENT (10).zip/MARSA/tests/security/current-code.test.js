// 5.04 — اختبارات توصيفية للكود الحالي (4.08-final) تثبت حدود الحماية الفعلية. لا تعدّل التطبيق. تشغيل: node tests/security/current-code.test.js
// الوسوم: [حاجز] حماية واجهة مقصودة · [خطر معروف] حقيقة غير آمنة موثقة (يجب أن تبقى مرئية حتى تُعالج في برومبت التنفيذ).
'use strict';
var fs = require('fs'), path = require('path');
var ROOT = path.resolve(__dirname, '..', '..'), pass = 0, fail = 0;
function check(n, c, d) { if (c) { pass++; console.log('PASS ' + n); } else { fail++; console.log('FAIL ' + n + (d ? ' :: ' + d : '')); } }
function read(f) { return fs.readFileSync(path.join(ROOT, f), 'utf8'); }
function stripComments(src) { return src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"\\])\/\/.*$/gm, '$1'); }
function body(src, name) { // يستخرج جسم function name(...) { ... } بمطابقة الأقواس
  var i = src.indexOf('function ' + name + '('); if (i < 0) return null;
  var j = src.indexOf('{', i), d = 0, k;
  for (k = j; k < src.length; k++) { if (src[k] === '{') d++; else if (src[k] === '}') { d--; if (!d) return src.slice(j, k + 1); } }
  return null;
}
var app = read('js/app.js'), appCode = stripComments(app), html = read('full.html');
var jsFiles = fs.readdirSync(path.join(ROOT, 'js')).filter(function (f) { return /\.js$/.test(f); });

// ---- [حاجز] صفحتا الطالب الخاصتان لا تقرآن أي تخزين ----
['renderStudentGrades', 'renderStudentAbsence'].forEach(function (fn) {
  var b = stripComments(body(app, fn) || '');
  check('[حاجز] ' + fn + ' موجودة ولا تقرأ تخزيناً ولا store ولا localStorage', b.length > 20 && !/store\.|MarsaAcademicStore|localStorage|readCollection|getRecord/.test(b), b.slice(0, 80));
});
// ---- [حاجز] مصادر عرض الطالب لا تشمل الأنواع الحساسة ----
var ak = /var AK_SRC = \[(.*?)\];/.exec(appCode);
check('[حاجز] مصادر أرشيف الطالب (AK_SRC) = دروس/تحاضير/امتحانات فقط', !!ak && !/attendance|grades|payments/.test(ak[1]) && /dailyLessons/.test(ak[1]) && /preparations/.test(ak[1]) && /exams/.test(ak[1]), ak && ak[1]);
var dash = /var DASH_SRC = \[(.*?)\];/.exec(appCode);
check('[حاجز] مصادر لوحة اليوم (DASH_SRC) بلا حضور/درجات/مقبوضات', !!dash && !/attendance|grades|payments/.test(dash[1]), dash && dash[1]);
var rep = /var REP_SRC = \[(.*?)\];/.exec(appCode);
check('[توصيف] REP_SRC (ملخص الممثل) هو المكان الوحيد الذي يقرأ الأنواع الحساسة في لوحة اليوم', !!rep && /attendance/.test(rep[1]) && /grades/.test(rep[1]) && /payments/.test(rep[1]));
var stCfgTypes = (appCode.match(/type:\s*'(\w+)',\s*modelName/g) || []).map(function (x) { return /'(\w+)'/.exec(x)[1]; });
check('[حاجز] إعدادات عروض الطالب (cfg.type) ضمن الدروس/التحاضير/الامتحانات فقط', stCfgTypes.length >= 2 && stCfgTypes.every(function (t) { return ['dailyLessons', 'preparations', 'exams', 'schedule'].indexOf(t) >= 0; }), stCfgTypes.join(','));
// ---- كل قراءة لنوع حساس تقع داخل دوال الممثل فقط ----
var sensReads = [], re = /store\.readCollection\((ATT_TYPE|GR_TYPE|PAY_TYPE)|st\.readCollection\(t,|st\.readCollection\(p\[1\]/g, mm;
check('[توصيف] قراءات الأنواع الحساسة مرتبطة بثوابت ATT_TYPE/GR_TYPE/PAY_TYPE في أقسام الممثل (6 مواضع معروفة)', (appCode.match(/readCollection\((ATT_TYPE|GR_TYPE|PAY_TYPE)/g) || []).length === 6, String((appCode.match(/readCollection\((ATT_TYPE|GR_TYPE|PAY_TYPE)/g) || []).length));
check('[توصيف] وضع الطالب لا يشمل شاشات الحضور/الدرجات/المدفوعات (views)', (function () { var m = /student:\s*\{[^}]*views:\s*\[([^\]]*)\]/.exec(appCode); return !!m && !/'attendance'|'payments'|'r-grades'|'reports'|'students'/.test(m[1]); })());
check('[حاجز] go() يردّ الطالب عن صفحات الممثل (MODES.rep.views) ما لم يُفتح وضع الممثل', /MODES\.rep\.views\.indexOf\(navOf\(id\)\) > -1\) id = MODES\[state\.mode\]\.start/.test(appCode));

// ---- [خطر معروف] الرمز التجريبي والأكواد ----
var demoLines = appCode.split('\n').filter(function (l) { return /MRS-REP-DEMO-26/.test(l); });
check('[خطر معروف R1] الرمز التجريبي مكتوب في الكود مرة واحدة فقط (سطر واحد) ويجب ألا يوجد في بناء shared', demoLines.length === 1, String(demoLines.length));
check('[خطر معروف] الرمز التجريبي لا يظهر في index.html ولا في أي ملف js غير app.js', !/MRS-REP-DEMO/.test(html) && jsFiles.filter(function (f) { return f !== 'app.js' && /MRS-REP-DEMO/.test(read('js/' + f)); }).length === 0);
check('[حاجز] حالة فتح وضع الممثل في الذاكرة فقط (لا تُكتب لأي تخزين)', !/localStorage\.setItem\([^)]*repUnlocked|sessionStorage/.test(appCode) && /repUnlocked = true/.test(appCode));
check('[خطر معروف] حماية وضع الممثل = متغير JS قابل للتجاوز من أدوات المتصفح (لا مصادقة خادمية): لا fetch/XHR/WebSocket/sendBeacon في الكود', jsFiles.every(function (f) { return !/\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource/.test(stripComments(read('js/' + f))); }));
var alpha = /CODE_CHARS = '([^']+)', CODE_LEN = (\d+)/.exec(appCode);
check('[خطر معروف] studentCode: أبجدية 31 وطول 6 ⇒ ≈ 29.7 بت: معرّف لا يصلح كلمة مرور', !!alpha && alpha[1].length === 31 && +alpha[2] === 6 && 6 * Math.log2(31) < 32, alpha && alpha[0]);
check('[خطر معروف] توليد الكود يملك بديل Math.random عند غياب crypto (غير آمن كسر لكنه مقبول كمعرّف فقط)', /Math\.random/.test(appCode) && /لا يصلح سراً|يكفي للتعريف/.test(app));
check('[توصيف] نص الكود نفسه يعلن أن studentCode معرّف وليس سراً', /الكود معرّف للطالب وليس سراً ولا كلمة مرور/.test(app));

// ---- [خطر معروف] البيانات الحساسة نص صريح محلياً، ولا مسارات تصدير/مشاركة في الكود ----
check('[خطر معروف R2] التخزين الأكاديمي JSON.stringify مباشرة إلى localStorage بلا تشفير', /JSON\.stringify/.test(read('js/academic-store.js')) && !/crypto\.subtle|encrypt|AES/i.test(read('js/academic-store.js')));
// V1 يضيف المشاركة عمداً (navigator.share + رابط واتساب) في js/v1-*.js؛ يبقى هذا التوصيف حارساً لكود التطبيق القديم فقط، وفحص V1 المقابل في tests/v1-static.test.js
check('[توصيف] لا مسار تصدير/تنزيل/مشاركة/طباعة في الكود الحالي (Blob/createObjectURL/download/navigator.share/print)', jsFiles.filter(function (f) { return !/^v1-/.test(f); }).every(function (f) { return !/new Blob\(|createObjectURL|\.download\s*=|navigator\.share|window\.print\s*\(/.test(stripComments(read('js/' + f))); }));
check('[توصيف] لا console.log لبيانات (لا تسريب عبر الكونسول)', jsFiles.every(function (f) { return !/console\.(log|info|debug)\s*\(/.test(stripComments(read('js/' + f))); }));
check('[خطر معروف R11] index.html يحمّل خطاً من fonts.googleapis.com (تسريب IP/اعتماد خارجي) — يُعالج بقرار Q10', /fonts\.googleapis\.com/.test(html));
check('[حاجز] لا سكربت خارجي ولا معالج حدث مضمّن في index.html', !/<script[^>]+src=["']https?:/i.test(html) && !/\son[a-z]+\s*=|javascript:/i.test(html));
check('[حاجز] لا HTML sink ولا eval في js/ (XSS يقلّل أثر سرقة التخزين)', jsFiles.every(function (f) { var c = stripComments(read('js/' + f)); return !/\beval\s*\(|new\s+Function\s*\(|\.innerHTML\s*=|\.outerHTML\s*=|insertAdjacentHTML|document\.write\s*\(/.test(c); }));

// ---- لا أسرار في أي ملف من المشروع (الكود/الوثائق/الاختبارات) ----
var SECRET_PATTERNS = [
  ['JWT', /eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}/],
  ['supabase-secret-key', /sb_secret_[A-Za-z0-9_-]{10,}/],
  ['supabase-publishable-literal', /sb_publishable_[A-Za-z0-9_-]{10,}/],
  ['private-key', /-----BEGIN [A-Z ]*PRIVATE KEY-----/],
  ['aws', /AKIA[0-9A-Z]{16}/],
  ['stripe/openai-like', /\bsk[-_](live|test|proj)[-_][A-Za-z0-9]{10,}/],
  ['supabase-url-with-ref', /https:\/\/[a-z0-9]{20}\.supabase\.co/],
  ['password-assign', /(password|passwd|pwd)\s*[:=]\s*['"][^'"\s]{6,}['"]/i]
];
function walk(dir, out) { fs.readdirSync(dir).forEach(function (f) { var p = path.join(dir, f); var s = fs.statSync(p); if (s.isDirectory()) walk(p, out); else if (/\.(js|html|css|md|json|mmd|svg)$/.test(f)) out.push(p); }); return out; }
var files = walk(ROOT, []).filter(function (p) { return p.indexOf('/node_modules/') < 0 && path.basename(p) !== 'current-code.test.js'; });
var hits = [];
files.forEach(function (p) { var t = fs.readFileSync(p, 'utf8'); SECRET_PATTERNS.forEach(function (sp) { if (sp[1].test(t)) hits.push(sp[0] + '@' + path.relative(ROOT, p)); }); });
check('[حاجز] لا أسرار/مفاتيح/توكنات/روابط مشاريع في أي ملف (' + files.length + ' ملفاً مفحوصاً)', hits.length === 0, hits.join(','));
var clientFiles = ['index.html', 'full.html'].concat(jsFiles.map(function (f) { return 'js/' + f; }));
check('[حاجز] كلمات service_role/secret key/SUPABASE_ لا تظهر في ملفات العميل', clientFiles.every(function (f) { return !/service_role|secret[_ -]?key|SUPABASE_|serviceKey/i.test(read(f)); }));

// ---- فاحص الأسرار نفسه يعمل (ليس فارغاً) ----
check('SELF الفاحص يلتقط JWT/مفتاح سري/رابط مشروع مصطنع', SECRET_PATTERNS[0][1].test('eyJhbGciOiJIUzI1NiIsInR5cCI6.eyJyb2xlIjoic2VydmljZV9yb2xlIn0abc.SflKxwRJSMeKKF2QT4fw') && SECRET_PATTERNS[1][1].test('sb_secret_abcdefghij1234') && SECRET_PATTERNS[6][1].test('https://abcdefghijklmnopqrst.supabase.co'));

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
