// 5.04 — اختبار سلبي بالمتصفح: وضع الطالب لا يعرض ولا يقرأ حضور/درجات/مقبوضات/أسماء زملاء (بيانات اصطناعية بعلامات فريدة).
// ضابط إيجابي: وضع الممثل يعرض العلامات نفسها (لإثبات أن الاختبار ليس فارغاً). حاجز واجهة فقط — ليس أمن خادم.
// تشغيل: NODE_PATH=$(npm root -g) node tests/security/e2e-student-no-leak.playwright.js
var pw = require('playwright'), path = require('path');
var URL = 'file://' + path.resolve(__dirname, '..', '..', 'full.html');
var results = [], jsErrors = [], fails = 0;
function check(name, cond, detail) { results.push(cond); if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + (detail || ''))); }
var CID = 'cls_demo_001', T = '2026-10-22';
var S = { n1: 'سنتينل-زميل-أول', n2: 'سنتينل-زميل-ثانٍ', n3: 'سنتينل-زميل-ثالث', payPurpose: 'SENTPAYPURPOSE91', payNote: 'SENTPAYNOTE92', payReceipt: 'SENTRCPT93', payAmount: '7654321', grSubject: 'SENTGRSUBJ94', grTitle: 'SENTGRTITLE95', grScore: '8765', attNote: 'SENTATTNOTE96' };
var SENT = [S.n1, S.n2, S.n3, S.payPurpose, S.payNote, S.payReceipt, S.grSubject, S.grTitle, S.attNote];
function seedScript(a) {
  if (localStorage.getItem('marsa.roster')) return;
  var base = { createdAt: '2026-10-20T05:00:00.000Z', updatedAt: '2026-10-20T05:00:00.000Z' };
  localStorage.setItem('marsa.roster', JSON.stringify({ schemaVersion: 2, classId: a.cid, students: [
    { studentId: 'stu_a', name: a.S.n1, status: 'active', createdAt: base.createdAt, archivedAt: null, studentCode: 'MR-AAAAAA'.replace(/A/g, '2') },
    { studentId: 'stu_b', name: a.S.n2, status: 'active', createdAt: base.createdAt, archivedAt: null, studentCode: 'MR-333333' },
    { studentId: 'stu_c', name: a.S.n3, status: 'archived', createdAt: base.createdAt, archivedAt: base.createdAt, studentCode: 'MR-444444' }] }));
  function put(type, recs) { localStorage.setItem('marsa.academic.' + type + '.' + a.cid, JSON.stringify({ schemaVersion: 1, classId: a.cid, records: recs })); }
  put('payments', [Object.assign({ recordId: 'pay_1', classId: a.cid, studentId: 'stu_b', date: a.t, amount: +a.S.payAmount, purpose: a.S.payPurpose, receiptNo: a.S.payReceipt, note: a.S.payNote }, base)]);
  put('grades', [Object.assign({ recordId: 'grd_1', classId: a.cid, studentId: 'stu_b', date: a.t, subject: a.S.grSubject, title: a.S.grTitle, score: 77, maxScore: 100, note: 'x' }, base)]);
  put('attendance', [Object.assign({ recordId: 'att_1', classId: a.cid, studentId: 'stu_b', date: a.t, status: 'absent', note: a.S.attNote }, base)]);
  put('preparations', [Object.assign({ recordId: 'prep_1', classId: a.cid, date: a.t, subject: 'مادة-عامة', title: 'تحضير-عام-ظاهر', content: 'محتوى' }, base)]);
}
function normDigits(s) { return String(s).replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 0x0660); }).replace(/[۰-۹]/g, function (d) { return String(d.charCodeAt(0) - 0x06F0); }).replace(/[,٬٫،\s.]/g, ''); }
function leaks(txt) { var out = SENT.filter(function (s) { return txt.indexOf(s) >= 0; }); if (normDigits(txt).indexOf(S.payAmount) >= 0) out.push('amount'); if (normDigits(txt).indexOf('MR-') >= 0) out.push('MR-code'); return out; }
async function open(browser) {
  var ctx = await browser.newContext({ viewport: { width: 390, height: 780 }, timezoneId: 'Asia/Baghdad', locale: 'ar-IQ', hasTouch: true, isMobile: true });
  await ctx.addInitScript('(' + function (a) {
    window.__keyReads = [];
    var g = Storage.prototype.getItem; Storage.prototype.getItem = function (k) { try { window.__keyReads.push(String(k)); } catch (e) {} return g.apply(this, arguments); };
  }.toString() + ')()');
  await ctx.addInitScript('(' + seedScript.toString() + ')(' + JSON.stringify({ cid: CID, t: T, S: S }) + ')');
  var page = await ctx.newPage();
  page.on('pageerror', function (e) { jsErrors.push(e.message); });
  await page.clock.install({ time: new Date('2026-10-22T06:00:00Z') });
  await page.goto(URL);
  await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  return { ctx: ctx, page: page };
}
async function navTo(page, label) { await page.click('.nav button:has-text("' + label + '")'); await page.waitForSelector('#page-title:visible, #welcome:visible'); await page.waitForTimeout(120); }
async function everything(page) { return page.evaluate(function () { return document.body.innerText + '\n' + document.documentElement.outerHTML.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<style[\s\S]*?<\/style>/g, ''); }); }
async function sensitiveKeyReads(page) { return page.evaluate(function () { return window.__keyReads.filter(function (k) { return /^marsa\.academic\.(attendance|grades|payments)\./.test(k); }).length; }); }

(async function main() {
  var browser = await pw.chromium.launch(), c, page, t, label, views;
  // ===== 1) وضع الطالب: لا تسريب في أي صفحة طالب =====
  c = await open(browser); page = c.page;
  var seeded = await page.evaluate(function () { return [localStorage.getItem('marsa.academic.payments.cls_demo_001'), localStorage.getItem('marsa.academic.grades.cls_demo_001'), localStorage.getItem('marsa.academic.attendance.cls_demo_001'), localStorage.getItem('marsa.roster')].every(function (x) { return !!x; }); });
  check('تهيئة: البيانات الاصطناعية الأربعة مكتوبة في التخزين', seeded);
  await page.evaluate(function () { window.__keyReads.length = 0; }); // قراءة التحقق أعلاه من الاختبار نفسه لا من التطبيق
  views = ['الرئيسية', 'الجدول', 'التحاضير', 'الأرشيف', 'الامتحانات', 'الإعلانات', 'المواد والملازم', 'درجاتي', 'غيابي', 'الإعدادات'];
  for (var i = 0; i < views.length; i++) {
    await navTo(page, views[i]);
    t = await everything(page);
    check('طالب/' + views[i] + ': لا علامات حضور/درجات/مقبوضات/أسماء زملاء ولا أكواد MR- في الصفحة', leaks(t).length === 0, leaks(t).join(','));
  }
  await navTo(page, 'التحاضير'); t = await everything(page);
  check('ضابط: المحتوى العام (تحضير الصف) يظهر للطالب — الاختبار ليس فارغاً', /تحضير-عام-ظاهر/.test(t));
  check('طالب: لم تُقرأ أي مفاتيح attendance/grades/payments من التخزين أثناء كل التنقل (حاجز واجهة لا أمن)', (await sensitiveKeyReads(page)) === 0, String(await sensitiveKeyReads(page)));

  // ===== 2) محاولة تجاوز الواجهة: إظهار مبدّل الوضع بـDOM والنقر =====
  await page.evaluate(function () { var seg = document.querySelector('.seg'); if (seg) seg.hidden = false; document.querySelectorAll('.seg button').forEach(function (b) { b.hidden = false; }); });
  await page.click('.seg button[data-m="rep"]', { force: true }).catch(function () {});
  await page.waitForTimeout(400);
  var modeNow = await page.evaluate(function () { var b = document.querySelector('.seg button[aria-pressed="true"], .seg button.on, .seg button[aria-selected="true"]'); return b ? b.getAttribute('data-m') : 'unknown'; });
  var navLabels = await page.$$eval('.nav button', function (l) { return l.map(function (x) { return x.textContent.trim(); }); });
  check('تجاوز DOM: إظهار المبدّل والنقر على «ممثل» لا يفتح وضع الممثل (التبويبات بلا الحضور/المدفوعات)', navLabels.indexOf('الحضور') < 0 && navLabels.indexOf('المدفوعات') < 0 && modeNow !== 'rep', navLabels.join('|') + ' mode=' + modeNow);
  t = await everything(page);
  check('تجاوز DOM: لا تسريب بعد المحاولة', leaks(t).length === 0, leaks(t).join(','));
  check('تجاوز DOM: لم تُقرأ مفاتيح حساسة', (await sensitiveKeyReads(page)) === 0);
  check('توصيف [خطر معروف R2]: صفحة الطالب نفسها تستطيع قراءة البيانات الحساسة نصاً صريحاً من localStorage (لا عزل حقيقي)', await page.evaluate(function (p) { return (localStorage.getItem('marsa.academic.payments.cls_demo_001') || '').indexOf(p) >= 0; }, S.payPurpose));
  await c.ctx.close();

  // ===== 3) ضابط إيجابي: وضع الممثل (بالرمز التجريبي) يعرض العلامات =====
  c = await open(browser); page = c.page;
  await navTo(page, 'الإعدادات'); await page.fill('#rep-code-in', 'MRS-REP-DEMO-26'); await page.click('button:has-text("تفعيل")');
  await page.click('.seg button[data-m="rep"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
  await navTo(page, 'المدفوعات'); t = await everything(page);
  check('ضابط: وضع الممثل يعرض مقبوضات الصف (غرض الوصل ظاهر)', t.indexOf(S.payPurpose) >= 0);
  await navTo(page, 'الدرجات'); t = await everything(page);
  check('ضابط: وضع الممثل يعرض الدرجات', t.indexOf(S.grTitle) >= 0);
  await navTo(page, 'الحضور'); t = await everything(page);
  check('ضابط: وضع الممثل يعرض صفحة الحضور مع اسم الطالب', t.indexOf(S.n2) >= 0);
  // العودة لوضع الطالب: لا بقايا
  await page.click('.seg button[data-m="student"]'); await page.waitForSelector('#mode-fx', { state: 'hidden', timeout: 6000 });
  await navTo(page, 'درجاتي'); t = await everything(page);
  check('بعد العودة من الممثل إلى الطالب: لا بقايا بيانات حساسة في DOM', leaks(t).length === 0, leaks(t).join(','));
  // إعادة التحميل: الوضع يُقفل (لا يُحفظ)
  await page.reload(); await page.waitForSelector('#intro:not([hidden])'); await page.click('#skip-intro'); await page.waitForSelector('#intro', { state: 'hidden' });
  var segHidden = await page.evaluate(function () { var s = document.querySelector('.seg'); return !s || s.hidden || s.offsetParent === null; });
  check('بعد إعادة التحميل: وضع الممثل مقفول من جديد (لا يُحفظ فتحه)', segHidden);
  var prefs = await page.evaluate(function () { return localStorage.getItem('marsa.ui'); });
  check('تفضيلات الواجهة المخزّنة لا تحفظ وضع الممثل أبداً', !prefs || /"mode":"student"/.test(prefs));
  await c.ctx.close();
  await browser.close();

  check('لا أخطاء JavaScript أثناء الاختبار', jsErrors.length === 0, jsErrors.join(' | '));
  console.log('\n' + results.filter(Boolean).length + ' passed, ' + fails + ' failed');
  process.exit(fails ? 1 : 0);
})().catch(function (e) { console.error('CRASH', e); process.exit(2); });
