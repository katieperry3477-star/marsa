// اختبارات منطق الدرجات (4.04) — بعيداً عن DOM. تشغيل: node tests/grades-model.test.js (لا يحتاج مكتبات)
var assert = require('assert');
var M = require('../js/grades-model.js'), S = require('../js/academic-store.js');
var n = 0, f = 0;
function t(name, fn) { try { fn(); n++; console.log('PASS', name); } catch (e) { f++; console.log('FAIL', name, '-', e.message); } }
function fake(opts) { var d = {}; opts = opts || {}; return { d: d, get length() { return Object.keys(d).length; }, key: function (i) { return Object.keys(d)[i] || null; }, getItem: function (k) { return k in d ? d[k] : null; }, setItem: function (k, v) { if (opts.failWrite) throw new Error('QuotaExceededError'); d[k] = String(v); }, removeItem: function (k) { delete d[k]; } }; }
var CID = 'cls_t1', TODAY = '2026-10-22', ACT = ['stu_a', 'stu_b'];
var STUDENTS = [{ studentId: 'stu_a', name: 'أحمد', status: 'active' }, { studentId: 'stu_b', name: 'بشرى', status: 'active' }, { studentId: 'stu_c', name: 'جاسم', status: 'archived' }];
function ok(over) { var b = { studentId: 'stu_a', subject: 'الرياضيات', title: 'اختبار قصير', date: '2026-10-20', score: '7.5', maxScore: '10', note: '' }; for (var k in (over || {})) b[k] = over[k]; return b; }
var CTX = { today: TODAY, activeIds: ACT };
function rec(id, sid, subj, title, date, score, max, extra) { var r = { recordId: id, classId: CID, studentId: sid, subject: subj, title: title, date: date, score: score, maxScore: max }; for (var k in (extra || {})) r[k] = extra[k]; return r; }

// ---- الأرقام ----
t('parseNumber: أرقام لاتينية وعربية وفاصلة عشرية مختلفة', function () {
  assert.strictEqual(M.parseNumber('7.5').value, 7.5); assert.strictEqual(M.parseNumber('٧٫٥').value, 7.5); assert.strictEqual(M.parseNumber('۸').value, 8);
  assert.strictEqual(M.parseNumber('7,5').value, 7.5); assert.strictEqual(M.parseNumber(' 10 ').value, 10); assert.strictEqual(M.parseNumber('0').value, 0); assert.strictEqual(M.parseNumber(12.5).value, 12.5);
});
t('parseNumber: يرفض غير الرقمي (لا parseFloat متساهل)', function () {
  ['abc', '12abc', '1e3', '--5', '-3', '+3', '1.2.3', 'Infinity', 'NaN', '٧٫', '0x10', '5 5'].forEach(function (s) { assert.strictEqual(M.parseNumber(s).ok, false, s); });
  assert.strictEqual(M.parseNumber('').reason, 'empty'); assert.strictEqual(M.parseNumber('   ').reason, 'empty'); assert.strictEqual(M.parseNumber(null).reason, 'empty');
  assert.strictEqual(M.parseNumber(NaN).ok, false); assert.strictEqual(M.parseNumber(Infinity).ok, false);
});

// ---- الحدود الدنيا والعليا ----
t('الدرجة صفر صالحة (حد أدنى) وتساوي القصوى صالحة (حد أعلى)', function () {
  var a = M.validateEntry(ok({ score: '0' }), CTX), b = M.validateEntry(ok({ score: '10' }), CTX);
  assert.ok(a.ok); assert.strictEqual(a.values.score, 0); assert.ok(b.ok); assert.strictEqual(b.values.score, 10);
});
t('الدرجة السالبة أو الأكبر من القصوى مرفوضة', function () {
  assert.ok(M.validateEntry(ok({ score: '-1' }), CTX).errors.score); assert.ok(M.validateEntry(ok({ score: '10.01' }), CTX).errors.score); assert.ok(M.validateEntry(ok({ score: '11' }), CTX).errors.score);
  assert.ok(/أكبر من الدرجة القصوى/.test(M.validateEntry(ok({ score: '11' }), CTX).errors.score));
});
t('maxScore صفر أو سالب أو فارغ أو غير رقمي مرفوض', function () {
  ['0', '-5', '', 'abc', '0.0'].forEach(function (m) { var r = M.validateEntry(ok({ maxScore: m, score: '0' }), CTX); assert.strictEqual(r.ok, false, m); assert.ok(r.errors.maxScore, m); });
  assert.ok(/أكبر من صفر/.test(M.validateEntry(ok({ maxScore: '0', score: '0' }), CTX).errors.maxScore));
});
t('maxScore فوق 1000 مرفوض و1000 صالح، ولا تُفترض 100', function () {
  assert.ok(M.validateEntry(ok({ maxScore: '1001', score: '5' }), CTX).errors.maxScore); assert.ok(M.validateEntry(ok({ maxScore: '1000', score: '5' }), CTX).ok);
  assert.ok(M.validateEntry(ok({ maxScore: '', score: '5' }), CTX).errors.maxScore);
});
t('مدخلات غير رقمية للدرجة: رسالة صريحة ولا تتحول إلى صفر', function () {
  ['', 'abc', '١٢ب', '7..5', 'null'].forEach(function (s) { var r = M.validateEntry(ok({ score: s }), CTX); assert.strictEqual(r.ok, false, s); assert.ok(r.errors.score, s); assert.strictEqual(r.values.score, undefined, s); });
});
t('أعداد عشرية: 7.5 و0.25 و19.99 صالحة؛ ثلاث خانات مرفوضة', function () {
  assert.ok(M.validateEntry(ok({ score: '0.25', maxScore: '1' }), CTX).ok); assert.ok(M.validateEntry(ok({ score: '19.99', maxScore: '20' }), CTX).ok); assert.ok(M.validateEntry(ok({ score: '7.5', maxScore: '12.5' }), CTX).ok);
  assert.ok(M.validateEntry(ok({ score: '7.555' }), CTX).errors.score); assert.ok(M.validateEntry(ok({ maxScore: '10.123' }), CTX).errors.maxScore);
});
t('أرقام عربية-هندية تُقبل وتُخزَّن عدداً (score ليس نصاً)', function () {
  var r = M.validateEntry(ok({ score: '٧٫٥', maxScore: '١٠' }), CTX); assert.ok(r.ok); assert.strictEqual(typeof r.values.score, 'number'); assert.strictEqual(r.values.score, 7.5); assert.strictEqual(r.values.maxScore, 10);
});

// ---- التواريخ ----
t('التاريخ: فارغ، غير موجود، صيغة خاطئة، خارج النطاق، مستقبلي', function () {
  assert.ok(M.validateEntry(ok({ date: '' }), CTX).errors.date); assert.ok(M.validateEntry(ok({ date: '2026-02-30' }), CTX).errors.date); assert.ok(M.validateEntry(ok({ date: '22/10/2026' }), CTX).errors.date);
  assert.ok(M.validateEntry(ok({ date: '1999-12-31' }), CTX).errors.date); assert.ok(M.validateEntry(ok({ date: '2101-01-01' }), CTX).errors.date); assert.ok(M.validateEntry(ok({ date: '2026-10-23' }), CTX).errors.date);
  assert.ok(M.validateEntry(ok({ date: TODAY }), CTX).ok); assert.ok(M.validateEntry(ok({ date: '2024-02-29' }), CTX).ok); assert.ok(M.validateEntry(ok({ date: '2025-02-29' }), CTX).errors.date);
});
t('localDate محلي لا UTC: 23:30 محلياً يبقى اليوم نفسه', function () {
  assert.strictEqual(M.localDate(new Date(2026, 9, 22, 23, 30)), '2026-10-22'); assert.strictEqual(M.localDate(new Date(2026, 0, 1, 0, 5)), '2026-01-01');
  assert.strictEqual(M.formatDate('2026-10-22'), '22/10/2026'); assert.strictEqual(M.formatDate('bad'), 'bad'); assert.strictEqual(M.formatDate(''), '(بلا تاريخ)');
});

// ---- الطالب والصف ----
t('الطالب: غير فعّال/مؤرشف/غير معروف/معرّف غير صالح ⇒ مرفوض', function () {
  assert.ok(M.validateEntry(ok({ studentId: 'stu_c' }), CTX).errors.studentId); assert.ok(M.validateEntry(ok({ studentId: 'stu_zzz' }), CTX).errors.studentId);
  assert.ok(M.validateEntry(ok({ studentId: '' }), CTX).errors.studentId); assert.ok(M.validateEntry(ok({ studentId: 'a b' }), CTX).errors.studentId); assert.ok(M.validateEntry(ok({ studentId: '1' }), { today: TODAY, activeIds: ['stu_a'] }).errors.studentId);
  assert.ok(M.validateEntry(ok({ studentId: 'stu_b' }), CTX).ok);
});
t('studentKind: فعّال/مؤرشف/غير معروف (حسب studentId لا الاسم أو الترتيب)', function () {
  assert.strictEqual(M.studentKind('stu_a', STUDENTS), 'active'); assert.strictEqual(M.studentKind('stu_c', STUDENTS), 'archived'); assert.strictEqual(M.studentKind('nope', STUDENTS), 'unknown'); assert.strictEqual(M.studentKind('1', STUDENTS), 'unknown');
});
t('النصوص: مادة وعنوان مطلوبان وبحد 80 وملاحظة 200، مع تنظيف المسافات والمحارف الخفية', function () {
  assert.ok(M.validateEntry(ok({ subject: '   ' }), CTX).errors.subject); assert.ok(M.validateEntry(ok({ title: '' }), CTX).errors.title);
  assert.ok(M.validateEntry(ok({ subject: 'م'.repeat(81) }), CTX).errors.subject); assert.ok(M.validateEntry(ok({ subject: 'م'.repeat(80) }), CTX).ok);
  assert.ok(M.validateEntry(ok({ title: 'ع'.repeat(81) }), CTX).errors.title); assert.ok(M.validateEntry(ok({ note: 'ن'.repeat(201) }), CTX).errors.note); assert.ok(M.validateEntry(ok({ note: 'ن'.repeat(200) }), CTX).ok);
  var r = M.validateEntry(ok({ subject: '  الرياضيات \u200B  ', title: 'اختبار\n  قصير', note: ' \u0007ملاحظة ' }), CTX);
  assert.strictEqual(r.values.subject, 'الرياضيات'); assert.strictEqual(r.values.title, 'اختبار قصير'); assert.strictEqual(r.values.note, 'ملاحظة');
});

// ---- النسب والمتوسطات ----
t('percent: من البيانات المخزنة، وnull للبيانات غير الصالحة (لا صفر)', function () {
  assert.strictEqual(M.percent({ score: 7.5, maxScore: 10 }), 75); assert.strictEqual(M.percent({ score: 0, maxScore: 10 }), 0); assert.strictEqual(M.percent({ score: 10, maxScore: 20 }), 50);
  assert.strictEqual(M.percent({ score: 5, maxScore: 0 }), null); assert.strictEqual(M.percent({ score: 5, maxScore: -1 }), null); assert.strictEqual(M.percent({ score: '5', maxScore: 10 }), null); assert.strictEqual(M.percent({ score: NaN, maxScore: 10 }), null); assert.strictEqual(M.percent(null), null);
  assert.strictEqual(M.fmtPercent(null), '—'); assert.strictEqual(M.fmtPercent(66.666666), '66.67%'); assert.strictEqual(M.fmtNum(7.5), '7.5');
});
t('pooledAverage: المجموع ÷ مجموع القصوى، وتقييمات بدرجات قصوى مختلفة', function () {
  var list = [rec('g1', 'stu_a', 'ر', 'أ', '2026-10-01', 9, 10), rec('g2', 'stu_a', 'ر', 'ب', '2026-10-02', 10, 100)], a = M.pooledAverage(list);
  assert.strictEqual(a.count, 2); assert.strictEqual(a.sumScore, 19); assert.strictEqual(a.sumMax, 110); assert.ok(Math.abs(a.percent - 17.2727) < 0.001);
  assert.ok(Math.abs(M.meanOfPercents(list) - 50) < 1e-9); // الطريقتان تختلفان ولا تُخلطان
  assert.notStrictEqual(Math.round(a.percent), Math.round(M.meanOfPercents(list)));
});
t('pooledAverage: فارغ ⇒ percent=null (لا 0%)، والسجل غير الصالح يُستثنى ويُعدّ', function () {
  var e = M.pooledAverage([]); assert.strictEqual(e.percent, null); assert.strictEqual(e.count, 0);
  var m = M.pooledAverage([rec('g1', 'stu_a', 'ر', 'أ', '2026-10-01', 5, 10), { recordId: 'bad', score: 'x', maxScore: 10 }, rec('g3', 'stu_a', 'ر', 'ج', '2026-10-03', 5, 0)]);
  assert.strictEqual(m.count, 1); assert.strictEqual(m.invalid, 2); assert.strictEqual(m.percent, 50);
  assert.strictEqual(M.pooledAverage([{ score: 'x', maxScore: 10 }]).percent, null);
});
t('pooledAverage: دقة الأعداد العشرية (0.1+0.2) والدرجات الصفرية تُحسب', function () {
  var a = M.pooledAverage([rec('g1', 'stu_a', 'ر', 'أ', '2026-10-01', 0.1, 1), rec('g2', 'stu_a', 'ر', 'ب', '2026-10-02', 0.2, 1)]); assert.strictEqual(a.sumScore, 0.3); assert.ok(Math.abs(a.percent - 15) < 1e-9);
  assert.strictEqual(M.pooledAverage([rec('g1', 'stu_a', 'ر', 'أ', '2026-10-01', 0, 10)]).percent, 0);
});
t('summarizeBySubject: يجمع المواد بعد توحيد الهمزات والتاء المربوطة ويفرزها', function () {
  var s = M.summarizeBySubject([rec('g1', 'stu_a', 'اللغة العربية', 'أ', '2026-10-01', 5, 10), rec('g2', 'stu_a', 'اللغه العربيه', 'ب', '2026-10-02', 10, 10), rec('g3', 'stu_a', 'الرياضيات', 'ج', '2026-10-03', 1, 10)]);
  assert.strictEqual(s.length, 2); var ar = s.filter(function (x) { return /العرب/.test(x.subject); })[0]; assert.strictEqual(ar.count, 2); assert.strictEqual(ar.percent, 75);
});

// ---- التفرّد وإعادة الامتحان ----
t('التفرّد: نفس (طالب، مادة، عنوان، تاريخ) بعد التوحيد ⇒ تكرار', function () {
  var list = [rec('g1', 'stu_a', 'الرياضيات', 'اختبار قصير', '2026-10-20', 7, 10)];
  assert.ok(M.findDuplicate(list, { studentId: 'stu_a', subject: ' الرياضيات ', title: 'اختبار  قصير', date: '2026-10-20' }, null));
  assert.ok(M.findDuplicate(list, { studentId: 'stu_a', subject: 'الرياضيات', title: 'إختبار قصير', date: '2026-10-20' }, null)); // همزة
  assert.strictEqual(M.findDuplicate(list, { studentId: 'stu_a', subject: 'الرياضيات', title: 'اختبار قصير', date: '2026-10-20' }, 'g1'), null); // نفس السجل عند التعديل
});
t('إعادة الامتحان/تقييم مماثل مسموح: عنوان أو تاريخ أو مادة أو طالب مختلف', function () {
  var list = [rec('g1', 'stu_a', 'الرياضيات', 'اختبار شهري', '2026-10-20', 4, 10)];
  [{ title: 'اختبار شهري - إعادة' }, { date: '2026-10-27' }, { subject: 'الفيزياء' }, { studentId: 'stu_b' }].forEach(function (o) {
    var c = { studentId: 'stu_a', subject: 'الرياضيات', title: 'اختبار شهري', date: '2026-10-20' }; for (var k in o) c[k] = o[k];
    assert.strictEqual(M.findDuplicate(list, c, null), null, JSON.stringify(o));
  });
});
t('planSave: إنشاء بلا recordId، وتكرار يُرفض مع status=duplicate ويرجع السجل القائم', function () {
  var list = [rec('g1', 'stu_a', 'الرياضيات', 'اختبار قصير', '2026-10-20', 7, 10)];
  var p = M.planSave(ok({ studentId: 'stu_b' }), list, CTX, null); assert.ok(p.ok); assert.strictEqual(p.mode, 'create'); assert.strictEqual(p.record.recordId, undefined); assert.strictEqual(p.record.score, 7.5);
  var d = M.planSave(ok(), list, CTX, null); assert.strictEqual(d.ok, false); assert.strictEqual(d.status, 'duplicate'); assert.strictEqual(d.duplicate.recordId, 'g1'); assert.ok(d.errors._);
});
t('planSave: التعديل يحفظ recordId وclassId وcreatedAt وstudentId ولا ينشئ سجلاً جديداً', function () {
  var ex = rec('g1', 'stu_a', 'الرياضيات', 'اختبار قصير', '2026-10-20', 7, 10, { createdAt: '2026-10-20T08:00:00.000Z', updatedAt: '2026-10-20T08:00:00.000Z', note: 'قديمة' });
  var p = M.planSave(ok({ studentId: 'stu_b', score: '9', note: '' }), [ex], CTX, ex); // محاولة تغيير الطالب تُتجاهل
  assert.ok(p.ok); assert.strictEqual(p.mode, 'update'); assert.strictEqual(p.record.recordId, 'g1'); assert.strictEqual(p.record.classId, CID); assert.strictEqual(p.record.studentId, 'stu_a'); assert.strictEqual(p.record.createdAt, ex.createdAt); assert.strictEqual(p.record.score, 9); assert.strictEqual(p.record.note, undefined);
});
t('planSave: تعديل بلا تغيير ⇒ unchanged؛ تعديل يصطدم بسجل آخر ⇒ duplicate؛ سجل محذوف ⇒ not-found', function () {
  var a = rec('g1', 'stu_a', 'الرياضيات', 'اختبار قصير', '2026-10-20', 7.5, 10), b = rec('g2', 'stu_a', 'الرياضيات', 'اختبار آخر', '2026-10-20', 5, 10);
  assert.strictEqual(M.planSave(ok(), [a, b], CTX, a).mode, 'unchanged');
  var c = M.planSave(ok({ title: 'اختبار آخر' }), [a, b], CTX, a); assert.strictEqual(c.status, 'duplicate'); assert.strictEqual(c.duplicate.recordId, 'g2');
  assert.strictEqual(M.planSave(ok(), [b], CTX, a).status, 'not-found');
});
t('planSave: تعديل يرفع الدرجة فوق القصوى الجديدة ⇒ مرفوض ولا يعدّل', function () {
  var a = rec('g1', 'stu_a', 'الرياضيات', 'اختبار قصير', '2026-10-20', 9, 10), p = M.planSave(ok({ score: '9', maxScore: '5' }), [a], CTX, a); assert.strictEqual(p.ok, false); assert.ok(p.errors.score);
});
t('findConflicts: يرصد تكراراً مخزّناً ولا يحذف شيئاً', function () {
  var list = [rec('g1', 'stu_a', 'ر', 'أ', '2026-10-20', 1, 10), rec('g2', 'stu_a', 'ر', 'أ', '2026-10-20', 2, 10), rec('g3', 'stu_b', 'ر', 'أ', '2026-10-20', 2, 10)], c = M.findConflicts(list);
  assert.strictEqual(c.length, 1); assert.deepStrictEqual(c[0].recordIds, ['g1', 'g2']); assert.strictEqual(list.length, 3);
});

// ---- البحث والفرز ----
var LIST = [
  rec('g1', 'stu_a', 'الرياضيات', 'اختبار قصير', '2026-10-20', 9, 10, { note: 'ممتاز' }), rec('g2', 'stu_b', 'اللغة العربية', 'واجب الأسبوع', '2026-10-21', 5, 10),
  rec('g3', 'stu_a', 'اللغة العربية', 'امتحان نصفي', '2026-09-30', 40, 50), rec('g4', 'stu_c', 'الرياضيات', 'اختبار قصير', '2026-10-01', 3, 10)
];
function nm(id) { var s = STUDENTS.filter(function (x) { return x.studentId === id; })[0]; return s ? s.name : ''; }
t('البحث: بالطالب والمادة والعنوان والتاريخ (بصيغتين) والملاحظة، مع توحيد الهمزات', function () {
  function ids(o) { o.nameOf = nm; return M.filterRecords(LIST, o).map(function (r) { return r.recordId; }).sort().join(); }
  assert.strictEqual(ids({ query: 'أحمد' }), 'g1,g3'); assert.strictEqual(ids({ query: 'احمد' }), 'g1,g3'); assert.strictEqual(ids({ query: 'العربيه' }), 'g2,g3'); assert.strictEqual(ids({ query: 'اختبار' }), 'g1,g4');
  assert.strictEqual(ids({ query: '2026-10-21' }), 'g2'); assert.strictEqual(ids({ query: '21/10/2026' }), 'g2'); assert.strictEqual(ids({ query: 'ممتاز' }), 'g1'); assert.strictEqual(ids({ query: 'لا شيء' }), ''); assert.strictEqual(ids({ query: '' }), 'g1,g2,g3,g4');
});
t('الفلاتر: طالب، مادة، مدى تواريخ (شامل الطرفين)، ودمجها', function () {
  function ids(o) { o.nameOf = nm; return M.filterRecords(LIST, o).map(function (r) { return r.recordId; }).sort().join(); }
  assert.strictEqual(ids({ studentId: 'stu_a' }), 'g1,g3'); assert.strictEqual(ids({ studentId: 'all' }), 'g1,g2,g3,g4'); assert.strictEqual(ids({ subject: 'الرياضيات' }), 'g1,g4');
  assert.strictEqual(ids({ from: '2026-10-01', to: '2026-10-20' }), 'g1,g4'); assert.strictEqual(ids({ studentId: 'stu_a', subject: 'اللغة العربية' }), 'g3'); assert.strictEqual(ids({ studentId: 'stu_c' }), 'g4');
});
t('الفرز: تاريخ/طالب/مادة/عنوان/نسبة، الاتجاهان، وحتمية عند التساوي، ولا يعدّل الأصل', function () {
  function ids(k, d) { return M.sortRecords(LIST, k, d, nm).map(function (r) { return r.recordId; }).join(); }
  var before = LIST.map(function (r) { return r.recordId; }).join();
  assert.strictEqual(ids('date', 'desc'), 'g2,g1,g4,g3'); assert.strictEqual(ids('date', 'asc'), 'g3,g4,g1,g2'); assert.strictEqual(ids('percent', 'desc'), 'g1,g3,g2,g4'); assert.strictEqual(ids('percent', 'asc'), 'g4,g2,g3,g1');
  assert.strictEqual(ids('student', 'asc').split(',')[0], 'g1'); // أحمد أولاً (g1 أحدث من g3)
  assert.strictEqual(ids('subject', 'asc').split(',').slice(0, 2).sort().join(), 'g1,g4'); assert.strictEqual(ids('bogus', 'desc'), ids('date', 'desc'));
  assert.strictEqual(LIST.map(function (r) { return r.recordId; }).join(), before);
});
t('distinctSubjects: مواد فريدة مرتبة بلا تكرار تحريري', function () { assert.deepStrictEqual(M.distinctSubjects(LIST), ['الرياضيات', 'اللغة العربية']); });

// ---- تكامل مع المتجر ----
t('تكامل: planSave → upsertRecord ينشئ grd_ ثم تعديل يحفظ recordId', function () {
  var st = fake(), s = S.create({ storage: st }), p = M.planSave(ok(), [], CTX, null), o1 = s.upsertRecord('grades', CID, p.record);
  assert.ok(o1.ok); assert.ok(/^grd_/.test(o1.record.recordId)); assert.strictEqual(o1.record.classId, CID);
  var cur = o1.records, p2 = M.planSave(ok({ score: '8' }), cur, CTX, o1.record), o2 = s.upsertRecord('grades', CID, p2.record);
  assert.ok(o2.ok); assert.strictEqual(o2.records.length, 1); assert.strictEqual(o2.record.recordId, o1.record.recordId); assert.strictEqual(o2.record.score, 8);
});
t('تكامل: المتجر نفسه يرفض التكرار حتى لو تخطّاه النموذج (خط دفاع ثانٍ)', function () {
  var st = fake(), s = S.create({ storage: st }); s.upsertRecord('grades', CID, M.planSave(ok(), [], CTX, null).record);
  var o = s.upsertRecord('grades', CID, M.planSave(ok(), [], CTX, null).record); assert.strictEqual(o.ok, false); assert.strictEqual(o.status, 'duplicate'); assert.strictEqual(s.readCollection('grades', CID).records.length, 1);
});
t('تكامل: التخزين معطّل/ممتلئ ⇒ فشل صريح لا نجاح كاذب ولا كتابة جزئية', function () {
  var st = fake({ failWrite: true }), s = S.create({ storage: st }), o = s.upsertRecord('grades', CID, M.planSave(ok(), [], CTX, null).record);
  assert.strictEqual(o.ok, false); assert.ok(o.error);
  var s2 = S.create({ storage: null }), o2 = s2.upsertRecord('grades', CID, M.planSave(ok(), [], CTX, null).record); assert.ok(o2.ok); assert.strictEqual(o2.persistent, false); // ذاكرة مؤقتة معلنة
});
t('تكامل: بيانات تالفة تُحجب ولا تُقرأ كقائمة فارغة ولا يُكتب فوقها', function () {
  var st = fake(), s = S.create({ storage: st }); st.setItem('marsa.academic.grades.' + CID, '{broken');
  var r = s.readCollection('grades', CID); assert.strictEqual(r.ok, false); var o = s.upsertRecord('grades', CID, M.planSave(ok(), [], CTX, null).record); assert.strictEqual(o.ok, false); assert.strictEqual(st.getItem('marsa.academic.grades.' + CID), '{broken');
  st.setItem('marsa.academic.grades.' + CID, JSON.stringify({ schemaVersion: 1, classId: CID, records: [rec('g1', 'stu_a', 'ر', 'أ', '2026-10-20', 99, 10)] })); // درجة أكبر من القصوى
  assert.strictEqual(s.readCollection('grades', CID).ok, false);
});
t('تكامل: العزل بين صفين، وحذف سجل لا يمسّ الآخر ولا مفاتيح الطلاب', function () {
  var st = fake(), s = S.create({ storage: st }); st.setItem('marsa.roster', 'R'); st.setItem('marsa.classes', 'C');
  var a = s.upsertRecord('grades', 'cls_a', M.planSave(ok(), [], CTX, null).record), b = s.upsertRecord('grades', 'cls_b', M.planSave(ok({ title: 'آخر' }), [], CTX, null).record);
  assert.strictEqual(s.readCollection('grades', 'cls_a').records.length, 1); assert.strictEqual(s.readCollection('grades', 'cls_b').records[0].title, 'آخر');
  s.deleteRecord('grades', 'cls_a', a.record.recordId); assert.strictEqual(s.readCollection('grades', 'cls_a').records.length, 0); assert.strictEqual(s.readCollection('grades', 'cls_b').records.length, 1);
  assert.strictEqual(st.getItem('marsa.roster'), 'R'); assert.strictEqual(st.getItem('marsa.classes'), 'C'); assert.strictEqual(s.readCollection('exams', 'cls_a').records.length, 0); // لا خلط مع نوع الامتحانات
});
t('الفصل عن الامتحانات: النموذج لا يستورد exams-model ولا يلمس نوع exams', function () {
  var src = require('fs').readFileSync(require('path').resolve(__dirname, '..', 'js', 'grades-model.js'), 'utf8');
  assert.ok(!/exams-model|MarsaExamsModel|'exams'/.test(src.replace(/\/\*[\s\S]*?\*\//, '')));
});

// ---- 4.08: فاصلة الآلاف الملتبسة لا تُقرأ بصمت كعشرية ----
t('4.08 parseNumber: «1,000» و«7,500» و«7.500» و«٬» مرفوضة (كانت تُقرأ 1 و7.5 و7.5 و1 بصمت)', function () {
  ['1,000', '7,500', '7.500', '1.000', '5.255', '٧٫٥٠٠'].forEach(function (x) { var r = M.parseNumber(x); assert.strictEqual(r.ok, false, x); assert.strictEqual(r.reason, 'decimals', x); });
  ['١٬٠٠٠', '1٬000', '٧٬٥'].forEach(function (x) { var r = M.parseNumber(x); assert.strictEqual(r.ok, false, x); assert.strictEqual(r.reason, 'separator', x); });
});
t('4.08 parseNumber: الصيغ الصحيحة ما زالت تعمل (7,5 و٧٫٥ و5.25 و10 و1000 و0.1)', function () {
  assert.strictEqual(M.parseNumber('7,5').value, 7.5); assert.strictEqual(M.parseNumber('٧٫٥').value, 7.5); assert.strictEqual(M.parseNumber('5.25').value, 5.25);
  assert.strictEqual(M.parseNumber('10').value, 10); assert.strictEqual(M.parseNumber('1000').value, 1000); assert.strictEqual(M.parseNumber('0.1').value, 0.1); assert.strictEqual(M.parseNumber('5.50').value, 5.5);
});
t('4.08 validateEntry: درجة قصوى «1,000» ودرجة «7,500» تُنتجان رسالة خطأ لا قيمة مخمَّنة', function () {
  var a = M.validateEntry(ok({ maxScore: '1,000', score: '1' }), CTX), b = M.validateEntry(ok({ score: '7,500' }), CTX), c = M.validateEntry(ok({ maxScore: '١٬٠٠٠', score: '1' }), CTX);
  assert.strictEqual(a.ok, false); assert.ok(/خانتان|فاصلة/.test(a.errors.maxScore)); assert.strictEqual(a.values.maxScore, undefined);
  assert.strictEqual(b.ok, false); assert.ok(/خانتان|فاصلة/.test(b.errors.score)); assert.strictEqual(b.values.score, undefined);
  assert.strictEqual(c.ok, false); assert.ok(/٬/.test(c.errors.maxScore));
  assert.strictEqual(M.planSave(ok({ maxScore: '1,000', score: '1' }), [], CTX, null).ok, false);
});

console.log('\n' + n + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
