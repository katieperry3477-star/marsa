# مصفوفة الأدوار والأمان — مَرسى V2 (01.01)

**التاريخ:** 2026-11-08 · **المرجع الأعلى:** `PRODUCT_SPEC.md` §3 ← `DECISION_REGISTER.md` · **يُنفِّذ:** ADR-306 وADR-308 (`ARCHITECTURE-V2.md`) · **يحدّث:** `THREAT-MODEL-V2.md` (T-67…T-78 + ربط T-03/05/06/07/11/46/49/63).
**الوسوم:** **[م]** مثبت بتشغيل فعلي في هذا البرومبت · **[ت]** تصميم/قرار منفّذ قابل للرجوع · **[؟]** غير متحقق ويحتاج بيئة.

## 0) ما فُعل وما لم يُفعل
- **فُعل [م]:** مصفوفة دقيقة لـ33 كياناً × 3 أدوار × 4 عمليات (396 خلية) كبيانات قابلة للتنفيذ في `tests/security/access-matrix-v2.js`؛ مرجع قرار `canV2` وقواعد إدارة العضويات `canAdmin`؛ مدقّق ثوابت؛ كتالوج حالات منع مُولَّد؛ اختبارات `tests/security/access-matrix-v2.test.js` (انظر §14)؛ جداول هذه الوثيقة **مُولَّدة من البيانات** ويفحص الاختبار تطابقها.
- **لم يُفعل (عمداً):** لا قاعدة بيانات ولا سياسات RLS ولا Edge Functions ولا حساب Supabase ولا نشر ولا تعديل لكود V1. **المصفوفة حتى الآن عقد مكتوب + اختبارات على مرجع القرار، وليست سياسات خادم نافذة**: لم يُختبر أي رفض على Postgres حقيقي. ذلك في 03.03 (كتابة السياسات) و09.02 (اختبارات بجلسات حقيقية) ببيئة EX-1/EX-2 (`GATES.md` §4).

## 1) المبدأ: الخادم هو مصدر الصلاحيات
1. **الواجهة غير موثوقة.** إخفاء زر ليس صلاحية. كل خلية في §3 تُنفَّذ في Postgres (RLS + منح ضيقة + RPC) أو Edge Function؛ والواجهة تعرض فقط ما سمح به الخادم.
2. **الدور والحالة من جدول `members` في كل طلب** لا من JWT claims ولا `user_metadata` (ADR-306). تغيّر الحالة (تعليق/أرشفة) يقطع الوصول في الطلب التالي دون انتظار انتهاء جلسة.
3. **الفشل مغلق:** كيان/عملية/دور/نطاق غير معروف أو معرّف صف فاسد أو حالة غير `active` ⇒ رفض (`canV2` يفعل ذلك وتختبره AM-14…AM-17).
4. **لا حذف صلب لأي دور.** «الأرشفة» (A) = تعيين `archived_at` أو استعادته؛ لا منح `DELETE` على أي جدول، ولا `UPDATE/DELETE` على `audit_log` حتى للمطوّر (E-007).
5. **أصغر امتياز:** `anon` بلا أي منح. `authenticated` يُمنح الأدنى فقط (عمود «منح الجدول» في §4 مشتق آلياً من المصفوفة). كل كتابة على بيانات C1–C4 عبر RPC/Edge، لا INSERT/UPDATE مباشر (E-008).

### التعريفات
| الرمز | المعنى |
|---|---|
| **R** | قراءة (SELECT أو RPC قراءة) |
| **C** | إضافة (أو «تنفيذ» في كيانات الأفعال: تصدير/وضع الدعم) |
| **U** | تعديل (يشمل تثبيت الإعلان وتغيير حالة العضوية) |
| **A** | أرشفة/استعادة (حذف منطقي بأثر تدقيق). لا يوجد «D» |
| `any` | أي صف (للمطوّر وحده) · `class` صفوف شعبته · `self` صفه/مالكه فقط · `auth` أي عضو نشط (للقراءة العامة) |
| `@rpc` / `@edge` | المسار الوحيد للعملية (دالة Postgres / Edge Function). بلا لاحقة = RLS مباشر |

**أصناف البيانات:** C0 محتوى الصف · C1 بيانات شخصية · C2 حضور/درجات · C3 مالية · C4 هوية/أسرار/نظام · SELF حالة ذاتية · SYS نظام. المشتق يرث أعلى حساسية (`THREAT-MODEL-V2.md` §2).

## 2) الفاعلون والحالات
| الفاعل | الوصف | ملاحظة |
|---|---|---|
| **المطوّر** | حساب واحد (فهرس فريد جزئي)، `class_id` فارغ، نطاق `any` | أعلى ثقة؛ لا يُنشأ ثانٍ بأي مسار (AM-11)؛ يُحمى بـMFA للمزود خارجياً (T-47) |
| **ممثل الصف** | عدة ممثلين بصلاحيات متساوية، نطاق `class` | لا يدير ممثلاً ولا مطوّراً ولا يرى صف المطوّر ولا `audit_log` ولا النسخ ولا الدعم |
| **الطالب** | نطاق `self` للبيانات الشخصية و`class` لمحتوى الصف الحي | لا كتابة إلا حالة قراءته واشتراكه |
| عضو `pending/suspended/archived` | عضوية غير مفعّلة/موقوفة/مغادرة | **رفض كل شيء** (AM-14) |
| `anonymous` / دور غير معروف (مدرّس/مدير مستقبلاً) | بلا عضوية | رفض كل شيء (AM-15). أدوار المستقبل تحتاج صفاً جديداً في المصفوفة وسياسات جديدة قبل أي وصول |
| ممثل/طالب صف آخر | صف `class_id` مختلف | رفض (AM-07، AM-08). الإصدار الأول شعبة واحدة لكن كل سياسة تتحقق من `class_id` (AM-27) |
| المطوّر في **وضع الدعم** | يعرض بصفة حساب دون توكن بالنيابة (ADR-308) | حقوقه الأصلية لا تتغير؛ الكتابة أثناء جلسة دعم مفتوحة تتطلب تأكيداً يفرضه الخادم (§6، AM-20) |

## 3) المصفوفة
**اقرأ الخلية:** `R:class C:class@rpc …` = القراءة لصفوف الشعبة مباشرة، والإضافة لصفوفها عبر RPC. `—` = لا شيء. الأدوار الثلاثة بالترتيب: المطوّر · الممثل · الطالب.

<!-- GEN:MATRIX:START -->
| الكيان | الصنف | المطوّر | ممثل الصف | الطالب |
|---|---|---|---|---|
| `classes` — الشعبة | C0 | R:any U:any@rpc | R:class | R:class |
| `members` — العضويات (الدور والحالة) | C4 | R:any C:any@edge U:any@edge A:any@edge | R:class C:class@edge U:class@edge A:class@edge | R:self |
| `students` — ملف الطالب (اسم، هاتف، ميلاد، غياب سابق) | C1 | R:any C:any@rpc U:any@rpc A:any@rpc | R:class C:class@rpc U:class@rpc A:class@rpc | R:self |
| `activation_codes` — رموز التفعيل (بصمات HMAC) | C4 | R:any@rpc C:any@edge A:any@edge | R:class@rpc C:class@edge A:class@edge | — |
| `activation_attempts` — محاولات التفعيل وحدود المعدل | SYS | — | — | — |
| `attendance_sheets` — كشوف الحضور اليومية (الاعتماد) | C2 | R:any C:any@rpc U:any@rpc A:any@rpc | R:class C:class@rpc U:class@rpc A:class@rpc | — |
| `attendance_records` — سجلات الحضور والغياب | C2 | R:any C:any@rpc U:any@rpc A:any@rpc | R:class C:class@rpc U:class@rpc A:class@rpc | R:self |
| `grades` — الدرجات | C2 | R:any C:any@rpc U:any@rpc A:any@rpc | R:class C:class@rpc U:class@rpc A:class@rpc | R:self |
| `exams` — الامتحانات | C0 | R:any C:any U:any A:any | R:class C:class U:class A:class | R:class |
| `schedule_entries` — الجدول الدراسي | C0 | R:any C:any U:any A:any | R:class C:class U:class A:class | R:class |
| `preps` — التحاضير | C0 | R:any C:any U:any A:any | R:class C:class U:class A:class | R:class |
| `prep_status` — حالة التحضير (تم/لم يتم/تأجل) | C0 | R:any C:any U:any A:any | R:class C:class U:class A:class | R:class |
| `homework` — الواجبات | C0 | R:any C:any U:any A:any | R:class C:class U:class A:class | R:class |
| `announcements` — الإعلانات | C0 | R:any C:any U:any A:any | R:class C:class U:class A:class | R:class |
| `file_objects` — سجلات المرفقات (بيانات وصفية) | C0 | R:any C:any@rpc U:any@rpc A:any@rpc | R:class C:class@rpc U:class@rpc A:class@rpc | R:class |
| `storage_objects` — ملفات التخزين (bucket خاص) | C0 | R:any@rpc C:any@rpc | R:class@rpc C:class@rpc | R:class@rpc |
| `cost_items` — بنود التكاليف | C3 | R:any C:any@rpc U:any@rpc A:any@rpc | R:class C:class@rpc U:class@rpc A:class@rpc | R:self |
| `cost_assignments` — إسناد البنود للطلاب وحالتها | C3 | R:any C:any@rpc U:any@rpc A:any@rpc | R:class C:class@rpc U:class@rpc A:class@rpc | R:self |
| `payments` — سجل الدفعات | C3 | R:any C:any@rpc A:any@rpc | R:class C:class@rpc A:class@rpc | R:self |
| `cost_stats` — إحصاءات التكاليف المجمّعة (view) | C3 | R:any | R:class | — |
| `notifications` — الإشعارات | C0 | R:any | R:class | R:class |
| `notification_reads` — حالة قراءة الإشعار (ذاتية) | SELF | R:self C:self U:self | R:self C:self U:self | R:self C:self U:self |
| `push_subscriptions` — اشتراكات Push (ذاتية) | SELF | R:self C:self U:self A:self | R:self C:self U:self A:self | R:self C:self U:self A:self |
| `support_sessions` — جلسات وضع الدعم | C4 | R:self C:self@rpc U:self@rpc | — | — |
| `audit_log` — سجل التدقيق | C4 | R:any | — | — |
| `record_history` — سجل تعديلات السجلات الأكاديمية (view) | C2 | R:any | R:class | — |
| `app_meta` — إصدار المخطط والحد الأدنى للعميل | SYS | R:auth | R:auth | R:auth |
| `class_settings` — إعدادات الشعبة (قاعدة المعدل، تسميات) | C0 | R:any U:any@rpc | R:class U:class@rpc | R:class |
| `system_settings` — إعدادات النظام (حصص، نسخ) | C4 | R:any U:any@rpc | — | — |
| `storage_usage` — لقطة استخدام التخزين والحصص | SYS | R:any@rpc | R:class@rpc | — |
| `roster_export` — تصدير قائمة الطلاب (CSV) | C1 | C:any@rpc | C:class@rpc | — |
| `backup_export` — نسخة احتياطية كاملة | C4 | C:any@rpc | — | — |
| `backup_restore` — استعادة نسخة | SYS | — | — | — |
<!-- GEN:MATRIX:END -->

## 4) الإنفاذ لكل كيان (مشتق من البيانات نفسها)
«منح الجدول» = ما يُمنح لدور Postgres `authenticated` (الأدوار التطبيقية تُميَّز بالسياسات لا بأدوار Postgres)؛ `—` = لا منح، فكل الوصول عبر RPC/Edge. «فلتر الطالب»: `live` = غير مؤرشف · `approved` = من كشف معتمد · `assigned` = مسند إليه · `audience` = موجّه لجمهوره · `parent` = أصله مقروء له.

<!-- GEN:ENFORCE:START -->
| الكيان | المسار | منح الجدول لـ`authenticated` | فلتر قراءة الطالب | قيود الهدف | تدقيق | `version` | ملاحظة |
|---|---|---|---|---|---|---|---|
| `classes` | rls | select | — | — | نعم | — | شعبة واحدة تُبذر بالـmigration؛ الإنشاء/الأرشفة غير منفّذين في الإصدار الأول (قابلية توسع فقط). |
| `members` | rpc | select | — | developer.C→{rep,student} ؛ developer.U→{rep,student} ؛ developer.A→{rep,student} ؛ rep.R→{student,rep} ؛ rep.C→{student} ؛ rep.U→{student} ؛ rep.A→{student} | نعم | — | لا كتابة مباشرة. الدور غير قابل للتعديل بأي مسار؛ تغيير الدور = عضوية جديدة. الممثل لا يرى صف المطوّر ولا يدير ممثلاً. |
| `students` | rls | select | — | — | نعم | نعم | الطالب يقرأ سطره فقط ولا يعدّله (لا منح كتابة). الاستيراد الجماعي RPC بحد دفعة. |
| `activation_codes` | edge | — | — | developer.R→{rep,student} ؛ developer.C→{rep,student} ؛ developer.A→{rep,student} ؛ rep.R→{student} ؛ rep.C→{student} ؛ rep.A→{student} | نعم | — | لا منح على الجدول لأي دور. القراءة = بيانات وصفية فقط (الحالة، الانتهاء، المُصدِر) عبر RPC؛ لا بصمة ولا رمز. لا تعديل: الاستهلاك للخادم وحده. |
| `activation_attempts` | system | — | — | — | — | — | للخادم/`service_role` فقط؛ عناوين مُجزَّأة بملح يومي. |
| `attendance_sheets` | rls | select | — | — | نعم | نعم | الاعتماد وتعديل كشف سابق عبر RPC ذري مع تدقيق. الطالب لا يرى رأس الكشف. |
| `attendance_records` | rls | select | approved | — | نعم | نعم | الطالب يرى سجله هو من كشوف معتمدة فقط، لا مسودات. |
| `grades` | rls | select | live | — | نعم | نعم |  |
| `exams` | rls | select+insert+update | live | — | — | نعم |  |
| `schedule_entries` | rls | select+insert+update | live | — | — | نعم |  |
| `preps` | rls | select+insert+update | live | — | — | — |  |
| `prep_status` | rls | select+insert+update | live | — | — | — |  |
| `homework` | rls | select+insert+update | live | — | — | — |  |
| `announcements` | rls | select+insert+update | live | — | — | — | التثبيت = تعديل. النشر يولّد إشعاراً بمشغّل خادمي لا بكتابة العميل. |
| `file_objects` | rls | select | parent | — | نعم | — | الإضافة عبر RPC لفحص الحصة والنوع. الطالب يرى مرفقاً فقط إن كان الأصل (تحضير/واجب/امتحان) مقروءاً له. |
| `storage_objects` | storage | — | parent | — | — | — | روابط موقّعة قصيرة العمر فقط؛ لا listing. لا تعديل (الاستبدال = كائن جديد). الإزالة الفعلية صيانة خادمية لا دور تطبيقي. |
| `cost_items` | rls | select | assigned | — | نعم | نعم | الطالب يرى فقط البنود المسندة إليه. |
| `cost_assignments` | rls | select | live | — | نعم | نعم |  |
| `payments` | rls | select | live | — | نعم | نعم | سجل للإلحاق فقط: لا تعديل. التصحيح = إبطال (أرشفة بسبب) + دفعة جديدة. (E-009) |
| `cost_stats` | view | select | — | — | — | — | `security_invoker`. الطالب لا يقرأ أي تجميع (يكشف أعداد زملائه). |
| `notifications` | rls | select | audience | — | — | — | يُنشئها مشغّل/RPC خادمي فقط؛ لا دور يكتبها. حمولة Push بلا بيانات شخصية. |
| `notification_reads` | rls | select+insert+update | — | — | — | — | استثناء مقصود: الطالب يكتب حالة قراءته هو فقط. |
| `push_subscriptions` | rls | select+insert+update | — | — | — | — | لا دور يقرأ اشتراك غيره (حتى المطوّر)؛ `send-push` وحدها تقرأها بمفتاح الخدمة. |
| `support_sessions` | rpc | select | — | — | نعم | — | ADR-308: عرض بصفة؛ لا توكن بالنيابة. لا يُعرض للمستهدف (E-011). |
| `audit_log` | rls | select | — | — | — | — | للإلحاق فقط بمشغّلات/RPC خادمية؛ لا INSERT/UPDATE/DELETE لأي دور حتى المطوّر. |
| `record_history` | view | select | — | — | — | — | يلبّي «سجل تعديل ومن قام به» (المواصفة §5) دون فتح `audit_log` للممثل: حضور/درجات فقط. |
| `app_meta` | rls | select | — | — | — | — | قراءة لكل عضو نشط؛ الكتابة بالـmigrations فقط. |
| `class_settings` | rls | select | — | — | نعم | نعم |  |
| `system_settings` | rls | select | — | — | نعم | — |  |
| `storage_usage` | rpc | — | — | — | — | — |  |
| `roster_export` | rpc | — | — | — | نعم | — | «C» = تنفيذ التصدير. كل تصدير يُدقَّق (T-63). |
| `backup_export` | rpc | — | — | — | نعم | — |  |
| `backup_restore` | system | — | — | — | — | — | لا يملكها أي دور تطبيقي: سكربت محلي بمفتاح خدمة إلى مشروع منفصل (ADR-315). |
<!-- GEN:ENFORCE:END -->

## 5) إدارة العضويات والرموز (Edge `issue-code`/`set-member-status` وRPC)
<!-- GEN:ADMIN:START -->
| الإجراء | المطوّر على | الممثل على (صفه فقط) | الطالب على |
|---|---|---|---|
| إصدار رمز تفعيل/إعادة تفعيل (`issue_code`) | rep، student | student | — |
| إبطال رمز (`revoke_code`) | rep، student | student | — |
| تعليق عضوية (`suspend`) | rep، student | student | — |
| إعادة تفعيل عضوية (`reactivate`) | rep، student | student | — |
| أرشفة عضوية (مغادرة) (`archive_member`) | rep، student | student | — |
| فتح وضع الدعم على حساب (`open_support`) | rep، student | — | — |
| تغيير دور عضوية (`change_role`) | — | — | — |
| إنشاء مطوّر (`create_developer`) | — | — | — |
<!-- GEN:ADMIN:END -->

- **الدور ثابت:** لا مسار يغيّر `members.role`؛ تغيير الدور = عضوية جديدة (AM-30). `members.role` و`class_id` و`created_by` أعمدة غير قابلة للتعديل بمشغّل [ت].
- **عضوية نشطة واحدة لكل مستخدم Auth** (فهرس فريد جزئي) كي لا تتداخل صلاحيات مطوّر/ممثل/طالب [ت] (T-77).
- **الممثل لا يعلّق نفسه ولا ممثلاً آخر**؛ قفل الإدارة بين ممثلين يُحل بالمطوّر فقط (T-68).
- **تعليق/أرشفة** يمرّان بـ`set-member-status` الذي يرفع `session_epoch` ويبطل التجديد (ADR-307)؛ يتحقق الخادم من الحالة في كل طلب فلا يبقى وصول بجلسة قائمة (T-72).
- **إصدار الرمز**: لمستلم محدد؛ المُصدِر يرى الرمز مرة واحدة؛ كل إصدار/إبطال/فشل يُدقَّق؛ سقف رموز نشطة لكل مستلم يُحدَّد في 01.03.

## 6) وضع الدعم (ADR-308) — قواعد الصلاحيات
1. **المطوّر وحده** يفتح جلسة (`support_sessions`: C/R/U بنطاق `self`؛ لا أرشفة ولا حذف). الممثل والطالب بلا أي وصول لهذا الجدول (AM-21).
2. العرض «بصفة» حساب = **الواجهة تستعلم بالتصفية نفسها**؛ لا يُصدر الخادم توكناً ولا يغيّر كلمة المرور/PIN. **حد معلن:** العرض لا يثبت صحة RLS؛ RLS تُختبر بجلسات مستخدمين حقيقيين (09.02).
3. **الكتابة أثناء جلسة دعم مفتوحة** (`ends_at` لم يمضِ): كل RPC كتابة يرفض ما لم يصله `support_confirm = true` المرتبط بالجلسة، **والرفض في الخادم لا في الواجهة** (AM-20، T-73). القراءة لا تتطلب تأكيداً.
4. كل قراءة حساسة وكل كتابة أثناء الدعم تُدقَّق بـ`actor` = المطوّر و`support_target` = الحساب المعروض (ADR-314). انتهاء تلقائي للجلسة.
5. لا كاش لعرض الدعم ولا لـ`audit_log` على الجهاز (T-65).
6. المستهدف **لا يرى** أن جلسة دعم فُتحت على حسابه في الإصدار الأول (E-011)؛ الشفافية مع القاصرين/الأولياء تُحال إلى DEC-11 القانوني.

## 7) الأسطح غير الجدولية (كل سطح مشتق يلتزم بالمصفوفة)
| السطح | القاعدة | مصدر الإنفاذ |
|---|---|---|
| **Views** (`cost_stats`, `record_history`) | `security_invoker`؛ بلا طالب؛ الممثل بنطاق صفه؛ لا يكشف تجميعاً عبر الطلاب لطالب | 03.03 |
| **Storage** (`class-files`) | bucket خاص؛ مسار يبدأ بـ`class_id`؛ لا listing؛ قراءة الطالب عبر رابط موقّع قصير العمر من RPC يتحقق أن الأصل (تحضير/واجب/امتحان) مقروء له (`parent`)؛ لا تعديل (الاستبدال = كائن جديد) | 06.02 |
| **RPC/Edge** | كل دالة `security definer` بـ`search_path` فارغ، وتبدأ بفحص دور/حالة/نطاق **مطابق لـ`canV2`/`canAdmin`**، ثم تدقّق في المعاملة نفسها (فشل التدقيق يُفشل العملية) | 03.03، 04.x |
| **Realtime** | لا Broadcast ولا Presence حاملة بيانات؛ لا جداول C1–C3 في publication [ت]؛ التحديث بالسحب (ADR-309). [؟] سلوك Realtime مع RLS لم يُجرَّب | 03.04، 09.02 |
| **Push** | حمولة بلا بيانات شخصية؛ `send-push` تتحقق من دور المُرسِل وتحدّ المعدل؛ اشتراك كل عضو ملكه وحده | 07.03 |
| **الكاش/Service Worker** | لا كاش لـ`audit_log` وعرض الدعم؛ الطالب يخزّن محتوى الصف وسجلاته فقط؛ مسح عند أول 401/403 | 07.04، 02.03 |
| **التصدير** | `roster_export` للمطوّر/الممثل فقط، مدقَّق، بتعقيم خلايا `= + - @`؛ النسخة الكاملة للمطوّر وحده؛ الاستعادة خارج التطبيق | 05.01، 09.05 |
| **`auth.users`** | لا دور تطبيقي يقرأ أو يكتب؛ الدوال الخادمية وحدها | 04.x |

## 8) الثوابت (تُختبر آلياً في `access-matrix-v2.test.js`)
**I-01** لا حذف ولا منح DELETE · **I-02** `anon` بلا منح · **I-03** نطاق `any` للمطوّر وحده · **I-04** الطالب لا يكتب إلا حالته الذاتية · **I-05** قراءة الطالب لبيانات C1–C4 `self` فقط · **I-06** الممثل لا يملك C4 إلا الأعضاء/الرموز بحد «طالب صفه» · **I-07** `audit_log` قراءة للمطوّر فقط · **I-08** كتابات C1–C3 عبر RPC فقط · **I-09** `members`/`activation_codes`/`audit_log`/`support_sessions`/`activation_attempts` بلا منح كتابة مباشرة · **I-10** الدفعات بلا تعديل · **I-11** لا استعادة نسخ من التطبيق · **I-12** اشتراكات Push ذاتية للجميع · **I-13** كل كتابة C1–C4 مدقَّقة · **I-14** فلتر طالب على كل كيان C0 يقرؤه · **I-15** الطالب لا يقرأ `cost_stats`/`record_history`/`audit_log`/`activation_codes`/`attendance_sheets`/`system_settings` · **I-16** لا تغيير دور ولا إنشاء مطوّر.
المدقّق `validate()` يصنّف انتهاكاته بالرموز V1…V22؛ وكل ضعف متعمد في طفرات §10 يكشفه.

## 9) قوالب التنفيذ لـ03.03 [ت — غير منفّذة، لا تُنسخ آلياً]
```sql
-- دوال مساعدة (مخطط private، لا تُكشف عبر API)
create function private.me() returns table(member_id uuid, role text, class_id uuid)
language sql stable security definer set search_path = '' as $$
  select id, role, class_id from public.members where user_id = (select auth.uid()) and status = 'active' $$;
-- مثال: درجات (القراءة مباشرة؛ الكتابة RPC فقط ⇒ لا سياسة insert/update)
create policy grades_read on public.grades for select to authenticated using (
  exists (select 1 from private.me() m where
    m.role = 'developer'
    or (m.role = 'rep' and m.class_id = grades.class_id)
    or (m.role = 'student' and m.class_id = grades.class_id and m.member_id = grades.student_id and grades.archived_at is null)));
-- members: الممثل لا يرى صف المطوّر
create policy members_read on public.members for select to authenticated using (
  exists (select 1 from private.me() m where m.role = 'developer'
    or (m.role = 'rep' and m.class_id = members.class_id and members.role in ('student','rep'))
    or (m.member_id = members.id)));
revoke all on all tables in schema public from anon, authenticated;   -- ثم منح الأدنى كما في «منح الجدول» §4
```
كل كتابة حساسة: `create function rpc_<action>(...) ... security definer set search_path = ''` تستدعي فحصاً مطابقاً لـ`canV2` ثم تكتب `audit_log` في المعاملة نفسها.

## 10) اختبارات المنع
### 10-أ) المنفَّذة فعلاً [م] — مستوى المصفوفة (`node tests/security/access-matrix-v2.test.js`)
| المعرّف | ما يمنعه/يثبته |
|---|---|
| AM-01…AM-04 | طالب لا يقرأ درجات/دفعات/غيابات/تكاليف/ملف زميل ولا القوائم والإحصاءات والتدقيق والرموز |
| AM-05، AM-06 | طالب لا يكتب/يعدّل/يؤرشف أي كيان أكاديمي أو مالي أو إداري؛ يكتب حالة قراءته/اشتراكه هو فقط |
| AM-07، AM-08 | ممثل/طالب صف آخر مرفوض في كل كيان وعملية |
| AM-09…AM-13 | ممثل لا يصعّد: لا يُنشئ/يعدّل/يؤرشف ممثلاً أو مطوّراً ولا يصدر لهما رمزاً ولا يرى صف المطوّر؛ لا أحد يعدّل بصمة رمز |
| AM-14، AM-15 | عضوية غير نشطة، ومجهول/دور غير معروف/كائن فارغ ⇒ رفض الكل |
| AM-16، AM-17 | عملية/كيان غير معروف (حتى `__proto__`) ومعرّف صف فاسد ⇒ رفض |
| AM-18، AM-19 | الطالب لا يرى مؤرشفاً ولا مسودة كشف ولا بنداً غير مسند ولا مرفقاً لأصل غير مقروء ولا إشعار غير جمهوره |
| AM-20، AM-21 | كتابة المطوّر أثناء دعم مفتوح بلا تأكيد مرفوضة؛ الدعم لا يمنح غير المطوّر شيئاً |
| AM-22، AM-23 | `audit_log` بلا كتابة حتى للمطوّر؛ المطوّر عبر الصفوف والممثل لا |
| AM-24، AM-25، AM-26 | سلوك الممثل المسموح والممنوع؛ `app_meta` |
| AM-27 | كل نطاق `class` يتحقق من `class_id` (جاهزية الشعب المتعددة) |
| AM-28…AM-30 | قواعد الإدارة: من يصدر/يعلّق/يؤرشف/يفتح دعماً لمن؛ لا تغيير دور ولا مطوّر ثانٍ |
| AM-31 | المنح المشتقة: لا INSERT/UPDATE مباشر إلا C0 والحالة الذاتية |
| AM-32، AM-33 | دفاع بالعمق: مصفوفة مُفسَدة (نطاق `any` لممثل، خلية فاسدة، دور مفقود) ⇒ الـoracle يرفض لا يسمح |
| طفرات (48) | كل ضعف متعمد في المصفوفة/القواعد يكشفه المدقّق (§8) |
| كتالوج | حالات منع مُولَّدة من الـoracle (انظر الإحصاء أدناه) في `tests/security/access-v2-deny-cases.json` لتعيد 03.03/09.02 تشغيلها على RLS حقيقية |
| مطابقة مستقلة | تشفير ثانٍ للقواعد في الاختبار نفسه يُقارَن بكل الخلايا (396) |

<!-- GEN:STATS:START -->
**الإحصاء المولَّد:** 33 كياناً × 3 أدوار × 4 عمليات = 396 خلية · 2025 حالة في كتالوج المنع (1772 منع، 253 سماح) · بصمة المصفوفة SHA-256: `b43aba9d80a1616bd14ade8ca49d8c795621a99292983f806c94b7fd95628364`

| صنف الحالة | منع | سماح |
|---|---|---|
| base | 202 | 194 |
| status | 970 | 0 |
| support-no-confirm | 59 | 0 |
| support-confirmed | 0 | 59 |
| cross-class | 104 | 0 |
| actor-no-class | 104 | 0 |
| target | 19 | 0 |
| not-self | 31 | 0 |
| archived-row | 14 | 0 |
| filter | 5 | 0 |
| anonymous | 132 | 0 |
| unknown-role | 132 | 0 |
<!-- GEN:STATS:END -->

### 10-ب) المخطّطة ولم تُنفَّذ [؟] — مستوى قاعدة البيانات (لا Postgres هنا)
| المعرّف | الفحص | يُنفَّذ في |
|---|---|---|
| L-01 | كل جدول في `public` عليه RLS؛ lint يفشل إن وجد جدولاً بلا RLS (T-49) | 03.03 |
| L-02 | `anon` بلا منح على أي جدول/دالة عدا `activate-code` | 03.03 |
| L-03 | المنح الفعلية = `tests/security/access-v2-expected-grants.json` (لا زيادة ولا نقص؛ لا DELETE) | 03.03 |
| L-04 | كل `security definer`: `search_path` فارغ + فحص دور/حالة داخلي | 03.03 |
| L-05 | كل view على جدول حساس `security_invoker` | 03.03 |
| L-06 | `audit_log`: مشغّل يمنع UPDATE/DELETE حتى لـ`service_role` العادي؛ لا INSERT مباشر | 03.03 |
| L-07 | `members`: لا منح كتابة؛ فهرس فريد لمطوّر واحد؛ فريد جزئي لعضوية نشطة لكل مستخدم | 03.02 |
| L-08 | إعادة تشغيل `access-v2-deny-cases.json` بجلسات مستخدمين حقيقيين (مطوّر/ممثلان/طالبان/موقوف/صف آخر) | 09.02 |
| L-09 | أعمدة ثابتة (`class_id`, `role`, `created_by`) ترفض التعديل؛ mass-assignment مرفوض (T-76) | 03.03 |
| L-10 | Storage: bucket خاص، مسار `class_id/…`، لا listing، روابط موقّعة قصيرة | 06.02 |
| L-11 | لا جدول C1–C3 في publication الـRealtime (T-70) | 03.04 |
| L-12 | كل RPC حساس يفشل كاملاً إن فشل إدراج التدقيق (ذرية، T-74) | 03.03 |
| L-13 | RPC الكتابة أثناء جلسة دعم مفتوحة ترفض بلا `support_confirm` (T-73) | 04.04 |
| L-14 | طفرات على سياسات SQL تكشفها الاختبارات (T-49) | 09.02 |

## 11) ربط التهديدات
| التهديد | الاختبار المنفَّذ [م] | اختبار الخادم المخطط [؟] |
|---|---|---|
| T-03 IDOR بين الطلاب | AM-01…AM-04 | L-08 |
| T-05 ممثل يقرأ صفاً آخر | AM-07، AM-08، AM-27 | L-08 |
| T-06 رفع صلاحية ذاتي | AM-09…AM-13 | L-07، L-09 |
| T-07 مجهول يمر كمسجَّل | AM-14، AM-15 | L-02 |
| T-11 طالب يكتب سجله | AM-05، AM-06 | L-03، L-08 |
| T-46 إساءة وضع الدعم | AM-20، AM-21 | L-13 |
| T-49 جدول بلا RLS/منح زائدة | AM-31، I-01…I-09 | L-01…L-03، L-14 |
| T-63 كشف بيانات الطلاب/تصدير | AM-03، AM-04، AM-25 | L-08 |
| T-67…T-78 (جديدة) | انظر `THREAT-MODEL-V2.md` §4-ب | L-01…L-14 |

## 12) قرارات المنفّذ في هذا البرومبت (ليست قرارات مستخدم؛ كلها قابلة للرجوع)
| ID | القرار | لماذا | الرجوع |
|---|---|---|---|
| **E-007** | أربع عمليات R/C/U/A بلا حذف صلب؛ الأرشفة = `archived_at` عبر RPC؛ لا DELETE ولا تعديل لـ`audit_log` لأي دور | قاعدة افتراضية 7 في سجل القرارات + ADR-314 | تعديل صف في `access-matrix-v2.js` وإعادة التوليد |
| **E-008** | كتابات C1–C3 والأعضاء والرموز والإعدادات الحساسة عبر RPC/Edge فقط؛ المحتوى C0 (إعلانات، تحاضير…) مباشر بـRLS | ذرية مع التدقيق (ADR-314) ويسدّ mass-assignment (T-76) | نقل عملية إلى `rls` بتغيير لاحقتها (المدقّق V11 ينبّه) |
| **E-009** | سجل الدفعات للإلحاق فقط: لا تعديل؛ التصحيح = إبطال بسبب + دفعة جديدة | حماية أثر مالي بين ممثلين متساوين (T-78)؛ المواصفة تطلب «سجل دفعات» ولا تشترط التعديل | منح U للدفعات يتطلب تغيير I-10 والاختبار عمداً |
| **E-010** | الممثل يعلّق/يؤرشف/يعيد تفعيل **طلاب صفه** ويصدر لهم الرموز (المواصفة: إدارة بياناتهم ورمز جديد وأرشفة عند المغادرة)؛ لا يفتح دعماً ولا يدير ممثلاً؛ **الطالب لا يعدّل ملفه** (يطلب التصحيح من الممثل) | أدنى امتياز يحقق المواصفة | تعديل `adminRules`/الخلية |
| **E-011** | وضع الدعم لا يُعرض للمستهدف؛ `support_sessions` للمطوّر وحده؛ فرض تأكيد الكتابة في الخادم | ADR-308 يطلب شريطاً للمطوّر لا إشعاراً للمستهدف؛ الشفافية مسألة قانونية DEC-11 | إضافة قراءة `self` للمستهدف بصف جديد |
| **E-012** | الطالب يقرأ الصفوف الحية فقط (غير مؤرشفة) ومن كشوف معتمدة وما أُسند إليه؛ الممثل والمطوّر يرون المؤرشف ويستعيدونه؛ `record_history` للممثل بدل فتح `audit_log` | يمنع تسرب المسودات ويلبّي «سجل تعديل» (§5 المواصفة) | تغيير `studentFilter` |

**فجوات في المواصفة سُدّت بقرار أعلاه ولم تُسأل:** من يؤرشف الطالب (E-010)؛ هل يعدّل الطالب ملفه (E-010)؛ تصحيح دفعة (E-009)؛ هل يعلم المستهدف بالدعم (E-011)؛ ما يراه الطالب من المؤرشف/المسودة (E-012).

## 13) مفتوح وحدود
- **قانوني خارجي (DEC-11، T-22، T-35):** الممثل قد يكون زميلاً قاصراً ويرى هواتف/درجات/غيابات/مبالغ صفه كله بحكم المواصفة. المصفوفة تفرض أدنى امتياز ضمن ذلك وتدقّق كل فعل، **لا تعالج الخطر القانوني**. يبقى شرط GX-REAL.
- **ممثل خبيث لصفه** يرى ويعدّل صفه (مقبول موثق، `THREAT-MODEL-V2.md` §5)؛ التخفيف: إلحاق الدفعات، `record_history`، حذف منطقي، تدقيق.
- **غير مختبر:** سلوك RLS/RPC الفعلي، Realtime مع RLS، Storage policies، Edge Functions، Auth (إبطال الجلسات)، أي جهاز. كلها مخطّطة في §10-ب.
- **الأدوار المستقبلية** (مدرّس/مدير/شعب متعددة) غير ممثَّلة؛ تدخل بصف جديد في المصفوفة وطفرات جديدة قبل أي وصول.
- الصور المرجعية: لا شاشات V2 بعد؛ الوثيقة لا تغيّر شيئاً مرئياً في التطبيق (انظر `TEST_EVIDENCE.md`).

## 14) التحقق الفعلي
**2026-11-08 · Ubuntu 24 · Node v22.23.4 · Chromium headless · بلا شبكة.**
| الأمر | النتيجة |
|---|---|
| `node tests/security/access-matrix-v2.test.js` | 152 نجاح، 0 فشل |
| طفرات: 48 على المصفوفة والقواعد + 6 على `canV2` نفسه | كلها مكتشفة (السابعة، حارس `any`، أضاف AM-32) |
| `node tests/security/generate-access-v2.js --check` | متطابق |
| `node <file>` لكل `tests/**/*.test.js` | 27 ملفاً، 984 PASS، 0 فاشل |
| `check-architecture.js` / `check-traceability.js` | 42/0 · 21/0 |
| Playwright الأساسي (4 ملفات) | 81 / 136 / 11 / 24 — 0 فشل |
| بصمات الكود | 14/14 OK (لم يُعدَّل كود تشغيل) |
**لم يُختبر:** كل ما في §10-ب (قاعدة بيانات/RLS/RPC/Edge/Storage/Realtime/Auth/أجهزة).

## 13) ملحق 01.02 — توافق المخطط مع المصفوفة
- تطابق مُختبَر آلياً (DB-01…DB-15): كل كيان جدولي في المصفوفة له جدول بالصنف نفسه، و`version` حيث وُسم فقط، وأرشفة حيث وُجدت عملية `A`، و`class_id` في كل صفّي.
- **انحراف مقصود واحد (E-013):** `record_history` عرض بوابة فوق جدول خاص `private.record_revisions` بدل جدول عام؛ الصلاحية لم تتغيّر (مطوّر وممثل صفه فقط، الطالب لا يقرأ) وأُثبت ذلك في DB-217…219.
- `storage_usage` دالة (`private.storage_usage`) لا جدول، و`roster_export` و`backup_export` و`backup_restore` عمليات Edge لا جداول.
- السياسات الفعلية لم تُكتب (03.03)؛ اختبارات الدخان في DB-213…223 تستعمل سياسات اختبارية مؤقتة داخل معاملات متراجَع عنها.
