// يفحص اتساق ARCHITECTURE-V2 / ADR-V2 / THREAT-MODEL-V2 / GATES مع PROMPT_INDEX وSTATE.json والمصفوفة وبصمات الكود.
// التشغيل: node docs/execution-v2/tools/check-architecture.js   (بلا شبكة، لا يعدّل شيئاً)
'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const D = path.join(__dirname, '..'), ROOT = path.join(D, '..', '..');
const rd = (p) => fs.readFileSync(p, 'utf8');

// ---------- دوال نقية (تُختبر أيضاً على نصوص مُفسَدة عمداً) ----------
const promptIds = (pi) => new Set((pi.match(/`(\d\d\.\d\d)`/g) || []).map((s) => s.replace(/`/g, '')));
const adrSections = (s) => { const out = {}; const re = /^## (ADR-3\d\d) — .*$/gm; let m, idx = []; while ((m = re.exec(s))) idx.push([m[1], m.index]); idx.forEach((e, i) => { out[e[0]] = s.slice(e[1], i + 1 < idx.length ? idx[i + 1][1] : s.length); }); return out; };
const ADR_IDS = Array.from({ length: 21 }, (_, i) => 'ADR-' + (301 + i));
const VERDICTS = ['معتمد بتعديل', 'معتمد جزئياً', 'مستبدل جزئياً', 'معتمد', 'مستبدل'];
const checkAdrSections = (s, prompts) => { const sec = adrSections(s), bad = [];
  for (const id of ADR_IDS) { const t = sec[id]; if (!t) { bad.push(id + ':مفقود'); continue; }
    if (!/\*\*الحالة:\*\*/.test(t)) bad.push(id + ':بلا حالة'); if (!/حدّ الرجوع/.test(t)) bad.push(id + ':بلا حد رجوع'); if (!/يُتحقق في/.test(t)) bad.push(id + ':بلا يُتحقق في');
    const ps = (t.match(/يُتحقق في:?\*{0,2}[^\n]*/) || [''])[0].match(/\b\d\d\.\d\d\b/g) || []; if (!ps.length || ps.some((p) => !prompts.has(p))) bad.push(id + ':برومبت غير صالح'); }
  return bad; };
const dispositionRows = (s) => { const a = s.indexOf('## 2) حكم ADR-201'); const b = s.indexOf('\n## 3)', a); return s.slice(a, b < 0 ? undefined : b).split('\n').filter((l) => /^\| 2\d\d \|/.test(l)).map((l) => l.split('|').slice(1, -1).map((c) => c.trim())); };
const checkDisposition = (s) => { const rows = dispositionRows(s), bad = [];
  for (let n = 201; n <= 217; n++) { const r = rows.find((x) => x[0] === String(n)); if (!r) { bad.push(n + ':مفقود'); continue; }
    if (!VERDICTS.includes(r[1])) bad.push(n + ':حكم غير معروف'); if (!(/ADR-3\d\d/.test(r[2]) || /GATES\.md/.test(r[2]))) bad.push(n + ':بلا مقابل');
    (r[2].match(/ADR-3\d\d/g) || []).forEach((a) => { if (!ADR_IDS.includes(a)) bad.push(n + ':' + a + ' غير موجود'); }); }
  return bad; };
const tmOldRows = (s) => { const a = s.indexOf('## 3) حكم'); const b = s.indexOf('\n## 4)', a); return s.slice(a, b < 0 ? undefined : b).split('\n').filter((l) => /^\| T-\d\d /.test(l)).map((l) => l.split('|').slice(1, -1).map((c) => c.trim())); };
const tmNewRows = (s) => { const a = s.indexOf('## 4) تهديدات جديدة'); const b = s.indexOf('\n## 5)', a); return s.slice(a, b < 0 ? undefined : b).split('\n').filter((l) => /^\| T-\d\d /.test(l)).map((l) => l.split('|').slice(1, -1).map((c) => c.trim())); };
const checkThreats = (s, prompts) => { const bad = [], old = tmOldRows(s), nw = tmNewRows(s);
  for (let n = 1; n <= 39; n++) { const id = 'T-' + String(n).padStart(2, '0'); const r = old.find((x) => x[0].startsWith(id + ' ')); if (!r) { bad.push(id + ':مفقود'); continue; } if (!['✅', '🟡', '⚠', '📜', '⛔'].includes(r[1])) bad.push(id + ':حكم'); if (r[2].length < 8) bad.push(id + ':فارغ'); }
  for (let n = 40; n <= 66; n++) { const id = 'T-' + n; const r = nw.find((x) => x[0] === id); if (!r) { bad.push(id + ':مفقود'); continue; }
    if (r.length !== 7) bad.push(id + ':أعمدة'); else { if (!['حرجة', 'عالية', 'متوسطة', 'منخفضة'].includes(r[3])) bad.push(id + ':شدة'); if (r[4].length < 15) bad.push(id + ':معالجة'); (r[5].match(/ADR-\d+|\d{3}/g) || []).forEach(() => {}); const ps = r[6].match(/\b\d\d\.\d\d\b/g) || []; if (!(ps.length || /كل برومبت/.test(r[6]))) bad.push(id + ':بلا اختبار مخطط'); if (ps.some((p) => !prompts.has(p))) bad.push(id + ':برومبت غير صالح'); } }
  const adrRefs = (s.match(/ADR-\d{3}/g) || []).filter((a) => !ADR_IDS.includes(a) && !/^ADR-(20\d|21\d)$/.test(a)); if (adrRefs.length) bad.push('مرجع ADR غير موجود: ' + [...new Set(adrRefs)].join());
  return bad; };
const GATE_IDS = ['GX-00', 'GX-01', 'GX-02', 'GX-03', 'GX-04', 'GX-05', 'GX-06', 'GX-07', 'GX-08', 'GX-09', 'GX-REAL', 'GX-PUBLISH'];
const checkGates = (s, state, prompts) => { const bad = [];
  for (const g of GATE_IDS) if (!new RegExp('\\*\\*' + g + '\\*\\*|## [^\\n]*' + g).test(s)) bad.push(g + ':مفقودة في الوثيقة');
  s.split('\n').filter((l) => /^\| \*\*GX-0\d\*\* /.test(l)).forEach((l) => { if (l.split('|').length - 2 !== 7) bad.push(l.slice(0, 14) + ':أعمدة'); });
  const mapRows = s.slice(s.indexOf('## 5) تعيين')).split('\n').filter((l) => /^\| \d\d\.\d\d \|/.test(l)); const seen = {};
  mapRows.forEach((l) => { const c = l.split('|').slice(1, -1).map((x) => x.trim()); for (let i = 0; i + 1 < c.length; i += 2) if (c[i]) { seen[c[i]] = (seen[c[i]] || 0) + 1; if (!/GX-0\d/.test(c[i + 1])) bad.push(c[i] + ':بوابة'); } });
  prompts.forEach((p) => { if (seen[p] !== 1) bad.push(p + ':تعيين ' + (seen[p] || 0)); }); Object.keys(seen).forEach((p) => { if (!prompts.has(p)) bad.push(p + ':غير موجود في الفهرس'); });
  const keys = Object.keys((state && state.gates) || {}).sort(); if (JSON.stringify(keys) !== JSON.stringify([...GATE_IDS].sort())) bad.push('STATE.gates لا يطابق');
  Object.entries((state && state.gates) || {}).forEach(([k, v]) => { if (!['passed', 'pending', 'blocked'].includes(v)) bad.push(k + ':قيمة'); if (k !== 'GX-00' && v === 'passed') bad.push(k + ':مجتازة قبل وجود تنفيذ'); });
  return bad; };
const checkArchMap = (s, prompts) => { const bad = [], a = s.indexOf('## 10)'), b = s.indexOf('\n## 11)', a); const seen = {};
  s.slice(a, b).split('\n').filter((l) => /^\| \d\d\.\d\d \|/.test(l)).forEach((l) => { const c = l.split('|').slice(1, -1).map((x) => x.trim()); for (let i = 0; i + 1 < c.length; i += 2) if (c[i]) { seen[c[i]] = c[i + 1]; (c[i + 1].match(/\d{3}/g) || []).forEach((n) => { if (+n < 301 || +n > 321) bad.push(c[i] + ':ADR-' + n); }); } });
  prompts.forEach((p) => { if (!(p in seen)) bad.push(p + ':بلا ربط'); }); return { bad, seen }; };
const SECRET_RES = [/eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/, /sb_secret_[A-Za-z0-9]{10,}/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /SERVICE_ROLE_KEY\s*[=:]\s*['"]?[A-Za-z0-9._-]{20,}/, /\bsk-[A-Za-z0-9]{20,}/, /PEPPER\s*[=:]\s*['"]?[A-Za-z0-9+\/=_-]{16,}/, /VAPID_PRIVATE_KEY\s*[=:]\s*['"]?[A-Za-z0-9_-]{20,}/];
const findSecrets = (s) => SECRET_RES.filter((r) => r.test(s)).map(String);
const checkLimits = (s) => { const bad = []; ['500 MB', '1 GB', '5 GB', '50,000', '500K', '0 دولار'].forEach((k) => { if (!s.includes(k)) bad.push('حد مفقود: ' + k); });
  if (s.split('\n').some((l) => /للأبد/.test(l) && !/لا ادّعاء/.test(l))) bad.push('ادّعاء مجانية دائمة'); if (!/\[؟\]/.test(s)) bad.push('بلا وسم غير متحقق'); if (!/\[ح\]/.test(s)) bad.push('بلا وسم حقيقة رسمية'); return bad; };

module.exports = { checkAdrSections, checkDisposition, checkThreats, checkGates, checkArchMap, findSecrets, checkLimits, promptIds };
if (require.main !== module) return;

// ---------- التشغيل ----------
let pass = 0, fail = 0;
const t = (n, ok, x) => { if (ok) { pass++; console.log('PASS', n); } else { fail++; console.log('FAIL', n, x || ''); } };
const ARCH = rd(path.join(D, 'ARCHITECTURE-V2.md')), ADR = rd(path.join(D, 'ADR-V2.md')), TM = rd(path.join(D, 'THREAT-MODEL-V2.md')), GT = rd(path.join(D, 'GATES.md'));
const PI = rd(path.join(D, 'PROMPT_INDEX.md')), STATE = JSON.parse(rd(path.join(D, 'STATE.json'))), TR = rd(path.join(D, 'REQUIREMENTS-TRACEABILITY.md'));
const prompts = promptIds(PI);
t('43 برومبتاً في الفهرس', prompts.size === 43, prompts.size);
['ARCHITECTURE-V2.md', 'ADR-V2.md', 'THREAT-MODEL-V2.md', 'GATES.md'].forEach((f) => t('المخرج موجود وغير فارغ: ' + f, fs.existsSync(path.join(D, f)) && fs.statSync(path.join(D, f)).size > 3000));
// ADR
t('ADR-301…321 كلها بحالة وحدّ رجوع وبرومبت تحقق صالح', checkAdrSections(ADR, prompts).length === 0, checkAdrSections(ADR, prompts).join());
t('حكم ADR-201…217 مكتمل ومرتبط بمقابل صالح', checkDisposition(ADR).length === 0, checkDisposition(ADR).join());
t('لا ADR يدّعي أنه قرار مستخدم', !/معتمد من المستخدم|قرار المستخدم: معتمد/.test(ADR) && /اجتهاد تنفيذي/.test(ADR));
// التهديدات
t('T-01…T-39 لكل منها حكم، وT-40…T-66 بسبعة أعمدة وشدة ومعالجة واختبار مخطط صالح', checkThreats(TM, prompts).length === 0, checkThreats(TM, prompts).join());
// 01.01: صار تشغيل اختبارات مستوى المصفوفة حقيقياً؛ الحارس يبقى: الوثيقة تقرّ صراحة بأن لا اختبار على قاعدة/RLS نُفِّذ.
t('وثيقة التهديدات تقرّ بأن لا اختبار على قاعدة/RLS نُفِّذ', /لم يُنفَّذ أي اختبار على قاعدة أو RLS/.test(TM));
// البوابات
t('البوابات GX-00…09 وGX-REAL وGX-PUBLISH مكتملة، وكل برومبت معيَّن لبوابة مرة واحدة، وSTATE.gates مطابقة', checkGates(GT, STATE, prompts).length === 0, checkGates(GT, STATE, prompts).join());
t('G-A…G-D مصرَّح باستبدالها', /تستبدل\*{0,2} G-A…G-D/.test(GT));
t('بوابة البيانات الحقيقية تشترط DEC-11 واستعادة فعلية وهاتفين وتفويضاً', /DEC-11/.test(GT) && /استعادة فعلية/.test(GT) && /هاتفان/.test(GT) && /تفويض/.test(GT));
// المعمارية
const am = checkArchMap(ARCH, prompts); t('كل برومبت من 43 مربوط بقرارات ضمن ADR-301…321', am.bad.length === 0, am.bad.join());
t('كل مرجع ADR في ARCHITECTURE-V2 موجود', (ARCH.match(/ADR-\d{3}/g) || []).every((a) => ADR_IDS.includes(a) || /^ADR-2\d\d$/.test(a)));
t('أقسام ARCHITECTURE-V2 0…15 موجودة', Array.from({ length: 16 }, (_, i) => i).every((i) => new RegExp('^## ' + i + '\\)', 'm').test(ARCH)));
t('الحدود والكلفة: أرقام Free ووسوم [ح]/[؟] وبلا ادّعاء مجانية دائمة', checkLimits(ARCH).length === 0, checkLimits(ARCH).join());
t('ARCHITECTURE-V2 تنص على أن APK لم يُختبر وأن لا حساب أُنشئ', /لم يتحقق/.test(ARCH) && /لا حساب/.test(ARCH));
const rRows = TR.slice(TR.indexOf('## 3) المصفوفة'), TR.indexOf('## 4) معايير')).split('\n').filter((l) => /^\| R-\d{3} /.test(l)).map((l) => l.split('|').slice(1, -1).map((s) => s.trim()));
const uncovered = rRows.filter((r) => { const ps = (r[6].match(/\b\d\d\.\d\d\b/g) || []).filter((p) => p in am.seen && am.seen[p] !== '—'); return !ps.length && !/وكل ما بعده|كل/.test(r[6]); }).map((r) => r[0]);
t('كل مطلب R-001…R-100 له برومبت تنفيذ مربوط بقرار معماري (أو وثائقي صراحة)', rRows.length === 100 && uncovered.length === 0, uncovered.join());
// الأسرار والكود
const files = ['ARCHITECTURE-V2.md', 'ADR-V2.md', 'THREAT-MODEL-V2.md', 'GATES.md'].map((f) => rd(path.join(D, f)));
t('لا أسرار في الوثائق الأربع', files.every((x) => findSecrets(x).length === 0));
const walk = (d, o = []) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) { if (!['node_modules', '.git'].includes(e.name)) walk(p, o); } else o.push(p); } return o; };
const all = walk(ROOT).filter((p) => !/الصور المرجعية|archive|\.png$|\.zip$/.test(p));
t('لا ملف .env حقيقي في الشجرة (يُسمح بـ.env.example)', !all.some((p) => /(^|\/)\.env($|\.(?!example))/.test(p)));
const leaks = all.filter((p) => /\.(md|js|json|html|txt|css|example)$/.test(p) && !/tests\//.test(p)).filter((p) => findSecrets(rd(p)).length); t('لا سر ظاهر في ملفات المشروع النصية خارج tests', leaks.length === 0, leaks.join());
const base = rd(path.join(ROOT, 'docs', 'architecture', 'code-baseline.sha256')).trim().split('\n').filter(Boolean); let okFp = 0;
base.forEach((l) => { const m = l.match(/^([0-9a-f]{64})\s+\*?(.+)$/); if (m && fs.existsSync(path.join(ROOT, m[2])) && crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, m[2]))).digest('hex') === m[1]) okFp++; });
t('بصمات كود التشغيل ' + okFp + '/' + base.length + ' (لم يُعدَّل كود)', okFp === base.length && base.length === 14);
t('STATE.json: runtime_code_modified_by_pack = false', STATE.runtime_code_modified_by_pack === false);

// ---------- اختبارات التفسير المتعمَّد (الفاحص نفسه يجب أن يفشل على المُفسَد) ----------
const mut = (n, fn) => t('طفرة تُكتشف: ' + n, fn());
mut('حذف ADR-310', () => checkAdrSections(ADR.replace(/## ADR-310 — [^\n]*/, '## بدون'), prompts).length > 0);
mut('حذف «حدّ الرجوع» من ADR-305', () => { const sec = ADR.split('## ADR-305')[1].split('## ADR-306')[0]; return checkAdrSections(ADR.replace(sec, sec.replace(/حدّ الرجوع/g, 'x')), prompts).length > 0; });
mut('برومبت تحقق وهمي 99.99', () => checkAdrSections(ADR.replace(/(## ADR-311[\s\S]*?يُتحقق في:\*{0,2} )/, '$199.99 '), prompts).length > 0);
mut('حكم مجهول لـADR-205', () => checkDisposition(ADR.replace(/\| 205 \| مستبدل \|/, '| 205 | ربما |')).length > 0);
mut('حذف صف ADR-212', () => checkDisposition(ADR.replace(/^\| 212 \|.*$/m, '')).length > 0);
mut('حذف T-30', () => checkThreats(TM.replace(/^\| T-30 .*$/m, ''), prompts).length > 0);
mut('شدة مجهولة في T-50', () => checkThreats(TM.replace(/\| T-50 \| I \| ([^|]*)\| عالية \|/, '| T-50 | I | $1| ما \|'), prompts).length > 0);
mut('حذف T-66', () => checkThreats(TM.replace(/^\| T-66 .*$/m, ''), prompts).length > 0);
mut('حذف GX-04', () => checkGates(GT.replace(/^\| \*\*GX-04\*\*.*$/m, ''), STATE, prompts).length > 0);
mut('برومبت مكرر في البوابات', () => checkGates(GT.replace('| 00.04 | GX-00 |', '| 00.04 | GX-00 |').replace('| 03.01 | GX-03 |', '| 00.04 | GX-00 |'), STATE, prompts).length > 0);
mut('STATE.gates ناقصة', () => { const s = JSON.parse(JSON.stringify(STATE)); delete s.gates['GX-REAL']; return checkGates(GT, s, prompts).length > 0; });
mut('بوابة لاحقة مجتازة ادّعاءً', () => { const s = JSON.parse(JSON.stringify(STATE)); s.gates['GX-05'] = 'passed'; return checkGates(GT, s, prompts).length > 0; });
mut('حذف صف 06.02 من ربط المعمارية', () => checkArchMap(ARCH.replace(/\| 06\.02 \| 312 \|/, '|  |  |'), prompts).bad.length > 0);
mut('سر JWT مزروع', () => findSecrets('SUPABASE_SERVICE_' + 'ROLE_KEY=' + 'eyJhbGciOiJIUzI1NiJ9' + '.abcdefghijklmnop.signaturepart').length > 0);
mut('مفتاح خاص مزروع', () => findSecrets('-----BEGIN ' + 'PRIVATE KEY-----\nMIIE').length > 0);
mut('ادّعاء مجاني للأبد', () => checkLimits(ARCH + '\nالخدمة مجانية للأبد.').length > 0);
mut('حذف حد 1 GB', () => checkLimits(ARCH.split('1 GB').join('X')).length > 0);
t('نص سليم لا يُطلق إنذاراً كاذباً (الأسرار)', findSecrets('مثال: <SERVICE_ROLE_KEY> يُحفظ في أسرار الدالة فقط').length === 0);
console.log('\nالنتيجة: ' + pass + ' نجاح، ' + fail + ' فشل'); process.exit(fail ? 1 : 0);
