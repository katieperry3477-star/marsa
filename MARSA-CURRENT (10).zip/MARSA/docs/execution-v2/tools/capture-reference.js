// يلتقط صوراً مرجعية للحالة الحالية بالوضع الداكن فقط (هاتف وحاسبة) — قرار المستخدم 2026-11-08. التشغيل: NODE_PATH=$(npm root -g) node docs/execution-v2/tools/capture-reference.js <PROMPT_ID>
// اختياري (00.02): --docs مسار1.md,مسار2.md  يعرض وثائق Markdown ويلتقطها (مخرجات وثائقية). السلوك الأصلي لا يتغير.
// اختياري (02.02، قرار المستخدم 2026-11-13): --no-base يتخطى لقطات V1/full.html (لا يلتقط إلا ما يخص المهمة)؛ --v2-shell يلتقط قشرة V2 بالداكن (هاتف/تابلت/حاسبة، أدوار وحالات). كل لقطة تُتحقق بوجود الملف وحجمه > 0 فقط، دون فتحها.
// يخدم المجلد محلياً فقط، بلا شبكة خارجية. لا يعدّل كود التطبيق. بيانات اصطناعية فقط.
var pw = require('playwright'), http = require('http'), fs = require('fs'), path = require('path');
var ID = process.argv[2] || 'unknown';
var di = process.argv.indexOf('--docs'), DOCS = di > 0 && process.argv[di + 1] ? process.argv[di + 1].split(',') : [];
var pgi = process.argv.indexOf('--pages'), PAGES = pgi > 0 && process.argv[pgi + 1] ? process.argv[pgi + 1].split(',') : []; // 01.05: صفحات HTML ثابتة داخل المشروع (معاينات التصميم) بالداكن فقط
var NO_BASE = process.argv.indexOf('--no-base') > 0, V2SHELL = process.argv.indexOf('--v2-shell') > 0, CAPTURED = [];
var ROOT = path.resolve(__dirname, '..', '..', '..');
var OUT = path.join(ROOT, 'الصور المرجعية', ID);
fs.mkdirSync(OUT, { recursive: true });
var types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.json': 'application/json' };
var server = http.createServer(function (q, r) {
  var p = decodeURIComponent(q.url.split('?')[0]); if (p === '/') p = '/index.html';
  var f = path.join(ROOT, p);
  if (f.indexOf(ROOT) !== 0 || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { r.writeHead(404); return r.end(); }
  r.writeHead(200, { 'Content-Type': types[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(r);
});

// 02.02: لقطات قشرة V2 (داكن فقط). كل مشهد يُبنى من العنوان ?mock=<role>#<route>?state=<state> أو بنقرات حقيقية؛ لا بيانات حقيقية.
async function captureV2Shell(b, base) {
  var n = 0;
  var views = { phone: { width: 390, height: 844 }, tablet: { width: 768, height: 1024 }, desktop: { width: 1280, height: 800 } };
  async function ctxFor(view, motion) {
    var c = await b.newContext({ viewport: views[view], colorScheme: 'dark', locale: 'ar-IQ', reducedMotion: motion || 'reduce' });
    await c.route(function (u) { return u.hostname !== '127.0.0.1'; }, function (rt) { rt.abort(); });
    return c;
  }
  async function settle(pg, loading) {
    if (loading) { await pg.waitForTimeout(700); return; }
    await pg.waitForTimeout(80);
    await pg.waitForFunction(function () { return !document.querySelector('[data-view][aria-busy="true"]'); }, null, { timeout: 6000 });
    await pg.waitForTimeout(120);
  }
  async function shot(pg, name, view) { var f = path.join(OUT, 'v2-shell-' + name + '-' + view + '-dark.png'); await pg.screenshot({ path: f }); CAPTURED.push(f); n++; }
  async function scene(name, view, role, hash, steps, loading) {
    var c = await ctxFor(view), pg = await c.newPage();
    await pg.goto(base + '/v2/index.html' + (role ? '?mock=' + role : '') + (hash ? '#' + hash : ''));
    await pg.waitForSelector('html[data-v2="ready"]'); await settle(pg, loading);
    if (steps) await steps(pg);
    await shot(pg, name, view); await c.close();
  }
  var openMenu = async function (pg) { await pg.locator('.menu-btn').click(); await pg.waitForSelector('#sidebar[data-open="true"]'); await pg.waitForTimeout(420); };
  // الافتتاحية (بحركة طبيعية) ثم المنتقي
  var ci = await ctxFor('phone', 'no-preference'), pi = await ci.newPage();
  await pi.goto(base + '/v2/index.html'); await pi.waitForSelector('#intro:not([hidden])'); await pi.waitForTimeout(700); await shot(pi, 'intro', 'phone'); await ci.close();
  await scene('picker', 'phone', null, '');
  for (var r of [['student', '/home'], ['rep', '/home'], ['dev', '/dev']]) await scene(r[0] + '-home', 'phone', r[0], r[1]);
  await scene('student-sidebar', 'phone', 'student', '/home', openMenu);
  await scene('rep-sidebar', 'phone', 'rep', '/home', openMenu);
  await scene('dev-sidebar-future', 'phone', 'dev', '/dev', async function (pg) { await openMenu(pg); await pg.locator('#sidebar .sb-future').first().click(); await pg.waitForTimeout(320); });
  await scene('student-preps-today', 'phone', 'student', '/preps/today');
  await scene('student-preps-tomorrow', 'phone', 'student', '/preps/tomorrow');
  await scene('student-exam', 'phone', 'student', '/preps/exam');
  await scene('rep-preps-empty', 'phone', 'rep', '/preps/today?state=empty');
  await scene('state-loading', 'phone', 'student', '/preps/today?state=loading', null, true);
  await scene('state-error', 'phone', 'student', '/preps/today?state=error');
  await scene('state-offline-stamp', 'phone', 'student', '/preps/today?state=offline');
  await scene('state-offline-write-disabled', 'phone', 'rep', '/preps/today?state=offline');
  await scene('state-blocked-offline', 'phone', 'dev', '/dev?state=offline');
  await scene('student-settings-theme', 'phone', 'student', '/settings');
  await scene('student-upcoming', 'phone', 'student', '/settings/upcoming');
  await scene('student-forbidden', 'phone', 'student', '/class/students');
  await scene('student-notfound', 'phone', 'student', '/zzz');
  await scene('dev-support-active', 'phone', 'dev', '/dev/support', async function (pg) { await pg.locator('[data-support-start="student"]').click(); await settle(pg); });
  await scene('student-home', 'tablet', 'student', '/home');
  await scene('student-home', 'desktop', 'student', '/home');
  await scene('rep-preps-today', 'desktop', 'rep', '/preps/today');
  await scene('dev-home', 'desktop', 'dev', '/dev');
  return n;
}
(async function () {
  await new Promise(function (ok) { server.listen(0, '127.0.0.1', ok); });
  var base = 'http://127.0.0.1:' + server.address().port, b = await pw.chromium.launch(), n = 0, SERVER_BASE = base;
  var pages = NO_BASE ? [] : [['v1', '/index.html'], ['full', '/full.html']];
  var views = [['phone', { width: 390, height: 844 }], ['desktop', { width: 1280, height: 800 }]];
  for (var pi = 0; pi < pages.length; pi++) for (var vi = 0; vi < views.length; vi++) for (var cs of ['dark']) {
    var ctx = await b.newContext({ viewport: views[vi][1], colorScheme: cs, locale: 'ar-IQ', reducedMotion: 'reduce' });
    await ctx.route(function (u) { return u.hostname !== '127.0.0.1'; }, function (rt) { rt.abort(); });
    var pg = await ctx.newPage();
    await pg.goto(base + pages[pi][1]); await pg.waitForTimeout(1200);
    await pg.screenshot({ path: path.join(OUT, pages[pi][0] + '-' + views[vi][0] + '-' + cs + '.png') }); n++;
    if (pages[pi][0] === 'v1') {
      var sk = pg.getByText('تخطّي').first();
      if (await sk.count()) { await sk.click(); await pg.waitForTimeout(900); await pg.screenshot({ path: path.join(OUT, 'v1-' + views[vi][0] + '-' + cs + '-after-intro.png') }); n++; }
    }
    await ctx.close();
  }

  for (var di2 = 0; di2 < DOCS.length; di2++) {
    var mk = require('marked'), parse = (mk.marked && mk.marked.parse) || mk.parse, md = fs.readFileSync(path.join(ROOT, DOCS[di2]), 'utf8');
    var html = '<!doctype html><html dir="rtl" lang="ar"><meta charset="utf-8"><style>body{font:15px/1.7 system-ui,sans-serif;margin:16px;max-width:1100px}table{border-collapse:collapse;display:block;overflow-x:auto}td,th{border:1px solid #8886;padding:4px 8px;vertical-align:top}code{background:#8882;padding:0 3px}blockquote{border-inline-start:4px solid #0aa;margin:0;padding:0 12px}@media(prefers-color-scheme:dark){body{background:#101826;color:#e8edf5}}</style><body>' + parse(md) + '</body></html>';
    var base = path.basename(DOCS[di2], '.md');
    for (var vj = 0; vj < views.length; vj++) for (var cs2 of ['dark']) {
      var cx = await b.newContext({ viewport: views[vj][1], colorScheme: cs2, locale: 'ar-IQ' });
      var pgd = await cx.newPage(); await pgd.setContent(html); await pgd.waitForTimeout(300);
      await pgd.screenshot({ path: path.join(OUT, 'doc-' + base + '-' + views[vj][0] + '-' + cs2 + '.png') }); n++; await cx.close();
    }
  }
  for (var pj = 0; pj < PAGES.length; pj++) for (var vk = 0; vk < views.length; vk++) {
    var cp2 = await b.newContext({ viewport: views[vk][1], colorScheme: 'dark', locale: 'ar-IQ', reducedMotion: 'reduce' });
    await cp2.route(function (u) { return u.hostname !== '127.0.0.1'; }, function (rt) { rt.abort(); });
    var pp = await cp2.newPage(); await pp.goto(SERVER_BASE + '/' + PAGES[pj]); await pp.waitForTimeout(600);
    var pn = path.basename(PAGES[pj], '.html');
    await pp.screenshot({ path: path.join(OUT, 'page-' + pn + '-' + views[vk][0] + '-dark.png') }); n++;
    for (var sec of ['three', 'sidebar']) { var el2 = pp.locator('#' + sec); if (await el2.count()) { await el2.scrollIntoViewIfNeeded(); await pp.waitForTimeout(200); await pp.screenshot({ path: path.join(OUT, 'page-' + pn + '-' + sec + '-' + views[vk][0] + '-dark.png') }); n++; } }
    await cp2.close();
  }
  if (V2SHELL) n += await captureV2Shell(b, base);
  await b.close(); server.close();
  // تحقق الوجود والحجم فقط (لا فتح للصور ولا قراءة لمحتواها)
  var all = fs.readdirSync(OUT).filter(function (f) { return /\.png$/.test(f); }).map(function (f) { return path.join(OUT, f); });
  var empty = all.filter(function (f) { return fs.statSync(f).size <= 0; }), missing = CAPTURED.filter(function (f) { return !fs.existsSync(f); });
  console.log('captured ' + n + ' -> ' + OUT + ' | files=' + all.length + ' empty=' + empty.length + ' missing=' + missing.length);
  if (empty.length || missing.length) process.exit(1);
})().catch(function (e) { console.error(e); process.exit(1); });
