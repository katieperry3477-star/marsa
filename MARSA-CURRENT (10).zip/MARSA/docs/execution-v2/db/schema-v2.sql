-- ============================================================================
-- مَرسى V2 — 01.02 — المخطط المرجعي لقاعدة البيانات (PostgreSQL 15+ / Supabase)
--
-- الحالة: DDL مرجعي صُمّم وشُغّل فعلياً على PostgreSQL 16 محلي في 01.02 عبر tests/db/schema-v2.test.js.
-- ليس migration: 03.02 يحوّله إلى migrations مرقّمة (ADR-319) دون تغيير دلالاته إلا بقرار موثق.
-- لا سياسات RLS هنا (03.03) ولا RPC ولا Edge: كل جدول RLS-مفعّل بلا أي سياسة ولا منحة = رفض افتراضي.
-- المرجع: DATA-MODEL-V2.md (الأعمدة والقيود وأسبابها) · ACCESS-MATRIX-V2.md (من يصل لماذا).
--
-- اصطلاحات:
--  • كل معرّف داخلي uuid (gen_random_uuid). لا رقم مدرسي. الهاتف ليس مفتاحاً ولا فريداً.
--  • class_id في كل جدول صفّي، وكل مرجع بين جدولين صفّيين مفتاح مركّب (id, class_id) فلا ارتباط عابر للشعب.
--  • لا حذف صلب: archived_at (أو revoked_at للرموز والاشتراكات) + مشغّلات تمنع DELETE/TRUNCATE.
--  • المال أعداد صحيحة بالدينار العراقي فقط؛ لا عمود عملة.
--  • version للجداول التي تحمل وسم version في المصفوفة (تزامن متفائل، ADR-309).
-- ============================================================================

create schema if not exists extensions;
create extension if not exists pg_trgm with schema extensions;
create schema if not exists private;
revoke all on schema private from public;

-- ───────────────────────── 1) دوال مساعدة نقية ─────────────────────────
-- توحيد النص للبحث والتجميع: نفس foldText في V1 (تشكيل، تطويل، همزات، ى، ة، حروف صغيرة) + توحيد الأرقام العربية/الفارسية.
create or replace function private.fold_ar(t text) returns text
language sql immutable parallel safe as $$
  select lower(btrim(regexp_replace(
    translate(
      regexp_replace(coalesce(t, ''), '[ً-ٰٟـ]', '', 'g'),
      'أإآٱىة٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹',
      'اااايه01234567890123456789'),
    '\s+', ' ', 'g')))
$$;

-- «اليوم الدراسي» بتوقيت العراق (لا UTC) حتى لا ينزاح اليوم؛ التواريخ الدراسية أعمدة date بلا منطقة.
create or replace function private.school_today() returns date
language sql stable as $$ select (now() at time zone 'Asia/Baghdad')::date $$;

-- ───────────────────────── 2) الجداول ─────────────────────────
-- الترتيب يتبع اعتماد المفاتيح الأجنبية (وهو ترتيب التصدير/الاستعادة؛ انظر DATA-MODEL-V2.md).

-- 2-1 الشعبة. إنشاء الشعب وأرشفتها غير مفعّل في الإصدار الأول (لا شاشة ولا منحة) لكن العمود جاهز.
create table public.classes (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (char_length(btrim(name)) between 1 and 80 and name = btrim(name)),
  academic_year text check (academic_year is null or char_length(academic_year) between 1 and 20),
  archived_at   timestamptz,
  archived_by   uuid,
  created_at    timestamptz not null default now(),
  created_by    uuid,
  updated_at    timestamptz not null default now(),
  updated_by    uuid
);

-- 2-2 ملف الطالب (C1). الاسم الثلاثي يُفرض في RPC/الواجهة؛ القاعدة تفرض غير الفارغ والمقصوص.
create table public.students (
  id             uuid primary key default gen_random_uuid(),
  class_id       uuid not null references public.classes (id),
  full_name      text not null check (char_length(full_name) between 1 and 120 and full_name = btrim(full_name)),
  name_key       text generated always as (private.fold_ar(full_name)) stored,
  phone          text not null check (phone ~ '^\+?[0-9]{7,15}$'),
  birth_date     date check (birth_date is null or birth_date >= date '1940-01-01'),
  prior_absences integer not null default 0 check (prior_absences between 0 and 1000),
  archived_at    timestamptz,
  archived_by    uuid,
  created_at     timestamptz not null default now(),
  created_by     uuid,
  updated_at     timestamptz not null default now(),
  updated_by     uuid,
  version        integer not null default 1,
  constraint students_id_class_key unique (id, class_id)
);

-- 2-3 العضويات (C4): الدور والحالة من هنا لا من JWT (ADR-306). المطوّر class_id فارغ؛ الطالب مربوط بسجل طالبه.
create table public.members (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid references auth.users (id),
  role              text not null check (role in ('developer', 'rep', 'student')),
  class_id          uuid references public.classes (id),
  student_id        uuid,
  display_name      text check (display_name is null or (char_length(display_name) between 1 and 80 and display_name = btrim(display_name))),
  status            text not null default 'pending' check (status in ('pending', 'active', 'suspended', 'archived')),
  status_changed_at timestamptz not null default now(),
  status_changed_by uuid,
  session_epoch     integer not null default 0 check (session_epoch >= 0),
  activated_at      timestamptz,
  archived_at       timestamptz,
  archived_by       uuid,
  created_at        timestamptz not null default now(),
  created_by        uuid,
  updated_at        timestamptz not null default now(),
  updated_by        uuid,
  constraint members_id_class_key unique (id, class_id),
  constraint members_student_fk foreign key (student_id, class_id) references public.students (id, class_id),
  constraint members_role_scope_chk check ((role = 'developer') = (class_id is null)),
  constraint members_student_link_chk check ((role = 'student') = (student_id is not null)),
  constraint members_display_name_chk check ((role = 'student') = (display_name is null)),
  constraint members_dev_status_chk check (role <> 'developer' or status in ('pending', 'active')),
  constraint members_active_user_chk check (status <> 'active' or user_id is not null),
  constraint members_archived_chk check ((status = 'archived') = (archived_at is not null))
);

-- المراجع المؤجلة لأعمدة التوقيع في الجداول التي سبقت members (اعتماد دائري).
alter table public.classes  add constraint classes_created_by_fkey  foreign key (created_by)  references public.members (id);
alter table public.classes  add constraint classes_updated_by_fkey  foreign key (updated_by)  references public.members (id);
alter table public.classes  add constraint classes_archived_by_fkey foreign key (archived_by) references public.members (id);
alter table public.students add constraint students_created_by_fkey  foreign key (created_by)  references public.members (id);
alter table public.students add constraint students_updated_by_fkey  foreign key (updated_by)  references public.members (id);
alter table public.students add constraint students_archived_by_fkey foreign key (archived_by) references public.members (id);
alter table public.members  add constraint members_created_by_fkey  foreign key (created_by)  references public.members (id);
alter table public.members  add constraint members_updated_by_fkey  foreign key (updated_by)  references public.members (id);
alter table public.members  add constraint members_archived_by_fkey foreign key (archived_by) references public.members (id);
alter table public.members  add constraint members_status_changed_by_fkey foreign key (status_changed_by) references public.members (id);

-- 2-4 كتالوج أحداث التدقيق (مرجع؛ إضافة حدث = migration). خاص: لا منح لأي دور تطبيقي.
create table private.audit_event_types (
  action      text primary key check (action ~ '^[a-z]+\.[a-z_]+$'),
  category    text not null check (category in ('code', 'member', 'support', 'data', 'export', 'access', 'system')),
  description text not null
);

-- 2-5 رموز التفعيل (C4): بصمة HMAC فقط، لا نص صريح، رمز نشط واحد لكل عضوية. خاص (لا منح، يُقرأ عبر RPC/Edge).
create table private.activation_codes (
  id            uuid primary key default gen_random_uuid(),
  class_id      uuid not null references public.classes (id),
  member_id     uuid not null,
  code_hash     bytea not null check (octet_length(code_hash) = 32),
  purpose       text not null check (purpose in ('activate', 'reactivate')),
  issued_by     uuid not null references public.members (id),
  issued_at     timestamptz not null default now(),
  expires_at    timestamptz not null,
  consumed_at   timestamptz,
  revoked_at    timestamptz,
  revoked_by    uuid references public.members (id),
  revoke_reason text check (revoke_reason is null or char_length(revoke_reason) between 1 and 120),
  constraint activation_codes_hash_key unique (code_hash),
  constraint activation_codes_member_fk foreign key (member_id, class_id) references public.members (id, class_id),
  constraint activation_codes_ttl_chk check (expires_at > issued_at and expires_at <= issued_at + interval '30 days'),
  constraint activation_codes_final_chk check (not (consumed_at is not null and revoked_at is not null)),
  constraint activation_codes_revoke_chk check ((revoked_at is null) = (revoked_by is null))
);

-- 2-6 محاولات التفعيل وحدود المعدل (SYS): للخادم وحده؛ عناوين مجزّأة بملح يومي؛ تنظيف بعد 90 يوماً.
create table private.activation_attempts (
  id           uuid primary key default gen_random_uuid(),
  attempted_at timestamptz not null default now(),
  outcome      text not null check (outcome in ('success', 'invalid', 'expired', 'revoked', 'consumed', 'rate_limited')),
  code_id      uuid references private.activation_codes (id),
  ip_hash      bytea check (ip_hash is null or octet_length(ip_hash) = 32)
);
create index activation_attempts_code_idx on private.activation_attempts (code_id) where code_id is not null;

-- 2-7 الحضور (C2): كشف واحد لكل (شعبة، تاريخ) ثم سجل لكل طالب. الاعتماد يقفل الكشف ويظهره للطالب.
create table public.attendance_sheets (
  id          uuid primary key default gen_random_uuid(),
  class_id    uuid not null references public.classes (id),
  school_date date not null,
  status      text not null default 'draft' check (status in ('draft', 'approved')),
  approved_at timestamptz,
  approved_by uuid references public.members (id),
  archived_at timestamptz,
  archived_by uuid references public.members (id),
  created_at  timestamptz not null default now(),
  created_by  uuid references public.members (id),
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.members (id),
  version     integer not null default 1,
  constraint attendance_sheets_day_key unique (class_id, school_date),
  constraint attendance_sheets_id_class_key unique (id, class_id),
  constraint attendance_sheets_approval_chk check ((status = 'approved') = (approved_at is not null) and (status = 'approved') = (approved_by is not null))
);

create table public.attendance_records (
  id          uuid primary key default gen_random_uuid(),
  class_id    uuid not null references public.classes (id),
  sheet_id    uuid not null,
  student_id  uuid not null,
  status      text not null default 'present' check (status in ('present', 'absent', 'excused', 'late', 'exceptional')),
  note        text check (note is null or char_length(note) <= 200),
  archived_at timestamptz,
  archived_by uuid references public.members (id),
  created_at  timestamptz not null default now(),
  created_by  uuid references public.members (id),
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.members (id),
  version     integer not null default 1,
  constraint attendance_records_one_key unique (sheet_id, student_id),
  constraint attendance_records_sheet_fk foreign key (sheet_id, class_id) references public.attendance_sheets (id, class_id),
  constraint attendance_records_student_fk foreign key (student_id, class_id) references public.students (id, class_id)
);

-- 2-8 الدرجات (C2): ثلاث فئات؛ الشهرية برقم الشهر؛ 0 ≤ الدرجة ≤ العظمى (R-049). النسبة تُشتق ولا تُخزَّن.
create table public.grades (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id),
  student_id   uuid not null,
  subject      text not null check (char_length(subject) between 1 and 80 and subject = btrim(subject)),
  subject_key  text generated always as (private.fold_ar(subject)) stored,
  term         text not null check (term in ('monthly', 'midyear', 'final')),
  period_month smallint check (period_month between 1 and 12),
  score        numeric(7, 2) not null,
  max_score    numeric(7, 2) not null,
  note         text check (note is null or char_length(note) <= 200),
  archived_at  timestamptz,
  archived_by  uuid references public.members (id),
  created_at   timestamptz not null default now(),
  created_by   uuid references public.members (id),
  updated_at   timestamptz not null default now(),
  updated_by   uuid references public.members (id),
  version      integer not null default 1,
  constraint grades_student_fk foreign key (student_id, class_id) references public.students (id, class_id),
  constraint grades_range_chk check (max_score > 0 and max_score <= 1000 and score >= 0 and score <= max_score),
  constraint grades_period_chk check ((term = 'monthly') = (period_month is not null))
);

-- 2-9 الامتحانات والجدول (C0).
create table public.exams (
  id          uuid primary key default gen_random_uuid(),
  class_id    uuid not null references public.classes (id),
  subject     text not null check (char_length(subject) between 1 and 80 and subject = btrim(subject)),
  subject_key text generated always as (private.fold_ar(subject)) stored,
  exam_date   date not null,
  start_time  time,
  notes       text check (notes is null or char_length(notes) <= 300),
  archived_at timestamptz,
  archived_by uuid references public.members (id),
  created_at  timestamptz not null default now(),
  created_by  uuid references public.members (id),
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.members (id),
  version     integer not null default 1,
  constraint exams_id_class_key unique (id, class_id)
);

create table public.schedule_entries (
  id          uuid primary key default gen_random_uuid(),
  class_id    uuid not null references public.classes (id),
  weekday     text not null check (weekday in ('sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri')),
  period_no   smallint check (period_no between 1 and 30),
  subject     text not null check (char_length(subject) between 1 and 80 and subject = btrim(subject)),
  subject_key text generated always as (private.fold_ar(subject)) stored,
  start_time  time,
  end_time    time,
  notes       text check (notes is null or char_length(notes) <= 300),
  archived_at timestamptz,
  archived_by uuid references public.members (id),
  created_at  timestamptz not null default now(),
  created_by  uuid references public.members (id),
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.members (id),
  version     integer not null default 1,
  constraint schedule_entries_time_chk check (start_time is null or end_time is null or end_time > start_time)
);

-- 2-10 التحاضير: المادة + اليوم الدراسي الداخلي + الملاحظات (+ الواجب في homework، والمرفقات في file_objects).
-- لا عنوان درس ولا نص موضوع ولا اسم مدرّس (R-053/R-054).
create table public.preps (
  id          uuid primary key default gen_random_uuid(),
  class_id    uuid not null references public.classes (id),
  subject     text not null check (char_length(subject) between 1 and 80 and subject = btrim(subject)),
  subject_key text generated always as (private.fold_ar(subject)) stored,
  school_date date not null default private.school_today(),
  notes       text check (notes is null or char_length(notes) <= 2000),
  pinned_at   timestamptz,
  archived_at timestamptz,
  archived_by uuid references public.members (id),
  created_at  timestamptz not null default now(),
  created_by  uuid references public.members (id),
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.members (id),
  constraint preps_id_class_key unique (id, class_id)
);

-- حالة إغلاق اليوم لكل تحضير (تم/لم يتم/تأجل). التأجيل لا ينسخ ولا يغيّر تاريخ التحضير: يسجّل «تأجل إلى» فقط.
create table public.prep_status (
  id               uuid primary key default gen_random_uuid(),
  class_id         uuid not null references public.classes (id),
  prep_id          uuid not null,
  status           text not null check (status in ('taken', 'not_taken', 'postponed')),
  postponed_to_date date,
  note             text check (note is null or char_length(note) <= 300),
  archived_at      timestamptz,
  archived_by      uuid references public.members (id),
  created_at       timestamptz not null default now(),
  created_by       uuid references public.members (id),
  updated_at       timestamptz not null default now(),
  updated_by       uuid references public.members (id),
  constraint prep_status_one_key unique (prep_id),
  constraint prep_status_prep_fk foreign key (prep_id, class_id) references public.preps (id, class_id),
  constraint prep_status_postpone_chk check ((status = 'postponed') = (postponed_to_date is not null))
);

-- 2-11 الواجبات: مرتبط بتحضير (يرث المادة واليوم منه فلا تكرار، R-062) أو قائم بذاته بمادته ويومه.
create table public.homework (
  id          uuid primary key default gen_random_uuid(),
  class_id    uuid not null references public.classes (id),
  prep_id     uuid,
  subject     text check (subject is null or (char_length(subject) between 1 and 80 and subject = btrim(subject))),
  subject_key text generated always as (case when subject is null then null else private.fold_ar(subject) end) stored,
  school_date date,
  body        text not null check (char_length(body) between 1 and 2000),
  notes       text check (notes is null or char_length(notes) <= 1000),
  archived_at timestamptz,
  archived_by uuid references public.members (id),
  created_at  timestamptz not null default now(),
  created_by  uuid references public.members (id),
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.members (id),
  constraint homework_id_class_key unique (id, class_id),
  constraint homework_prep_fk foreign key (prep_id, class_id) references public.preps (id, class_id),
  constraint homework_inherit_chk check (
    (prep_id is not null and subject is null and school_date is null)
    or (prep_id is null and subject is not null and school_date is not null))
);

-- 2-12 الإعلانات (C0).
create table public.announcements (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id),
  title        text not null check (char_length(title) between 1 and 120 and title = btrim(title)),
  body         text not null check (char_length(body) between 1 and 2000),
  published_at timestamptz not null default now(),
  pinned_at    timestamptz,
  archived_at  timestamptz,
  archived_by  uuid references public.members (id),
  created_at   timestamptz not null default now(),
  created_by   uuid references public.members (id),
  updated_at   timestamptz not null default now(),
  updated_by   uuid references public.members (id)
);

-- 2-13 المرفقات (بيانات وصفية؛ الملف في bucket خاص بمسار {class_id}/{kind}/{uuid}.{ext}، ADR-312).
-- الأصل واحد من ثلاثة بمفتاح أجنبي حقيقي (لا ربط متعدد الأشكال). الملف ثابت: الاستبدال = سجل جديد.
create table public.file_objects (
  id              uuid primary key default gen_random_uuid(),
  class_id        uuid not null references public.classes (id),
  prep_id         uuid,
  homework_id     uuid,
  exam_id         uuid,
  storage_path    text not null,
  thumb_path      text,
  mime_type       text not null check (mime_type in ('image/jpeg', 'image/png', 'image/webp', 'application/pdf')),
  byte_size       integer not null check (byte_size > 0),
  thumb_byte_size integer check (thumb_byte_size is null or (thumb_byte_size > 0 and thumb_byte_size <= 102400)),
  width           smallint check (width is null or width > 0),
  height          smallint check (height is null or height > 0),
  sha256          bytea not null check (octet_length(sha256) = 32),
  display_order   smallint not null default 0 check (display_order >= 0),
  archived_at     timestamptz,
  archived_by     uuid references public.members (id),
  created_at      timestamptz not null default now(),
  created_by      uuid references public.members (id),
  updated_at      timestamptz not null default now(),
  updated_by      uuid references public.members (id),
  constraint file_objects_path_key unique (storage_path),
  constraint file_objects_prep_fk foreign key (prep_id, class_id) references public.preps (id, class_id),
  constraint file_objects_homework_fk foreign key (homework_id, class_id) references public.homework (id, class_id),
  constraint file_objects_exam_fk foreign key (exam_id, class_id) references public.exams (id, class_id),
  constraint file_objects_one_parent_chk check (num_nonnulls(prep_id, homework_id, exam_id) = 1),
  constraint file_objects_size_chk check (
    (mime_type = 'application/pdf' and byte_size <= 3145728) or (mime_type <> 'application/pdf' and byte_size <= 2097152)),
  constraint file_objects_path_chk check (
    storage_path ~ ('^' || class_id::text || '/(prep|homework|exam)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(jpg|png|webp|pdf)$')),
  constraint file_objects_thumb_chk check (thumb_path is null or thumb_path ~ ('^' || class_id::text || '/thumb/[0-9a-f-]{36}\.webp$'))
);

-- 2-14 التكاليف (C3). المبالغ أعداد صحيحة بالدينار العراقي؛ لا عمود عملة (R-066).
create table public.cost_items (
  id          uuid primary key default gen_random_uuid(),
  class_id    uuid not null references public.classes (id),
  title       text not null check (char_length(title) between 1 and 120 and title = btrim(title)),
  description text check (description is null or char_length(description) <= 500),
  amount      bigint not null check (amount > 0 and amount <= 100000000),
  due_date    date,
  archived_at timestamptz,
  archived_by uuid references public.members (id),
  created_at  timestamptz not null default now(),
  created_by  uuid references public.members (id),
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.members (id),
  version     integer not null default 1,
  constraint cost_items_id_class_key unique (id, class_id)
);

-- إسناد بند لطالب. amount_due لقطة من البند عند الإسناد (تسمح باستثناء/تخفيض موثق). paid_total مجموع مخزَّن
-- تحدّثه مشغّلات الدفعات حصراً؛ الحالة مشتقة منه (R-064). المدفوع لا يتجاوز المطلوب (قرار موثق E-016).
create table public.cost_assignments (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id),
  cost_item_id uuid not null,
  student_id   uuid not null,
  amount_due   bigint not null check (amount_due >= 0 and amount_due <= 100000000),
  paid_total   bigint not null default 0 check (paid_total >= 0),
  pay_status   text generated always as (
    case when paid_total >= amount_due then 'paid' when paid_total = 0 then 'unpaid' else 'partial' end) stored,
  archived_at  timestamptz,
  archived_by  uuid references public.members (id),
  created_at   timestamptz not null default now(),
  created_by   uuid references public.members (id),
  updated_at   timestamptz not null default now(),
  updated_by   uuid references public.members (id),
  version      integer not null default 1,
  constraint cost_assignments_one_key unique (cost_item_id, student_id),
  constraint cost_assignments_triple_key unique (id, class_id, student_id),
  constraint cost_assignments_item_fk foreign key (cost_item_id, class_id) references public.cost_items (id, class_id),
  constraint cost_assignments_student_fk foreign key (student_id, class_id) references public.students (id, class_id),
  constraint cost_assignments_paid_le_due_chk check (paid_total <= amount_due)
);

-- الدفعات: للإلحاق فقط. التصحيح = إبطال (archived_at + سبب، نهائي) ثم دفعة جديدة (E-009).
create table public.payments (
  id             uuid primary key default gen_random_uuid(),
  class_id       uuid not null references public.classes (id),
  assignment_id  uuid not null,
  student_id     uuid not null,
  amount         bigint not null check (amount > 0 and amount <= 100000000),
  paid_on        date not null default private.school_today(),
  note           text check (note is null or char_length(note) <= 300),
  archived_at    timestamptz,
  archived_by    uuid references public.members (id),
  archive_reason text check (archive_reason is null or char_length(archive_reason) between 1 and 200),
  created_at     timestamptz not null default now(),
  created_by     uuid references public.members (id),
  updated_at     timestamptz not null default now(),
  updated_by     uuid references public.members (id),
  version        integer not null default 1,
  constraint payments_assignment_fk foreign key (assignment_id, class_id, student_id)
    references public.cost_assignments (id, class_id, student_id),
  constraint payments_void_reason_chk check ((archived_at is null) = (archive_reason is null))
);

-- 2-15 الإشعارات: صف واحد لكل حدث (لا صف لكل مستلم)؛ حالة القراءة ذاتية في جدول مستقل (ADR-313).
create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  class_id   uuid not null references public.classes (id),
  kind       text not null check (kind in ('announcement', 'prep', 'exam')),
  event      text not null check (event in ('created', 'updated')),
  ref_id     uuid not null,
  title      text not null check (char_length(title) between 1 and 120),
  audience   text not null default 'all' check (audience in ('all', 'students', 'reps')),
  dedupe_key text not null,
  created_at timestamptz not null default now(),
  constraint notifications_id_class_key unique (id, class_id),
  constraint notifications_dedupe_key unique (dedupe_key)
);

create table public.notification_reads (
  notification_id uuid not null,
  member_id       uuid not null references public.members (id),
  class_id        uuid not null,
  read_at         timestamptz not null default now(),
  primary key (member_id, notification_id),
  constraint notification_reads_notification_fk foreign key (notification_id, class_id) references public.notifications (id, class_id)
);

-- اشتراكات Web Push (ذاتية). مفتاح auth سرّ تشغيلي تقرأه send-push وحدها (T-R: لا دور يقرأ اشتراك غيره).
create table public.push_subscriptions (
  id              uuid primary key default gen_random_uuid(),
  member_id       uuid not null references public.members (id),
  endpoint        text not null check (endpoint ~ '^https://' and char_length(endpoint) <= 2048),
  p256dh          text not null check (char_length(p256dh) between 1 and 512),
  auth_key        text not null check (char_length(auth_key) between 1 and 512),
  user_agent_hint text check (user_agent_hint is null or char_length(user_agent_hint) <= 120),
  failure_count   integer not null default 0 check (failure_count >= 0),
  last_success_at timestamptz,
  revoked_at      timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint push_subscriptions_endpoint_key unique (endpoint)
);

-- 2-16 جلسات وضع الدعم (C4): عرض بصفة؛ لا توكن بالنيابة (ADR-308). المطوّر وحده.
create table public.support_sessions (
  id                  uuid primary key default gen_random_uuid(),
  developer_member_id uuid not null references public.members (id),
  target_member_id    uuid not null references public.members (id),
  reason              text not null check (char_length(btrim(reason)) between 1 and 200),
  started_at          timestamptz not null default now(),
  ends_at             timestamptz not null,
  ended_at            timestamptz,
  constraint support_sessions_ttl_chk check (ends_at > started_at and ends_at <= started_at + interval '8 hours'),
  constraint support_sessions_not_self_chk check (developer_member_id <> target_member_id)
);

-- 2-17 سجل التدقيق (C4): للإلحاق فقط؛ معرّفات لا أسماء ولا قيم ولا IP خام (ADR-314).
create table public.audit_log (
  id                    uuid primary key default gen_random_uuid(),
  seq                   bigint generated always as identity unique,
  at                    timestamptz not null default now(),
  actor_member_id       uuid references public.members (id),
  actor_role            text check (actor_role in ('developer', 'rep', 'student')),
  class_id              uuid references public.classes (id),
  action                text not null references private.audit_event_types (action),
  entity                text check (entity is null or entity ~ '^[a-z_]{1,40}$'),
  entity_id             uuid,
  support_target_member_id uuid references public.members (id),
  outcome               text not null default 'success' check (outcome in ('success', 'denied', 'error')),
  reason_code           text check (reason_code is null or reason_code ~ '^[a-z0-9_.]{1,60}$'),
  item_count            integer check (item_count is null or item_count >= 0),
  request_id            uuid,
  client_ip_hash        bytea check (client_ip_hash is null or octet_length(client_ip_hash) = 32),
  details               jsonb not null default '{}'::jsonb,
  constraint audit_log_details_size_chk check (octet_length(details::text) <= 2048),
  constraint audit_log_details_keys_chk check (not (details ?| array[
    'name', 'full_name', 'phone', 'birth_date', 'code', 'code_hash', 'pin', 'password', 'token', 'secret', 'email',
    'amount', 'score', 'max_score', 'note', 'notes', 'payload', 'records']))
);

-- 2-18 سجل المراجعات (خاص): القيم القديمة والجديدة والفاعل لحضور/درجات (R-045). يُقرأ عبر view record_history فقط.
create table private.record_revisions (
  id                       uuid primary key default gen_random_uuid(),
  seq                      bigint generated always as identity unique,
  at                       timestamptz not null default now(),
  class_id                 uuid not null references public.classes (id),
  entity                   text not null check (entity in ('attendance_records', 'grades')),
  record_id                uuid not null,
  student_id               uuid not null,
  version                  integer not null,
  action                   text not null check (action in ('update', 'archive', 'restore')),
  changes                  jsonb not null,
  actor_member_id          uuid references public.members (id),
  support_target_member_id uuid references public.members (id)
);

-- 2-19 البيانات الوصفية والإعدادات (صف واحد لكل منها حيث ينطبق).
create table public.app_meta (
  id                 boolean primary key default true check (id),
  schema_version     integer not null check (schema_version >= 1),
  min_client_version text not null default '0.0.0' check (min_client_version ~ '^[0-9]+\.[0-9]+\.[0-9]+$'),
  updated_at         timestamptz not null default now()
);

create table public.class_settings (
  class_id      uuid primary key references public.classes (id),
  grade_rule    text not null default 'mean_percent' check (grade_rule in ('mean_percent')),
  schedule_days text[] not null default array['sun', 'mon', 'tue', 'wed', 'thu'],
  created_at    timestamptz not null default now(),
  created_by    uuid references public.members (id),
  updated_at    timestamptz not null default now(),
  updated_by    uuid references public.members (id),
  version       integer not null default 1,
  constraint class_settings_days_chk check (
    cardinality(schedule_days) between 1 and 7 and schedule_days <@ array['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri']::text[])
);

create table public.system_settings (
  id                         boolean primary key default true check (id),
  storage_quota_bytes        bigint not null default 1073741824 check (storage_quota_bytes > 0),
  storage_warn_pct           smallint not null default 70,
  storage_strong_pct         smallint not null default 90,
  storage_reject_pct         smallint not null default 95,
  db_quota_bytes             bigint not null default 524288000 check (db_quota_bytes > 0),
  activation_code_ttl_hours  integer not null default 168 check (activation_code_ttl_hours between 1 and 720),
  audit_retention_months     smallint not null default 12 check (audit_retention_months >= 12),
  attempts_retention_days    smallint not null default 90 check (attempts_retention_days >= 30),
  created_at                 timestamptz not null default now(),
  created_by                 uuid references public.members (id),
  updated_at                 timestamptz not null default now(),
  updated_by                 uuid references public.members (id),
  constraint system_settings_pct_chk check (0 < storage_warn_pct and storage_warn_pct < storage_strong_pct
    and storage_strong_pct < storage_reject_pct and storage_reject_pct <= 100)
);

-- ───────────────────────── 3) الفهارس ─────────────────────────
-- الهوية: مطوّر واحد للأبد، وعضوية فعّالة/موقوفة واحدة لكل مستخدم Auth، وعضوية واحدة لكل طالب.
create unique index members_one_developer on public.members ((true)) where role = 'developer';
create unique index members_one_live_per_user on public.members (user_id) where user_id is not null and status in ('active', 'suspended');
create unique index members_one_per_student on public.members (student_id) where student_id is not null;
create index members_class_role_idx on public.members (class_id, role);

create index students_class_idx on public.students (class_id) where archived_at is null;
create index students_name_trgm_idx on public.students using gin (name_key extensions.gin_trgm_ops);
create index students_phone_trgm_idx on public.students using gin (phone extensions.gin_trgm_ops);

create unique index activation_codes_one_live_per_member on private.activation_codes (member_id) where consumed_at is null and revoked_at is null;
create index activation_codes_expires_idx on private.activation_codes (expires_at);
create index activation_attempts_ip_idx on private.activation_attempts (ip_hash, attempted_at);
create index activation_attempts_at_idx on private.activation_attempts (attempted_at);

create index attendance_records_student_idx on public.attendance_records (student_id, sheet_id);
create index attendance_records_sheet_idx on public.attendance_records (sheet_id);

create unique index grades_one_live_idx on public.grades (student_id, subject_key, term, coalesce(period_month, 0)) where archived_at is null;
create index grades_class_student_idx on public.grades (class_id, student_id);

create index exams_class_date_idx on public.exams (class_id, exam_date) where archived_at is null;
create index schedule_entries_class_day_idx on public.schedule_entries (class_id, weekday, period_no) where archived_at is null;
create index preps_class_day_idx on public.preps (class_id, school_date desc, subject_key);
create index preps_pinned_idx on public.preps (class_id, pinned_at) where pinned_at is not null and archived_at is null;
create unique index homework_one_per_prep_idx on public.homework (prep_id) where prep_id is not null and archived_at is null;
create index homework_class_day_idx on public.homework (class_id, school_date) where prep_id is null;
create index announcements_class_pub_idx on public.announcements (class_id, published_at desc) where archived_at is null;
create index file_objects_prep_idx on public.file_objects (prep_id) where prep_id is not null;
create index file_objects_homework_idx on public.file_objects (homework_id) where homework_id is not null;
create index file_objects_exam_idx on public.file_objects (exam_id) where exam_id is not null;
create index file_objects_class_idx on public.file_objects (class_id);
create index cost_assignments_student_idx on public.cost_assignments (student_id);
create index payments_assignment_idx on public.payments (assignment_id);
create index payments_student_day_idx on public.payments (student_id, paid_on);
create index notifications_class_idx on public.notifications (class_id, created_at desc);
create index notification_reads_notification_idx on public.notification_reads (notification_id);
create index push_subscriptions_member_idx on public.push_subscriptions (member_id);
create unique index support_sessions_one_open_idx on public.support_sessions (developer_member_id) where ended_at is null;
create index audit_log_at_idx on public.audit_log (at desc);
create index audit_log_actor_idx on public.audit_log (actor_member_id, at desc);
create index audit_log_entity_idx on public.audit_log (entity, entity_id);
create index record_revisions_record_idx on private.record_revisions (class_id, entity, record_id, at);
create index record_revisions_student_idx on private.record_revisions (student_id);

-- ───────────────────────── 4) دوال الهوية والتدقيق ─────────────────────────
-- الفاعل الحالي من جدول members (لا من JWT claims) — ADR-306. null لغير الأعضاء/المفتاح الخدمي.
create or replace function private.actor_member_id() returns uuid
language sql stable security definer set search_path = '' as $$
  select m.id from public.members m where m.user_id = (select auth.uid()) and m.status = 'active' $$;

create or replace function private.me() returns table (member_id uuid, role text, class_id uuid)
language sql stable security definer set search_path = '' as $$
  select m.id, m.role, m.class_id from public.members m where m.user_id = (select auth.uid()) and m.status = 'active' $$;

-- جلسة الدعم المفتوحة غير المنتهية للمطوّر الحالي: هدفها، وإلا null.
create or replace function private.support_target() returns uuid
language sql stable security definer set search_path = '' as $$
  select s.target_member_id from public.support_sessions s
  where s.developer_member_id = private.actor_member_id() and s.ended_at is null and s.ends_at > now() limit 1 $$;

-- تُستدعى من كل RPC كتابة: أثناء دعم مفتوح ترفض الكتابة بلا تأكيد صريح (AM-20، L-13).
create or replace function private.require_support_confirm(p_confirm boolean) returns void
language plpgsql stable security definer set search_path = '' as $$
begin
  if private.support_target() is not null and coalesce(p_confirm, false) is not true then
    raise exception 'support_confirm_required' using errcode = '42501';
  end if;
end $$;

-- الإدراج الوحيد في audit_log (لا منحة INSERT لأي دور). فشله يُفشل المعاملة التي استدعته.
create or replace function private.audit(
  p_action text, p_entity text default null, p_entity_id uuid default null, p_class_id uuid default null,
  p_outcome text default 'success', p_reason text default null, p_count integer default null,
  p_details jsonb default '{}'::jsonb, p_request_id uuid default null, p_ip_hash bytea default null) returns uuid
language plpgsql security definer set search_path = '' as $$
declare act uuid := private.actor_member_id(); rid uuid;
begin
  insert into public.audit_log (actor_member_id, actor_role, class_id, action, entity, entity_id, support_target_member_id,
                                outcome, reason_code, item_count, request_id, client_ip_hash, details)
  values (act, (select m.role from public.members m where m.id = act), p_class_id, p_action, p_entity, p_entity_id,
          private.support_target(), p_outcome, p_reason, p_count, p_request_id, p_ip_hash, coalesce(p_details, '{}'::jsonb))
  returning id into rid;
  return rid;
end $$;

-- ───────────────────────── 5) دوال المشغّلات ─────────────────────────
-- ختم الإنشاء/التعديل والإصدار والأرشفة. لا يثق بقيم العميل: يفرض الفاعل ووقت الخادم.
create or replace function private.stamp() returns trigger language plpgsql security definer set search_path = '' as $$
declare act uuid := private.actor_member_id(); j jsonb := to_jsonb(new); oj jsonb; patch jsonb;
begin
  if tg_op = 'INSERT' then
    patch := jsonb_build_object('created_at', now(), 'updated_at', now());
    if act is not null then patch := patch || jsonb_build_object('created_by', act, 'updated_by', act); end if;
    if j ? 'version' then patch := patch || '{"version":1}'::jsonb; end if;
  else
    oj := to_jsonb(old);
    patch := jsonb_build_object('updated_at', now());
    if act is not null then patch := patch || jsonb_build_object('updated_by', act); end if;
    if j ? 'version' then patch := patch || jsonb_build_object('version', (oj ->> 'version')::integer + 1); end if;
    if j ? 'archived_at' then
      if j -> 'archived_at' <> 'null'::jsonb and oj -> 'archived_at' = 'null'::jsonb then
        patch := patch || jsonb_build_object('archived_by', coalesce(act, (j ->> 'archived_by')::uuid));
      elsif j -> 'archived_at' = 'null'::jsonb and oj -> 'archived_at' <> 'null'::jsonb then
        patch := patch || '{"archived_by":null}'::jsonb;
      end if;
    end if;
  end if;
  new := jsonb_populate_record(new, patch);
  return new;
end $$;

-- أعمدة لا تتغير بعد الإنشاء (الأسماء في tg_argv). يمنع نقل صف بين الشعب أو تبديل أصله.
create or replace function private.forbid_change() returns trigger language plpgsql as $$
declare c text;
begin
  foreach c in array tg_argv loop
    if to_jsonb(new) -> c is distinct from to_jsonb(old) -> c then
      raise exception 'column % is immutable on %.%', c, tg_table_schema, tg_table_name using errcode = '23001';
    end if;
  end loop;
  return new;
end $$;

create or replace function private.no_delete() returns trigger language plpgsql as $$
begin
  raise exception 'hard delete/truncate is forbidden on %.% (use archive)', tg_table_schema, tg_table_name using errcode = '23001';
end $$;

create or replace function private.append_only() returns trigger language plpgsql as $$
begin
  raise exception '%.% is append-only', tg_table_schema, tg_table_name using errcode = '23001';
end $$;

create or replace function private.members_guard() returns trigger language plpgsql security definer set search_path = '' as $$
declare act uuid := private.actor_member_id();
begin
  if tg_op = 'UPDATE' then
    if old.user_id is not null and new.user_id is distinct from old.user_id then
      raise exception 'members.user_id is bound once' using errcode = '23001';
    end if;
    if new.status is distinct from old.status then
      if new.status = 'pending' then raise exception 'a member cannot return to pending' using errcode = '23514'; end if;
      new.session_epoch := old.session_epoch + 1;
      new.status_changed_at := now();
      new.status_changed_by := coalesce(act, new.status_changed_by);
      if new.status = 'archived' then
        new.archived_at := coalesce(new.archived_at, now());
        new.archived_by := coalesce(act, new.archived_by);
      else
        new.archived_at := null;
        new.archived_by := null;
      end if;
    end if;
  end if;
  return new;
end $$;

create or replace function private.code_guard() returns trigger language plpgsql security definer set search_path = '' as $$
declare r text;
begin
  if tg_op = 'INSERT' then
    select m.role into r from public.members m where m.id = new.member_id;
    if r is null or r not in ('rep', 'student') then
      raise exception 'activation codes target rep or student members only' using errcode = '23514';
    end if;
  else
    if old.consumed_at is not null and new.consumed_at is distinct from old.consumed_at then
      raise exception 'consumed_at is final' using errcode = '23001'; end if;
    if old.revoked_at is not null and (new.revoked_at is distinct from old.revoked_at or new.revoked_by is distinct from old.revoked_by) then
      raise exception 'revocation is final' using errcode = '23001'; end if;
  end if;
  return new;
end $$;

-- الكشف المعتمد نهائي الحالة ومكتمل: لكل طالب غير مؤرشف سجل (غير المحدد يكون «حاضر» بإدراج RPC قبل الاعتماد).
create or replace function private.sheet_guard() returns trigger language plpgsql security definer set search_path = '' as $$
declare missing integer;
begin
  if old.status = 'approved' and new.status <> 'approved' then
    raise exception 'an approved sheet cannot return to draft' using errcode = '23514';
  end if;
  if old.status <> 'approved' and new.status = 'approved' then
    select count(*) into missing from public.students s
    where s.class_id = new.class_id and s.archived_at is null
      and not exists (select 1 from public.attendance_records r where r.sheet_id = new.id and r.student_id = s.id);
    if missing > 0 then
      raise exception 'sheet incomplete: % student(s) without a record', missing using errcode = '23514';
    end if;
  end if;
  return new;
end $$;

create or replace function private.assignment_guard() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    if new.amount_due is null then
      select i.amount into new.amount_due from public.cost_items i where i.id = new.cost_item_id and i.class_id = new.class_id;
    end if;
    if new.paid_total <> 0 then raise exception 'paid_total starts at zero' using errcode = '23514'; end if;
  elsif new.paid_total is distinct from old.paid_total and pg_trigger_depth() < 2 then
    raise exception 'paid_total is maintained by payment triggers only' using errcode = '23001';
  end if;
  return new;
end $$;

create or replace function private.payment_guard() returns trigger language plpgsql security definer set search_path = '' as $$
declare keep text[] := array['archived_at', 'archived_by', 'archive_reason', 'updated_at', 'updated_by', 'version'];
begin
  if tg_op = 'INSERT' then
    if exists (select 1 from public.cost_assignments a where a.id = new.assignment_id and a.archived_at is not null) then
      raise exception 'cannot pay an archived assignment' using errcode = '23514';
    end if;
  else
    if (to_jsonb(new) - keep) is distinct from (to_jsonb(old) - keep) then
      raise exception 'payments are append-only; void and record a new payment' using errcode = '23001';
    end if;
    if old.archived_at is not null and new.archived_at is distinct from old.archived_at then
      raise exception 'a voided payment is final' using errcode = '23001';
    end if;
  end if;
  return new;
end $$;

-- يحافظ على مجموع الدفعات في الإسناد. يقفل الصف أولاً ثم يحسب بلقطة جديدة فلا يضيع تحديث عند دفعتين متزامنتين.
create or replace function private.payment_totals() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  perform 1 from public.cost_assignments a where a.id = new.assignment_id for update;
  update public.cost_assignments a
     set paid_total = coalesce((select sum(p.amount) from public.payments p where p.assignment_id = a.id and p.archived_at is null), 0)
   where a.id = new.assignment_id;
  return null;
end $$;

create or replace function private.prep_status_guard() returns trigger language plpgsql security definer set search_path = '' as $$
declare d date;
begin
  if new.postponed_to_date is not null then
    select p.school_date into d from public.preps p where p.id = new.prep_id;
    if new.postponed_to_date <= d then
      raise exception 'postponed_to_date must be after the prep day' using errcode = '23514';
    end if;
  end if;
  return new;
end $$;

create or replace function private.support_guard() returns trigger language plpgsql security definer set search_path = '' as $$
declare dr text; tr text;
begin
  if tg_op = 'INSERT' then
    select m.role into dr from public.members m where m.id = new.developer_member_id;
    select m.role into tr from public.members m where m.id = new.target_member_id;
    if dr is distinct from 'developer' or tr is null or tr not in ('rep', 'student') then
      raise exception 'support sessions: developer -> rep/student only' using errcode = '23514';
    end if;
  elsif old.ended_at is not null and new.ended_at is distinct from old.ended_at then
    raise exception 'ended_at is final' using errcode = '23001';
  end if;
  return new;
end $$;

-- سقف الملفات الناعم (ADR-312): رفض إدراج مرفق جديد إذا بلغ الاستخدام عتبة الرفض.
create or replace function private.file_guard() returns trigger language plpgsql security definer set search_path = '' as $$
declare used bigint; s public.system_settings%rowtype;
begin
  select * into s from public.system_settings where id;
  select coalesce(sum(f.byte_size + coalesce(f.thumb_byte_size, 0)), 0) into used from public.file_objects f;
  if (used + new.byte_size + coalesce(new.thumb_byte_size, 0)) * 100 >= s.storage_quota_bytes * s.storage_reject_pct then
    raise exception 'storage_quota_exceeded' using errcode = '53100';
  end if;
  return new;
end $$;

-- إشعار واحد لكل حدث: إنشاء، أو تعديل جوهري (لا تثبيت ولا أرشفة) لم يسبقه إشعار للصف نفسه خلال 10 دقائق.
create or replace function private.notify_content() returns trigger language plpgsql security definer set search_path = '' as $$
declare k text; e text; j jsonb := to_jsonb(new); t text;
        ignore text[] := array['updated_at', 'updated_by', 'version', 'pinned_at', 'archived_at', 'archived_by'];
begin
  if new.archived_at is not null then return null; end if;
  k := case tg_table_name when 'announcements' then 'announcement' when 'preps' then 'prep' else 'exam' end;
  if tg_op = 'INSERT' then
    e := 'created';
  else
    if (j - ignore) = (to_jsonb(old) - ignore) then return null; end if;
    if exists (select 1 from public.notifications n where n.ref_id = new.id and n.created_at > now() - interval '10 minutes') then
      return null;
    end if;
    e := 'updated';
  end if;
  t := case k
         when 'announcement' then j ->> 'title'
         when 'prep' then (case e when 'created' then 'تحضير جديد: ' else 'تحضير معدّل: ' end) || (j ->> 'subject')
         else (case e when 'created' then 'امتحان جديد: ' else 'امتحان معدّل: ' end) || (j ->> 'subject') end;
  insert into public.notifications (class_id, kind, event, ref_id, title, dedupe_key)
  values (new.class_id, k, e, new.id, left(t, 120),
          k || ':' || new.id || ':' || e || ':' || floor(extract(epoch from now()) / 600)::bigint)
  on conflict (dedupe_key) do nothing;
  return null;
end $$;

-- سجل المراجعات: يُنشأ عند تعديل/أرشفة/استعادة فقط (لا عند الإنشاء: created_at/created_by في الصف نفسه تكفي، وقيمة الإنشاء الأولى
-- تبقى في حقل old لأول تعديل). يسجّل قيماً قديمة/جديدة وفاعلاً وهدف دعم؛ لا صف إن لم يتغير عمود عمل (E-014).
create or replace function private.record_revision() returns trigger language plpgsql security definer set search_path = '' as $$
declare
  skip text[] := array['updated_at', 'updated_by', 'version', 'created_at', 'created_by', 'archived_by', 'subject_key', 'id', 'class_id', 'student_id', 'sheet_id'];
  n jsonb := to_jsonb(new) - array['updated_at', 'updated_by', 'version', 'created_at', 'created_by', 'archived_by', 'subject_key', 'id', 'class_id', 'student_id', 'sheet_id'];
  o jsonb := to_jsonb(old) - array['updated_at', 'updated_by', 'version', 'created_at', 'created_by', 'archived_by', 'subject_key', 'id', 'class_id', 'student_id', 'sheet_id'];
  chg jsonb := '{}'::jsonb; k text; act text;
begin
  for k in select jsonb_object_keys(n) loop
    if n -> k is distinct from o -> k then chg := chg || jsonb_build_object(k, jsonb_build_object('old', o -> k, 'new', n -> k)); end if;
  end loop;
  if chg = '{}'::jsonb then return null; end if;
  act := case when o -> 'archived_at' = 'null'::jsonb and n -> 'archived_at' <> 'null'::jsonb then 'archive'
              when o -> 'archived_at' <> 'null'::jsonb and n -> 'archived_at' = 'null'::jsonb then 'restore'
              else 'update' end;
  insert into private.record_revisions (class_id, entity, record_id, student_id, version, action, changes, actor_member_id, support_target_member_id)
  values (new.class_id, tg_table_name, new.id, new.student_id, (to_jsonb(new) ->> 'version')::integer, act, chg,
          private.actor_member_id(), private.support_target());
  return null;
end $$;

create or replace function private.seed_class() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.class_settings (class_id) values (new.id) on conflict do nothing;
  return null;
end $$;

-- ───────────────────────── 6) ربط المشغّلات ─────────────────────────
do $$
declare t text;
begin
  -- الختم على كل جدول يحمل أعمدة created_*/updated_*.
  foreach t in array array['classes', 'members', 'students', 'attendance_sheets', 'attendance_records', 'grades', 'exams',
      'schedule_entries', 'preps', 'prep_status', 'homework', 'announcements', 'file_objects', 'cost_items',
      'cost_assignments', 'payments', 'class_settings', 'system_settings'] loop
    execute format('create trigger trg_b_stamp before insert or update on public.%I for each row execute function private.stamp()', t);
  end loop;
  -- منع الحذف الصلب والتفريغ على كل سجل أكاديمي/مالي/هوية/تدقيق.
  foreach t in array array['classes', 'members', 'students', 'attendance_sheets', 'attendance_records', 'grades', 'exams',
      'schedule_entries', 'preps', 'prep_status', 'homework', 'announcements', 'file_objects', 'cost_items',
      'cost_assignments', 'payments', 'support_sessions', 'class_settings'] loop
    execute format('create trigger trg_a_no_delete before delete on public.%I for each row execute function private.no_delete()', t);
    execute format('create trigger trg_a_no_truncate before truncate on public.%I for each statement execute function private.no_delete()', t);
  end loop;
end $$;

create trigger trg_a_no_delete before delete on private.record_revisions for each row execute function private.no_delete();
create trigger trg_a_no_truncate before truncate on private.record_revisions for each statement execute function private.no_delete();
create trigger trg_a_append_only before update on private.record_revisions for each row execute function private.append_only();
create trigger trg_audit_append_only before update or delete on public.audit_log for each row execute function private.append_only();
create trigger trg_audit_no_truncate before truncate on public.audit_log for each statement execute function private.append_only();
create trigger trg_a_append_only before update on public.notifications for each row execute function private.append_only();

-- أعمدة ثابتة لكل جدول.
create trigger trg_a_fixed before update on public.classes for each row execute function private.forbid_change('id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.members for each row execute function private.forbid_change('id', 'role', 'class_id', 'student_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.students for each row execute function private.forbid_change('id', 'class_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.attendance_sheets for each row execute function private.forbid_change('id', 'class_id', 'school_date', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.attendance_records for each row execute function private.forbid_change('id', 'class_id', 'sheet_id', 'student_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.grades for each row execute function private.forbid_change('id', 'class_id', 'student_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.exams for each row execute function private.forbid_change('id', 'class_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.schedule_entries for each row execute function private.forbid_change('id', 'class_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.preps for each row execute function private.forbid_change('id', 'class_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.prep_status for each row execute function private.forbid_change('id', 'class_id', 'prep_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.homework for each row execute function private.forbid_change('id', 'class_id', 'prep_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.announcements for each row execute function private.forbid_change('id', 'class_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.file_objects for each row execute function private.forbid_change(
  'id', 'class_id', 'prep_id', 'homework_id', 'exam_id', 'storage_path', 'thumb_path', 'mime_type', 'byte_size', 'thumb_byte_size', 'sha256', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.cost_items for each row execute function private.forbid_change('id', 'class_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.cost_assignments for each row execute function private.forbid_change('id', 'class_id', 'cost_item_id', 'student_id', 'created_at', 'created_by');
create trigger trg_a_fixed before update on public.notification_reads for each row execute function private.forbid_change('notification_id', 'member_id', 'class_id');
create trigger trg_a_fixed before update on public.push_subscriptions for each row execute function private.forbid_change('id', 'member_id', 'endpoint', 'created_at');
create trigger trg_a_fixed before update on public.support_sessions for each row execute function private.forbid_change('id', 'developer_member_id', 'target_member_id', 'reason', 'started_at', 'ends_at');
create trigger trg_a_fixed before update on private.activation_codes for each row execute function private.forbid_change(
  'id', 'class_id', 'member_id', 'code_hash', 'purpose', 'issued_by', 'issued_at', 'expires_at');

-- حراس المجال.
create trigger trg_c_members_guard before insert or update on public.members for each row execute function private.members_guard();
create trigger trg_c_code_guard before insert or update on private.activation_codes for each row execute function private.code_guard();
create trigger trg_c_sheet_guard before update on public.attendance_sheets for each row execute function private.sheet_guard();
create trigger trg_c_assignment_guard before insert or update on public.cost_assignments for each row execute function private.assignment_guard();
create trigger trg_c_payment_guard before insert or update on public.payments for each row execute function private.payment_guard();
create trigger trg_d_payment_totals after insert or update of archived_at on public.payments for each row execute function private.payment_totals();
create trigger trg_c_prep_status_guard before insert or update on public.prep_status for each row execute function private.prep_status_guard();
create trigger trg_c_support_guard before insert or update on public.support_sessions for each row execute function private.support_guard();
create trigger trg_c_file_guard before insert on public.file_objects for each row execute function private.file_guard();
create trigger trg_d_notify after insert or update on public.announcements for each row execute function private.notify_content();
create trigger trg_d_notify after insert or update on public.preps for each row execute function private.notify_content();
create trigger trg_d_notify after insert or update on public.exams for each row execute function private.notify_content();
create trigger trg_d_revision after update on public.attendance_records for each row execute function private.record_revision();
create trigger trg_d_revision after update on public.grades for each row execute function private.record_revision();
create trigger trg_d_seed_class after insert on public.classes for each row execute function private.seed_class();

-- ───────────────────────── 7) الاحتفاظ والتنظيف ─────────────────────────
-- تنظيف ما يحق تنظيفه فقط (سياسة DATA-MODEL-V2 §8): محاولات التفعيل، رموز منتهية نهائياً، إشعارات قديمة، اشتراكات ملغاة.
create or replace function private.purge_expired() returns jsonb language plpgsql security definer set search_path = '' as $$
declare s public.system_settings%rowtype; a integer; c integer; n integer; p integer;
begin
  select * into s from public.system_settings where id;
  delete from private.activation_attempts where attempted_at < now() - make_interval(days => s.attempts_retention_days);
  get diagnostics a = row_count;
  -- رمز انتهى (استُهلك/أُبطل/انقضى) منذ أكثر من مدة الاحتفاظ ولا محاولة باقية عليه.
  delete from private.activation_codes k
   where coalesce(k.consumed_at, k.revoked_at, k.expires_at) < now() - make_interval(days => s.attempts_retention_days)
     and (k.consumed_at is not null or k.revoked_at is not null or k.expires_at < now())
     and not exists (select 1 from private.activation_attempts t where t.code_id = k.id);
  get diagnostics c = row_count;
  delete from public.notification_reads r using public.notifications x where r.notification_id = x.id and x.created_at < now() - interval '12 months';
  delete from public.notifications where created_at < now() - interval '12 months';
  get diagnostics n = row_count;
  delete from public.push_subscriptions where revoked_at is not null and revoked_at < now() - interval '30 days';
  get diagnostics p = row_count;
  return jsonb_build_object('attempts', a, 'codes', c, 'notifications', n, 'push', p);
end $$;

-- تدوير التدقيق: بعد تصدير موثّق فقط، ولا أحدث من audit_retention_months (12 افتراضياً). المسار الوحيد للحذف من audit_log.
create or replace function private.purge_audit(p_exported_through timestamptz) returns integer
language plpgsql security definer set search_path = '' as $$
declare s public.system_settings%rowtype; cutoff timestamptz; n integer;
begin
  if p_exported_through is null then raise exception 'purge_audit requires a documented export timestamp' using errcode = '23514'; end if;
  select * into s from public.system_settings where id;
  cutoff := least(p_exported_through, now() - make_interval(months => s.audit_retention_months));
  alter table public.audit_log disable trigger trg_audit_append_only;
  delete from public.audit_log where at < cutoff;
  get diagnostics n = row_count;
  alter table public.audit_log enable trigger trg_audit_append_only;
  insert into public.audit_log (action, outcome, item_count, reason_code) values ('audit.purged', 'success', n, 'retention');
  return n;
end $$;

-- استخدام التخزين: يحسب من file_objects (المؤرشف يشغل مساحة أيضاً). المستويات حسب عتبات system_settings.
create or replace function private.storage_usage(p_class_id uuid default null)
returns table (files_count bigint, used_bytes bigint, quota_bytes bigint, used_pct numeric, level text)
language sql stable security definer set search_path = '' as $$
  with s as (select * from public.system_settings where id),
       u as (select count(*) c, coalesce(sum(f.byte_size + coalesce(f.thumb_byte_size, 0)), 0)::bigint b
             from public.file_objects f where p_class_id is null or f.class_id = p_class_id),
       t as (select coalesce(sum(f.byte_size + coalesce(f.thumb_byte_size, 0)), 0)::bigint b from public.file_objects f)
  select u.c, u.b, s.storage_quota_bytes, round(t.b * 100.0 / s.storage_quota_bytes, 2),
         case when t.b * 100 >= s.storage_quota_bytes * s.storage_reject_pct then 'reject'
              when t.b * 100 >= s.storage_quota_bytes * s.storage_strong_pct then 'strong'
              when t.b * 100 >= s.storage_quota_bytes * s.storage_warn_pct then 'warn' else 'ok' end
  from u, s, t $$;

-- فحص تطابق المجاميع المخزّنة مع الدفعات (يُستدعى في الاختبار وفي 09.05 بعد الاستعادة). يعيد الإسنادات المنحرفة.
create or replace function private.verify_cost_totals() returns table (assignment_id uuid, stored bigint, actual bigint)
language sql stable security definer set search_path = '' as $$
  select a.id, a.paid_total, coalesce(sum(p.amount) filter (where p.archived_at is null), 0)::bigint
  from public.cost_assignments a left join public.payments p on p.assignment_id = a.id
  group by a.id, a.paid_total
  having a.paid_total <> coalesce(sum(p.amount) filter (where p.archived_at is null), 0) $$;

-- ───────────────────────── 8) الـviews ─────────────────────────
-- إحصاءات التكاليف: security_invoker فتحترم RLS الجداول الأصلية؛ لا منحة للطالب (يكشف أعداد زملائه).
create view public.cost_stats with (security_invoker = true) as
select i.id as cost_item_id, i.class_id, i.title, i.amount as unit_amount,
       count(a.id) as students_count,
       coalesce(sum(a.amount_due), 0)::bigint as due_total,
       coalesce(sum(a.paid_total), 0)::bigint as paid_total,
       (coalesce(sum(a.amount_due), 0) - coalesce(sum(a.paid_total), 0))::bigint as remaining_total,
       count(a.id) filter (where a.pay_status = 'paid') as paid_count,
       count(a.id) filter (where a.pay_status = 'partial') as partial_count,
       count(a.id) filter (where a.pay_status = 'unpaid') as unpaid_count
from public.cost_items i
left join public.cost_assignments a on a.cost_item_id = i.id and a.archived_at is null
where i.archived_at is null
group by i.id;

-- سجل التعديلات للممثل/المطوّر: بوابة مقصودة على private.record_revisions (مالك العرض، security_barrier)، لا security_invoker
-- لأن الجدول الخلفي خاص بلا منح. التصفية داخل التعريف: المطوّر كل شيء، الممثل صفّه فقط، غيرهما لا شيء (E-013).
create view public.record_history with (security_barrier = true) as
select r.id, r.class_id, r.entity, r.record_id, r.student_id, r.version, r.action, r.changes, r.actor_member_id,
       m.display_name as actor_name, r.at
from private.record_revisions r
left join public.members m on m.id = r.actor_member_id
where exists (select 1 from private.me() me
              where me.role = 'developer' or (me.role = 'rep' and me.class_id = r.class_id));

-- ───────────────────────── 9) البذور ─────────────────────────
insert into private.audit_event_types (action, category, description) values
  ('code.issued', 'code', 'إصدار رمز تفعيل/إعادة تفعيل'),
  ('code.consumed', 'code', 'استهلاك رمز ناجح'),
  ('code.failed', 'code', 'محاولة تفعيل فاشلة (السبب الداخلي في reason_code فقط)'),
  ('code.revoked', 'code', 'إبطال رمز'),
  ('member.created', 'member', 'إنشاء عضوية (ممثل/طالب)'),
  ('member.suspended', 'member', 'تعليق عضوية'),
  ('member.reactivated', 'member', 'إعادة تفعيل عضوية'),
  ('member.archived', 'member', 'أرشفة عضوية (مغادرة)'),
  ('support.opened', 'support', 'فتح جلسة دعم'),
  ('support.closed', 'support', 'إغلاق جلسة دعم'),
  ('support.write', 'support', 'كتابة أثناء جلسة دعم'),
  ('student.created', 'data', 'إضافة طالب'),
  ('student.updated', 'data', 'تعديل ملف طالب'),
  ('student.archived', 'data', 'أرشفة طالب'),
  ('student.restored', 'data', 'استعادة طالب'),
  ('student.imported', 'data', 'استيراد قائمة طلاب'),
  ('attendance.approved', 'data', 'اعتماد كشف حضور'),
  ('attendance.corrected', 'data', 'تعديل سجل/كشف حضور سابق'),
  ('attendance.archived', 'data', 'أرشفة كشف حضور'),
  ('grade.changed', 'data', 'إضافة/تعديل درجة'),
  ('grade.archived', 'data', 'أرشفة درجة'),
  ('cost.created', 'data', 'إنشاء بند تكلفة وإسناده'),
  ('cost.changed', 'data', 'تعديل بند أو مبلغ مستحق'),
  ('cost.archived', 'data', 'أرشفة بند/إسناد'),
  ('payment.recorded', 'data', 'تسجيل دفعة'),
  ('payment.voided', 'data', 'إبطال دفعة'),
  ('file.uploaded', 'data', 'تسجيل مرفق'),
  ('file.rejected', 'data', 'رفض مرفق (حصة/نوع/حجم)'),
  ('export.roster', 'export', 'تصدير قائمة الطلاب'),
  ('export.backup', 'export', 'تصدير نسخة كاملة'),
  ('restore.executed', 'export', 'استعادة نسخة'),
  ('settings.changed', 'system', 'تغيير إعدادات الشعبة/النظام'),
  ('class.updated', 'system', 'تعديل بيانات الشعبة'),
  ('access.denied', 'access', 'رفض وصول ملاحَظ'),
  ('audit.purged', 'system', 'تدوير سجل التدقيق بعد تصدير موثق');

insert into public.app_meta (schema_version) values (1);
insert into public.system_settings default values;
insert into public.classes (name) values ('الشعبة الأولى');   -- شعبة واحدة في الإصدار الأول؛ يغيّر المطوّر اسمها (class_settings تُبذر بمشغّل).

-- ───────────────────────── 10) RLS والمنح (رفض افتراضي) ─────────────────────────
do $$
declare r record;
begin
  for r in select schemaname, tablename from pg_tables where schemaname in ('public', 'private') loop
    execute format('alter table %I.%I enable row level security', r.schemaname, r.tablename);
  end loop;
end $$;

revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;
revoke all on all tables in schema private from public, anon, authenticated;
revoke all on all sequences in schema private from public, anon, authenticated;
revoke all on all functions in schema private from public, anon, authenticated;

-- ما تحتاجه سياسات 03.03 فقط (تُقيَّم بصلاحية المستدعي): قراءة الفاعل واليوم الدراسي. لا شيء آخر.
grant usage on schema private to authenticated;
-- fold_ar وschool_today تُقيَّمان عند إدراج المستدعي (عمود مولَّد/افتراضي) فيلزمهما EXECUTE.
grant execute on function private.me(), private.actor_member_id(), private.school_today(), private.fold_ar(text) to authenticated;
revoke all on public.record_history, public.cost_stats from anon;

-- ───────────────────────── 11) توصيف الجداول (يطابق ACCESS-MATRIX-V2: «الصنف|الوصف») ─────────────────────────
comment on table public.classes is 'C0|الشعبة';
comment on table public.members is 'C4|العضويات (الدور والحالة)';
comment on table public.students is 'C1|ملف الطالب';
comment on table private.activation_codes is 'C4|رموز التفعيل (بصمات HMAC)';
comment on table private.activation_attempts is 'SYS|محاولات التفعيل وحدود المعدل';
comment on table public.attendance_sheets is 'C2|كشوف الحضور اليومية';
comment on table public.attendance_records is 'C2|سجلات الحضور والغياب';
comment on table public.grades is 'C2|الدرجات';
comment on table public.exams is 'C0|الامتحانات';
comment on table public.schedule_entries is 'C0|الجدول الدراسي';
comment on table public.preps is 'C0|التحاضير';
comment on table public.prep_status is 'C0|حالة التحضير';
comment on table public.homework is 'C0|الواجبات';
comment on table public.announcements is 'C0|الإعلانات';
comment on table public.file_objects is 'C0|سجلات المرفقات';
comment on table public.cost_items is 'C3|بنود التكاليف';
comment on table public.cost_assignments is 'C3|إسناد البنود للطلاب';
comment on table public.payments is 'C3|سجل الدفعات';
comment on table public.notifications is 'C0|الإشعارات';
comment on table public.notification_reads is 'SELF|حالة قراءة الإشعار';
comment on table public.push_subscriptions is 'SELF|اشتراكات Push';
comment on table public.support_sessions is 'C4|جلسات وضع الدعم';
comment on table public.audit_log is 'C4|سجل التدقيق';
comment on table public.app_meta is 'SYS|إصدار المخطط';
comment on table public.class_settings is 'C0|إعدادات الشعبة';
comment on table public.system_settings is 'C4|إعدادات النظام';
comment on table private.record_revisions is 'C2|مخزن سجل التعديلات (خلف record_history)';
comment on table private.audit_event_types is 'SYS|كتالوج أحداث التدقيق';
comment on view public.cost_stats is 'C3|إحصاءات التكاليف المجمّعة';
comment on view public.record_history is 'C2|سجل تعديلات السجلات الأكاديمية';
