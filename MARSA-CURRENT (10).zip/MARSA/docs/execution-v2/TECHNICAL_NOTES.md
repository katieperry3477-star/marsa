# ملاحظات تقنية تم التحقق منها — 2026-11-05

هذه معلومات خارجية متغيرة؛ يجب إعادة التحقق منها من الوثائق الرسمية قبل التنفيذ النهائي أو النشر.

## Supabase Free (وثائق رسمية)

- 500 MB قاعدة بيانات لكل مشروع Free.
- 1 GB تخزين ملفات.
- 50,000 مستخدم نشط شهرياً (MAU).
- 5 GB egress.
- 500,000 استدعاء Edge Functions حسب صفحة التسعير الرسمية.
- مشروع Free قد يتوقف إذا انخفض نشاط قاعدة البيانات مدة أسبوع؛ صفحة الإيقاف توضح أن معيار النشاط قد يختلف ولا يوجد ضمان بأن عدداً ثابتاً من الاستعلامات يمنع الإيقاف.
- صفحة التسعير توضح أن النسخ اليومية المؤتمتة متوفرة ضمن Pro، وليس ضمن Free؛ لذلك لا تعتمد الخطة على نسخ Supabase اليومية المجانية.

مصادر رسمية:
- https://supabase.com/pricing
- https://supabase.com/docs/guides/platform/free-project-pausing
- https://supabase.com/docs/guides/platform/billing-on-supabase
- https://supabase.com/docs/guides/auth/anonymous-sign-ins
- https://supabase.com/docs/guides/auth/rate-limits

## Push على iPhone

تدعم Apple Web Push لتطبيقات الويب المضافة إلى الشاشة الرئيسية على iOS/iPadOS 16.4 أو أحدث؛ يتطلب ذلك Push API وNotifications API وService Worker وخادماً يرسل إشعارات. يجب وجود بديل داخل التطبيق للأجهزة أو المتصفحات التي لا تدعم هذا المسار.

مصادر رسمية:
- https://developer.apple.com/documentation/usernotifications/sending-web-push-notifications-in-web-apps-and-browsers
- https://webkit.org/blog/13878/

## توجيه التنفيذ

- لا تعتمد على anonymous sign-in وحده كحل نهائي لتسجيل الطالب عبر أجهزة متعددة؛ توثيق Supabase يوضح أن المستخدم المجهول قد يفقد الوصول إذا سجّل الخروج أو مسح بيانات المتصفح أو استخدم جهازاً آخر. استخدمه فقط إذا أثبت التصميم أنه يناسب استرداد الحساب وتعدد الأجهزة، وإلا اختر مساراً أقوى مع رموز تفعيل لمرة واحدة.
- لا تفترض أن إشعارات Web Push تعمل تلقائياً داخل APK. يجب اختبار PWA على Safari/iOS وAndroid Chrome، ثم اختبار APK مستقلاً.
- يجب ضغط الصور قبل رفعها، وتسجيل استخدام التخزين، ووضع حدود استخدام واضحة لتجنب استنفاد 1 GB.
