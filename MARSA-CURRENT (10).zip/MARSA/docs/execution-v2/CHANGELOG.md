# سجل تغييرات حزمة التنفيذ

> **ملاحظة (2026-11-08):** ما يرد هنا عن 12 أو 16 صورة أو الوضع الفاتح **مستبدل**؛ القاعدة الحالية: داكن فقط، عدد غير ثابت (`REFERENCE_IMAGES_RULE.md` بنود 10–14).

## 2026-11-05 — إنشاء حزمة V2
- تثبيت مواصفات المنتج المستخلصة من إجابات المستخدم.
- إضافة سجل القرارات وخريطة تنفيذ 43 برومبتاً قصيراً و4 مراجعات Codex اختيارية.
- أرشفة ملف HTML القديم وتقرير الفحص الأولي كمرجع تاريخي.
- لم تتغير ملفات تشغيل V1 أو التطبيق السابق أثناء إنشاء الحزمة.

## 2026-11-07 — البرومبت 00.01: تثبيت خط الأساس
- أُنشئ `BASELINE-RECHECK.md` (تقرير ما يعمل فعلاً وما هو خطة وما تعذر اختباره).
- شُغّلت اختبارات Node وPlaywright كاملة؛ سُجّلت نتائجها الخام في `tools/00.01-*-results.txt`.
- أُضيفت أداة `tools/capture-reference.js` و12 صورة مرجعية في `الصور المرجعية/00.01/`.
- أُضيف `REFERENCE_IMAGES_RULE.md` وربطه في `PROMPT_CONTROL.md` و`START_HERE.md` (قرار دائم من المستخدم).
- صُحّح نص غير مُعبَّأ `{len(codex)}` في `PROMPT_INDEX.md` إلى 4.
- أُضيفت لافتة «مستبدل بقرار 2026-11-05» في `MARSA_PROGRESS.md` و`MARSA_HANDOFF.md`.
- لم يتغير أي كود تطبيق أو اختبار.

## 2026-11-07 — البرومبت 00.02: توحيد القرارات والوثائق
- أُنشئ `LEGACY-RECONCILIATION.md`: 25 تعارضاً جوهرياً (C-01…C-25) بحكم لكل منها، حكم V2 على 33 ADR (001–012، 013–016، 201–217)، وحالة كل سؤال/قرار قديم (Q-01…13، Q1…17، DEC-01…26، D-1…8، G-xx، U-xx).
- أُضيفت لافتة «⚑ حالة التوحيد (00.02)» في أعلى 53 وثيقة قديمة (نصها الأصلي سليم، لا حذف).
- حُدّث `docs/architecture/ADR-INDEX.md` (قسم V2 يضم ADR-201…217 التي لم تكن مفهرسة) و`USER-DECISIONS-STATUS.md` وجداول حالة في `02.03-QUESTIONS` و`5.02-DECISIONS` و`5.04-OPEN-DECISIONS` و`02.02-DECISIONS-AND-ASSUMPTIONS` وقسم في `DECISION-LOG.md`.
- `STATE.json`: 00.02 مكتمل، التالي الموصى به 00.03. `BLOCKERS.md` و`DECISION_REGISTER.md` (ملحق قرارات المنفّذ E-001…E-004) و`HANDOFF.md` محدّثة.
- لم يتغير أي كود تطبيق أو اختبار أو ملف مولَّد أو JSON أمني أو مخطط؛ ولم يُمسّ `docs/execution-v2/legacy/` ولا `archive/`.

## 2026-11-07 — البرومبت 00.03: ربط المتطلبات بالاختبارات
- أُنشئ `REQUIREMENTS-TRACEABILITY.md`: 100 مطلب (R-001…R-100) مرتبطة بالدور والشاشة والبيانات وبرومبت التنفيذ والتحقق، ومعيار قبول قابل للتحقق واختبار مسمّى (`T-Rnnn`) لكل مطلب، و6 متطلبات عملية (P-01…P-06)، وجدول بوابات §14 (9 بنود)، و18 بنداً خارج الإصدار الأول، وفهرس عكسي برومبت←مطالب.
- أُضيفت `tools/check-traceability.js` (21 فحصاً) لحماية اتساق المصفوفة؛ تشغَّل ضمن كل برومبت لاحق يغيّر المصفوفة.
- `STATE.json`: 00.03 مكتمل، التالي الموصى به 00.04. لم يتغير كود ولا اختبار قائم.
- عند ظهور مطلب جديد يُضاف برقم جديد في القسم المناسب ويُعاد تشغيل الفاحص.

## 2026-11-07 — البرومبت 00.04: اعتماد المعمارية والبوابات
- أُنشئ `ARCHITECTURE-V2.md` (المخرج الرئيسي) و`ADR-V2.md` (ADR-301…321 + حكم ADR-201…217) و`THREAT-MODEL-V2.md` (حكم T-01…T-39 + T-40…T-66) و`GATES.md` (GX-00…09، GX-REAL، GX-PUBLISH، تستبدل G-A…G-D) و`tools/check-architecture.js`.
- حُدّثت حالة R-007/R-088/R-089 وربط R-100 بـ02.01 في `REQUIREMENTS-TRACEABILITY.md`.
- أُضيفت لافتات V2 في `02.03-ADR.md` و`02.02-THREAT-MODEL.md` و`ADR-INDEX.md` دون المساس بنصها الأصلي؛ `STATE.json` فيه `gates`.
- لا كود تشغيل ولا حساب ولا نشر.

## 2026-11-08 — تعديل قاعدة الصور المرجعية (قرار المستخدم)
- `tools/capture-reference.js` يلتقط الوضع الداكن فقط (هاتف وحاسبة) مع بقاء `--docs` وكل وظائفه.
- `REFERENCE_IMAGES_RULE.md` بنود 10–14: داكن فقط، عدد غير ثابت، عدم توفر صور مقبول بجملة سبب، لا تُقرأ الصور، تُرسل الداكنة فقط. أُعلمت إشارات 8/12/16 صورة والفاتح السابقة بأنها مستبدلة؛ صور 00.01–00.04 باقية تاريخياً.
- لا تغيير في كود التطبيق.

## 2026-11-08 — البرومبت 01.01: مصفوفة الأدوار والأمان
- أُنشئ `ACCESS-MATRIX-V2.md` (المخرج الرئيسي): مصفوفة R/C/U/A للمطوّر وممثل الصف والطالب لكل من 33 كياناً، قواعد إدارة العضويات والرموز، وضع الدعم، الأسطح غير الجدولية (views، Storage، RPC، Realtime، Push، كاش)، 16 ثابتاً، قوالب RLS غير منفّذة، كتالوج الاختبارات المنفَّذة والمخططة، قرارات المنفّذ E-007…E-012. الخادم/RLS مصدر الصلاحيات؛ لا حذف صلب لأي دور.
- أُضيفت `tests/security/access-matrix-v2.js` (بيانات + `canV2` + `canAdmin` + مدقّق + مولِّدات) و`access-matrix-v2.test.js` (152 فحصاً) و`generate-access-v2.js` و`access-v2-deny-cases.json` (2025 حالة) و`access-v2-expected-grants.json` (لفاحص 03.03).
- حُدّث `THREAT-MODEL-V2.md`: §4-ب (T-67…T-78) وربط التهديدات القائمة بالاختبارات؛ عُدِّل بند الحدود ليقرّ بأن ما نُفِّذ مستوى المصفوفة فقط. حُدّث حارس `tools/check-architecture.js` ليطلب إقرار «لا اختبار على قاعدة/RLS» (لم يُضعَف).
- `DECISION_REGISTER.md`: ملحق E-007…E-012. لا تغيير في كود V1 أو `full.html` (بصمات 14/14).

- (01.01، استكمال) حُدّث عمود «الحالة اليوم» لـR-003 وR-023 في `REQUIREMENTS-TRACEABILITY.md` ليشير إلى `ACCESS-MATRIX-V2.md` مع بيان أن رفض RLS الفعلي لم يُختبر. لم يبدأ أي برومبت آخر.

- (01.01، استكمال) أُضيفت 8 صور مرجعية داكنة في `الصور المرجعية/01.01/` كانت مغفلة خطأً؛ عُدّل سطر الصور في `TEST_EVIDENCE.md`.

## 2026-11-09 — 01.02 تصميم قاعدة البيانات
- إضافة `DATA-MODEL-V2.md` و`db/schema-v2.sql` و`db/stubs-supabase.sql` (محاكاة اختبارية فقط) و`DATA-MODEL-ER.mmd/.svg`.
- إضافة `tests/db/` (مشغّل PostgreSQL مؤقت، 241 فحصاً، مولّد الوثيقة `generate-data-model.js --check`).
- تحديث `THREAT-MODEL-V2.md` §4-ج، `ACCESS-MATRIX-V2.md` §13، `REQUIREMENTS-TRACEABILITY.md` §9.
- لم يُعدَّل كود التطبيق ولا الاختبارات القائمة.

## 2026-11-09 — صور 01.02
- إضافة `الصور المرجعية/01.02/` (6 صور داكنة). لا تغيير في الكود.

## 2026-11-11 — البرومبت 01.05: خريطة الواجهات ونظام التصميم
- أُنشئ `UI-MAP-V2.md` (45 شاشة + 7 مكوّنات إطار، أشرطة وقوائم لكل دور، الصفحات الثلاث، الرئيسية بسقف، قيد التطوير، دعم/دون اتصال/حالات، ثيمات وتباين وحركات، قرارات E-019…E-029) بكتل مولَّدة من `tests/ui/ui-map-v2.js`.
- أُضيفت معاينة تصميم ثابتة `ui/UI-DESIGN-PREVIEW-V2.html` (+PNG) ومخطط تنقل `ui/UI-NAV-V2.{mmd,svg}`؛ مولِّدان `tests/ui/generate-ui-map.js` و`build-preview.js` واختباران `tests/ui/ui-map-v2.test.js` (73) و`tests/e2e-ui-preview.playwright.js` (55).
- وُسّعت `tools/capture-reference.js` بخيار `--pages` (داكن فقط) + إصلاح تظليل متغير `base`.
- حُدّث معجم `REQUIREMENTS-TRACEABILITY.md` (§10 حالة 01.05). **لا كود تطبيق ولا حساب ولا نشر**؛ بصمات 14/14.
- نُفّذ 01.05 قبل 01.03/01.04 بطلب المستخدم؛ يبقى 01.03 التالي الموصى به.

## 2026-11-12 — البرومبت 02.01: تجهيز هيكل V2 دون كسر V1
- أُنشئ `V2-FOUNDATION.md` (المخرج الرئيسي) ومجلد `v2/` المعزول: `index.html` (هيكل بلا inline)، `js/main.js`، `js/core/{constants,storage,i18n,legacy-loader}.js`، `js/i18n/ar.js`، `css/{tokens,base}.css`، `_headers` (CSP صارمة)، `version.json`، وREADME لمجلدات `data/features/ui` التي تُملأ لاحقاً.
- `v2/legacy/`: نسخ حرفية لست وحدات V1 نقية (`safe-text`، `attendance`، `grades`، `exams`، `schedule`، `payments`) + `MANIFEST.json` (بصمات، أجزاء معاد استعمالها، فجوات التكييف مع `schema-v2.sql`، وقائمة 10 استبعادات بأسبابها).
- `scripts/v2-sync.js` (+`--check`): ينسخ ويولّد `MANIFEST.json` و`tokens.css` من `tests/ui/ui-map-v2.js`.
- `docs/execution-v2/v1-parity.sha256`: بصمات 22 ملفاً من V1/`full.html`/`css`/`js` ثُبّتت قبل أي تعديل.
- اختبارات جديدة في `tests/v2/`: `v2-isolation.test.js` (52)، `legacy-parity.test.js` (53)، `e2e-v2-foundation.playwright.js` (28، تحت CSP الحقيقية، ويشمل تجربة الرجوع بحذف `v2/`). سبع طفرات متعمدة (مفتاح V1، سكربت مضمّن، `unsafe-inline`، تعديل ملف V1، انجراف نسخة، مورد خارجي، مفتاح أكاديمي في ملف جديد) كُشفت كلها ثم استُرجعت الملفات.
- قرارات E-030…E-036 في `DECISION_REGISTER.md`؛ حُسم **DEC-21** (قناة MARSA1 لا تُنقل) وحُدّثت إشاراته في `LEGACY-RECONCILIATION.md` و`ARCHITECTURE-V2.md` و`ADR-V2.md`؛ حُدّثت حالة R-098 (جزئي) وR-100 (مختبر) في `REQUIREMENTS-TRACEABILITY.md`.
- **لا تعديل في `index.html` ولا `full.html` ولا `css/*` ولا `js/*`.** لا حساب ولا شبكة ولا نشر.
- صور مرجعية: `الصور المرجعية/02.01/` (8 داكنة: V1 وfull.html وصفحة هيكل V2 بهاتف/حاسبة).

## 2026-11-14 — البرومبت 02.02 (المهمة-009): بناء هيكل الواجهة والتنقل
- **جديد (19 ملفاً):** `scripts/v2-nav-sync.js` (مولِّد التنقل من خريطة الواجهات، مع `--check`)؛ `v2/js/ui/{nav-config*,nav,router,shell,screens,states,store,theme,time,dom,icons,mock-session}.js` و`v2/js/i18n/ar-nav.js` (*مولَّدان) و`v2/js/data/mock.js`؛ `v2/css/{shell,components}.css`؛ `tests/v2/shell-config.test.js` و`tests/v2/e2e-v2-shell.playwright.js`.
- **معدَّل (9):** `v2/index.html` (هيكل القشرة بدل صفحة 02.01)، `v2/js/main.js`، `v2/js/core/i18n.js` (دمج ar-nav + `tf`)، `v2/js/i18n/ar.js` (توسيع؛ أُزيلت مفاتيح `foundation.*` الخاصة بصفحة الهيكل المستبدلة وحُفظت وظائفها: التخطي، رقم البناء، سطر قيد التطوير)، `v2/css/base.css`، `v2/version.json` (`2.0.0-shell.1`)، `tests/v2/e2e-v2-foundation.playwright.js` (تكييف للصفحة الأولى الجديدة)، `tests/v2/legacy-parity.test.js` (فحص المتغيّرات يقبل تعريفاً محلياً ويشمل shell/components)، `docs/execution-v2/tools/capture-reference.js` (خياران اختياريان `--no-base` و`--v2-shell` + تحقق وجود/حجم).
- **لا حذف** لأي ملف أو وظيفة. V1 وfull.html لم يتغيرا (بصمات 22/22 و14/14).
- **وثائق:** `UI-SHELL-REPORT.md` (المخرج الرئيسي)، `PROJECT_MEMORY/` (00–08، جديد)، تحديث `STATE.json` و`DECISION_REGISTER.md` (U2-039/U2-040 وE-037…E-046) و`PROMPT_CONTROL.md` و`REFERENCE_IMAGES_RULE.md` و`HANDOFF.md` و`TEST_EVIDENCE.md` و`BLOCKERS.md` و`START_HERE.md` وREADMEs الخاصة بـ`v2/` وملفات `MARSA_*`.
- **لقطات:** 26 داكنة في `الصور المرجعية/المهمة-009/` (وجود/حجم فقط).
- **نتائج:** Node 31 ملفاً 1300/0 (+1 متخطّى بلا PostgreSQL)؛ Playwright 26 ملفاً 1833/0؛ 8 طفرات كُشفت.
