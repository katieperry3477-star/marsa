# نموذج بيانات مَرسى V2 — البرومبت 01.02

> المصدر المنفَّذ: `docs/execution-v2/db/schema-v2.sql` (مخطط PostgreSQL 16 / Supabase). الجداول والأعمدة والفهارس والمشغّلات والدوال أدناه **مولَّدة من قاعدة حية** حُمِّل فيها المخطط (`node tests/db/generate-data-model.js`، وللتحقق `--check`)، فلا يمكن أن تنحرف الوثيقة عن المخطط دون أن يفشل الفحص.
> المرجع: `ACCESS-MATRIX-V2.md` (33 كيان × 3 أدوار)، `THREAT-MODEL-V2.md`، `ADR-V2.md` (306، 309، 312–315، 319)، `PRODUCT_SPEC.md`.
> ما اختُبر وما لم يُختبر: §12.

## 1) المبادئ
1. **هوية داخلية UUID ثابتة** لكل صف (`gen_random_uuid()`)؛ لا رقم مدرسي، والهاتف خاصية لا مفتاح وقد يتكرر (R-037). `id` غير قابل للتعديل بمشغّل.
2. **تعدد الشعب جاهز لا مفعَّل (R-002):** `class_id` NOT NULL في كل جدول بيانات صفّي؛ كل مفتاح أجنبي إلى جدول صفّي **مركّب `(id, class_id)`** فلا يمكن ربط صف شعبة بصف شعبة أخرى حتى بالخطأ. لا شاشة ولا مسار لإنشاء شعبة ثانية في الإصدار الأول.
3. **لا حذف صلب:** الأرشفة المنطقية (`archived_at`/`revoked_at`) + مشغّلات `no_delete` و`no_truncate`. الاستثناءات المعلنة: التنظيف المجدول بمدة احتفاظ موثقة (§8). الجداول **للإلحاق فقط:** `audit_log`، `record_revisions`، `notifications`، `payments` (الإبطال وحده مسموح).
4. **رفض افتراضي:** RLS مفعّل على كل جدول، **بلا أي سياسة** في هذا البرومبت، مع `revoke` صريح من `anon`/`authenticated`/`public` لأن Supabase يمنح الجداول الجديدة افتراضياً (أُثبت في الاختبار DB-204). السياسات الفعلية في 03.03 وكتابات الحساسة عبر RPC/Edge فقط (E-008).
5. **مخطط `private`** لما لا يُعرَّض عبر الـAPI: رموز التفعيل، محاولات التفعيل، سجل المراجعات، كتالوج الأحداث، والدوال الحساسة. الدوال `SECURITY DEFINER` بـ`search_path` فارغ.
6. **تزامن متفائل `version` فقط حيث تطلبه المصفوفة** (طلاب، كشوف وسجلات حضور، درجات، امتحانات، جدول، بنود التكاليف والإسنادات والدفعات، إعدادات الشعبة)؛ يُرفع تلقائياً بمشغّل ولا يكتبه العميل.
7. **الأوقات `timestamptz`، والأيام الدراسية `date` بتوقيت بغداد** (`private.school_today()`) فلا ينزاح اليوم بين UTC والعراق.
8. **المبالغ أعداد صحيحة بالدينار** (لا عملة ولا كسور، R-066)؛ الدرجات `numeric(6,2)` مع `0 ≤ الدرجة ≤ العظمى ≤ 1000`.

## 2) خريطة الجداول
<!-- GEN:TABLES:START -->
| # | الجدول | الصنف | أعمدة | `class_id` | `version` | أرشفة | مشغّلات | الغرض |
|---|---|---|---|---|---|---|---|---|
| 1 | `public.classes` | C0 | 9 | — | — | ✓ | 5 | الشعبة |
| 2 | `public.students` | C1 | 14 | ✓ | ✓ | ✓ | 4 | ملف الطالب |
| 3 | `public.members` | C4 | 17 | ✓ | — | ✓ | 5 | العضويات (الدور والحالة) |
| 4 | `public.attendance_sheets` | C2 | 13 | ✓ | ✓ | ✓ | 5 | كشوف الحضور اليومية |
| 5 | `public.attendance_records` | C2 | 13 | ✓ | ✓ | ✓ | 5 | سجلات الحضور والغياب |
| 6 | `public.grades` | C2 | 17 | ✓ | ✓ | ✓ | 5 | الدرجات |
| 7 | `public.exams` | C0 | 14 | ✓ | ✓ | ✓ | 5 | الامتحانات |
| 8 | `public.schedule_entries` | C0 | 16 | ✓ | ✓ | ✓ | 4 | الجدول الدراسي |
| 9 | `public.preps` | C0 | 13 | ✓ | — | ✓ | 5 | التحاضير |
| 10 | `public.prep_status` | C0 | 12 | ✓ | — | ✓ | 5 | حالة التحضير |
| 11 | `public.homework` | C0 | 14 | ✓ | — | ✓ | 4 | الواجبات |
| 12 | `public.announcements` | C0 | 12 | ✓ | — | ✓ | 5 | الإعلانات |
| 13 | `public.file_objects` | C0 | 20 | ✓ | — | ✓ | 5 | سجلات المرفقات |
| 14 | `public.cost_items` | C3 | 13 | ✓ | ✓ | ✓ | 4 | بنود التكاليف |
| 15 | `public.cost_assignments` | C3 | 14 | ✓ | ✓ | ✓ | 5 | إسناد البنود للطلاب |
| 16 | `public.payments` | C3 | 15 | ✓ | ✓ | ✓ | 5 | سجل الدفعات |
| 17 | `public.notifications` | C0 | 9 | ✓ | — | — | 1 | الإشعارات |
| 18 | `public.notification_reads` | SELF | 4 | ✓ | — | — | 1 | حالة قراءة الإشعار |
| 19 | `public.push_subscriptions` | SELF | 11 | — | — | ✓ | 1 | اشتراكات Push |
| 20 | `public.support_sessions` | C4 | 7 | — | — | — | 4 | جلسات وضع الدعم |
| 21 | `public.audit_log` | C4 | 16 | ✓ | — | — | 2 | سجل التدقيق |
| 22 | `public.app_meta` | SYS | 4 | — | — | — | 0 | إصدار المخطط |
| 23 | `public.class_settings` | C0 | 8 | ✓ | ✓ | — | 3 | إعدادات الشعبة |
| 24 | `public.system_settings` | C4 | 13 | — | — | — | 1 | إعدادات النظام |
| 25 | `private.audit_event_types` | SYS | 3 | — | — | — | 0 | كتالوج أحداث التدقيق |
| 26 | `private.activation_codes` | C4 | 12 | ✓ | — | ✓ | 2 | رموز التفعيل (بصمات HMAC) |
| 27 | `private.activation_attempts` | SYS | 5 | — | — | — | 0 | محاولات التفعيل وحدود المعدل |
| 28 | `private.record_revisions` | C2 | 12 | ✓ | ✓ | — | 3 | مخزن سجل التعديلات (خلف record_history) |
<!-- GEN:TABLES:END -->

العروض: `public.cost_stats` (`security_invoker`، إجماليات التكاليف دون تسريب صفوف الزملاء) و`public.record_history` (`security_barrier`، بوابة المراجعات للممثل/المطوّر — انظر E-013).

مخطط العلاقات (مولَّد): `DATA-MODEL-ER.mmd` و`DATA-MODEL-ER.svg`.

![ER](DATA-MODEL-ER.svg)

## 3) المطابقة مع V1 (التخزين المحلي)
| V1 | V2 | ملاحظة ترحيل |
|---|---|---|
| طالب `{id, name, phone}` | `students` (+`members` للحساب) | معرّف V1 النصي لا يُحمل؛ يُنشأ UUID ويُحفظ جدول مطابقة في أداة الترحيل (09.01) |
| حضور `{studentId, date, status}` | `attendance_sheets` + `attendance_records` | اليوم صار كشفاً؛ الحالة «معذور» و«استثنائي» جديدتان (R-043) |
| درجة `{subject, title, date}` | `grades` بـ`term` و`period_month` | عنوان الدرجة وتاريخها أُلغيا بقرار المواصفة (R-048)؛ يُجمع الترحيل على (طالب، مادة، فئة، شهر) |
| تحضير/واجب/امتحان/جدول | `preps`، `homework`، `exams`، `schedule_entries` | المادة نص حر + `subject_key` موحَّد (E-015)؛ الواجب يرث مادة التحضير |
| دفعة `{studentId, amount}` | `cost_items` + `cost_assignments` + `payments` | الدفعة القديمة تُسند إلى بند «رصيد مرحَّل» واحد لكل طالب |
| `foldText` | `private.fold_ar` | تطابق مُختبَر (DB-18) مع فارق مقصود واحد: القص يُجرى بعد حذف التطويل فلا فراغ لاحق |

## 4) قواعد السلامة وآلية فرضها
| القاعدة | المتطلب | الآلية | الاختبار |
|---|---|---|---|
| مطوّر واحد؛ دور رابع مستحيل | R-003، R-012 | فهرس فريد جزئي + `CHECK(role)` | DB-20…22 |
| عضوية حية واحدة لكل مستخدم Auth ولكل طالب | T-77 | فهارس فريدة جزئية | DB-25، 26 |
| الدور والشعبة وربط المستخدم ثابتة | ADR-306 | `members_guard` | DB-30…33 |
| تغيير الحالة يرفع `session_epoch` ويختم الأرشفة | ADR-307 | `members_guard` | DB-34، 35 |
| الطالب ≠ مفتاحه الهاتف | R-037 | `id` UUID فقط | DB-36…38 |
| رمز تفعيل: بصمة فقط، نشط واحد، نهائي الاستهلاك/الإبطال | R-020…R-023 | `code_guard` + فهرس فريد جزئي | DB-49…64 |
| كشف واحد لكل (شعبة، يوم) وسجل لكل (كشف، طالب) | R-042 | فهرسان فريدان | DB-65…67 |
| لا اعتماد لكشف ناقص ولا رجوع إلى مسودة | R-044 | `sheet_guard` | DB-72…75 |
| تعديل الحضور/الدرجة يترك أثراً بالقديم والجديد والفاعل | R-045 | `record_revision` (تحديث/أرشفة/استعادة فقط، E-014) | DB-77…80، 95 |
| درجة حية واحدة لكل (طالب، مادة موحَّدة، فئة، شهر) | R-048 | فهرس فريد جزئي على `subject_key` | DB-92، 93 |
| تحضير بحالة واحدة؛ التأجيل بتاريخ لاحق | R-058 | `prep_status` + `prep_status_guard` | DB-105…110 |
| الواجب المرتبط لا يكرّر مادته/يومه | R-062 | قيد `homework_inherit_chk` | DB-111…116 |
| مرفق: نوع/حجم/مسار بادئته `class_id`، ثابت، أصل واحد | R-055، ADR-312 | قيود + `file_guard` | DB-120…131 |
| سقف التخزين الناعم 70/90/95% | ADR-312 | `file_guard` + `storage_usage()` | DB-132…134 |
| مجموع المدفوع محفوظ ومحمي من ضياع التحديث | R-064، R-065 | `payment_totals` بقفل الصف + `pg_trigger_depth()` | DB-137…153، 237…239 |
| الدفعة للإلحاق فقط؛ الإبطال بسبب ونهائي؛ لا تجاوز للمستحق | E-009، E-016 | `payment_guard` + `paid_le_due_chk` | DB-138…148 |
| إشعار واحد لكل حدث، بلا بيانات شخصية، لا تكرار خلال 10 دقائق | R-069 | `notify_content` + `dedupe_key` | DB-154…163 |
| جلسة دعم مفتوحة واحدة، ≤ 8 ساعات، تأكيد الكتابة خادمياً | ADR-308، AM-20 | فهرس فريد + `support_guard` + `require_support_confirm` | DB-169…184 |
| التدقيق ذري، من كتالوج مغلق، بمعرّفات فقط، للإلحاق فقط | R-034، T-74 | `private.audit` + FK + قيود المفاتيح/الحجم | DB-184…197 |
| لا وصول مباشر للأدوار الخارجية | L-01…L-05 | RLS + revoke + EXECUTE محدود | DB-198…212 |

## 5) التفاصيل المولَّدة
### 5-1) الأعمدة والقيود
<!-- GEN:COLUMNS:START -->
#### `public.classes` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `name` | text | NOT NULL |  |
| `academic_year` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `classes_pkey` (PK)، `classes_academic_year_check` (CHECK)، `classes_name_check` (CHECK)، `classes_archived_by_fkey` (FK)، `classes_created_by_fkey` (FK)، `classes_updated_by_fkey` (FK)

#### `public.students` — C1

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `full_name` | text | NOT NULL |  |
| `name_key` | text | مولَّد | `private.fold_ar(full_name)` |
| `phone` | text | NOT NULL |  |
| `birth_date` | date |  |  |
| `prior_absences` | integer | NOT NULL | `0` |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `students_pkey` (PK)، `students_birth_date_check` (CHECK)، `students_full_name_check` (CHECK)، `students_phone_check` (CHECK)، `students_prior_absences_check` (CHECK)، `students_archived_by_fkey` (FK)، `students_class_id_fkey` (FK)، `students_created_by_fkey` (FK)، `students_updated_by_fkey` (FK)، `students_id_class_key` (UNIQUE)

#### `public.members` — C4

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `user_id` | uuid |  |  |
| `role` | text | NOT NULL |  |
| `class_id` | uuid |  |  |
| `student_id` | uuid |  |  |
| `display_name` | text |  |  |
| `status` | text | NOT NULL | `'pending'::text` |
| `status_changed_at` | timestamp with time zone | NOT NULL | `now()` |
| `status_changed_by` | uuid |  |  |
| `session_epoch` | integer | NOT NULL | `0` |
| `activated_at` | timestamp with time zone |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `members_pkey` (PK)، `members_active_user_chk` (CHECK)، `members_archived_chk` (CHECK)، `members_dev_status_chk` (CHECK)، `members_display_name_check` (CHECK)، `members_display_name_chk` (CHECK)، `members_role_check` (CHECK)، `members_role_scope_chk` (CHECK)، `members_session_epoch_check` (CHECK)، `members_status_check` (CHECK)، `members_student_link_chk` (CHECK)، `members_archived_by_fkey` (FK)، `members_class_id_fkey` (FK)، `members_created_by_fkey` (FK)، `members_status_changed_by_fkey` (FK)، `members_student_fk` (FK)، `members_updated_by_fkey` (FK)، `members_user_id_fkey` (FK)، `members_id_class_key` (UNIQUE)

#### `public.attendance_sheets` — C2

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `school_date` | date | NOT NULL |  |
| `status` | text | NOT NULL | `'draft'::text` |
| `approved_at` | timestamp with time zone |  |  |
| `approved_by` | uuid |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `attendance_sheets_pkey` (PK)، `attendance_sheets_approval_chk` (CHECK)، `attendance_sheets_status_check` (CHECK)، `attendance_sheets_approved_by_fkey` (FK)، `attendance_sheets_archived_by_fkey` (FK)، `attendance_sheets_class_id_fkey` (FK)، `attendance_sheets_created_by_fkey` (FK)، `attendance_sheets_updated_by_fkey` (FK)، `attendance_sheets_day_key` (UNIQUE)، `attendance_sheets_id_class_key` (UNIQUE)

#### `public.attendance_records` — C2

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `sheet_id` | uuid | NOT NULL |  |
| `student_id` | uuid | NOT NULL |  |
| `status` | text | NOT NULL | `'present'::text` |
| `note` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `attendance_records_pkey` (PK)، `attendance_records_note_check` (CHECK)، `attendance_records_status_check` (CHECK)، `attendance_records_archived_by_fkey` (FK)، `attendance_records_class_id_fkey` (FK)، `attendance_records_created_by_fkey` (FK)، `attendance_records_sheet_fk` (FK)، `attendance_records_student_fk` (FK)، `attendance_records_updated_by_fkey` (FK)، `attendance_records_one_key` (UNIQUE)

#### `public.grades` — C2

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `student_id` | uuid | NOT NULL |  |
| `subject` | text | NOT NULL |  |
| `subject_key` | text | مولَّد | `private.fold_ar(subject)` |
| `term` | text | NOT NULL |  |
| `period_month` | smallint |  |  |
| `score` | numeric(7,2) | NOT NULL |  |
| `max_score` | numeric(7,2) | NOT NULL |  |
| `note` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `grades_pkey` (PK)، `grades_note_check` (CHECK)، `grades_period_chk` (CHECK)، `grades_period_month_check` (CHECK)، `grades_range_chk` (CHECK)، `grades_subject_check` (CHECK)، `grades_term_check` (CHECK)، `grades_archived_by_fkey` (FK)، `grades_class_id_fkey` (FK)، `grades_created_by_fkey` (FK)، `grades_student_fk` (FK)، `grades_updated_by_fkey` (FK)

#### `public.exams` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `subject` | text | NOT NULL |  |
| `subject_key` | text | مولَّد | `private.fold_ar(subject)` |
| `exam_date` | date | NOT NULL |  |
| `start_time` | time without time zone |  |  |
| `notes` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `exams_pkey` (PK)، `exams_notes_check` (CHECK)، `exams_subject_check` (CHECK)، `exams_archived_by_fkey` (FK)، `exams_class_id_fkey` (FK)، `exams_created_by_fkey` (FK)، `exams_updated_by_fkey` (FK)، `exams_id_class_key` (UNIQUE)

#### `public.schedule_entries` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `weekday` | text | NOT NULL |  |
| `period_no` | smallint |  |  |
| `subject` | text | NOT NULL |  |
| `subject_key` | text | مولَّد | `private.fold_ar(subject)` |
| `start_time` | time without time zone |  |  |
| `end_time` | time without time zone |  |  |
| `notes` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `schedule_entries_pkey` (PK)، `schedule_entries_notes_check` (CHECK)، `schedule_entries_period_no_check` (CHECK)، `schedule_entries_subject_check` (CHECK)، `schedule_entries_time_chk` (CHECK)، `schedule_entries_weekday_check` (CHECK)، `schedule_entries_archived_by_fkey` (FK)، `schedule_entries_class_id_fkey` (FK)، `schedule_entries_created_by_fkey` (FK)، `schedule_entries_updated_by_fkey` (FK)

#### `public.preps` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `subject` | text | NOT NULL |  |
| `subject_key` | text | مولَّد | `private.fold_ar(subject)` |
| `school_date` | date | NOT NULL | `private.school_today()` |
| `notes` | text |  |  |
| `pinned_at` | timestamp with time zone |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `preps_pkey` (PK)، `preps_notes_check` (CHECK)، `preps_subject_check` (CHECK)، `preps_archived_by_fkey` (FK)، `preps_class_id_fkey` (FK)، `preps_created_by_fkey` (FK)، `preps_updated_by_fkey` (FK)، `preps_id_class_key` (UNIQUE)

#### `public.prep_status` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `prep_id` | uuid | NOT NULL |  |
| `status` | text | NOT NULL |  |
| `postponed_to_date` | date |  |  |
| `note` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `prep_status_pkey` (PK)، `prep_status_note_check` (CHECK)، `prep_status_postpone_chk` (CHECK)، `prep_status_status_check` (CHECK)، `prep_status_archived_by_fkey` (FK)، `prep_status_class_id_fkey` (FK)، `prep_status_created_by_fkey` (FK)، `prep_status_prep_fk` (FK)، `prep_status_updated_by_fkey` (FK)، `prep_status_one_key` (UNIQUE)

#### `public.homework` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `prep_id` | uuid |  |  |
| `subject` | text |  |  |
| `subject_key` | text |  |  |
| `CASE` | undefined |  |  |
| `    WHEN (subject IS NULL) THEN NULL::text` | undefined |  |  |
| `    ELSE private.fold_ar(subject)` | undefined |  |  |
| `END` | مولَّد |  |  |
| `school_date` | date |  |  |
| `body` | text | NOT NULL |  |
| `notes` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `homework_pkey` (PK)، `homework_body_check` (CHECK)، `homework_inherit_chk` (CHECK)، `homework_notes_check` (CHECK)، `homework_subject_check` (CHECK)، `homework_archived_by_fkey` (FK)، `homework_class_id_fkey` (FK)، `homework_created_by_fkey` (FK)، `homework_prep_fk` (FK)، `homework_updated_by_fkey` (FK)، `homework_id_class_key` (UNIQUE)

#### `public.announcements` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `title` | text | NOT NULL |  |
| `body` | text | NOT NULL |  |
| `published_at` | timestamp with time zone | NOT NULL | `now()` |
| `pinned_at` | timestamp with time zone |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `announcements_pkey` (PK)، `announcements_body_check` (CHECK)، `announcements_title_check` (CHECK)، `announcements_archived_by_fkey` (FK)، `announcements_class_id_fkey` (FK)، `announcements_created_by_fkey` (FK)، `announcements_updated_by_fkey` (FK)

#### `public.file_objects` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `prep_id` | uuid |  |  |
| `homework_id` | uuid |  |  |
| `exam_id` | uuid |  |  |
| `storage_path` | text | NOT NULL |  |
| `thumb_path` | text |  |  |
| `mime_type` | text | NOT NULL |  |
| `byte_size` | integer | NOT NULL |  |
| `thumb_byte_size` | integer |  |  |
| `width` | smallint |  |  |
| `height` | smallint |  |  |
| `sha256` | bytea | NOT NULL |  |
| `display_order` | smallint | NOT NULL | `0` |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `file_objects_pkey` (PK)، `file_objects_byte_size_check` (CHECK)، `file_objects_display_order_check` (CHECK)، `file_objects_height_check` (CHECK)، `file_objects_mime_type_check` (CHECK)، `file_objects_one_parent_chk` (CHECK)، `file_objects_path_chk` (CHECK)، `file_objects_sha256_check` (CHECK)، `file_objects_size_chk` (CHECK)، `file_objects_thumb_byte_size_check` (CHECK)، `file_objects_thumb_chk` (CHECK)، `file_objects_width_check` (CHECK)، `file_objects_archived_by_fkey` (FK)، `file_objects_class_id_fkey` (FK)، `file_objects_created_by_fkey` (FK)، `file_objects_exam_fk` (FK)، `file_objects_homework_fk` (FK)، `file_objects_prep_fk` (FK)، `file_objects_updated_by_fkey` (FK)، `file_objects_path_key` (UNIQUE)

#### `public.cost_items` — C3

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `title` | text | NOT NULL |  |
| `description` | text |  |  |
| `amount` | bigint | NOT NULL |  |
| `due_date` | date |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `cost_items_pkey` (PK)، `cost_items_amount_check` (CHECK)، `cost_items_description_check` (CHECK)، `cost_items_title_check` (CHECK)، `cost_items_archived_by_fkey` (FK)، `cost_items_class_id_fkey` (FK)، `cost_items_created_by_fkey` (FK)، `cost_items_updated_by_fkey` (FK)، `cost_items_id_class_key` (UNIQUE)

#### `public.cost_assignments` — C3

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `cost_item_id` | uuid | NOT NULL |  |
| `student_id` | uuid | NOT NULL |  |
| `amount_due` | bigint | NOT NULL |  |
| `paid_total` | bigint | NOT NULL | `0` |
| `pay_status` | text |  |  |
| `CASE` | undefined |  |  |
| `    WHEN (paid_total >= amount_due) THEN 'paid'::text` | undefined |  |  |
| `    WHEN (paid_total = 0) THEN 'unpaid'::text` | undefined |  |  |
| `    ELSE 'partial'::text` | undefined |  |  |
| `END` | مولَّد |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `cost_assignments_pkey` (PK)، `cost_assignments_amount_due_check` (CHECK)، `cost_assignments_paid_le_due_chk` (CHECK)، `cost_assignments_paid_total_check` (CHECK)، `cost_assignments_archived_by_fkey` (FK)، `cost_assignments_class_id_fkey` (FK)، `cost_assignments_created_by_fkey` (FK)، `cost_assignments_item_fk` (FK)، `cost_assignments_student_fk` (FK)، `cost_assignments_updated_by_fkey` (FK)، `cost_assignments_one_key` (UNIQUE)، `cost_assignments_triple_key` (UNIQUE)

#### `public.payments` — C3

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `assignment_id` | uuid | NOT NULL |  |
| `student_id` | uuid | NOT NULL |  |
| `amount` | bigint | NOT NULL |  |
| `paid_on` | date | NOT NULL | `private.school_today()` |
| `note` | text |  |  |
| `archived_at` | timestamp with time zone |  |  |
| `archived_by` | uuid |  |  |
| `archive_reason` | text |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `payments_pkey` (PK)، `payments_amount_check` (CHECK)، `payments_archive_reason_check` (CHECK)، `payments_note_check` (CHECK)، `payments_void_reason_chk` (CHECK)، `payments_archived_by_fkey` (FK)، `payments_assignment_fk` (FK)، `payments_class_id_fkey` (FK)، `payments_created_by_fkey` (FK)، `payments_updated_by_fkey` (FK)

#### `public.notifications` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `kind` | text | NOT NULL |  |
| `event` | text | NOT NULL |  |
| `ref_id` | uuid | NOT NULL |  |
| `title` | text | NOT NULL |  |
| `audience` | text | NOT NULL | `'all'::text` |
| `dedupe_key` | text | NOT NULL |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |

القيود: `notifications_pkey` (PK)، `notifications_audience_check` (CHECK)، `notifications_event_check` (CHECK)، `notifications_kind_check` (CHECK)، `notifications_title_check` (CHECK)، `notifications_class_id_fkey` (FK)، `notifications_dedupe_key` (UNIQUE)، `notifications_id_class_key` (UNIQUE)

#### `public.notification_reads` — SELF

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `notification_id` | uuid | NOT NULL |  |
| `member_id` | uuid | NOT NULL |  |
| `class_id` | uuid | NOT NULL |  |
| `read_at` | timestamp with time zone | NOT NULL | `now()` |

القيود: `notification_reads_pkey` (PK)، `notification_reads_member_id_fkey` (FK)، `notification_reads_notification_fk` (FK)

#### `public.push_subscriptions` — SELF

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `member_id` | uuid | NOT NULL |  |
| `endpoint` | text | NOT NULL |  |
| `p256dh` | text | NOT NULL |  |
| `auth_key` | text | NOT NULL |  |
| `user_agent_hint` | text |  |  |
| `failure_count` | integer | NOT NULL | `0` |
| `last_success_at` | timestamp with time zone |  |  |
| `revoked_at` | timestamp with time zone |  |  |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |

القيود: `push_subscriptions_pkey` (PK)، `push_subscriptions_auth_key_check` (CHECK)، `push_subscriptions_endpoint_check` (CHECK)، `push_subscriptions_failure_count_check` (CHECK)، `push_subscriptions_p256dh_check` (CHECK)، `push_subscriptions_user_agent_hint_check` (CHECK)، `push_subscriptions_member_id_fkey` (FK)، `push_subscriptions_endpoint_key` (UNIQUE)

#### `public.support_sessions` — C4

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `developer_member_id` | uuid | NOT NULL |  |
| `target_member_id` | uuid | NOT NULL |  |
| `reason` | text | NOT NULL |  |
| `started_at` | timestamp with time zone | NOT NULL | `now()` |
| `ends_at` | timestamp with time zone | NOT NULL |  |
| `ended_at` | timestamp with time zone |  |  |

القيود: `support_sessions_pkey` (PK)، `support_sessions_not_self_chk` (CHECK)، `support_sessions_reason_check` (CHECK)، `support_sessions_ttl_chk` (CHECK)، `support_sessions_developer_member_id_fkey` (FK)، `support_sessions_target_member_id_fkey` (FK)

#### `public.audit_log` — C4

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `seq` | bigint | NOT NULL |  |
| `at` | timestamp with time zone | NOT NULL | `now()` |
| `actor_member_id` | uuid |  |  |
| `actor_role` | text |  |  |
| `class_id` | uuid |  |  |
| `action` | text | NOT NULL |  |
| `entity` | text |  |  |
| `entity_id` | uuid |  |  |
| `support_target_member_id` | uuid |  |  |
| `outcome` | text | NOT NULL | `'success'::text` |
| `reason_code` | text |  |  |
| `item_count` | integer |  |  |
| `request_id` | uuid |  |  |
| `client_ip_hash` | bytea |  |  |
| `details` | jsonb | NOT NULL | `'{}'::jsonb` |

القيود: `audit_log_pkey` (PK)، `audit_log_actor_role_check` (CHECK)، `audit_log_client_ip_hash_check` (CHECK)، `audit_log_details_keys_chk` (CHECK)، `audit_log_details_size_chk` (CHECK)، `audit_log_entity_check` (CHECK)، `audit_log_item_count_check` (CHECK)، `audit_log_outcome_check` (CHECK)، `audit_log_reason_code_check` (CHECK)، `audit_log_action_fkey` (FK)، `audit_log_actor_member_id_fkey` (FK)، `audit_log_class_id_fkey` (FK)، `audit_log_support_target_member_id_fkey` (FK)، `audit_log_seq_key` (UNIQUE)

#### `public.app_meta` — SYS

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | boolean | NOT NULL | `true` |
| `schema_version` | integer | NOT NULL |  |
| `min_client_version` | text | NOT NULL | `'0.0.0'::text` |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |

القيود: `app_meta_pkey` (PK)، `app_meta_id_check` (CHECK)، `app_meta_min_client_version_check` (CHECK)، `app_meta_schema_version_check` (CHECK)

#### `public.class_settings` — C0

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `class_id` | uuid | NOT NULL |  |
| `grade_rule` | text | NOT NULL | `'mean_percent'::text` |
| `schedule_days` | text[] | NOT NULL | `ARRAY['sun'::text, 'mon'::text, 'tue'::text, 'wed'::text, 'thu'::text]` |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |
| `version` | integer | NOT NULL | `1` |

القيود: `class_settings_pkey` (PK)، `class_settings_days_chk` (CHECK)، `class_settings_grade_rule_check` (CHECK)، `class_settings_class_id_fkey` (FK)، `class_settings_created_by_fkey` (FK)، `class_settings_updated_by_fkey` (FK)

#### `public.system_settings` — C4

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | boolean | NOT NULL | `true` |
| `storage_quota_bytes` | bigint | NOT NULL | `1073741824` |
| `storage_warn_pct` | smallint | NOT NULL | `70` |
| `storage_strong_pct` | smallint | NOT NULL | `90` |
| `storage_reject_pct` | smallint | NOT NULL | `95` |
| `db_quota_bytes` | bigint | NOT NULL | `524288000` |
| `activation_code_ttl_hours` | integer | NOT NULL | `168` |
| `audit_retention_months` | smallint | NOT NULL | `12` |
| `attempts_retention_days` | smallint | NOT NULL | `90` |
| `created_at` | timestamp with time zone | NOT NULL | `now()` |
| `created_by` | uuid |  |  |
| `updated_at` | timestamp with time zone | NOT NULL | `now()` |
| `updated_by` | uuid |  |  |

القيود: `system_settings_pkey` (PK)، `system_settings_activation_code_ttl_hours_check` (CHECK)، `system_settings_attempts_retention_days_check` (CHECK)، `system_settings_audit_retention_months_check` (CHECK)، `system_settings_db_quota_bytes_check` (CHECK)، `system_settings_id_check` (CHECK)، `system_settings_pct_chk` (CHECK)، `system_settings_storage_quota_bytes_check` (CHECK)، `system_settings_created_by_fkey` (FK)، `system_settings_updated_by_fkey` (FK)

#### `private.audit_event_types` — SYS

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `action` | text | NOT NULL |  |
| `category` | text | NOT NULL |  |
| `description` | text | NOT NULL |  |

القيود: `audit_event_types_pkey` (PK)، `audit_event_types_action_check` (CHECK)، `audit_event_types_category_check` (CHECK)

#### `private.activation_codes` — C4

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `class_id` | uuid | NOT NULL |  |
| `member_id` | uuid | NOT NULL |  |
| `code_hash` | bytea | NOT NULL |  |
| `purpose` | text | NOT NULL |  |
| `issued_by` | uuid | NOT NULL |  |
| `issued_at` | timestamp with time zone | NOT NULL | `now()` |
| `expires_at` | timestamp with time zone | NOT NULL |  |
| `consumed_at` | timestamp with time zone |  |  |
| `revoked_at` | timestamp with time zone |  |  |
| `revoked_by` | uuid |  |  |
| `revoke_reason` | text |  |  |

القيود: `activation_codes_pkey` (PK)، `activation_codes_code_hash_check` (CHECK)، `activation_codes_final_chk` (CHECK)، `activation_codes_purpose_check` (CHECK)، `activation_codes_revoke_chk` (CHECK)، `activation_codes_revoke_reason_check` (CHECK)، `activation_codes_ttl_chk` (CHECK)، `activation_codes_class_id_fkey` (FK)، `activation_codes_issued_by_fkey` (FK)، `activation_codes_member_fk` (FK)، `activation_codes_revoked_by_fkey` (FK)، `activation_codes_hash_key` (UNIQUE)

#### `private.activation_attempts` — SYS

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `attempted_at` | timestamp with time zone | NOT NULL | `now()` |
| `outcome` | text | NOT NULL |  |
| `code_id` | uuid |  |  |
| `ip_hash` | bytea |  |  |

القيود: `activation_attempts_pkey` (PK)، `activation_attempts_ip_hash_check` (CHECK)، `activation_attempts_outcome_check` (CHECK)، `activation_attempts_code_id_fkey` (FK)

#### `private.record_revisions` — C2

| العمود | النوع | قيد | افتراضي |
|---|---|---|---|
| `id` | uuid | NOT NULL | `gen_random_uuid()` |
| `seq` | bigint | NOT NULL |  |
| `at` | timestamp with time zone | NOT NULL | `now()` |
| `class_id` | uuid | NOT NULL |  |
| `entity` | text | NOT NULL |  |
| `record_id` | uuid | NOT NULL |  |
| `student_id` | uuid | NOT NULL |  |
| `version` | integer | NOT NULL |  |
| `action` | text | NOT NULL |  |
| `changes` | jsonb | NOT NULL |  |
| `actor_member_id` | uuid |  |  |
| `support_target_member_id` | uuid |  |  |

القيود: `record_revisions_pkey` (PK)، `record_revisions_action_check` (CHECK)، `record_revisions_entity_check` (CHECK)، `record_revisions_actor_member_id_fkey` (FK)، `record_revisions_class_id_fkey` (FK)، `record_revisions_support_target_member_id_fkey` (FK)، `record_revisions_seq_key` (UNIQUE)

<!-- GEN:COLUMNS:END -->

### 5-2) الفهارس
<!-- GEN:INDEXES:START -->
| الجدول | الفهرس | | التعريف |
|---|---|---|---|
| `private.activation_attempts` | `activation_attempts_at_idx` |  | `btree (attempted_at)` |
| `private.activation_attempts` | `activation_attempts_code_idx` |  | `btree (code_id) WHERE (code_id IS NOT NULL)` |
| `private.activation_attempts` | `activation_attempts_ip_idx` |  | `btree (ip_hash, attempted_at)` |
| `private.activation_codes` | `activation_codes_expires_idx` |  | `btree (expires_at)` |
| `private.activation_codes` | `activation_codes_hash_key` | فريد | `btree (code_hash)` |
| `private.activation_codes` | `activation_codes_one_live_per_member` | فريد | `btree (member_id) WHERE ((consumed_at IS NULL) AND (revoked_at IS NULL))` |
| `private.record_revisions` | `record_revisions_record_idx` |  | `btree (class_id, entity, record_id, at)` |
| `private.record_revisions` | `record_revisions_seq_key` | فريد | `btree (seq)` |
| `private.record_revisions` | `record_revisions_student_idx` |  | `btree (student_id)` |
| `public.announcements` | `announcements_class_pub_idx` |  | `btree (class_id, published_at DESC) WHERE (archived_at IS NULL)` |
| `public.attendance_records` | `attendance_records_one_key` | فريد | `btree (sheet_id, student_id)` |
| `public.attendance_records` | `attendance_records_sheet_idx` |  | `btree (sheet_id)` |
| `public.attendance_records` | `attendance_records_student_idx` |  | `btree (student_id, sheet_id)` |
| `public.attendance_sheets` | `attendance_sheets_day_key` | فريد | `btree (class_id, school_date)` |
| `public.attendance_sheets` | `attendance_sheets_id_class_key` | فريد | `btree (id, class_id)` |
| `public.audit_log` | `audit_log_actor_idx` |  | `btree (actor_member_id, at DESC)` |
| `public.audit_log` | `audit_log_at_idx` |  | `btree (at DESC)` |
| `public.audit_log` | `audit_log_entity_idx` |  | `btree (entity, entity_id)` |
| `public.audit_log` | `audit_log_seq_key` | فريد | `btree (seq)` |
| `public.cost_assignments` | `cost_assignments_one_key` | فريد | `btree (cost_item_id, student_id)` |
| `public.cost_assignments` | `cost_assignments_student_idx` |  | `btree (student_id)` |
| `public.cost_assignments` | `cost_assignments_triple_key` | فريد | `btree (id, class_id, student_id)` |
| `public.cost_items` | `cost_items_id_class_key` | فريد | `btree (id, class_id)` |
| `public.exams` | `exams_class_date_idx` |  | `btree (class_id, exam_date) WHERE (archived_at IS NULL)` |
| `public.exams` | `exams_id_class_key` | فريد | `btree (id, class_id)` |
| `public.file_objects` | `file_objects_class_idx` |  | `btree (class_id)` |
| `public.file_objects` | `file_objects_exam_idx` |  | `btree (exam_id) WHERE (exam_id IS NOT NULL)` |
| `public.file_objects` | `file_objects_homework_idx` |  | `btree (homework_id) WHERE (homework_id IS NOT NULL)` |
| `public.file_objects` | `file_objects_path_key` | فريد | `btree (storage_path)` |
| `public.file_objects` | `file_objects_prep_idx` |  | `btree (prep_id) WHERE (prep_id IS NOT NULL)` |
| `public.grades` | `grades_class_student_idx` |  | `btree (class_id, student_id)` |
| `public.grades` | `grades_one_live_idx` | فريد | `btree (student_id, subject_key, term, COALESCE((period_month)::integer, 0)) WHERE (archived_at IS NULL)` |
| `public.homework` | `homework_class_day_idx` |  | `btree (class_id, school_date) WHERE (prep_id IS NULL)` |
| `public.homework` | `homework_id_class_key` | فريد | `btree (id, class_id)` |
| `public.homework` | `homework_one_per_prep_idx` | فريد | `btree (prep_id) WHERE ((prep_id IS NOT NULL) AND (archived_at IS NULL))` |
| `public.members` | `members_class_role_idx` |  | `btree (class_id, role)` |
| `public.members` | `members_id_class_key` | فريد | `btree (id, class_id)` |
| `public.members` | `members_one_developer` | فريد | `btree ((true)) WHERE (role = 'developer'::text)` |
| `public.members` | `members_one_live_per_user` | فريد | `btree (user_id) WHERE ((user_id IS NOT NULL) AND (status = ANY (ARRAY['active'::text, 'suspended'::text])))` |
| `public.members` | `members_one_per_student` | فريد | `btree (student_id) WHERE (student_id IS NOT NULL)` |
| `public.notification_reads` | `notification_reads_notification_idx` |  | `btree (notification_id)` |
| `public.notifications` | `notifications_class_idx` |  | `btree (class_id, created_at DESC)` |
| `public.notifications` | `notifications_dedupe_key` | فريد | `btree (dedupe_key)` |
| `public.notifications` | `notifications_id_class_key` | فريد | `btree (id, class_id)` |
| `public.payments` | `payments_assignment_idx` |  | `btree (assignment_id)` |
| `public.payments` | `payments_student_day_idx` |  | `btree (student_id, paid_on)` |
| `public.prep_status` | `prep_status_one_key` | فريد | `btree (prep_id)` |
| `public.preps` | `preps_class_day_idx` |  | `btree (class_id, school_date DESC, subject_key)` |
| `public.preps` | `preps_id_class_key` | فريد | `btree (id, class_id)` |
| `public.preps` | `preps_pinned_idx` |  | `btree (class_id, pinned_at) WHERE ((pinned_at IS NOT NULL) AND (archived_at IS NULL))` |
| `public.push_subscriptions` | `push_subscriptions_endpoint_key` | فريد | `btree (endpoint)` |
| `public.push_subscriptions` | `push_subscriptions_member_idx` |  | `btree (member_id)` |
| `public.schedule_entries` | `schedule_entries_class_day_idx` |  | `btree (class_id, weekday, period_no) WHERE (archived_at IS NULL)` |
| `public.students` | `students_class_idx` |  | `btree (class_id) WHERE (archived_at IS NULL)` |
| `public.students` | `students_id_class_key` | فريد | `btree (id, class_id)` |
| `public.students` | `students_name_trgm_idx` |  | `gin (name_key extensions.gin_trgm_ops)` |
| `public.students` | `students_phone_trgm_idx` |  | `gin (phone extensions.gin_trgm_ops)` |
| `public.support_sessions` | `support_sessions_one_open_idx` | فريد | `btree (developer_member_id) WHERE (ended_at IS NULL)` |
<!-- GEN:INDEXES:END -->

### 5-3) المشغّلات
أسماء المشغّلات تبدأ بـ`a_`…`d_` لضبط ترتيب التنفيذ (الحراسة ← الختم ← المجاميع ← الأثر والتدقيق).
<!-- GEN:TRIGGERS:START -->
| الجدول | المشغّل | التعريف |
|---|---|---|
| `activation_codes` | `trg_a_fixed` | `BEFORE UPDATE ON private.activation_codes FOR EACH ROW → private.forbid_change('id', 'class_id', 'member_id', 'code_hash', 'purpose', 'issued_by', 'is` |
| `activation_codes` | `trg_c_code_guard` | `BEFORE INSERT OR UPDATE ON private.activation_codes FOR EACH ROW → private.code_guard()` |
| `announcements` | `trg_a_fixed` | `BEFORE UPDATE ON public.announcements FOR EACH ROW → private.forbid_change('id', 'class_id', 'created_at', 'created_by')` |
| `announcements` | `trg_a_no_delete` | `BEFORE DELETE ON public.announcements FOR EACH ROW → private.no_delete()` |
| `announcements` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.announcements FOR EACH STATEMENT → private.no_delete()` |
| `announcements` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.announcements FOR EACH ROW → private.stamp()` |
| `announcements` | `trg_d_notify` | `AFTER INSERT OR UPDATE ON public.announcements FOR EACH ROW → private.notify_content()` |
| `attendance_records` | `trg_a_fixed` | `BEFORE UPDATE ON public.attendance_records FOR EACH ROW → private.forbid_change('id', 'class_id', 'sheet_id', 'student_id', 'created_at', 'created_by'` |
| `attendance_records` | `trg_a_no_delete` | `BEFORE DELETE ON public.attendance_records FOR EACH ROW → private.no_delete()` |
| `attendance_records` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.attendance_records FOR EACH STATEMENT → private.no_delete()` |
| `attendance_records` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.attendance_records FOR EACH ROW → private.stamp()` |
| `attendance_records` | `trg_d_revision` | `AFTER UPDATE ON public.attendance_records FOR EACH ROW → private.record_revision()` |
| `attendance_sheets` | `trg_a_fixed` | `BEFORE UPDATE ON public.attendance_sheets FOR EACH ROW → private.forbid_change('id', 'class_id', 'school_date', 'created_at', 'created_by')` |
| `attendance_sheets` | `trg_a_no_delete` | `BEFORE DELETE ON public.attendance_sheets FOR EACH ROW → private.no_delete()` |
| `attendance_sheets` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.attendance_sheets FOR EACH STATEMENT → private.no_delete()` |
| `attendance_sheets` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.attendance_sheets FOR EACH ROW → private.stamp()` |
| `attendance_sheets` | `trg_c_sheet_guard` | `BEFORE UPDATE ON public.attendance_sheets FOR EACH ROW → private.sheet_guard()` |
| `audit_log` | `trg_audit_append_only` | `BEFORE DELETE OR UPDATE ON public.audit_log FOR EACH ROW → private.append_only()` |
| `audit_log` | `trg_audit_no_truncate` | `BEFORE TRUNCATE ON public.audit_log FOR EACH STATEMENT → private.append_only()` |
| `class_settings` | `trg_a_no_delete` | `BEFORE DELETE ON public.class_settings FOR EACH ROW → private.no_delete()` |
| `class_settings` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.class_settings FOR EACH STATEMENT → private.no_delete()` |
| `class_settings` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.class_settings FOR EACH ROW → private.stamp()` |
| `classes` | `trg_a_fixed` | `BEFORE UPDATE ON public.classes FOR EACH ROW → private.forbid_change('id', 'created_at', 'created_by')` |
| `classes` | `trg_a_no_delete` | `BEFORE DELETE ON public.classes FOR EACH ROW → private.no_delete()` |
| `classes` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.classes FOR EACH STATEMENT → private.no_delete()` |
| `classes` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.classes FOR EACH ROW → private.stamp()` |
| `classes` | `trg_d_seed_class` | `AFTER INSERT ON public.classes FOR EACH ROW → private.seed_class()` |
| `cost_assignments` | `trg_a_fixed` | `BEFORE UPDATE ON public.cost_assignments FOR EACH ROW → private.forbid_change('id', 'class_id', 'cost_item_id', 'student_id', 'created_at', 'created_b` |
| `cost_assignments` | `trg_a_no_delete` | `BEFORE DELETE ON public.cost_assignments FOR EACH ROW → private.no_delete()` |
| `cost_assignments` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.cost_assignments FOR EACH STATEMENT → private.no_delete()` |
| `cost_assignments` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.cost_assignments FOR EACH ROW → private.stamp()` |
| `cost_assignments` | `trg_c_assignment_guard` | `BEFORE INSERT OR UPDATE ON public.cost_assignments FOR EACH ROW → private.assignment_guard()` |
| `cost_items` | `trg_a_fixed` | `BEFORE UPDATE ON public.cost_items FOR EACH ROW → private.forbid_change('id', 'class_id', 'created_at', 'created_by')` |
| `cost_items` | `trg_a_no_delete` | `BEFORE DELETE ON public.cost_items FOR EACH ROW → private.no_delete()` |
| `cost_items` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.cost_items FOR EACH STATEMENT → private.no_delete()` |
| `cost_items` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.cost_items FOR EACH ROW → private.stamp()` |
| `exams` | `trg_a_fixed` | `BEFORE UPDATE ON public.exams FOR EACH ROW → private.forbid_change('id', 'class_id', 'created_at', 'created_by')` |
| `exams` | `trg_a_no_delete` | `BEFORE DELETE ON public.exams FOR EACH ROW → private.no_delete()` |
| `exams` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.exams FOR EACH STATEMENT → private.no_delete()` |
| `exams` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.exams FOR EACH ROW → private.stamp()` |
| `exams` | `trg_d_notify` | `AFTER INSERT OR UPDATE ON public.exams FOR EACH ROW → private.notify_content()` |
| `file_objects` | `trg_a_fixed` | `BEFORE UPDATE ON public.file_objects FOR EACH ROW → private.forbid_change('id', 'class_id', 'prep_id', 'homework_id', 'exam_id', 'storage_path', 'thum` |
| `file_objects` | `trg_a_no_delete` | `BEFORE DELETE ON public.file_objects FOR EACH ROW → private.no_delete()` |
| `file_objects` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.file_objects FOR EACH STATEMENT → private.no_delete()` |
| `file_objects` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.file_objects FOR EACH ROW → private.stamp()` |
| `file_objects` | `trg_c_file_guard` | `BEFORE INSERT ON public.file_objects FOR EACH ROW → private.file_guard()` |
| `grades` | `trg_a_fixed` | `BEFORE UPDATE ON public.grades FOR EACH ROW → private.forbid_change('id', 'class_id', 'student_id', 'created_at', 'created_by')` |
| `grades` | `trg_a_no_delete` | `BEFORE DELETE ON public.grades FOR EACH ROW → private.no_delete()` |
| `grades` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.grades FOR EACH STATEMENT → private.no_delete()` |
| `grades` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.grades FOR EACH ROW → private.stamp()` |
| `grades` | `trg_d_revision` | `AFTER UPDATE ON public.grades FOR EACH ROW → private.record_revision()` |
| `homework` | `trg_a_fixed` | `BEFORE UPDATE ON public.homework FOR EACH ROW → private.forbid_change('id', 'class_id', 'prep_id', 'created_at', 'created_by')` |
| `homework` | `trg_a_no_delete` | `BEFORE DELETE ON public.homework FOR EACH ROW → private.no_delete()` |
| `homework` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.homework FOR EACH STATEMENT → private.no_delete()` |
| `homework` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.homework FOR EACH ROW → private.stamp()` |
| `members` | `trg_a_fixed` | `BEFORE UPDATE ON public.members FOR EACH ROW → private.forbid_change('id', 'role', 'class_id', 'student_id', 'created_at', 'created_by')` |
| `members` | `trg_a_no_delete` | `BEFORE DELETE ON public.members FOR EACH ROW → private.no_delete()` |
| `members` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.members FOR EACH STATEMENT → private.no_delete()` |
| `members` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.members FOR EACH ROW → private.stamp()` |
| `members` | `trg_c_members_guard` | `BEFORE INSERT OR UPDATE ON public.members FOR EACH ROW → private.members_guard()` |
| `notification_reads` | `trg_a_fixed` | `BEFORE UPDATE ON public.notification_reads FOR EACH ROW → private.forbid_change('notification_id', 'member_id', 'class_id')` |
| `notifications` | `trg_a_append_only` | `BEFORE UPDATE ON public.notifications FOR EACH ROW → private.append_only()` |
| `payments` | `trg_a_no_delete` | `BEFORE DELETE ON public.payments FOR EACH ROW → private.no_delete()` |
| `payments` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.payments FOR EACH STATEMENT → private.no_delete()` |
| `payments` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.payments FOR EACH ROW → private.stamp()` |
| `payments` | `trg_c_payment_guard` | `BEFORE INSERT OR UPDATE ON public.payments FOR EACH ROW → private.payment_guard()` |
| `payments` | `trg_d_payment_totals` | `AFTER INSERT OR UPDATE OF archived_at ON public.payments FOR EACH ROW → private.payment_totals()` |
| `prep_status` | `trg_a_fixed` | `BEFORE UPDATE ON public.prep_status FOR EACH ROW → private.forbid_change('id', 'class_id', 'prep_id', 'created_at', 'created_by')` |
| `prep_status` | `trg_a_no_delete` | `BEFORE DELETE ON public.prep_status FOR EACH ROW → private.no_delete()` |
| `prep_status` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.prep_status FOR EACH STATEMENT → private.no_delete()` |
| `prep_status` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.prep_status FOR EACH ROW → private.stamp()` |
| `prep_status` | `trg_c_prep_status_guard` | `BEFORE INSERT OR UPDATE ON public.prep_status FOR EACH ROW → private.prep_status_guard()` |
| `preps` | `trg_a_fixed` | `BEFORE UPDATE ON public.preps FOR EACH ROW → private.forbid_change('id', 'class_id', 'created_at', 'created_by')` |
| `preps` | `trg_a_no_delete` | `BEFORE DELETE ON public.preps FOR EACH ROW → private.no_delete()` |
| `preps` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.preps FOR EACH STATEMENT → private.no_delete()` |
| `preps` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.preps FOR EACH ROW → private.stamp()` |
| `preps` | `trg_d_notify` | `AFTER INSERT OR UPDATE ON public.preps FOR EACH ROW → private.notify_content()` |
| `push_subscriptions` | `trg_a_fixed` | `BEFORE UPDATE ON public.push_subscriptions FOR EACH ROW → private.forbid_change('id', 'member_id', 'endpoint', 'created_at')` |
| `record_revisions` | `trg_a_append_only` | `BEFORE UPDATE ON private.record_revisions FOR EACH ROW → private.append_only()` |
| `record_revisions` | `trg_a_no_delete` | `BEFORE DELETE ON private.record_revisions FOR EACH ROW → private.no_delete()` |
| `record_revisions` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON private.record_revisions FOR EACH STATEMENT → private.no_delete()` |
| `schedule_entries` | `trg_a_fixed` | `BEFORE UPDATE ON public.schedule_entries FOR EACH ROW → private.forbid_change('id', 'class_id', 'created_at', 'created_by')` |
| `schedule_entries` | `trg_a_no_delete` | `BEFORE DELETE ON public.schedule_entries FOR EACH ROW → private.no_delete()` |
| `schedule_entries` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.schedule_entries FOR EACH STATEMENT → private.no_delete()` |
| `schedule_entries` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.schedule_entries FOR EACH ROW → private.stamp()` |
| `students` | `trg_a_fixed` | `BEFORE UPDATE ON public.students FOR EACH ROW → private.forbid_change('id', 'class_id', 'created_at', 'created_by')` |
| `students` | `trg_a_no_delete` | `BEFORE DELETE ON public.students FOR EACH ROW → private.no_delete()` |
| `students` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.students FOR EACH STATEMENT → private.no_delete()` |
| `students` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.students FOR EACH ROW → private.stamp()` |
| `support_sessions` | `trg_a_fixed` | `BEFORE UPDATE ON public.support_sessions FOR EACH ROW → private.forbid_change('id', 'developer_member_id', 'target_member_id', 'reason', 'started_at',` |
| `support_sessions` | `trg_a_no_delete` | `BEFORE DELETE ON public.support_sessions FOR EACH ROW → private.no_delete()` |
| `support_sessions` | `trg_a_no_truncate` | `BEFORE TRUNCATE ON public.support_sessions FOR EACH STATEMENT → private.no_delete()` |
| `support_sessions` | `trg_c_support_guard` | `BEFORE INSERT OR UPDATE ON public.support_sessions FOR EACH ROW → private.support_guard()` |
| `system_settings` | `trg_b_stamp` | `BEFORE INSERT OR UPDATE ON public.system_settings FOR EACH ROW → private.stamp()` |
<!-- GEN:TRIGGERS:END -->

### 5-4) الدوال
<!-- GEN:FUNCTIONS:START -->
| الدالة | الامتياز | الثبات | EXECUTE | ملاحظة |
|---|---|---|---|---|
| `private.actor_member_id()` | DEFINER | stable | authenticated |  |
| `private.append_only()` | INVOKER | volatile | — |  |
| `private.assignment_guard()` | DEFINER | volatile | — |  |
| `private.audit(p_action text, p_entity text, p_entity_id uuid, p_class_id uuid, p_outcome text, p_reason text, p_count integer, p_details jsonb, p_request_id uuid, p_ip_hash bytea)` | DEFINER | volatile | — |  |
| `private.code_guard()` | DEFINER | volatile | — |  |
| `private.file_guard()` | DEFINER | volatile | — |  |
| `private.fold_ar(t text)` | INVOKER | immutable | authenticated |  |
| `private.forbid_change()` | INVOKER | volatile | — |  |
| `private.me()` | DEFINER | stable | authenticated |  |
| `private.members_guard()` | DEFINER | volatile | — |  |
| `private.no_delete()` | INVOKER | volatile | — |  |
| `private.notify_content()` | DEFINER | volatile | — |  |
| `private.payment_guard()` | DEFINER | volatile | — |  |
| `private.payment_totals()` | DEFINER | volatile | — |  |
| `private.prep_status_guard()` | DEFINER | volatile | — |  |
| `private.purge_audit(p_exported_through timestamp with time zone)` | DEFINER | volatile | — |  |
| `private.purge_expired()` | DEFINER | volatile | — |  |
| `private.record_revision()` | DEFINER | volatile | — |  |
| `private.require_support_confirm(p_confirm boolean)` | DEFINER | stable | — |  |
| `private.school_today()` | INVOKER | stable | authenticated |  |
| `private.seed_class()` | DEFINER | volatile | — |  |
| `private.sheet_guard()` | DEFINER | volatile | — |  |
| `private.stamp()` | DEFINER | volatile | — |  |
| `private.storage_usage(p_class_id uuid)` | DEFINER | stable | — |  |
| `private.support_guard()` | DEFINER | volatile | — |  |
| `private.support_target()` | DEFINER | stable | — |  |
| `private.verify_cost_totals()` | DEFINER | stable | — |  |
<!-- GEN:FUNCTIONS:END -->

### 5-5) المنح والرفض الافتراضي
<!-- GEN:GRANTS:START -->
| الفحص | القيمة |
|---|---|
| جداول بـRLS مفعّل | 28 من 28 |
| سياسات RLS معرّفة | 0 (تُكتب في 03.03) |
| جداول/عروض يملك `anon` عليها أي صلاحية DML | 0 |
| جداول/عروض يملك `authenticated` عليها أي صلاحية DML | 0 |
| دوال `authenticated` يستدعيها | actor_member_id، fold_ar، me، school_today |
<!-- GEN:GRANTS:END -->

### 5-6) كتالوج أحداث التدقيق
<!-- GEN:EVENTS:START -->
| الحدث | الفئة | الوصف |
|---|---|---|
| `access.denied` | access | رفض وصول ملاحَظ |
| `code.consumed` | code | استهلاك رمز ناجح |
| `code.failed` | code | محاولة تفعيل فاشلة (السبب الداخلي في reason_code فقط) |
| `code.issued` | code | إصدار رمز تفعيل/إعادة تفعيل |
| `code.revoked` | code | إبطال رمز |
| `attendance.approved` | data | اعتماد كشف حضور |
| `attendance.archived` | data | أرشفة كشف حضور |
| `attendance.corrected` | data | تعديل سجل/كشف حضور سابق |
| `cost.archived` | data | أرشفة بند/إسناد |
| `cost.changed` | data | تعديل بند أو مبلغ مستحق |
| `cost.created` | data | إنشاء بند تكلفة وإسناده |
| `file.rejected` | data | رفض مرفق (حصة/نوع/حجم) |
| `file.uploaded` | data | تسجيل مرفق |
| `grade.archived` | data | أرشفة درجة |
| `grade.changed` | data | إضافة/تعديل درجة |
| `payment.recorded` | data | تسجيل دفعة |
| `payment.voided` | data | إبطال دفعة |
| `student.archived` | data | أرشفة طالب |
| `student.created` | data | إضافة طالب |
| `student.imported` | data | استيراد قائمة طلاب |
| `student.restored` | data | استعادة طالب |
| `student.updated` | data | تعديل ملف طالب |
| `export.backup` | export | تصدير نسخة كاملة |
| `export.roster` | export | تصدير قائمة الطلاب |
| `restore.executed` | export | استعادة نسخة |
| `member.archived` | member | أرشفة عضوية (مغادرة) |
| `member.created` | member | إنشاء عضوية (ممثل/طالب) |
| `member.reactivated` | member | إعادة تفعيل عضوية |
| `member.suspended` | member | تعليق عضوية |
| `support.closed` | support | إغلاق جلسة دعم |
| `support.opened` | support | فتح جلسة دعم |
| `support.write` | support | كتابة أثناء جلسة دعم |
| `audit.purged` | system | تدوير سجل التدقيق بعد تصدير موثق |
| `class.updated` | system | تعديل بيانات الشعبة |
| `settings.changed` | system | تغيير إعدادات الشعبة/النظام |
<!-- GEN:EVENTS:END -->

## 6) القرارات المسجَّلة في هذا البرومبت
| المعرّف | القرار | السبب |
|---|---|---|
| E-013 | `record_history` عرض بوابة (`security_barrier`) فوق `private.record_revisions`؛ الممثل يقرؤه بدل `audit_log` | مصفوفة 01.01 تعرّف الكيان عرضاً؛ الجدول الخلفي خاص فلا تسريب مباشر (DB-217، 218) |
| E-014 | المراجعات تُسجَّل عند **التعديل/الأرشفة/الاستعادة** فقط لا عند الإنشاء | الإنشاء مسجّل في الصف نفسه؛ يخفض الحجم إلى النصف تقريباً |
| E-015 | المادة نص حر + `subject_key` موحَّد (يطابق `foldText`) لا جدول مواد | مواد المدرسة غير محصورة (R-054)؛ التوحيد يمنع «إنجليزي/انجليزي» |
| E-016 | دفعة تتجاوز المتبقي تُرفض | بديل الرصيد الدائن غير مطلوب في المواصفة؛ الزيادة غالباً خطأ إدخال |
| E-017 | رمز تفعيل حي واحد لكل عضوية؛ إعادة الإصدار = إبطال ثم إصدار والسجل نفسه (R-022) | يمنع تسرّب رموز قديمة صالحة |
| E-018 | قاعدة «الاسم الثلاثي» تُفرض في RPC/الواجهة لا في CHECK | تفادي رفض أسماء مشروعة في الاستعادة والترحيل؛ القاع يفرض الطول والتنظيف فقط |

## 7) الترحيل (ADR-319)
توسيع ← ترحيل ← انكماش. كل تغيير لاحق ملف migration مرقَّم؛ `app_meta.schema_version` = 1 الآن. إضافة حدث تدقيق = migration يضيف صفاً للكتالوج.

## 8) الاحتفاظ والتنظيف (`private.purge_expired`, `private.purge_audit`)
| الصنف | المدة | القاعدة |
|---|---|---|
| محاولات التفعيل | 90 يوماً | تُحذف بعدها |
| رموز التفعيل | 90 يوماً بعد الإبطال/الاستهلاك/الانتهاء (نفس مدة المحاولات) | لا تُحذف ما دامت لها محاولات |
| الإشعارات | 12 شهراً | تُحذف بعدها |
| اشتراكات Push الملغاة | 30 يوماً | تُحذف بعدها |
| سجل التدقيق | 12 شهراً | **لا يُحذف بلا تصدير موثق**، ويُدوَّن حدث `audit.purged` |

الجداول الأكاديمية والمالية **لا تُحذف تلقائياً أبداً**.

## 9) الحجم والأداء (قياس فعلي)
قاعدة اصطناعية لسنة دراسية كاملة (100 طالب، 170 يوماً، 17,000 سجل حضور، 8,000 درجة، نحو 1,900 دفعة، 1,020 تحضيراً، 680 مرفقاً وصفياً، 2,800 حدث تدقيق): **حجم الجداول ≈ 14 MB** من أصل 500 MB في الخطة المجانية، أي نحو 3% في السنة، فتتسع عشرات السنين من البيانات الجدولية؛ **القيد الفعلي هو تخزين الملفات** (≈ 182 MB للمرفقات الاصطناعية على سقف 1 GB) وهو تحت سقف ADR-312 الناعم. زمن تحميل السنة كاملة بالمشغّلات الفعلية ≈ 2 ثانية. الأرقام تخصّ هذه البيانات الاصطناعية وهذا الجهاز ولا تعد بأداء الإنتاج.

## 10) مخاطر وردود (تفاصيل التهديدات T-79…T-84 في `THREAT-MODEL-V2.md` §4-ج)
- مجاميع الدفعات المخزّنة قد تنحرف إن عُطّلت المشغّلات: `private.verify_cost_totals()` يكشفها (DB-153)؛ يوصى بتشغيله ضمن نسخ الاحتياط.
- `record_history` قد يُعاد تعريفه أو يُمنح خطأً: اختبار DB-217…219 يمنع التسرب.
- ترتيب المشغّلات حساس: لا تغيّر البادئات `a_…d_` دون إعادة تشغيل `schema-v2.test.js`.

## 11) خارج النطاق (لم يُنفَّذ هنا)
سياسات RLS الفعلية (03.03)، RPC/Edge (04.x)، الربط بـSupabase Auth/Storage/Realtime (03.01–03.02)، ترحيل V1 (09.01)، شاشات إدارة الشعب.

## 12) ما اختُبر وما لم يُختبر
**اختُبر فعلاً (241 فحصاً على PostgreSQL محلي 16، `tests/db/schema-v2.test.js`):** اتساق المخطط مع المصفوفة (DB-01…15)، دالتا التوحيد واليوم (16…19)، الهوية والطلاب (20…48)، الرموز (49…64)، الحضور (65…83)، الدرجات (84…96)، الجدول والامتحانات والتحاضير والواجبات والمرفقات (97…134)، التكاليف والدفعات (135…153)، الإشعارات (154…168)، الدعم والتدقيق (169…197)، الرفض الافتراضي والمنح (198…212)، فحوص دخان بسياسات اختبارية مؤقتة (213…223، ليست سياسات 03.03)، الاحتفاظ (224، 225)، الإعدادات وتعدد الشعب (226…236)، التزامن بجلستين حقيقيتين (237…239)، الحمل الاصطناعي (240…242).
**لم يُختبر:** سلوك Supabase الحقيقي (Auth، PostgREST، Storage، Realtime، Edge، أدوار الإنتاج) — المحاكاة `stubs-supabase.sql` تحاكي الأدوار و`auth.uid()` والمنح الافتراضية فقط؛ سياسات RLS النهائية؛ أداء الاستعلامات تحت حمل متزامن حقيقي؛ الترحيل من V1؛ عنقود Docker/Supabase محلي (غير متاح هنا).
