# سجل أدلة الاختبار — التنفيذ V2

> **ملاحظة (2026-11-08):** ما يرد هنا عن 12 أو 16 صورة أو الوضع الفاتح **مستبدل**؛ القاعدة الحالية: داكن فقط، عدد غير ثابت (`REFERENCE_IMAGES_RULE.md` بنود 10–14).

لم يبدأ تنفيذ البرومبتات بعد. خط الأساس التاريخي ونتائج الفحص الأولي في `BASELINE.md` و`legacy/تقرير-الفحص-الأولي-2026-11-05.md`. أي نتيجة جديدة يجب أن تتضمن الأمر والبيئة والتاريخ والنتيجة، مع فصل الاختبار الفعلي عن المحاكاة وغير المتاح.

## 00.01 — 2026-11-07 (Linux Ubuntu 24، Node v22.23.4، Chromium headless Playwright، بلا شبكة)
| الأمر | النتيجة |
|---|---|
| `node <file>` لكل `tests/**/*.test.js` (26 ملفاً) | 898 نجاح، 0 فشل، كل رموز الخروج 0 (عدّ PASS وحده = 832؛ ملفان يطبعان ملخصاً فقط) |
| `NODE_PATH=$(npm root -g) node <file>` لكل `tests/**/*.playwright.js` (23 ملفاً) | 1568 نجاح، 0 فشل، كل رموز الخروج 0 |
| `sha256sum -c docs/architecture/code-baseline.sha256` | 14/14 OK |
| `diff -rq` للشجرة قبل/بعد التشغيل | لا فروق |
| فحص أسرار نمطي (خارج tests) | لا نتائج |
| `node docs/execution-v2/tools/capture-reference.js 00.01` | 12 صورة في `الصور المرجعية/00.01/`؛ فُحصت لقطتان بصرياً |
| لم يُختبر | خادم/Supabase/Docker، هواتف، Safari/Firefox، PWA/APK/Push، قارئ شاشة، واتساب، الطفرات |
التفاصيل في `BASELINE-RECHECK.md`.

## 00.02 — 2026-11-07 (Ubuntu 24، Node v22.23.4، Chromium headless، بلا شبكة) — وثائق فقط
| الأمر | النتيجة |
|---|---|
| `node <file>` لكل `tests/**/*.test.js` (26 ملفاً) بعد تعليم الوثائق | 898 نجاح، 0 فشل |
| `NODE_PATH=$(npm root -g) node <file>` لكل `tests/**/*.playwright.js` (23 ملفاً) على نسخة بكود مطابق | 1568 نجاح، 0 فشل (Chromium فقط) |
| `sha256sum -c docs/architecture/code-baseline.sha256` | 14/14 OK |
| `diff -rq` للكود والاختبارات والـJSON الأمني والمخططات و`legacy/` و`archive/` | لا فروق |
| فحص أسرار | لا نتائج |
| `capture-reference.js 00.02 --docs docs/execution-v2/LEGACY-RECONCILIATION.md` | 16 صورة في `الصور المرجعية/00.02/` (12 قياسية + 4 لوثيقة التوحيد)؛ كل منها أكبر من صفر؛ لم تُقرأ بصرياً |
| لم يُختبر | خادم/Supabase، هواتف، Safari/Firefox، PWA/APK/Push |

## 00.03 — 2026-11-07 (Ubuntu 24، Node v22.23.4، Chromium headless، بلا شبكة) — وثائق وأداة فحص فقط
| الأمر | النتيجة |
|---|---|
| `node docs/execution-v2/tools/check-traceability.js` | 21 نجاح، 0 فشل (100 مطلب، 38 قراراً U2، §1…§14، 10 ملفات اختبار قائمة مذكورة موجودة) |
| `node <file>` لكل `tests/**/*.test.js` (26 ملفاً) | 898 نجاح، 0 فشل |
| Playwright: e2e-v1 / e2e-v1-ui / e2e-v1-boundaries / e2e-student-no-leak | 81 / 136 / 11 / 24 — 0 فشل (الكامل 23 ملفاً 1568/0 نُفّذ في 00.02، والكود لم يتغير) |
| `sha256sum -c docs/architecture/code-baseline.sha256` | 14/14 OK |
| `diff -rq` للكود والاختبارات و`archive/` و`legacy/` | لا فروق |
| `capture-reference.js 00.03 --docs docs/execution-v2/REQUIREMENTS-TRACEABILITY.md` | 16 صورة في `الصور المرجعية/00.03/`، كل منها > 0 بايت؛ لم تُقرأ بصرياً |
| لم يُختبر | أي مطلب V2 (لا تنفيذ بعد)، خادم/Supabase، هواتف |

## 00.04 — 2026-11-07 (Ubuntu 24، Node v22.23.4، Chromium headless) — وثائق وأداة فحص فقط
| الأمر | النتيجة |
|---|---|
| `node docs/execution-v2/tools/check-architecture.js` | 42 نجاح، 0 فشل (ADR-301…321، حكم ADR-201…217، T-01…T-66، البوابات، ربط 43 برومبتاً، تغطية R-001…R-100، فحص أسرار، بصمات 14/14، 18 طفرة تُكتشف) |
| `node docs/execution-v2/tools/check-traceability.js` | 21 نجاح، 0 فشل (بعد تحديث حالة R-007/R-088/R-089 وربط R-100 بـ02.01) |
| `node <file>` لكل `tests/**/*.test.js` (26 ملفاً) | 0 فشل، كل رموز الخروج 0 |
| Playwright e2e-v1 / e2e-v1-ui / v1-boundaries / student-no-leak | 81 / 136 / 11 / 24 — 0 فشل (الكامل 1568/0 نُفّذ في 00.02 والكود لم يتغير) |
| `sha256sum -c docs/architecture/code-baseline.sha256` | 14/14 OK |
| `capture-reference.js 00.04 --docs` (4 وثائق) | صور في `الصور المرجعية/00.04/`؛ لم تُقرأ بصرياً |
| بحث ويب رسمي (Supabase، Cloudflare Pages، Bubblewrap/TWA، auth admin) | نتائج مسجلة في `ARCHITECTURE-V2.md` §12؛ الصفحات لم تُفتح كاملة |
| لم يُختبر | سلوك Auth، Docker/Supabase، Web Push، TWA/APK، هواتف، Safari |

## 2026-11-08 — تعديل أداة وقاعدة الصور المرجعية (وثائق وأداة التقاط فقط)
| الأمر | النتيجة |
|---|---|
| `capture-reference.js _tool-check --docs docs/execution-v2/GATES.md` | 8 صور، كلها `-dark` (لا فاتح)، كلها أكبر من صفر؛ لم تُقرأ؛ حُذف المجلد المؤقت |
| `node <file>` لكل `tests/**/*.test.js` | انظر الصف التالي |
| نتيجة إعادة التشغيل | Node 26 ملفاً 0 فشل؛ Playwright e2e-v1 81 / e2e-v1-ui 136 / boundaries 11 / student-no-leak 24 — 0 فشل؛ `check-architecture` 42/0؛ `check-traceability` 21/0؛ بصمات 14/14 |

## 01.01 — 2026-11-08 (Ubuntu 24، Node v22.23.4، Chromium headless Playwright، بلا شبكة) — تصميم وثائق + اختبارات مستوى المصفوفة
| الأمر | النتيجة |
|---|---|
| `node tests/security/access-matrix-v2.test.js` | 152 نجاح، 0 فشل: اكتمال 396 خلية، 16 ثابتاً، مطابقة تشفير مستقل لكل الخلايا، AM-01…AM-33، 48 طفرة على المصفوفة تُكتشف كلها، اتساق الوثيقة والـJSON المولَّدة، T-67…T-78 |
| طفرات على `canV2` نفسه (6 تعديلات: cross-class، الحالة، not-self، قيد الهدف، تأكيد الدعم، فلتر الأرشفة) على نسخة مؤقتة | كل تعديل كُشف باختبار واحد على الأقل؛ تعديل سابع (حارس `any`) كان زائداً فأُضيف له AM-32 |
| `node tests/security/generate-access-v2.js --check` | متطابق |
| `node <file>` لكل `tests/**/*.test.js` | 27 ملفاً، 984 سطر PASS (832 سابقة + 152)، 0 ملف فاشل |
| `node docs/execution-v2/tools/check-architecture.js` | 42 نجاح، 0 فشل (بعد تحديث الحارس) |
| `node docs/execution-v2/tools/check-traceability.js` | 21 نجاح، 0 فشل |
| Playwright e2e-v1 / e2e-v1-ui / boundaries / student-no-leak | 81 / 136 / 11 / 24 — 0 فشل (الكامل 1568/0 نُفّذ في 00.02 والكود لم يتغير) |
| `sha256sum -c docs/architecture/code-baseline.sha256` | 14/14 OK |
| الصور المرجعية | `capture-reference.js 01.01 --docs docs/execution-v2/ACCESS-MATRIX-V2.md`: 8 صور داكنة في `الصور المرجعية/01.01/` (V1 وfull.html + الوثيقة، هاتف وحاسبة)، كلها > 0 بايت؛ لم تُقرأ. (صورة الوثيقة على الهاتف حجمها صغير نسبياً ≈ 2.7KB — يراجعها المستخدم) أُضيفت متأخراً بعد ملاحظة المستخدم؛ كان الإغفال الأول خطأ من المنفّذ |
| **لم يُختبر** | أي سياسة RLS/RPC/Edge على Postgres (لا Docker ولا مشروع Supabase)؛ Realtime مع RLS؛ Storage policies؛ Auth؛ الهواتف. فحوص قاعدة البيانات L-01…L-14 مخططة فقط |

## 01.02 — 2026-11-09 (Linux، Node v22.23.4، PostgreSQL 16 محلي مؤقت على 127.0.0.1، بلا شبكة ولا حسابات)
| الأمر | النتيجة |
|---|---|
| `MARSA_PG_TMP=… node tests/db/schema-v2.test.js` | 241 نجاح، 0 فشل (مخطط، قيود، مشغّلات، رموز، حضور، درجات، تحاضير، مرفقات، دفعات، إشعارات، دعم، تدقيق، رفض افتراضي، احتفاظ، تعدد شعب) |
| دفعتان متزامنتان بجلستين حقيقيتين (DB-237، 238) | تنجح كلتاهما حين يتسع المستحق؛ تفشل واحدة حين يتجاوز؛ المجموع صحيح |
| حمل سنة اصطناعية (100 طالب × 170 يوماً) | ≈ 13.9 MB للجداول؛ تحميل ≈ 2 ث؛ `verify_cost_totals` = 0 انحراف |
| كل `tests/**/*.test.js` (28 ملفاً) | 1225 نجاح، 0 فشل (984 سابقاً + 241) |
| `check-architecture` / `check-traceability` | 42/0 · 21/0 |
| `generate-access-v2.js --check` / `generate-data-model.js --check` | متطابق · متطابق |
| `sha256sum -c code-baseline.sha256` | 14/14 |
| Playwright الأساسي: e2e-v1، e2e-v1-ui، e2e-attendance، e2e-payments | 81 · 136 · 76 · 91 نجاحاً، 0 فشل (كود التطبيق لم يتغير) |
**أخطاء كشفها الاختبار وأُصلحت:** `fold_ar` لا يحوّل «ة»→«ه» (DB-18)؛ مفتاح أجنبي بلا فهرس في محاولات التفعيل (DB-11).
**لم يُختبر:** Supabase الحقيقي، سياسات RLS النهائية، حمل متزامن إنتاجي، ترحيل V1، Docker.
**الصور المرجعية:** لا تُنتَج لأن هذا البرومبت وثائقي/مخطط بيانات بلا أي تغيير مرئي في الواجهة.

**01.02 — صور مرجعية (بطلب المستخدم 2026-11-09):** `الصور المرجعية/01.02/` — 6 صور داكنة فقط (هاتف وحاسبة) لحالة V1 وfull.html الحالية؛ لا تغيير مرئي في هذا البرومبت. تحقق: كل ملف موجود وحجمه أكبر من صفر (0 ملفات فارغة)، دون فتح الصور.

## 01.05 — 2026-11-11/12 (Linux، Node v22.23.4، Chromium headless Playwright، بلا شبكة) — تصميم + معاينة ثابتة
| الأمر | النتيجة |
|---|---|
| `node tests/ui/ui-map-v2.test.js` | 73 نجاحاً، 0 فشل (اتساق مع المصفوفة والمعجم والأشرطة والقوائم والتباين والحركة والوثيقة والمعاينة والبصمات) |
| `NODE_PATH=$(npm root -g) node tests/e2e-ui-preview.playwright.js` | 55 نجاحاً، 0 فشل (320/390/1280 فاتح/داكن؛ قائمة، تركيز، قيد التطوير، الصفحات الثلاث، دعم، ثيم، لمس، تقليل الحركة، بلا شبكة) |
| `generate-ui-map.js --check` / `build-preview.js --check` | متطابقان |
| `check-traceability` / `check-architecture` | 21/0 · 42/0 |
| كل `tests/**/*.test.js` | 29 ملفاً، 1298 نجاحاً، 0 فشل |
| Playwright e2e-v1 / e2e-v1-ui / attendance / payments | 81 / 136 / 76 / 91 — 0 فشل |
| `sha256sum -c code-baseline.sha256` | 14/14 OK |
| **لم يُختبر** | هاتف حقيقي، Safari/iPhone، قارئ شاشة، خطوط الأجهزة، أداء الحركة؛ أي مطلب على التطبيق الفعلي (الواجهة غير منفّذة) |
**الصور المرجعية:** `الصور المرجعية/01.05/` — 14 صورة داكنة فقط (V1 وfull.html + وثيقة UI-MAP + المعاينة بهاتف/حاسبة)، كلها > 0 بايت؛ لم تُفتح ولم تُقرأ.

## 02.01 — 2026-11-12 (Linux، Node v22.23.4، Chromium headless Playwright، بلا شبكة) — هيكل V2 + اختبارات عزل وتكافؤ وانحدار
| الأمر | النتيجة |
|---|---|
| `node tests/v2/v2-isolation.test.js` | 52 نجاحاً، 0 فشل |
| `node tests/v2/legacy-parity.test.js` | 53 نجاحاً، 0 فشل |
| `NODE_PATH=$(npm root -g) node tests/v2/e2e-v2-foundation.playwright.js` | 28 نجاحاً، 0 فشل (تحت CSP من `v2/_headers`، V1 وfull.html على الأصل نفسه، تجربة الرجوع بلا `v2/`) |
| طفرات متعمدة (7) | كُشفت كلها ثم استُرجعت |
| `node scripts/v2-sync.js --check` | OK (8 ملفات) |
| كل `tests/**/*.test.js` | 31 ملفاً، 1403 نجاحاً، 0 فشل |
| كل `tests/**/*.playwright.js` | 25 ملفاً، 1651 نجاحاً، 0 فشل |
| `sha256sum -c v1-parity.sha256` / `code-baseline.sha256` | 22/22 · 14/14 OK |
| `check-traceability` / `check-architecture` | 21/0 · 42/0 |
| لم يُختبر | تكافؤ الوظائف P2 والأجهزة P3، Safari/Firefox، هاتف حقيقي، أداء الفتح، اتصال بخدمات |
**الصور المرجعية:** `الصور المرجعية/02.01/` — 8 صور داكنة فقط (V1 وfull.html وصفحة هيكل V2، هاتف وحاسبة)، كلها > 0 بايت؛ لم تُفتح ولم تُقرأ.
التفاصيل في `V2-FOUNDATION.md` §9.

## 02.02 — 2026-11-14 (Linux، Node v22.23.4، Chromium 153 رأسي، Playwright 1.63، معالج واحد، بلا شبكة) — قشرة V2
| الأمر | النتيجة |
|---|---|
| `node tests/v2/shell-config.test.js` (جديد) | 68 نجاحاً، 0 فشل (أول تشغيل: 5 إخفاقات بين خلل كود حقيقي ثم ضبط اختبار ◄ 0) |
| `NODE_PATH=$(npm root -g) node tests/v2/e2e-v2-shell.playwright.js` (جديد) | 181 نجاحاً، 0 فشل (عدة جولات إصلاح؛ ثلاثة إصلاحات كود: التبويب الأب للممثل، ارتفاع شريط الدعم الكسري، عرض المنتقي) |
| `node tests/v2/v2-isolation.test.js` | 52 / 0 |
| `node tests/v2/legacy-parity.test.js` | 57 / 0 (كان 53؛ الفحص حُسِّن ووُسِّع إلى shell/components) |
| `NODE_PATH=$(npm root -g) node tests/v2/e2e-v2-foundation.playwright.js` (مكيَّف) | 29 / 0 |
| `node <file>` لكل `tests/**/*.test.js` (32 ملفاً) | **31 ملفاً: 1300 نجاح / 0 فشل**؛ `tests/db/schema-v2.test.js` **تخطّى** (لا PostgreSQL على هذا الجهاز ◄ لم يُختبر) |
| `NODE_PATH=$(npm root -g) node <file>` لكل `tests/**/*.playwright.js` (26 ملفاً) | **1833 فحصاً / 0 فشل** (24 قديماً = 1623 + foundation 29 + shell 181)؛ `e2e-isolation` يستغرق ≈212ث (144/0 عند إعادته منفرداً بعد أن قطعته مهلة 140ث) |
| `node scripts/v2-sync.js --check` · `node scripts/v2-nav-sync.js --check` | مطابقان (8 ملفات · 2 ملف) |
| `node docs/execution-v2/tools/check-traceability.js` · `check-architecture.js` | 21 / 0 · 42 / 0 |
| `sha256sum -c docs/execution-v2/v1-parity.sha256` · `docs/architecture/code-baseline.sha256` | 22/22 · 14/14 OK |
| 8 طفرات على نسخ مؤقتة (`/tmp`) | 8/8 كُشفت: حارس الدور مفتوح (node) · `left:0` بدل المنطقي (node) · التبويب الأب خاطئ (node) · inert الخلفية محذوف (e2e E3) · إعادة التركيز محذوفة (e2e E5) · المظهر لا يُحفظ (e2e G3) · الكتابة دون اتصال مفعّلة (e2e F12) · ختم «آخر تحديث» محذوف (e2e F10 ينهار بمهلة `.stamp` برمز خروج 2) |
| `node docs/execution-v2/tools/capture-reference.js المهمة-009 --no-base --v2-shell` | 26 لقطة داكنة؛ فُحص الوجود وحجم > 0 (26/26، 0 فارغة، 0 مفقودة)؛ **لم تُفتح** |
| لم يُختبر | Safari/Firefox/هاتف حقيقي، safe-area على iPhone، قارئ شاشة، PostgreSQL (`schema-v2.test.js`)، الشبكة/Supabase، PWA (02.03) |
**أخطاء الاختبار والتصحيح:** موثقة في `UI-SHELL-REPORT.md` §7. لم يُضعَف أي اختبار أمان؛ عُدّل اختباران قديمان لسبب موثّق (التقرير §7).
**اللقطات:** `الصور المرجعية/المهمة-009/` — 26 صورة داكنة (هاتف/تابلت/حاسبة)، لم تُفتح ولم تُوصف.
**الأرشيف:** يُسجَّل بعد بنائه في `PROJECT_MEMORY/06_TASK_HISTORY.md` (المهمة-009).
